# ⚠️ Backend Fix Required: Parallel Agent Execution

## Issue Summary

The UI is working correctly, but **agents are running sequentially, not in parallel**. This is a backend issue.

## What's Happening Now (Sequential)

```
Time 0s:  agent_activated: BrowserExecutor
Time 1s:  [Browser does work...]
Time 2s:  agent_deactivated: BrowserExecutor  ← Browser finishes
Time 2s:  agent_activated: TerminalExecutor   ← Terminal starts AFTER browser
Time 3s:  [Terminal does work...]
Time 4s:  agent_deactivated: TerminalExecutor
```

**Result:** Only one agent visible at a time (sequential execution)

## What Should Happen (Parallel)

```
Time 0s:  agent_activated: BrowserExecutor
Time 0s:  agent_activated: TerminalExecutor   ← Both start together
Time 1s:  [Both agents work simultaneously...]
Time 2s:  agent_deactivated: BrowserExecutor  ← Both finish
Time 2s:  agent_deactivated: TerminalExecutor
```

**Result:** Both agents visible simultaneously (parallel execution)

## Backend Code Fix

### Current (Sequential) - ❌

```python
# Browser executes first
await browser_executor.activate()
result1 = await browser_executor.execute(task)
await browser_executor.deactivate()

# Then terminal executes
await terminal_executor.activate()
result2 = await terminal_executor.execute(task)
await terminal_executor.deactivate()
```

### Fixed (Parallel) - ✅

**Option 1: Using asyncio.gather**

```python
# Activate both agents
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_activated", 
    "agent": "TerminalExecutor"
})

# Execute both in parallel
results = await asyncio.gather(
    browser_executor.execute(task),
    terminal_executor.execute(task)
)

# Deactivate both
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "TerminalExecutor"
})
```

**Option 2: Using asyncio.create_task**

```python
# Activate both agents
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "TerminalExecutor"
})

# Create parallel tasks
browser_task = asyncio.create_task(browser_executor.execute(task))
terminal_task = asyncio.create_task(terminal_executor.execute(task))

# Wait for both to complete
browser_result = await browser_task
terminal_result = await terminal_task

# Deactivate both
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "TerminalExecutor"
})
```

**Option 3: Using TaskGroup (Python 3.11+)**

```python
# Activate both agents
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "TerminalExecutor"
})

# Execute in parallel
async with asyncio.TaskGroup() as tg:
    browser_task = tg.create_task(browser_executor.execute(task))
    terminal_task = tg.create_task(terminal_executor.execute(task))

# Deactivate both
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "BrowserExecutor"
})
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "TerminalExecutor"
})
```

## Where to Make Changes

Look for code that:
1. Activates agents
2. Executes agent tasks
3. Deactivates agents

Likely locations:
- `uv/src/uv/services/swarm_service.py`
- `uv/src/uv/services/task_service.py`
- `Synapse/core/conductor.py`
- Agent executor classes

## Key Points

1. **Don't deactivate agents until they're done working**
   - Current: Deactivate immediately after execute() returns
   - Fixed: Keep active during entire parallel execution

2. **Use async/await for parallel execution**
   - `asyncio.gather()` for simple parallel execution
   - `asyncio.create_task()` for more control
   - `asyncio.TaskGroup()` for structured concurrency

3. **Broadcast activation/deactivation events at the right time**
   - Activate: When agent starts working
   - Deactivate: When agent finishes working (not before!)

## Testing

After backend fix, you should see:

```
✅ agent_activated: BrowserExecutor
✅ agent_activated: TerminalExecutor
   [Both agents work...]
   [UI shows both agents simultaneously]
✅ agent_deactivated: BrowserExecutor
✅ agent_deactivated: TerminalExecutor
```

## UI Changes Already Made

✅ **Layout:** Changed to vertical split (top/bottom)
✅ **xterm.js:** Fixed loading race condition with retry logic
✅ **Event Queueing:** Terminal events are queued if not ready
✅ **Multi-Agent Support:** UI correctly handles multiple active agents

**The UI is ready. The backend needs to be updated to run agents in parallel.**

## Quick Test

To verify the UI works with parallel agents, you can manually trigger in DevTools:

```javascript
// Activate both agents
app.agentViewManager.activateAgent('BrowserExecutor');
app.agentViewManager.activateAgent('TerminalExecutor');

// Check layout
const container = document.getElementById('agents-grid-workspace');
console.log('Layout class:', container.className); // Should be 'split-view-2'
console.log('Active agents:', app.agentViewManager.getActiveAgents()); // Should be ['BrowserExecutor', 'TerminalExecutor']
```

You should see both agents displayed vertically (top/bottom).
