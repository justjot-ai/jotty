# A-Team Review: WhatsApp Baileys Rate Limit Alternatives

**Date:** 2026-02-03  
**Feature:** ADR – WhatsApp Baileys rate limit alternatives  
**Status:** APPROVED ✅

---

## A-Team Debate: Alternatives and Priorities

### 1. “Just Use Official API” vs “Stay Unofficial”

**Cursor Engineering Head:**
> "The only way to avoid rate limits for good is the Cloud API. Everything else is duct tape."

**Young MIT Graduate:**
> "Cloud API means Business Account, templates, and a different product. We’re automating a personal/single-number flow. Throwing 'use official API' at every problem is lazy—we need mitigations first."

**Claude Code Lead:**
> "ADR correctly separates short-term (harden Baileys) from medium-term (evaluate Cloud API or hosted). Nobody said 'only' official; we’re proposing a path, not a rewrite tomorrow."

**CONSENSUS:** Mitigate first, then evaluate Cloud API or hosted; don’t drop Baileys without a clear migration target ✅

---

### 2. Pairing Code vs QR

**Systems/Performance:**
> "Pairing code = one less 'new device' handshake. Fewer connection events, less surface for rate limits. We should implement it."

**QA/Validation:**
> "QR is already in the UI and works. Pairing code is another flow to test and document. Do we have evidence that QR itself is what’s being rate-limited, or is it reconnect storms?"

**Reliability/SRE:**
> "Both matter. Pairing code reduces churn; backoff and cooldown prevent storms. ADR should list pairing code as optional improvement, not the only fix."

**CONSENSUS:** Add pairing code as an option; keep QR; prioritize backoff/cooldown and single-session behaviour ✅

---

### 3. whatsapp-web.js – Worth the Migration?

**Young MIT Graduate:**
> "Switching to whatsapp-web.js is a big refactor for 'maybe different rate limits.' We already have Electron and Baileys. That’s a lot of work for a maybe."

**Product/UX:**
> "If we ever switch, it’s for diversification of client type (browser vs WebSocket), not because we proved Baileys is uniquely bad. ADR wording is correct: consider only if we explicitly want that."

**CONSENSUS:** Don’t migrate to whatsapp-web.js unless we have a clear reason (e.g. Baileys deprecated or blocked); document as alternative only ✅

---

### 4. Hosted API (Whapi.Cloud etc.)

**Info Theory (Shannon):**
> "Third-party = data leaves our stack. That’s a cost. Document it."

**RL/Optimization:**
> "For teams that need 'it just works' and can pay, hosted is a valid path. ADR should list pros (proxy, managed retries) and cons (cost, vendor lock-in, ToS)."

**CONSENSUS:** Keep hosted as a medium-term option with clear pros/cons; no commitment to a specific vendor ✅

---

## Verdict on ADR

- **Short term:** Harden Baileys (backoff, cooldown, single session, optional pairing code).  
- **Medium term:** Evaluate WhatsApp Cloud API where it fits; otherwise evaluate hosted unofficial API.  
- **Alternative stack:** whatsapp-web.js only if we explicitly want browser-based client diversification.

**FINAL:** ADR approved. Implement mitigations in `whatsapp-service.js` per ADR; no change to Python/Electron contract until we choose a different backend.
