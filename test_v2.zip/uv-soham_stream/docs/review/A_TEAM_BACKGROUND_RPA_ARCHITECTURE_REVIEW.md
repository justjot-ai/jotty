# A-Team Review: Background RPA Architecture

**Date:** 2026-02-04  
**Topic:** Non-Intrusive Background RPA System Design  
**Attendees:** Architect Alex, Backend Bob, Systems/Performance Sam, Security/Privacy Sarah, Reliability/SRE Rick, QA Quinn, Product/UX Pat

---

## Context

**User Request:** "I want to do sort of background RPA, but I want to do it in background such that user can perform their daily work as well as apps actions can be performed by RPA."

**Current State:**
- Executor agents (BrowserExecutor, TerminalExecutor) run synchronously
- Tasks block user interactions
- No isolation between RPA and user's active applications
- No task queue or scheduling system

**Proposed Solution:**
- Background task queue system
- Virtual display isolation
- Background RPA executor service
- Task scheduler for recurring tasks
- REST API endpoints

---

## Team Discussion

### Architect Alex (Opens Meeting)

"Alright team, we have a clear user requirement: background RPA that doesn't interfere with daily work. I've drafted an architecture with 5 core components:

1. **Task Queue Service** - Priority-based queue with persistence
2. **Virtual Display Manager** - OS-specific display isolation
3. **Background RPA Executor** - Wraps existing executors
4. **RPA Scheduler** - Cron-like scheduling
5. **REST API** - Task management endpoints

The key insight is using virtual displays to isolate GUI automation from the user's active display. This allows RPA to run in the background while the user continues working.

Thoughts?"

---

### Backend Bob (Skeptical)

"Alex, this is OVER-ENGINEERED. Let me break down what you're proposing:

**Virtual Display Manager Issues:**

**macOS:**
- You're suggesting headless Chrome with separate profile
- But macOS doesn't support true virtual displays like Linux
- Headless Chrome STILL uses system resources and can interfere
- Separate profile doesn't prevent window focus stealing
- What about TerminalExecutor? It WILL interfere with user's terminal

**Linux:**
- Xvfb is reasonable, BUT:
  - Requires X server (not available in all environments)
  - Adds 200-500MB memory overhead per display
  - Complex process management
  - What if user is on Wayland? Xvfb doesn't work!

**Windows:**
- You literally wrote 'Windows doesn't support virtual displays easily'
- So what's the plan? Just give up on Windows?
- Separate desktop sessions require admin privileges
- Not portable at all

**This is a 3-platform problem with 3 different solutions, and 2 of them are half-baked.**

Plus, you're proposing a COMPLETE NEW SERVICE LAYER. We already have:
- `TaskService` in `uv/src/uv/services/task_service.py`
- `SwarmService` for conductor management
- `solve_task_sync` for task execution

Why are we creating ANOTHER service layer? This violates DRY principles."

---

### Systems/Performance Sam (Concerned)

"Bob's right about the complexity, but let me add PERFORMANCE concerns:

**Resource Overhead:**

1. **Virtual Displays:**
   - Xvfb: 200-500MB RAM per display
   - Chrome headless: 100-300MB RAM per instance
   - If we run 5 concurrent tasks = 1.5-4GB RAM overhead
   - User's machine might not have that!

2. **Process Isolation:**
   - Each background task = new process
   - Process creation overhead: 50-200ms per task
   - Context switching overhead
   - If queue has 100 tasks, we're creating 100 processes?

3. **Task Queue Persistence:**
   - You mentioned 'survive restarts'
   - That means database or file-based persistence
   - Database = additional dependency (PostgreSQL? SQLite?)
   - File-based = race conditions, corruption risk
   - Either way = I/O overhead

**Concurrency Limits:**
- You mentioned 'concurrent task execution limits'
- But what's the limit? 5? 10? 50?
- How do we prevent resource exhaustion?
- What if user has 8GB RAM and we spawn 20 Chrome instances?

**This will CRUSH user's machine.**"

---

### Security/Privacy Sarah (Alarmed)

"Hold on, SECURITY concerns:

**Virtual Display Security:**

1. **Xvfb on Linux:**
   - If we expose Xvfb displays, they're accessible to other processes
   - Need proper X11 security (xhost, XAUTHORITY)
   - Misconfiguration = other users can see RPA actions
   - Screenshot capture could leak sensitive data

2. **Chrome Headless:**
   - Separate profile doesn't prevent cookie/session leakage
   - If RPA logs into user's account, cookies persist
   - What if RPA accesses user's personal data?
   - No clear data isolation boundaries

3. **Process Isolation:**
   - Background processes run with same user permissions
   - If RPA task is compromised, attacker has user's permissions
   - No sandboxing mentioned in the design

**Task Queue Security:**

- REST API endpoints for task management
- Who can submit tasks? Any authenticated user?
- What prevents DoS attacks? (submit 1000 tasks)
- Task instructions could contain malicious code
- No input validation mentioned

**This is a SECURITY NIGHTMARE waiting to happen.**"

---

### Reliability/SRE Rick (Frustrated)

"Everyone's missing the OPERATIONAL nightmare:

**Process Management:**

1. **Orphaned Processes:**
   - What if background task crashes?
   - Virtual display stays running forever
   - Chrome process stays alive
   - Memory leak over time

2. **Cleanup Failures:**
   - You mentioned 'automatic cleanup on task completion'
   - But what if cleanup fails?
   - What if process is killed (SIGKILL)?
   - What if system crashes mid-task?

3. **Monitoring:**
   - How do we know if background task is stuck?
   - How do we detect zombie processes?
   - What's the alerting strategy?
   - No monitoring mentioned in the design!

**Task Queue Reliability:**

- Queue persistence: What if disk is full?
- What if database is corrupted?
- What if queue file is locked?
- No recovery mechanism mentioned

**Scheduler Reliability:**

- Cron-like scheduling: What if system time changes?
- What if system sleeps/hibernates?
- What if scheduler process crashes?
- How do we handle missed schedules?

**This will create OPERATIONAL CHAOS.**"

---

### QA Quinn (Overwhelmed)

"Guys, let's talk about TESTING:

**What needs testing:**

1. **Virtual Display Isolation:**
   - Does RPA actually not interfere with user?
   - Test on macOS, Linux, Windows
   - Test with multiple concurrent tasks
   - Test with user actively using apps
   - Test edge cases (user switches apps mid-task)

2. **Task Queue:**
   - Priority ordering
   - Concurrent execution limits
   - Persistence and recovery
   - Retry mechanism
   - Error handling

3. **Background Executor:**
   - Process isolation
   - Resource limits
   - Timeout handling
   - Output capture
   - Log collection

4. **Scheduler:**
   - Cron parsing
   - Timezone handling
   - Missed schedule recovery
   - Task dependencies

5. **API Endpoints:**
   - All CRUD operations
   - Authentication/authorization
   - Rate limiting
   - Error responses

**Test Coverage Needed:**
- Unit tests: 200+ test cases
- Integration tests: 50+ scenarios
- End-to-end tests: 20+ workflows
- Performance tests: Load testing
- Security tests: Penetration testing
- Cross-platform tests: macOS/Linux/Windows

**This is 2-3 MONTHS of testing work.**"

---

### Product/UX Pat (Confused)

"Wait, I'm confused about the USER EXPERIENCE:

**User's Mental Model:**

User wants: 'RPA runs in background, I keep working'

But what does that MEAN?

1. **Visibility:**
   - Does user see RPA is running?
   - Notification? Status bar? Dashboard?
   - What if RPA fails silently?

2. **Interruption:**
   - What if user needs to use the same app RPA is using?
   - What if RPA needs user input?
   - What if RPA conflicts with user's actions?

3. **Control:**
   - How does user pause/cancel RPA?
   - How does user see what RPA is doing?
   - How does user debug failed tasks?

**The design mentions:**
- 'Status monitoring and logging'
- But WHERE? In UI? CLI? API only?

**Current Electron App:**
- We have a UI with agent views
- But background RPA = no UI feedback?
- User has no idea what's happening?

**This is TERRIBLE UX. User will be confused and frustrated.**"

---

### Architect Alex (Defensive)

"Okay, okay, I hear you all. Let me address concerns:

**Bob's Virtual Display Concerns:**
- macOS: Use headless browser + separate Chrome profile (best we can do)
- Linux: Xvfb for X11, headless for Wayland
- Windows: Headless browser only (acknowledge limitation)

**Sam's Performance Concerns:**
- Add resource limits: Max 3 concurrent tasks by default
- Configurable limits per user
- Process pooling to reuse Chrome instances
- Monitor resource usage and throttle

**Sarah's Security Concerns:**
- Add input validation for task instructions
- Rate limiting on API endpoints
- Sandboxing for background processes (Docker on Linux)
- Clear data isolation boundaries

**Rick's Reliability Concerns:**
- Add process monitoring and cleanup daemon
- Health checks for background tasks
- Automatic recovery for stuck tasks
- Queue corruption recovery mechanism

**Quinn's Testing Concerns:**
- Phased testing approach
- Start with critical paths
- Add tests incrementally

**Pat's UX Concerns:**
- Add UI dashboard for background tasks
- Real-time status updates via WebSocket
- Notifications for task completion/failure
- Task logs accessible in UI

**Revised Architecture:**

1. **Simplified Virtual Display:**
   - macOS: Headless Chrome (acknowledge limitation)
   - Linux: Xvfb (X11) or headless (Wayland)
   - Windows: Headless Chrome only

2. **Resource Management:**
   - Process pool for Chrome instances
   - Configurable concurrency limits
   - Resource monitoring and throttling

3. **Security Hardening:**
   - Input validation
   - Rate limiting
   - Sandboxing where possible

4. **Reliability:**
   - Process monitoring daemon
   - Automatic cleanup
   - Health checks

5. **UX:**
   - UI dashboard
   - WebSocket status updates
   - Task logs in UI

**Better?""

---

### Backend Bob (Still Skeptical)

"Alex, you're STILL over-engineering. Let me propose a SIMPLER solution:

**What if we DON'T use virtual displays at all?**

**Simpler Approach:**

1. **Headless Browser Only:**
   - All browser automation runs headless
   - No virtual display needed
   - Works on all platforms
   - Lower resource overhead

2. **Terminal Isolation:**
   - Use separate terminal sessions (already supported)
   - Each RPA task gets its own terminal
   - User's terminal unaffected

3. **Task Queue (Simplified):**
   - In-memory queue (no persistence initially)
   - Add persistence later if needed
   - Simple priority queue

4. **Background Execution:**
   - Run tasks in background threads/processes
   - Use existing `asyncio` patterns
   - No need for separate executor service

5. **UI Integration:**
   - Add background task list to existing UI
   - Show status, logs, results
   - Use existing WebSocket infrastructure

**Benefits:**
- Simpler implementation (2-3 weeks vs 2-3 months)
- Lower resource overhead
- Works on all platforms consistently
- Reuses existing infrastructure

**Trade-offs:**
- Browser automation is headless (user can't see it)
- But user doesn't NEED to see it if it's background!

**Why is this worse than your virtual display approach?**"

---

### Systems/Performance Sam (Agrees)

"Bob's approach is MUCH better:

**Resource Comparison:**

**Alex's Approach:**
- Virtual displays: 200-500MB per task
- Chrome instances: 100-300MB per task
- Total: 300-800MB per concurrent task
- 5 tasks = 1.5-4GB RAM

**Bob's Approach:**
- Headless Chrome: 100-200MB per task
- Terminal sessions: 10-50MB per task
- Total: 110-250MB per concurrent task
- 5 tasks = 550MB-1.25GB RAM

**Bob's approach uses 50-70% LESS memory.**

Plus:
- Simpler = fewer bugs
- Simpler = easier to maintain
- Simpler = faster to implement

**I vote for Bob's simplified approach.**"

---

### Security/Privacy Sarah (Partially Convinced)

"Bob's approach is better, but I still have concerns:

**Headless Browser Security:**
- Still need input validation
- Still need rate limiting
- Still need sandboxing where possible

**Terminal Isolation:**
- Separate sessions are good
- But need to ensure no file system conflicts
- Need to handle environment variable isolation

**Task Queue:**
- In-memory is fine for MVP
- But need persistence for production
- Need to handle queue corruption

**I agree with Bob's simplified approach, BUT:**
- Add security measures from the start
- Don't skip security for simplicity"

---

### Reliability/SRE Rick (More Convinced)

"Bob's approach is more OPERATIONALLY SOUND:

**Process Management:**
- Headless Chrome = easier to manage
- Fewer moving parts = fewer failure points
- Simpler cleanup logic

**Monitoring:**
- Can reuse existing monitoring
- Simpler to add health checks
- Easier to debug issues

**BUT:**
- Still need process monitoring daemon
- Still need cleanup mechanisms
- Still need health checks

**I agree with Bob's approach, with operational safeguards.**"

---

### QA Quinn (Relieved)

"Bob's approach is MUCH MORE TESTABLE:

**Simpler = Fewer Test Cases:**

1. **Headless Browser:**
   - Test headless Chrome automation
   - Test on all platforms
   - Test concurrent tasks
   - ~50 test cases (vs 200+ for virtual displays)

2. **Terminal Isolation:**
   - Test separate terminal sessions
   - Test environment isolation
   - ~20 test cases

3. **Task Queue:**
   - Test priority ordering
   - Test concurrent limits
   - Test error handling
   - ~30 test cases

4. **Background Execution:**
   - Test process isolation
   - Test resource limits
   - Test timeout handling
   - ~40 test cases

**Total: ~140 test cases (vs 300+ for Alex's approach)**

**Much more manageable. I can test this in 3-4 weeks instead of 2-3 months.**"

---

### Product/UX Pat (Happy)

"Bob's approach is BETTER UX:

**User's Mental Model:**
- 'RPA runs in background' = headless is fine
- User doesn't need to SEE browser automation
- User just needs STATUS and RESULTS

**UI Integration:**
- Add background task list to existing UI
- Show: Status, Progress, Logs, Results
- Use existing WebSocket for updates
- Simple, clean, familiar

**This matches user expectations better.**

**I vote for Bob's approach.**"

---

### Architect Alex (Conceding)

"Fine, fine. Bob's approach is simpler and better. Let me revise the architecture:

**Revised Background RPA Architecture:**

1. **Headless Browser Automation:**
   - All browser tasks run headless
   - Works consistently on all platforms
   - Lower resource overhead

2. **Terminal Isolation:**
   - Separate terminal sessions per task
   - Environment variable isolation
   - File system conflict prevention

3. **Simplified Task Queue:**
   - In-memory priority queue (MVP)
   - Add persistence later if needed
   - Simple FIFO with priority override

4. **Background Execution:**
   - Use existing `asyncio` patterns
   - Run tasks in background threads/processes
   - Reuse existing executor agents

5. **UI Integration:**
   - Add background task dashboard to Electron UI
   - WebSocket status updates
   - Task logs and results in UI

6. **Security & Reliability:**
   - Input validation
   - Rate limiting
   - Process monitoring
   - Health checks
   - Automatic cleanup

**Implementation Plan:**

**Phase 1 (Week 1-2):**
- Headless browser support
- Terminal isolation
- Basic task queue (in-memory)

**Phase 2 (Week 3):**
- Background execution integration
- Process monitoring
- Health checks

**Phase 3 (Week 4):**
- UI dashboard
- WebSocket updates
- Task logs

**Phase 4 (Week 5):**
- Testing
- Bug fixes
- Documentation

**Total: 5 weeks (vs 12+ weeks for virtual display approach)**

**Better?""

---

### Backend Bob (Satisfied)

"Much better, Alex. This is realistic and achievable.

**One more thing:**
- Let's use existing `TaskService` infrastructure
- Don't create duplicate services
- Extend what we have instead of building new

**I approve this revised architecture.**"

---

### Systems/Performance Sam (Approves)

"Resource overhead is acceptable.
Implementation timeline is realistic.
I approve."

---

### Security/Privacy Sarah (Conditional Approval)

"Add security measures from Phase 1:
- Input validation
- Rate limiting
- Basic sandboxing

Then I approve."

---

### Reliability/SRE Rick (Approves)

"Add operational safeguards from Phase 1:
- Process monitoring
- Health checks
- Cleanup mechanisms

Then I approve."

---

### QA Quinn (Approves)

"Testable in reasonable timeframe.
I approve."

---

### Product/UX Pat (Approves)

"Better UX.
I approve."

---

## A-Team Consensus

**Unanimous Approval** (with conditions):

1. ✅ **Simplified Architecture**: Headless browser + terminal isolation
2. ✅ **Reuse Existing Infrastructure**: Extend `TaskService`, don't duplicate
3. ✅ **Security from Start**: Input validation, rate limiting, sandboxing
4. ✅ **Operational Safeguards**: Process monitoring, health checks, cleanup
5. ✅ **UI Integration**: Dashboard, WebSocket updates, task logs
6. ✅ **Phased Implementation**: 5 weeks, incremental delivery

**Key Changes from Original Design:**

- ❌ **Removed**: Virtual Display Manager (too complex, platform-specific)
- ✅ **Simplified**: Headless browser for all platforms
- ✅ **Simplified**: In-memory task queue (add persistence later)
- ✅ **Simplified**: Reuse existing services instead of creating new ones
- ✅ **Added**: Security measures from Phase 1
- ✅ **Added**: Operational safeguards from Phase 1

**Next Steps:**

1. Update ADR with revised architecture
2. Create detailed implementation plan for Phase 1
3. Begin implementation of headless browser support
4. Add security and operational safeguards

---

## Final Verdict

**APPROVED** - Simplified Background RPA Architecture

The team unanimously agrees that Bob's simplified approach is superior:
- Simpler implementation (5 weeks vs 12+ weeks)
- Lower resource overhead (50-70% less memory)
- Works consistently on all platforms
- More testable and maintainable
- Better UX alignment

**Ready to proceed with implementation.**
