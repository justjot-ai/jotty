# A-TEAM REVIEW: User Message Missing Key Details Fix

**Date:** 2026-02-02  
**Issue:** User message says "I have recommendations ready" instead of showing actual flight details  
**Severity:** HIGH - Defeats purpose of user-friendly communication  

---

## Problem Statement

When a user asks for flight recommendations, the system:
- **FINAL OUTPUT** contains: "SQ403 (21:45) and AI2380 (23:00), 5h 30m-6h 20m, direct flights, Terminal 3 to Terminal 2"
- **USER MESSAGE** says: "I've researched your options and have some good choices. I have 2-3 solid recommendations ready."

This is **useless**. The user asked for recommendations and got told "I have them" instead of receiving them.

---

## Root Causes Identified

### 1. Output Truncation (conductor.py:4625)
```python
output_preview = str(final_output)[:500]  # ONLY 500 CHARS!
```
The UserCommunicationAgent only sees 500 characters of the final output.

### 2. Signature Instructions (user_communication_signatures.py:62-68)
The signature says:
- "2-3 sentences max"
- "Speak naturally, warmly"
- Example: "I've opened WhatsApp Web for you. The page is loaded and ready."

**MISSING:** Instructions to include the actual data when task is about getting information.

---

## A-TEAM DEBATE

### Young MIT Graduate (Alex):
> "What the fuck is this? The user asked for flight options and we tell them 'I have options'? That's like a waiter saying 'I have food' instead of serving the dish. The signature is designed for UI tasks ('opened WhatsApp'), not information retrieval tasks. We need to distinguish task types."

### Cursor Engineering Head (Sarah):
> "Alex, stop being dramatic. The real problem is simpler - we're only passing 500 chars of context. The LLM can't include details it doesn't see. But Alex has a point - the signature examples are all about UI actions, not data delivery."

### Claude Code Lead Architect (Marcus):
> "Both of you are half-right, half-wrong. 500 chars is tight, but even with more, the signature doesn't tell the LLM to INCLUDE the key data points. We need both fixes:
> 1. Increase output preview to at least 2000 chars
> 2. Add explicit instruction: 'For information/research tasks, include the key facts (prices, times, names) in your message'"

### RL/Optimization Expert (Chen):
> "Marcus is correct. The signature's examples set a pattern of vague confirmations. We need examples of data-rich responses too."

### Product/UX (Priya):
> "From a UX perspective, this is a critical failure. The user message IS the product. If it says 'I have recommendations' instead of giving them, users will think the system is broken or useless. Fix this NOW."

### QA/Validation (Tom):
> "I agree with Marcus's dual fix. But be careful - don't make the message too long. 2-3 sentences should INCLUDE the key data, not be a data dump. Quality over quantity."

### Logic/Math - Dr. Agarwal:
> "The fix is mathematically sound: more input context + better instructions = better output. The 500 char limit was arbitrary. 2000 is still reasonable for LLM context."

---

## CONSENSUS (6/7 Agree, 1 Abstain)

**Approved Fixes:**

1. **Increase output preview from 500 to 2000 characters** in `conductor.py:4625`
   
2. **Update UserCommunicationSignature** to include:
   - Explicit instruction about including key data for informational tasks
   - Example of data-rich response (not just UI confirmations)
   - Guidance: "For research/information tasks, include the specific findings (names, numbers, options)"

---

## Implementation Plan

### File 1: `Synapse/core/conductor.py`
- Line 4625: Change `[:500]` to `[:2000]`

### File 2: `Synapse/signatures/user_communication_signatures.py`
- Update `message` OutputField description
- Add example of data-rich completion message

---

## Risk Assessment

| Risk | Mitigation |
|------|------------|
| Longer context = more tokens | 2000 chars is ~500 tokens, acceptable |
| Message becomes too verbose | Signature still says "2-3 sentences" |
| Breaks existing behavior | No - only improves information density |

**Risk Level: LOW**

---

## FINAL VERDICT: APPROVED ✅

**Young MIT Graduate:** "Finally, some common sense."  
**Cursor Engineering Head:** "Ship it."  
**Claude Code Lead:** "Approved with the dual fix."  
**RL/Optimization:** "Approved."  
**Product/UX:** "Long overdue. Approved."  
**QA/Validation:** "Approved."  
**Logic/Math:** "Mathematically sound. Approved."

---

**Implementation assigned to: Current session**  
**Priority: HIGH**
