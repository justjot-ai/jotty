# A-Team Review: WebSocket Browser Screenshot Cleanup

**Date**: 2026-02-01  
**Issue**: WebSocket `/ws/browser` causing 403 errors and unnecessary complexity  
**Participants**: Alex (Architecture), Blake (Backend), Casey (Frontend), Devon (DevOps)

---

## 🔥 Blake (Backend - Aggressive)

"Are you KIDDING me? We have a stub WebSocket endpoint that literally does NOTHING except accept connections and send pong messages? This is embarrassing! Look at this garbage:"

```python
@router.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    await websocket.accept()
    logger.info("Browser WebSocket connected (stub)")
    try:
        while True:
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
```

"It's a STUB! It doesn't stream screenshots, it doesn't do ANYTHING useful! And the Electron app is desperately trying to connect to it every 5 seconds like a lost puppy! This is technical debt at its finest!"

---

## 💻 Casey (Frontend - Defensive but Concerned)

"Hold on Blake, there WAS a reason for this! The ADR `electron-browser-view-integration.md` shows this was designed for real-time browser screenshot streaming. It was supposed to show users what the browser agent is doing in real-time!"

"But... I'll admit, the implementation never got finished. The Electron app has all this code:"

```javascript
connectBrowserWebSocket() {
  const wsUrl = 'ws://127.0.0.1:8000/api/ws/browser';
  this.browserWS = new WebSocket(wsUrl);
  // ... auto-reconnect logic, ping/pong, etc
}
```

"And it's just connecting to a stub that does nothing. The 403 errors are annoying but at least it reconnects..."

---

## 🏗️ Alex (Architecture - Analytical)

"Let me break down what happened here. This WebSocket was part of the OLD architecture before we moved to the `/perform` SSE streaming endpoint. Look at the timeline:"

**Old Architecture (January 2026)**:
- Backend writes logs to files
- WebSocket streams logs to frontend
- Browser screenshots sent via WebSocket
- Artifact polling via REST API

**New Architecture (February 2026)**:
- `/perform` endpoint streams events via SSE
- No log files needed
- No WebSocket needed
- Cleaner, simpler, faster

"The ADR `electron-remove-log-file-reading.md` removed the log WebSocket but FORGOT to remove the browser screenshot WebSocket. Classic refactoring oversight."

---

## 🔧 Devon (DevOps - Pragmatic)

"Okay, let's look at the actual impact:"

**Current State**:
- ❌ 403 errors every 5 seconds in logs
- ❌ Unnecessary reconnection attempts
- ❌ Stub endpoint wasting resources
- ❌ Dead code in Electron app
- ❌ Confusing for developers

**If We Remove It**:
- ✅ No more 403 errors
- ✅ Cleaner logs
- ✅ Less code to maintain
- ✅ No performance impact (it's a stub anyway)

"The only question is: Do we NEED browser screenshot streaming?"

---

## 🔥 Blake (Backend - Brutal Honesty)

"NO! We don't need it! The `/perform` endpoint already streams conversational events like 'I am browsing to example.com' and 'I found 5 results'. That's ENOUGH feedback for users!"

"If we really wanted screenshots, we'd add them to the SSE stream, not use a separate WebSocket! This is just architectural inconsistency!"

---

## 💻 Casey (Frontend - Reluctant Agreement)

"Fine, I'll admit it. The browser screenshot feature was cool in theory but never got properly implemented. The Electron app shows events in the System terminal now, which is good enough."

"And honestly, streaming screenshots would be HUGE data over the network. Base64-encoded PNGs every few seconds? That's bandwidth we don't need to waste."

---

## 🏗️ Alex (Architecture - Decision)

"Alright, consensus time. Here's what we remove:"

### Backend (UV Server)
1. Delete `/ws/browser` endpoint from `electron_support.py`
2. Delete `/ws/logs/{session_id}` endpoint (also unused)
3. Remove WebSocket imports

### Frontend (Electron App)
1. Remove `connectBrowserWebSocket()` function
2. Remove `updateBrowserView()` function
3. Remove `browserWS` property
4. Remove browser screenshot HTML/CSS (if exists)
5. Remove auto-reconnect logic

### Surface Tools
1. Remove `_screenshot_callback` global variable
2. Remove `set_screenshot_callback()` function
3. Remove `_send_screenshot_if_callback()` function
4. Keep `take_screenshot()` tool (saves to disk, useful for debugging)

---

## 🔧 Devon (DevOps - Risk Assessment)

"Risk analysis:"

**Low Risk**:
- Feature never worked properly
- No production usage
- Easy to revert if needed
- No database changes

**High Reward**:
- Cleaner codebase
- No more error spam
- Easier to understand
- Better performance

"I say we do it. This is low-hanging fruit."

---

## 🔥 Blake (Backend - Final Verdict)

"AGREED! This is dead code removal 101. Let's rip it out like a bad tooth!"

---

## 💻 Casey (Frontend - Final Verdict)

"Okay, okay. I agree. Let's remove it. But document it properly so we know WHY we removed it if someone asks later."

---

## 🏗️ Alex (Architecture - Final Verdict)

"Unanimous decision. Remove all WebSocket browser screenshot code. Keep the `take_screenshot()` tool for manual debugging. Document in ADR."

---

## ✅ Consensus Decision

**REMOVE all WebSocket browser screenshot streaming code.**

### Rationale
1. Feature never fully implemented (stub only)
2. New SSE architecture makes it obsolete
3. Causing 403 errors and log spam
4. Wasting resources and adding complexity
5. Screenshot streaming would be bandwidth-heavy
6. Current event streaming provides sufficient feedback

### Keep
- `take_screenshot()` tool (saves to disk for debugging)
- SSE streaming via `/perform` endpoint

### Remove
- `/ws/browser` WebSocket endpoint
- `/ws/logs/{session_id}` WebSocket endpoint
- All frontend WebSocket connection code
- Screenshot callback system in browser_tools.py

---

## 📋 Implementation Plan

1. **Backend cleanup** - Remove WebSocket endpoints
2. **Frontend cleanup** - Remove WebSocket connection code
3. **Surface cleanup** - Remove screenshot callback system
4. **Create ADR** - Document removal decision
5. **Test** - Verify no 403 errors, app still works

---

## 🎯 Success Criteria

- ✅ No more 403 WebSocket errors in logs
- ✅ Electron app starts without WebSocket connection attempts
- ✅ `/perform` endpoint still streams events correctly
- ✅ Browser automation still works (just no live screenshots)
- ✅ Code is cleaner and easier to understand

---

**Meeting Adjourned** - Let's clean this mess up! 🧹
