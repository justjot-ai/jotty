# A-Team Review: Task Collapse Dependency Handling

## Problem Statement

Current `_collapse_consecutive_tasks` in `todo_creator_agent.py` merges consecutive tasks by the same actor WITHOUT checking for internal dependencies within the group.

**Current Bug**:
- Tasks 1,2,3,4 where 3 depends on 2 and 4 depends on 3 (same actor for 2,3,4)
- Current: Combines into 2_3_4 → WRONG! Cannot execute 3 before 2 completes!
- Expected: Keep as 2,3,4 with dependency chain preserved

**Correct Scenarios**:
1. Tasks 1,2,3,4 | 2,3 depend on 1 (external) | 2,3,4 same actor → 1, 2_3_4 (carry external dep on 1) ✅
2. Tasks 1,2,3,4 | 3 depends on 2 | 4 depends on 3 (internal chain) → 1,2,3,4 (NO merge) ✅

---

## A-Team Debate

### Dr. Agarwal (Logic/Math)
"This is basic graph theory. You CANNOT merge vertices that have edges between them. If task B depends on task A, they are NOT independent and cannot be combined. The invariant is: **merged tasks must be mutually independent (no internal edges)**."

### Young MIT Graduate (Software Design)
"The fix is simple - before merging a group, check if any task in the group depends on another task in the group. If yes, split at that boundary. Time complexity: O(n) per group where n is group size."

### Claude Code Lead (Agentic Workflow)
"This is a CRITICAL bug. Combined tasks execute as ONE unit. If task 3 needs output from task 2, combining them makes the dependency impossible to satisfy. The agent would fail silently or produce garbage."

### Cursor Engineering Head (Tool Wiring)
"The fix needs to maintain the actor assignment through splits. When we split a group due to internal dependency, BOTH resulting sub-groups should still be candidates for their own merging (if they have no internal deps)."

### RL/Optimization
"This is also about execution order. The topological sort gives us the correct execution order. We should only merge tasks that are 'parallel-safe' - meaning they could theoretically run in any order without affecting correctness."

### Systems/Performance
"Merging saves LLM calls and context switches. But merging incorrectly breaks execution. The invariant must be: **merged tasks share NO directed edges between them**."

---

## Consensus Algorithm

**Step 1**: For each consecutive group of tasks by same actor
**Step 2**: Build sub-graph of internal dependencies within the group  
**Step 3**: Split group wherever there's an internal dependency edge
**Step 4**: For each resulting sub-group with NO internal edges → merge
**Step 5**: Carry forward ALL external dependencies to the merged task

**Invariant**: `∀ task_a, task_b in merged_group: task_a ∉ task_b.depends_on AND task_b ∉ task_a.depends_on`

---

## Implementation Decision

**Approach**: Modify `_collapse_consecutive_tasks` to:
1. After grouping consecutive tasks by actor, perform internal dependency check
2. Split groups at internal dependency boundaries
3. Only merge sub-groups that pass the independence check
4. Collect ALL external dependencies from ALL tasks in a merge-group

**Code Location**: `Synapse/agents/todo_creator_agent.py` → `_collapse_consecutive_tasks()`

---

## Test Cases Required

1. **No internal deps**: Tasks [1,2,3] same actor, no internal deps → merge to 1_2_3 ✅
2. **Chain dependency**: Tasks [1,2,3] same actor, 2→1, 3→2 → NO merge (keep 1,2,3) ✅
3. **Partial chain**: Tasks [1,2,3,4] same actor, 3→2 → merge [1], [2,3], [4] separately? Or split at dep ✅
4. **External only**: Tasks [2,3,4] depend on task [1] (different actor) → merge 2_3_4 with dep on 1 ✅
5. **Mixed**: Tasks [1,2,3,4,5] same actor, 3→2, 5→ext → merge [1,2], keep [3], merge [4,5] ✅

---

## Verdict

**APPROVED** - Fix the internal dependency check. This is a correctness bug, not a performance issue.

Signed:
- Dr. Agarwal ✓
- Young MIT Graduate ✓
- Claude Code Lead ✓
- Cursor Engineering Head ✓
- RL/Optimization ✓
- Systems/Performance ✓
