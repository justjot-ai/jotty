# A-Team Review: Dynamic Task Planner Integration

**Date:** 2026-01-12  
**Topic:** Integrating LLM-based task decomposition into MarkovianTODO  
**Status:** APPROVED

---

## Attendees
- **Marcus** - Senior Architect
- **Sarah** - ML/Data Science Lead
- **Viktor** - DevOps/Systems Expert
- **Luna** - Frontend/UX Specialist
- **Raj** - Security/Backend Engineer

---

## Problem Statement

**Marcus:** We have two parallel systems that aren't connected:
1. `Conductor._initialize_todo_from_goal()` - Creates flat "Execute X pipeline" tasks
2. `MarkovianTODO` - Has hierarchical data structures but receives flat input

**Sarah:** This is Shannon's information loss problem! "Execute BusinessTermResolver pipeline" has ~5 bits of information. "Resolve 'P2P' to technical term from knowledge base" has ~15 bits. We're wasting 10 bits per task!

**Viktor:** The AgenticAgentSelector selects WHICH agents, but doesn't decompose WHAT they do.

**Luna:** So we get proper agent selection but garbage task descriptions?

**Viktor:** Exactly. A recursive language model should:
1. UNDERSTAND the goal semantically
2. DECOMPOSE it into atomic steps
3. ASSIGN steps to actors
4. TRACK dependencies between steps

---

## Meeting Transcript

**Raj:** Show me the guilty code.

**Marcus:** `conductor.py` lines 2417-2428:
```python
self.todo.add_task(
    task_id=f"{name}_main",
    description=f"Execute {name} pipeline for: {goal[:100]}",  # ← GENERIC!
    actor=name,
    depends_on=[f"{prev}_main" for prev in prev_selected],
    priority=1.0 - (i * 0.1)
)
```

**Sarah:** This is an embarrassment. The task description is just the goal truncated. No semantic decomposition!

**Viktor:** Where's the DynamicTaskPlanner I keep hearing about?

**Marcus:** It doesn't exist. That's what we need to build.

**Luna:** Wait, so the whole "recursive language model task decomposition" was never implemented?

**Marcus:** Correct. We have the data structures (MarkovianTODO, SubtaskState) but the initialization is brain-dead.

---

## Proposed Solution

**Raj:** Three changes needed:

### Change 1: Create DynamicTaskPlanner
Location: `Synapse/core/dynamic_task_planner.py`

```python
class TaskDecompositionSignature(dspy.Signature):
    """Decompose a goal into fine-grained subtasks."""
    goal = dspy.InputField(desc="High-level goal")
    available_agents = dspy.InputField(desc="Agents with capabilities")
    context = dspy.InputField(desc="Additional context")
    
    task_plan = dspy.OutputField(desc="JSON: {tasks: [{task_id, agent, description, depends_on, inputs_needed, outputs_produced}]}")
```

**Sarah:** Good. The LLM does the semantic work, not regex.

### Change 2: Add initialize_from_plan() to MarkovianTODO
Location: `Synapse/core/roadmap.py`

**Viktor:** The method should:
1. Clear existing tasks
2. Parse the LLM plan
3. Create SubtaskState for each
4. Store inputs_needed/outputs_produced in intermediary_values
5. Update dependency graph

**Luna:** What about the execution_order?

**Viktor:** Topological sort based on depends_on. Tasks with no deps first.

### Change 3: Integrate into Conductor
Location: `Synapse/core/conductor.py`

**Marcus:** Add `enable_dynamic_planning` flag. When True:
1. Call DynamicTaskPlanner with goal + selected agents
2. Get structured plan back
3. Initialize TODO from plan

**Raj:** Keep the fallback path for when the LLM fails.

---

## Task Decomposition Prompt Design

**Sarah:** The prompt is critical. Here's what I propose:

```
DECOMPOSITION PRINCIPLES:
1. ATOMICITY: Each subtask should be a single coherent action
2. CLARITY: Description should specify WHAT, not just WHO
3. DEPENDENCIES: Explicit data flow between subtasks
4. PARALLELISM: Independent subtasks can run in parallel

BAD EXAMPLE:
- task_id: "agent1_main"
- description: "Execute agent1 pipeline"  ← Too vague!

GOOD EXAMPLE:
- task_id: "resolve_date_reference"
- description: "Convert 'yesterday' to concrete date 2026-01-11"
- agent: "CodeMaster"
- outputs_produced: ["resolved_date", "date_format"]
```

**Viktor:** The output format?

**Sarah:** JSON with tasks array. Each task has:
- task_id (semantic, not "agent_main")
- agent (which agent executes)
- description (specific action)
- depends_on (list of task_ids)
- inputs_needed (what data from previous)
- outputs_produced (what this produces)

**Luna:** What about priority?

**Sarah:** Derived from dependency depth: `priority = 1.0 - len(depends_on) * 0.1`

---

## Edge Cases

**Raj:** What if decomposition fails?

**Marcus:** Fallback to current behavior: one task per selected agent.

**Viktor:** What if task_id collides?

**Marcus:** Prefix with agent name: `CodeMaster_resolve_date` not just `resolve_date`.

**Luna:** Maximum decomposition depth?

**Sarah:** Let the LLM decide, but cap at 10 subtasks per agent. We don't want 100 micro-tasks.

**Viktor:** Agreed. If the LLM goes crazy, truncate.

---

## Implementation Plan

| Priority | Component | File | Change |
|----------|-----------|------|--------|
| 🔴 HIGH | DynamicTaskPlanner | `dynamic_task_planner.py` | New file |
| 🔴 HIGH | initialize_from_plan() | `roadmap.py` | Add method |
| 🔴 HIGH | Conductor integration | `conductor.py` | Wire planner |
| 🟡 MED | Unit tests | `tests/` | Test decomposition |

---

## Risk Assessment

**Raj:** What are the risks?

1. **LLM inconsistency**: Different decompositions for same goal
   - Mitigation: Structured output with JSON schema

2. **Performance**: Extra LLM call per task
   - Mitigation: Only for complex tasks (heuristic: goal > 50 chars)

3. **Dependency cycles**: LLM generates circular deps
   - Mitigation: Validate with topological sort, reject if cyclic

**Marcus:** Acceptable risks. The information gain outweighs them.

---

## Final Vote

- **Marcus:** APPROVE - "This is the fix we should have made months ago"
- **Sarah:** APPROVE - "Finally, semantic task descriptions"
- **Viktor:** APPROVE - "Clean architecture"
- **Luna:** APPROVE - "Better debugging with meaningful task names"
- **Raj:** APPROVE - "Security review passed"

---

## Action Items

1. [ ] Create `dynamic_task_planner.py` with TaskDecompositionSignature
2. [ ] Add `initialize_from_plan()` to MarkovianTODO
3. [ ] Integrate planner into `Conductor._initialize_todo_from_goal()`
4. [ ] Create ADR documenting the change
5. [ ] Add tests for task decomposition

---

*Meeting adjourned. Viktor owes Sarah $20 for the bet.*
