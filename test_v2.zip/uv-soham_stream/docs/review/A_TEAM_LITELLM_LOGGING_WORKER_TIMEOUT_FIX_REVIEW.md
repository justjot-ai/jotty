# A-Team Review: LiteLLM Logging Worker Timeout Fix

**Date:** 2026-02-04  
**Feature:** Disable LiteLLM logging worker to prevent timeout errors  
**Status:** APPROVED ✅

---

## A-Team Debate: Design Decisions

### 1. Disable vs Fix the Logging Worker

**Young MIT Graduate:**
> "The timeout is happening because LiteLLM's async logging worker is poorly designed. We should disable it entirely - we don't need API call logging in production anyway. It's just noise."

**Cursor Engineering Head:**
> "I initially wanted to fix the timeout by increasing it or implementing retry logic, but that's treating the symptom, not the cause. Disabling the worker is the right call - we can always re-enable it if we need detailed logging for debugging."

**Claude Code Lead:**
> "Agreed. The logging worker is a non-critical feature. If it's causing errors and we don't need it, disable it. Production systems should only log what's necessary."

**Systems/Performance:**
> "Disabling the async worker also reduces overhead. Fewer background tasks means less resource contention. This is a performance win."

**CONSENSUS:** Disable the logging worker ✅

---

### 2. Environment Variable vs Code Configuration

**Young MIT Graduate:**
> "Setting `LITELLM_LOG="ERROR"` as an environment variable before import is the cleanest approach. It prevents the worker from initializing in the first place."

**Reliability/SRE:**
> "I prefer code-based configuration so it's explicit and version-controlled. But the environment variable approach works and is consistent with LiteLLM's design."

**QA/Validation:**
> "The environment variable approach is better because it prevents initialization. Code-based disabling might happen after the worker is already started."

**CONSENSUS:** Use environment variable before import, then disable in code ✅

---

### 3. Where to Apply the Fix

**Cursor Engineering Head:**
> "We need to apply this in two places: `swarm_service.py` (UV server initialization) and `surface.py` (Surface agent DSPy configuration). Both are initialization points where LiteLLM gets configured."

**Systems/Performance:**
> "Should we create a utility function to avoid code duplication?"

**Young MIT Graduate:**
> "No, the code is simple enough that duplication is fine. A utility function would add unnecessary abstraction. Keep it inline where it's used."

**Claude Code Lead:**
> "I agree. The fix is 5 lines of code. Creating a utility function would be over-engineering. If we need it in more places later, we can refactor then."

**CONSENSUS:** Apply fix inline at initialization points ✅

---

### 4. Error Logging Level

**Reliability/SRE:**
> "Setting `LITELLM_LOG="ERROR"` means we still get critical errors. That's good - we don't want to lose error visibility."

**QA/Validation:**
> "But what if we need detailed API call logs for debugging? Should we make this configurable?"

**Young MIT Graduate:**
> "YAGNI. We don't need it now. If we need it later, we can add a configuration flag. Don't over-engineer."

**Claude Code Lead:**
> "The fix is simple and can be easily reverted or made conditional if needed. For now, ERROR level is appropriate for production."

**CONSENSUS:** Use ERROR level, can be made configurable later if needed ✅

---

## A-Team Verdict

### ✅ APPROVED - Implementation Complete

**Summary:**
- Disable LiteLLM logging worker via environment variable and code configuration
- Apply fix at initialization points (swarm_service.py and surface.py)
- Keep error logging enabled for critical issues
- Simple, inline implementation (no utility function needed)

**Rationale:**
- Eliminates non-critical timeout errors cluttering logs
- Reduces background task overhead
- Maintains error visibility
- Easy to revert or make configurable if needed

**Files Modified:**
- `uv/src/uv/services/swarm_service.py`: Added LiteLLM logging disable logic
- `surface/src/surface/surface.py`: Added LiteLLM logging disable logic

**Testing:**
- ✅ No more `LoggingWorker error` messages
- ✅ API calls work normally
- ✅ Critical errors still logged
- ✅ Cleaner production logs

---

## A-Team Members' Final Comments

**Young MIT Graduate:**
> "Clean fix. Disabling unnecessary background workers is always the right call. The timeout was a symptom of over-engineering in LiteLLM's logging system."

**Cursor Engineering Head:**
> "Good decision to disable rather than patch. The logging worker isn't critical for our use case, and disabling it eliminates the problem entirely."

**Claude Code Lead:**
> "Simple, effective solution. Production systems should minimize noise. This fix achieves that while maintaining error visibility."

**Reliability/SRE:**
> "Reducing background tasks improves system stability. This is a win for production reliability."

**QA/Validation:**
> "The fix is straightforward and testable. No more timeout errors cluttering test logs. Approved."

---

**Status:** ✅ **APPROVED AND IMPLEMENTED**
