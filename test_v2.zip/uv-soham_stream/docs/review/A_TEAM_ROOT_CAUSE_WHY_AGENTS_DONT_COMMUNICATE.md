# A-Team Root Cause Analysis: Why Agents Aren't Communicating

**Date:** 2026-01-28  
**Critical Finding:** Infrastructure exists but is NOT connected to agents  
**Severity:** CRITICAL - System failure despite having all components  
**Root Cause:** Architectural disconnection between communication layer and agent execution

---

## 🚨 EXECUTIVE SUMMARY: The Fatal Flaw

### What EXISTS:
✅ `SmartAgentSlack` - Intelligent communication system  
✅ `agent_slack.send()` and `agent_slack.receive()` methods  
✅ Agents are REGISTERED with SmartAgentSlack  
✅ Message Bus, Format Registry, Auto-transformation  
✅ Cooperation tracking, context management  

### What's BROKEN:
❌ Agents DON'T have a reference to `agent_slack`  
❌ Agents DON'T know what other agents exist  
❌ Agents DON'T have a "request_help()" method  
❌ Agents CAN'T call `agent_slack.send()` - they don't have access!  
❌ Communication is IMPLICIT (via Conductor), not EXPLICIT (agent-to-agent)

**Analogy:** You built a beautiful Slack workspace, but nobody has login credentials!

---

## 🎭 A-Team Deliberation: Root Cause Analysis

### Alan Turing (Computation):
> "This is a **reference problem**, not a design problem. SmartAgentSlack is computationally sound. The issue is that the function `send(from_agent, to_agent, data)` is never called BY agents - only BY Conductor on their behalf. Agents are **black boxes without I/O ports** to the communication system."
>
> **Evidence:**
> - File: `Synapse/core/axon.py` lines 291-428
> - Method: `SmartAgentSlack.send()` - works perfectly
> - File: `surface/agents/domain_expert.py`
> - Problem: Agent has NO `self.agent_slack` attribute
> - Problem: Agent has NO `self.known_agents` directory
>
> **Root Cause:** Agents are **not dependency-injected** with communication capability.

---

### John von Neumann (Game Theory):
> "This is a **game-theoretic failure**. In multi-agent systems, agents must be **autonomous players** who can initiate communication. Currently, agents are **passive servants** of Conductor. They don't PLAY the game - they're played BY the game."
>
> **Current (BROKEN) Model:**
> ```
> Conductor → calls agent
> Agent → returns result
> Conductor → decides if other agents needed
> Conductor → calls those agents
> ```
>
> **Correct Model:**
> ```
> Conductor → gives goal to Agent A
> Agent A → realizes needs help
> Agent A → agent_slack.send(from_A, to_B, "I need help with X")
> Agent B → receives message
> Agent B → responds with help
> Agent A → continues with new knowledge
> ```
>
> **The difference:** Agents must be PROACTIVE, not REACTIVE.

---

### David Silver (RL):
> "From a reinforcement learning perspective, agents have **no action space for communication**. Their action space is limited to:
> - `send_terminal_command()`
> - `web_search()`
>- `scrape_website()`
>
> But they CANNOT:
> - `request_help_from(agent_name, problem)`
> - `share_knowledge_with(agent_name, data)`
> - `broadcast_discovery(finding)`
>
> **Evidence:**
> - File: `surface/signatures/domain_expert_signature.py`
> - No output fields for `agent_messages` or `collaboration_requests`
> - File: `surface/agents/domain_expert.py`
> - No `self.known_agents` attribute
> - No `request_help()` method
>
> **Root Cause:** Agents have **tool use capabilities** but NO **agent collaboration capabilities**.

---

### Noam Chomsky (Language/Communication):
> "This is a **pragmatics failure**. The agents have SYNTAX (message format via SmartAgentSlack) and SEMANTICS (what data means), but they lack PRAGMATICS - the ability to USE language for communication acts like:
> - Requesting
> - Offering
> - Negotiating
> - Coordinating
>
> **Current State:**
> - Agents produce monologues (commands, reasoning)
> - No dialogues between agents
> - No speech acts (requests, offers, promises)
>
> **Evidence:**
> - File: `surface/agents/domain_expert.py` method `forward()`
> - Returns: `{analysis, plan, commands, task_complete, reasoning}`
> - Missing: `{help_requested_from, knowledge_shared_with, agent_messages}`
>
> **Root Cause:** Agents' signatures don't include **communication acts** as outputs.

---

### Modern AI Engineer:
> "Let me trace the execution flow to show exactly where communication breaks down:
>
> **File:** `Synapse/core/conductor.py` line 956
> ```
> self.agent_slack = SmartAgentSlack(config={}, enable_cooperation=True)
> ```
> ✅ SmartAgentSlack created
>
> **File:** `Synapse/core/conductor.py` lines 1116-1128
> ```python
> self.agent_slack.register_agent(
>     agent_name=actor_config.name,
>     signature=signature_obj,
>     callback=_make_slack_callback(actor_config.name),
>     max_context=16000
> )
> ```
> ✅ Agents registered with SmartAgentSlack
>
> **File:** `Synapse/core/conductor.py` lines 4932-5133 `_execute_actor()`
> ```python
> result = await actor(**resolved_kwargs)
> ```
> ❌ Agent is called
> ❌ Agent does NOT receive `agent_slack` as a parameter
> ❌ Agent does NOT receive `known_agents` directory
> ❌ Agent CANNOT call `self.agent_slack.send()`
>
> **File:** `surface/agents/domain_expert.py` method `forward()`
> ```python
> def forward(self, instruction, terminal_session, conversation_history, ...):
>     # Agent executes
>     # Agent has self.tools (terminal, web_search)
>     # Agent does NOT have self.agent_slack
>     # Agent does NOT have self.known_agents
>     return result
> ```
> ❌ No communication capability
>
> **Root Cause Summary:**
> 1. `agent_slack` is NOT injected into agents
> 2. Agent directory is NOT provided to agents
> 3. Agents have no mechanism to discover peers
> 4. Agents have no method to request help

---

## 📊 Detailed Problem Breakdown

### Problem 1: No Agent Directory

**What's Missing:**
```python
# Agents need to know:
known_agents = {
    "CodeMaster": {
        "capabilities": ["python", "debugging", "algorithms"],
        "provides": ["code_implementation", "bug_fixes"],
        "status": "available"
    },
    "DomainExpert": {
        "capabilities": ["library_research", "error_analysis"],
        "provides": ["library_knowledge", "error_solutions"],
        "status": "available"
    },
    # ... other agents
}
```

**Where This Should Be:**
- **File:** `Synapse/core/conductor.py`
- **Method:** `_build_agent_directory()`
- **When:** During Conductor initialization
- **Injected:** Into each agent via `agent_directory` parameter

**Current State:**
- Agents know NOTHING about peers
- Can't request help because don't know who to ask
- Can't discover capabilities

---

### Problem 2: No Communication Reference

**What's Missing:**
```python
# Each agent needs:
class DomainExpertAgent:
    def __init__(self, ...):
        self.agent_slack = None  # ❌ Missing!
        self.agent_directory = None  # ❌ Missing!
        self.my_name = None  # ❌ Missing!
```

**Where This Should Be Injected:**
- **File:** `Synapse/core/conductor.py`
- **Method:** `_execute_actor()` lines 4932-5133
- **Current code:**
```python
resolved_kwargs = self._resolve_parameters(...)
result = await actor(**resolved_kwargs)
```

**Should be:**
```python
resolved_kwargs = self._resolve_parameters(...)
# ✅ ADD:
resolved_kwargs['_agent_slack'] = self.agent_slack
resolved_kwargs['_agent_directory'] = self.agent_directory
resolved_kwargs['_my_name'] = actor_config.name
result = await actor(**resolved_kwargs)
```

**Then agents must accept these:**
- **File:** `surface/agents/domain_expert.py`
- **Method:** `forward()` signature
- **Current:**
```python
def forward(self, instruction, terminal_session, conversation_history, ...):
```

**Should be:**
```python
def forward(self, instruction, terminal_session, conversation_history, 
            _agent_slack=None, _agent_directory=None, _my_name=None, ...):
    self.agent_slack = _agent_slack
    self.agent_directory = _agent_directory
    self.my_name = _my_name
```

---

### Problem 3: No "Request Help" Capability

**What's Missing:**
```python
# Agents need methods like:
def request_help(self, target_agent, problem, context):
    """Request help from another agent."""
    if not self.agent_slack:
        return None
    
    # Send help request
    self.agent_slack.send(
        from_agent=self.my_name,
        to_agent=target_agent,
        data={
            "type": "help_request",
            "problem": problem,
            "context": context,
            "urgent": True
        }
    )
    
    # Wait for response (or continue and check later)
    return "help_requested"
```

**Where This Should Be:**
- **File:** `surface/agents/base_swarm_agent.py` (new base class)
- **OR:** `Synapse/core/agent_collaboration_mixin.py` (new mixin)
- **Inherited by:** All agents

**Methods Needed:**
1. `request_help(target_agent, problem, context)` - Ask for help
2. `share_knowledge(target_agent, data)` - Share findings
3. `broadcast_discovery(data)` - Share with all
4. `check_messages()` - See if others sent messages
5. `respond_to_request(request_id, response)` - Answer help requests

---

### Problem 4: No Agent-to-Agent Signatures

**What's Missing:**
Agent signatures don't include communication as output:

- **File:** `surface/signatures/domain_expert_signature.py`
- **Current output fields:**
```python
analysis = dspy.OutputField(desc="Analysis of the task")
plan = dspy.OutputField(desc="Step-by-step plan")
commands = dspy.OutputField(desc="Terminal commands")
task_complete = dspy.OutputField(desc="Whether task is done")
reasoning = dspy.OutputField(desc="Reasoning process")
```

**Should also have:**
```python
help_requests = dspy.OutputField(
    desc="""JSON array of help requests to other agents:
    [
        {
            "to_agent": "CodeMaster",
            "request_type": "implementation",
            "problem": "Need code for chess FEN extraction",
            "context": {...},
            "priority": "high"
        }
    ]
    """
)

knowledge_shares = dspy.OutputField(
    desc="""JSON array of knowledge to share with other agents:
    [
        {
            "to_agent": "CodeMaster",
            "knowledge_type": "library_info",
            "data": {"library": "python-chess", "edge_cases": [...]},
            "confidence": 0.9
        }
    ]
    """
)
```

---

## 🔍 Trace: Why Chess Task Failed

Let's trace the chess task failure through the communication lens:

### Step 1: DynamicTaskPlanner creates plan
**File:** `Synapse/core/dynamic_task_planner.py`  
**Output:** List of tasks  
**Problem:** Plan doesn't identify WHICH agent should research libraries  
**Why:** No agent directory to make assignment decisions

---

### Step 2: Conductor assigns tasks to agents
**File:** `Synapse/core/conductor.py` method `_execute_actor()`  
**Problem:** 
- CodeMaster called to solve chess task
- CodeMaster doesn't know DomainExpert exists
- CodeMaster can't request "research python-chess library"
- CodeMaster tries to solve blind

---

### Step 3: CodeMaster fails - cv2.imread returns None
**File:** Execution logs show error  
**Problem:**
- CodeMaster doesn't know about cv2.imread edge case
- DomainExpert COULD have warned about this if:
  a) DomainExpert was called to research opencv BEFORE CodeMaster
  b) CodeMaster could request help from DomainExpert DURING execution
- But neither mechanism exists

---

### Step 4: Auditor sees failure
**File:** Auditor validation logs  
**Problem:**
- Auditor knows task failed
- Auditor can't tell DomainExpert "research this error"
- Auditor can't tell CodeMaster "retry with fix"
- Communication is one-way: Conductor→Agents, not Agent↔Agent

---

### Step 5: System gives up
**Result:** Task marked as failed  
**Root Cause:** No agent collaboration mechanism despite error being solvable

---

##🎯 THE FIX: Agent Collaboration Architecture

### Component 1: Agent Directory (Registry)

**File to modify:** `Synapse/core/conductor.py`  
**New method to add:** `_build_agent_directory()` (after line 1130)

**Purpose:** Create a directory of all agents with their capabilities

**Structure:**
```python
{
    "agent_name": {
        "capabilities": List[str],  # From ActorConfig
        "role": str,  # e.g., "research", "coding", "validation"
        "provides": List[str],  # What outputs they produce
        "accepts_requests_for": List[str],  # What they can help with
        "status": "available" | "busy",
        "confidence_domains": Dict[str, float]  # Domain→confidence
    }
}
```

**Integration point:** Pass to agents in `_execute_actor()` line 5103

---

### Component 2: Agent Collaboration Mixin

**New file to create:** `Synapse/core/agent_collaboration_mixin.py`

**Purpose:** Provide communication methods to all agents

**Methods:**
```python
class AgentCollaborationMixin:
    def set_collaboration_context(
        self, 
        agent_slack, 
        agent_directory, 
        my_name
    ):
        """Called by Conductor before agent execution."""
        self.agent_slack = agent_slack
        self.agent_directory = agent_directory
        self.my_name = my_name
    
    def request_help(self, target_agent, problem, context, urgent=False):
        """Request help from another agent."""
        pass
    
    def share_knowledge(self, target_agent, knowledge_type, data):
        """Share knowledge with another agent."""
        pass
    
    def broadcast_to_swarm(self, message_type, data):
        """Broadcast to all agents."""
        pass
    
    def check_incoming_messages(self):
        """Check for messages from other agents."""
        pass
    
    def find_agent_for_capability(self, capability):
        """Find which agent has a capability."""
        pass
```

**Integration:** All agents inherit from this mixin

---

### Component 3: Enhanced Agent Signatures

**Files to modify:**
- `surface/signatures/domain_expert_signature.py`
- `surface/signatures/code_master_signature.py`
- (all other agent signatures)

**Add output fields:**
```python
collaboration_actions = dspy.OutputField(
    desc="""JSON array of collaboration actions to take:
    [
        {
            "action": "request_help" | "share_knowledge" | "broadcast",
            "target_agent": "agent_name" | "all",
            "type": "library_research" | "error_solution" | "code_review" | ...,
            "data": {...},
            "priority": "critical" | "high" | "normal"
        }
    ]
    
    IMPORTANT: Use this to request help or share knowledge with other agents!
    Available agents: {agent_directory will be injected}
    """
)
```

---

### Component 4: Collaboration-Aware Execution Loop

**File to modify:** `Synapse/core/conductor.py`  
**Method to modify:** `_execute_actor()` lines 4932-5133

**Current flow:**
```
1. Resolve parameters
2. Call agent
3. Get result
4. Store result
5. Continue to next agent
```

**Enhanced flow:**
```
1. Resolve parameters
2. Inject collaboration context (agent_slack, directory, name)
3. Call agent
4. Get result
5. Process collaboration_actions from result:
   a. If help_requested: invoke target agent
   b. If knowledge_shared: store in shared memory
   c. If broadcast: notify all agents
6. Store result
7. Check if any agents sent messages to current agent
8. Continue
```

---

### Component 5: Pre-Execution Research Phase

**File to modify:** `Synapse/core/conductor.py`  
**New method to add:** `_run_pre_execution_research()` (before `run()` line 2000)

**Purpose:** Automatically call DomainExpert BEFORE task execution

**Flow:**
```
1. Conductor.run(goal="Solve chess puzzle")
2. DynamicTaskPlanner decomposes goal
3. ✅ NEW: Conductor identifies research needs from plan
4. ✅ NEW: Conductor calls DomainExpert: "Research libraries for chess + image processing"
5. ✅ NEW: DomainExpert stores findings in HierarchicalMemory
6. ✅ NEW: Agent directory updated with "DomainExpert researched: python-chess, opencv"
7. Conductor assigns tasks to CodeMaster
8. CodeMaster has access to research via:
   a. HierarchicalMemory query (automatic via RAG)
   b. Agent directory showing DomainExpert has knowledge
   c. Ability to request more details from DomainExpert
```

---

### Component 6: Agent-Aware Prompts

**Files to modify:** All architect prompts in `surface_synapse/architect/`

**Add to each prompt:**
```markdown
## Available Agents and Collaboration

You are part of a multi-agent system. Other agents can help you!

### Available Agents:
{{agent_directory}}

### How to Request Help:
If you need help, include in your `collaboration_actions`:
```json
{
    "action": "request_help",
    "target_agent": "DomainExpert",
    "type": "library_research",
    "data": {
        "problem": "Need to know best library for chess board image processing",
        "context": "Converting chess position from image to FEN notation"
    },
    "priority": "high"
}
```

### How to Share Knowledge:
If you discovered something useful, share it:
```json
{
    "action": "share_knowledge",
    "target_agent": "CodeMaster",
    "type": "edge_case_warning",
    "data": {
        "library": "opencv",
        "warning": "cv2.imread returns None instead of raising exception",
        "solution": "Always check: if img is None: raise FileNotFoundError()"
    }
}
```

IMPORTANT: You are NOT alone! Use other agents' expertise!
```

---

## 📋 Implementation Roadmap (Design Level)

### Phase 1: Foundation (Week 1)

**Goal:** Create collaboration infrastructure

#### Task 1.1: Create Agent Directory
- **File:** `Synapse/core/conductor.py`
- **Add method:** `_build_agent_directory()`
- **Location:** After line 1130 (after agent registration)
- **Purpose:** Build registry of all agents with capabilities

#### Task 1.2: Create Collaboration Mixin
- **New file:** `Synapse/core/agent_collaboration_mixin.py`
- **Purpose:** Provide communication methods to agents
- **Methods:** 5 core methods (request_help, share_knowledge, etc.)

#### Task 1.3: Inject Collaboration Context
- **File:** `Synapse/core/conductor.py`
- **Method:** `_execute_actor()` line 5103
- **Add:** Pass agent_slack, agent_directory, my_name to agents
- **Purpose:** Give agents access to communication system

---

### Phase 2: Agent Enhancement (Week 2)

**Goal:** Make agents collaboration-aware

#### Task 2.1: Update Agent Base Classes
- **File:** `surface/agents/base_swarm_agent.py`
- **Add:** Inherit from AgentCollaborationMixin
- **Add:** `set_collaboration_context()` call in `__init__`
- **Purpose:** All agents get collaboration capability

#### Task 2.2: Update Agent Signatures
- **Files:** All signature files in `surface/signatures/`
- **Add:** `collaboration_actions` output field
- **Purpose:** Agents can express collaboration intent

#### Task 2.3: Update Agent Prompts
- **Files:** All architect prompts in `surface_synapse/architect/`
- **Add:** Agent directory section
- **Add:** Collaboration examples
- **Purpose:** Teach agents to use collaboration

---

### Phase 3: Execution Enhancement (Week 2-3)

**Goal:** Process collaboration actions during execution

#### Task 3.1: Enhanced Execution Loop
- **File:** `Synapse/core/conductor.py`
- **Method:** `_execute_actor()`
- **Add:** Process `collaboration_actions` from agent output
- **Add:** Invoke target agents for help requests
- **Purpose:** Enable runtime agent-to-agent communication

#### Task 3.2: Pre-Execution Research
- **File:** `Synapse/core/conductor.py`
- **Add method:** `_run_pre_execution_research()`
- **Call before:** Task execution in `run()` method
- **Purpose:** Automatic DomainExpert research before coding

#### Task 3.3: Error-Triggered Collaboration
- **File:** `Synapse/core/conductor.py`
- **Method:** Error handling in `run()`
- **Add:** On error, invoke DomainExpert for error research
- **Add:** Inject error solution into retry context
- **Purpose:** Learning from errors

---

### Phase 4: Testing & Validation (Week 3)

**Goal:** Verify agents collaborate

#### Task 4.1: Chess Task with Collaboration
- **Expected flow:**
  1. Conductor calls DomainExpert to research chess + image libraries
  2. DomainExpert finds python-chess, opencv, Pillow
  3. DomainExpert warns about cv2.imread edge case
  4. CodeMaster receives research via shared memory
  5. CodeMaster implements with edge case handling
  6. Task succeeds

#### Task 4.2: Collaboration Metrics
- **Add:** Track agent-to-agent messages
- **Add:** Track help requests and responses
- **Add:** Measure collaboration impact on success rate
- **Purpose:** Quantify improvement

---

## 🎯 Expected Improvements

### Before (Current State):
- Agents work in isolation
- No knowledge sharing
- Errors not researched
- Success rate: ~30% on complex tasks

### After (With Collaboration):
- Agents request help when stuck
- DomainExpert shares library knowledge
- Errors trigger research and retry
- Expected success rate: ~80% on complex tasks

### Collaboration Examples:

**Example 1: Chess Task**
```
1. Conductor: "Solve chess puzzle"
2. DomainExpert (AUTO-CALLED): Research chess + image libraries
   → Finds python-chess, opencv
   → Warns about cv2.imread returning None
   → Stores in shared memory
3. CodeMaster: Check shared memory for chess knowledge
   → Finds library info and edge cases
   → Implements with proper error handling
4. Success!
```

**Example 2: Runtime Help Request**
```
1. CodeMaster: Tries to parse image
2. CodeMaster: Gets error
3. CodeMaster: request_help(
     target="DomainExpert",
     problem="cv2.imread returned None",
     context={"file": "chess_board.png", "code": "..."}
   )
4. DomainExpert: Researches error
5. DomainExpert: share_knowledge(
     target="CodeMaster",
     data={"solution": "Check if file exists first", "code_fix": "..."}
   )
6. CodeMaster: Applies fix
7. Success!
```

---

## 📊 File-by-File Change Summary

| File | Changes | Lines | Purpose |
|------|---------|-------|---------|
| `Synapse/core/conductor.py` | Add agent_directory builder<br>Inject collaboration context<br>Process collaboration actions<br>Add pre-execution research | ~200 | Enable collaboration |
| `Synapse/core/agent_collaboration_mixin.py` | NEW FILE | ~150 | Collaboration methods |
| `surface/agents/base_swarm_agent.py` | Inherit mixin<br>Accept collaboration params | ~20 | Agent capability |
| `surface/signatures/*.py` | Add collaboration_actions field | ~15 each | Agent outputs |
| `surface_synapse/architect/*.md` | Add agent directory section<br>Add collaboration examples | ~50 each | Agent prompts |

**Total new code:** ~500 lines  
**Total modifications:** ~300 lines  
**Total effort:** 2-3 weeks

---

## ✅ Success Criteria

### Phase 1 (Infrastructure):
- ✅ Agent directory built and populated
- ✅ AgentCollaborationMixin working
- ✅ Agents receive collaboration context
- ✅ No existing tests broken

### Phase 2 (Agent Enhancement):
- ✅ All agents inherit collaboration capability
- ✅ Signatures include collaboration_actions
- ✅ Prompts teach collaboration
- ✅ Agents can discover peers

### Phase 3 (Execution):
- ✅ Collaboration actions processed
- ✅ Help requests invoke target agents
- ✅ Pre-execution research works
- ✅ Error-triggered collaboration works

### Phase 4 (Validation):
- ✅ Chess task succeeds with collaboration
- ✅ Agent-to-agent messages logged
- ✅ Success rate improves to >75%
- ✅ System is GENERIC (not chess-specific)

---

## 🚨 Critical Design Principles

### Principle 1: Agents Must Be Autonomous
Agents decide WHEN and WHO to communicate with, not Conductor

### Principle 2: Communication Must Be Explicit
No implicit handoffs - agents explicitly request/share via agent_slack.send()

### Principle 3: Directory Must Be Dynamic
Agent directory updates in real-time as agents discover capabilities

### Principle 4: No Hardcoding
No "if task == chess: call DomainExpert" - agents reason about needs

### Principle 5: Generic System
Works for ANY task type - chess, image processing, web scraping, etc.

---

**Status:** Ready for detailed implementation
**Approval:** Requires A-Team review  
**Next Step:** Create detailed code-level design for Phase 1

