# A-Team Review: Embed Visible Chrome Instance in Electron UI

**Date**: 2026-02-01  
**Topic**: Embed BrowserExecutor's Chrome window (headless=false) inside Electron UI  
**Status**: Final Requirements - Clear Implementation Path  

---

## Meeting Attendees

- **Alex (Senior Architect)** - System design
- **Jordan (Backend Engineer)** - Python/Selenium expert
- **Casey (Frontend Engineer)** - Electron/UI specialist
- **Morgan (DevOps/Security)** - Operations

---

## Crystal Clear Requirements

**User wants:**
1. ✅ BrowserExecutor runs with `headless=False` (Chrome window visible)
2. ✅ That Chrome window is **embedded inside the Electron UI** (not separate window)
3. ✅ User sees browser automation happening inside the Electron app

**Visual Goal:**
```
┌─────────────────────────────────────────────────────┐
│  UV - Personal Assistant                   [_][□][X] │
├─────────────────────────────────────────────────────┤
│ Chat Panel          │  Embedded Chrome Browser      │
│                     │  ┌─────────────────────────┐  │
│ User: Search Google │  │ [Google.com loaded]     │  │
│                     │  │                         │  │
│ Assistant: Searching│  │  [Search box]           │  │
│ ...                 │  │                         │  │
│                     │  │  [Search results...]    │  │
│                     │  │                         │  │
│                     │  │  ← User SEES this live! │  │
│                     │  └─────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

## Discussion

### Alex (Senior Architect) 🏗️

"Alright, NOW we have the complete picture. The user wants:
- Chrome running visibly (`headless=False`)
- That Chrome window embedded in Electron UI

This is actually a **hybrid of our previous solutions**. Let me outline the technical approaches:

**Approach 1: Native Window Embedding (Platform-Specific)**
- Use OS-level APIs to embed Chrome window into Electron window
- Selenium launches Chrome normally
- We capture Chrome's window handle
- Embed it into Electron using native APIs

**Approach 2: CDP + BrowserView (Hybrid)**
- Launch Chrome with CDP enabled
- Use Electron's BrowserView to connect to Chrome
- Display Chrome's content in Electron UI

**Approach 3: Screenshot Streaming (Fallback)**
- Selenium runs Chrome with `headless=False`
- Capture screenshots continuously
- Stream to Electron and display as live feed
- Not true embedding but looks similar

Let me break down each approach's feasibility..."

---

### Casey (Frontend Engineer) ⚛️

"Let me jump in here because I know Electron best.

**Approach 1: Native Window Embedding** ⚠️

This is POSSIBLE but HACKY and platform-specific:

**On macOS:**
```javascript
// Using native macOS APIs
const { exec } = require('child_process');

// Get Chrome window ID
exec('osascript -e \'tell application "Google Chrome" to get id of window 1\'', 
  (err, windowId) => {
    // Embed using NSView
    const { embedWindow } = require('native-window-manager');
    embedWindow(windowId, electronWindow);
  }
);
```

**On Windows:**
```javascript
// Using Win32 APIs
const ffi = require('ffi-napi');
const user32 = ffi.Library('user32', {
  'SetParent': ['long', ['long', 'long']],
  'FindWindow': ['long', ['string', 'string']]
});

// Find Chrome window and embed
const chromeHandle = user32.FindWindow(null, 'Google Chrome');
const electronHandle = mainWindow.getNativeWindowHandle();
user32.SetParent(chromeHandle, electronHandle);
```

**Problems:**
- ❌ Different code for each OS (macOS, Windows, Linux)
- ❌ Requires native modules (`ffi-napi`, `native-window-manager`)
- ❌ Fragile - breaks if Chrome window title changes
- ❌ Window management issues (resize, focus, etc.)
- ⚠️ Works but feels hacky

**Verdict:** Possible but not elegant

---

**Approach 2: CDP + BrowserView** 🎯

This is the PROPER way to do it:

```javascript
// Backend launches Chrome with CDP
// Python code:
from selenium import webdriver
options = webdriver.ChromeOptions()
options.add_argument('--remote-debugging-port=9222')
driver = webdriver.Chrome(options=options)

// Electron connects to Chrome via CDP
const CDP = require('chrome-remote-interface');
const { BrowserView } = require('electron');

// Connect to Chrome's CDP
const client = await CDP({ port: 9222 });
const { Page, Target } = client;

// Get the page target
const targets = await Target.getTargets();
const pageTarget = targets.find(t => t.type === 'page');

// Create BrowserView and navigate to devtools://
const view = new BrowserView({
  webPreferences: {
    nodeIntegration: false,
    contextIsolation: true
  }
});

mainWindow.setBrowserView(view);
view.setBounds({ x: 400, y: 0, width: 1000, height: 900 });

// Connect to Chrome's page via devtools protocol
view.webContents.loadURL(
  `devtools://devtools/bundled/inspector.html?ws=localhost:9222/devtools/page/${pageTarget.id}`
);
```

**Problems:**
- ⚠️ Shows DevTools UI, not clean browser view
- ⚠️ Complex to get raw page rendering
- ⚠️ CDP doesn't directly provide 'embed this page' functionality

**Verdict:** Technically sound but complex

---

**Approach 3: Screenshot Streaming** ✅

This is SIMPLE and WORKS:

```javascript
// Backend captures screenshots continuously
// Python code:
import asyncio
from selenium import webdriver

async def stream_screenshots():
    while browser_active:
        screenshot = driver.get_screenshot_as_base64()
        await websocket.send({
            'type': 'browser_frame',
            'data': screenshot
        })
        await asyncio.sleep(0.1)  # 10 FPS

// Electron displays as live feed
socket.on('browser_frame', (data) => {
  const img = document.getElementById('browser-view');
  img.src = `data:image/png;base64,${data}`;
});
```

**Problems:**
- ⚠️ Not true embedding (it's a video feed)
- ⚠️ Latency (~100-200ms)
- ⚠️ CPU usage for continuous screenshots
- ✅ But it WORKS and looks good!

**Verdict:** Best practical solution

---

**My Recommendation: Approach 3 (Screenshot Streaming)**

Why?
- ✅ Works on all platforms (no platform-specific code)
- ✅ Simple to implement (2-3 hours)
- ✅ No native modules required
- ✅ User sees live browser activity
- ✅ Looks like embedding (good enough!)
- ✅ No complex window management

The user won't notice it's not 'true' embedding if we do it right!"

---

### Jordan (Backend Engineer) 🐍

"Casey, I agree with Approach 3 for a QUICK solution, but let me propose something better:

**Approach 4: Puppeteer + CDP Streaming** 🚀

Instead of Selenium screenshots, use Puppeteer which has BUILT-IN streaming:

```python
# Use pyppeteer (Puppeteer for Python)
from pyppeteer import launch

async def start_browser():
    browser = await launch(
        headless=False,
        args=['--remote-debugging-port=9222']
    )
    page = await browser.newPage()
    
    # Get CDP session
    cdp = await page.target.createCDPSession()
    
    # Enable page events
    await cdp.send('Page.enable')
    
    # Stream frames via CDP
    async def stream_frames():
        while True:
            # Capture screenshot via CDP (faster than Selenium)
            result = await cdp.send('Page.captureScreenshot', {
                'format': 'jpeg',
                'quality': 80
            })
            await websocket.send({
                'type': 'browser_frame',
                'data': result['data']
            })
            await asyncio.sleep(0.05)  # 20 FPS
```

**Benefits over Selenium screenshots:**
- ✅ 2x faster (CDP is native)
- ✅ Better quality control
- ✅ Lower CPU usage
- ✅ Can capture at 20-30 FPS (smoother)

**Drawback:**
- ⚠️ Requires rewriting BrowserExecutor to use Puppeteer

**Compromise Solution:**
Use Approach 3 NOW (Selenium screenshots), migrate to Approach 4 LATER (Puppeteer)."

---

### Morgan (DevOps/Security) 🔒

"Let me evaluate each approach from security and operations perspective:

**Approach 1 (Native Embedding):**
- ⚠️ Moderate risk - native modules can have vulnerabilities
- ⚠️ Platform-specific = more testing needed
- ⚠️ Window handle manipulation = potential security issues

**Approach 2 (CDP + BrowserView):**
- ⚠️ CDP port exposed on localhost (security risk)
- ⚠️ Need authentication for CDP
- ⚠️ Complex error handling

**Approach 3 (Selenium Screenshots):**
- ✅ Low risk - just image streaming
- ✅ No new attack vectors
- ✅ Process isolation maintained
- ✅ Easy to secure

**Approach 4 (Puppeteer + CDP):**
- ⚠️ CDP port exposed (same as Approach 2)
- ✅ Better performance
- ⚠️ Requires rewrite

**Recommendation: Start with Approach 3, consider Approach 4 later**

Approach 3 is the safest and quickest path forward."

---

### Alex (Senior Architect) 🏗️

"Alright team, I'm hearing consensus around Approach 3 for immediate implementation.

Let me propose a **THREE-PHASE PLAN**:

**Phase 1: Screenshot Streaming (This Week)** ✅
- Use Selenium with `headless=False`
- Capture screenshots at 10 FPS
- Stream to Electron via WebSocket
- Display in embedded panel
- **Effort:** 2-3 hours
- **Result:** User sees browser activity in Electron UI

**Phase 2: Optimization (Next Week)** 🔧
- Increase FPS to 20-30
- Add quality controls
- Optimize bandwidth (JPEG compression)
- Add activity logs alongside video
- **Effort:** 4-5 hours
- **Result:** Smoother, better quality

**Phase 3: Puppeteer Migration (Future)** 🚀
- Migrate to Puppeteer for native CDP streaming
- Better performance and quality
- True real-time streaming
- **Effort:** 2-3 weeks
- **Result:** Production-grade solution

This gives us a working solution TODAY while planning for the future."

---

## Team Consensus

### ✅ **Recommended: Three-Phase Approach**

---

## Phase 1: Screenshot Streaming Implementation

### Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Electron App                          │
│  ┌──────────────┐         ┌─────────────────────────┐  │
│  │ Chat Panel   │         │  Browser View Panel     │  │
│  │              │         │  ┌───────────────────┐  │  │
│  │ User: Task   │         │  │ <img> element     │  │  │
│  │              │         │  │ (live screenshots)│  │  │
│  │ Assistant:   │         │  │                   │  │  │
│  │ Working...   │         │  │  [Chrome content] │  │  │
│  │              │         │  │  updates 10x/sec  │  │  │
│  └──────────────┘         │  └───────────────────┘  │  │
│                           └─────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                              ▲
                              │ WebSocket
                              │ (screenshot stream)
┌─────────────────────────────┴───────────────────────────┐
│              Python Backend (FastAPI)                    │
│  ┌───────────────────────────────────────────────────┐  │
│  │  BrowserExecutor Agent                            │  │
│  │  ┌─────────────────────────────────────────────┐ │  │
│  │  │ Selenium WebDriver                          │ │  │
│  │  │ - headless=False                            │ │  │
│  │  │ - Capture screenshots every 100ms           │ │  │
│  │  │ - Encode as base64                          │ │  │
│  │  │ - Send via WebSocket                        │ │  │
│  │  └─────────────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │  Chrome Browser  │
                    │  (visible window)│
                    │  - Runs on screen│
                    │  - User can see  │
                    └──────────────────┘
```

---

### Implementation Details

#### **Backend Changes**

**File: `surface/src/surface/tools/browser_tools.py`**

```python
import asyncio
import base64
from typing import Optional

# Global flag for screenshot streaming
_screenshot_streaming_active = False
_screenshot_stream_task = None

async def start_screenshot_streaming(websocket_manager, interval: float = 0.1):
    """
    Start streaming browser screenshots to Electron.
    
    Parameters
    ----------
    websocket_manager : WebSocketManager
        WebSocket manager for broadcasting
    interval : float
        Seconds between screenshots (default 0.1 = 10 FPS)
    """
    global _screenshot_streaming_active, _browser_driver
    
    _screenshot_streaming_active = True
    
    while _screenshot_streaming_active and _browser_driver:
        try:
            # Capture screenshot
            screenshot = _browser_driver.get_screenshot_as_base64()
            
            # Get current URL for context
            current_url = _browser_driver.current_url
            
            # Broadcast to Electron
            await websocket_manager.broadcast({
                "type": "browser_frame",
                "data": screenshot,
                "url": current_url,
                "timestamp": datetime.now().isoformat()
            })
            
            await asyncio.sleep(interval)
            
        except Exception as e:
            logger.error(f"Screenshot streaming error: {e}")
            await asyncio.sleep(1)  # Back off on error

def stop_screenshot_streaming():
    """Stop screenshot streaming."""
    global _screenshot_streaming_active
    _screenshot_streaming_active = False

def initialize_browser(
    browser_type: str = "chrome",
    headless: bool = True,
    window_size: Tuple[int, int] = (1920, 1080),
    stream_to_electron: bool = False,  # 🆕 NEW PARAMETER
    websocket_manager = None,
    **kwargs
) -> Dict[str, Any]:
    """
    Initialize browser with optional Electron streaming.
    
    Parameters
    ----------
    stream_to_electron : bool
        If True, stream screenshots to Electron UI
    websocket_manager : WebSocketManager
        Required if stream_to_electron is True
    """
    # ... existing initialization code ...
    
    # 🆕 Start screenshot streaming if requested
    if stream_to_electron and websocket_manager:
        # Force headless=False for streaming
        headless = False
        
        # Start streaming in background
        global _screenshot_stream_task
        _screenshot_stream_task = asyncio.create_task(
            start_screenshot_streaming(websocket_manager)
        )
        
        logger.info("📹 Screenshot streaming to Electron enabled")
    
    return {
        "status": "success",
        "streaming": stream_to_electron,
        # ... rest of response
    }

def close_browser() -> Dict[str, Any]:
    """Close browser and stop streaming."""
    global _browser_driver, _screenshot_stream_task
    
    # Stop streaming
    stop_screenshot_streaming()
    if _screenshot_stream_task:
        _screenshot_stream_task.cancel()
        _screenshot_stream_task = None
    
    # ... existing close code ...
```

**File: `surface_synapse/integration.py`**

```python
async def solve_task(task: str, context: dict = None):
    """Solve task with optional browser streaming."""
    
    # Check if browser streaming requested
    stream_browser = context.get('stream_browser', False)
    
    # Pass to BrowserExecutor
    if 'BrowserExecutor' in selected_agents:
        browser_result = await browser_executor.execute(
            task=task,
            stream_to_electron=stream_browser,
            websocket_manager=websocket_manager  # Pass WebSocket manager
        )
```

---

#### **Frontend Changes**

**File: `electron-app/src/renderer/index.html`**

```html
<!-- Add browser view panel -->
<div class="main-container">
  <!-- Existing chat panel -->
  <div class="chat-panel">
    <!-- ... existing chat UI ... -->
  </div>
  
  <!-- 🆕 NEW: Browser view panel -->
  <div class="browser-panel" id="browser-panel">
    <div class="browser-header">
      <span class="browser-title">Browser View</span>
      <span class="browser-url" id="browser-url">about:blank</span>
      <button id="toggle-browser-panel" class="btn-icon">⬅️</button>
    </div>
    <div class="browser-content">
      <img id="browser-frame" class="browser-frame" />
      <div class="browser-placeholder" id="browser-placeholder">
        Browser view will appear here when active
      </div>
    </div>
  </div>
</div>

<!-- Settings toggle -->
<div class="settings-panel">
  <label>
    <input type="checkbox" id="stream-browser" checked />
    Show Browser View
  </label>
</div>
```

**File: `electron-app/src/renderer/css/styles.css`**

```css
/* Browser panel layout */
.main-container {
  display: flex;
  height: 100vh;
}

.chat-panel {
  flex: 1;
  min-width: 400px;
}

.browser-panel {
  flex: 1;
  min-width: 600px;
  border-left: 1px solid #2a2f3a;
  display: flex;
  flex-direction: column;
  background: #0a0e14;
}

.browser-panel.hidden {
  display: none;
}

.browser-header {
  display: flex;
  align-items: center;
  padding: 12px;
  background: #1a1f2a;
  border-bottom: 1px solid #2a2f3a;
}

.browser-title {
  font-weight: 600;
  color: #00d4ff;
  margin-right: 12px;
}

.browser-url {
  flex: 1;
  color: #8a8f98;
  font-size: 12px;
  font-family: monospace;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.browser-content {
  flex: 1;
  position: relative;
  overflow: hidden;
}

.browser-frame {
  width: 100%;
  height: 100%;
  object-fit: contain;
  background: #ffffff;
}

.browser-placeholder {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #8a8f98;
  text-align: center;
}

.browser-placeholder.hidden {
  display: none;
}
```

**File: `electron-app/src/renderer/js/app.js`**

```javascript
// Browser view state
let browserPanelVisible = true;
let browserFrameActive = false;

// Initialize browser panel
function initBrowserPanel() {
  const browserPanel = document.getElementById('browser-panel');
  const toggleBtn = document.getElementById('toggle-browser-panel');
  const streamCheckbox = document.getElementById('stream-browser');
  
  // Toggle panel visibility
  toggleBtn.addEventListener('click', () => {
    browserPanelVisible = !browserPanelVisible;
    browserPanel.classList.toggle('hidden', !browserPanelVisible);
    toggleBtn.textContent = browserPanelVisible ? '⬅️' : '➡️';
  });
  
  // Save preference
  streamCheckbox.addEventListener('change', (e) => {
    localStorage.setItem('stream-browser', e.target.checked);
  });
  
  // Load preference
  const savedPref = localStorage.getItem('stream-browser');
  if (savedPref !== null) {
    streamCheckbox.checked = savedPref === 'true';
  }
}

// Handle browser frames from WebSocket
socket.on('browser_frame', (data) => {
  const browserFrame = document.getElementById('browser-frame');
  const browserUrl = document.getElementById('browser-url');
  const placeholder = document.getElementById('browser-placeholder');
  
  // Show frame, hide placeholder
  if (!browserFrameActive) {
    browserFrameActive = true;
    placeholder.classList.add('hidden');
  }
  
  // Update image
  browserFrame.src = `data:image/png;base64,${data.data}`;
  
  // Update URL
  if (data.url) {
    browserUrl.textContent = data.url;
  }
});

// Handle browser close
socket.on('browser_closed', () => {
  browserFrameActive = false;
  document.getElementById('browser-placeholder').classList.remove('hidden');
  document.getElementById('browser-url').textContent = 'about:blank';
});

// Send message with browser streaming preference
async function sendMessage(message) {
  const streamBrowser = document.getElementById('stream-browser').checked;
  
  const response = await window.api.sendMessage(message, {
    stream_browser: streamBrowser
  });
  
  // ... handle response ...
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  initBrowserPanel();
  // ... other initialization ...
});
```

---

### Testing Plan

**Manual Tests:**
1. ✅ Enable "Show Browser View" → Browser panel appears
2. ✅ Run browser task → Screenshots stream to panel
3. ✅ Verify URL updates in browser header
4. ✅ Toggle panel visibility → Panel hides/shows
5. ✅ Disable streaming → Panel shows placeholder
6. ✅ Close browser → Placeholder reappears

**Performance Tests:**
1. ✅ Monitor CPU usage during streaming
2. ✅ Monitor network bandwidth (WebSocket)
3. ✅ Test with long-running browser tasks
4. ✅ Test with multiple tabs/windows

---

## Phase 2: Optimization (Future)

### Improvements

1. **Higher FPS:**
   - Increase to 20-30 FPS for smoother experience
   - Adaptive FPS based on activity

2. **Better Compression:**
   - Use JPEG instead of PNG (smaller size)
   - Adjustable quality settings

3. **Activity Overlay:**
   - Show activity logs on top of browser view
   - Highlight elements being interacted with

4. **User Interaction:**
   - Allow clicking in browser view (forward to backend)
   - Mouse hover shows element info

---

## Phase 3: Puppeteer Migration (Future)

### Benefits

- 2-3x better performance
- Native CDP streaming
- Better quality control
- Lower latency (~50ms vs ~200ms)

### Migration Path

1. Create `PuppeteerBrowserExecutor` agent
2. Port browser tools to Puppeteer
3. Run both agents in parallel
4. Gradually migrate users
5. Deprecate Selenium agent

---

## Comparison: All Approaches

| Approach | Effort | Quality | Latency | Platform | Security |
|----------|--------|---------|---------|----------|----------|
| Native Embed | High | Perfect | 0ms | Specific | Medium |
| CDP + View | High | Good | 50ms | All | Medium |
| Selenium Screenshots | **Low** | **Good** | **200ms** | **All** | **High** |
| Puppeteer + CDP | Medium | Excellent | 50ms | All | Medium |

**Winner for Phase 1:** Selenium Screenshots (best effort/value ratio)

---

## Final Recommendation

### ✅ **Implement Phase 1 NOW (2-3 hours)**

**What user gets:**
- ✅ Browser activity visible in Electron UI
- ✅ Looks like embedded browser (good enough!)
- ✅ Real-time updates (10 FPS)
- ✅ Toggle on/off as needed
- ✅ Works on all platforms

**What it costs:**
- 2-3 hours of development
- Minimal security risk
- ~5-10% CPU overhead
- ~1-2 Mbps network bandwidth

**Future improvements:**
- Phase 2: Better quality and performance
- Phase 3: True CDP streaming with Puppeteer

---

## Success Criteria

- ✅ User can see browser automation in Electron UI
- ✅ Updates appear in real-time (< 200ms latency)
- ✅ CPU usage < 15% overhead
- ✅ No security issues introduced
- ✅ Works on macOS, Windows, Linux
- ✅ Implementation complete in < 3 hours

---

## Conclusion

**YES, we can embed the Chrome instance in Electron UI!**

**Method:** Screenshot streaming (Phase 1)
- Not "true" embedding but looks and feels like it
- Quick to implement (2-3 hours)
- Works perfectly for user's needs
- Safe and secure

**Future:** Migrate to Puppeteer for true CDP streaming (Phase 3)

---

**Meeting Adjourned** 🎯

*Alex: "Finally, a clear path forward!"*  
*Jordan: "Phase 1 now, Phase 3 later. I'm happy."*  
*Casey: "I can implement Phase 1 this afternoon!"*  
*Morgan: "Safe, secure, and practical. Approved!"*  
*All: "Let's ship it! 🚀"*
