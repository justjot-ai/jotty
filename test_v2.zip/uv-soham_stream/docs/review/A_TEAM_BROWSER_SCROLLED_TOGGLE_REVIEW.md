# A-Team Review: Browser Card Toggle When Scrolled + Instance Cleanup

**Date:** 2026-02-02  
**Topic:** Hide browser when card is scrolled out of view; reset browser on new task  
**Status:** APPROVED FOR IMPLEMENTATION

---

## Meeting Attendees

- **Alex (Senior Architect)** - System design
- **Jordan (Backend Engineer)** - Electron IPC expert
- **Casey (Frontend Engineer)** - Renderer/UI specialist
- **Morgan (DevOps/Security)** - Performance & resource management

---

## User Requirements

**Request 1:**
> "In electron js, once browser card is moved to scrollable location i.e there are 4 cards more active than browser... then hide embedded browser in the card and instead of directly showing it... make it such that there is a display toggle button to show browser in that card"

**Request 2:**
> "Also once task is complete and user starts new task is the older browser instance closed?"

---

## Discussion

### Alex (Senior Architect) 🏗️

"Alright team, let's break this down into two distinct problems:

**Problem 1: BrowserView Position When Scrolled**

Currently, we have a native BrowserView that overlays the browser module card. The problem is:
- Cards are in a 2x2 grid (4 visible at once)
- When 5+ cards exist, the grid scrolls
- The BrowserView doesn't know when its card scrolls out of view
- It continues rendering at calculated bounds, potentially showing outside the visible area

**Problem 2: Browser Instance Lifecycle**

Looking at the code:
```javascript
// main.js - BrowserView is created ONCE
function createBrowserView() {
  browserView = new BrowserView({ ... });
  browserView.webContents.loadURL('about:blank');
}
```

The BrowserView persists across tasks. It's hidden via `removeBrowserView()` but never reset or destroyed. This is BY DESIGN because they use a persistent session (`persist:browser-agent`) to preserve login state.

**My Architecture Proposal:**

1. Track browser card position relative to viewport
2. Auto-hide BrowserView when card index >= 4 (not in first 2 rows)
3. Show a toggle button that user can click to temporarily show browser
4. On new task: Reset BrowserView to about:blank but keep session

Casey, what do you think about the UI approach?"

---

### Casey (Frontend Engineer) ⚛️

"Alex is overcomplicating the visibility detection. We don't need to track scroll position manually!

**Simple Solution for Visibility:**

The `moveBoxToFront()` method already reorders cards based on activity. I can:
1. Count total cards in the container
2. Find browser card's position (index)
3. If index >= 4, card is 'off-screen' (below the fold)
4. Auto-hide BrowserView and show toggle button

```javascript
// In agent-view-manager.js
checkBrowserCardVisibility() {
  const cards = Array.from(this.container.children);
  const browserCard = this.moduleBoxes.get('BrowserExecutor')?.element;
  
  if (!browserCard) return { isVisible: false, position: -1 };
  
  const position = cards.indexOf(browserCard);
  const isInViewport = position < 4; // First 2 rows (2x2 grid)
  
  return { isVisible: isInViewport, position };
}
```

**Toggle Button Design:**

When browser is hidden due to scroll, replace the placeholder with:
```html
<div class="browser-toggle-container">
  <div class="browser-toggle-info">
    <span class="toggle-icon">🌐</span>
    <span class="toggle-text">Browser is active (hidden to save resources)</span>
  </div>
  <button class="browser-show-btn">👁 Show Browser</button>
</div>
```

This is cleaner than trying to overlay the BrowserView on a scrolled card.

**Implementation Plan:**
1. Add `browserHiddenDueToScroll` flag to AgentViewManager
2. Modify `moveBoxToFront()` to call visibility check after move
3. Create toggle button HTML in browser card
4. Toggle between BrowserView visible and placeholder with button

Jordan, how should we handle the BrowserView bounds when hidden?"

---

### Jordan (Backend Engineer) 🐍

"Casey, your approach is solid. Let me address the BrowserView management:

**BrowserView State Management:**

When browser card is NOT in top 4 positions:
1. Call `mainWindow.removeBrowserView(browserView)` - detaches from window
2. Keep BrowserView alive (preserve page state & session)
3. Show toggle button in card

When user clicks 'Show Browser':
1. Re-attach BrowserView with `mainWindow.setBrowserView(browserView)`
2. Update bounds to match card position
3. Focus the BrowserView for input

```javascript
// In main.js - Add new IPC handler
ipcMain.handle('browser-detach-preserve', async () => {
  if (browserView && mainWindow) {
    mainWindow.removeBrowserView(browserView);
    browserView._detachedPreserved = true;
    return { success: true, state: 'detached' };
  }
  return { success: false };
});

ipcMain.handle('browser-reattach', async () => {
  if (browserView && mainWindow && browserView._detachedPreserved) {
    mainWindow.setBrowserView(browserView);
    browserView._detachedPreserved = false;
    browserView.webContents.focus();
    return { success: true };
  }
  return { success: false };
});
```

**For New Task Cleanup:**

We SHOULD NOT destroy the BrowserView (loses session). Instead:
```javascript
ipcMain.handle('browser-reset', async () => {
  if (browserView) {
    // Navigate to blank - clears page state
    await browserView.webContents.loadURL('about:blank');
    // Optional: Clear local storage (but keep cookies for auth)
    await browserView.webContents.session.clearStorageData({
      storages: ['localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
    });
    return { success: true };
  }
  return { success: false };
});
```

Morgan, any security concerns?"

---

### Morgan (DevOps/Security) 🔒

"Jordan's approach is good. Let me add some operational concerns:

**Performance Consideration:**

Detaching BrowserView is BETTER than just hiding with bounds:
- Detached BrowserView doesn't consume GPU compositing
- Reduces memory pressure when user is focused elsewhere
- Page continues running (good for websocket connections, bad for CPU)

**Recommendation:** Add option to pause JavaScript when detached for long periods (>5 minutes):
```javascript
if (detachedForLong) {
  browserView.webContents.executeJavaScript('window.stop();');
}
```

**Security on Reset:**

Jordan's reset is good but incomplete. For new tasks, also clear:
- Browser history (in-memory)
- Pending network requests

```javascript
ipcMain.handle('browser-reset', async () => {
  if (browserView) {
    // Stop any ongoing page operations
    browserView.webContents.stop();
    
    // Clear storage but preserve cookies
    await browserView.webContents.session.clearStorageData({
      storages: ['localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
    });
    
    // Navigate to blank
    await browserView.webContents.loadURL('about:blank');
    
    // Clear browsing data BUT preserve cookies
    await browserView.webContents.clearHistory();
    
    return { success: true };
  }
  return { success: false };
});
```

**My Approval:** ✅ This approach is safe and resource-efficient."

---

## Consensus & Final Solution

### ✅ APPROVED: Two-Part Implementation

---

## Part 1: Auto-Hide Browser When Scrolled + Toggle Button

### AgentViewManager Changes (`agent-view-manager.js`):

```javascript
// Add new properties
this.browserHiddenDueToScroll = false;
this.browserToggleShown = false;

// New method: Check browser visibility based on card position
checkBrowserCardPosition() {
  if (!this.container) return { isVisible: true, position: -1 };
  
  const cards = Array.from(this.container.children);
  const browserCard = this.moduleBoxes.get('BrowserExecutor')?.element;
  
  if (!browserCard) return { isVisible: true, position: -1 };
  
  const position = cards.indexOf(browserCard);
  const isInViewport = position >= 0 && position < 4; // First 2 rows
  
  return { isVisible: isInViewport, position };
}

// New method: Update browser visibility based on card position
async updateBrowserVisibilityForScroll() {
  const { isVisible, position } = this.checkBrowserCardPosition();
  
  if (isVisible && this.browserHiddenDueToScroll) {
    // Card moved back to visible area - show browser if toggle is on
    // Don't auto-show, let user decide via toggle
  } else if (!isVisible && this.browserViewVisible) {
    // Card scrolled out of view - hide and show toggle
    await this.hideBrowserDueToScroll();
  }
}

// New method: Hide browser due to scroll, show toggle
async hideBrowserDueToScroll() {
  this.browserHiddenDueToScroll = true;
  
  // Hide BrowserView
  if (window.browserAPI) {
    await window.browserAPI.setVisible(false);
  }
  this.browserViewVisible = false;
  
  // Show toggle button in card
  this.showBrowserToggleButton();
}

// New method: Show toggle button in browser card
showBrowserToggleButton() {
  const moduleBox = this.moduleBoxes.get('BrowserExecutor');
  if (!moduleBox || !moduleBox.placeholder) return;
  
  moduleBox.placeholder.style.display = 'flex';
  moduleBox.placeholder.innerHTML = `
    <div class="browser-toggle-container">
      <div class="browser-toggle-icon">🌐</div>
      <div class="browser-toggle-text">Browser Active</div>
      <div class="browser-toggle-hint">Hidden to save resources (card scrolled)</div>
      <button class="browser-toggle-btn" onclick="window.agentViewManager.toggleBrowserDisplay()">
        👁 Show Browser
      </button>
    </div>
  `;
  
  this.browserToggleShown = true;
}

// New method: Toggle browser display via button
async toggleBrowserDisplay() {
  if (this.browserViewVisible) {
    // Hide browser
    await this.hideNativeBrowser();
    this.showBrowserToggleButton();
  } else {
    // Show browser
    await this.showNativeBrowser();
    this.browserHiddenDueToScroll = false;
    this.browserToggleShown = false;
  }
}
```

### Modify `moveBoxToFront()`:

```javascript
// After animation cleanup, check browser visibility
setTimeout(() => {
  // ... existing cleanup code ...
  
  // Check if browser card moved out of visible area
  this.updateBrowserVisibilityForScroll();
}, 400);
```

---

## Part 2: Browser Reset on New Task

### Main Process (`main.js`):

```javascript
// Add new IPC handler
ipcMain.handle('browser-reset', async () => {
  if (!browserView) {
    return { success: false, error: 'BrowserView not initialized' };
  }
  
  try {
    // Stop ongoing operations
    browserView.webContents.stop();
    
    // Clear storage but preserve cookies (for login persistence)
    await browserView.webContents.session.clearStorageData({
      storages: ['localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
    });
    
    // Navigate to blank
    await browserView.webContents.loadURL('about:blank');
    
    // Clear in-memory history
    browserView.webContents.clearHistory();
    
    // Reset custom bounds flag
    browserView._customBounds = false;
    
    console.log('🔄 BrowserView reset for new task');
    return { success: true };
  } catch (error) {
    console.error('Browser reset error:', error);
    return { success: false, error: error.message };
  }
});
```

### Preload Script (`preload.js`):

```javascript
// Add to browserAPI
reset: () => ipcRenderer.invoke('browser-reset'),
```

### App.js - Call Reset on New Task:

```javascript
// In sendMessageWorkspace(), before task execution:
async sendMessageWorkspace(message) {
  // Reset browser for new task
  if (window.browserAPI) {
    await window.browserAPI.reset();
  }
  
  // Reset agent view manager
  if (this.agentViewManager) {
    this.agentViewManager.resetView();
  }
  
  // ... rest of method
}
```

---

## CSS Additions (`agent-views.css`):

```css
/* Browser Toggle Button */
.browser-toggle-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 20px;
  text-align: center;
}

.browser-toggle-icon {
  font-size: 48px;
  opacity: 0.7;
}

.browser-toggle-text {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
}

.browser-toggle-hint {
  font-size: 11px;
  color: var(--text-dim);
  max-width: 200px;
}

.browser-toggle-btn {
  padding: 10px 20px;
  background: linear-gradient(135deg, rgba(96, 165, 250, 0.2), rgba(59, 130, 246, 0.3));
  border: 1px solid rgba(96, 165, 250, 0.4);
  border-radius: 8px;
  color: var(--accent-blue);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.browser-toggle-btn:hover {
  background: linear-gradient(135deg, rgba(96, 165, 250, 0.3), rgba(59, 130, 246, 0.4));
  border-color: rgba(96, 165, 250, 0.6);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(96, 165, 250, 0.2);
}

.browser-toggle-btn:active {
  transform: translateY(0);
}
```

---

## Testing Checklist

1. **Toggle Visibility:**
   - [ ] Create 5+ module boxes (browser card pushed past row 2)
   - [ ] Verify BrowserView hides automatically
   - [ ] Verify toggle button appears
   - [ ] Click toggle → BrowserView reappears
   - [ ] Move browser card to front → BrowserView should show option to display

2. **New Task Reset:**
   - [ ] Start task with browser navigation
   - [ ] Complete task → return to welcome
   - [ ] Start new task
   - [ ] Verify browser shows about:blank initially
   - [ ] Verify old page state is cleared
   - [ ] Verify login cookies still work

---

## Implementation Order

1. **Phase 1:** Browser Reset IPC handler (`main.js`, `preload.js`)
2. **Phase 2:** Browser visibility tracking (`agent-view-manager.js`)
3. **Phase 3:** Toggle button UI (`agent-view-manager.js`, `agent-views.css`)
4. **Phase 4:** Integrate reset in app.js

**Estimated Time:** 1-2 hours  
**Risk:** LOW (additive changes, no breaking modifications)

---

**Meeting Adjourned** ✅

*Alex: "Clean solution. Auto-hide when scrolled, manual toggle to show."*  
*Jordan: "IPC handlers are straightforward. Reset preserves auth."*  
*Casey: "UI is minimal - just a toggle button when needed."*  
*Morgan: "Resource-efficient. No security concerns."*
