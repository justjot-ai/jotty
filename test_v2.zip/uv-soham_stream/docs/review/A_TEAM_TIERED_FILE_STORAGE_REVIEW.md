# A-Team Review: Tiered File Storage for Inter-Agent Communication

**Date:** 2026-02-02  
**Feature:** Large File Transfer with Tiered Storage Lifecycle  
**Severity:** ENHANCEMENT - Enables binary data transfer between agents  
**Source:** External analysis document (AGENT_SLACK_FILE_TRANSFER_ANALYSIS.md)

---

## 🚨 EXECUTIVE SUMMARY

### What We're Adding:
- `FileReference` dataclass for file path passing instead of raw bytes
- `SharedFileStorage` class for managing inter-agent file transfers
- `TieredStorageManager` for lifecycle management (hot → warm → cold → archive)
- Auto-detection of large files (>1MB or binary) for file mode

### Storage Tiers:
| Tier | Age | Location | Format | Access Speed |
|------|-----|----------|--------|--------------|
| **Hot** | 0-1 day | `/synapse_shared/hot/` | Raw files | Instant |
| **Warm** | 1-7 days | `/synapse_shared/warm/` | Raw files | Fast |
| **Cold** | 7-30 days | `/synapse_shared/cold/` | Compressed (.gz) | Medium |
| **Archive** | 30+ days | `/synapse_shared/archive/YYYY/MM/` | Tar.gz bundles | Slow |

---

## 🎭 A-Team Deliberation

### Alan Turing (Computation):

> "The proposal is **computationally sound**, but I have concerns about the tiered storage complexity. Let me analyze:
>
> **The Good:**
> - File reference pattern avoids O(n) memory for large files
> - Lazy loading shifts computation cost to consumers who actually need data
> - Checksum verification is cryptographically proper (SHA256)
>
> **The Problematic:**
> - The storage tier transitions require a **background scheduler**. Who runs it? The proposal doesn't specify.
> - Race condition: What if Agent A sends a file reference, then storage manager moves it to warm/cold before Agent B reads it?
> - The `path` in `FileReference` becomes **stale** after tier transition
>
> **Evidence:**
> ```python
> # PROBLEM: FileReference has absolute path
> ref = FileReference(
>     path='/synapse_shared/hot/a1b2c3d4_audio.wav',  # ← This becomes INVALID
>     ...
> )
> # After 24h, file moves to /synapse_shared/warm/...
> # Receiver tries ref.path → FileNotFoundError!
> ```
>
> **Verdict:** The design needs a **path resolution layer** that translates logical IDs to physical paths."

---

### John von Neumann (Game Theory):

> "Turing is being **pedantic as usual**. The path staleness problem is trivial to solve with a registry lookup. My concerns are **strategic**:
>
> **Game-Theoretic Issues:**
>
> 1. **Storage is a shared resource** - What prevents Agent A from flooding storage with 50GB of files? There's no **quota system**.
>
> 2. **Archive retention is wasteful** - Why keep files for a YEAR? Agent communication is typically consumed within minutes. This isn't backup storage.
>
> 3. **The 1MB threshold is arbitrary** - A 900KB JSON file won't trigger file mode, but it's still large. Should be configurable per-agent or per-content-type.
>
> **Evidence from the original proposal:**
> ```python
> self.file_mode_threshold = config.get('file_mode_threshold', 1_000_000)  # Fixed 1MB
> ```
>
> **Nash Equilibrium Concern:** Without quotas, agents have **no incentive to clean up**. The dominant strategy is 'always save, never delete' which leads to storage exhaustion.
>
> **Verdict:** Add per-agent quotas and a **cost function** for storage usage that feeds into the Nash communication decision."

---

### David Silver (Reinforcement Learning):

> "Von Neumann, your quota idea is **overcomplicated nonsense**. We're not building a cloud provider. This is same-machine inter-agent communication.
>
> **The RL Perspective:**
>
> The tiered storage is essentially a **state transition system**:
> ```
> S_hot → S_warm → S_cold → S_archive → S_deleted
> ```
>
> **My Concerns:**
>
> 1. **Transition timing is rigid** - Why fixed 1 day, 7 days, 30 days? Files should transition based on **access patterns**. A file accessed frequently should stay hot even after 24h.
>
> 2. **No learning from access patterns** - We should track file access frequency and optimize tier placement. LRU-like behavior is smarter than age-based.
>
> 3. **Compression is expensive** - Moving to cold tier requires CPU for gzip. If many files transition simultaneously (e.g., after a batch job), this causes **latency spikes**.
>
> **Proposed Enhancement:**
> ```python
> @dataclass
> class FileMetadata:
>     created_at: float
>     last_accessed: float
>     access_count: int
>     
>     def should_stay_hot(self) -> bool:
>         # Keep hot if accessed recently OR frequently accessed
>         recency = time.time() - self.last_accessed < 3600  # <1h since access
>         frequency = self.access_count > 10
>         return recency or frequency
> ```
>
> **Verdict:** Age-based tiers are fine for v1, but we need **access tracking** from day one to enable smarter policies later."

---

### Noam Chomsky (Language/Structure):

> "Silver, you're proposing **premature optimization**. We haven't even built the basic system.
>
> Let me focus on the **structural/semantic issues**:
>
> **Issue 1: File Reference Schema**
>
> The proposed `file_reference` message type is **underspecified**:
> ```python
> data = {
>     'type': 'file_reference',
>     'path': file_ref.path,
>     'content_type': file_ref.content_type,
>     'size_bytes': file_ref.size_bytes,
>     'checksum': file_ref.checksum,
>     'original_field': field_name
> }
> ```
>
> Missing:
> - `file_id`: Unique identifier for registry lookup (Turing's point)
> - `tier`: Current storage tier
> - `ttl`: Time-to-live before deletion
> - `encoding`: For text files (UTF-8, ASCII, etc.)
>
> **Issue 2: Content Type Detection**
>
> The magic number detection is **incomplete**:
> ```python
> if data[:4] == b'RIFF':  # WAV
> elif data[:3] == b'\xff\xd8\xff':  # JPEG
> # ...
> ```
>
> Missing: MP3 (ID3), MP4/MOV, WebP, BMP, TIFF, and many others. Should use `python-magic` library or similar.
>
> **Issue 3: Archive Structure**
>
> The `/archive/YYYY/MM/` structure is good, but:
> - What about files spanning month boundaries?
> - How do we find a specific archived file? Need an **index**.
>
> **Verdict:** The schema needs to be more robust. Add `file_id` for path-independent reference, use proper MIME detection, create archive index."

---

### Modern AI Engineer:

> "Alright, I've listened to everyone's **theoretically correct but practically useless** concerns. Let me synthesize a **actually buildable** design:
>
> ## Synthesis: Practical Tiered Storage Design
>
> ### Phase 1: Core Implementation (What we build now)
>
> **File 1: `Synapse/core/file_storage.py`** (~200 lines)
>
> ```python
> import hashlib
> import uuid
> import time
> import gzip
> import tarfile
> import os
> import shutil
> from pathlib import Path
> from dataclasses import dataclass, field
> from typing import Dict, Optional, Any
> from enum import Enum
> import logging
> 
> logger = logging.getLogger(__name__)
> 
> 
> class StorageTier(Enum):
>     HOT = 'hot'      # 0-1 day, raw files, instant access
>     WARM = 'warm'    # 1-7 days, raw files, fast access
>     COLD = 'cold'    # 7-30 days, compressed, medium access
>     ARCHIVE = 'archive'  # 30+ days, tar bundles, slow access
> 
> 
> @dataclass
> class FileReference:
>     \"\"\"
>     Reference to a file in shared storage.
>     
>     Uses file_id for path-independent referencing (Turing's suggestion).
>     \"\"\"
>     file_id: str  # UUID - primary identifier
>     original_filename: str
>     content_type: str
>     size_bytes: int
>     checksum: str  # SHA256
>     created_at: float
>     tier: StorageTier = StorageTier.HOT
>     metadata: Dict[str, Any] = field(default_factory=dict)
>     
>     # Access tracking (Silver's suggestion)
>     last_accessed: float = field(default_factory=time.time)
>     access_count: int = 0
>     
>     def resolve_path(self, storage: 'TieredFileStorage') -> Path:
>         \"\"\"Resolve current physical path via storage registry.\"\"\"
>         return storage.resolve_path(self.file_id)
>     
>     def read_bytes(self, storage: 'TieredFileStorage') -> bytes:
>         \"\"\"Read file content, handling compression transparently.\"\"\"
>         return storage.read_file(self.file_id)
> 
> 
> class TieredFileStorage:
>     \"\"\"
>     Tiered storage system for inter-agent file transfer.
>     
>     Tiers:
>     - HOT: 0-1 day, raw files
>     - WARM: 1-7 days, raw files  
>     - COLD: 7-30 days, gzip compressed
>     - ARCHIVE: 30+ days, monthly tar.gz bundles
>     \"\"\"
>     
>     # Tier age thresholds in seconds
>     TIER_THRESHOLDS = {
>         StorageTier.HOT: 0,           # Immediate
>         StorageTier.WARM: 86400,      # 1 day
>         StorageTier.COLD: 604800,     # 7 days
>         StorageTier.ARCHIVE: 2592000, # 30 days
>     }
>     
>     def __init__(self, base_path: str = '/tmp/synapse_shared'):
>         self.base_path = Path(base_path)
>         self._init_tier_directories()
>         
>         # File registry: file_id -> FileReference
>         self.registry: Dict[str, FileReference] = {}
>         
>         # Path index: file_id -> current physical path
>         self.path_index: Dict[str, Path] = {}
>         
>         logger.info(f'📁 [TIERED STORAGE] Initialized at {self.base_path}')
>     
>     def _init_tier_directories(self):
>         \"\"\"Create tier directories.\"\"\"
>         for tier in StorageTier:
>             tier_path = self.base_path / tier.value
>             tier_path.mkdir(parents=True, exist_ok=True)
>     
>     def save(
>         self,
>         data: bytes,
>         filename: str,
>         content_type: str,
>         metadata: Dict = None
>     ) -> FileReference:
>         \"\"\"Save file to hot tier and return reference.\"\"\"
>         file_id = str(uuid.uuid4())
>         checksum = hashlib.sha256(data).hexdigest()
>         
>         # Save to hot tier
>         safe_filename = self._sanitize_filename(filename)
>         physical_path = self.base_path / 'hot' / f'{file_id}_{safe_filename}'
>         
>         with open(physical_path, 'wb') as f:
>             f.write(data)
>         
>         # Create reference
>         ref = FileReference(
>             file_id=file_id,
>             original_filename=filename,
>             content_type=content_type,
>             size_bytes=len(data),
>             checksum=checksum,
>             created_at=time.time(),
>             tier=StorageTier.HOT,
>             metadata=metadata or {}
>         )
>         
>         # Register
>         self.registry[file_id] = ref
>         self.path_index[file_id] = physical_path
>         
>         logger.info(f'📁 [STORAGE] Saved {filename} ({len(data)} bytes) -> {file_id}')
>         return ref
>     
>     def resolve_path(self, file_id: str) -> Optional[Path]:
>         \"\"\"Resolve file_id to current physical path.\"\"\"
>         return self.path_index.get(file_id)
>     
>     def read_file(self, file_id: str) -> Optional[bytes]:
>         \"\"\"Read file by ID, handling compression transparently.\"\"\"
>         ref = self.registry.get(file_id)
>         if not ref:
>             logger.warning(f'📁 [STORAGE] File not found: {file_id}')
>             return None
>         
>         path = self.path_index.get(file_id)
>         if not path or not path.exists():
>             logger.error(f'📁 [STORAGE] Physical path missing: {file_id}')
>             return None
>         
>         # Update access tracking
>         ref.last_accessed = time.time()
>         ref.access_count += 1
>         
>         # Handle compression
>         if ref.tier == StorageTier.COLD:
>             with gzip.open(path, 'rb') as f:
>                 return f.read()
>         elif ref.tier == StorageTier.ARCHIVE:
>             return self._read_from_archive(ref)
>         else:
>             with open(path, 'rb') as f:
>                 return f.read()
>     
>     def run_tier_transition(self):
>         \"\"\"
>         Move files between tiers based on age.
>         
>         Call this periodically (e.g., every hour via background task).
>         \"\"\"
>         now = time.time()
>         transitions = []
>         
>         for file_id, ref in list(self.registry.items()):
>             age = now - ref.created_at
>             
>             # Determine target tier based on age
>             target_tier = self._get_tier_for_age(age)
>             
>             if target_tier != ref.tier:
>                 transitions.append((file_id, ref.tier, target_tier))
>         
>         # Execute transitions
>         for file_id, from_tier, to_tier in transitions:
>             self._transition_file(file_id, from_tier, to_tier)
>         
>         if transitions:
>             logger.info(f'📁 [STORAGE] Transitioned {len(transitions)} files')
>     
>     def _get_tier_for_age(self, age_seconds: float) -> StorageTier:
>         \"\"\"Determine tier based on file age.\"\"\"
>         if age_seconds >= self.TIER_THRESHOLDS[StorageTier.ARCHIVE]:
>             return StorageTier.ARCHIVE
>         elif age_seconds >= self.TIER_THRESHOLDS[StorageTier.COLD]:
>             return StorageTier.COLD
>         elif age_seconds >= self.TIER_THRESHOLDS[StorageTier.WARM]:
>             return StorageTier.WARM
>         else:
>             return StorageTier.HOT
>     
>     def _transition_file(self, file_id: str, from_tier: StorageTier, to_tier: StorageTier):
>         \"\"\"Move file between tiers.\"\"\"
>         ref = self.registry.get(file_id)
>         if not ref:
>             return
>         
>         old_path = self.path_index.get(file_id)
>         if not old_path or not old_path.exists():
>             return
>         
>         logger.info(f'📁 [STORAGE] Transitioning {file_id}: {from_tier.value} -> {to_tier.value}')
>         
>         if to_tier == StorageTier.COLD:
>             # Compress with gzip
>             new_path = self.base_path / 'cold' / f'{file_id}.gz'
>             with open(old_path, 'rb') as f_in:
>                 with gzip.open(new_path, 'wb') as f_out:
>                     shutil.copyfileobj(f_in, f_out)
>             old_path.unlink()
>             
>         elif to_tier == StorageTier.ARCHIVE:
>             # Add to monthly tar.gz archive
>             new_path = self._add_to_archive(ref, old_path)
>             old_path.unlink()
>             
>         else:
>             # Simple move (HOT -> WARM or decompression)
>             new_path = self.base_path / to_tier.value / old_path.name
>             shutil.move(str(old_path), str(new_path))
>         
>         # Update registry
>         ref.tier = to_tier
>         self.path_index[file_id] = new_path
>     
>     def _add_to_archive(self, ref: FileReference, source_path: Path) -> Path:
>         \"\"\"Add file to monthly archive bundle.\"\"\"
>         from datetime import datetime
>         dt = datetime.fromtimestamp(ref.created_at)
>         archive_dir = self.base_path / 'archive' / str(dt.year) / f'{dt.month:02d}'
>         archive_dir.mkdir(parents=True, exist_ok=True)
>         
>         archive_path = archive_dir / f'{dt.year}_{dt.month:02d}_files.tar.gz'
>         
>         # Append to existing archive or create new
>         mode = 'a:gz' if archive_path.exists() else 'w:gz'
>         with tarfile.open(archive_path, mode) as tar:
>             tar.add(source_path, arcname=f'{ref.file_id}_{ref.original_filename}')
>         
>         return archive_path
>     
>     def _read_from_archive(self, ref: FileReference) -> Optional[bytes]:
>         \"\"\"Read file from tar.gz archive.\"\"\"
>         archive_path = self.path_index.get(ref.file_id)
>         if not archive_path or not archive_path.exists():
>             return None
>         
>         target_name = f'{ref.file_id}_{ref.original_filename}'
>         with tarfile.open(archive_path, 'r:gz') as tar:
>             for member in tar.getmembers():
>                 if target_name in member.name:
>                     f = tar.extractfile(member)
>                     if f:
>                         return f.read()
>         return None
>     
>     def _sanitize_filename(self, filename: str) -> str:
>         \"\"\"Remove dangerous characters from filename.\"\"\"
>         # Remove path traversal attempts
>         safe = filename.replace('..', '').replace('/', '_').replace('\\\\', '_')
>         return safe[:100]  # Limit length
>     
>     def cleanup_expired(self, max_archive_age_days: int = 365):
>         \"\"\"Remove archives older than max age.\"\"\"
>         from datetime import datetime, timedelta
>         cutoff = datetime.now() - timedelta(days=max_archive_age_days)
>         
>         archive_base = self.base_path / 'archive'
>         if not archive_base.exists():
>             return
>         
>         for year_dir in archive_base.iterdir():
>             if not year_dir.is_dir():
>                 continue
>             try:
>                 year = int(year_dir.name)
>                 if year < cutoff.year:
>                     shutil.rmtree(year_dir)
>                     logger.info(f'📁 [STORAGE] Removed archive: {year_dir}')
>             except ValueError:
>                 pass
>     
>     def get_stats(self) -> Dict:
>         \"\"\"Get storage statistics.\"\"\"
>         stats = {tier.value: {'count': 0, 'size': 0} for tier in StorageTier}
>         
>         for ref in self.registry.values():
>             stats[ref.tier.value]['count'] += 1
>             stats[ref.tier.value]['size'] += ref.size_bytes
>         
>         return {
>             'total_files': len(self.registry),
>             'tiers': stats,
>             'base_path': str(self.base_path)
>         }
> ```
>
> ### Phase 2: Integration with SmartAgentSlack
>
> **File: `Synapse/core/axon.py`** - Add to existing class
>
> ```python
> # Add to SmartAgentSlack.__init__:
> from .file_storage import TieredFileStorage, FileReference
> 
> self.file_storage = TieredFileStorage(
>     base_path=config.get('storage_path', '/tmp/synapse_shared')
> )
> self.file_mode_threshold = config.get('file_mode_threshold', 1_000_000)  # 1MB
> 
> # Add to send_stream() after size detection (around line 355):
> # Check if file mode should be used
> use_file_mode = (
>     current_size > self.file_mode_threshold or
>     isinstance(data, bytes)
> )
> 
> if use_file_mode:
>     logger.info(f'  📁 [FILE MODE] Large data detected ({current_size} bytes)')
>     yield {'module': 'axon', 'message': f'Using file mode ({current_size} bytes)'}
>     
>     filename = (metadata or {}).get('filename', f'{field_name}.bin')
>     content_type = self._infer_content_type(data, metadata)
>     
>     # Convert to bytes if needed
>     if isinstance(data, (dict, list)):
>         data_bytes = json.dumps(data).encode('utf-8')
>         content_type = 'application/json'
>     elif isinstance(data, str):
>         data_bytes = data.encode('utf-8')
>         content_type = 'text/plain'
>     else:
>         data_bytes = data
>     
>     # Save to tiered storage
>     file_ref = self.file_storage.save(
>         data=data_bytes,
>         filename=filename,
>         content_type=content_type,
>         metadata=metadata
>     )
>     
>     # Replace data with file reference message
>     data = {
>         'type': 'file_reference',
>         'file_id': file_ref.file_id,
>         'filename': file_ref.original_filename,
>         'content_type': file_ref.content_type,
>         'size_bytes': file_ref.size_bytes,
>         'checksum': file_ref.checksum
>     }
>     current_format = 'file_reference'
>     current_size = len(json.dumps(data))
> ```
>
> ### Phase 3: Background Tier Transition
>
> **Integration point:** Call `run_tier_transition()` periodically.
>
> Option A: Manual call from Conductor after task completion
> Option B: Background thread with 1-hour interval
> Option C: Lazy transition on file access
>
> **Recommendation:** Option A for v1 (simplest), upgrade to B later.
>
> ---
>
> ## ⚠️ CRITICAL: Binary Files Must Skip LLM Chunker
>
> **User Requirement:** Audio (WAV, MP3), images (PNG, JPEG), and other binary files must NEVER be processed by `UnifiedChunker`.
>
> **Why:** `UnifiedChunker` uses token counting (`count_tokens_accurate`) which is designed for TEXT. Binary data would:
> - Produce meaningless token counts
> - Waste LLM calls on non-text data
> - Potentially corrupt binary data during "chunk and consolidate"
>
> **Implementation Guard (in send_stream):**
> ```python
> # STEP 4: Check if chunking needed (data too large for target)
> if current_size > target_caps.max_input_size:
>     # CRITICAL GUARD: Only chunk TEXT formats
>     if use_file_mode:
>         # Already using file mode - chunker is bypassed
>         pass
>     elif current_format in ('str', 'dict', 'list', 'json', 'text'):
>         # TEXT data - OK to chunk
>         logger.info(f"  🔧 [AUTO] Chunking text data...")
>         chunked_file = self.chunker.chunk_and_consolidate(...)
>     else:
>         # BINARY or unknown format - force file mode instead of chunking
>         logger.warning(f"  ⚠️ Cannot chunk binary format '{current_format}', using file mode")
>         use_file_mode = True
>         # ... save to file storage ...
> ```
>
> **Safeguard Locations:**
> 1. `send_stream()` - Check format before calling chunker
> 2. `_send_sync()` - Same guard for sync version
> 3. `_detect_format()` - Returns 'bytes' for binary data
>
> ---
>
> ## Addressing Team Concerns:
>
> | Concern | Solution |
> |---------|----------|
> | Turing: Path staleness | `file_id` based registry with `resolve_path()` |
> | Von Neumann: No quotas | Future enhancement (not blocking for v1) |
> | Silver: Rigid timing | Access tracking added, smart policies can layer on |
> | Chomsky: Incomplete MIME | Use magic numbers for now, add python-magic later |
>
> **Verdict:** Build this. It's practical, addresses the core problem, and leaves room for enhancement."

---

## 📊 Final Consensus

### Approved For Implementation:
✅ `FileReference` dataclass with `file_id` (not path-dependent)  
✅ `TieredFileStorage` with 4 tiers (hot/warm/cold/archive)  
✅ Access tracking (`last_accessed`, `access_count`)  
✅ Integration with `SmartAgentSlack.send_stream()`  
✅ Checksum verification for integrity  
✅ Transparent compression handling  

### Critical Safeguard (User Requirement):
⚠️ **LLM Chunker must NEVER process binary files (audio, images, video)**  
⚠️ `UnifiedChunker` is text/token-based only  
⚠️ Binary data → File mode → Skip chunker entirely  

**Implementation in `axon.py` send_stream():**
```python
# CRITICAL: Skip chunker for binary/file-mode data
if use_file_mode:
    # Binary files go directly to file storage
    # DO NOT call self.chunker for bytes/binary content
    pass
elif current_size > target_caps.max_input_size:
    # Only chunk TEXT data that's too large
    if current_format in ('str', 'dict', 'list', 'json'):
        # OK to chunk - it's text
        chunked = self.chunker.chunk_and_consolidate(...)
    else:
        # NOT OK - unknown format, use file mode instead
        logger.warning(f"Cannot chunk format '{current_format}', using file mode")
        use_file_mode = True
```

### Deferred to v2:
⏸️ Per-agent storage quotas  
⏸️ Access-pattern-based tier promotion (keep hot if frequently used)  
⏸️ `python-magic` library for robust MIME detection  
⏸️ Archive indexing for fast lookup  
⏸️ Background scheduler (use manual trigger for v1)  

### Implementation Estimate:
- **New code:** ~250 lines (`file_storage.py`)
- **Modifications:** ~50 lines (`axon.py`)
- **Tests:** ~100 lines
- **Risk:** LOW (additive, backward compatible)
- **Impact:** HIGH (enables WAV, image, large JSON transfer)

---

**Status:** APPROVED FOR IMPLEMENTATION  
**Next Step:** Create `Synapse/core/file_storage.py`  
**ADR:** `docs/adr/tiered-file-storage-inter-agent-transfer.md`
