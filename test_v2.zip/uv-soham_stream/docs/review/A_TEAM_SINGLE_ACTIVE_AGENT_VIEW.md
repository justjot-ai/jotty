# A-Team Review: Single Active Agent View (Auto-Switching)

**Date**: 2026-02-01  
**Topic**: Show ONLY the active agent in center panel - auto-switch based on which agent is yielding logs  
**Status**: Final Implementation Plan  

---

## Meeting Attendees

- **Alex (Senior Architect)** - System design
- **Jordan (Backend Engineer)** - Python/Agent integration
- **Casey (Frontend Engineer)** - Electron/UI specialist
- **Morgan (DevOps/Security)** - Operations

---

## Clarified Requirements

**User wants:**
> "Center: AGENT VIEWS... this needs to be on need basis... the agent that is yielding logs should only be visible... so if browser then only browser and if terminal then only terminal... whichever is active agent it should show only that tool"

**Translation:**
- ✅ Show ONLY ONE agent at a time
- ✅ Automatically switch to whichever agent is currently active
- ✅ If BrowserExecutor is working → show browser
- ✅ If TerminalExecutor is working → show terminal
- ✅ Seamless automatic switching

---

## Discussion

### Alex (Senior Architect) 🏗️

"Ah! This is actually SIMPLER than showing all agents. The user wants automatic view switching based on agent activity.

**Architecture:**

```
┌─────────────────────────────────────────────────────┐
│              Electron Frontend                       │
│  ┌──────────────────────────────────────────────┐  │
│  │      Single Agent View Container             │  │
│  │  (Shows only ONE agent at a time)            │  │
│  │                                               │  │
│  │  Current: BrowserExecutor                    │  │
│  │  ┌────────────────────────────────────────┐ │  │
│  │  │ [Chrome Browser View]                  │ │  │
│  │  │                                        │ │  │
│  │  └────────────────────────────────────────┘ │  │
│  │                                               │  │
│  │  Hidden: TerminalExecutor, WebSearch, etc.   │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
                         ▲
                         │ WebSocket
                         │ "agent_activated" event
                         │
┌─────────────────────────────────────────────────────┐
│              Python Backend                          │
│  ┌──────────────────────────────────────────────┐  │
│  │      AgentSessionManager                      │  │
│  │  • Tracks which agent is currently active     │  │
│  │  • Sends "agent_activated" when agent starts  │  │
│  │  • Sends "agent_deactivated" when done        │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

**Key Changes:**
1. **Backend:** Send `agent_activated` event when agent starts working
2. **Frontend:** Automatically switch view to active agent
3. **Only ONE view visible at a time**
4. **Smooth transitions between agents**

**This is MUCH simpler than the multi-view approach!**"

---

### Jordan (Backend Engineer) 🐍

"Perfect! This simplifies the backend too.

**Agent Activation Flow:**

```python
# When BrowserExecutor starts
async def on_browser_executor_start():
    manager = get_agent_session_manager()
    await manager.activate_agent(AgentType.BROWSER)
    # This sends "agent_activated" to Electron
    # Electron automatically switches to browser view

# When BrowserExecutor finishes
async def on_browser_executor_finish():
    manager = get_agent_session_manager()
    await manager.deactivate_agent(AgentType.BROWSER)

# When TerminalExecutor starts
async def on_terminal_executor_start():
    manager = get_agent_session_manager()
    await manager.activate_agent(AgentType.TERMINAL)
    # Electron automatically switches to terminal view
```

**Updated AgentSessionManager:**

```python
class AgentSessionManager:
    def __init__(self, websocket_manager):
        self.websocket_manager = websocket_manager
        self.active_agent = None  # Only ONE active agent
        self.agent_views = {}
    
    async def activate_agent(self, agent_type: AgentType):
        \"\"\"Activate an agent - makes it visible in Electron.\"\"\"
        
        # Deactivate previous agent if any
        if self.active_agent:
            await self.deactivate_agent(self.active_agent)
        
        # Activate new agent
        self.active_agent = agent_type
        
        # Notify Electron to switch view
        await self.websocket_manager.broadcast({
            "type": "agent_activated",
            "agent": agent_type.value,
            "timestamp": datetime.now().isoformat()
        })
        
        logger.info(f"✅ Agent activated: {agent_type.value}")
    
    async def deactivate_agent(self, agent_type: AgentType):
        \"\"\"Deactivate an agent - hides it in Electron.\"\"\"
        
        if self.active_agent == agent_type:
            self.active_agent = None
        
        await self.websocket_manager.broadcast({
            "type": "agent_deactivated",
            "agent": agent_type.value,
            "timestamp": datetime.now().isoformat()
        })
        
        logger.info(f"⏸️  Agent deactivated: {agent_type.value}")
    
    async def broadcast_agent_event(
        self,
        agent_type: AgentType,
        event_type: str,
        data: Dict[str, Any]
    ):
        \"\"\"Broadcast agent event (only if agent is active).\"\"\"
        
        # Auto-activate agent if it sends an event
        if self.active_agent != agent_type:
            await self.activate_agent(agent_type)
        
        # Broadcast event
        await self.websocket_manager.broadcast({
            "type": "agent_event",
            "agent": agent_type.value,
            "event_type": event_type,
            "data": data
        })
```

**Key Feature: AUTO-ACTIVATION**

When any agent sends an event, it automatically becomes the active agent! This means:
- BrowserExecutor navigates → Browser view appears
- TerminalExecutor outputs → Terminal view appears
- WebSearchAgent returns results → Search view appears

**No manual switching needed!**"

---

### Casey (Frontend Engineer) ⚛️

"This is SO much cleaner on the frontend!

**Single View Container:**

```javascript
class AgentViewManager {
    constructor() {
        this.views = new Map();
        this.activeAgentName = null;
        this.container = document.getElementById('center-workspace');
        this.initializeViews();
    }
    
    initializeViews() {
        // Create all views but hide them
        this.createView('BrowserExecutor', 'browser');
        this.createView('TerminalExecutor', 'terminal');
        this.createView('WebSearchAgent', 'search');
        this.createView('PlannerAgent', 'planner');
        
        // All hidden by default
        this.hideAllViews();
    }
    
    createView(agentName, type) {
        const view = document.createElement('div');
        view.className = `agent-view agent-view-${type}`;
        view.id = `agent-view-${agentName}`;
        view.style.display = 'none';  // Hidden by default
        
        // Create header
        const header = this.createHeader(agentName, type);
        
        // Create content container
        const content = document.createElement('div');
        content.className = 'agent-view-content';
        content.id = `agent-content-${agentName}`;
        
        view.appendChild(header);
        view.appendChild(content);
        this.container.appendChild(view);
        
        // Store reference
        this.views.set(agentName, {
            element: view,
            type: type,
            handler: this.createHandler(type, content)
        });
    }
    
    /**
     * Switch to active agent (called when agent_activated event received)
     */
    switchToAgent(agentName) {
        // Hide all views
        this.hideAllViews();
        
        // Show active agent view
        const agentView = this.views.get(agentName);
        if (agentView) {
            agentView.element.style.display = 'flex';
            this.activeAgentName = agentName;
            
            // Smooth fade-in animation
            agentView.element.style.opacity = '0';
            setTimeout(() => {
                agentView.element.style.opacity = '1';
            }, 50);
            
            // Initialize view if needed (e.g., xterm.js, BrowserView)
            agentView.handler.initialize();
            
            logger.info(`Switched to agent: ${agentName}`);
        }
    }
    
    hideAllViews() {
        this.views.forEach(view => {
            view.element.style.display = 'none';
        });
    }
    
    /**
     * Handle agent activation from backend
     */
    handleAgentActivated(event) {
        const { agent } = event;
        this.switchToAgent(agent);
    }
    
    /**
     * Handle agent event (only if agent is active)
     */
    handleAgentEvent(event) {
        const { agent, event_type, data } = event;
        
        // Only process if this is the active agent
        if (this.activeAgentName !== agent) {
            // Auto-switch to this agent
            this.switchToAgent(agent);
        }
        
        // Delegate to handler
        const agentView = this.views.get(agent);
        if (agentView) {
            agentView.handler.handleEvent(event_type, data);
        }
    }
}
```

**WebSocket Event Handlers:**

```javascript
// In app.js
const agentViewManager = new AgentViewManager();

// Agent activated - switch view
socket.on('agent_activated', (event) => {
    agentViewManager.handleAgentActivated(event);
    
    // Update active indicator in right sidebar
    updateActiveAgentIndicator(event.agent);
});

// Agent deactivated
socket.on('agent_deactivated', (event) => {
    // Could show a "waiting" state or keep last view
    console.log(`Agent deactivated: ${event.agent}`);
});

// Agent event - auto-switch if needed
socket.on('agent_event', (event) => {
    agentViewManager.handleAgentEvent(event);
});

function updateActiveAgentIndicator(agentName) {
    // Update right sidebar to show which agent is active
    document.querySelectorAll('.agent-status-row').forEach(row => {
        row.classList.remove('active');
    });
    
    const activeRow = document.querySelector(`[data-agent="${agentName.toLowerCase()}"]`);
    if (activeRow) {
        activeRow.classList.add('active');
    }
}
```

**CSS for Smooth Transitions:**

```css
.agent-view {
    display: none;
    flex-direction: column;
    width: 100%;
    height: 100%;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
}

.agent-view[style*="display: flex"] {
    opacity: 1;
}

/* Ensure only one view visible */
.center-workspace {
    position: relative;
    overflow: hidden;
}

.agent-view {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}
```

**Benefits:**
- ✅ Only ONE view visible at a time
- ✅ Automatic switching based on agent activity
- ✅ Smooth transitions
- ✅ Clean, simple UI
- ✅ No clutter"

---

### Morgan (DevOps/Security) 🔒

"This is much better from an operational standpoint!

**Benefits:**
- ✅ Lower resource usage (only one view active)
- ✅ Simpler state management
- ✅ Easier debugging (one active agent at a time)
- ✅ Clear user experience (no confusion about which agent is working)

**Monitoring:**
- Easy to track active agent
- Clear logs of agent switches
- Simple metrics (time per agent)

**Security:**
- Same as before (all views read-only)
- No additional risks

This is the right approach!"

---

## Team Consensus

### ✅ **Single Active Agent View with Auto-Switching**

---

## Implementation Plan

### **Phase 1: Core Infrastructure** (3-4 hours)

#### **Backend: Agent Activation System**

**File: `surface_synapse/agent_session_manager.py`**

```python
from typing import Optional
from enum import Enum
from datetime import datetime

class AgentType(Enum):
    BROWSER = "BrowserExecutor"
    TERMINAL = "TerminalExecutor"
    WEBSEARCH = "WebSearchAgent"
    PLANNER = "PlannerAgent"

class AgentSessionManager:
    """Manages single active agent view."""
    
    def __init__(self, websocket_manager):
        self.websocket_manager = websocket_manager
        self.active_agent: Optional[AgentType] = None
    
    async def activate_agent(self, agent_type: AgentType):
        """Activate agent - makes it visible in Electron."""
        
        # Deactivate previous if different
        if self.active_agent and self.active_agent != agent_type:
            await self.deactivate_agent(self.active_agent)
        
        self.active_agent = agent_type
        
        # Notify Electron
        await self.websocket_manager.broadcast({
            "type": "agent_activated",
            "agent": agent_type.value,
            "timestamp": datetime.now().isoformat()
        })
    
    async def deactivate_agent(self, agent_type: AgentType):
        """Deactivate agent."""
        if self.active_agent == agent_type:
            self.active_agent = None
        
        await self.websocket_manager.broadcast({
            "type": "agent_deactivated",
            "agent": agent_type.value,
            "timestamp": datetime.now().isoformat()
        })
    
    async def broadcast_agent_event(
        self,
        agent_type: AgentType,
        event_type: str,
        data: dict
    ):
        """Broadcast event and auto-activate agent."""
        
        # Auto-activate if not already active
        if self.active_agent != agent_type:
            await self.activate_agent(agent_type)
        
        # Broadcast event
        await self.websocket_manager.broadcast({
            "type": "agent_event",
            "agent": agent_type.value,
            "event_type": event_type,
            "data": data
        })
    
    def get_active_agent(self) -> Optional[AgentType]:
        """Get currently active agent."""
        return self.active_agent
```

**File: `surface_synapse/server.py`**

```python
from surface_synapse.agent_session_manager import (
    AgentSessionManager,
    initialize_agent_session_manager
)

# Initialize manager
agent_session_manager = initialize_agent_session_manager(websocket_manager)
```

---

#### **Frontend: Single View Manager**

**File: `electron-app/src/renderer/js/agent-view-manager.js`**

```javascript
class AgentViewManager {
    constructor() {
        this.views = new Map();
        this.activeAgentName = null;
        this.container = document.getElementById('center-workspace');
    }
    
    initialize() {
        // Create all views (hidden by default)
        this.createView('BrowserExecutor', 'browser', BrowserViewHandler);
        this.createView('TerminalExecutor', 'terminal', TerminalViewHandler);
        this.createView('WebSearchAgent', 'search', SearchViewHandler);
        this.createView('PlannerAgent', 'planner', PlannerViewHandler);
    }
    
    createView(agentName, type, HandlerClass) {
        const view = document.createElement('div');
        view.className = `agent-view agent-view-${type}`;
        view.id = `agent-view-${agentName}`;
        view.style.display = 'none';
        
        // Header
        view.innerHTML = `
            <div class="agent-view-header">
                <span class="agent-view-icon">${this.getIcon(type)}</span>
                <span class="agent-view-name">${agentName}</span>
                <span class="agent-view-status">Active</span>
            </div>
            <div class="agent-view-content" id="agent-content-${agentName}"></div>
        `;
        
        this.container.appendChild(view);
        
        // Create handler
        const contentEl = document.getElementById(`agent-content-${agentName}`);
        const handler = new HandlerClass(contentEl);
        
        this.views.set(agentName, {
            element: view,
            type: type,
            handler: handler
        });
    }
    
    switchToAgent(agentName) {
        // Hide all
        this.views.forEach(view => {
            view.element.style.display = 'none';
        });
        
        // Show active
        const agentView = this.views.get(agentName);
        if (agentView) {
            agentView.element.style.display = 'flex';
            this.activeAgentName = agentName;
            
            // Initialize if needed
            agentView.handler.initialize();
        }
    }
    
    handleAgentActivated(event) {
        this.switchToAgent(event.agent);
    }
    
    handleAgentEvent(event) {
        const agentView = this.views.get(event.agent);
        if (agentView) {
            agentView.handler.handleEvent(event.event_type, event.data);
        }
    }
    
    getIcon(type) {
        const icons = {
            browser: '🌐',
            terminal: '⚡',
            search: '🔍',
            planner: '🧠'
        };
        return icons[type] || '📋';
    }
}

export default AgentViewManager;
```

---

### **Phase 2: Agent Integrations** (5-6 hours)

#### **BrowserExecutor Integration**

**Backend:**
```python
# In browser_tools.py
async def navigate_to_url(url: str):
    manager = get_agent_session_manager()
    
    # This auto-activates BrowserExecutor view
    await manager.broadcast_agent_event(
        AgentType.BROWSER,
        "navigate",
        {"url": url, "title": _browser_driver.title}
    )
```

**Frontend:**
```javascript
class BrowserViewHandler {
    constructor(container) {
        this.container = container;
        this.initialized = false;
    }
    
    initialize() {
        if (!this.initialized) {
            // Request Electron to show BrowserView
            window.browserAPI.setVisible(true);
            this.initialized = true;
        }
    }
    
    handleEvent(eventType, data) {
        if (eventType === 'navigate') {
            window.browserAPI.navigate(data.url);
        }
    }
}
```

---

#### **TerminalExecutor Integration**

**Backend:**
```python
# In terminal_tools.py
async def stream_terminal_output():
    while _terminal_streaming_active:
        chunk = _terminal_session.read_nonblocking(size=256, timeout=0.01)
        
        if chunk:
            manager = get_agent_session_manager()
            # This auto-activates TerminalExecutor view
            await manager.broadcast_agent_event(
                AgentType.TERMINAL,
                "output",
                {"output": chunk}
            )
```

**Frontend:**
```javascript
class TerminalViewHandler {
    constructor(container) {
        this.container = container;
        this.terminal = null;
    }
    
    initialize() {
        if (!this.terminal) {
            this.terminal = new Terminal({ /* config */ });
            this.terminal.open(this.container);
        }
    }
    
    handleEvent(eventType, data) {
        if (eventType === 'output') {
            this.terminal.write(data.output);
        }
    }
}
```

---

### **Phase 3: Polish** (1-2 hours)

- Smooth transitions
- Loading states
- Error handling
- Testing

---

## WebSocket Events

### **Agent Activation**
```json
{
  "type": "agent_activated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-01T10:30:00Z"
}
```

### **Agent Event (auto-activates if needed)**
```json
{
  "type": "agent_event",
  "agent": "TerminalExecutor",
  "event_type": "output",
  "data": { "output": "test passed\n" }
}
```

### **Agent Deactivation**
```json
{
  "type": "agent_deactivated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-01T10:35:00Z"
}
```

---

## User Experience Flow

### **Scenario: Multi-Agent Task**

1. **User:** "Search for Python tutorials and open the first result"

2. **WebSearchAgent activates:**
   - Backend: `activate_agent(AgentType.WEBSEARCH)`
   - Frontend: Switches to search view
   - User sees: Search results panel

3. **BrowserExecutor activates:**
   - Backend: `activate_agent(AgentType.BROWSER)`
   - Frontend: Automatically switches to browser view
   - User sees: Chrome browser opening first result

4. **TerminalExecutor activates:**
   - Backend: `activate_agent(AgentType.TERMINAL)`
   - Frontend: Automatically switches to terminal view
   - User sees: Terminal running commands

**Seamless automatic switching!**

---

## Benefits

### **Simplified Architecture**
- ✅ Only ONE view active at a time
- ✅ Automatic switching (no manual control needed)
- ✅ Lower resource usage
- ✅ Cleaner code

### **Better UX**
- ✅ Clear focus on active agent
- ✅ No clutter
- ✅ Smooth transitions
- ✅ Easy to understand

### **Easier Implementation**
- ✅ Simpler than multi-view
- ✅ Less state management
- ✅ Easier debugging
- ✅ Faster to build

---

## Timeline

| Phase | Component | Effort |
|-------|-----------|--------|
| **Phase 1** | Agent activation system | 3-4 hours |
| **Phase 2** | Agent integrations | 5-6 hours |
| **Phase 3** | Polish & testing | 1-2 hours |
| **Total** | | **9-12 hours** |

**3 hours faster than multi-view approach!**

---

## Success Criteria

- ✅ Only ONE agent visible at a time
- ✅ Automatic switching when agent becomes active
- ✅ Smooth transitions between agents
- ✅ Clear indicator of active agent
- ✅ All agent types supported
- ✅ Implementation complete in < 12 hours

---

## Conclusion

**Single active agent view with automatic switching is:**
- ✅ **Simpler** than multi-view
- ✅ **Cleaner** UX (no clutter)
- ✅ **Faster** to implement (9-12 hours vs 12-15 hours)
- ✅ **More intuitive** (focus on what's happening now)
- ✅ **Exactly what user wants!**

**This is the RIGHT approach!** 🎯

---

**Meeting Adjourned** 🏁

*Alex: "Single view with auto-switching is elegant and simple!"*  
*Jordan: "Auto-activation on event broadcast is genius - no manual switching!"*  
*Casey: "Much cleaner frontend - just show/hide views!"*  
*Morgan: "Lower resource usage, easier to monitor. Perfect!"*  
*All: "This is the way! 🚀"*
