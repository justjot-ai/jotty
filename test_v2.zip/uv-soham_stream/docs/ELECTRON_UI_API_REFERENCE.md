# Electron UI API Reference

Quick reference for testing what the Electron UI should be displaying.

## Prerequisites

- Server running: `poetry run python surface_synapse/server.py`
- Server URL: `http://127.0.0.1:8765`

## REST APIs

### 1. Get Tasks/Artifacts
**Endpoint:** `GET /api/artifacts/{session_id}`

**Example:**
```bash
curl -s "http://127.0.0.1:8765/api/artifacts/1769857656693" | python3 -m json.tool
```

**Response:**
```json
{
  "q_tables": [...],
  "todos": [
    {
      "filename": "log_extracted_todos",
      "path": "/path/to/log",
      "content": {
        "tasks": [
          {
            "id": "task_1",
            "actor": "TerminalExecutor",
            "description": "Extract and return the date from environment",
            "status": "in_progress"
          }
        ]
      }
    }
  ],
  "env_files": [...],
  "session_id": "1769857656693"
}
```

### 2. Quick Task Status
```bash
curl -s "http://127.0.0.1:8765/api/artifacts/{session_id}" | \
  python3 -c "import json, sys; \
  d=json.load(sys.stdin); \
  [print(f'{t[\"id\"]}: {t[\"description\"]} - {t[\"status\"]}') \
  for t in d['todos'][0]['content']['tasks']]"
```

### 3. Get Active Agents
**Endpoint:** `GET /api/agents/{session_id}`

```bash
curl -s "http://127.0.0.1:8765/api/agents/1769857656693" | python3 -m json.tool
```

**Response:**
```json
{
  "agents": [
    "BrowserExecutor",
    "TerminalExecutor", 
    "WebSearchAgent"
  ],
  "session_id": "1769857656693"
}
```

### 4. Health Check
```bash
curl -s "http://127.0.0.1:8765/"
```

**Response:**
```json
{
  "status": "online",
  "service": "UV Assistant API",
  "version": "1.0.0",
  "synapse_available": true
}
```

## WebSocket APIs

### 1. Log Streaming
**Endpoint:** `WS /ws/logs/{session_id}`

**Python Test:**
```python
import asyncio
import websockets
import json

async def stream_logs(session_id):
    uri = f"ws://127.0.0.1:8765/ws/logs/{session_id}"
    async with websockets.connect(uri) as websocket:
        print("✅ Connected to log stream")
        
        while True:
            message = await websocket.recv()
            data = json.loads(message)
            
            if data['type'] == 'log_line':
                print(data['content'])
            elif data['type'] == 'error':
                print(f"Error: {data['message']}")
                break

asyncio.run(stream_logs("1769857656693"))
```

**Message Format:**
```json
{
  "type": "log_line",
  "content": "2026-01-31 16:38:22,532 - INFO - Starting task...",
  "timestamp": "2026-01-31T16:44:10.123456"
}
```

## Common Session IDs

Session IDs are timestamps in milliseconds. To find recent sessions:

```bash
ls -t /Users/anshulchauhan/Tech/term/logs/electron_tasks/ | head -5
```

Example session ID: `task_1769857656693_2026-01-31_16-38-22.log`
Extract ID: `1769857656693`

## Troubleshooting

### No tasks showing?
```bash
# Check if session exists
ls /Users/anshulchauhan/Tech/term/logs/electron_tasks/task_{session_id}*.log

# Check what the API returns
curl -s "http://127.0.0.1:8765/api/artifacts/{session_id}" | \
  python3 -c "import json, sys; d=json.load(sys.stdin); print(f'Todos: {len(d[\"todos\"])}')"
```

### WebSocket not connecting?
```bash
# Check server is running
lsof -i :8765

# Check server logs
tail -f /Users/anshulchauhan/Tech/term/logs/backend.log
```

### Server not responding?
```bash
# Restart server
pkill -f surface_synapse/server.py
cd /Users/anshulchauhan/Tech/term
poetry run python surface_synapse/server.py > logs/backend.log 2>&1 &
```

## Electron App Integration

The Electron app uses these APIs:
- **Tasks Panel:** Polls `/api/artifacts/{session_id}` every few seconds
- **Log Stream:** Connects to `/ws/logs/{session_id}` on session start
- **Agent Terminals:** Fetches from `/api/agents/{session_id}`

To debug the Electron app:
1. Open DevTools (Cmd+Option+I on Mac)
2. Check Console for WebSocket/API errors
3. Check Network tab for failed API calls
