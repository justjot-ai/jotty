# Agent Session Embedding - Testing Guide

**Date:** 2026-02-01  
**Status:** Ready for Testing  

---

## Implementation Complete! ✅

All core features have been implemented:
- ✅ AgentSessionManager (backend)
- ✅ AgentViewManager (frontend)
- ✅ BrowserView integration
- ✅ xterm.js integration
- ✅ Auto-switching logic
- ✅ WebSocket protocol

---

## Quick Start

### Start Backend
```bash
cd /Users/anshulchauhan/Tech/term
./scripts/run_server.sh
```

### Start Electron
```bash
cd /Users/anshulchauhan/Tech/term/electron-app
npm start
```

---

## Test Scenarios

### Test 1: Browser Agent Activation

**Task:** "Open Google and search for Python tutorials"

**Expected:**
1. ✅ Center panel shows BrowserExecutor view
2. ✅ Real Chrome browser embedded in center
3. ✅ Browser navigates to Google
4. ✅ Right sidebar: Browser indicator active (●)
5. ✅ Smooth fade-in transition

**Console logs to verify:**
```
✅ WebSocket connected
Agent activated: BrowserExecutor
Switching to agent: BrowserExecutor
✅ BrowserView shown
Browser navigating to: https://google.com
```

---

### Test 2: Terminal Agent Activation

**Task:** "List all files in the current directory"

**Expected:**
1. ✅ Center panel switches to TerminalExecutor view
2. ✅ xterm.js terminal appears
3. ✅ Command shown: `$ ls -la`
4. ✅ Terminal output displayed with colors
5. ✅ Right sidebar: Terminal indicator active (●)

**Console logs to verify:**
```
Agent activated: TerminalExecutor
Switching to agent: TerminalExecutor
✅ Terminal initialized
Terminal event: command { command: "ls -la" }
Terminal event: output { output: "..." }
```

---

### Test 3: Auto-Switching Between Agents

**Task:** "Search Google for Python, then list files, then go back to Google"

**Expected:**
1. ✅ Browser view appears (Google search)
2. ✅ Auto-switches to terminal view (list files)
3. ✅ Auto-switches back to browser view (Google)
4. ✅ Smooth transitions between views
5. ✅ Right sidebar indicator updates each time

**Verify:**
- Only ONE view visible at any time
- Previous view is hidden when new agent activates
- No flickering or layout issues

---

### Test 4: Window Resizing

**Actions:**
1. Resize window
2. Maximize window
3. Enter/exit fullscreen
4. Minimize and restore

**Expected:**
- ✅ BrowserView repositions correctly
- ✅ Terminal resizes correctly
- ✅ No layout breaks
- ✅ Views remain in center panel

---

### Test 5: Multiple Tasks in Sequence

**Tasks:**
1. "Open GitHub"
2. "List files"
3. "Search for React tutorials"
4. "Run npm test"

**Expected:**
- ✅ Browser → Terminal → Browser → Terminal
- ✅ Each switch is smooth
- ✅ No memory leaks
- ✅ All views work correctly

---

## Verification Checklist

### Backend
- [ ] AgentSessionManager initialized
- [ ] WebSocket broadcast() method working
- [ ] browser_tools.py sending events
- [ ] terminal_tools.py sending events
- [ ] No Python errors in logs

### Frontend
- [ ] WebSocket connection established
- [ ] AgentViewManager initialized
- [ ] BrowserView created
- [ ] xterm.js loaded from CDN
- [ ] All handler classes working
- [ ] No JavaScript errors in console

### Integration
- [ ] agent_activated events received
- [ ] agent_event events received
- [ ] View switching working
- [ ] BrowserView navigation working
- [ ] Terminal output displaying
- [ ] Right sidebar indicator updating

### UI/UX
- [ ] Only one view visible at a time
- [ ] Smooth transitions (no flickering)
- [ ] Proper positioning in center panel
- [ ] Responsive to window resize
- [ ] Professional appearance
- [ ] No layout issues

---

## Known Issues & Workarounds

### Issue 1: xterm.js not loading
**Symptom:** Terminal view shows placeholder, no terminal
**Workaround:** Check internet connection (CDN), or install locally
**Fix:** `cd electron-app && npm install`

### Issue 2: BrowserView not visible
**Symptom:** Center panel empty when browser agent active
**Workaround:** Check console for errors, verify `browserAPI.setVisible(true)` called
**Fix:** Ensure BrowserView bounds are set correctly

### Issue 3: WebSocket reconnection
**Symptom:** Agent events stop after backend restart
**Workaround:** Refresh Electron app (Cmd+R)
**Fix:** Auto-reconnection already implemented (3s delay)

---

## Performance Monitoring

### Memory Usage
```bash
# Check Electron memory
Activity Monitor → UV → Memory

Expected: ~500-600MB
```

### CPU Usage
```bash
# Check CPU during agent activity
Activity Monitor → UV → CPU

Expected: 5-10% idle, 10-15% active
```

### Network
```bash
# Check WebSocket traffic
Developer Tools → Network → WS

Expected: Small JSON messages (<1KB each)
```

---

## Debug Mode

### Enable DevTools
```bash
cd electron-app
npm run dev
```

### Check Logs
- **Electron Console:** F12 in app
- **Backend Logs:** Terminal running server
- **Main Process:** Terminal running Electron

### Useful Console Commands
```javascript
// Check AgentViewManager
app.agentViewManager

// Check active agent
app.agentViewManager.getActiveAgent()

// Check WebSocket
app.websocket.readyState  // 1 = OPEN

// Check views
app.agentViewManager.views
```

---

## Next Steps

### If Tests Pass
1. ✅ Mark implementation complete
2. Install xterm.js locally (remove CDN)
3. Add WebSearchAgent integration
4. Add PlannerAgent integration
5. Polish UI/UX
6. Write user documentation
7. Deploy!

### If Tests Fail
1. Review console logs
2. Check WebSocket connection
3. Verify file paths
4. Review implementation ADR
5. Fix issues
6. Re-test

---

## Support

**Documentation:**
- Quick Start: `docs/AGENT_EMBEDDING_QUICK_START.md`
- Implementation: `docs/adr/agent-session-embedding-implementation.md`
- Architecture: `docs/review/A_TEAM_SINGLE_ACTIVE_AGENT_VIEW.md`

**Troubleshooting:**
- Check all console logs (Electron + Backend)
- Verify WebSocket connection
- Review ADR documents
- Check file modifications

---

## Summary

**What was built:**
- Unified agent session embedding system
- Single active agent view with auto-switching
- BrowserView for real Chrome embedding
- xterm.js for real terminal embedding
- WebSocket protocol for real-time updates

**Ready to test!** 🚀

Follow the test scenarios above and verify all checkboxes. Report any issues found.
