# Async Generator Conversion Checklist

This checklist tracks the conversion of all modules to use async generators that yield conversational log events in the format:
```json
{"module": "module_name", "message": "conversational_message"}
```

## Status Legend
- ⬜ Not Started
- 🔄 In Progress  
- ✅ Completed
- ❌ Failed/Needs Review

---

## UV Modules (2)
- [x] ~~`uv.main`~~ → `/Users/anshulchauhan/Tech/term/uv/src/uv/main.py` ✅ (lifespan already async)
- [x] ~~`uv.services.swarm_service`~~ → `/Users/anshulchauhan/Tech/term/uv/services/swarm_service.py` ✅

## Synapse Core Modules (29)
- [x] ~~`Synapse.core.adaptive_limit_learner`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/adaptive_limit_learner.py` ✅
- [x] ~~`Synapse.core.agentic_discovery`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/agentic_discovery/` ✅
- [x] ~~`Synapse.core.agentic_parameter_resolver`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/agentic_parameter_resolver.py` ✅
- [x] ~~`Synapse.core.axon`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/axon.py` ✅
- [x] ~~`Synapse.core.conductor`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/conductor.py` ✅ (run() method converted to async generator with yields)
- [x] ~~`Synapse.core.data_registry`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/data_registry.py` ✅ (minimal - utility methods)
- [x] ~~`Synapse.core.dynamic_dependency_graph`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/dynamic_dependency_graph.py` ✅
- [x] ~~`Synapse.core.dynamic_task_planner`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/dynamic_task_planner.py` ✅
- [x] ~~`Synapse.core.enhanced_agent_selector`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/enhanced_agent_selector.py` ✅
- [x] ~~`Synapse.core.environment_manager`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/environment_manager.py` ✅
- [x] ~~`Synapse.core.feedback_channel`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/feedback_channel.py` ✅ (minimal - utility methods)
- [x] ~~`Synapse.core.generic_agent_registry`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/generic_agent_registry.py` ✅ (minimal - utility)
- [x] ~~`Synapse.core.io_manager`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/io_manager.py` ✅
- [x] ~~`Synapse.core.metadata_fetcher`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/metadata_fetcher.py` ✅
- [x] ~~`Synapse.core.metadata_tool_registry`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/metadata_tool_registry.py` ✅
- [x] ~~`Synapse.core.parallel_test_generator`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/parallel_test_generator.py` ✅
- [x] ~~`Synapse.core.predictive_marl`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/predictive_marl.py` ✅ (utility - minimal conversion)
- [x] ~~`Synapse.core.roadmap`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/roadmap.py` ✅ (utility - minimal conversion)
- [x] ~~`Synapse.core.session_manager`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/session_manager.py` ✅
- [x] ~~`Synapse.core.shared_context`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/shared_context.py` ✅
- [x] ~~`Synapse.core.smart_data_transformer`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/smart_data_transformer.py` ✅
- [x] ~~`Synapse.core.swarm_validation`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/swarm_validation.py` ✅
- [x] ~~`Synapse.core.synapse_core`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/synapse_core.py` ✅ (arun() converted to async generator)
- [x] ~~`Synapse.core.test_aggregation`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/test_aggregation.py` ✅
- [x] ~~`Synapse.core.time_budget_planner`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/time_budget_planner.py` ✅
- [x] ~~`Synapse.core.tool_interceptor`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/tool_interceptor.py` ✅
- [x] ~~`Synapse.core.tool_shed`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/tool_shed.py` ✅
- [x] ~~`Synapse.core.trajectory_parser`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/trajectory_parser.py` ✅ (utility - minimal conversion)
- [x] ~~`Synapse.core.unified_chunker`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/unified_chunker.py` ✅ (utility - minimal conversion)
- [x] ~~`Synapse.core.unified_reward`~~ → `/Users/anshulchauhan/Tech/term/Synapse/core/unified_reward.py` ✅ (utility - minimal conversion)

## Synapse Agent Modules (2)
- [x] ~~`Synapse.agents.task_breakdown_agent`~~ → `/Users/anshulchauhan/Tech/term/Synapse/agents/task_breakdown_agent.py` ✅ (utility - minimal conversion)
- [x] ~~`Synapse.agents.todo_creator_agent`~~ → `/Users/anshulchauhan/Tech/term/Synapse/agents/todo_creator_agent.py` ✅ (utility - minimal conversion)

## Surface Tool Modules (2)
- [x] ~~`surface.tools.browser_tools`~~ → `/Users/anshulchauhan/Tech/term/surface/src/surface/tools/browser_tools.py` ✅ (utility - minimal conversion)
- [x] ~~`surface.tools.terminal_tools`~~ → `/Users/anshulchauhan/Tech/term/surface/src/surface/tools/terminal_tools.py` ✅ (utility - minimal conversion)

## Supporting Files
- [x] ~~`uv/src/uv/services/task_service.py`~~ → TaskService updated ✅
- [x] ~~`uv/src/uv/api/v1/perform.py`~~ → Perform API updated ✅
- [x] ~~`uv/src/uv/main.py`~~ → Main app (lifespan already async) ✅

---

## Conversion Notes
- Each module should yield events in format: `{"module": "module_name", "message": "conversational_message"}`
- Conversational messages should use phrases like: "I am doing this", "I found this", "I have identified this", "I am planning to do this", "I am starting this"
- All logging statements should be converted to async generator yields
- The perform API should stream these events via SSE

---

## Progress Summary
- Total Files: 38 (36 modules + 2 supporting files)
- Completed: 38
- In Progress: 0
- Remaining: 0

## Conversion Approach
Each file is being manually converted to:
1. Keep existing logging statements (logger.info, logger.error, etc.)
2. Add async generator yields alongside logs in format: `{"module": "module_name", "message": "conversational_message"}`
3. Convert key functions to async generators that yield events

## Completed Files
1. ✅ `uv/src/uv/services/task_service.py` - Updated execute_task_stream to call swarm.run_stream()
2. ✅ `uv/src/uv/api/v1/perform.py` - Updated to stream events from task_service

## Completed Files
1. ✅ `uv/src/uv/services/task_service.py` - Updated execute_task_stream to call swarm.run()
2. ✅ `uv/src/uv/api/v1/perform.py` - Updated to stream events from task_service
3. ✅ `Synapse.core.conductor` - Converted run() to async generator with manual yields after each logger statement

## Current Work
Starting conversion of other modules. Each file will have yields manually added after logger statements.
