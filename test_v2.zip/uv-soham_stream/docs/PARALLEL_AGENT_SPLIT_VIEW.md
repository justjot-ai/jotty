# Parallel Agent Split View Implementation

**Date:** 2026-02-02  
**Status:** ✅ Implemented

## Overview

Updated the Electron UI to support displaying multiple agents simultaneously in a split-screen layout during parallel execution. Previously, only one agent could be visible at a time, and the UI would switch between agents. Now, when multiple agents are active in parallel (e.g., BrowserExecutor and TerminalExecutor), they are displayed side-by-side.

## Changes Made

### 1. AgentViewManager (`agent-view-manager.js`)

**Key Changes:**
- Changed from single `activeAgentName` to `activeAgents` Set to track multiple active agents
- Replaced `switchToAgent()` with `activateAgent()` - additive instead of exclusive
- Added `deactivateAgent()` to remove specific agents from view
- Implemented `updateContainerLayout()` to dynamically adjust grid based on active agent count
- Maintained backward compatibility with `switchToAgent()` for legacy code

**Layout Logic:**
- **1 agent active:** Full-screen view (`.split-view-1`)
- **2 agents active:** 50/50 vertical split - top/bottom (`.split-view-2`)
- **3 agents active:** 2x2 grid with one empty (`.split-view-3`)
- **4 agents active:** 2x2 grid (`.split-view-4`)

### 2. CSS Styles (`styles.css`)

**Grid Layout:**
```css
/* Single agent - full screen */
.agents-grid-workspace.split-view-1 {
  grid-template-columns: 1fr;
  grid-template-rows: 1fr;
}

/* Two agents - vertical split (50/50 top-down) */
.agents-grid-workspace.split-view-2 {
  grid-template-columns: 1fr;
  grid-template-rows: 1fr 1fr;
}

/* Three agents - 2x2 grid with one empty */
.agents-grid-workspace.split-view-3 {
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
}

/* Four agents - 2x2 grid */
.agents-grid-workspace.split-view-4 {
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
}
```

**Transitions:**
- Smooth opacity and scale transitions when agents activate/deactivate
- 300ms cubic-bezier easing for professional feel

### 3. Agent View Styles (`agent-views.css`)

**Responsive Sizing:**
- Added `min-height: 0` and `min-width: 0` to prevent overflow in split views
- Ensured browser canvas scales properly in split layouts
- Added overflow handling for proper content containment

### 4. Resize Handling

**Terminal View:**
- Added `ResizeObserver` to detect container size changes
- Automatically refits terminal when layout changes (split-view transitions)
- Cleanup on agent deactivation

**Browser View:**
- Added `ResizeObserver` to detect canvas container size changes
- Stores last screenshot data for redrawing at new size
- Automatically redraws screenshot when layout changes
- Maintains aspect ratio in all split configurations

## Usage

### Backend Integration

Agents should emit activation/deactivation events:

```python
# Activate agent (shows in UI)
await broadcast_agent_event({
    "type": "agent_activated",
    "agent": "BrowserExecutor"
})

# Deactivate agent (hides from UI)
await broadcast_agent_event({
    "type": "agent_deactivated",
    "agent": "BrowserExecutor"
})
```

### Automatic Behavior

- When a single agent is active, it displays full-screen
- When a second agent activates, the UI automatically splits 50/50
- When agents deactivate, the layout automatically adjusts
- If all agents deactivate, the UI returns to empty state

## Examples

### Parallel Browser + Terminal

```
┌─────────────────────────────────────┐
│         BrowserExecutor              │
│         [Chrome View]                │
├─────────────────────────────────────┤
│        TerminalExecutor              │
│        [Terminal View]               │
└─────────────────────────────────────┘
```

### Three Agents Active

```
┌─────────────────────────────────────┐
│  BrowserExecutor  │ TerminalExecutor│
│                   │                  │
├─────────────────────────────────────┤
│  WebSearchAgent   │     (empty)      │
│                   │                  │
└─────────────────────────────────────┘
```

### Four Agents Active

```
┌─────────────────────────────────────┐
│  BrowserExecutor  │ TerminalExecutor│
│                   │                  │
├─────────────────────────────────────┤
│  WebSearchAgent   │  PlannerAgent    │
│                   │                  │
└─────────────────────────────────────┘
```

## Performance Considerations

- **Browser Screenshots:** Continue at 2 FPS (500ms interval) to minimize overhead
- **Terminal:** xterm.js handles rendering efficiently
- **Layout Transitions:** Hardware-accelerated CSS transforms for smooth animations
- **Resize Handling:** Debounced via ResizeObserver for optimal performance

## Testing

To test the split-view functionality:

1. Start the Electron app
2. Execute a task that uses multiple agents in parallel
3. Verify that both agents appear side-by-side
4. Check that each agent view is properly sized and functional
5. Verify smooth transitions when agents activate/deactivate
6. Test resize behavior by changing window size

## Future Enhancements

Potential improvements:
- User-configurable layout preferences (vertical vs horizontal split)
- Drag-to-resize split dividers
- Agent view maximization/minimization
- Picture-in-picture mode for browser view
- Custom grid layouts for specific agent combinations

## Related Files

- `/electron-app/src/renderer/js/agent-view-manager.js` - Core logic
- `/electron-app/src/renderer/css/styles.css` - Grid layout styles
- `/electron-app/src/renderer/css/agent-views.css` - Agent-specific styles
- `/docs/adr/parallel-agent-split-view.md` - Architecture decision record
