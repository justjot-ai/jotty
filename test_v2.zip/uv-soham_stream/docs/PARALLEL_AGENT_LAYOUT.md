# Parallel Agent Layout - Top/Bottom Split

## Visual Layout

When 2 agents are active simultaneously:

```
┌─────────────────────────────────────────────┐
│                                             │
│         🌐 BrowserExecutor (TOP)            │
│                                             │
│     [Chrome browser view with CDP]          │
│                                             │
│                                             │
├─────────────────────────────────────────────┤
│                                             │
│        ⌘ TerminalExecutor (BOTTOM)          │
│                                             │
│     [Terminal output view]                  │
│                                             │
│                                             │
└─────────────────────────────────────────────┘
```

## CSS Configuration

```css
/* Two agents - vertical split (50/50 top-down) */
.agents-grid-workspace.split-view-2 {
  grid-template-columns: 1fr;      /* Single column */
  grid-template-rows: 1fr 1fr;     /* Two rows = 50% top, 50% bottom */
}
```

## How It Works

1. **AgentViewManager** detects 2 active agents
2. Applies `split-view-2` class to container
3. CSS Grid creates vertical split:
   - Row 1: BrowserExecutor (50% height)
   - Row 2: TerminalExecutor (50% height)
4. Both views resize dynamically

## Features

✅ **50/50 Split:** Equal space for both agents  
✅ **Responsive:** Resizes with window  
✅ **Real-time:** Updates as agents work  
✅ **Clean:** 8px gap between views  

## Testing

After restarting the server, run a task that uses both agents:

**Expected:**
- Browser view appears on TOP
- Terminal view appears on BOTTOM
- Both visible at the same time
- Both update in real-time

**Logs should show:**
```
✅ Agent activated: BrowserExecutor (total active: 1)
✅ Agent activated: TerminalExecutor (total active: 2)
Layout updated: 2 active agent(s)
```

## Related Files

- `/electron-app/src/renderer/css/styles.css` - Layout CSS (lines 1902-1905)
- `/electron-app/src/renderer/js/agent-view-manager.js` - View management
- `/surface_synapse/agent_session_manager.py` - Multi-agent support
- `/Synapse/core/conductor.py` - Parallel execution

## Scaling

The layout supports up to 4 agents:

- **1 agent:** Full screen
- **2 agents:** Top/Bottom (50/50)
- **3 agents:** 2x2 grid (one empty)
- **4 agents:** 2x2 grid (all filled)
