# Project Structure

This document describes the organized folder structure of the Term project.

## Root Directory

The project root contains only essential configuration files and directories:

```
term/
├── .gitignore              # Git ignore rules
├── pyproject.toml          # Poetry project configuration
├── poetry.lock             # Poetry dependency lock file
├── run_*.sh                # Executable shell scripts
└── (directories below)
```

## Directory Structure

### 📁 `app/`
Application entry point and main application code.

### 📁 `cursor/`
Cursor IDE configuration and custom tooling.

### 📁 `docs/`
**All project documentation organized by type:**

#### `docs/adr/`
Architectural Decision Records (ADRs) - lightweight documentation of design decisions.

#### `docs/analysis/`
Analysis reports and findings:
- `b_txt_analysis*.txt` - B.txt analysis reports
- `timing_analysis*.md` - Performance timing analysis

#### `docs/design/`
Design documents and architecture guides:
- `COMPREHENSIVE_AGENT_SWARM_REDESIGN.md`
- `MASTER_SWARM_REDESIGN_IMPLEMENTATION_GUIDE.md`
- `START_HERE_AGENT_COLLABORATION_FIX.md`
- `RCA_CHESS_BEST_MOVE_FAILURE.md`
- `FIXED_SUMMARY.md`

#### `docs/planning/`
Project planning artifacts:
- `dag_*.txt/md/json` - Task dependency graphs
- `executable_dag.json` - Executable DAG representation
- `task_dag.json` - Task DAG structure
- `execution_plan.txt` - Execution plans
- `implementation_plan*.txt` - Implementation plans
- `tasks_detailed.txt` - Detailed task breakdowns
- `actor_assignments.txt` - Actor role assignments

#### `docs/review/`
A-Team reviews and code review documents (per user rules).

### 📁 `logs/`
Runtime logs and debug output.

### 📁 `profiling/`
Performance profiling data and results.

### 📁 `runs/`
Execution run artifacts and outputs.

### 📁 `scripts/`
Utility scripts organized by purpose:

#### `scripts/analysis/`
Analysis and data processing scripts:
- `analyze_persona_subcategories*.py`
- `analyze_task_personas.py`
- `analyze_timing.py`
- `convert_to_yaml.py`

### 📁 `surface/`
**Surface agent system** - DSPy-based multi-agent framework:

```
surface/
├── src/surface/
│   ├── agents/          # Agent implementations (BrowserExecutor, CodeMaster, etc.)
│   ├── signatures/      # DSPy signatures
│   └── tools/           # Tool implementations (browser_tools, terminal_tools, etc.)
├── example_*.py         # Usage examples
├── *.md                 # Surface documentation
└── pyproject.toml       # Surface package config
```

**Browser Executor Documentation:**
- `AUTHENTICATION_PERSISTENCE_SUMMARY.md`
- `BROWSER_EXECUTOR_SETUP.md`
- `BROWSER_PERSISTENCE_GUIDE.md`
- `RUN_BROWSER_EXECUTOR.md`
- `WHY_TERMINAL_SESSION_NOT_NEEDED.md`
- `WHATSAPP_PERSISTENCE_HOWTO.md`

### 📁 `surface_synapse/`
Surface-Synapse integration layer.

### 📁 `Synapse/`
Synapse multi-agent system core:
- Complex agent orchestration
- Memory management
- Learning systems
- Swarm intelligence

### 📁 `Synapse_new/`
Next-generation Synapse implementation (in development).

### 📁 `terminal-bench/`
Terminal benchmarking and testing framework.

### 📁 `tests/`
Unit tests and integration tests:
- `test_browser_no_terminal.py` - Browser agent tests
- Other test files

### 📁 `working/`
**Temporary files and work-in-progress:**

#### `working/screenshots/`
Runtime screenshots from browser automation and testing.

#### Working files:
- `a.txt`, `b.txt`, `c.txt`, `d.txt` - Temporary text files

## File Organization Rules

Based on user rules and best practices:

1. **No clutter in root** - Only essential config files (.gitignore, pyproject.toml, poetry.lock) and executable scripts (.sh files)

2. **Documentation in `docs/`**:
   - ADRs → `docs/adr/`
   - Reviews → `docs/review/`
   - Analysis → `docs/analysis/`
   - Design → `docs/design/`
   - Planning → `docs/planning/`

3. **Code organization**:
   - Tests → `tests/`
   - Scripts → `scripts/` (organized by purpose)
   - Temporary files → `working/`

4. **Domain-specific documentation stays with code**:
   - Surface docs → `surface/`
   - Synapse docs → `Synapse/docs/`

## Quick Reference

| What you're looking for | Where to find it |
|------------------------|------------------|
| Architecture decisions | `docs/adr/` |
| Design documents | `docs/design/` |
| A-Team reviews | `docs/review/` |
| Project planning | `docs/planning/` |
| Analysis reports | `docs/analysis/` |
| Browser automation docs | `surface/` |
| Surface examples | `surface/example_*.py` |
| Tests | `tests/` |
| Utility scripts | `scripts/` |
| Temporary work | `working/` |

## Maintenance

When adding new files, follow these guidelines:

1. **ADRs** - Always create lightweight ADRs in `docs/adr/` for design decisions
2. **Reviews** - All A-Team reviews go in `docs/review/`
3. **Tests** - Always in `tests/` folder
4. **Scripts** - Organize in `scripts/` by purpose (analysis, deployment, etc.)
5. **Docs** - Never create loose `.md` files in root; use appropriate `docs/` subfolder
6. **Temporary files** - Use `working/` for any temporary artifacts

This structure ensures the project remains organized and maintainable as it grows.
