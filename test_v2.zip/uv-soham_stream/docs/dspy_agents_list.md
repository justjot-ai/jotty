# DSPy Agents List

This document lists all DSPy-based agents from the async generator conversion checklist.

## Overview

**Total DSPy Agents: 24**

DSPy agents are modules that use DSPy (Declarative Self-improving Python) for LLM orchestration. They fall into three categories:
1. **DSPy Module Classes** - Inherit from `dspy.Module`
2. **DSPy ReAct Agents** - Use `dspy.ReAct` for tool orchestration
3. **DSPy ChainOfThought Agents** - Use `dspy.ChainOfThought` for reasoning

---

## 1. DSPy Module Classes (2)

These agents inherit from `dspy.Module` and implement the full DSPy module interface.

### 1.1 `Synapse.core.agentic_parameter_resolver`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/agentic_parameter_resolver.py`
- **Class**: `AgenticParameterResolver(dspy.Module)`
- **Purpose**: Resolves and matches parameters intelligently using LLM
- **DSPy Components**: 
  - Inherits from `dspy.Module`
  - Uses `dspy.ChainOfThought(ParameterMatchingSignature)`

### 1.2 `Synapse.agents.task_breakdown_agent`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/agents/task_breakdown_agent.py`
- **Class**: `TaskBreakdownAgent(dspy.Module)`
- **Purpose**: Breaks down complex tasks into subtasks
- **DSPy Components**:
  - Inherits from `dspy.Module`
  - Uses `dspy.ChainOfThought(ExtractTasksSignature)`

---

## 2. DSPy ReAct Agents (3)

These agents use `dspy.ReAct` for tool-based reasoning and action orchestration.

### 2.1 `Synapse.core.dynamic_task_planner`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/dynamic_task_planner.py`
- **Class**: `DynamicTaskPlanner`
- **Purpose**: Plans and decomposes tasks dynamically
- **DSPy Components**:
  - `dspy.ReAct` for task decomposition
  - `dspy.ChainOfThought(TaskDecompositionSignature)`
  - `dspy.ChainOfThought(JSONRepairSignature)`
  - `dspy.ChainOfThought(PlanRepairSignature)`

### 2.2 `Synapse.core.metadata_fetcher`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/metadata_fetcher.py`
- **Class**: `MetaDataFetcher`
- **Purpose**: Fetches and extracts metadata from various sources
- **DSPy Components**:
  - `dspy.ReAct` for metadata extraction
  - `MetaDataFetcherSignature`

### 2.3 `Synapse.core.inspector`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/inspector.py`
- **Class**: `InspectorAgent`
- **Purpose**: Enhanced evaluation agent with A-Team features (Architect/Auditor)
- **DSPy Components**:
  - `dspy.ReAct` for validation orchestration
  - `dspy.ChainOfThought(TrajectoryFilterSignature)`
  - `dspy.ChainOfThought(ReasoningVoteConsistencySignature)`
  - `dspy.ChainOfThought(RefinementSignature)`

---

## 3. DSPy ChainOfThought Agents (19)

These agents use `dspy.ChainOfThought` for reasoning tasks.

### 3.1 `Synapse.core.conductor`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/conductor.py`
- **Class**: `Conductor`
- **Purpose**: Main orchestrator for Synapse system
- **DSPy Components**:
  - `dspy.ChainOfThought(LLMQPredictorSignature)` - Q-learning predictions
  - `dspy.ChainOfThought(SimilarExperienceSelectorSignature)` - Experience selection
  - `dspy.ChainOfThought(ContextAllocationSignature)` - Context management
  - `dspy.ChainOfThought(OverflowDetectionSignature)` - Overflow detection
  - `dspy.ChainOfThought(PolicyExplorerSignature)` - Policy exploration
  - `dspy.ChainOfThought(SwarmLearnerSignature)` - Swarm learning
  - `dspy.ChainOfThought(TaskCoverageSignature)` - Task coverage checking
  - `dspy.ChainOfThought(ErrorPatternSignature)` - Error pattern extraction
  - `dspy.ChainOfThought(MissingParameterSignature)` - Parameter detection
  - `dspy.ChainOfThought(FieldMatchSignature)` - Field matching

### 3.2 `Synapse.core.roadmap`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/roadmap.py`
- **Class**: `AgenticTODOAdapter`
- **Purpose**: Adapts and manages TODO items
- **DSPy Components**:
  - `dspy.ChainOfThought(ToolLinkSignature)` - Tool linking
  - `dspy.ChainOfThought(TrajectoryPredictorSignature)` - Trajectory prediction
  - `dspy.ChainOfThought(TODOAdaptationSignature)` - TODO adaptation

### 3.3 `Synapse.core.agentic_discovery`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/agentic_discovery/__init__.py`
- **Class**: `AgenticDiscovery`
- **Purpose**: Discovers and analyzes artifacts
- **DSPy Components**:
  - `dspy.ChainOfThought(AnalyzeArtifactSignature)` - Artifact analysis
  - `dspy.ChainOfThought(GenerateTagsSignature)` - Tag generation

### 3.4 `Synapse.core.tool_shed`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/tool_shed.py`
- **Classes**: `AgenticToolSelector`, `AgenticAgentSelector`
- **Purpose**: Selects appropriate tools and agents
- **DSPy Components**:
  - `dspy.ChainOfThought(ToolSelectionSignature)` - Tool selection
  - `dspy.ChainOfThought(AgentSelectionSignature)` - Agent selection

### 3.5 `Synapse.core.test_aggregation`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/test_aggregation.py`
- **Class**: `TestAggregator`
- **Purpose**: Aggregates test results semantically
- **DSPy Components**:
  - `dspy.ChainOfThought(SemanticAggregationSignature)`

### 3.6 `Synapse.core.time_budget_planner`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/time_budget_planner.py`
- **Class**: `TimeBudgetPlanner`
- **Purpose**: Plans time budgets for tasks
- **DSPy Components**:
  - `dspy.ChainOfThought(TimeBudgetPlanningSignature)`

### 3.7 `Synapse.core.parallel_test_generator`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/parallel_test_generator.py`
- **Class**: `ParallelTestGenerator`
- **Purpose**: Generates and validates test cases in parallel
- **DSPy Components**:
  - `dspy.ChainOfThought(TestCaseGenerationSignature)` - Test generation
  - `dspy.ChainOfThought(LLMTestValidationSignature)` - Test validation

### 3.8 `Synapse.core.generic_agent_registry`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/generic_agent_registry.py`
- **Class**: `GenericAgentRegistry`
- **Purpose**: Manages and selects agents based on capabilities
- **DSPy Components**:
  - `dspy.ChainOfThought(CapabilityInferenceSignature)` - Capability inference
  - `dspy.ChainOfThought(ActorSelectionSignature)` - Actor selection

### 3.9 `Synapse.core.environment_manager`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/environment_manager.py`
- **Class**: `EnvironmentManager`
- **Purpose**: Manages and summarizes environment state
- **DSPy Components**:
  - `dspy.ChainOfThought(EnvironmentSummarizationSignature)`

### 3.10 `Synapse.core.synapse_core`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/synapse_core.py`
- **Class**: `SynapseCore`
- **Purpose**: Core Synapse orchestration
- **DSPy Components**:
  - `dspy.ChainOfThought(OutputMetadataSignature)` - Metadata extraction

### 3.11 `Synapse.core.enhanced_agent_selector`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/enhanced_agent_selector.py`
- **Class**: `EnhancedAgenticAgentSelector`
- **Purpose**: Enhanced agent selection with context awareness
- **DSPy Components**:
  - `dspy.ChainOfThought(EnhancedAgentSelectionSignature)`

### 3.12 `Synapse.core.swarm_validation`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/swarm_validation.py`
- **Class**: `SwarmValidator`
- **Purpose**: Validates swarm configurations
- **DSPy Components**:
  - `dspy.ChainOfThought(SwarmArchitectSignature)` - Architect validation
  - `dspy.ChainOfThought(SwarmAuditorSignature)` - Auditor validation

### 3.13 `Synapse.core.adaptive_limit_learner`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/adaptive_limit_learner.py`
- **Class**: `AdaptiveLimitLearner`
- **Purpose**: Learns and adapts token limits
- **DSPy Components**:
  - `dspy.ChainOfThought(TokenOverflowDetectorSignature)` - Overflow detection
  - `dspy.ChainOfThought(LimitExtractorSignature)` - Limit extraction

### 3.14 `Synapse.agents.todo_creator_agent`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/agents/todo_creator_agent.py`
- **Class**: `TodoCreatorAgent`
- **Purpose**: Creates and validates executable DAGs with actor assignments
- **DSPy Components**:
  - `dspy.ChainOfThought(OptimizeDAGSignature)` - DAG optimization
  - `dspy.ChainOfThought(ActorAssignmentSignature)` - Actor assignment
  - `dspy.ChainOfThought(DAGValidationSignature)` - DAG validation

### 3.15 `Synapse.agents.user_communication_agent`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/agents/user_communication_agent.py`
- **Class**: `UserCommunicationAgent`
- **Purpose**: Generates user-facing messages for tasks based on context
- **DSPy Components**:
  - `dspy.ChainOfThought(UserCommunicationSignature)` - Communication generation
  - `dspy.ChainOfThought(CommunicationPrioritySignature)` - Priority determination

### 3.16 `Synapse.core.unified_chunker`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/unified_chunker.py`
- **Class**: `UnifiedChunker`
- **Purpose**: Chunks content with relevance scoring
- **DSPy Components**:
  - `dspy.ChainOfThought(RelevanceSignature)` - Relevance scoring

### 3.17 `Synapse.core.trajectory_parser`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/trajectory_parser.py`
- **Class**: `TrajectoryParser`
- **Purpose**: Parses and tags DSPy ReAct trajectories
- **DSPy Components**:
  - `dspy.ChainOfThought(TagAttemptSignature)` - Attempt tagging

### 3.18 `Synapse.core.predictive_cooperation`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/predictive_cooperation.py`
- **Classes**: `NashBargainingSolver`, `CooperationReasoner`, `PredictiveCooperativeAgent`
- **Purpose**: Manages cooperative multi-agent behavior
- **DSPy Components**:
  - `dspy.ChainOfThought(NashBargainingSignature)` - Nash bargaining
  - `dspy.ChainOfThought(CooperationReasoningSignature)` - Cooperation reasoning

### 3.19 `Synapse.core.agentic_feedback_router`
- **File**: `/Users/anshulchauhan/Tech/term/Synapse/core/agentic_feedback_router.py`
- **Class**: `AgenticFeedbackRouter`
- **Purpose**: Routes feedback intelligently using game theory
- **DSPy Components**:
  - `dspy.ChainOfThought(AgenticFeedbackSignature)` - Feedback routing

---

## Additional DSPy Agents (Not in Checklist)

These agents exist in the codebase but are not in the async generator conversion checklist:

### Surface Synapse Agents

1. **`surface_synapse.agents.web_search_agent`**
   - Class: `WebSearchAgent(dspy.Module)`
   - Purpose: Web search agent

2. **`surface_synapse.agents.browser_executor_agent`**
   - Class: `BrowserExecutorAgent(dspy.Module)`
   - Purpose: Browser automation agent

3. **`surface_synapse.agents.terminal_executor_agent`**
   - Class: `TerminalExecutorAgent(dspy.Module)`
   - Purpose: Terminal command execution agent

### Interface Agents

4. **`Synapse.interface`**
   - Classes: `SQLGenerator(dspy.Module)`, `DataAnalyzer(dspy.Module)`
   - Purpose: SQL generation and data analysis

### Other Core Agents

5. **`Synapse.core.research_need_inference`**
   - Class: `ResearchNeedInferenceModule(dspy.Module)`
   - Purpose: Infers research needs from context

---

## DSPy Signatures (Not Agents)

The following modules define DSPy Signatures but are not agents themselves:

- `Synapse.signatures.todo_creator_signatures` - Signatures for TODO creator
- `Synapse.signatures.dag_optimization_signatures` - Signatures for DAG optimization
- `Synapse.signatures.task_breakdown_signatures` - Signatures for task breakdown
- `Synapse.signatures.user_communication_signatures` - Signatures for user communication
- `surface.src.surface.signatures.*` - Various executor signatures

---

## Async Generator Conversion Status

All 24 DSPy agents listed above have been converted to use async generators that yield conversational log events in the format:

```json
{"module": "module_name", "message": "conversational_message"}
```

**Status**: ✅ All completed (as per checklist)

---

## Notes

1. **DSPy Module vs ChainOfThought**: 
   - `dspy.Module` classes are full agents with complex workflows
   - `dspy.ChainOfThought` is used for single reasoning tasks within larger agents

2. **ReAct Agents**: 
   - Use tool-based reasoning (Reason + Act pattern)
   - Best for tasks requiring multiple tool calls and exploration

3. **Async Generator Pattern**: 
   - All agents yield conversational messages during execution
   - Messages use first-person language: "I am doing this", "I found this"
   - Enables real-time streaming of agent progress to UI

---

**Last Updated**: 2026-02-02
**Total DSPy Agents in Checklist**: 24
**Total Additional DSPy Agents**: 5
**Grand Total**: 29 DSPy Agents
