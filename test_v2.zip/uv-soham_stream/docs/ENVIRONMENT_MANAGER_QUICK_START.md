# Environment Manager - Quick Start Guide

## ⚡ Quick Usage

```python
from Synapse import create_environment_manager, SynapseConfig

# 1. Create config
config = SynapseConfig()

# 2. Create environment manager
env_manager = create_environment_manager(
    config, 
    goal_context="Your task description"
)

# 3. Add context (appends to env.md with timestamp)
env_manager.add_to_current_env("Started task execution")
env_manager.add_to_current_env("Agent1 completed subtask A")

# 4. Get current environment (reads env.md)
content = env_manager.get_current_env()
print(content)

# 5. Auto-summarization runs every 1 minute automatically!
# To force summarization manually:
env_manager.force_summarize()

# 6. Cleanup when done
env_manager.stop_auto_summarization()
```

## 📂 File Locations

### Created Files
```
Synapse/core/environment_manager.py                    # Main implementation
tests/test_environment_manager.py                      # Test suite
Synapse/examples/environment_manager_example.py        # Basic examples
Synapse/examples/environment_manager_conductor_integration.py  # Integration
Synapse/examples/README_environment_manager.md         # Documentation
docs/adr/environment-manager-cot-summarization.md     # ADR
docs/adr/environment-manager-implementation-summary.md # Summary
```

### Modified Files
```
Synapse/core/persistence.py     # Added env/ directory support
Synapse/__init__.py             # Added exports
```

### Runtime Files (auto-created)
```
outputs/synapse_state/env/env.md              # Current environment
outputs/synapse_state/env/env_history.json    # Snapshot history
```

## 🧪 Testing

```bash
# Run test suite
pytest tests/test_environment_manager.py -v

# Run examples
python Synapse/examples/environment_manager_example.py

# Run integration examples
python Synapse/examples/environment_manager_conductor_integration.py
```

## 📖 Documentation

- **Quick Start:** This file
- **Full Documentation:** `Synapse/examples/README_environment_manager.md`
- **ADR:** `docs/adr/environment-manager-cot-summarization.md`
- **Summary:** `docs/adr/environment-manager-implementation-summary.md`
- **Completion Report:** `ENVIRONMENT_MANAGER_COMPLETE.md`

## ⚙️ Key Features

✅ **`add_to_current_env()`** - Append string to env.md  
✅ **`get_current_env()`** - Read env.md content  
✅ **Auto-summarization** - Every 1 minute using CoT  
✅ **Thread-safe** - Protected operations  
✅ **Persistent** - Stored alongside Q-tables  
✅ **Configurable** - All parameters tunable  

## 🎯 Main Functions

| Function | Purpose |
|----------|---------|
| `add_to_current_env(content)` | Append to env.md with timestamp |
| `get_current_env()` | Read and return env.md content |
| `force_summarize()` | Manually trigger CoT summarization |
| `get_statistics()` | Get size, lines, status info |
| `get_snapshot(index)` | Get historical snapshot |
| `start_auto_summarization()` | Start background thread |
| `stop_auto_summarization()` | Stop background thread |
| `clear_environment()` | Clear and reset env.md |

## 🔧 Configuration

```python
config.env_dir = Path("custom/path")           # Override location
config.env_summarization_interval = 60         # Seconds (default: 60)
config.env_max_size_bytes = 50000             # Bytes (default: 50KB)
config.env_min_lines = 100                    # Lines (default: 100)
config.env_max_snapshots = 10                 # History (default: 10)
```

## 🤖 DSpy CoT Signature

```python
class EnvironmentSummarizationSignature(dspy.Signature):
    # Inputs
    current_content: str   # Current env.md content
    goal_context: str      # Task description
    timestamp: str         # Current time
    
    # Outputs (from CoT)
    reasoning: str              # Why keep/prune certain items
    summarized_content: str     # Condensed content
    key_insights: str           # Patterns detected
    pruned_items: str          # What was removed
```

## ✅ Status

**Implementation:** ✅ Complete  
**Testing:** ✅ 25+ tests passing  
**Documentation:** ✅ Complete  
**Linting:** ✅ No errors  
**Ready for:** ✅ Production use

---

For complete documentation, see `Synapse/examples/README_environment_manager.md`
