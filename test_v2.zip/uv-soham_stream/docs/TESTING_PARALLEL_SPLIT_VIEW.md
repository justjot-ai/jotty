# Testing Guide: Parallel Agent Split View

## Quick Test Checklist

### ✅ Basic Functionality

1. **Single Agent Display**
   - [ ] Start a task that uses only BrowserExecutor
   - [ ] Verify browser view displays full-screen
   - [ ] Check that layout class is `.split-view-1`

2. **Two Agents (50/50 Split)**
   - [ ] Start a task that uses BrowserExecutor + TerminalExecutor in parallel
   - [ ] Verify both agents appear side-by-side (horizontal split)
   - [ ] Check that layout class is `.split-view-2`
   - [ ] Verify each agent gets 50% width
   - [ ] Check browser screenshots display correctly in split view
   - [ ] Check terminal is readable and properly sized

3. **Three Agents (2x2 Grid)**
   - [ ] Start a task that activates 3 agents
   - [ ] Verify 2x2 grid layout with one empty cell
   - [ ] Check that layout class is `.split-view-3`

4. **Four Agents (Full 2x2 Grid)**
   - [ ] Start a task that activates all 4 agents
   - [ ] Verify all agents display in 2x2 grid
   - [ ] Check that layout class is `.split-view-4`

### ✅ Transitions

5. **Agent Activation**
   - [ ] Start with empty state
   - [ ] Activate first agent - verify smooth fade-in
   - [ ] Activate second agent - verify layout transitions smoothly
   - [ ] Check opacity and scale animations work

6. **Agent Deactivation**
   - [ ] With 2 agents active, deactivate one
   - [ ] Verify remaining agent expands to full-screen
   - [ ] Check smooth transition
   - [ ] Deactivate last agent - verify return to empty state

### ✅ Resize Handling

7. **Window Resize**
   - [ ] With 2 agents active, resize window
   - [ ] Verify browser canvas redraws at new size
   - [ ] Verify terminal refits to new dimensions
   - [ ] Check aspect ratios maintained

8. **Layout Change Resize**
   - [ ] Start with 1 agent (full-screen)
   - [ ] Activate 2nd agent (triggers split)
   - [ ] Verify browser canvas redraws for split view
   - [ ] Verify terminal refits for split view

### ✅ Browser View Specific

9. **Screenshot Display**
   - [ ] Verify screenshots appear in browser view
   - [ ] Check screenshots scale properly in split view
   - [ ] Verify aspect ratio maintained
   - [ ] Check canvas fills available space

10. **CDP Connection**
    - [ ] Verify CDP connects when browser agent activates
    - [ ] Check screenshot capture continues at 2 FPS
    - [ ] Verify cleanup on deactivation

### ✅ Terminal View Specific

11. **Terminal Display**
    - [ ] Verify xterm.js initializes properly
    - [ ] Check terminal output is readable in split view
    - [ ] Verify scrollback works
    - [ ] Check colors and formatting

12. **Terminal Resize**
    - [ ] Verify FitAddon adjusts terminal size
    - [ ] Check ResizeObserver triggers on layout change
    - [ ] Verify cleanup on deactivation

### ✅ Edge Cases

13. **Rapid Activation/Deactivation**
    - [ ] Quickly activate and deactivate agents
    - [ ] Verify no visual glitches
    - [ ] Check cleanup happens properly
    - [ ] Verify no memory leaks

14. **Multiple Layout Changes**
    - [ ] Cycle through 1 → 2 → 3 → 4 → 3 → 2 → 1 agents
    - [ ] Verify smooth transitions at each step
    - [ ] Check all agents remain functional

15. **Empty State**
    - [ ] Start with no agents
    - [ ] Verify empty state displays
    - [ ] Check container styling

## Manual Testing Commands

### Test 1: Single Agent (Browser Only)

```bash
# In Electron app, send message:
"Open google.com in browser"
```

**Expected:** Browser view full-screen

### Test 2: Two Agents (Browser + Terminal)

```bash
# In Electron app, send message:
"Search for Python tutorials and list files in current directory"
```

**Expected:** Browser and terminal side-by-side

### Test 3: Verify Layout Classes

Open DevTools in Electron app:

```javascript
// Check current layout
const container = document.getElementById('agents-grid-workspace');
console.log('Layout class:', container.className);
console.log('Active agents:', app.agentViewManager.getActiveAgents());
```

### Test 4: Simulate Agent Events

```javascript
// Manually trigger agent activation
app.agentViewManager.activateAgent('BrowserExecutor');
app.agentViewManager.activateAgent('TerminalExecutor');

// Check layout
const container = document.getElementById('agents-grid-workspace');
console.log('Should be split-view-2:', container.className);

// Deactivate one
app.agentViewManager.deactivateAgent('BrowserExecutor');
console.log('Should be split-view-1:', container.className);
```

## Visual Inspection

### Layout Verification

1. **Spacing:** 8px gap between agent views
2. **Borders:** 1px border on each agent view, 8px border-radius
3. **Opacity:** Smooth fade-in from 0 to 1
4. **Scale:** Smooth scale from 0.95 to 1.0

### Browser View

- Canvas should fill available space
- Screenshots should maintain aspect ratio
- No distortion or stretching
- Black background visible if screenshot smaller than canvas

### Terminal View

- Text should be crisp and readable
- Colors should match theme
- Cursor should be visible
- Scrollbar should appear when needed

## Performance Checks

### CPU Usage

- Monitor CPU usage with 2 agents active
- Browser screenshots should be ~2 FPS (low CPU)
- Terminal should be minimal CPU when idle

### Memory Usage

- Check memory before and after agent activation
- Verify cleanup releases memory on deactivation
- No memory leaks after multiple activation/deactivation cycles

### Frame Rate

- UI should remain responsive at 60 FPS
- Transitions should be smooth
- No stuttering during layout changes

## Common Issues

### Issue: Browser canvas not resizing

**Solution:** Check ResizeObserver is attached and firing

```javascript
// In DevTools
const browserHandler = app.agentViewManager.views.get('BrowserExecutor').handler;
console.log('ResizeObserver:', browserHandler.resizeObserver);
```

### Issue: Terminal not fitting properly

**Solution:** Check FitAddon is loaded and ResizeObserver attached

```javascript
// In DevTools
const termHandler = app.agentViewManager.views.get('TerminalExecutor').handler;
console.log('FitAddon:', termHandler.fitAddon);
console.log('ResizeObserver:', termHandler.resizeObserver);
```

### Issue: Layout not updating

**Solution:** Check activeAgents Set and layout class

```javascript
// In DevTools
console.log('Active agents:', app.agentViewManager.activeAgents);
const container = document.getElementById('agents-grid-workspace');
console.log('Layout class:', container.className);
```

## Success Criteria

✅ All agents display correctly in split views  
✅ Smooth transitions between layouts  
✅ Proper resize handling for all agent types  
✅ No visual glitches or artifacts  
✅ Performance remains acceptable (60 FPS UI)  
✅ Memory cleanup works properly  
✅ Browser screenshots scale correctly  
✅ Terminal text remains readable  

## Reporting Issues

If you find issues, please report:

1. **Steps to reproduce**
2. **Expected behavior**
3. **Actual behavior**
4. **Screenshots/videos** (if applicable)
5. **Console errors** (check DevTools)
6. **System info** (OS, Electron version)

## Next Steps

After testing, consider:

- User feedback on split-view UX
- Performance optimization if needed
- Additional layout options
- Drag-to-resize functionality
