# Test Agent Embedding - Troubleshooting Guide

**Status:** WebSocket Connected ✅ | Agent Events Not Broadcasting ❌

---

## Current Status

### ✅ What's Working
- WebSocket connection successful
- Electron connecting to `/ws/browser`
- Server logs show: `✅ WebSocket connected. Total: 3`

### ❌ What's Not Working
- Browser view not appearing in Electron
- No agent events being broadcast
- AgentSessionManager not logging initialization

---

## Root Cause

The server was restarted, but the **AgentSessionManager initialization is not logging**, which means:

1. The initialization code might be failing silently
2. OR the server needs a fresh restart to pick up all changes

---

## Quick Fix Steps

### Step 1: Verify Files Are Correct

Check that these files exist:
```bash
ls -la uv/src/uv/api/v1/websocket_agents.py
grep "initialize_agent_session_manager" uv/src/uv/main.py
```

### Step 2: Full Server Restart

**In Terminal 106:**
```bash
# Stop server
Ctrl+C

# Clear any cached Python files
find uv -name "*.pyc" -delete
find uv -name "__pycache__" -type d -exec rm -rf {} +

# Restart server
./run_server.sh
```

**Look for in logs:**
```
✅ Synapse swarm initialized and ready
✅ AgentSessionManager initialized for agent view embedding  ← MUST SEE THIS!
INFO: Uvicorn running on http://0.0.0.0:8000
```

### Step 3: Test Browser Event

**Send a message in Electron:**
```
"Open Google"
```

**Check server logs for:**
```
Agent activated: BrowserExecutor
📡 Agent event: BrowserExecutor.navigate
```

---

## If Still Not Working

### Debug 1: Check Import Error

The AgentSessionManager import might be failing. Check logs for:
```bash
grep -i "error\|exception\|failed" /path/to/terminal/106.txt | tail -20
```

### Debug 2: Manual Test

Test if AgentSessionManager can be imported:
```bash
cd /Users/anshulchauhan/Tech/term
python3 -c "from surface_synapse.agent_session_manager import initialize_agent_session_manager; print('✅ Import works')"
```

### Debug 3: Check Browser Tools

Verify browser_tools has the broadcast code:
```bash
grep "broadcast_browser_event" surface/src/surface/tools/browser_tools.py
```

---

## Expected Flow

### 1. Server Startup
```
Starting UV application...
Initializing Synapse swarm...
✅ Synapse swarm initialized
✅ AgentSessionManager initialized  ← KEY!
Uvicorn running on http://0.0.0.0:8000
```

### 2. Electron Connects
```
WebSocket connection attempt from: ('127.0.0.1', ...)
✅ WebSocket connected. Total: 1
```

### 3. Browser Task Sent
```
🌐 Navigating to URL: https://google.com
✅ Navigation successful
Agent activated: BrowserExecutor  ← KEY!
📡 Agent event: BrowserExecutor.navigate  ← KEY!
```

### 4. Electron Receives Event
```javascript
// In Electron console
Agent activated: BrowserExecutor
Switching to agent: BrowserExecutor
✅ BrowserView shown
```

---

## Most Likely Issue

The server was restarted but **Python cached the old code**. The fix:

```bash
# In uv directory
find . -name "*.pyc" -delete
find . -name "__pycache__" -type d -exec rm -rf {} +
./run_server.sh
```

---

## Alternative: Check If Module Path Is Correct

The import might be failing because the path is wrong. Let me verify:

```python
# In uv/src/uv/main.py, the import is:
from surface_synapse.agent_session_manager import initialize_agent_session_manager

# This assumes surface_synapse is in Python path
# Check if it's installed:
pip list | grep surface-synapse
```

If not installed, the import will fail silently!

---

## Quick Verification Script

Create `test_imports.py`:
```python
#!/usr/bin/env python3
import sys
sys.path.insert(0, '/Users/anshulchauhan/Tech/term')

try:
    from uv.api.v1.websocket_agents import get_websocket_manager
    print("✅ websocket_agents import works")
except Exception as e:
    print(f"❌ websocket_agents import failed: {e}")

try:
    from surface_synapse.agent_session_manager import initialize_agent_session_manager
    print("✅ agent_session_manager import works")
except Exception as e:
    print(f"❌ agent_session_manager import failed: {e}")

try:
    ws_manager = get_websocket_manager()
    agent_mgr = initialize_agent_session_manager(ws_manager)
    print(f"✅ AgentSessionManager initialized: {agent_mgr}")
except Exception as e:
    print(f"❌ Initialization failed: {e}")
```

Run:
```bash
cd /Users/anshulchauhan/Tech/term
python3 test_imports.py
```

---

## Next Steps

1. ✅ WebSocket is working
2. ⏳ Need to verify AgentSessionManager initialization
3. ⏳ Clear Python cache and restart
4. ⏳ Check for import errors
5. ⏳ Test browser event broadcasting

**Most likely fix: Clear cache and restart server!** 🔄
