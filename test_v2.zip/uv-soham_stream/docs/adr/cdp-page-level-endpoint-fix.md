# ADR: CDP Page-Level Endpoint Fix

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Browser embedding in Electron UI

## Problem

The initial CDP implementation connected to the **browser-level** endpoint (`/devtools/browser/...`), which doesn't support page-specific commands like `Page.enable`, `Page.captureScreenshot`, etc.

**Error encountered:**
```
Uncaught (in promise) Error: 'Page.enable' wasn't found
```

## Root Cause

The `get_cdp_endpoint()` function in `browser_tools.py` was querying:
- `http://localhost:9222/json/version` → Returns browser-level WebSocket URL
- Browser-level endpoints only support browser-wide commands, not page/tab commands

## Solution

Modified `get_cdp_endpoint()` to:

1. **Query page targets:** Use `http://localhost:9222/json` to get list of all pages/tabs
2. **Filter for pages:** Find targets with `type == "page"`
3. **Use first page:** Connect to the first page's `webSocketDebuggerUrl`
4. **Fetch version separately:** Still get browser version from `/json/version` for metadata

## Changes

### File: `surface/src/surface/tools/browser_tools.py`

```python
# Before: Browser-level endpoint
cdp_http_url = "http://localhost:9222/json/version"
ws_url = cdp_info.get("webSocketDebuggerUrl")  # Browser-level

# After: Page-level endpoint
cdp_http_url = "http://localhost:9222/json"
pages = response.json()
page_targets = [p for p in pages if p.get("type") == "page"]
ws_url = page_targets[0].get("webSocketDebuggerUrl")  # Page-level
```

### Additional Improvements

1. **Enhanced logging:** Added page title and URL to CDP endpoint logs
2. **Better error handling:** Check if any page targets exist
3. **CSP fix:** Added `img-src 'self' data: blob: https:` to allow screenshot images
4. **Debug logging:** Added console logs for screenshot capture process

## Result

✅ Electron now connects to page-level CDP endpoint  
✅ `Page.enable`, `Page.captureScreenshot` commands work  
✅ Screenshots are captured and displayed on canvas  
✅ True browser embedding is functional

## Testing

```javascript
// Electron console should show:
🌐 CDP endpoint ready: ws://localhost:9222/devtools/page/...
✅ CDP WebSocket connected
✅ CDP connected successfully
📸 Capturing screenshot...
✅ Screenshot captured, size: XXXXX bytes
🖼️ Image loaded, rendering to canvas...
```

## Notes

- The first page target is used by default (usually the active tab)
- If multiple tabs exist, Selenium's current tab will be the one shown
- Page-level endpoints support full CDP Page domain commands
