# ADR: Electron Debug Mode and Event Logging

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Electron App Event Streaming

## Decision

Enabled comprehensive debug mode in the Electron application to log all API events and WebSocket messages in real-time.

## Implementation

### Debug Mode Features

1. **Event Counter**: Tracks total number of events received during task execution
2. **Console Logging**: Detailed console.log for every event with full JSON structure
3. **UI Logging**: Debug messages displayed in system terminal panel
4. **Stream Monitoring**: Logs each SSE chunk received from `/api/v1/perform`
5. **WebSocket Tracking**: Logs all WebSocket messages from `ws://127.0.0.1:8000/ws/browser`

### Key Changes

**File**: `electron-app/src/renderer/js/app.js`

#### Added Properties
```javascript
this.debugMode = true;      // Enable debug mode
this.eventCounter = 0;      // Track event count
```

#### Enhanced Logging Points

1. **API Request Logging**
   - Request URL and body
   - Response status and headers
   - Each SSE chunk with byte count
   - Raw and parsed event data

2. **Event Processing**
   - Event number, type, module
   - Full event object structure
   - Timestamp for each event
   - Data payload inspection

3. **WebSocket Messages**
   - Message type identification
   - Full message payload
   - Agent activation/deactivation tracking
   - Unknown message type warnings

4. **Task Lifecycle**
   - Task start with session info
   - Event counter reset
   - Processing state changes
   - Error stack traces

### Debug Output Format

**Console Logs:**
```
🔍 [DEBUG] Event #5 received: {...}
🔍 [DEBUG] Event keys: ["type", "module", "message"]
🔍 [DEBUG] Event details: {...}
```

**UI Terminal Logs:**
```
🔍 [DEBUG] Event #5 | Type: status
🔍 [DEBUG] WS: agent_activated | {...}
🔍 [DEBUG] Total events: 42
```

## Benefits

1. **Real-time Visibility**: See every event as it arrives
2. **Debugging**: Identify parsing errors or missing data
3. **Performance Monitoring**: Track event count and timing
4. **Protocol Validation**: Verify SSE and WebSocket message formats
5. **Development Aid**: Easier troubleshooting during development

## Usage

Debug mode is enabled by default. To disable:
```javascript
this.debugMode = false;
```

All debug logs are prefixed with `🔍 [DEBUG]` for easy filtering.

## Related

- `/api/v1/perform` - SSE streaming endpoint
- `ws://127.0.0.1:8000/ws/browser` - WebSocket endpoint
- Event format: `{type, module, message, data, error}`
