# ADR: Executor Agent Signature Fix

**Date:** 2026-01-30  
**Status:** Implemented  
**Context:** BrowserExecutor, TerminalExecutor, and WebSearch agents failing with TypeError

## Problem

All three executor agent wrappers (`BrowserExecutorAgent`, `TerminalExecutorAgent`, `WebSearchAgent`) were passing an invalid `terminal_state=""` parameter to `BaseSwarmAgent.forward()`, causing:

```
TypeError: BaseSwarmAgent.forward() got an unexpected keyword argument 'terminal_state'
```

## Root Cause

The wrapper agents were incorrectly passing `terminal_state` as a parameter, but `BaseSwarmAgent.forward()` signature only accepts:
- `instruction: str`
- `terminal_session=None`
- `conversation_history: str = ""`
- `session_id: Optional[str] = None`
- `model_id: Optional[str] = None`

The base agent handles terminal state internally by calling `get_terminal_state()` when needed.

## Solution

Fixed all three agent wrappers to:
1. Remove `terminal_state=""` parameter
2. Pass `terminal_session` parameter correctly
3. Pass through `session_id` and `model_id` parameters

### Changes

**BrowserExecutorAgent:**
- Changed from: `terminal_state=""`
- Changed to: `terminal_session=None` (browser tasks don't need terminal)

**TerminalExecutorAgent:**
- Changed from: `terminal_state=""`
- Changed to: `terminal_session=terminal_session` (pass through)

**WebSearchAgent:**
- Changed from: `terminal_state=""`
- Changed to: `terminal_session=None` (web search doesn't need terminal)

## Files Modified

- `surface_synapse/agents/browser_executor_agent.py`
- `surface_synapse/agents/terminal_executor_agent.py`
- `surface_synapse/agents/web_search_agent.py`

## Impact

- ✅ Fixes TypeError preventing executor agents from running
- ✅ Aligns wrapper signatures with BaseSwarmAgent
- ✅ Maintains proper parameter passing for session and model IDs
- ✅ Preserves terminal session handling logic in base agent

## Testing

Run the solve_task script to verify the fix:
```bash
./scripts/run_solve_task.sh "test browser automation"
```
