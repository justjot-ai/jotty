# ADR: Final Swarm Output Logging

## Status
Proposed

## Context
The swarm execution completes successfully but the final output is not being logged or streamed to the client. The logs show:
- Task completes with `success=False` 
- `output_length=9` (which is "No output" fallback)
- No final output message in the event stream

The flow is:
1. Conductor yields result event with SwarmResult
2. TaskService extracts result but doesn't yield final output event
3. Client receives completion message but no actual result

## Problem
Users cannot see the actual result of their task execution. The final output from the swarm needs to be:
1. Logged clearly in the server logs
2. Streamed as a final event to the client
3. Include the actual result data from the agents

### Root Cause
The sync `register_output` method in `io_manager.py` was incomplete - it only logged debug information but didn't actually extract output_fields or create the ActorOutput object. This caused `self.io_manager.outputs` to be empty, resulting in `final_output=None`.

## Decision
Add a final output event that:
1. Extracts the final_output from SwarmResult
2. Logs it with a clear marker (e.g., "🎯 FINAL SWARM OUTPUT")
3. Yields it as a dedicated event with type "final_output"
4. Includes both the raw output and a human-readable summary

## Implementation

### 1. Fix `io_manager.py` (Root Cause)
Complete the sync `register_output` method to:
- Extract signature from actor if not provided
- Extract output_fields from the DSPy output
- Create ActorOutput object with fields and tagged_attempts
- Store in `self.outputs[actor_name]`
- Log extraction results for debugging

### 2. Enhance `conductor.py`
- Add fallback logic to construct final_output from available fields when standard fields don't exist
- Priority order: `reasoning` > `analysis` > `plan` > combined text fields
- Add clear logging with "🎯 FINAL SWARM OUTPUT" marker before yielding result
- Enhanced debug logging to show which field was used

### 3. Improve `task_service.py`
- Add support for handling both dict and object result formats
- Add "🎯 FINAL SWARM OUTPUT" log message
- Yield a new `final_output` event to the client with:
  - The actual output text
  - Success status
  - Agents used
  - Execution time
- Improved error handling for None/non-string outputs

## Consequences
### Positive
- Users can see the actual result of their task
- Better debugging with clear output logging
- Improved user experience with streaming updates

### Negative
- Slightly more verbose logs
- Additional event in the stream

## Notes
- The BrowserExecutor completed successfully (found 0 unread messages)
- The result is in the actor_outputs but not being extracted/logged properly
- Need to ensure final_output extraction works for all agent types
