# ADR: Electron Dual View System

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: Electron desktop app with toggleable classic and grid views

## Decision

Implement a dual-view system allowing users to toggle between two distinct UI layouts:
1. **Classic View** - Original vertical layout with eyes, system status, and chat
2. **Grid View** - Expansion-based grid layout inspired by professional multi-agent dashboards

## Implementation

### View Toggle Button
- Added to toolbar between Clear and Theme buttons
- Icon: 4-square grid icon
- Label dynamically updates: "Grid" (when in classic) or "Classic" (when in grid)
- View preference persisted in localStorage as `uv-view`

### Classic View
- Original design preserved
- Vertical flex layout with sections:
  - Eyes (compact)
  - System Status (agents, task, browser)
  - Conversation (expanded)
- Optimized for personal assistant feel with eyes at top

### Grid View
- Professional 3-column grid layout
- **Left Sidebar** (200px):
  - Mini eyes panel (compact status indicator)
  - Agents list (browser, terminal, search)
- **Center Stage** (fluid):
  - 2x2 expansion grid for terminals
  - Active terminal expands (1.8fr vs 1fr ratio)
  - Smooth cubic-bezier transitions
  - Opacity management (inactive: 0.35, active: 1.0)
- **Right Sidebar** (240px):
  - Session info
  - Task status
- **Chat Bar** (bottom):
  - Full-width input at bottom
  - Consistent with terminal app pattern

### Expansion System
Grid view terminals expand when active using CSS grid transitions:
```css
.terminals-grid-expand.focus-0 {
  grid-template-columns: 1.8fr 1fr;
  grid-template-rows: 1.8fr 1fr;
}
```

### Dual-View Support
- Both views share same backend WebSocket connections
- Browser screenshots update in both views simultaneously
- Chat input synchronized between views
- Session ID and status synced across views
- View-aware message handling (detects active view's input)

## Technical Details

### HTML Structure
```
<div class="container classic-view">
  <!-- Original design -->
</div>

<div class="container grid-view" style="display: none;">
  <div class="sidebar-left">...</div>
  <div class="center-stage">
    <div class="terminals-grid-expand">
      <div class="terminal-expand">...</div>
    </div>
  </div>
  <div class="sidebar-right">...</div>
  <div class="chat-bar-grid">...</div>
</div>
```

### CSS Classes
- `.container.classic-view` - Vertical flex layout
- `.container.grid-view` - 3-column grid layout
- `.terminal-expand` - Individual terminal panel
- `.terminal-expand.active` - Expanded/focused terminal
- `.terminals-grid-expand.focus-N` - Grid with Nth terminal expanded

### JavaScript API
```javascript
this.currentView = 'classic'; // or 'grid'
this.toggleView(); // Switch between views
this.applyView(view); // Apply view on load
```

### View Switching Logic
1. Hide current view container
2. Show target view container  
3. Update button label
4. Focus appropriate chat input
5. Sync session data
6. Save preference to localStorage

## Design Inspirations

### Classic View
- TUI design from `uv.py`
- Personal assistant with sentient eyes
- Vertical scroll with sections

### Grid View
- Professional agent orchestration dashboards
- Terminal-based workflows
- Expansion grids for focus management
- Opacity-based visual hierarchy

## Benefits

### For Users
- **Flexibility**: Choose layout based on task
- **Classic View**: Better for casual chat, emphasis on personality
- **Grid View**: Better for monitoring multiple agents, professional workflows
- **Seamless**: No data loss when switching, instant toggle

### For Development
- **Modular**: Two independent layouts, easier to maintain
- **Extensible**: Can add more views in future
- **Backwards Compatible**: Classic view preserves original design

## Future Enhancements

### Grid View
- Click terminal to expand (not just auto-expand on activity)
- Drag & drop terminals to rearrange
- Minimize/maximize individual terminals
- Terminal history/tabs

### Additional Views
- **Compact View**: Minimal chat-only interface
- **Dashboard View**: Analytics and metrics focus
- **Debug View**: Logs and system internals

### View Customization
- Save layout preferences per view
- Custom terminal arrangements
- Personalize panel visibility

## Files Modified

### Created
- None (all modifications to existing files)

### Modified
- `electron-app/src/renderer/index.html`
  - Added view toggle button to toolbar
  - Added `.classic-view` class to original container
  - Created complete `.grid-view` HTML structure
  
- `electron-app/src/renderer/css/styles.css`
  - Added `.container.classic-view` and `.container.grid-view` rules
  - Added complete grid view styling (~500 lines)
  - Added expansion grid animations
  - Added dual-theme support for both views

- `electron-app/src/renderer/js/app.js`
  - Added `currentView` property
  - Added `setupViewToggle()` method
  - Added `toggleView()` method
  - Added `applyView()` method
  - Updated `handleSendMessage()` to detect active view
  - Updated `updateBrowserView()` to update both views
  - Added grid view event listeners

## Consequences

### Positive
- Users get two distinct UX paradigms in one app
- Can switch instantly based on workflow needs
- Grid view feels more professional for agent monitoring
- Classic view maintains personal assistant charm
- No code duplication (shared backend logic)

### Negative
- Increased HTML/CSS size (~800 lines added)
- Need to maintain two UI layouts
- Some state synchronization complexity
- Grid view animations may impact performance on slower machines

### Neutral
- View preference stored locally per-device
- Both views have same functionality
- Learning curve for users to understand two views
