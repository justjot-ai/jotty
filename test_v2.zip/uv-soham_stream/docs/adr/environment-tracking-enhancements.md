# ADR: Environment Tracking Enhancements

**Status:** Implemented  
**Date:** 2026-01-31  
**Author:** A-Team  
**Component:** Environment Manager Tracking

## Context

After implementing the Environment Manager and integrating it into the TODO pipeline, two additional tracking capabilities were needed:

1. **Complete TODO Structure:** After TODO creation, append the full TODO list with all tasks, actors, and dependencies
2. **ReAct Trajectory:** After each action in ReAct agents, append the trajectory details (attempts, tools, reasoning)

These enhancements provide complete visibility into planning and execution.

## Decision

### Enhancement 1: Complete TODO Structure Tracking

**Location:** `Synapse/core/conductor.py` (line ~4356)

After TODO creation completes, append the full TODO structure to environment:

```python
# Build complete TODO structure
todo_structure = []
todo_structure.append("✅ TODO creation complete:")
todo_structure.append(f"  - Tasks created: {len(task_dag.tasks)}")
todo_structure.append(f"  - Actor assignments: {len(executable_dag.assignments)}")
todo_structure.append(f"  - DAG validation: {'✅ Passed' if executable_dag.validation_passed else '⚠️ Issues found'}")
todo_structure.append("\n📋 **TODO Task List:**")

# Add each task with details
for task_id, task in task_dag.tasks.items():
    actor = executable_dag.assignments.get(task_id)
    actor_name = actor.name if actor else "Unassigned"
    todo_structure.append(f"\n  **Task {task_id}:** {task.name}")
    todo_structure.append(f"    - Actor: {actor_name}")
    todo_structure.append(f"    - Type: {task.task_type.value}")
    todo_structure.append(f"    - Description: {task.description[:150]}")
    if task.depends_on:
        todo_structure.append(f"    - Dependencies: {', '.join(task.depends_on)}")

# Add execution stages
stages = task_dag.get_execution_stages()
todo_structure.append(f"\n  **Execution Plan:** {len(stages)} stages")
for i, stage in enumerate(stages, 1):
    todo_structure.append(f"    Stage {i}: {', '.join(stage)}")

env_manager.add_to_current_env("\n".join(todo_structure))
```

**What's Tracked:**
- Total task count
- Actor assignments
- DAG validation status
- Each task with:
  - Task ID and name
  - Assigned actor
  - Task type
  - Description (truncated to 150 chars)
  - Dependencies
- Execution stages (parallel execution plan)

**Example Output:**
```markdown
✅ TODO creation complete:
  - Tasks created: 5
  - Actor assignments: 5
  - DAG validation: ✅ Passed
  - Total duration: 2.345s

📋 **TODO Task List:**

  **Task task_1:** Setup Environment
    - Actor: TerminalExecutor
    - Type: setup
    - Description: Create virtual environment and install dependencies
    - Dependencies: []

  **Task task_2:** Create Script
    - Actor: CodeMaster
    - Type: implementation
    - Description: Create Python web scraper script using BeautifulSoup4
    - Dependencies: ['task_1']

  **Task task_3:** Test Script
    - Actor: TerminalExecutor
    - Type: test
    - Description: Run the scraper script and verify output
    - Dependencies: ['task_2']

  **Execution Plan:** 3 stages
    Stage 1: task_1
    Stage 2: task_2
    Stage 3: task_3
```

### Enhancement 2: ReAct Trajectory Tracking

**Location:** `Synapse/core/synapse_core.py` (line ~799)

After trajectory parsing, append trajectory details to environment:

```python
# Format trajectory for environment
trajectory_info = []
trajectory_info.append(f"🎯 **Action Trajectory** (Agent: {agent_name})")

# Add tagged attempts (from TrajectoryParser)
if tagged_attempts:
    trajectory_info.append(f"  - Total attempts: {len(tagged_attempts)}")
    for attempt in tagged_attempts[:5]:  # Show first 5
        trajectory_info.append(
            f"    #{attempt.attempt_number}: {attempt.tag} | "
            f"Tool: {attempt.tool_name} | "
            f"Args: {str(attempt.tool_args)[:80]}"
        )
    if len(tagged_attempts) > 5:
        trajectory_info.append(f"    ... and {len(tagged_attempts) - 5} more attempts")

# Add ReAct trajectory (thought-action-observation triplets)
if react_trajectory:
    num_steps = len(react_trajectory) // 3
    trajectory_info.append(f"  - ReAct steps: {num_steps}")
    
    # Show first 3 steps
    for i in range(min(3, num_steps)):
        thought_key = f"thought_{i}"
        action_key = f"action_{i}"
        
        if thought_key in react_trajectory:
            thought = str(react_trajectory[thought_key])[:100]
            trajectory_info.append(f"    Step {i+1} Thought: {thought}")
        
        if action_key in react_trajectory:
            action = str(react_trajectory[action_key])[:100]
            trajectory_info.append(f"    Step {i+1} Action: {action}")
    
    if num_steps > 3:
        trajectory_info.append(f"    ... and {num_steps - 3} more steps")

# Add output summary
if hasattr(actor_output, '_store'):
    fields = list(actor_output._store.keys())
    trajectory_info.append(f"  - Output fields: {', '.join(fields[:5])}")

env_manager.add_to_current_env("\n".join(trajectory_info))
```

**What's Tracked:**
- Agent name
- Total attempts (from TrajectoryParser)
- Each attempt with:
  - Attempt number
  - Tag (answer/error/exploratory)
  - Tool used
  - Tool arguments (truncated)
- ReAct steps (thought-action-observation)
- Output field summary

**Example Output:**
```markdown
🎯 **Action Trajectory** (Agent: CodeMaster)
  - Total attempts: 3
    #1: exploratory | Tool: web_search | Args: "Python web scraping libraries 2024"
    #2: exploratory | Tool: web_search | Args: "BeautifulSoup4 rate limiting best practices"
    #3: answer | Tool: generate_code | Args: {"language": "python", "task": "web scraper"}
  - ReAct steps: 3
    Step 1 Thought: I need to research current web scraping libraries to ensure best practices
    Step 1 Action: web_search("Python web scraping libraries 2024")
    Step 2 Thought: BeautifulSoup4 is recommended, but I should check rate limiting requirements
    Step 2 Action: web_search("BeautifulSoup4 rate limiting best practices")
    Step 3 Thought: Now I have all the information needed to create the scraper
    Step 3 Action: generate_code(language="python", task="web scraper with rate limiting")
  - Output fields: code, reasoning, imports, best_practices
```

## Benefits

### 1. Complete TODO Visibility
- All agents see the full plan
- Know what tasks exist
- Understand dependencies
- See execution order

### 2. Trajectory Transparency
- See exactly what each agent tried
- Understand reasoning steps
- Debug failures easily
- Learn from attempts

### 3. Better Decision Making
- Agents avoid redundant attempts
- Build on previous reasoning
- Skip failed approaches
- Use successful patterns

### 4. Enhanced Debugging
- Complete execution trail
- See decision points
- Understand failures
- Identify bottlenecks

### 5. Learning & Improvement
- Pattern recognition
- Failure analysis
- Success identification
- Strategy refinement

## Files Modified

### 1. `Synapse/core/conductor.py`
- Enhanced TODO tracking (line ~4356)
- Added complete TODO structure formatting
- Includes tasks, actors, dependencies, stages

### 2. `Synapse/core/synapse_core.py`
- Added trajectory tracking (line ~806)
- Captures tagged attempts
- Captures ReAct steps
- Formats for environment

## Integration with Existing Features

### Works With Environment Manager
- Uses existing `add_to_current_env()` API
- Subject to auto-summarization (every 1 minute)
- Stored in same `env.md` file
- Benefits from CoT summarization

### Works With Context Injection
- TODO structure injected into all agent instructions
- Trajectory history available in environment context
- Agents see complete execution history

### Works With Tracking
- Complements existing tracking points:
  - Execution start
  - Task start/completion/failure
  - TODO creation ← Enhanced
  - Trajectory ← New

## Performance Considerations

### TODO Structure Tracking
- **Size:** ~50-200 bytes per task
- **Frequency:** Once per execution
- **Impact:** Minimal (single write)

### Trajectory Tracking
- **Size:** ~100-500 bytes per trajectory
- **Frequency:** Once per action (could be many)
- **Impact:** Moderate (multiple writes)
- **Mitigation:** Auto-summarization keeps size manageable

### Overall Impact
- **Memory:** ~1-5KB additional per execution
- **I/O:** Append operations (fast)
- **Benefit:** Far outweighs cost (better decisions = fewer retries)

## Configuration

Uses existing Environment Manager configuration:

```python
config = SynapseConfig()
config.env_summarization_interval = 60  # Auto-summarize
config.env_max_size_bytes = 50000      # Size threshold
```

No additional configuration needed.

## Testing

### Verification Steps

1. **Check TODO structure tracking:**
```bash
# After TODO creation, check env.md
cat outputs/synapse_state/env/env.md | grep -A 20 "TODO Task List"
```

2. **Check trajectory tracking:**
```bash
# After actor execution, check env.md
cat outputs/synapse_state/env/env.md | grep -A 10 "Action Trajectory"
```

3. **Verify in logs:**
```bash
# Look for these log messages:
# "✅ Tracked complete TODO structure in environment"
# "✅ Tracked trajectory in environment"
```

## Future Enhancements

Possible improvements (not implemented):

1. **Selective Tracking:** Only track important trajectories
2. **Aggregated Stats:** Summarize trajectories (e.g., "5 web_search calls")
3. **Pattern Detection:** Automatically identify repeated patterns
4. **Success Metrics:** Track success rate of different approaches
5. **Visual Timeline:** Generate visual execution timeline

## Related ADRs

- `environment-manager-cot-summarization.md` - Environment Manager base
- `environment-context-injection-in-todo-pipeline.md` - Context injection

## Conclusion

These enhancements provide complete visibility into both planning (TODO structure) and execution (ReAct trajectory). Every agent can see:
- What needs to be done (TODO)
- What has been tried (Trajectory)
- What worked and what didn't (Results)

This creates a comprehensive execution history that enables better decision-making, easier debugging, and continuous learning.

**Status:** ✅ Fully Implemented

---

**Implementation Summary:**
- 2 files modified
- 2 new tracking capabilities
- Complete TODO structure visible
- Complete trajectory history visible
- Integrated with existing features
- Minimal performance impact
