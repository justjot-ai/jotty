# ADR: Project Root Cleanup and Organization

**Date:** 2026-01-30  
**Status:** Implemented

## Context

The project root directory had become cluttered with numerous temporary files, analysis outputs, planning artifacts, and documentation scattered without clear organization. This made it difficult to:

- Navigate the project
- Find relevant documentation
- Distinguish between essential and temporary files
- Maintain a clean development environment
- Onboard new developers

The clutter included:
- 4+ temporary txt files (a.txt, b.txt, c.txt, d.txt)
- Multiple analysis files and timing reports
- DAG and planning files scattered in root
- Design documents in root
- Test files in root
- Duplicate review folders
- Screenshot files from testing
- Analysis Python scripts in root

## Decision

Implement a comprehensive folder structure based on best practices and user rules:

### Essential Root Files Only

Keep only essential configuration and executable files in root:
- `pyproject.toml` - Poetry configuration
- `poetry.lock` - Dependency lock
- `.gitignore` - Git ignore rules
- `*.sh` scripts - Executable shell scripts
- `README.md` - Project overview
- `PROJECT_STRUCTURE.md` - Organization guide

### Organized Directory Structure

```
docs/
├── adr/          # Architectural Decision Records
├── analysis/     # Analysis reports and findings
├── design/       # Design documents
├── planning/     # Project planning artifacts
└── review/       # A-Team reviews (consolidated)

scripts/
└── analysis/     # Analysis and processing scripts

working/
├── screenshots/  # Runtime screenshots
└── *.txt         # Temporary work files

tests/            # All test files
```

### Domain-Specific Documentation

Keep documentation with related code:
- Surface docs → `surface/`
- Synapse docs → `Synapse/docs/`
- Terminal-bench docs → `terminal-bench/`

## Implementation

### Phase 1: Create Directory Structure

```bash
mkdir -p docs/analysis docs/planning docs/design scripts/analysis working/screenshots
```

### Phase 2: Organize Files by Type

**Temporary files → `working/`:**
```bash
mv a.txt b.txt c.txt d.txt working/
```

**Analysis files → `docs/analysis/`:**
```bash
mv b_txt_analysis*.txt timing_analysis*.{md,txt} docs/analysis/
```

**Analysis scripts → `scripts/analysis/`:**
```bash
mv analyze_*.py convert_to_yaml.py scripts/analysis/
```

**Planning artifacts → `docs/planning/`:**
```bash
mv dag_*.{txt,md,json} *_dag.json *_plan*.txt tasks_detailed.txt actor_assignments.txt docs/planning/
```

**Design documents → `docs/design/`:**
```bash
mv COMPREHENSIVE_*.md MASTER_*.md START_HERE_*.md RCA_*.md FIXED_SUMMARY.md docs/design/
```

**Browser docs → `surface/`:**
```bash
mv AUTHENTICATION_*.md BROWSER_*.md RUN_BROWSER_*.md WHY_TERMINAL_*.md surface/
```

**Test files → `tests/`:**
```bash
mv test_*.py tests/
```

**Screenshots → `working/screenshots/`:**
```bash
mv *.png working/screenshots/
```

**Consolidate reviews → `docs/review/`:**
```bash
mv review/*.md docs/review/
rmdir review
```

### Phase 3: Documentation

Created comprehensive documentation:
- `README.md` - Project overview and quick start
- `PROJECT_STRUCTURE.md` - Detailed structure guide
- This ADR

## Rationale

### Follows User Rules

1. ✅ "Do not create any md file for any changes" - Created ADR instead
2. ✅ "Always add A-team reviews in a folder at path docs/review" - Consolidated reviews
3. ✅ "tests should always be created in tests folder" - Moved test files
4. ✅ "Always create documentations inside docs folder" - Organized docs
5. ✅ "Always write code in modular fashion" - Clear separation of concerns

### Industry Best Practices

1. **Clean Root** - Only essential config files
2. **Documentation Organization** - Structured by type and purpose
3. **Separation of Concerns** - Code, docs, tests, temp files all separated
4. **Discoverability** - Clear naming and logical grouping
5. **Maintainability** - Easy to find and update files

### Benefits

**For Developers:**
- Quick navigation to relevant files
- Clear understanding of project structure
- Easy to find documentation
- Less cognitive overhead

**For Maintenance:**
- Clear rules for where new files go
- Easy to identify and clean temporary files
- Reduced confusion about file purpose
- Better version control

**For Onboarding:**
- README provides overview
- PROJECT_STRUCTURE.md explains organization
- ADRs document decisions
- Clear examples in proper locations

## File Movement Summary

| File Type | From | To |
|-----------|------|-----|
| Temporary text files | Root | `working/` |
| Analysis reports | Root | `docs/analysis/` |
| Analysis scripts | Root | `scripts/analysis/` |
| Planning artifacts | Root | `docs/planning/` |
| Design documents | Root | `docs/design/` |
| Browser docs | Root | `surface/` |
| Test files | Root | `tests/` |
| Screenshots | Root | `working/screenshots/` |
| Review files | `review/` | `docs/review/` |

## Verification

After cleanup, root contains only:

**Files:**
- `.gitignore`
- `poetry.lock`
- `pyproject.toml`
- `README.md`
- `PROJECT_STRUCTURE.md`
- `*.sh` scripts (executable)

**Directories:**
- `.git/`, `.venv/` (standard)
- `app/`, `cursor/` (application)
- `docs/` (organized documentation)
- `logs/`, `profiling/`, `runs/` (runtime)
- `scripts/` (organized utilities)
- `surface/`, `Synapse/`, `Synapse_new/` (core systems)
- `surface_synapse/` (integration)
- `terminal-bench/` (subsystem)
- `tests/` (test suite)
- `working/` (temporary)

## Consequences

### Positive

1. ✅ Clean, professional project structure
2. ✅ Easy to navigate and find files
3. ✅ Follows user rules and best practices
4. ✅ Better git history (less root clutter)
5. ✅ Clear separation of permanent vs temporary files
6. ✅ Easier to maintain and extend
7. ✅ Better onboarding experience

### Negative

1. ⚠️ Existing links/references may need updating
2. ⚠️ Team members need to learn new structure
3. ⚠️ Scripts with hardcoded paths need updates

### Mitigation

- `PROJECT_STRUCTURE.md` provides clear mapping
- `README.md` includes quick reference
- Most files were temporary and not referenced
- Core code structure unchanged (only docs moved)

## Maintenance Guidelines

### When Adding New Files

**Analysis outputs:**
```bash
# ✅ Correct
mv report.txt docs/analysis/

# ❌ Wrong
# Leaving in root
```

**Design decisions:**
```bash
# ✅ Correct
vim docs/adr/new-feature-decision.md

# ❌ Wrong
vim NEW_FEATURE_DESIGN.md  # in root
```

**Temporary work:**
```bash
# ✅ Correct
mv test_output.txt working/

# ❌ Wrong
# Leaving in root
```

**Tests:**
```bash
# ✅ Correct
vim tests/test_new_feature.py

# ❌ Wrong
vim test_new_feature.py  # in root
```

### Regular Cleanup

**Weekly:**
- Review `working/` folder
- Delete obsolete temporary files
- Archive old screenshots

**Monthly:**
- Review logs in `logs/`
- Clean up old profiling data
- Update documentation

**Per Release:**
- Verify all docs are current
- Clean `working/` completely
- Archive planning artifacts if needed

## Future Improvements

1. **Git Hooks** - Prevent files from being added directly to root
2. **Automated Cleanup** - Script to identify and suggest file moves
3. **Documentation Generator** - Auto-update PROJECT_STRUCTURE.md
4. **Linting** - Enforce file organization in CI/CD

## Related ADRs

- [Browser Automation Tools](browser-automation-tools.md)
- [Agent Tool Assignment Refactoring](agent-tool-assignment-refactoring.md)
- [Browser Authentication Persistence](browser-authentication-persistence.md)

## References

- User Rules (`.cursor/rules/`)
- Python Package Layout Best Practices
- Git Repository Organization Guidelines

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Reviewed:** Pending A-Team Review  
**Implementation:** Complete
