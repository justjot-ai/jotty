# ADR: Native Browser Embedding in Electron

## Status
Accepted

## Date
2026-02-02

## Context

The previous architecture used a screenshot-based approach to display the browser in Electron:
- Python/Selenium controlled Chrome with CDP enabled (port 9222)
- Electron connected to Chrome via CDP WebSocket
- Screenshots were captured every 200-500ms and rendered to a canvas
- User interactions were translated from canvas coordinates to CDP input events

This approach had several limitations:
1. **Latency**: Screenshot-based display introduces visual delay
2. **Resource intensive**: Constant screenshot capture consumes CPU/memory
3. **Not truly interactive**: Feels like VNC rather than native browser
4. **Complex coordinate translation**: Canvas-to-viewport coordinate mapping required

## Decision

Move browser control to Electron's native `BrowserView`, allowing both:
1. **User interaction**: Native browser experience - click, type, scroll directly
2. **Backend automation**: Python sends commands via WebSocket → Electron → BrowserView

### New Architecture

```
┌─────────────────┐              ┌──────────────────────────────────┐
│  Python Backend │              │           Electron                │
│                 │   WebSocket  │  ┌────────────────────────────┐  │
│  navigate()     │ ──────────▶  │  │     BrowserView            │  │
│  click()        │              │  │  (native Chromium browser) │  │
│  type()         │              │  │                            │  │
└─────────────────┘              │  │  ◀── User clicks/types     │  │
                                 │  └────────────────────────────┘  │
                                 └──────────────────────────────────┘
```

### Components Modified

1. **Electron main.js**
   - Added browser automation IPC handlers (click, type, scroll, fill, etc.)
   - BrowserView already existed, now fully utilized

2. **Electron preload.js**
   - Exposed browserAPI with all automation methods

3. **Electron app.js (renderer)**
   - Added `handleBrowserCommand()` to forward WebSocket commands to BrowserView
   - Added `browser_command` message type handling

4. **Python browser_tools.py**
   - Added `ElectronBrowserClient` async class for WebSocket communication
   - Added `electron_*` sync helper functions
   - Added `_send_browser_command_sync()` for broadcasting commands

5. **Python agent_session_manager.py**
   - Added `broadcast_message()` method for arbitrary WebSocket messages

### Supported Browser Commands

| Command | Description |
|---------|-------------|
| `navigate` | Navigate to URL |
| `click` | Click at coordinates or selector |
| `type` | Type text (keyboard simulation) |
| `fill` | Fill form field (direct value set) |
| `scroll` | Scroll page or element |
| `execute_js` | Execute JavaScript |
| `get_content` | Get HTML content |
| `get_text` | Get text content |
| `screenshot` | Capture screenshot |
| `wait_for_selector` | Wait for element |
| `get_cookies` | Get cookies |
| `set_cookie` | Set cookie |
| `clear_cookies` | Clear cookies |

## Consequences

### Positive
- **Native browser experience**: No latency, true interactivity
- **Lower resource usage**: No continuous screenshot capture
- **Simpler code**: Direct API calls instead of coordinate translation
- **Better UX**: User can interact naturally with browser

### Negative
- **Session isolation**: BrowserView has its own session (separate from Selenium)
- **Backward compatibility**: CDP screenshot mode still available for legacy use
- **WebSocket dependency**: Requires WebSocket connection for backend control

### Migration Path
- Set `USE_ELECTRON_BROWSER = True` in browser_tools.py to use new mode
- Old CDP/screenshot mode still works by setting to `False`
- Can switch modes dynamically if needed

## Notes

The old CDP screenshot mode is preserved for backward compatibility and fallback scenarios. The module box for BrowserExecutor now shows a status indicator instead of live screenshots when using native BrowserView mode.
