# ADR: Terminal Module Card Shows Actual Output Instead of Logs

## Status
Accepted

## Context
The Terminal module card in the Electron app was only showing log summaries like `"📡 output (123 chars)"` instead of actual terminal output. This was because:

1. `BrowserExecutor` had special handling in `handleAgentEvent()` to route events to `handleBrowserEvent()` which renders content
2. `TerminalExecutor` events were being summarized and sent to `addSystemLog()` as generic log entries
3. The `TerminalViewHandler` class existed but wasn't being used for the module box

## Decision
Add special handling for `TerminalExecutor` events similar to `BrowserExecutor`:

1. **Updated `createModuleBox()`**: Added terminal-specific HTML structure with `module-terminal-content` and `terminal-output-area` elements (similar pattern to browser canvas)

2. **Added `handleTerminalEvent()`**: Routes terminal events (output, command, error, status) to display actual content in the terminal card

3. **Added `appendTerminalOutput()`**: Renders terminal output with ANSI escape code stripping, proper styling for commands/errors/output, and auto-scroll

4. **Updated `handleAgentEvent()`**: Added routing for `TerminalExecutor` and `terminal_executor_agent` to `handleTerminalEvent()`

5. **Added CSS styles**: Styled `.module-terminal-content`, `.terminal-output-area`, and `.terminal-output-line` variants

## Consequences
- Terminal card now shows actual command output instead of just log summaries
- Commands are styled in blue, errors in red, regular output in light gray
- Terminal output auto-scrolls to bottom as new content arrives
- Limited to 1000 lines to prevent memory issues
- ANSI escape codes are stripped for clean display

## Files Modified
- `electron-app/src/renderer/js/agent-view-manager.js`
- `electron-app/src/renderer/css/agent-views.css`
