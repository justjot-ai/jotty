# ADR: Top Bar Buttons Removal

**Date**: 2026-02-02  
**Status**: Implemented  
**Context**: Electron UI Simplification

## Decision

Removed all buttons from the top bar except the theme button to simplify the UI.

## Changes Made

### HTML (`electron-app/src/renderer/index.html`)
- Removed Help button (`/help`)
- Removed Stats button (`/status`)
- Removed Clear button (`/clear`)
- Removed window control buttons (minimize, maximize, close)
- Kept only the Theme button in the center

### JavaScript (`electron-app/src/renderer/js/app.js`)
- Removed event listeners for window control buttons
- Removed event listeners for command buttons
- Added debug logging for theme button initialization
- Added null checks for theme button and menu elements

## Technical Details

The theme dropdown functionality remains intact:
- Theme button toggles the dropdown menu
- Supports 17 themes (8 dark, 9 light)
- Click outside closes the dropdown
- ESC key closes the dropdown
- Scrollable menu for better organization

### Dark Themes (8)
1. 🌙 Midnight - Original blue-tinted dark theme
2. 🌊 Deep Ocean - Deep blue ocean theme
3. ⚫ Carbon - Neutral gray theme
4. 💎 Obsidian - VS Code inspired dark
5. 🌲 Forest - Green forest theme (#2a3a2e base)
6. 🔮 Purple Haze - Purple/violet theme
7. 🌹 Crimson Night - Red/crimson theme
8. 🪨 Slate - Modern slate gray theme

### Light Themes (9)
1. 🌅 Dawn - Warm orange/peach theme
2. 🤍 Pearl - Clean white/gray theme
3. ❄️ Arctic - Cool blue theme
4. 🍦 Vanilla - Warm yellow theme
5. 🌸 Cherry Blossom - Pink theme
6. 💜 Lavender - Purple/lavender theme
7. 🍃 Mint - Green/mint theme
8. 🍑 Peach - Warm peach/orange theme
9. ☁️ Sky - Light blue sky theme

## Debugging

Added console logs to verify:
- Theme button element is found during initialization
- Theme menu element is found during initialization
- Click event is properly attached
- Toggle state is correctly applied

## Impact

- Cleaner, more minimal UI
- Users can still change themes
- Window controls removed (users can use OS-level controls)
- Command buttons removed (functionality can be accessed through other means if needed)
