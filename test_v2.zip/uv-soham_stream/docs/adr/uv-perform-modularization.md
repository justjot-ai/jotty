# ADR: UV Perform Endpoint Modularization

**Status**: Implemented  
**Date**: 2026-01-31  
**Author**: Anshul Chauhan

## Context

The `/perform` endpoint initially had all business logic embedded in the API layer (`perform.py`), including:
- Swarm creation and lifecycle management
- DSPy configuration
- Browser initialization
- Agent setup
- Task execution logic

This violated separation of concerns and made the code:
- Hard to test
- Difficult to maintain
- Not reusable from other parts of the application
- Inconsistent with the existing service layer pattern

## Decision

Refactored the `/perform` endpoint to follow proper layered architecture:

### New Structure

```
uv/src/uv/
├── api/v1/
│   └── perform.py          # HTTP layer only (180 lines)
├── services/
│   ├── swarm_service.py    # Swarm lifecycle (230 lines)
│   └── task_service.py     # Task execution (130 lines)
```

### Layer Responsibilities

#### 1. API Layer (`api/v1/perform.py`)

**Purpose**: HTTP request/response handling only

```python
@router.post("/perform")
async def perform_task(request: PerformTaskRequest):
    # Get service
    swarm_service = get_swarm_service()
    task_service = TaskService(swarm_service.swarm)
    
    # Execute
    result = await task_service.execute_task(request.task, request.context)
    
    # Return response
    return PerformTaskResponse(**result)
```

**Responsibilities**:
- Request validation (Pydantic)
- HTTP error handling
- Response formatting
- Logging HTTP events

**Does NOT**:
- Create swarms
- Execute tasks
- Manage browser/agents
- Handle business logic

#### 2. Service Layer (`services/`)

**`swarm_service.py`** - Swarm Lifecycle Management

```python
class SwarmService:
    def initialize() -> bool:
        # Create browser, agents, conductor
        # Configure DSPy, Synapse
        
    def cleanup() -> None:
        # Close browser
        # Clean up resources
        
    def is_initialized() -> bool:
        # Check swarm status
```

**Responsibilities**:
- Swarm creation and configuration
- Browser lifecycle
- Agent initialization
- DSPy setup
- Resource cleanup

**`task_service.py`** - Task Execution

```python
class TaskService:
    async def execute_task(instruction, context) -> Dict:
        # Run task through swarm
        # Return structured result
        
    async def execute_task_stream(instruction, context):
        # Yield progress events
        # Stream task execution
```

**Responsibilities**:
- Task execution logic
- Result extraction and formatting
- Progress streaming
- Event generation

### Architecture Diagram

```
┌─────────────────────────────────────────┐
│         API Layer (perform.py)          │
│  • HTTP request handling                │
│  • Validation                           │
│  • Response formatting                  │
└────────────┬────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────┐
│    Service Layer (swarm_service.py)     │
│  • Swarm lifecycle                      │
│  • Browser management                   │
│  • Agent initialization                 │
└────────────┬────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────┐
│    Service Layer (task_service.py)      │
│  • Task execution                       │
│  • Progress streaming                   │
│  • Result formatting                    │
└────────────┬────────────────────────────┘
             │
             ↓
┌─────────────────────────────────────────┐
│      Synapse & Surface (external)       │
│  • Conductor orchestration              │
│  • Executor agents                      │
│  • Tools (browser, terminal, search)    │
└─────────────────────────────────────────┘
```

## Implementation Details

### Singleton Pattern for Swarm

```python
# services/swarm_service.py
_swarm_service = SwarmService()

def get_swarm_service() -> SwarmService:
    return _swarm_service
```

- Single global instance
- Initialized at startup via `main.py`
- Accessed via function (dependency injection ready)

### Application Integration

```python
# main.py
async def lifespan(app: FastAPI):
    # Startup
    swarm_service = get_swarm_service()
    swarm_service.initialize()
    
    yield
    
    # Shutdown
    swarm_service.cleanup()
```

### Streaming Support

Added `/perform/stream` endpoint with Server-Sent Events:

```python
@router.post("/perform/stream")
async def perform_task_stream(request):
    task_service = TaskService(swarm)
    
    async def event_generator():
        async for event in task_service.execute_task_stream(...):
            yield f"data: {json.dumps(event)}\n\n"
    
    return StreamingResponse(event_generator(), media_type="text/event-stream")
```

Event types:
- `status`: Progress updates
- `result`: Final output
- `error`: Error information

## Benefits

### 1. Separation of Concerns

- API layer: HTTP only
- Service layer: Business logic
- Clear boundaries

### 2. Testability

```python
# Easy to test services in isolation
def test_task_execution():
    swarm_service = SwarmService()
    swarm_service.initialize()
    
    task_service = TaskService(swarm_service.swarm)
    result = await task_service.execute_task("test task")
    
    assert result['success'] == True
```

### 3. Reusability

Services can be used from anywhere:

```python
# Use from CLI
from uv.services.swarm_service import get_swarm_service
from uv.services.task_service import TaskService

swarm = get_swarm_service()
task_service = TaskService(swarm.swarm)
result = await task_service.execute_task("My task")
```

### 4. Maintainability

- Services are focused and cohesive
- Easy to find and modify logic
- Consistent with auth/user services

### 5. Streaming Support

- Real-time progress updates
- Better UX for long-running tasks
- Standard SSE format

## File Sizes

| File | Before | After | Reduction |
|------|--------|-------|-----------|
| `perform.py` | 453 lines | 180 lines | **60% smaller** |
| `swarm_service.py` | N/A | 230 lines | New |
| `task_service.py` | N/A | 130 lines | New |
| **Total** | 453 lines | 540 lines | Better organized |

## API Changes

### New Endpoints

**Original**:
- `POST /api/v1/perform` - Execute task

**New**:
- `POST /api/v1/perform` - Execute task (non-streaming)
- `POST /api/v1/perform/stream` - Execute task with SSE streaming

### Request/Response

No changes to existing endpoint. Streaming is additive.

## Usage Examples

### Non-Streaming (Original)

```bash
curl -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{"task": "What are the top 3 Python frameworks?"}'
```

Response:
```json
{
  "success": true,
  "output": "Based on research...",
  "agents_used": ["WebSearchAgent"],
  "execution_time": 8.5,
  "error": null
}
```

### Streaming (New)

```bash
curl -N -X POST "http://localhost:8000/api/v1/perform/stream" \
  -H "Content-Type: application/json" \
  -d '{"task": "What are the top 3 Python frameworks?"}'
```

Response (SSE):
```
data: {"type":"status","message":"Task started","data":{...}}

data: {"type":"status","message":"Executing task through Synapse swarm","data":{...}}

data: {"type":"status","message":"Task completed","data":{...}}

data: {"type":"result","message":"Final output","data":{"success":true,...}}
```

## Testing

```bash
# Non-streaming
./example_perform.sh

# Streaming
./example_perform_stream.sh

# Service layer tests
pytest tests/test_swarm_service.py
pytest tests/test_task_service.py
```

## Migration

No breaking changes. Existing `/perform` endpoint works identically.

## Future Enhancements

1. **Service Mocking**: Easy to mock services in tests
2. **Async/Sync Variants**: Service layer can support both
3. **Multiple Swarms**: SwarmService can manage a pool
4. **Custom Agents**: Service layer can register new agents
5. **Metrics**: Service layer can emit metrics
6. **Caching**: Service layer can cache results

## Comparison with Other Services

Follows the same pattern as existing services:

```
services/
├── auth_service.py      # Authentication logic
├── user_service.py      # User management logic
├── swarm_service.py     # Swarm lifecycle (new)
└── task_service.py      # Task execution (new)
```

All services:
- Pure Python classes
- No HTTP dependencies
- Testable in isolation
- Reusable from anywhere

## References

- Original implementation: `uv/src/uv/api/v1/perform.py` (v1)
- Service pattern: `uv/src/uv/services/auth_service.py`
- Synapse integration: `surface_synapse/integration.py`

## Conclusion

The modularization:
- ✅ Follows FastAPI best practices
- ✅ Matches existing service layer pattern
- ✅ Improves testability and maintainability
- ✅ Enables streaming support
- ✅ No breaking changes to API

The API layer is now thin and focused on HTTP, while business logic lives in reusable service modules.
