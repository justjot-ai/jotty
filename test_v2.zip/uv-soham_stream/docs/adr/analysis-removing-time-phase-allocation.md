# Analysis: Removing All Time/Phase Allocation Logic

**Date**: 2026-02-05  
**Status**: ✅ Implemented - All Time/Phase Allocation Removed  
**Question**: What would happen if we remove all time/phase allocation logic from Synapse?

## Implementation Status

**✅ COMPLETED**: All time/phase allocation logic has been removed from Synapse:
- TimeBudgetPlanner removed
- TimeAwareExecutor removed  
- Phase-based execution removed
- Time-aware context injection removed
- Stuck detection integration removed
- Config sections removed

**What Remains**:
- Basic `actor_timeout` config (simple timeout per actor)
- TimeoutWarningManager (independent warning system)

## Current Time/Phase Allocation Components

### 1. **TimeBudgetPlanner** (Dynamic Time Allocation)
- **Purpose**: Uses LLM to dynamically allocate time budgets based on task complexity
- **Output**: Phase allocations (exploration: 15%, validation: 10%, MVP: 40%, etc.) + per-actor timeout overrides
- **Location**: `Synapse/core/time_budget_planner.py`
- **Usage**: Called once per run to plan time budgets

### 2. **TimeAwareExecutor** (Phase Management)
- **Purpose**: Manages execution phases with time budgets
- **Phases**: EXPLORATION → VALIDATION → MVP → REFINEMENT → VERIFICATION
- **Features**:
  - Time boxing per phase
  - Stuck detection
  - Time reallocation between phases
  - Phase guidance injection
- **Location**: `Synapse/core/time_aware_execution.py`
- **Usage**: Active throughout execution, tracks phase progress

### 3. **Time Context Injection** (Actor Awareness)
- **Purpose**: Injects time awareness into actor context
- **Provides**:
  - Current phase and remaining time
  - Time pressure indicators (low/medium/high/critical)
  - Phase-specific guidance
  - Priority messages ("CRITICAL TIME: Execute simplest solution NOW")
- **Location**: `Synapse/core/conductor.py` line 6452-6485
- **Usage**: Injected into every actor execution context

### 4. **TimeoutWarningManager** (Warning System)
- **Purpose**: Warns agents when approaching timeout
- **Features**: Warns at 75%, critical at 90%
- **Location**: `Synapse/core/conductor.py` line 1753
- **Usage**: Tracks overall timeout, independent of phases

## What Would Happen If Removed

### ✅ **What Would Still Work**

1. **Core Execution**: Actors would still execute tasks normally
2. **Basic Timeouts**: `actor_timeout` config would still work (simple timeout per actor)
3. **Task Execution**: DAG execution, task dependencies, agent selection all work
4. **Learning Systems**: Q-learning, TD(λ), memory systems unaffected
5. **Validation**: Architect/Auditor validation unaffected

### ❌ **What Would Break/Change**

1. **Time Context Injection** (Line 6452-6485):
   - Currently injects phase guidance, time pressure, remaining time
   - **Impact**: Actors lose awareness of time pressure and phase goals
   - **Workaround**: Could inject simple timeout warnings instead

2. **Stuck Detection**:
   - Currently integrated with TimeAwareExecutor
   - **Impact**: Would lose automatic stuck pattern detection
   - **Workaround**: Could keep StuckDetector standalone

3. **Phase-Based Guidance**:
   - Currently provides phase-specific instructions ("Focus on MVP", "Validate approach first")
   - **Impact**: Agents lose structured execution guidance
   - **Workaround**: None - this is the core value

4. **Time Reallocation**:
   - Currently allows moving time from one phase to another
   - **Impact**: Would lose adaptive time management
   - **Workaround**: None

### 🔧 **What Would Need Changes**

1. **Conductor.run()** (Line 2906-2919):
   - Currently creates TimeAwareExecutor and starts EXPLORATION phase
   - **Change**: Remove initialization, keep simple timeout tracking

2. **Context Building** (Line 6452-6485):
   - Currently injects time-aware context
   - **Change**: Either remove entirely or replace with simple timeout warnings

3. **Config Files**:
   - Remove `time_budget_planning` section
   - Remove `time_aware` section
   - Keep `timeout_warning` (independent feature)

## Utility Analysis

### 🎯 **High Utility Features**

1. **Time Pressure Awareness**:
   - **Value**: Critical for preventing timeouts
   - **Example**: "CRITICAL TIME: Execute simplest solution NOW" prevents agents from over-engineering
   - **Impact if removed**: Higher timeout rate, agents waste time on perfectionism

2. **Stuck Detection**:
   - **Value**: Detects repetitive failure loops
   - **Example**: Agent trying same failing approach 3+ times
   - **Impact if removed**: Agents can get stuck in loops without intervention

3. **Phase Guidance**:
   - **Value**: Provides structured execution approach
   - **Example**: "MVP phase: Focus on getting working solution, skip optimizations"
   - **Impact if removed**: Agents may skip validation or spend too much time exploring

### ⚖️ **Medium Utility Features**

1. **Dynamic Time Allocation** (TimeBudgetPlanner):
   - **Value**: Adapts to task complexity
   - **Example**: Complex tasks get more exploration time
   - **Impact if removed**: Fixed allocations may not fit all tasks, but defaults work reasonably well
   - **Cost**: Extra LLM API call

2. **Per-Actor Timeout Overrides**:
   - **Value**: Optimizes timeouts per agent based on history
   - **Example**: TerminalExecutor gets 120s, PresentationBuilder gets 180s
   - **Impact if removed**: All actors use same timeout (may be inefficient but simpler)

3. **Time Reallocation**:
   - **Value**: Adaptive time management
   - **Example**: Move time from refinement to MVP if MVP taking longer
   - **Impact if removed**: Fixed allocations, less adaptive but simpler

### 🔻 **Low Utility Features**

1. **Phase Tracking**:
   - **Value**: Logging/debugging visibility
   - **Impact if removed**: Less visibility but doesn't affect execution

2. **Phase-Specific Fail-Fast**:
   - **Value**: Validation phase fails fast
   - **Impact if removed**: Validation might take longer but still works

## Simplified Alternative: Minimal Time Management

If removing all phase logic, you could keep:

### Option 1: Simple Timeout Only
```python
# Just track total timeout, no phases
total_timeout = actor_timeout  # e.g., 900s
elapsed = time.time() - start_time
remaining = total_timeout - elapsed

# Simple warning injection
if remaining < 120:
    context['time_pressure'] = 'critical'
    context['message'] = 'Execute simplest solution NOW'
elif remaining < 300:
    context['time_pressure'] = 'high'
    context['message'] = 'Focus on core task'
```

**Pros**:
- ✅ Much simpler code
- ✅ No phase management overhead
- ✅ Still prevents timeouts with warnings
- ✅ No LLM calls for time budgeting

**Cons**:
- ❌ No structured execution guidance
- ❌ No stuck detection integration
- ❌ Agents may waste time on wrong approach
- ❌ Less adaptive to task complexity

### Option 2: Keep Stuck Detection Only
```python
# Keep StuckDetector but remove phases
stuck_detector = StuckDetector()
# Use it independently without phase context
```

**Pros**:
- ✅ Detects repetitive failures
- ✅ Simpler than full phase system
- ✅ Still prevents infinite loops

**Cons**:
- ❌ Less context-aware (no phase-specific patterns)
- ❌ May be less effective without phase context

## Recommendation

### **Keep Minimal Version** (Recommended)

**Remove**:
- ❌ TimeBudgetPlanner (dynamic allocation) - Extra LLM call, marginal benefit
- ❌ Phase management (EXPLORATION/VALIDATION/MVP/REFINEMENT/VERIFICATION) - Complex, may not be necessary

**Keep**:
- ✅ Simple timeout tracking (total time remaining)
- ✅ Time pressure warnings (critical/high/medium)
- ✅ Stuck detection (standalone, without phase context)
- ✅ TimeoutWarningManager (warns at 75%/90%)

**Result**:
- **Simpler**: ~500 lines of code removed
- **Still effective**: Prevents timeouts with warnings
- **No LLM overhead**: No extra API calls
- **Easier to maintain**: Less complex state management

### **Full Removal** (If You Want Maximum Simplicity)

**Remove Everything**:
- ❌ TimeBudgetPlanner
- ❌ TimeAwareExecutor
- ❌ Phase management
- ❌ Time context injection
- ❌ Stuck detection (or keep standalone)

**Keep Only**:
- ✅ Basic `actor_timeout` config (simple timeout per actor)
- ✅ TimeoutWarningManager (optional, for warnings)

**Result**:
- **Simplest**: ~1000+ lines removed
- **Risk**: Higher timeout rate, agents may waste time
- **Trade-off**: Simplicity vs. timeout prevention

## Code Impact Summary

### Files That Would Change

1. **`Synapse/core/conductor.py`**:
   - Remove TimeBudgetPlanner initialization (line 1779-1785)
   - Remove TimeAwareExecutor creation (line 2906-2919)
   - Simplify context injection (line 6452-6485)
   - **Lines affected**: ~50-100 lines

2. **`Synapse/core/time_budget_planner.py`**:
   - **Can delete entirely** (~210 lines)

3. **`Synapse/core/time_aware_execution.py`**:
   - **Can delete entirely** (~637 lines)

4. **`Synapse/default_config.yml`**:
   - Remove `time_budget_planning` section
   - Remove `time_aware` section
   - Keep `timeout_warning` (independent)

### Total Code Reduction

- **~850 lines removed** (if removing everything)
- **~500 lines removed** (if keeping minimal timeout warnings)

## Conclusion

**Utility Assessment**:
- **High**: Time pressure awareness, stuck detection
- **Medium**: Dynamic allocation, phase guidance
- **Low**: Phase tracking, complex reallocation

**Recommendation**: **Keep minimal version** - Remove phase management but keep simple timeout warnings and stuck detection. This provides most of the timeout prevention benefit with much less complexity.

**If you want maximum simplicity**: Remove everything and rely on basic `actor_timeout` config. Accept higher timeout risk for simpler codebase.
