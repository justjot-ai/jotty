# ADR: Dynamic Task Planner Integration

**Date:** 2026-01-12  
**Status:** Accepted  
**Context:** Synapse Conductor, MarkovianTODO

## Problem

The `Conductor._initialize_todo_from_goal()` method created **flat, generic tasks** for each agent:

```python
# BEFORE (Bug)
self.todo.add_task(
    task_id=f"{name}_main",
    description=f"Execute {name} pipeline for: {goal[:100]}",  # ← GENERIC!
    actor=name,
    depends_on=[f"{prev}_main" for prev in prev_selected],
    priority=1.0 - (i * 0.1)
)
```

### Information Loss (Shannon Analysis)

| Task Type | Information Content | Example |
|-----------|---------------------|---------|
| Generic | ~5 bits | "Execute CodeMaster pipeline" |
| Semantic | ~15 bits | "Run git reflog to find dangling commits" |
| **Loss** | **~10 bits/task** | Wasted semantic guidance |

### Root Cause

Two systems existed but were **NOT connected**:

1. **MarkovianTODO** - Had hierarchical data structures but received flat input
2. **AgenticAgentSelector** - Selected WHICH agents, not WHAT they do

Missing: LLM-based goal decomposition → TODO initialization

## Decision

Implement **DynamicTaskPlanner** and integrate it into the Conductor.

### Components Added

1. **`DynamicTaskPlanner`** class (`dynamic_task_planner.py`):
   - Uses DSPy ChainOfThought with `TaskDecompositionSignature`
   - Decomposes goals into semantic subtasks
   - Tracks `inputs_needed` and `outputs_produced` for data flow
   - Validates plans for cycles and missing dependencies
   - Falls back to sequential tasks if LLM fails

2. **`MarkovianTODO.initialize_from_plan()`** method (`roadmap.py`):
   - Clears existing state
   - Creates SubtaskState for each decomposed task
   - Calculates priority from dependency depth
   - Topologically sorts execution order
   - Stores `inputs_needed`/`outputs_produced` in intermediary values

3. **Conductor Integration** (`conductor.py`):
   - New `enable_dynamic_planning` flag (default: True)
   - Imports DynamicTaskPlanner when available
   - Calls planner before fallback sequential task creation
   - Passes context (kb_info, conversation_history) to planner

## Task Decomposition

### Prompt Design

```
DECOMPOSITION PRINCIPLES:
1. ATOMICITY: Each subtask = single coherent action
2. CLARITY: Description specifies WHAT to do
3. DEPENDENCIES: Explicit data flow between subtasks
4. PARALLELISM: Independent subtasks have no dependencies

BAD:  "Execute CodeMaster pipeline"
GOOD: "Run git reflog to find dangling commits"
```

### Output Format

```json
{
  "tasks": [
    {
      "task_id": "find_current_branch",
      "agent": "CodeMaster",
      "description": "Get current git branch using 'git branch --show-current'",
      "depends_on": [],
      "inputs_needed": [],
      "outputs_produced": ["current_branch"]
    },
    {
      "task_id": "find_lost_commits",
      "agent": "CodeMaster",
      "description": "Search git reflog for commits not in branch history",
      "depends_on": ["find_current_branch"],
      "inputs_needed": ["current_branch"],
      "outputs_produced": ["lost_commit_shas"]
    }
  ]
}
```

## Consequences

### Positive
- Semantic task descriptions guide agent execution
- Explicit data flow enables better dependency tracking
- Credit assignment works at subtask level
- Parallelizable tasks run in parallel (no false dependencies)
- Better debugging with meaningful task names

### Negative
- Additional LLM call for decomposition (~200ms overhead)
- Complex goals may exceed max_tasks_per_agent limit
- LLM may produce invalid plans (mitigated by fallback)

### Risk Mitigation

| Risk | Mitigation |
|------|------------|
| LLM inconsistency | Structured JSON output + validation |
| Circular dependencies | Cycle detection + rejection |
| Over-decomposition | max_tasks_per_agent=10 limit |
| LLM failure | Fallback to sequential agent tasks |

## Files Changed

| File | Change |
|------|--------|
| `dynamic_task_planner.py` | NEW - LLM-based decomposition |
| `roadmap.py` | ADD `initialize_from_plan()`, `_topological_sort()` |
| `conductor.py` | ADD `enable_dynamic_planning`, integrate planner |

## Example

**Before (Bug):**
```
Goal: "Find lost git changes and merge to master"
Tasks:
  - CodeMaster_main: "Execute CodeMaster pipeline for: Find lost git..."
```

**After (Fix):**
```
Goal: "Find lost git changes and merge to master"
Tasks:
  - find_current_branch: "Get current git branch using 'git branch --show-current'"
  - search_reflog: "Search git reflog for commits not in current branch"
  - identify_lost_commits: "Compare reflog entries with branch history"
  - cherry_pick_changes: "Cherry-pick identified commits to master"
  - verify_merge: "Verify changes are present in master branch"
```

## Bug Fix: Conductor Termination Logic

**Date:** 2026-01-12

**Problem:** The Conductor's main loop would `break` when `get_next_task()` returned `None`, even if there were pending tasks with unsatisfied dependencies. This caused 8/10 tasks to complete but 2 tasks to be abandoned.

**Fix:** Enhanced the termination logic in `conductor.py`:
1. Check for pending/blocked/in_progress counts before breaking
2. Retry `unblock_ready_tasks()` to catch edge cases
3. Log which tasks are stuck and WHY (missing dependencies)
4. Only break when truly no work remains

## Bug Fix: Actor Receiving Full Goal Instead of Task

**Date:** 2026-01-12

**Problem:** Actors received the FULL USER GOAL as their `query` parameter instead of the specific TODO task description. This caused:
- Actor doing ALL work in ONE call (9 things instead of 1)
- TODO tracking misaligned with actual work
- Subsequent tasks confused (work already done)
- Empty command loops

**Root Cause:**
```python
# BUG - Line 4092
resolved_kwargs['query'] = kwargs['goal']  # ← FULL GOAL!
```

**Fix:**
```python
# FIXED
resolved_kwargs['query'] = task.description  # ← SPECIFIC TASK!
```

Now each actor iteration receives only its assigned TODO task, enabling proper sequential task execution.

## A-Team Review

**Approved:** 2026-01-12

- **Marcus:** "This is the fix we should have made months ago"
- **Sarah:** "Finally, semantic task descriptions"
- **Viktor:** "Clean architecture with proper fallback"
- **Luna:** "Better debugging with meaningful task names"
- **Raj:** "Security review passed"

## References

- A-Team Review: `review/dynamic-task-planner-integration-review.md`
- Research: Recursive Language Models (Welleck et al., 2019)
- Research: Hierarchical RL (Sutton MAXQ, Feudal RL)
