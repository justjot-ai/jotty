# Browser State Reset Per API Call

**Status:** Implemented  
**Date:** 2026-02-02  
**Decision Makers:** Development Team  

## Context

UV uses a shared browser instance that is created once at application startup and reused across all `/perform` API calls. While this approach is efficient (avoiding the 1-2 second browser startup overhead), it creates a critical issue: **browser state persists between API calls**.

### Problem

When the same browser instance is used across multiple API requests:
- **Cookies persist** - Authentication state from one task affects another
- **localStorage/sessionStorage persist** - Data leakage between tasks
- **Open tabs accumulate** - Previous task's tabs remain open
- **Page state persists** - Current URL, form data, etc. carry over
- **Cache persists** - Previous task's cached resources may interfere

This breaks task isolation and can cause:
1. Unexpected behavior (e.g., already logged in when task expects fresh state)
2. Security issues (credentials/tokens leak between tasks)
3. Test unreliability (previous task state affects current task)
4. Resource accumulation (tabs, memory, cache grow over time)

### Current Architecture

```
Application Startup:
  ├─ SwarmService.initialize()
  │   └─ Creates single shared browser instance
  │       └─ Stored in _shared_resources
  │
Per API Call (/perform):
  ├─ TaskService.execute_task_stream()
  │   ├─ Creates fresh Conductor instance ✅
  │   └─ Uses SAME browser instance ❌
```

## Decision

**Implement browser state reset at the start of each `/perform` API call** without creating new browser instances.

### Solution: Browser Reset Function

Created `reset_browser_state()` function in `surface/tools/browser_tools.py` that:

1. **Closes extra tabs** - Keeps only the first tab, closes all others
2. **Navigates to about:blank** - Clears current page state
3. **Clears all cookies** - Removes authentication/session data
4. **Clears localStorage/sessionStorage** - Removes client-side storage
5. **Clears browser cache** - Uses CDP to clear network cache
6. **Resets zoom level** - Returns to 100% zoom

### Integration Points

**TaskService** (`uv/src/uv/services/task_service.py`):
- Added `_reset_browser_async()` helper method
- Calls `reset_browser_state()` at the start of:
  - `execute_task_stream()` - Streaming API endpoint
  - `execute_task()` - Non-streaming API endpoint

**Flow per API call:**
```
1. Receive /perform API request
2. Reset browser state (new) ← Ensures clean slate
3. Create fresh Conductor instance
4. Execute task with clean browser
5. Return results
```

## Alternatives Considered

### Option 2: Per-Request Browser Instances
**Approach:** Create a new browser instance for each API call

**Pros:**
- 100% clean state guaranteed
- True isolation between requests

**Cons:**
- 1-2 second startup overhead per request
- High memory usage (multiple Chrome instances)
- Complex CDP port management for Electron embedding
- Profile directory management overhead

**Verdict:** ❌ Too slow and resource-intensive

### Option 3: Browser Pool
**Approach:** Maintain 3-5 pre-initialized browsers, assign one per request

**Pros:**
- Fast (no startup overhead)
- Clean state per request

**Cons:**
- High memory usage (multiple Chrome instances always running)
- Complex pool management logic
- Overkill for current use case

**Verdict:** ❌ Over-engineered for current needs

### Option 1: Browser Reset (Chosen)
**Approach:** Reset state of shared browser between API calls

**Pros:**
- Fast (no browser startup)
- Low memory usage (single browser)
- Maintains Electron CDP embedding
- Simple implementation

**Cons:**
- Not 100% clean (some browser internals may persist)
- Requires comprehensive reset logic

**Verdict:** ✅ Best balance of performance and isolation

## Implementation Details

### New Function: `reset_browser_state()`

```python
def reset_browser_state() -> Dict[str, Any]:
    """
    Reset browser state to clean slate without creating new instance.
    
    Operations:
    1. Close all tabs except first one
    2. Navigate to about:blank
    3. Clear all cookies
    4. Clear localStorage/sessionStorage
    5. Clear browser cache via CDP
    6. Reset zoom to 100%
    
    Returns:
        Dict with status, reset_details, tabs_closed, error
    """
```

**Location:** `surface/src/surface/tools/browser_tools.py`  
**Exported from:** `surface/src/surface/tools/__init__.py`

### Modified Files

1. **surface/src/surface/tools/browser_tools.py**
   - Added `reset_browser_state()` function (120 lines)
   - Comprehensive error handling for each reset operation
   - Detailed logging of reset operations

2. **surface/src/surface/tools/__init__.py**
   - Exported `reset_browser_state` function
   - Added to `__all__` list

3. **uv/src/uv/services/task_service.py**
   - Added `_reset_browser_async()` helper method
   - Integrated reset into `execute_task_stream()`
   - Integrated reset into `execute_task()`
   - Runs reset in thread pool to avoid blocking

## Benefits

### ✅ Task Isolation
- Each API call starts with clean browser state
- No data leakage between tasks
- Predictable behavior

### ✅ Performance
- No browser startup overhead (1-2 seconds saved per request)
- Single browser instance (low memory usage)
- Fast reset operations (~100-200ms)

### ✅ Electron Compatibility
- Maintains single CDP endpoint (port 9222)
- No dynamic port allocation needed
- Electron embedding continues to work

### ✅ Security
- Cookies/tokens don't leak between tasks
- Authentication state is cleared
- localStorage/sessionStorage isolated

### ✅ Resource Management
- Prevents tab accumulation
- Clears cache to prevent growth
- Maintains consistent memory footprint

## Testing Strategy

### Manual Testing
1. Run two consecutive `/perform` API calls with browser tasks
2. Verify first task's cookies don't persist to second task
3. Verify tabs from first task are closed before second task
4. Verify localStorage is cleared between tasks

### Automated Testing
```python
# Test browser state reset
def test_browser_reset():
    # Set cookies, localStorage
    # Call reset_browser_state()
    # Verify all state cleared
```

### Integration Testing
```bash
# Test 1: Cookie isolation
curl -X POST /api/v1/perform -d '{"task": "Login to example.com"}'
curl -X POST /api/v1/perform -d '{"task": "Check if logged in to example.com"}'
# Expected: Second task should NOT be logged in

# Test 2: Tab cleanup
curl -X POST /api/v1/perform -d '{"task": "Open 5 tabs on different sites"}'
curl -X POST /api/v1/perform -d '{"task": "Count open tabs"}'
# Expected: Second task should see only 1 tab
```

## Monitoring

### Logs to Watch
```
🔄 Resetting browser state for clean task isolation
   ✅ Closed N extra tab(s)
   ✅ Navigated to about:blank
   ✅ Cleared N cookie(s)
   ✅ Cleared localStorage and sessionStorage
   ✅ Cleared browser cache via CDP
   ✅ Reset zoom to 100%
✅ Browser reset: [list of operations]
```

### Metrics
- Reset duration (should be <200ms)
- Reset success rate
- Number of tabs closed per reset
- Number of cookies cleared per reset

## Future Considerations

### If Reset Proves Insufficient
If browser state reset doesn't provide enough isolation:
1. Implement **Option 2** (per-request instances) as fallback
2. Add configuration flag: `BROWSER_ISOLATION_MODE=reset|new_instance`
3. Allow per-request override via API parameter

### Potential Enhancements
1. **Profile-based isolation** - Use temp profiles for sensitive tasks
2. **Selective reset** - Allow tasks to opt-out of reset (e.g., for session persistence)
3. **Reset verification** - Add assertions to verify reset completeness
4. **Browser health checks** - Detect and recover from browser hangs

## Conclusion

Browser state reset per API call provides an excellent balance between:
- **Performance** - No browser startup overhead
- **Isolation** - Clean state between tasks
- **Simplicity** - Straightforward implementation
- **Compatibility** - Works with Electron embedding

This solution addresses the state persistence issue while maintaining the performance benefits of a shared browser instance.

## References

- Issue: Browser state persists between API calls
- Related: `conductor-state-isolation-fix.md` (Conductor state isolation)
- Related: `unique-run-id-per-request.md` (Request isolation)
