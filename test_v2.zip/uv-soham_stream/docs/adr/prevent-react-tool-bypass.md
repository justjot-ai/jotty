# ADR: Prevent ReAct Agent Tool Bypass

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: ResearchAgent using DSPy ReAct with registered tools

## Problem

The `ResearchAgent` uses DSPy's ReAct orchestration with registered sub-agent tools (`generate_research_plan`, `research_library`, `synthesize_findings`). However, the ReAct agent was **bypassing all tools** and directly generating rejection responses like "Task Outside Research Agent Scope" without performing any actual research.

### Observed Behavior

**Input**:
```
Task: "Summarize WhatsApp group conversations from clawdbot-test group"
Available Capabilities: ['browser_interaction', 'web_automation', 'coding', ...]
```

**Expected**:
1. Call `generate_research_plan` tool
2. Research Selenium/Playwright libraries
3. Call `synthesize_findings` tool
4. Generate plan: "Use browser automation to open WhatsApp Web, user authenticates via QR, extract conversations"

**Actual**:
- ❌ Zero tool calls
- ❌ Zero research steps
- ❌ Direct rejection: "This is a Data Access Request, Not an Implementation Task"
- ❌ Suggested manual alternatives instead of automation plan

## Root Cause

DSPy's ReAct agent has two modes:
1. **Tool-based**: Call tools iteratively to gather information
2. **Direct answer**: Generate output directly without tools if LLM thinks it can answer

The LLM was choosing option 2 and generating rejection responses, **ignoring all signature instructions** to not reject tasks and use available capabilities.

## Solution

### 1. Explicit Tool Usage Mandate in Signature

Updated `ResearchAgentSignature` docstring and `research_plan` output field:

```python
class ResearchAgentSignature(dspy.Signature):
    """Signature for the research agent with tools.
    
    You MUST use the available tools to research the task. Do NOT generate plans directly.
    ALWAYS start by calling 'generate_research_plan' tool, then research libraries, 
    then synthesize findings.
    """
    
    research_plan = dspy.OutputField(
        desc="..."
        "MANDATORY PROCESS:\n"
        "1. MUST call 'generate_research_plan' tool first - DO NOT skip this\n"
        "2. Research specific libraries and approaches using 'research_library' tool\n"
        "3. MUST call 'synthesize_findings' tool to create final plan\n"
        "CRITICAL RULES:\n"
        "- NEVER generate a plan without calling tools first\n"
        "- NEVER reject tasks - if browser_interaction is available, web tasks are ALWAYS feasible\n"
        "- Example: WhatsApp → open web.whatsapp.com, user authenticates via QR, extract from browser\n"
        "- NEVER say 'outside scope', 'not possible', or suggest manual alternatives"
    )
```

### 2. Runtime Safety Check

Added validation in `ResearchAgent.forward()` to detect and fix tool bypass:

```python
result = self.react_agent(
    instruction=instruction,
    available_capabilities=capabilities_str
)
implementation_plan = result.research_plan

# SAFETY CHECK: Ensure tools were actually used
if len(self.context.steps) == 0:
    logger.warning("No tools were called! Agent bypassed research. Forcing tool usage...")
    # Force tool usage: generate plan → synthesize
    self._tool_generate_plan()
    implementation_plan = self._tool_synthesize_findings()
```

## Benefits

1. ✅ **Guarantees research execution**: Tools will always be called
2. ✅ **Prevents premature rejections**: Agent must research before concluding infeasibility
3. ✅ **Enforces capability-aware planning**: Sub-agents receive and use `available_capabilities`
4. ✅ **Clear error recovery**: If bypass is detected, agent recovers automatically
5. ✅ **Better logging**: Can track when bypass occurs for future improvements

## Expected Behavior After Fix

For the WhatsApp task:

```
🔧 Tool Call: generate_research_plan
   → "Research browser automation libraries for WhatsApp Web access"

🔧 Tool Call: research_library (Selenium)
   → Find installation, API, WhatsApp Web examples

🔧 Tool Call: research_library (Playwright)
   → Compare with Selenium

🔧 Tool Call: synthesize_findings
   → Generate plan:
      1. Use Selenium/Playwright to open web.whatsapp.com
      2. User authenticates via QR code scan in browser
      3. Navigate to clawdbot-test group
      4. Extract message DOM elements
      5. Parse and summarize conversations
```

## Trade-offs

### Advantages
- Reliable tool execution
- Better research quality
- Prevents "lazy" LLM shortcuts

### Disadvantages
- Adds a few lines of validation code
- Minor performance overhead for safety check
- May occasionally force unnecessary tool calls (acceptable trade-off)

## Alternatives Considered

1. **Increase ReAct `max_iters`**: Doesn't force initial tool usage
2. **Remove direct output option**: Not possible with DSPy ReAct architecture
3. **Use different orchestration**: Would require major refactoring
4. **Trust signature instructions alone**: Proven insufficient by observed behavior

## Related ADRs

- `user-authentication-in-plans.md`: Why we plan for auth instead of rejecting
- `capability-aware-research-agent.md`: How capabilities constrain planning
- `todo-creator-agent-implementation.md`: Similar tool-based orchestration pattern
