# ADR: System Logs Stream All /perform API Events

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Show all streaming events from /perform API in system logs

## Problem

The system logs were only showing agent activation/deactivation events and basic system messages. Users couldn't see the detailed streaming events coming from the `/perform` API, which provide valuable insight into what the system is doing during task execution.

## Decision

Log **all streaming events** from the `/perform` API to the system logs, not just agent-related events.

## Implementation

### Event Capture

In `handleStreamEvent()`, extract event details and log to system logs:

```javascript
handleStreamEvent(event) {
  this.eventCounter++;
  
  const module = event.module || 'system';
  const message = event.message || '';
  const type = event.type || 'info';
  const error = event.error || null;
  
  // Log to system logs (always, not just in debug mode)
  if (this.agentViewManager && message) {
    // Determine log level based on event type and content
    let logLevel = 'info';
    if (error) {
      logLevel = 'error';
    } else if (message.includes('✅') || message.includes('completed')) {
      logLevel = 'success';
    } else if (message.includes('⚠️') || message.includes('warning')) {
      logLevel = 'warning';
    } else if (message.includes('🔍') || message.includes('DEBUG')) {
      logLevel = 'debug';
    }
    
    this.agentViewManager.addSystemLog(module, message, logLevel);
  }
  
  // ... rest of event handling
}
```

### Log Level Detection

Automatically determine log level based on message content:

| Content | Level | Color |
|---------|-------|-------|
| `error` or has error field | error | Red |
| `✅`, `completed`, `success` | success | Green |
| `⚠️`, `warning` | warning | Yellow |
| `🔍`, `DEBUG` | debug | Gray |
| Default | info | White |

### Task Start Logging

```javascript
// Log task start
if (this.agentViewManager) {
  this.agentViewManager.addSystemLog(
    'system', 
    `🚀 Starting task: ${message.substring(0, 80)}...`, 
    'info'
  );
}
```

## Events Now Logged

### From Conductor
- Task decomposition
- Task planning
- Task execution start/end
- Parallel execution events
- Environment updates
- Data registry operations

### From Agents
- Agent initialization
- Tool calls
- ReAct iterations
- Agent outputs
- Agent completions

### From System
- Task start
- Task completion
- WebSocket events
- Unknown messages

## Example Log Output

```
02:15:30.123  system              🚀 Starting task: Check WhatsApp for unread...
02:15:31.456  Synapse.conductor   I am decomposing the goal into tasks
02:15:32.789  Synapse.planner     I have created 2 tasks for parallel execution
02:15:33.012  Synapse.conductor   I am executing 2 tasks in parallel
02:15:34.567  agent               ✅ BrowserExecutor activated
02:15:35.890  agent               ✅ TerminalExecutor activated
02:15:36.123  BrowserExecutor     I am navigating to web.whatsapp.com
02:15:37.456  TerminalExecutor    I am executing command: date
02:15:38.789  Synapse.conductor   I have completed parallel execution
02:15:39.012  system              🎯 Task completed successfully
```

## Benefits

✅ **Full visibility:** See every step of task execution  
✅ **Better debugging:** Track exactly what's happening  
✅ **Module attribution:** Know which component sent each message  
✅ **Color coding:** Quickly identify issues (red) vs success (green)  
✅ **Timestamps:** Track timing and sequence of events  
✅ **Always available:** Logs persist even when agents deactivate  

## Trade-offs

⚠️ **More logs:** Can be verbose for long-running tasks (mitigated by 1000 entry limit)  
⚠️ **Performance:** Minimal impact (simple DOM append)  

## User Experience

### Before
```
System Event Logs:
- Waiting for agent activity...
- (Empty until agents activate)
```

### After
```
System Event Logs:
02:15:30.123  system              🚀 Starting task: Check WhatsApp...
02:15:31.456  Synapse.conductor   I am decomposing the goal
02:15:32.789  Synapse.planner     I have created 2 tasks
02:15:33.012  Synapse.conductor   I am executing 2 tasks in parallel
02:15:34.567  agent               ✅ BrowserExecutor activated
02:15:35.890  agent               ✅ TerminalExecutor activated
02:15:36.123  BrowserExecutor     I am navigating to web.whatsapp.com
02:15:37.456  TerminalExecutor    I am executing command: date
...
```

## Testing

1. Start a task
2. Check system logs (should see task start)
3. Watch logs populate with streaming events
4. Verify module names are correct
5. Verify color coding works
6. Verify timestamps are accurate
7. Check that logs persist after agents deactivate

## Related Files

- `/electron-app/src/renderer/js/app.js` - Stream event handling (line 675)
- `/electron-app/src/renderer/js/agent-view-manager.js` - System logs implementation
- `/docs/adr/system-logs-collapsible-bar.md` - System logs feature

## Future Enhancements

- Filter by module
- Filter by log level
- Search logs
- Export logs
- Highlight specific modules
- Collapse/expand verbose events
