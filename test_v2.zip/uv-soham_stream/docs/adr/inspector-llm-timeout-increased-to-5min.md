# ADR: Inspector LLM Timeout Increased to 5 Minutes

**Date:** 2026-01-31  
**Status:** Implemented

## Context

During task execution, the Inspector Agent was timing out while validating terminal executor agent operations. The stack trace showed:

```
TimeoutError at line 704-705
InspectorAgent.run | timeout=180.0s (3 minutes)
```

The inspector's LLM call was exceeding the 3-minute timeout, causing task failures.

## Decision

Increased the inspector LLM timeout from **180 seconds (3 minutes)** to **300 seconds (5 minutes)**.

## Changes

**File:** `Synapse/core/inspector.py` (line 851)

```python
# Before:
timeout_seconds = getattr(self.config, 'llm_timeout_seconds', 180)  # 3 minutes default

# After:
timeout_seconds = getattr(self.config, 'llm_timeout_seconds', 300)  # 5 minutes default
```

## Rationale

- Complex validation tasks (especially terminal executor operations) require more time for thorough inspection
- 5 minutes provides adequate buffer for LLM processing while still preventing indefinite hangs
- This timeout is configurable via `llm_timeout_seconds` config parameter if further adjustment is needed

## Impact

- Inspector agents will have 2 additional minutes to complete validation
- Reduces timeout errors for complex tasks
- No breaking changes; timeout remains configurable via config
