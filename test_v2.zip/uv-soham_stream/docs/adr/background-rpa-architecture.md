# ADR: Background Desktop Application RPA Architecture

**Date:** 2026-02-04  
**Status:** Revised (Desktop App Focus)  
**Context:** Non-Intrusive Desktop Application Automation  
**Review:** See `docs/review/A_TEAM_BACKGROUND_RPA_ARCHITECTURE_REVIEW.md`

## Problem Statement

Users need RPA (Robotic Process Automation) capabilities for **native desktop applications** (Slack, Discord, Teams, etc.) that can run in the background without interfering with their daily work. Current executor agents focus on web automation, but users need to automate native desktop apps while continuing their work.

**Requirements:**
1. **Desktop Application Automation**: Automate native desktop apps (Slack, Discord, Teams, etc.)
2. **Non-Intrusive**: RPA tasks should execute in background without blocking user's primary work
3. **No Interference**: User should be able to continue using their applications normally
4. **Window Isolation**: RPA actions should not interfere with user's active windows/applications
5. **Focus Management**: Prevent focus stealing and window activation conflicts
6. **Support for scheduled/recurring RPA tasks**
7. **Task queue management** for multiple RPA workflows
8. **Status monitoring and logging** for background tasks

**Key Constraint**: **Desktop applications only** - NOT web-based automation. Must work with native desktop apps.

## Solution Architecture

### Core Components

#### 1. Background Task Queue System
- **Purpose**: Manage RPA task execution queue
- **Location**: Extend existing `uv/src/uv/services/task_service.py` (reuse, don't duplicate)
- **Features**:
  - Priority-based task queue (FIFO with priority override)
  - In-memory queue for MVP (add persistence later if needed)
  - Concurrent task execution limits (configurable, default: 3)
  - Task status tracking (pending, running, completed, failed)
  - Retry mechanism for failed tasks

#### 2. Desktop Application Automation (PRIMARY FOCUS)
- **Purpose**: Automate native desktop applications (Slack, Discord, Teams, etc.)
- **Location**: `uv/src/uv/services/desktop_app_executor.py` (new module)
- **Features**:
  - **Native Desktop App Support**: GUI automation for native desktop apps ONLY
  - **Platform-Specific Tools** (Cursor-Free Methods):
    - **macOS**: Accessibility API (AXUIElement) + AppleScript (no-activate mode) + Application APIs
    - **Linux**: X11 XTest extension (invisible cursor) + xdotool (--window option) + Application APIs
    - **Windows**: UI Automation API + SendMessage/PostMessage + Application APIs
  - **Virtual Display/Desktop**: Isolate automation from user's active display
  - **Cursor-Free Automation**: Use APIs that don't move physical cursor
  - **Application Detection**: Detect if app is running, launch if needed
  - **Window Management**: Manage windows without stealing focus or moving cursor
  - **Interaction Methods**: 
    - Direct UI element manipulation (no cursor movement)
    - Keyboard shortcuts and hotkeys
    - Application-specific APIs (Slack API, Discord API, etc.)
    - OCR for text extraction (read-only, no interaction)
  - **Focus Prevention**: Never steal focus from user's active applications
  - **Conflict Detection**: Check if user is actively using app before automation
  - **Idle Detection**: Only automate when user is idle or in different app

#### 2a. Virtual Display/Desktop Manager (REQUIRED)
- **Purpose**: Isolate desktop app automation from user's active display
- **Location**: `uv/src/uv/services/virtual_display_service.py` (new module)
- **Features**:
  - **macOS**: Use separate Space/Desktop (if possible) or window-level isolation
  - **Linux**: Xvfb (X Virtual Framebuffer) for true virtual displays
  - **Windows**: Virtual Desktop API (Windows 10+) for separate desktop
  - **Display Isolation**: Each RPA task runs in isolated display environment
  - **Automatic Cleanup**: Clean up virtual displays on task completion
  - **Resource Management**: Limit concurrent virtual displays

#### 3. Background Desktop App Executor
- **Purpose**: Execute desktop app RPA tasks in isolated environment
- **Location**: `uv/src/uv/services/background_desktop_rpa_executor.py` (new module)
- **Features**:
  - Wraps DesktopAppExecutor for background execution
  - Runs tasks in separate processes with virtual display/desktop
  - Uses platform-specific GUI automation tools
  - Captures screenshots and logs without interfering with user
  - Resource limits (CPU, memory, timeouts)
  - Process monitoring and health checks
  - Graceful shutdown on user interruption
  - Focus management to prevent stealing user's active window focus

#### 4. RPA Task Scheduler
- **Purpose**: Schedule recurring/one-time RPA tasks
- **Location**: `uv/src/uv/services/rpa_scheduler.py`
- **Features**:
  - Cron-like scheduling for recurring tasks
  - One-time scheduled tasks
  - Timezone-aware scheduling
  - Task dependencies and chaining
  - Schedule persistence

#### 5. RPA API Endpoints
- **Purpose**: Expose RPA functionality via REST API
- **Location**: `uv/src/uv/api/v1/rpa.py`
- **Endpoints**:
  - `POST /api/v1/rpa/tasks` - Submit RPA task
  - `GET /api/v1/rpa/tasks` - List all tasks
  - `GET /api/v1/rpa/tasks/{task_id}` - Get task status
  - `DELETE /api/v1/rpa/tasks/{task_id}` - Cancel task
  - `POST /api/v1/rpa/tasks/{task_id}/retry` - Retry failed task
  - `POST /api/v1/rpa/schedule` - Schedule recurring task
  - `GET /api/v1/rpa/logs/{task_id}` - Get task logs

### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    User's Daily Work                         │
│  (Browser, Terminal, IDE - Unaffected)                      │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ (No interference)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Background RPA Service Layer                    │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Task Queue   │  │  Scheduler    │  │  Executor    │    │
│  │  Service     │  │  Service      │  │  Service     │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
│         │                │                  │              │
│         └────────────────┴──────────────────┘              │
│                            │                                │
│                            ▼                                │
│              ┌─────────────────────────┐                   │
│              │ Virtual Display Manager │                   │
│              │  (Xvfb/Virtual Desktop) │                   │
│              └─────────────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         Isolated Desktop App Execution Environment          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐ │
│  │ Desktop App Executor                                │ │
│  │ - Native GUI Automation ONLY                        │ │
│  │ - Platform-specific tools:                         │ │
│  │   • macOS: AppleScript + Accessibility API         │ │
│  │   • Linux: xdotool/wmctrl + PyAutoGUI              │ │
│  │   • Windows: pywinauto + Virtual Desktop API       │ │
│  │ - Window management without focus stealing          │ │
│  │ - Conflict detection (user activity check)         │ │
│  └─────────────────────────────────────────────────────┘ │
│                                                             │
│  Supported Apps: Slack, Discord, Teams, Zoom, etc.         │
│  (Native desktop applications only - NO web automation)    │
└─────────────────────────────────────────────────────────────┘
```

## Implementation Plan

### Phase 1: Core Infrastructure (Week 1-3)

1. **Virtual Display/Desktop Manager**
   - **Linux**: Implement Xvfb (X Virtual Framebuffer) support
   - **Windows**: Implement Virtual Desktop API support (Windows 10+)
   - **macOS**: Implement window-level isolation (separate Space if possible)
   - Add display lifecycle management (create, use, cleanup)
   - Test virtual display isolation on each platform
   - Add resource limits (max concurrent displays)

2. **Desktop Application Executor (Cursor-Free)**
   - Create `DesktopAppExecutor` module
   - **CRITICAL**: Implement cursor-free automation methods:
     - **Application APIs First**: Use Slack API, Discord API, Teams API when available
     - **macOS**: Accessibility API (AXUIElement) - no cursor movement
     - **Linux**: X11 XTest extension - invisible cursor events
     - **Windows**: UI Automation API - direct element manipulation
   - **Avoid**: PyAutoGUI, AppleScript activate, xdotool mouse movement
   - Add application detection (is app running? launch if needed)
   - Implement window management (find windows, manage without focus/cursor)
   - Add interaction methods:
     - Direct UI element manipulation (no cursor)
     - Keyboard shortcuts and hotkeys
     - Application-specific APIs
     - OCR for read-only operations
   - Implement conflict detection (check if user is actively using app)
   - Add idle detection (only automate when user is idle)

3. **Interference Prevention System**
   - Detect user's active window/application
   - Detect user's mouse/keyboard activity (idle detection)
   - Prevent focus stealing from RPA tasks
   - **Prevent cursor movement** - use cursor-free automation methods
   - Implement activity queue (wait if user is active)
   - Add user activity monitoring (mouse movements, keyboard input, window focus)
   - Only automate when user is idle or using different app

4. **Task Queue (Simplified)**
   - Extend `TaskService` with background queue support
   - Implement in-memory priority queue
   - Add task status tracking
   - Add concurrent execution limits (consider virtual display limits)

### Phase 2: Background Execution (Week 4-5)

5. **Background Desktop App Executor**
   - Create `BackgroundDesktopRPAExecutor` module
   - Integrate with Virtual Display Manager
   - Implement background process execution with virtual display
   - Add screenshot capture and logging
   - Implement process monitoring and health checks
   - Add automatic cleanup of virtual displays
   - Add resource limits and timeouts

6. **Security & Operational Safeguards**
   - Add input validation for task instructions
   - Implement rate limiting on API endpoints
   - Add process monitoring daemon
   - Implement health checks for background tasks
   - Add automatic recovery for stuck tasks
   - Monitor virtual display resource usage

### Phase 3: UI Integration (Week 6)

7. **UI Dashboard**
   - Add background task list to Electron UI
   - Implement WebSocket status updates
   - Display task logs, screenshots, and results in UI
   - Add task management controls (pause, cancel, retry)
   - Show virtual display status

8. **REST API Endpoints**
   - Extend existing API with desktop RPA endpoints
   - Add WebSocket support for real-time status
   - Create API documentation
   - Add screenshot streaming endpoint

### Phase 4: Testing & Polish (Week 7-8)

9. **Testing**
   - Unit tests for virtual display manager (~30 test cases)
   - Integration tests for desktop app automation (~60 test cases)
   - Platform-specific tests (macOS/Linux/Windows)
   - Focus management tests (~20 test cases)
   - Conflict detection tests (~15 test cases)
   - Task queue tests (~30 test cases)
   - End-to-end tests with real desktop apps (Slack, Discord, etc.)

10. **Documentation & Bug Fixes**
    - Update documentation
    - Fix bugs discovered during testing
    - Performance optimization
    - Platform-specific optimization

## Technical Details

### Virtual Display/Desktop Implementation

**Linux (Xvfb - X Virtual Framebuffer):**
```python
from xvfbwrapper import Xvfb
import os

class VirtualDisplayManager:
    def __init__(self):
        self.xvfb = None
        self.display_num = None
    
    def start(self):
        """Start virtual display."""
        self.xvfb = Xvfb(width=1920, height=1080, colordepth=24)
        self.xvfb.start()
        self.display_num = self.xvfb.new_display
        os.environ['DISPLAY'] = f':{self.display_num}'
        return self.display_num
    
    def stop(self):
        """Stop virtual display."""
        if self.xvfb:
            self.xvfb.stop()
            os.environ.pop('DISPLAY', None)
```

**Windows (Virtual Desktop API):**
```python
import ctypes
from ctypes import wintypes

class VirtualDesktopManager:
    def __init__(self):
        self.desktop_handle = None
    
    def create_desktop(self):
        """Create new virtual desktop."""
        # Windows 10+ Virtual Desktop API
        # Use IVirtualDesktopManager interface
        # Requires Windows API calls via ctypes or pywin32
        pass
    
    def switch_to_desktop(self, desktop_handle):
        """Switch to virtual desktop."""
        # Move application to virtual desktop
        pass
```

**macOS (Window-Level Isolation):**
```python
import subprocess
import AppKit

class MacOSWindowIsolation:
    def isolate_window(self, app_name: str):
        """Isolate app window without stealing focus."""
        # Use AppleScript to manage windows
        # Keep window in background, don't activate
        script = f'''
        tell application "{app_name}"
            set frontmost to false
            -- Perform actions without activating
        end tell
        '''
        subprocess.run(['osascript', '-e', script])
```

### Desktop Application Automation

**Platform-Specific Implementation:**

**macOS (Accessibility API - Cursor-Free):**
```python
import AppKit
from Quartz import kAXValueAttribute, kAXTitleAttribute

def automate_slack_macos(action: str):
    """Automate Slack on macOS WITHOUT moving cursor."""
    # Use Accessibility API - no cursor movement
    app = AppKit.NSWorkspace.sharedWorkspace().runningApplications()
    slack_app = [a for a in app if a.bundleIdentifier() == 'com.tinyspeck.slackmacgap']
    
    if slack_app:
        # Get UI elements via Accessibility API
        ax_app = AppKit.AXUIElementCreateApplication(slack_app[0].processIdentifier())
        
        # Find UI elements without activating or moving cursor
        # Use AXUIElement methods that work in background
        # Example: Set text field value directly
        text_field = find_ui_element(ax_app, role='AXTextField')
        if text_field:
            # Set value directly - no cursor movement
            AppKit.AXUIElementSetAttributeValue(
                text_field, 
                kAXValueAttribute, 
                action
            )
```

**Linux (X11 XTest - Invisible Cursor):**
```python
import subprocess
import os
from Xlib import X, display
from Xlib.ext import xtest

def automate_slack_linux(action: str, display_num: int):
    """Automate Slack on Linux WITHOUT visible cursor movement."""
    # Connect to virtual display
    dpy = display.Display(f':{display_num}')
    xtest = xtest.XTestQueryExtension(dpy)
    
    # Find Slack window
    window_id = find_window_by_name(dpy, 'Slack')
    
    # Use XTest to send events directly to window
    # Events go to window without moving physical cursor
    window = dpy.create_resource_object('window', window_id)
    
    # Send keyboard events directly to window (no cursor)
    for char in action:
        # Send key press/release directly to window
        xtest.fake_input(dpy, X.KeyPress, keycode_for_char(char))
        xtest.fake_input(dpy, X.KeyRelease, keycode_for_char(char))
    dpy.sync()
```

**Windows (UI Automation API - Cursor-Free):**
```python
import comtypes.client
from comtypes.gen.UIAutomationClient import *

def automate_slack_windows(action: str):
    """Automate Slack on Windows WITHOUT moving cursor."""
    # Use UI Automation API - no cursor movement
    automation = comtypes.client.CreateObject(
        "{ff48dba4-60ef-4201-aa87-54103eef594e}",
        interface=IUIAutomation
    )
    
    # Get Slack window
    root = automation.GetRootElement()
    condition = automation.CreatePropertyCondition(
        UIA_NamePropertyId, "Slack"
    )
    slack_window = root.FindFirst(TreeScope_Children, condition)
    
    # Find text input field
    text_field_condition = automation.CreatePropertyCondition(
        UIA_ControlTypePropertyId, UIA_EditControlTypeId
    )
    text_field = slack_window.FindFirst(TreeScope_Descendants, text_field_condition)
    
    # Set value directly - no cursor movement
    value_pattern = text_field.GetCurrentPattern(UIA_ValuePatternId)
    value_pattern.SetValue(action)
```

**Alternative: Application APIs (Best Option):**
```python
# Use official APIs when available - NO GUI automation needed
import slack_sdk

def automate_slack_via_api(message: str, channel: str):
    """Use Slack API - no GUI, no cursor, no interference."""
    client = slack_sdk.WebClient(token=os.environ['SLACK_BOT_TOKEN'])
    client.chat_postMessage(channel=channel, text=message)
    # Zero interference with user - pure API call
```

**Focus & Cursor Prevention:**
```python
def prevent_interference():
    """Ensure RPA doesn't interfere with user (focus OR cursor)."""
    # 1. Check user's active window
    user_active_window = get_user_active_window()
    
    # 2. Check if user is actively using mouse/keyboard
    user_idle_time = get_user_idle_time()
    
    # 3. If user is using the app we want to automate, wait or skip
    if user_active_window == target_app:
        return False  # Don't automate
    
    # 4. If user is actively using mouse/keyboard, wait
    if user_idle_time < 5:  # User active in last 5 seconds
        return False  # Don't automate
    
    # 5. Use cursor-free automation methods only
    return True

def automate_without_cursor(app_name: str, action: str):
    """Automate using methods that DON'T move cursor."""
    # Option 1: Use application APIs (best)
    if has_api_support(app_name):
        return use_application_api(app_name, action)
    
    # Option 2: Use accessibility/UI automation APIs (cursor-free)
    if platform.system() == 'Darwin':
        return use_accessibility_api_macos(app_name, action)
    elif platform.system() == 'Linux':
        return use_xtest_api_linux(app_name, action)
    elif platform.system() == 'Windows':
        return use_uiautomation_api_windows(app_name, action)
    
    # Option 3: Use keyboard shortcuts (no mouse movement)
    return use_keyboard_shortcuts(app_name, action)
```

**macOS Implementation (AppleScript):**
```python
import subprocess

def automate_slack_macos(action: str):
    """Use AppleScript to automate Slack on macOS."""
    script = f'''
    tell application "Slack"
        activate
        -- Wait for app to be ready
        delay 1
        -- Perform action (click, type, etc.)
        {action}
    end tell
    '''
    subprocess.run(['osascript', '-e', script])
```

**Linux Implementation (xdotool):**
```python
import subprocess

def automate_slack_linux(action: str):
    """Use xdotool to automate Slack on Linux."""
    # Find Slack window
    window_id = subprocess.check_output(['xdotool', 'search', '--name', 'Slack']).decode().strip()
    # Focus window
    subprocess.run(['xdotool', 'windowactivate', window_id])
    # Perform action
    subprocess.run(['xdotool', 'type', action])
```

**Windows Implementation (pywinauto):**
```python
from pywinauto import Application

def automate_slack_windows(action: str):
    """Use pywinauto to automate Slack on Windows."""
    app = Application().connect(title_re=".*Slack.*")
    window = app.window(title_re=".*Slack.*")
    window.set_focus()
    # Perform action
    window.type_keys(action)
```

**Conflict Prevention:**
```python
def check_user_active(app_name: str) -> bool:
    """Check if user is actively using the application."""
    # Check if app window has focus
    # Check if user has interacted recently
    # Return True if user is active, False if safe to automate
    pass
```

### Task Queue Schema

```python
@dataclass
class RPATask:
    task_id: str
    instruction: str
    priority: int  # 1-10, higher = more priority
    scheduled_at: Optional[datetime]
    max_retries: int = 3
    timeout_seconds: int = 3600
    executor_type: str  # "browser", "terminal", "websearch", "multi"
    context: Dict[str, Any]
    status: TaskStatus  # pending, running, completed, failed, cancelled
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    result: Optional[Dict[str, Any]]
    error: Optional[str]
    logs: List[str]
```

### Background Desktop App Execution Flow

```python
async def execute_background_desktop_app_task(task: RPATask):
    """Execute desktop app RPA task in isolated virtual display."""
    
    # 1. Acquire virtual display/desktop
    virtual_display = await virtual_display_service.acquire_display()
    
    try:
        # 2. Check if user is actively using the target app
        if await check_user_active_app(task.app_name):
            task.status = TaskStatus.PENDING
            task.error = "User is actively using the application"
            return task  # Skip automation
        
        # 3. Launch app in virtual display if not running
        if not await is_app_running(task.app_name, virtual_display):
            await launch_app_in_display(task.app_name, virtual_display)
            await asyncio.sleep(2)  # Wait for app to start
        
        # 4. Execute desktop app automation
        result = await asyncio.wait_for(
            desktop_app_executor.execute(
                app_name=task.app_name,
                action=task.instruction,
                virtual_display=virtual_display,
                prevent_focus_steal=True
            ),
            timeout=task.timeout_seconds
        )
        
        # 5. Capture screenshots and logs
        screenshots = await capture_screenshots(virtual_display)
        task.result = {
            'output': result,
            'screenshots': screenshots,
            'logs': desktop_app_executor.get_logs()
        }
        task.status = TaskStatus.COMPLETED
        
    except asyncio.TimeoutError:
        task.status = TaskStatus.FAILED
        task.error = "Task timeout exceeded"
        
    except Exception as e:
        task.status = TaskStatus.FAILED
        task.error = str(e)
        
    finally:
        # 6. Cleanup virtual display
        await virtual_display_service.release_display(virtual_display)
        
    return task
```

## Benefits

1. **Native Desktop App Automation**: Can automate actual desktop applications (Slack, Discord, Teams, etc.)
2. **Non-Intrusive**: User can continue working while RPA runs in background virtual display
3. **True Isolation**: Virtual displays/desktops prevent interference with user's active applications
4. **Cursor-Free Automation**: Uses APIs that don't move physical cursor (Accessibility API, UI Automation, XTest)
5. **Focus Prevention**: Never steals focus from user's active windows
6. **Application APIs Preferred**: Uses official APIs (Slack API, Discord API) when available - zero interference
7. **Idle-Aware**: Only automates when user is idle or using different app
8. **Scalable**: Queue system supports multiple concurrent tasks (limited by virtual display resources)
9. **Reliable**: Retry mechanism and error handling
10. **Observable**: Status tracking, screenshots, and logging for all tasks
11. **Flexible**: Supports scheduled, recurring, and one-time tasks
12. **Platform Support**: Works on macOS, Linux, and Windows (with platform-specific implementations)

## Trade-offs

1. **Resource Usage**: Virtual displays consume significant memory (200-500MB per display on Linux, varies by platform)
2. **Platform Complexity**: Different implementations for macOS, Linux, Windows (no single solution)
3. **Implementation Complexity**: More complex than web automation (requires virtual displays, focus management, conflict detection, cursor-free methods)
4. **Cursor-Free Constraint**: 
   - **Cannot use PyAutoGUI** - moves physical cursor
   - **Cannot use AppleScript activate** - steals focus
   - **Must use Accessibility/UI Automation APIs** - more complex but cursor-free
   - **Prefer Application APIs** - Slack API, Discord API, etc. (best option)
5. **Platform Limitations**:
   - **Linux**: Xvfb + XTest extension (invisible cursor events)
   - **Windows**: Virtual Desktop API + UI Automation API
   - **macOS**: Accessibility API (AXUIElement) - no cursor movement
6. **Latency**: Background tasks have overhead from virtual display creation/teardown
7. **Concurrency Limits**: Limited by virtual display resources (typically 3-5 concurrent tasks)
8. **Testing Complexity**: Requires testing on each platform with real desktop applications
9. **Dependencies**: Requires platform-specific APIs (Accessibility API, UI Automation, XTest)
10. **Idle Requirement**: May need to wait for user idle time before automation

## Alternatives Considered

1. **Virtual Displays (Xvfb, etc.)**: Better isolation but complex
   - **Rejected**: Too complex, platform-specific, high resource overhead (300-800MB per task)
   - **A-Team Review**: Unanimously rejected in favor of simpler headless approach

2. **Separate User Session**: Better isolation but complex
   - **Rejected**: Requires system-level permissions, not portable

3. **Docker Containers**: Good isolation but heavy
   - **Considered**: May use for Linux, but not suitable for macOS/Windows GUI apps
   - **Future Consideration**: Could add Docker support for Linux-only use cases

4. **Headless Browser Only (Selected)**: Simpler, consistent, lower overhead
   - **Selected**: Works consistently across all platforms, 50-70% less memory, simpler implementation

## Success Metrics

- ✅ User can continue working while desktop app RPA tasks run
- ✅ Zero interference with user's active applications (virtual display isolation)
- ✅ Zero focus stealing from user's active windows
- ✅ **Zero cursor movement** - user never sees cursor moving
- ✅ Zero keyboard/mouse interference - user can type/move mouse normally
- ✅ 95%+ task completion rate (lower than web automation due to complexity)
- ✅ <10% overhead on system resources (virtual displays are heavier)
- ✅ Task queue processes 20-50 tasks/hour (limited by virtual display resources)
- ✅ 8-week implementation timeline (more complex than web automation)
- ✅ Application API usage rate >80% (prefer APIs over GUI automation)

## Desktop Application Use Cases

### Slack Desktop App Automation Example

**Option 1: Use Slack API (BEST - No GUI, No Cursor, No Interference)**
```python
# Task: Send message via Slack API
task = {
    "instruction": "Send message 'Hello team' to #general channel in Slack",
    "executor_type": "desktop_app",
    "app": "slack",
    "method": "api",  # Use Slack API - no GUI automation
    "api_token": "xoxb-...",  # Bot token
    "channel": "#general"
}
# Zero interference - pure API call
```

**Option 2: Cursor-Free GUI Automation (Fallback)**
```python
# Task: Send message via desktop app (cursor-free)
task = {
    "instruction": "Send message 'Hello team' to #general channel in Slack",
    "executor_type": "desktop_app",
    "app": "slack",
    "app_type": "native",  # Native desktop app ONLY
    "method": "accessibility_api",  # Use Accessibility/UI Automation APIs
    "check_user_active": True,  # Don't automate if user is using Slack
    "check_user_idle": True,  # Wait for user idle time
    "virtual_display": True,  # Use virtual display for isolation
    "prevent_focus_steal": True,  # Never steal focus from user
    "prevent_cursor_movement": True  # CRITICAL: No cursor movement
}
```

### Supported Desktop Applications

**Native Desktop Apps (Cursor-Free Automation):**

**Preferred Method: Application APIs**
- ✅ Slack Desktop App (Slack API - `slack_sdk`)
- ✅ Discord Desktop App (Discord API - `discord.py`)
- ✅ Microsoft Teams Desktop App (Microsoft Graph API)
- ✅ Zoom Desktop App (Zoom API)
- ✅ Any app with official API support

**Fallback Method: Cursor-Free GUI Automation**

**macOS:**
- ✅ Slack Desktop App (Accessibility API - AXUIElement)
- ✅ Discord Desktop App (Accessibility API)
- ✅ Microsoft Teams Desktop App (Accessibility API)
- ✅ Zoom Desktop App (Accessibility API)
- ✅ Any macOS native application (via Accessibility API)

**Linux:**
- ✅ Slack Desktop App (X11 XTest extension - invisible cursor)
- ✅ Discord Desktop App (XTest extension)
- ✅ Microsoft Teams Desktop App (XTest extension)
- ✅ Zoom Desktop App (XTest extension)
- ✅ Any Linux native application (via Xvfb + XTest)

**Windows:**
- ✅ Slack Desktop App (UI Automation API - direct element manipulation)
- ✅ Discord Desktop App (UI Automation API)
- ✅ Microsoft Teams Desktop App (UI Automation API)
- ✅ Zoom Desktop App (UI Automation API)
- ✅ Any Windows native application (via Virtual Desktop + UI Automation)

**Key Requirements:**
1. **Application APIs First**: Use official APIs when available (no GUI automation)
2. **Virtual Display/Desktop**: Required for GUI automation isolation
3. **Cursor-Free Methods**: Use Accessibility/UI Automation APIs (no PyAutoGUI)
4. **Focus Prevention**: Never steal focus from user's active applications
5. **Idle Detection**: Only automate when user is idle or using different app
6. **Conflict Detection**: Check if user is actively using app before automation
7. **Platform-Specific**: Different APIs for each OS
8. **Resource Management**: Limit concurrent virtual displays

## Related ADRs

- `environment-manager-non-blocking-summarization.md` - Background processing pattern
- `parallel-execution-event-streaming.md` - Concurrent execution patterns
- `browser-state-reset-per-api-call.md` - State isolation patterns
- `browser-automation-tools.md` - Browser automation capabilities

## Next Steps

1. ✅ **A-Team Review Complete** - See `docs/review/A_TEAM_BACKGROUND_RPA_ARCHITECTURE_REVIEW.md`
2. Create detailed implementation plan for Phase 1 (headless browser support)
3. Set up development environment for headless browser testing
4. Begin implementation of headless browser support in `browser_tools.py`
5. Extend `TaskService` with background queue support

## A-Team Review Summary

**Original Design (Web-First):**
- Headless browser approach (simpler, consistent)
- 5-week timeline
- Lower resource overhead

**Revised Design (Desktop App Focus):**
- ✅ Virtual Display/Desktop Manager (REQUIRED for desktop apps)
- ✅ Platform-specific GUI automation tools
- ✅ Focus prevention and conflict detection
- ✅ 8-week implementation timeline (more complex)
- ✅ Higher resource overhead (virtual displays)

**Key Requirements:**
- Virtual displays/desktops are REQUIRED (not optional) for desktop app automation
- Platform-specific implementations needed (macOS/Linux/Windows)
- Focus management is critical to prevent interfering with user
- Conflict detection to avoid automating when user is active
- Resource limits due to virtual display overhead
