# ADR: Tiered File Storage for Inter-Agent File Transfer

**Date:** 2026-02-02  
**Status:** Accepted  
**Deciders:** A-Team Review  

## Context

`SmartAgentSlack` currently loads all data into memory for inter-agent transfer. This fails for large binary files (50MB WAV, 10MB images) because:
1. Memory explosion when loading large files
2. `UnifiedChunker` is TEXT-only (token-based) - cannot process binary
3. No clean path mechanism for file references
4. No lifecycle management for transferred files

## Decision

Implement tiered file storage with file reference passing:

### Storage Tiers
| Tier | Age | Format | Purpose |
|------|-----|--------|---------|
| **Hot** | 0-1 day | Raw | Active transfers |
| **Warm** | 1-7 days | Raw | Recent files |
| **Cold** | 7-30 days | Gzip | Older files |
| **Archive** | 30+ days | Tar.gz bundles | Monthly archives |

### Key Components
1. `FileReference` - Path-independent reference using `file_id`
2. `TieredFileStorage` - Manages storage lifecycle
3. Auto file mode for `bytes` data or files >1MB
4. Background tier transitions

### Critical Safeguard
**Binary files (audio, images) MUST skip `UnifiedChunker`.**

```python
# In axon.py send_stream():
if isinstance(data, bytes) or current_format == 'bytes':
    use_file_mode = True  # Skip chunker, go directly to file storage
```

## Consequences

### Positive
- Enables large binary file transfer (WAV, PNG, etc.)
- No memory explosion (file references are ~200 bytes)
- Automatic lifecycle management with cleanup
- Integrity verification via SHA256 checksum

### Negative
- Disk I/O overhead for file operations
- Complexity of tier transitions
- Path resolution required for reads

### Neutral
- Files persist longer than typical agent communication (archive up to 1 year)
- Receiver must call `storage.read_file(file_id)` for content

## Implementation

**New file:** `Synapse/core/file_storage.py` (~250 lines)  
**Modified:** `Synapse/core/axon.py` (~50 lines)  
**Tests:** `tests/test_tiered_file_storage.py`

## References

- A-Team Review: `docs/review/A_TEAM_TIERED_FILE_STORAGE_REVIEW.md`
- Original Analysis: `AGENT_SLACK_FILE_TRANSFER_ANALYSIS.md`
