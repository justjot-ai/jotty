# ADR: Agent Resolver Implementation

**Date:** 2026-02-06  
**Status:** Implemented  
**Context:** Agents were requesting help from non-existent agents (e.g., "FileSystemNavigator" instead of "TerminalExecutor"), causing collaboration failures.

## Decision

Implemented an `AgentResolverAgent` that uses LLM-based reasoning to resolve incorrect or deprecated agent names to the correct agents based on capabilities and context.

## Problem

When agents set `collaboration_actions` with incorrect agent names:
1. Direct name matching failed
2. Simple keyword matching was too rigid
3. No understanding of agent capabilities or context
4. Collaboration requests failed silently

Example failure:
- PresentationBuilder requested help from "FileSystemNavigator" (doesn't exist)
- Should have been resolved to "TerminalExecutor" (can read files via terminal commands)
- Request failed, no PowerPoint created

## Solution

Created `AgentResolverAgent` that:
1. Takes requested agent name, knowledge type, and context
2. Analyzes available agents and their capabilities
3. Uses Chain of Thought reasoning to match intent
4. Returns resolved agent name with confidence score

## Implementation

### Files Created

1. **`Synapse/signatures/agent_resolver_signatures.py`**
   - `ResolveAgentSignature`: DSPy signature for agent resolution
   - Inputs: requested_agent_name, knowledge_type, request_context, available_agents
   - Outputs: resolved_agent_name, reasoning, confidence

2. **`Synapse/agents/agent_resolver_agent.py`**
   - `AgentResolverAgent`: DSPy Chain of Thought agent
   - Uses LLM to intelligently match agent names based on capabilities

### Files Modified

1. **`Synapse/core/conductor.py`**
   - Added `AgentResolverAgent` initialization in `__init__`
   - Enhanced `_resolve_target_agent()` to use `AgentResolverAgent` as fallback
   - Updated `_handle_help_request_stream()` to resolve agent names before processing

2. **`Synapse/agents/__init__.py`**
   - Added `AgentResolverAgent` export

3. **`Synapse/signatures/__init__.py`**
   - Added `ResolveAgentSignature` export

## Resolution Flow

```
1. Agent sets collaboration_actions with incorrect name
   → "FileSystemNavigator" requested

2. Conductor extracts collaboration_actions
   → Processes request_help action

3. _handle_help_request_stream() calls _resolve_target_agent()
   → Tries exact match → fails
   → Tries keyword matching → fails
   → Tries capability matching → fails

4. Falls back to AgentResolverAgent
   → Analyzes: "FileSystemNavigator" + "read_files" + context
   → Matches against available agents
   → Returns: "TerminalExecutor" (confidence: 0.85)

5. Conductor uses resolved agent
   → Executes TerminalExecutor
   → TerminalExecutor reads files
   → Sends results back via agent_slack
```

## Benefits

1. **Intelligent Matching**: Understands intent, not just names
2. **Capability-Aware**: Matches based on what agents can do
3. **Context-Sensitive**: Considers the type of help needed
4. **Confidence Scoring**: Returns confidence to handle edge cases
5. **Fallback Safe**: Falls back to "all" broadcast if no match

## Example Resolutions

- "FileSystemNavigator" + "read_files" → "TerminalExecutor"
- "WhatsAppManager" + "browser_automation" → "BrowserExecutor"
- "CodeMaster" + "execute_script" → "TerminalExecutor"
- "DataAnalyst" + "data_processing" → Checks capabilities, may return "all"

## Testing

To verify:
1. Agent requests help from non-existent agent
2. Check logs for "🤖 Using AgentResolverAgent to resolve..."
3. Verify resolved agent name appears in logs
4. Confirm collaboration succeeds with resolved agent

## Related Issues

- Fixes collaboration failures when agents use incorrect names
- Enables graceful degradation instead of silent failures
- Improves multi-agent coordination success rate
