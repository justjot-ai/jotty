# ADR: Making BrowserExecutor Tasks Visible to Users

**Status:** Approved  
**Date:** 2026-02-01  
**Deciders:** Architecture Team (A-Team Review)  
**Context:** User wants to see what BrowserExecutor agent is doing in real-time  

---

## Context

**User's Actual Requirement (Clarified):**
> "I want to show the user whatever is happening or tasks done by browser executor agent"

**What user wants:**
- ✅ Visual feedback of browser automation
- ✅ See what BrowserExecutor is doing in real-time
- ✅ Understand browser task progress

**What user is NOT asking for:**
- ❌ Complex browser instance sharing
- ❌ Embedding Chrome inside Electron UI
- ❌ Reducing resource usage or running single Chrome instance

**Current State:**
- BrowserExecutor runs in headless mode by default (invisible)
- No activity logs streamed to Electron UI
- User has no visibility into browser automation

---

## Decision Drivers

- **User Experience:** Provide clear visibility into browser automation
- **Simplicity:** Use existing features rather than complex rewrites
- **Development Effort:** Minimize implementation time (hours, not weeks)
- **Stability:** Zero breaking changes or architectural modifications
- **Security:** No new security risks or attack vectors
- **Maintainability:** Simple, easy-to-understand solution

---

## Options Considered

### Option 1: Visible Browser Window Toggle ✅
**Description:** Add UI toggle to show/hide browser window (use existing `headless` parameter)

**Implementation:**
- Add "Show Browser Window" checkbox in Electron UI
- Pass `show_browser` flag to backend
- Set `headless = not show_browser` when initializing browser
- Chrome window appears on screen when enabled

**Pros:**
- ✅ ZERO code changes to browser tools (already supported!)
- ✅ 30 minutes implementation time
- ✅ No security risks
- ✅ User sees actual browser automation
- ✅ No breaking changes
- ✅ Works immediately

**Cons:**
- ⚠️ Separate window (not embedded in Electron)
- ⚠️ Only works when browser is visible (not headless)

**Effort:** 30 minutes  
**Risk:** None  
**Verdict:** ✅ **APPROVED - Implement immediately**

---

### Option 2: Activity Log Streaming ✅
**Description:** Stream real-time activity logs from BrowserExecutor to Electron UI

**Implementation:**
- Add `_log_activity()` helper in browser_tools.py
- Update each browser tool to log activities
- Stream logs via existing WebSocket infrastructure
- Display in "Browser Activity" panel in Electron

**Example logs:**
- "🌐 Navigating to https://google.com"
- "⌨️ Typing 'Python tutorials' in search box"
- "🖱️ Clicking search button"
- "✅ Search results loaded"

**Pros:**
- ✅ Works in both headless and visible modes
- ✅ Detailed activity information
- ✅ Lightweight (just text streaming)
- ✅ 2 hours implementation time
- ✅ No security risks
- ✅ Great for debugging

**Cons:**
- ⚠️ Requires updating ~20 browser tool functions
- ⚠️ Text-only (not visual)

**Effort:** 2 hours  
**Risk:** Minimal  
**Verdict:** ✅ **APPROVED - Implement immediately**

---

### Option 3: Screenshot Streaming ⚠️
**Description:** Periodically capture and stream screenshots to Electron

**Pros:**
- Visual representation
- Works in headless mode

**Cons:**
- ❌ More complex than activity logs
- ❌ Higher bandwidth usage
- ❌ ~500ms latency
- ❌ Not as informative as activity logs
- ❌ Redundant if browser window is visible

**Effort:** 4-6 hours  
**Risk:** Low  
**Verdict:** ⚠️ **DEFERRED - Not needed if Options 1+2 implemented**

---

### Option 4: Complex Browser Embedding ❌
**Description:** Embed Chrome in Electron via CDP, Puppeteer rewrite, etc.

**Why it was considered:**
- Initial misunderstanding of user requirements
- Thought user wanted to share browser instances

**Why it's rejected:**
- ❌ User doesn't need embedding, just visibility
- ❌ 3-4 weeks of development time
- ❌ High complexity and risk
- ❌ Massive overkill for the actual requirement

**Effort:** 3-4 weeks  
**Risk:** High  
**Verdict:** ❌ **REJECTED - Doesn't match actual requirement**

---

## Decision

**Implement BOTH Option 1 + Option 2 immediately**

### **Part 1: Visible Browser Window Toggle** (30 minutes)
- Add UI toggle in Electron
- Pass flag to backend
- Use existing `headless` parameter
- User can watch browser automation live

### **Part 2: Activity Log Streaming** (2 hours)
- Add activity logging to browser tools
- Stream logs via WebSocket
- Display in Electron UI panel
- Works in both visible and headless modes

**Total Implementation Time:** 2.5 hours  
**Total Risk:** Minimal  
**Total Value:** Complete visibility into browser automation

---

## Implementation Plan

### Phase 1: Screenshot Streaming (1-2 days)

**Backend Changes:**
```python
# surface/src/surface/tools/browser_tools.py
def enable_electron_monitoring(interval_seconds: float = 0.5):
    """Enable periodic screenshot streaming to Electron."""
    # Capture screenshots at interval
    # Send via WebSocket
    pass

def initialize_browser(visible_in_electron: bool = False, **kwargs):
    if visible_in_electron:
        kwargs['headless'] = False
        enable_electron_monitoring()
    # ... existing code
```

**Frontend Changes:**
```javascript
// electron-app/src/renderer/js/app.js
// Add browser monitor panel
socket.on('browser_screenshot', (imageData) => {
  document.getElementById('browser-monitor').src = 
    `data:image/png;base64,${imageData}`;
});
```

**Deliverables:**
- Screenshot streaming functionality
- Browser Monitor panel in Electron UI
- `visible_in_electron` flag
- Documentation

---

### Phase 2: Puppeteer Migration (3-4 weeks)

**Step 1:** Create PuppeteerBrowserExecutor agent (1 week)
**Step 2:** Port critical browser tools (1-2 weeks)
**Step 3:** Electron CDP integration (3-5 days)
**Step 4:** Testing and validation (1 week)
**Step 5:** Documentation and rollout (2-3 days)

**Deliverables:**
- New PuppeteerBrowserExecutor agent
- Puppeteer-based browser tools
- CDP integration in Electron
- Migration guide
- Security hardening

---

## Security Considerations

### Phase 1 (Low Risk)
- ✅ Processes remain isolated
- ✅ No CDP exposure
- ✅ Existing cleanup handlers sufficient
- ✅ No new attack vectors

### Phase 2 (Medium Risk - Requires Mitigation)
- ⚠️ CDP port exposed on localhost
- **Required Mitigations:**
  - Authentication tokens for CDP connections
  - Bind to 127.0.0.1 only (not 0.0.0.0)
  - Connection timeout and rate limiting
  - Audit logging for CDP commands
  - Chrome sandbox mode
  - Proper cleanup on crashes
  - Security review before production

---

## Performance Impact

| Metric | Current | Phase 1 | Phase 2 |
|--------|---------|---------|---------|
| Chrome Instances | 2 | 2 | 1 |
| Memory Usage | 2x | 2x + 10MB | 1x |
| CPU Usage | 2x | 2x + 5% | 1x |
| Screenshot Latency | N/A | ~500ms | ~50ms |
| Development Effort | 0 | 1-2 days | 3-4 weeks |

---

## Consequences

### Positive
- ✅ User can monitor browser automation in Electron UI (Phase 1)
- ✅ Quick delivery with low risk (Phase 1)
- ✅ Validates need before major investment
- ✅ Clear migration path to modern architecture (Phase 2)
- ✅ No breaking changes for existing users
- ✅ Improved performance and resource usage (Phase 2)

### Negative
- ⚠️ Not true embedding in Phase 1 (acceptable tradeoff)
- ⚠️ Screenshot latency in Phase 1 (~500ms)
- ⚠️ Two Chrome instances remain in Phase 1
- ⚠️ Phase 2 requires significant development effort
- ⚠️ Security considerations in Phase 2 need careful handling

### Neutral
- Incremental approach allows course correction
- User feedback from Phase 1 informs Phase 2 decision
- Both phases are optional - can stop after Phase 1 if sufficient

---

## Open Questions

1. **Does user need true embedding or just visibility?**
   - If visibility → Phase 1 sufficient
   - If embedding → Phase 2 required

2. **Is screenshot latency acceptable?**
   - 500ms delay in Phase 1
   - 50ms delay in Phase 2

3. **Resource usage priority?**
   - If critical → Phase 2 needed (single Chrome instance)
   - If acceptable → Phase 1 sufficient (two instances)

4. **Development timeline constraints?**
   - If urgent → Phase 1 only
   - If flexible → Plan for Phase 2

---

## Related Decisions

- [electron-perform-api-streaming-integration.md](./electron-perform-api-streaming-integration.md) - WebSocket streaming infrastructure
- [remove-browser-screenshot-websocket.md](./remove-browser-screenshot-websocket.md) - Previous screenshot streaming removal

---

## References

- [A-Team Review: Electron Chrome Embedding](../review/A_TEAM_ELECTRON_CHROME_EMBEDDING_REVIEW.md)
- Selenium WebDriver: https://www.selenium.dev/documentation/webdriver/
- Chrome DevTools Protocol: https://chromedevtools.github.io/devtools-protocol/
- Puppeteer: https://pptr.dev/
- Electron BrowserView: https://www.electronjs.org/docs/latest/api/browser-view
- Pyppeteer: https://github.com/pyppeteer/pyppeteer

---

## Notes

**Team Consensus:**
- Alex (Architect): "Phase 1 now, Phase 2 if needed"
- Jordan (Backend): "Want Puppeteer, but Phase 1 is pragmatic"
- Casey (Frontend): "Phase 1 is easy, Phase 2 is doable but time-consuming"
- Morgan (DevOps): "Phase 1 is safe, Phase 2 needs security review"

**Key Insight:** The user's request is technically possible but requires significant architectural changes. A phased approach balances immediate value delivery with long-term architectural improvements while maintaining security and stability.
