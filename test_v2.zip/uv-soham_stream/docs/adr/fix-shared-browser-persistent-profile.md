# ADR: Fix Shared Browser to Use Persistent Profile

**Status:** Fixed  
**Date:** 2026-01-30  
**Context:** Shared browser not using persistent profile, losing cookies across runs

---

## Problem

The shared browser instance was created without a persistent profile, which meant:
- ❌ Cookies and sessions lost when browser closed
- ❌ Had to login every time
- ❌ No browser history or preferences saved
- ❌ Different behavior than `initialize_browser()` which uses profiles

```python
# Before - No persistent profile
chrome_options = Options()
chrome_options.add_argument('--no-sandbox')
# chrome_options.add_argument('--user-data-dir=...') ← Commented out!
shared_browser = webdriver.Chrome(options=chrome_options)
```

---

## Solution

Configure shared browser to use the **same persistent profile** as browser_tools:

```python
# After - With persistent profile
from pathlib import Path

chrome_options = Options()
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

# Use same profile directory as browser_tools
default_profile_dir = Path.home() / ".browser_executor" / "profiles" / "default_session"
default_profile_dir.mkdir(parents=True, exist_ok=True)
chrome_options.add_argument(f'--user-data-dir={default_profile_dir}')

# Anti-detection options
chrome_options.add_argument('--disable-blink-features=AutomationControlled')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)

shared_browser = webdriver.Chrome(options=chrome_options)
```

---

## Benefits

### ✅ Session Persistence Across Runs

**Before:**
```
Run 1: Login to website → ❌ Session lost when script ends
Run 2: Must login again → ❌ Session lost when script ends
Run 3: Must login again → ❌ ...
```

**After:**
```
Run 1: Login to website → ✅ Saved to profile
Run 2: Already logged in! ✅ Session restored from profile
Run 3: Still logged in! ✅ Session still there
```

### ✅ Consistency with Browser Tools

Both the shared browser AND `initialize_browser()` tool now use the **same profile directory**:
- `~/.browser_executor/profiles/default_session`

This means they share:
- Cookies
- LocalStorage
- Session storage
- Browser history
- Preferences
- Extensions

### ✅ Better for Testing

Once you login during development, you stay logged in for all subsequent runs until you explicitly clear the profile.

---

## Profile Location

**Default Profile Directory:**
```
~/.browser_executor/profiles/default_session/
```

This directory contains:
- `Cookies` - Cookie database
- `Local Storage/` - LocalStorage data
- `Session Storage/` - Session data
- `Preferences` - Browser settings
- `Extensions/` - Installed extensions

**To Clear Profile (Force Re-login):**
```bash
rm -rf ~/.browser_executor/profiles/default_session
```

---

## Property Bag Update

Also added profile path to property bag for reference:

```python
property_bag = {
    'browser': shared_browser,
    'browser_profile_path': str(default_profile_dir),  # ← New!
    'terminal_session': "surface_default_terminal",
    'browser_tabs': {},
    'session_data': {}
}
```

---

## Implementation Details

### Anti-Detection Options

Added options to make browser less detectable as automated:

```python
chrome_options.add_argument('--disable-blink-features=AutomationControlled')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)
```

This prevents websites from detecting automation via:
- `navigator.webdriver` (set to undefined instead of true)
- Automation extensions being visible
- Blink automation features

### Profile Directory Creation

Ensures profile directory exists before starting browser:

```python
default_profile_dir.mkdir(parents=True, exist_ok=True)
```

This prevents Chrome from failing if the directory doesn't exist.

---

## Testing

### Verify Profile Persistence

```bash
# Run 1: Login
./scripts/run_solve_task.sh "Login to example.com with username test@example.com"

# Run 2: Check if still logged in (should be!)
./scripts/run_solve_task.sh "Go to example.com and check if I'm logged in"
```

You should see that you're already logged in on Run 2.

### Check Profile Directory

```bash
ls -la ~/.browser_executor/profiles/default_session/
```

Should see files like:
- `Cookies`
- `Preferences`
- `Local Storage/`
- etc.

---

## Files Changed

- `surface_synapse/integration.py` - Added persistent profile configuration
- `docs/adr/property-bag-shared-instances.md` - Updated with profile details

---

## Related

- `docs/adr/property-bag-shared-instances.md` - Overall property bag pattern
- `docs/adr/fix-browser-tools-check-shared-first.md` - Browser tool integration fix
- `surface/src/surface/tools/browser_tools.py` - Browser tools use same profile

---

## Summary

Fixed shared browser to use persistent profile at `~/.browser_executor/profiles/default_session`, ensuring cookies, sessions, and browser state persist across runs. This matches the behavior of `initialize_browser()` tool and provides a better user experience by maintaining login sessions.
