# ADR: Automatic Compression and Retry on Context Length Errors

**Date:** 2026-01-30  
**Status:** Implemented

## Context

When using the BrowserExecutor (or any agent) with long conversation histories, users encounter context length errors from the LLM provider:

```
litellm.exceptions.BadRequestError: litellm.BadRequestError: OpenAIException - 
aws-bedrock error: The model returned the following errors: 
Input is too long for requested model.
```

### Current Behavior (Before Fix)

When this error occurs:
1. ❌ **Agent fails immediately** - No graceful handling
2. ❌ **User must manually fix** - Truncate history, clear session
3. ❌ **Loss of context** - Important conversation information lost
4. ❌ **Poor UX** - Cryptic error, unclear how to fix
5. ❌ **Manual intervention** - User must restart or modify code

### User Pain Points

**User's problem:**
> "we got litellm.exceptions.BadRequestError... in this sort of error use @Synapse_new/core/agentic_compressor.py to compress current session and then retry"

Users want:
- Automatic handling of context length errors
- Intelligent compression (not just truncation)
- Transparent retry without manual intervention
- Preservation of important context

## Decision

Implement **automatic compression and retry** using the AgenticCompressor from Synapse_new.

When a context length error occurs:
1. **Detect** - Catch `BadRequestError` with "Input is too long"
2. **Compress** - Use AgenticCompressor to intelligently compress conversation history
3. **Retry** - Re-execute agent with compressed context
4. **Repeat** - Up to 3 attempts with progressive compression
5. **Fail gracefully** - Clear error message if all retries fail

## Implementation

### Core Components

#### 1. CompressionRetryHandler

New utility class in `surface/src/surface/utils/compression_retry.py`:

```python
class CompressionRetryHandler:
    """
    Handles automatic compression and retry for context length errors.
    """
    
    def __init__(self, lm=None, max_retries: int = 3):
        self.max_retries = max_retries
        self.compressor = AgenticCompressor(lm=lm)
    
    def execute_with_retry(
        self,
        agent_callable: Callable,
        instruction: str,
        conversation_history: str = "",
        agent_name: str = "Agent",
        **kwargs
    ) -> Any:
        """Execute agent with automatic compression retry."""
```

**Key Features:**
- Detects context length errors automatically
- Uses AgenticCompressor for intelligent compression
- Progressive compression (starts at 70%, then 49%, then 34%)
- Preserves task-critical information
- Clear logging of compression stats
- Graceful failure with helpful error message

#### 2. Convenience Function

`execute_browser_with_compression_retry()` - Easy-to-use wrapper:

```python
result = execute_browser_with_compression_retry(
    agent=agent,
    instruction="Open WhatsApp",
    conversation_history=long_history,
    max_retries=3
)
```

#### 3. Integration with AgenticCompressor

Leverages existing Synapse_new compressor:

```python
# From Synapse_new/core/agentic_compressor.py
compressed = await self.compressor.compress(
    content=conversation_history,
    task_context={
        'actor_name': agent_name,
        'goal': instruction,
        'priority_keywords': keywords,
        'content_type': 'conversation'
    },
    target_tokens=target_tokens
)
```

**Benefits of AgenticCompressor:**
- ✅ **Intelligent** - Understands content, not just slicing
- ✅ **Context-aware** - Preserves task-relevant information
- ✅ **Quality metrics** - Reports compression quality (0-10)
- ✅ **Shapley-based** - Can use impact scores for prioritization
- ✅ **Explains** - Reports what was removed

## How It Works

### Flow Diagram

```
┌─────────────────────────────────────────────────┐
│ User: Execute agent with long conversation     │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│ execute_browser_with_compression_retry()        │
│                                                 │
│ Try 1: Execute with full conversation history  │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
          ┌──────────────┐
          │ Context too  │───No───► Success! ✅
          │    long?     │
          └──────┬───────┘
                 │ Yes
                 ▼
┌─────────────────────────────────────────────────┐
│ 🗜️ Compress conversation (70% target)          │
│                                                 │
│ AgenticCompressor intelligently compresses     │
│ preserving task-critical information           │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│ Try 2: Execute with compressed history         │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
          ┌──────────────┐
          │ Context too  │───No───► Success! ✅
          │    long?     │
          └──────┬───────┘
                 │ Yes
                 ▼
┌─────────────────────────────────────────────────┐
│ 🗜️ Compress MORE (49% of original target)      │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│ Try 3: Execute with more compressed history    │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
          ┌──────────────┐
          │ Context too  │───No───► Success! ✅
          │    long?     │
          └──────┬───────┘
                 │ Yes
                 ▼
┌─────────────────────────────────────────────────┐
│ ❌ Max retries reached                          │
│                                                 │
│ Clear error: "Failed to compress within 3      │
│ attempts. Consider starting new session."      │
└─────────────────────────────────────────────────┘
```

### Compression Strategy

**Progressive Compression:**
- **Attempt 1**: Full history (100%)
- **Attempt 2**: 70% of original (compression ratio: 0.7)
- **Attempt 3**: 49% of original (0.7 × 0.7 = 0.49)
- **Attempt 4**: 34% of original (0.7 × 0.7 × 0.7 = 0.343)

**Intelligent Preservation:**
```python
task_context = {
    'actor_name': 'BrowserExecutor',
    'goal': 'Open WhatsApp Web',
    'query': 'Open WhatsApp Web',
    'priority_keywords': ['WhatsApp', 'Web', 'Open', 'authentication'],
    'content_type': 'conversation'
}
```

The AgenticCompressor:
1. Understands the current task
2. Identifies critical information
3. Removes redundant/low-value content
4. Preserves context needed for task
5. Reports quality metrics

## Usage

### Example 1: Simple Integration

```python
from surface.agents.browser_executor import BrowserExecutorAgent
from surface.utils.compression_retry import execute_browser_with_compression_retry

agent = BrowserExecutorAgent(max_iters=50)

result = execute_browser_with_compression_retry(
    agent=agent,
    instruction="Open WhatsApp Web",
    conversation_history=long_history,
    max_retries=3
)
```

**That's it!** Compression and retry happen automatically.

### Example 2: Updated example_browser_simple.py

```python
# Automatic compression retry enabled by default
if COMPRESSION_RETRY_AVAILABLE:
    result = execute_browser_with_compression_retry(
        agent=agent,
        instruction=instruction,
        conversation_history="",
        terminal_session=None,
        session_id="simple_example",
        max_retries=3,
        lm=dspy_lm
    )
else:
    # Fallback to direct execution
    result = agent(instruction=instruction, ...)
```

### Example 3: Dedicated Demo

```bash
poetry run python surface/example_browser_with_compression.py
```

Output:
```
🧪 Browser Executor with Automatic Compression Retry
================================================================================

📊 Conversation history length: 15000 characters
📋 Task: Open https://example.com

🚀 Executing with compression retry protection...
--------------------------------------------------------------------------------

🚀 Executing BrowserExecutor (attempt 1)
⚠️  Context length error detected: Input is too long
🗜️ Attempting compression (ratio: 0.7)
🗜️ Compressing conversation history for BrowserExecutor...
   Original: 3750 tokens
   Target: 2625 tokens (70%)
✅ Intelligently compressed: 15000 → 10500 chars
   Compressed to 10500 chars, retrying...

🔄 Retry 1/3 with compression ratio 0.7
🚀 Executing BrowserExecutor (attempt 2)
✅ Success after 1 compression retries!

✅ Task Complete!
```

## Benefits

### For Users

1. ✅ **Automatic** - No manual intervention needed
2. ✅ **Transparent** - Just works, compression happens behind the scenes
3. ✅ **Intelligent** - Preserves important context, not blind truncation
4. ✅ **Resilient** - Up to 3 retry attempts
5. ✅ **Clear errors** - If all retries fail, get helpful error message

### For Developers

1. ✅ **Drop-in** - Easy to integrate with existing code
2. ✅ **Configurable** - Adjust max_retries, compression ratio
3. ✅ **Monitoring** - Detailed logging of compression process
4. ✅ **Graceful** - Fails gracefully with clear guidance

### For Production

1. ✅ **Robust** - Handles edge cases automatically
2. ✅ **Observable** - Logs show compression stats
3. ✅ **Recoverable** - Most context length errors resolved automatically
4. ✅ **User-friendly** - No cryptic errors

## Comparison

### Before (Manual Handling)

```python
try:
    result = agent(instruction, conversation_history=long_history)
except litellm.exceptions.BadRequestError as e:
    if "Input is too long" in str(e):
        # User must manually handle
        # What do I do now??
        # Truncate? How much? What to keep?
        history = long_history[:5000]  # ❌ Blind truncation
        result = agent(instruction, conversation_history=history)
    else:
        raise
```

**Problems:**
- ❌ Manual error handling
- ❌ Blind truncation loses context
- ❌ No retry logic
- ❌ No intelligence

### After (Automatic Handling)

```python
result = execute_browser_with_compression_retry(
    agent=agent,
    instruction=instruction,
    conversation_history=long_history
)
```

**Benefits:**
- ✅ Automatic error handling
- ✅ Intelligent compression
- ✅ Progressive retry logic
- ✅ Task-aware preservation

## Error Detection

The handler detects various context length error patterns:

```python
error_patterns = [
    "input is too long",
    "context length exceeded",
    "maximum context length",
    "token limit exceeded",
    "too many tokens",
    "context window exceeded"
]
```

Works with multiple LLM providers:
- ✅ AWS Bedrock
- ✅ OpenAI
- ✅ Anthropic
- ✅ LiteLLM router
- ✅ Other providers with similar errors

## Fallback Strategy

If AgenticCompressor is not available:

```python
# Simple truncation fallback
target_chars = target_tokens * 4
compressed = "...[earlier conversation compressed]...\n\n" + history[-target_chars:]
```

Still better than failing! But AgenticCompressor is recommended.

## Monitoring and Logging

### Compression Events

```
🗜️ Compressing conversation history for BrowserExecutor...
   Original: 3750 tokens
   Target: 2625 tokens (70%)
   High-impact items: WhatsApp, authentication, QR code
   Low-impact items: None - preserve all
✅ Intelligently compressed: 15000 → 10500 chars
   Quality score: 8.5/10
   Removed: Redundant greetings, repeated tool outputs
```

### Retry Events

```
⚠️  Context length error detected: Input is too long
🗜️ Attempting compression (ratio: 0.7)
   Compressed to 10500 chars, retrying...
🔄 Retry 1/3 with compression ratio 0.7
✅ Success after 1 compression retries!
```

### Failure Events

```
❌ Max retries (3) reached - context still too long
   Original history: 50000 chars
   Compressed history: 17000 chars
RuntimeError: Failed to compress context within 3 attempts.
Consider starting a new session or reducing conversation history.
```

## Configuration

### Adjust Max Retries

```python
result = execute_browser_with_compression_retry(
    agent=agent,
    instruction=instruction,
    conversation_history=history,
    max_retries=5  # More aggressive retry
)
```

### Custom Compression Ratio

Modify in `CompressionRetryHandler`:

```python
compression_ratio = 0.5  # Start with 50% (more aggressive)
```

### Different Compressor

```python
handler = CompressionRetryHandler(lm=custom_lm, max_retries=3)
```

## Testing

### Test with Long History

```bash
poetry run python surface/example_browser_with_compression.py
```

Creates a simulated long conversation history and demonstrates automatic compression.

### Test Different Scenarios

```python
# Scenario 1: No compression needed
short_history = "User: Hello\nAgent: Hi"
result = execute_browser_with_compression_retry(agent, "task", short_history)
# ✅ Executes directly, no compression

# Scenario 2: Single compression sufficient
medium_history = "..." * 1000
result = execute_browser_with_compression_retry(agent, "task", medium_history)
# ✅ Compresses once, succeeds

# Scenario 3: Multiple compressions needed
very_long_history = "..." * 10000
result = execute_browser_with_compression_retry(agent, "task", very_long_history)
# ✅ Compresses progressively, eventually succeeds

# Scenario 4: Even compression can't help
impossibly_long_history = "..." * 1000000
result = execute_browser_with_compression_retry(agent, "task", impossibly_long_history)
# ❌ Fails with clear error after 3 attempts
```

## Consequences

### Positive

1. ✅ **Automatic error recovery** - Most context length errors resolved
2. ✅ **Better UX** - Users don't see cryptic errors
3. ✅ **Intelligent** - Uses LLM to understand and compress content
4. ✅ **Transparent** - Works behind the scenes
5. ✅ **Configurable** - Adjust behavior as needed
6. ✅ **Observable** - Clear logging of compression process
7. ✅ **Production-ready** - Robust error handling

### Negative

1. ⚠️ **Extra LLM calls** - Compression uses LLM (cost consideration)
2. ⚠️ **Latency** - Retry adds time (but better than failing!)
3. ⚠️ **Dependency** - Requires Synapse_new/AgenticCompressor
4. ⚠️ **Context loss** - Even intelligent compression loses some info

### Mitigation

- **Cost**: Compression is only used on errors (rare)
- **Latency**: Only adds time when necessary (alternative is failure)
- **Dependency**: Fallback to simple truncation if not available
- **Context**: AgenticCompressor preserves task-critical info

## Future Enhancements

### 1. Proactive Compression

Don't wait for error - compress preemptively when nearing limit:

```python
if estimated_tokens > 0.9 * max_tokens:
    conversation_history = compress_proactively(conversation_history)
```

### 2. Sliding Window

Keep recent history, compress old history:

```python
recent = history[-10:]  # Keep last 10 turns
old = history[:-10]
compressed_old = compress(old)
history = compressed_old + recent
```

### 3. Shapley-Based Prioritization

Use credit assignment to prioritize important turns:

```python
# Compress with Shapley credits
compressed = compress(
    history,
    shapley_credits={'turn_1': 0.8, 'turn_2': 0.2, ...}
)
```

### 4. Adaptive Compression

Learn optimal compression ratios per task type:

```python
# Task: web scraping → can compress more (0.3)
# Task: debugging → preserve more (0.8)
```

## Related Work

- **AgenticCompressor** (`Synapse_new/core/agentic_compressor.py`) - Core compression
- **Token Utils** (`Synapse/core/token_utils.py`) - Token counting
- **Context Management** - Session and memory management

## Related ADRs

- [Browser Executor File Output](browser-executor-file-output.md)
- [Browser Executor Default Persistence](browser-executor-default-persistence.md)
- [Agent Tool Assignment Refactoring](agent-tool-assignment-refactoring.md)

## References

- LiteLLM Exception Handling
- DSPy Context Management
- AgenticCompressor Documentation
- Token Limit Best Practices

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Prompted by:** User experiencing "Input is too long" errors  
**Implementation:** Complete  
**Files Created:**
- `surface/src/surface/utils/compression_retry.py`
- `surface/src/surface/utils/__init__.py`
- `surface/example_browser_with_compression.py`

**Files Modified:**
- `surface/example_browser_simple.py`
