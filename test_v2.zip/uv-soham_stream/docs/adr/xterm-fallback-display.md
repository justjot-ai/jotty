# ADR: xterm.js Fallback Display

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** xterm.js CDN loading failure causing infinite retry loop

## Problem

xterm.js is loaded from CDN but sometimes fails to load completely, causing:
1. **Infinite retry loop** - Terminal keeps retrying initialization forever
2. **No terminal output visible** - User sees nothing while terminal is working
3. **Performance degradation** - Hundreds of setTimeout calls stack up

From logs:
```
agent-view-manager.js:728 xterm.js not loaded yet, will retry...
(repeated 228+ times)
```

## Root Cause

1. **CDN Dependency:** xterm.js loads from `https://cdn.jsdelivr.net/npm/xterm@5.3.0/lib/xterm.js`
2. **Network Issues:** CDN might be slow, blocked, or down
3. **No Timeout:** Original retry logic had no maximum limit
4. **No Fallback:** If xterm.js fails, terminal is completely unusable

## Decision

Implement a robust fallback system:

### 1. Maximum Retry Limit

```javascript
this.initRetries = 0;
this.maxRetries = 50; // Max 5 seconds of retries (50 * 100ms)
```

After 50 retries, stop trying and use fallback.

### 2. Output Buffering

```javascript
this.outputBuffer = []; // Buffer output while initializing

// In handleOutput/handleCommand
if (!this.initialized) {
  this.outputBuffer.push(data.output);
  this.initialize();
  return;
}
```

Terminal events are buffered and flushed when initialization completes.

### 3. Fallback Display

When xterm.js fails to load, use a simple HTML-based terminal:

```javascript
useFallbackDisplay() {
  this.container.innerHTML = `
    <div class="terminal-fallback">
      <div class="terminal-fallback-header">
        <span>⚡ Terminal Output</span>
        <span>(xterm.js failed to load - using fallback)</span>
      </div>
      <div class="terminal-fallback-content"></div>
    </div>
  `;
  
  this.fallbackContent = document.getElementById('terminal-fallback-content');
  this.initialized = true;
  
  // Flush buffered output
  this.outputBuffer.forEach(output => this.appendToFallback(output));
}
```

### 4. ANSI Code Stripping

Fallback display strips ANSI escape codes for clean text:

```javascript
appendToFallback(text) {
  // Strip ANSI escape codes
  const cleanText = text.replace(/\x1b\[[0-9;]*m/g, '').replace(/\r\n/g, '\n');
  
  const line = document.createElement('div');
  line.textContent = cleanText;
  this.fallbackContent.appendChild(line);
  
  // Auto-scroll
  this.fallbackContent.scrollTop = this.fallbackContent.scrollHeight;
}
```

## Implementation

### Changes to `TerminalViewHandler`

**Before:**
- Infinite retries
- No output buffering
- No fallback

**After:**
- Max 50 retries (5 seconds)
- Output buffering during initialization
- HTML fallback display
- ANSI code stripping
- Auto-scroll

### CSS Styling

Added `.terminal-fallback` styles:
- Similar look to xterm.js
- Warning banner about fallback mode
- Scrollable content area
- Monospace font
- Dark theme matching

## Consequences

### Positive
- ✅ No more infinite retry loops
- ✅ Terminal output always visible (even if xterm.js fails)
- ✅ Buffered output preserved and displayed
- ✅ Clear warning when fallback is used
- ✅ Better user experience

### Negative
- ⚠️ Fallback display lacks xterm.js features (colors, cursor, etc.)
- ⚠️ ANSI codes are stripped (no colored output)
- ⚠️ Not as polished as xterm.js

### Neutral
- Fallback is only used when xterm.js completely fails to load
- Most users will never see the fallback
- Performance impact is minimal

## Future Improvements

### Option 1: Bundle xterm.js Locally

Instead of loading from CDN, bundle xterm.js with the app:

```bash
npm install xterm xterm-addon-fit
```

```html
<!-- Local instead of CDN -->
<script src="node_modules/xterm/lib/xterm.js"></script>
```

**Pros:** No CDN dependency, always available  
**Cons:** Larger bundle size, need to manage updates

### Option 2: Lazy Load with Better Error Handling

```javascript
async loadXterm() {
  try {
    await import('https://cdn.jsdelivr.net/npm/xterm@5.3.0/lib/xterm.js');
    await import('https://cdn.jsdelivr.net/npm/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.js');
    return true;
  } catch (error) {
    console.error('Failed to load xterm.js:', error);
    return false;
  }
}
```

### Option 3: Multiple CDN Fallbacks

Try multiple CDNs in sequence:
1. jsDelivr (primary)
2. unpkg (fallback 1)
3. cdnjs (fallback 2)
4. Local bundle (fallback 3)

## Testing

### Test Fallback Trigger

1. **Block CDN in DevTools:**
   - Open DevTools → Network tab
   - Add block pattern: `*xterm*`
   - Reload page

2. **Verify Fallback:**
   - Terminal should show fallback display after 5 seconds
   - Warning message should appear
   - Terminal output should be visible

3. **Test Output Buffering:**
   - Send terminal events immediately after activation
   - Verify all output appears (nothing lost)

### Test Normal Operation

1. **With CDN Available:**
   - xterm.js should load normally
   - No fallback should be used
   - Full xterm.js features available

## Related Files

- `/electron-app/src/renderer/js/agent-view-manager.js` - Fallback logic
- `/electron-app/src/renderer/css/agent-views.css` - Fallback styles
- `/electron-app/src/renderer/index.html` - xterm.js CDN loading

## Recommendation

**Short-term:** Use current fallback solution (implemented)  
**Long-term:** Bundle xterm.js locally to eliminate CDN dependency

This ensures the terminal always works, regardless of network conditions.
