# RCA: Memory Directory Not Found Error

**Date**: 2026-02-05  
**Status**: ✅ Implemented  
**Issue**: `❌ Failed to load previous state: ❌ Memory directory not found: /Users/anshulchauhan/Tech/term/global/synapse_state/memories`

## Context

During Synapse initialization, the system attempts to load previous session state from a memory directory. The error occurs when the expected directory structure doesn't exist:

```
2026-02-05 16:50:17.702 | ERROR | Synapse.core.conductor:1236 | ❌ Failed to load previous state: ❌ Memory directory not found: /Users/anshulchauhan/Tech/term/global/synapse_state/memories
Expected directory structure from previous session is missing.
```

## 5 Whys Root Cause Analysis

### Why 1: Why is the memory directory not found?
**Answer**: The code is looking for `/Users/anshulchauhan/Tech/term/global/synapse_state/memories`, but the actual directory is `/Users/anshulchauhan/Tech/term/synapse_outputs/global/synapse_state/memories`.

### Why 2: Why is the wrong path being used?
**Answer**: The path resolution logic in `load_previous_state()` incorrectly calculates the global directory when resolving the `latest` symlink.

### Why 3: Why does the path resolution differ from directory creation?
**Answer**: `_setup_directories()` correctly uses `self.base_dir / "global"` (which is `synapse_outputs/global`), but `load_previous_state()` uses `latest_dir.parent.parent / "global"` which goes up two levels instead of one.

### Why 4: Why does load_previous_state() go up two levels?
**Answer**: The condition `latest_dir.parent.name == "outputs"` fails because the directory is named `synapse_outputs`, not `outputs`. The condition `"run_" in latest_dir.name` also fails because `latest_dir` is a symlink, so `latest_dir.name` is `"latest"`, not a run folder name.

### Why 5: Why doesn't the condition match the actual directory structure?
**Answer**: The path resolution logic was written assuming `output_base_dir` would be named `outputs`, but it's actually `synapse_outputs`. Additionally, the logic doesn't account for symlinks properly - it checks the symlink name instead of the resolved path.

## Root Cause

**The root cause is**: **Path resolution bug in `load_previous_state()`** - incorrect logic for determining global directory when `output_base_dir` is not named `outputs` and when dealing with symlinks. The method uses `latest_dir.parent.parent / "global"` instead of `latest_dir.parent / "global"`.

## Actual Path Resolution Issue

**Current behavior:**
- `output_base_dir` = `/Users/anshulchauhan/Tech/term/synapse_outputs`
- `latest_dir` = `/Users/anshulchauhan/Tech/term/synapse_outputs/latest` (symlink)
- `_setup_directories()` creates: `/Users/anshulchauhan/Tech/term/synapse_outputs/global/` ✅
- `load_previous_state()` looks for: `/Users/anshulchauhan/Tech/term/global/` ❌

**The bug is in `load_previous_state()` lines 192-195:**

```python
# Current (BUGGY) code:
if latest_dir.parent.name == "outputs" or "run_" in latest_dir.name:
    global_dir = latest_dir.parent / "global"
else:
    global_dir = latest_dir.parent.parent / "global"  # ❌ Goes up TWO levels
```

**Why it fails:**
1. `latest_dir.parent.name` = `"synapse_outputs"` (not `"outputs"`)
2. `latest_dir.name` = `"latest"` (not a run folder, so `"run_"` not in name)
3. Falls into `else` branch: `latest_dir.parent.parent` = `/Users/anshulchauhan/Tech/term`
4. Results in wrong path: `/Users/anshulchauhan/Tech/term/global`

## Suggested Fixes

### Fix 1: Fix Path Resolution Logic (Recommended)
**Location**: `Synapse/core/session_manager.py` (line 192-195)

```python
# Fix: Use same logic as _setup_directories() and resolve symlink
latest_dir_resolved = latest_dir.resolve() if latest_dir.is_symlink() else latest_dir

# Determine global directory using same logic as _setup_directories()
if latest_dir_resolved.parent.name == "outputs" or "run_" in latest_dir_resolved.name or latest_dir_resolved.parent.name.endswith("_outputs"):
    # We're in a run folder or outputs directory, go to parent/global
    global_dir = latest_dir_resolved.parent / "global"
else:
    # Fallback: create global sibling to parent
    global_dir = latest_dir_resolved.parent / "global"
```

**Better fix - use self.base_dir directly:**

```python
# Use the same base_dir that was used in _setup_directories()
# This ensures consistency between creation and loading
if self.base_dir.parent.name == "outputs" or "run_" in self.session_dir.name or self.base_dir.name.endswith("_outputs"):
    global_dir = self.base_dir / "global"
else:
    global_dir = self.base_dir.parent / "global"
```

### Fix 2: Store Global Directory Path in SessionManager
**Location**: `Synapse/core/session_manager.py`

Store `self.global_base_dir` during `_setup_directories()` and reuse it:

```python
def load_previous_state(self) -> Optional[Dict[str, Any]]:
    """Load previous state using the same global directory as setup."""
    # Use the global_base_dir that was set during _setup_directories()
    global_synapse_dir = self.global_synapse_dir  # Already set in __init__
    
    # Load memories from GLOBAL location
    if self.config.persist_memories:
        state['memories'] = self._load_memories(global_synapse_dir)
    # ... rest of loading
```

### Fix 3: Add Defensive Directory Creation
**Location**: `Synapse/core/session_manager.py` `_load_memories()` method (line 296)

```python
def _load_memories(self, source_dir: Path) -> Dict[str, Any]:
    """Load all memory files from GLOBAL location."""
    memories = {}
    mem_dir = source_dir / "memories"
    
    if not mem_dir.exists():
        # Create directory structure if missing (defensive programming)
        logger.warning(f"⚠️ Memory directory not found: {mem_dir}, creating it...")
        mem_dir.mkdir(parents=True, exist_ok=True)
        # Return empty memories dict for first run
        return memories
    
    # ... rest of loading logic
```

## Implementation Priority

1. **Critical**: Fix 1 (Fix Path Resolution) - Fixes the root cause, ensures correct path
2. **High**: Fix 2 (Store Global Directory) - Prevents future inconsistencies
3. **Medium**: Fix 3 (Defensive Creation) - Handles edge cases gracefully

## Consequences

### Positive
- ✅ First-run scenarios handled gracefully
- ✅ No error spam in logs for expected scenarios
- ✅ System can start fresh without previous state
- ✅ More robust state management

### Considerations
- ⚠️ Need to ensure directory permissions are correct
- ⚠️ Should document expected directory structure
- ⚠️ May want to add cleanup logic for old state files

## Testing

1. **First Run Test**: Start Synapse with no existing memory directory → Should create directory and continue
2. **Existing State Test**: Start with existing state → Should load successfully
3. **Permission Test**: Test with read-only directory → Should handle gracefully
4. **Cleanup Test**: Delete directory and restart → Should recreate and continue

## Files to Modify

- `Synapse/core/session_manager.py`:
  - Fix `load_previous_state()` path resolution (line 192-195)
  - Optionally store `global_base_dir` for reuse
  - Add defensive directory creation in `_load_memories()` (line 296)
- `Synapse/core/conductor.py` (error handling around line 1236) - Already handles gracefully

## Verification

After fix, verify:
1. ✅ `load_previous_state()` resolves to `/Users/anshulchauhan/Tech/term/synapse_outputs/global/synapse_state/memories`
2. ✅ Matches the path created by `_setup_directories()`
3. ✅ Works with both `outputs` and `synapse_outputs` directory names
4. ✅ Handles symlinks correctly
