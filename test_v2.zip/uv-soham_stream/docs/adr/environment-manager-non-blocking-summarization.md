# ADR: Environment Manager Non-Blocking Summarization

**Date:** 2026-01-31  
**Status:** Implemented  
**Context:** Environment Manager Performance Optimization

## Problem

The Environment Manager's summarization process was blocking the main execution flow:

1. When `add_to_current_env()` detected file size exceeded threshold, it called `_summarize_environment()` synchronously
2. The `_summarize_environment()` method held a lock during the entire LLM API call
3. This caused delays in task execution whenever summarization was triggered
4. Any concurrent operations on the environment had to wait for summarization to complete

**Example blocking behavior:**
```
2026-01-31 15:55:30.302 | INFO | Added to environment: 9869 bytes
2026-01-31 15:55:30.302 | INFO | Environment file exceeds 10240 bytes, triggering summarization
[BLOCKS HERE FOR ~24 SECONDS during LLM call]
2026-01-31 15:55:54.491 | INFO | Periodic summarization triggered
```

## Solution

Implemented queue-based non-blocking summarization:

### Architecture Changes

1. **Summarization Queue**: Added `queue.Queue()` to queue summarization requests
2. **Worker Thread**: New dedicated thread processes queued summarization tasks
3. **Status Tracking**: Added `_summarization_in_progress` flag to prevent duplicate requests
4. **Queue Methods**:
   - `_queue_summarization(reason)`: Non-blocking, queues request
   - `_summarization_worker()`: Background thread processes queue
   - `_do_summarize()`: Internal method with actual logic

### Key Implementation Details

```python
# Non-blocking queue-based approach
def add_to_current_env(self, content: str):
    # ... add content ...
    if file_size > self.max_size_before_summarize:
        self._queue_summarization("size_threshold")  # Returns immediately
        
def _queue_summarization(self, reason: str):
    if not self._summarization_in_progress:
        self._summarization_queue.put_nowait(reason)
        
def _summarization_worker(self):
    while self._running:
        reason = self._summarization_queue.get(timeout=1.0)
        self._summarize_environment()
        self._summarization_queue.task_done()
```

### Thread Architecture

- **Periodic Thread** (`EnvSummarizer`): Checks size every N seconds, queues if needed
- **Worker Thread** (`EnvWorker`): Processes summarization queue in background
- Both threads are daemon threads that gracefully shutdown when `_running = False`

## Benefits

1. **No Blocking**: `add_to_current_env()` returns immediately
2. **Better Performance**: Main execution flow continues while summarization runs in background
3. **Deduplication**: Skip queue if summarization already in progress
4. **Graceful Shutdown**: Worker completes pending tasks before stopping
5. **Flexible Control**: `force_summarize(blocking=True/False)` for manual control

## Trade-offs

1. **Slight Delay**: Summarization happens shortly after threshold, not immediately
2. **Race Conditions**: Environment might grow slightly more before summarization completes
3. **Memory**: Queue holds pending requests (minimal impact, typically 0-1 items)

## Usage

```python
# Non-blocking (default for automatic triggers)
env_manager.add_to_current_env("Large content...")  # Returns immediately

# Blocking (for manual control when needed)
env_manager.force_summarize(blocking=True)  # Waits for completion

# Non-blocking manual
env_manager.force_summarize(blocking=False)  # Queues and returns
```

## Statistics

Added queue metrics to `get_statistics()`:
- `summarization_in_progress`: Boolean flag
- `queued_summarizations`: Number of pending requests

## Testing

Test with:
```bash
cd Synapse/core
python environment_manager.py
```

## Related

- `environment_manager.py`: Core implementation
- `synapse_core.py`: Uses EnvironmentManager
- ADR: environment-manager-cot-summarization.md (original design)
