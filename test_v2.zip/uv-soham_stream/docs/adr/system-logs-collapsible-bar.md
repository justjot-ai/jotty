# ADR: System Logs with Collapsible Bar

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Add system event logs with collapsible bar when agents are active

## Problem

When no agents are active, the center screen shows empty space. Users need visibility into system events, agent activations, and general activity even when agents aren't running.

Additionally, when agents are active, users should still have access to system logs without losing the agent views.

## Decision

Implement a **System Event Logs** view with two states:

### 1. Expanded State (No Agents Active)
- Full-screen logs view
- Shows all system events with timestamps
- Similar to terminal fallback design
- Clear button to reset logs

### 2. Collapsed State (Agents Active)
- Collapses to a bottom bar
- Shows event count
- Click to expand (hides agent views)
- Click again to collapse (shows agent views)

## Implementation

### HTML Structure
```html
<div class="system-logs-view">
  <!-- Collapsed bar (shown when agents active) -->
  <div class="system-logs-bar" onclick="toggleSystemLogs()">
    <span>📊 System Event Logs</span>
    <span class="count">0 events</span>
    <span class="toggle">▲</span>
  </div>
  
  <!-- Expanded header (shown when no agents) -->
  <div class="system-logs-header">
    <span>📊 System Event Logs</span>
    <button onclick="clearSystemLogs()">Clear</button>
  </div>
  
  <!-- Log content -->
  <div class="system-logs-content">
    <!-- Log entries appended here -->
  </div>
</div>
```

### Log Entry Format
```javascript
{
  timestamp: "02:15:30.123",
  module: "agent" | "system" | "websocket",
  message: "✅ BrowserExecutor activated",
  level: "info" | "success" | "debug" | "warning" | "error"
}
```

### CSS States
```css
/* Expanded - full screen */
.system-logs-view.expanded {
  display: flex;
  height: 100%;
}

/* Collapsed - bottom bar */
.system-logs-view.collapsed {
  display: flex;
  height: 40px;
  position: fixed;
  bottom: 0;
  left: 240px;
  right: 260px;
}
```

### JavaScript Logic
```javascript
// Show expanded when no agents
showEmptyState() {
  hideAllAgentViews();
  showSystemLogs(); // expanded state
}

// Collapse when first agent activates
activateAgent(agent) {
  if (activeAgents.size === 0) {
    hideSystemLogs(); // collapse to bar
  }
  // ... activate agent
}

// Toggle between collapsed/expanded
toggleSystemLogs() {
  if (expanded) {
    collapse();
    showAgentViews();
  } else {
    expand();
    hideAgentViews();
  }
}
```

## Features

### Automatic Logging
- ✅ Agent activation/deactivation
- ✅ Task completion
- ✅ WebSocket events
- ✅ System messages
- ✅ Unknown message warnings

### Log Management
- Auto-scroll to latest
- Limit to 1000 entries (auto-trim oldest)
- Clear button
- Event counter in collapsed bar

### Visual Design
- Color-coded by level (info, success, debug, warning, error)
- Monospace font for timestamps
- Module names highlighted
- Smooth animations
- Consistent with terminal fallback design

## Benefits

✅ **Visibility:** Always see system activity  
✅ **Context:** Understand what's happening  
✅ **Debugging:** Track events and issues  
✅ **Non-intrusive:** Collapses when agents active  
✅ **Accessible:** One click to expand/collapse  

## Trade-offs

⚠️ **Memory:** Stores up to 1000 log entries  
⚠️ **Performance:** Minimal (DOM updates only on new logs)  
⚠️ **Screen space:** Takes 40px at bottom when collapsed  

## User Experience

### No Agents Active
```
┌─────────────────────────────────────┐
│ 📊 System Event Logs         [Clear]│
├─────────────────────────────────────┤
│ 02:15:30.123  system   Initialized  │
│ 02:15:31.456  agent    ✅ Browser...│
│ 02:15:32.789  agent    ⏸️  Browser...│
│ 02:15:33.012  system   Waiting...   │
└─────────────────────────────────────┘
```

### Agents Active (Collapsed)
```
┌─────────────────────────────────────┐
│                                     │
│     🌐 BrowserExecutor (TOP)        │
│                                     │
├─────────────────────────────────────┤
│                                     │
│     ⌘ TerminalExecutor (BOTTOM)     │
│                                     │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│ 📊 System Event Logs  45 events  ▲ │ ← Click to expand
└─────────────────────────────────────┘
```

### Agents Active (Expanded)
```
┌─────────────────────────────────────┐
│ 📊 System Event Logs         [Clear]│
├─────────────────────────────────────┤
│ 02:15:30.123  system   Initialized  │
│ 02:15:31.456  agent    ✅ Browser...│
│ 02:15:32.789  agent    ⏸️  Browser...│
│ 02:15:33.012  system   Waiting...   │
│ 02:15:34.567  agent    ✅ Terminal..│
│                                     │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│ 📊 System Event Logs  45 events  ▼ │ ← Click to collapse
└─────────────────────────────────────┘
```

## Testing

1. Start with no agents - should see expanded logs
2. Activate agent - logs should collapse to bottom bar
3. Click bar - logs should expand, agents hide
4. Click bar again - logs collapse, agents show
5. Verify event count updates
6. Verify auto-scroll works
7. Verify clear button works

## Related Files

- `/electron-app/src/renderer/js/agent-view-manager.js` - System logs logic
- `/electron-app/src/renderer/css/agent-views.css` - System logs styles
- `/electron-app/src/renderer/js/app.js` - WebSocket event logging

## Future Enhancements

- Filter by module/level
- Search logs
- Export logs
- Persist logs across sessions
- Configurable log limit
