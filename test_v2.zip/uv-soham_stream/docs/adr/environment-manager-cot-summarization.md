# ADR: Environment Manager with CoT Summarization

**Status:** Implemented  
**Date:** 2026-01-31  
**Author:** A-Team  
**Component:** `Synapse/core/environment_manager.py`

## Context

During long-running multi-agent task executions, tracking the execution context and environment state becomes crucial for understanding the current state, debugging issues, and making informed decisions. However, continuously appending to a context log can lead to:

1. **Context bloat**: Large files that become unwieldy
2. **Information overload**: Too much detail obscures important patterns
3. **Loss of key insights**: Important information buried in verbose logs
4. **Storage inefficiency**: Redundant or low-value information taking up space

We needed a solution that:
- Tracks environment context continuously
- Automatically summarizes and condenses information
- Uses Chain-of-Thought (CoT) reasoning to preserve important details
- Runs periodically without manual intervention
- Maintains thread safety for concurrent operations

## Decision

We created an **Environment Manager** module that provides:

### Core Features

1. **Persistent Context Tracking**
   - Stores environment context in `env.md` file
   - Located alongside Q-tables: `{synapse_dir}/env/env.md`
   - Thread-safe append operations
   - Timestamped entries

2. **CoT-Based Summarization**
   - Uses DSpy `ChainOfThought` signature for intelligent summarization
   - Reasoning about what to keep vs. prune
   - Extracts key insights automatically
   - Documents what was removed and why

3. **Automatic Background Process**
   - Runs every 1 minute (configurable)
   - Triggers summarization when file exceeds size threshold
   - Non-blocking daemon thread
   - Graceful start/stop controls

4. **Snapshot History**
   - Maintains historical snapshots before summarization
   - Configurable snapshot retention (default: 10)
   - Stored in `env_history.json`
   - Allows rollback and comparison

### API Design

```python
from Synapse import EnvironmentManager, create_environment_manager

# Create manager
env_manager = create_environment_manager(
    config, 
    goal_context="Multi-agent task execution"
)

# Add context
env_manager.add_to_current_env("Started task execution")
env_manager.add_to_current_env("Agent1 completed subtask A")

# Get current environment
content = env_manager.get_current_env()

# Force summarization (manual trigger)
env_manager.force_summarize()

# Get statistics
stats = env_manager.get_statistics()

# Access snapshots
snapshot = env_manager.get_snapshot(-1)  # Latest snapshot

# Cleanup
env_manager.stop_auto_summarization()
```

### DSpy Signature

```python
class EnvironmentSummarizationSignature(dspy.Signature):
    """Chain-of-Thought signature for summarizing environment context."""
    
    current_content = dspy.InputField(desc="Current content of environment.md file")
    goal_context = dspy.InputField(desc="The root goal/task being worked on")
    timestamp = dspy.InputField(desc="Current timestamp for reference")
    
    reasoning = dspy.OutputField(desc="Step-by-step reasoning about what's important to keep")
    summarized_content = dspy.OutputField(desc="Summarized and condensed environment context")
    key_insights = dspy.OutputField(desc="Key insights or patterns detected in the environment")
    pruned_items = dspy.OutputField(desc="What was removed and why")
```

## Configuration

All thresholds and parameters are configurable (NO HARDCODING):

```python
class SynapseConfig:
    env_dir: Optional[Path] = None  # Override default location
    env_summarization_interval: int = 60  # Seconds between checks
    env_max_size_bytes: int = 50000  # 50KB threshold
    env_min_lines: int = 100  # Minimum lines before summarizing
    env_max_snapshots: int = 10  # Snapshot history retention
```

## Integration Points

### 1. Persistence Layer (`persistence.py`)

Added methods to `Vault` class:

```python
def save_environment_manager(self, env_manager: 'EnvironmentManager')
def load_environment_manager(self, config, goal_context: str) -> 'EnvironmentManager'
```

Updated directory structure:
```
outputs/run_X/synapse_state/
├── q_tables/
├── env/              # NEW
│   ├── env.md
│   └── env_history.json
├── memories/
└── ...
```

### 2. Module Exports (`Synapse/__init__.py`)

Added to public API:
- `EnvironmentManager`
- `EnvironmentSnapshot`
- `create_environment_manager`

### 3. Testing (`tests/test_environment_manager.py`)

Comprehensive test suite covering:
- Initialization and directory creation
- Adding content (single, multiple, empty)
- Getting current environment
- Manual and automatic summarization
- Thread safety
- Snapshot management
- Persistence across sessions
- Statistics and utilities

## Files Created/Modified

### New Files
1. ✅ `Synapse/core/environment_manager.py` (525 lines)
2. ✅ `tests/test_environment_manager.py` (431 lines)
3. ✅ `Synapse/examples/environment_manager_example.py` (365 lines)
4. ✅ `docs/adr/environment-manager-cot-summarization.md` (this file)

### Modified Files
1. ✅ `Synapse/core/persistence.py`
   - Added `env/` directory to structure
   - Added `save_environment_manager()` method
   - Added `load_environment_manager()` method

2. ✅ `Synapse/__init__.py`
   - Added imports for environment manager components
   - Added to `__all__` exports

## Benefits

### 1. Automatic Context Management
- No manual intervention required
- Runs in background continuously
- Thread-safe for concurrent operations

### 2. Intelligent Summarization
- Uses CoT reasoning to preserve important details
- Extracts key insights automatically
- Documents pruning decisions
- Maintains context relevance

### 3. Storage Efficiency
- Prevents unbounded growth
- Configurable size thresholds
- Snapshot history for rollback

### 4. Developer Experience
- Simple API (`add_to_current_env`, `get_current_env`)
- Factory function for easy creation
- Rich statistics and debugging info
- Comprehensive examples

### 5. Generic Design
- No domain-specific logic
- Works for any use case
- Fully configurable
- Follows Synapse patterns (NO HARDCODING)

## Usage Patterns

### Pattern 1: Task Execution Tracking
```python
env_manager.add_to_current_env("Starting data pipeline")
env_manager.add_to_current_env("Agent DataMind processing batch 1")
env_manager.add_to_current_env("Agent DataMind completed batch 1")
```

### Pattern 2: Error Context
```python
env_manager.add_to_current_env("Error in Agent CodeMaster: Syntax error in generated code")
env_manager.add_to_current_env("Retry attempt 1 with different prompt")
env_manager.add_to_current_env("Retry successful")
```

### Pattern 3: State Changes
```python
env_manager.add_to_current_env("Model switched from GPT-4 to Claude Sonnet")
env_manager.add_to_current_env("Updated temperature parameter to 0.7")
```

### Pattern 4: Multi-Agent Coordination
```python
env_manager.add_to_current_env("Agent1 requested help from Agent2")
env_manager.add_to_current_env("Agent2 shared tool result with Agent1")
```

## Thread Safety

All operations are protected by `threading.Lock`:
- `add_to_current_env()` - Lock during file write
- `get_current_env()` - Lock during file read
- `_summarize_environment()` - Lock during summarization
- `clear_environment()` - Lock during clear

Background thread runs independently with periodic checks.

## Performance Considerations

### Memory
- Keeps at most `env_max_snapshots` in memory
- Old snapshots discarded automatically
- Each snapshot stores content + metadata (~1-50KB typically)

### CPU
- Background thread sleeps between checks (configurable interval)
- Summarization triggered only when threshold exceeded
- DSpy CoT call is primary compute cost (LLM API call)

### I/O
- Appends are fast (file opened in append mode)
- Reads are cached (file system handles caching)
- Summarization rewrites entire file (infrequent operation)

## Future Enhancements

Possible improvements (not implemented):

1. **Compression**: Gzip older snapshots
2. **Search**: Full-text search across environment history
3. **Metrics**: Track summarization effectiveness (compression ratio, insights extracted)
4. **Hierarchical**: Multiple environment contexts (global, per-agent)
5. **Streaming**: WebSocket streaming for real-time monitoring
6. **Export**: Export to different formats (JSON, HTML, PDF)

## Testing

Run tests:
```bash
pytest tests/test_environment_manager.py -v
```

Run examples:
```bash
python Synapse/examples/environment_manager_example.py
```

## Related ADRs

- None (new feature)

## References

- Q-learning implementation: `Synapse/core/q_learning.py`
- Persistence layer: `Synapse/core/persistence.py`
- DSpy ChainOfThought: https://dspy-docs.vercel.app/

## Conclusion

The Environment Manager provides automatic, intelligent context tracking with CoT-based summarization. It follows Synapse design principles (NO HARDCODING, configurable, generic) and integrates seamlessly with the existing persistence architecture.

**Status**: ✅ Fully Implemented and Tested
