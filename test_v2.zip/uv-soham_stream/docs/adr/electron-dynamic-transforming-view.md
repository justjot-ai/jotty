# ADR: Electron Dynamic Transforming View

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: State-driven UI that transforms from welcome screen to workspace

## Decision

Implement a dynamic, state-driven view system that provides an elegant transformation from a simple welcome interface to a full-featured multi-agent workspace. This creates a progressive disclosure pattern that doesn't overwhelm users on first launch.

## User Experience Flow

### Initial State: Welcome Screen
**Before First Message (60/40 split)**
- **60%**: Large animated googly eyes with UV branding
- **40%**: Simple welcome message and chat input
- Minimal, friendly, inviting interface
- Eyes animate subtly (looking around)

### Working State: Workspace
**After First Message Sent (3-column layout)**
- Eyes disappear completely
- Welcome chat disappears
- Full workspace materializes with smooth transition
- **Left Sidebar** (240px):
  - Tasks/TODOs panel
  - Session info panel
- **Center Stage** (fluid):
  - 2x2 expansion grid for agent terminals
  - Browser, Terminal, Web Search, Planner
  - Active terminal expands automatically
- **Right Sidebar** (260px):
  - Memory panel
  - Environment context
  - Active agents status
- **Bottom**: Chat input bar (persistent)

## Implementation

### HTML Structure
```html
<div class="container dynamic-view">
  <!-- Welcome State -->
  <div class="welcome-state" id="welcome-state">
    <section class="eyes-welcome">...</section>
    <section class="chat-welcome">...</section>
  </div>

  <!-- Workspace State -->
  <div class="workspace-state" id="workspace-state" style="display: none;">
    <div class="sidebar-workspace left">...</div>
    <div class="center-workspace">
      <div class="agents-grid-workspace">...</div>
    </div>
    <div class="sidebar-workspace right">...</div>
    <div class="chat-bar-workspace">...</div>
  </div>
</div>
```

### State Management
```javascript
this.currentState = 'welcome'; // or 'workspace'
this.firstMessageSent = false;
```

### Transformation Logic
1. User types first message in welcome input
2. `handleWelcomeMessage()` triggered
3. `transformToWorkspace()` called:
   - Fade out welcome state (0.5s)
   - Hide welcome state
   - Show workspace state
   - Fade in workspace state (0.5s)
   - Focus workspace chat input
   - Send first message via backend
4. Mark `firstMessageSent = true`
5. Update `currentState = 'workspace'`

### CSS Animations
```css
.welcome-state {
  transition: opacity 0.5s ease;
}

.workspace-state {
  transition: opacity 0.5s ease;
}

.agent-terminal-ws {
  opacity: 0.35;
  transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
}

.agent-terminal-ws.active {
  opacity: 1;
  transform: scale(1);
}
```

## Agent Terminal System

### 4 Agent Terminals (2x2 Grid)
1. **Browser** (🌐)
   - Shows browser screenshots
   - Receives screenshots via WebSocket
   - Selenium automation

2. **Terminal** (⌘)
   - Command execution output
   - Shell operations
   - pexpect integration

3. **Web Search** (🔍)
   - Search results
   - Research output
   - Serper API

4. **Planner** (🧠)
   - Task orchestration
   - Planning output
   - Agent coordination

### Expansion System
- Inactive terminals: 35% opacity, scaled 97%
- Active terminal: 100% opacity, expanded 1.8x
- Smooth cubic-bezier transitions
- Grid automatically adjusts:
  ```css
  .agents-grid-workspace.focus-0 {
    grid-template-columns: 1.8fr 1fr;
    grid-template-rows: 1.8fr 1fr;
  }
  ```

### Status Indicators
- **Pending**: Gray, "Inactive"
- **Active**: Cyan, pulsing, "Working..."
- **Working**: Yellow, pulsing
- **Complete**: Green, "Complete"

## Panels

### Left Sidebar
**Tasks Panel**
- Shows active tasks as they're created
- Initially shows "Waiting for task..."
- Tasks marked complete with ✓
- Supports running/complete states

**Session Panel**
- Session ID
- Status (ready/working/error)

### Right Sidebar
**Memory Panel**
- Empty state: "No memories yet"
- Will show episodic/semantic memories
- Expandable for future

**Environment Panel**
- Current working directory
- Shell type
- Python version
- Other env variables

**Active Agents Panel**
- Dot indicator per agent
- Idle: gray dot
- Active: cyan pulsing dot
- Shows which agents are working

## Progressive Disclosure Benefits

### For First-Time Users
- **Not Overwhelming**: Simple eyes + chat input
- **Friendly**: Googly eyes create personality
- **Clear CTA**: One input field, obvious action
- **No Cognitive Load**: Minimal decisions to make

### For Active Users
- **Powerful**: Full workspace after engagement
- **Transparent**: See all agent activity
- **Organized**: Clear information hierarchy
- **Focused**: Expansion grid highlights active work

### For Power Users
- **Can Toggle**: Switch to classic/grid views
- **Efficient**: All info visible without scrolling
- **Extensible**: Easy to add more panels/terminals

## Design Inspirations

### Welcome State
- macOS Spotlight-like simplicity
- Google search page minimalism
- Duolingo's friendly mascot approach
- Progressive web app first-run experiences

### Workspace State
- VSCode terminal panels
- Multi-agent orchestration dashboards
- Terminal multiplexers (tmux, screen)
- Professional IDE layouts

## Technical Details

### Welcome Eyes Animation
```javascript
animateWelcomeEyes() {
  setInterval(() => {
    const randomX = (Math.random() - 0.5) * 20;
    const randomY = (Math.random() - 0.5) * 20;
    pupils.forEach(pupil => {
      pupil.style.transform = `translate(${randomX}px, ${randomY}px)`;
    });
  }, 3000);
}
```

### Terminal Activation
```javascript
activateAgentTerminal(index, status) {
  // Add active/working classes
  // Update status text
  // Expand grid to focus terminal
  // Update agent status indicator
}
```

### Browser Screenshot Integration
- Screenshots update browser terminal in workspace
- Placeholder hidden automatically
- Image displayed with object-fit: contain
- Terminal activates on first screenshot

## View Cycling

Users can cycle through 3 views:
1. **Dynamic** (default) - Welcome → Workspace transformation
2. **Classic** - Original vertical layout with eyes
3. **Grid** - Full grid layout (no welcome state)

Toolbar button cycles: Dynamic → Classic → Grid → Dynamic

## Future Enhancements

### Welcome State
- Animated typing effect for welcome message
- Random friendly greetings
- Tips/suggestions for first-time users
- Voice input option

### Workspace State
- Click terminal to expand (manual focus)
- Drag & drop terminal reordering
- Detach terminal to separate window
- Save custom layouts
- Terminal history/replay

### Additional Terminals
- **Code Editor** - Show generated code
- **File Browser** - Visualize file operations
- **Network Monitor** - API calls tracking
- **Logs** - System logs and debugging

### Memory System
- Clickable memory items
- Memory categories (episodic, semantic, procedural)
- Memory search
- Memory timeline

### Environment Context
- Click to change directory
- Environment variable editor
- Git status integration
- Docker container status

## Files Modified

### HTML
- `electron-app/src/renderer/index.html`
  - Added complete welcome-state structure
  - Added complete workspace-state structure
  - Hidden classic/grid views by default

### CSS
- `electron-app/src/renderer/css/styles.css`
  - Added ~700 lines for dynamic view system
  - Welcome state styles (eyes, chat)
  - Workspace state styles (3-column grid)
  - Agent terminals with expansion
  - All panels and status indicators

### JavaScript
- `electron-app/src/renderer/js/app.js`
  - Added `currentState` tracking
  - Added `setupDynamicView()` method
  - Added `handleWelcomeMessage()` method
  - Added `transformToWorkspace()` method
  - Added `handleWorkspaceMessage()` method
  - Added `sendMessageWorkspace()` method
  - Added `activateAgentTerminal()` method
  - Added `completeAgentTerminal()` method
  - Added `updateTaskDisplay()` method
  - Updated `toggleView()` to support 3 views
  - Updated browser screenshot handler

## Consequences

### Positive
- **Reduced First-Run Anxiety**: Simple welcome reduces cognitive load
- **Smooth Learning Curve**: Features revealed progressively
- **Professional Feel**: Workspace looks like pro tool
- **Personality**: Googly eyes make it friendly and memorable
- **Scalable**: Easy to add more terminals/panels
- **Transparent**: All agent activity visible in workspace

### Negative
- **Initial Confusion**: Some users may not realize transformation happens
- **State Management**: More complex state tracking needed
- **Animation Performance**: Transitions may lag on slower machines
- **More Code**: Doubled UI complexity (2 states instead of 1)

### Neutral
- First message triggers transformation (irreversible in session)
- Can cycle to other views if preferred
- Transformation happens once per session
- State not persisted across restarts (always starts with welcome)

## Success Metrics

### User Engagement
- **Goal**: 90%+ of users send first message within 30 seconds
- **Metric**: Time to first message
- **Indicator**: Welcome state effectiveness

### Task Completion
- **Goal**: Users complete tasks without switching views
- **Metric**: View toggle frequency
- **Indicator**: Workspace state usefulness

### Feature Discovery
- **Goal**: Users notice agent activity in terminals
- **Metric**: Terminal focus time
- **Indicator**: Transparency effectiveness

## Accessibility

### Keyboard Navigation
- Tab through inputs
- Enter to send
- Esc to clear input
- Arrow keys for history (future)

### Screen Readers
- All panels have ARIA labels
- Status changes announced
- Terminal content accessible
- Agent names readable

### Reduced Motion
- Users with motion preferences should see instant transitions
- Future: Respect `prefers-reduced-motion` media query
