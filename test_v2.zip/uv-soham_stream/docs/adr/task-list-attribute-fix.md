# ADR: Fix Task List Attribute Error

**Status:** Fixed  
**Date:** 2026-02-02  
**Context:** Task List Streaming Bug Fix

## Problem

The task list event was not being yielded to the frontend due to an `AttributeError`:

```
WARNING | Failed to yield task list: 'SubtaskState' object has no attribute 'created_at'
```

This prevented the task list from appearing in the Electron UI.

## Root Cause

In `Synapse/core/roadmap.py`, the `get_all_tasks_list()` method was trying to access `task.created_at`, but the `SubtaskState` dataclass only has:
- `started_at` (when task execution begins)
- `completed_at` (when task finishes)

There is no `created_at` attribute.

## Solution

**File**: `Synapse/core/roadmap.py`

Removed the non-existent `created_at` field from the task list export:

```python
def get_all_tasks_list(self) -> List[Dict[str, Any]]:
    """Get complete list of all tasks with their details."""
    tasks_list = []
    for task_id, task in self.subtasks.items():
        tasks_list.append({
            'task_id': task_id,
            'description': task.description,
            'actor': task.actor,
            'status': task.status.value,
            'priority': task.priority,
            'estimated_reward': task.estimated_reward,
            'confidence': task.confidence,
            'progress': task.progress,
            'depends_on': task.depends_on,
            'blocks': task.blocks,
            'attempts': task.attempts,
            'max_attempts': task.max_attempts,
            'failure_reasons': task.failure_reasons,
            'started_at': task.started_at.isoformat() if task.started_at else None,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None,
            'estimated_duration': task.estimated_duration if hasattr(task, 'estimated_duration') else None,
        })
    return tasks_list
```

### Changes Made

1. **Removed**: `'created_at': task.created_at.isoformat() if task.created_at else None`
2. **Added**: `'estimated_duration': task.estimated_duration if hasattr(task, 'estimated_duration') else None`

## SubtaskState Attributes

For reference, `SubtaskState` has these timing attributes:

```python
@dataclass
class SubtaskState:
    # Timing
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    estimated_duration: float = 60.0  # seconds (can be learned)
```

**No `created_at` field exists.**

## Impact

### Before Fix
- Task list event failed with `AttributeError`
- Frontend never received task list
- Left sidebar showed "Waiting for task..." indefinitely
- Debug logs showed: `WARNING | Failed to yield task list`

### After Fix
- Task list event yields successfully
- Frontend receives complete task breakdown
- Left sidebar populates with all tasks
- Debug logs show: `🔍 Yielded complete task list: N tasks`

## Testing

To verify the fix:

1. **Restart backend**: The server needs to reload the fixed code
2. **Start a task** in the Electron app
3. **Check logs** for:
   ```
   ✅ Yielded complete task list: 8 tasks
   ```
4. **Check frontend** for:
   - Task list appears in left sidebar
   - Console shows: `📋 [TASK LIST] Received complete task list`
   - Tasks grouped by status with details

## Error Log Reference

**Before Fix:**
```
2026-02-02 00:47:27.461 | WARNING | Synapse.core.conductor:4660 | 
Failed to yield task list: 'SubtaskState' object has no attribute 'created_at'
```

**After Fix:**
```
2026-02-02 00:50:15.123 | INFO | Synapse.core.conductor:4658 | 
🔍 Yielded complete task list: 8 tasks
```

## Related

- `task-list-streaming.md` - Original task list implementation
- `task-list-ui-implementation-complete.md` - UI implementation
- `SubtaskState` dataclass in `Synapse/core/roadmap.py`

## Lesson Learned

Always verify dataclass attributes before accessing them, especially when:
- Working with dynamically created objects
- Exporting data for external consumption
- Dealing with optional/nullable fields

Consider adding validation or using `getattr()` with defaults for robustness.
