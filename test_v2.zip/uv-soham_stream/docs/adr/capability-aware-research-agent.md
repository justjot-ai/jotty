# ADR: Capability-Aware Research Agent

**Status:** Implemented  
**Date:** 2026-01-29  
**Decision Makers:** Development Team

## Context

Previously, the ResearchAgent generated implementation plans without knowing what execution capabilities were actually available. This led to plans that suggested:
- Browser automation when no BrowserExecutor was available
- Shell commands when TerminalExecutor wasn't configured
- Web search when WebsearchExecutor wasn't in the system

The gap between "what was planned" and "what could be executed" caused:
1. **Implementation failures** - Tasks requiring unavailable capabilities
2. **Wasted research** - LLM researched solutions that couldn't be executed
3. **Poor user experience** - Plans looked comprehensive but were infeasible

## Decision

**Update the ResearchAgent and its sub-agents to be capability-aware.**

The implementation plan must be constrained to only use available execution capabilities.

### Implementation

1. **Updated Signatures** - Added `available_capabilities` input field:
   - `GenerateResearchPlan` - Constrains research planning
   - `SynthesizeFindings` - Constrains implementation plan generation

2. **Updated Sub-Agents** - Accept and use capabilities:
   - `PlanGeneratorAgent.forward()` - Receives capabilities parameter
   - `FindingsSynthesizerAgent.forward()` - Receives capabilities parameter

3. **Updated ResearchAgent**:
   - `ResearchContext` - Stores available_capabilities
   - `forward()` - Accepts capabilities list
   - Tool wrappers - Pass capabilities to sub-agents

4. **Updated Example** - Extract capabilities from actors:
   ```python
   available_capabilities = [
       "coding", "software_engineering", "algorithms",
       "shell", "cli", "terminal",
       "web_search", "information_retrieval",
       # ... from all available actors
   ]
   agent(instruction, available_capabilities=capabilities)
   ```

## Rationale

### Why This Approach?

1. **Truth in Planning**: LLM knows constraints upfront
2. **Realistic Plans**: Only suggest what can be executed
3. **Better Research**: Focus on relevant solutions
4. **Fail Fast**: Catch capability gaps at planning stage
5. **Explicit Contract**: Clear what system can/cannot do

### Why Not Alternatives?

**❌ Post-Generation Filtering**
- Wastes LLM calls on infeasible plans
- Requires complex post-processing
- May still miss edge cases

**❌ Static Capability Mapping**
- Doesn't adapt to runtime configuration
- Requires code changes to add capabilities
- Not flexible for different deployments

**❌ No Constraints (Status Quo)**
- Generates infeasible plans
- Execution failures
- Poor user experience

**✅ Capability-Aware Planning (Chosen)**
- Plans are feasible by design
- LLM focuses research appropriately
- Adapts to available actors
- Clear contract

## Examples

### Before (No Capability Awareness)

```python
agent = create_research_agent()
result = agent("Build a stock price tracker")

# Generated plan includes:
# 1. Use Selenium for browser automation  ❌ (no BrowserExecutor)
# 2. Deploy with Docker compose          ❌ (no deployment capability)
# 3. Set up CI/CD pipeline              ❌ (not available)
```

### After (Capability-Aware)

```python
available_capabilities = [
    "coding", "implementation", "testing",
    "shell", "terminal", "scripting",
    "web_search", "information_retrieval"
]

agent = create_research_agent()
result = agent(
    "Build a stock price tracker",
    available_capabilities=capabilities
)

# Generated plan includes:
# 1. Use requests library for API calls  ✅ (coding capability)
# 2. Write shell script for execution   ✅ (shell capability)
# 3. Manual testing with test data       ✅ (testing capability)
# 
# NOT included:
# ❌ Browser automation (not available)
# ❌ Docker deployment (not available)
# ❌ CI/CD setup (not available)
```

## Consequences

### Positive

1. **Feasible Plans**: 100% of plan steps can be executed
2. **Focused Research**: LLM doesn't waste time on unavailable solutions
3. **Clear Constraints**: Explicit about system limitations
4. **Better UX**: Users know what's possible
5. **Flexible**: Adapts to different actor configurations
6. **Early Validation**: Catch gaps before execution

### Negative

1. **More Configuration**: Must pass capabilities to agent
2. **Potentially Limited Plans**: Can't suggest "ideal" solution if capabilities missing
3. **Verbose**: Capability list can be long

### Mitigation

1. **Default Capabilities**: Can provide sensible defaults
2. **Capability Expansion**: Easy to add new capabilities
3. **Clear Messaging**: LLM can explain capability constraints
4. **Documentation**: ADR and guide explain usage

## Configuration

### Capability List Format

Simple list of strings (no structure needed):
```python
available_capabilities = [
    # Core programming
    "coding", "software_engineering", "algorithms", "debugging",
    
    # Data science
    "ml", "data_science", "model_training", "analysis",
    
    # System operations
    "shell", "cli", "terminal", "os_commands", "scripting",
    
    # Web & automation
    "web_automation", "browser_interaction", "form_submission",
    "web_search", "information_retrieval",
    
    # Domain specific
    "games", "finance", "media_processing"
]
```

### Extracting from Actors

```python
# From actor definitions
actors = [
    {"name": "CodeMaster", "capabilities": ["coding", "debugging"]},
    {"name": "TerminalExecutor", "capabilities": ["shell", "cli"]},
    # ...
]

# Extract all unique capabilities
all_capabilities = list(set(
    cap
    for actor in actors
    for cap in actor["capabilities"]
))

# Pass to research agent
result = agent(instruction, available_capabilities=all_capabilities)
```

## Signature Changes

### GenerateResearchPlan

```python
# Before
class GenerateResearchPlan(dspy.Signature):
    instruction = dspy.InputField(desc="The implementation instruction")
    research_plan = dspy.OutputField(desc="Research plan")

# After
class GenerateResearchPlan(dspy.Signature):
    instruction = dspy.InputField(desc="The implementation instruction")
    available_capabilities = dspy.InputField(
        desc="List of execution capabilities available"
    )
    research_plan = dspy.OutputField(
        desc="Research plan feasible with available capabilities"
    )
```

### SynthesizeFindings

```python
# Before
class SynthesizeFindings(dspy.Signature):
    instruction = dspy.InputField(desc="Original instruction")
    research_history = dspy.InputField(desc="Research findings")
    implementation_plan = dspy.OutputField(desc="Implementation plan")

# After
class SynthesizeFindings(dspy.Signature):
    instruction = dspy.InputField(desc="Original instruction")
    research_history = dspy.InputField(desc="Research findings")
    available_capabilities = dspy.InputField(
        desc="List of execution capabilities available"
    )
    implementation_plan = dspy.OutputField(
        desc="Implementation plan ONLY using available capabilities"
    )
```

## Testing

### Verification

```bash
# Test capability awareness
python -m Synapse_new.example_research

# Verify capabilities are logged
# Expected log: "Available capabilities: coding, shell, web_search, ..."
```

### Expected Behavior

1. **Logs capabilities** at agent initialization
2. **Passes capabilities** to sub-agents (logged)
3. **Constrains plan** to available capabilities
4. **Does not suggest** unavailable capabilities

## Future Enhancements

1. **Capability Validation**: Check if suggested steps use only available capabilities
2. **Capability Recommendations**: Suggest which capabilities would improve the plan
3. **Capability Gaps**: Explicitly list what's missing for "ideal" solution
4. **Dynamic Capabilities**: Query actors at runtime for current capabilities
5. **Capability Categories**: Group related capabilities for better prompts

## References

- Implementation: `Synapse_new/agents/research_agent.py`
- Sub-agents: `Synapse_new/agents/plan_generator_agent.py`, `findings_synthesizer_agent.py`
- Signatures: `Synapse_new/signatures/research_signatures.py`
- Example: `Synapse_new/example_research.py`
- Pattern: Constraint-based AI planning

## Acceptance Criteria

- [x] Signatures updated with available_capabilities field
- [x] Sub-agents accept and pass capabilities parameter
- [x] ResearchAgent stores capabilities in context
- [x] ResearchAgent passes capabilities to sub-agents
- [x] Example script extracts and passes capabilities
- [x] No linter errors
- [x] Documentation created
- [x] Verification test passes

## Migration

No breaking changes for existing code. Capabilities parameter is optional:

```python
# Still works (no capabilities constraint)
agent(instruction)

# New way (with capabilities)
agent(instruction, available_capabilities=capabilities)
```
