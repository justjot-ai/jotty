# ADR: VLM Tools Not Being Used - Root Cause and Fix

**Status**: Fixed  
**Date**: 2026-02-08  
**Context**: VLM state identification tools were registered but not being used by agents

## Problem

VLM tools (`inspect_browser_state`, `visual_inspect`, `inspect_file_visually`, `inspect_pptx_slides`, `inspect_code_for_errors`) were:
- ✅ Successfully loaded (5 tools)
- ✅ Injected into all actors by `swarm_service.py` 
- ✅ Available to architect/auditor agents
- ❌ **NOT being merged into actor's ReAct tool dict** (only 3 tools merged instead of 5)

### Observed Behavior

**Logs showed:**
```
🔍 Injected 5 VLM tools into BrowserExecutor's actor tools  # swarm_service.py
🔧 Injected 3 tools into actor (generate.tools)            # SynapseCore (OVERWRITES!)
🔧 Merged 3 Synapse-injected tools into ReAct               # Only 3 tools available
```

**Expected:**
- 5 VLM tools + 3 actor tools = 8 total tools merged

**Actual:**
- Only 3 tools merged (VLM tools were lost)

## Root Cause

**Location**: `Synapse/core/synapse_core.py::_inject_actor_tools()`

**Issue**: Line 444 was **overwriting** `_synapse_additional_tools` instead of **merging**:

```python
# ❌ BEFORE (BUG):
self.actor._synapse_additional_tools = tools  # Overwrites existing 5 VLM tools!
```

**Sequence of Events:**
1. `swarm_service.py` sets `agent._synapse_additional_tools = [5 VLM tools]` ✅
2. `SynapseCore.__init__()` calls `_inject_actor_tools(actor_tools)` where `actor_tools = [3 tools]`
3. `_inject_actor_tools()` **overwrites** `_synapse_additional_tools` with only 3 tools ❌
4. `BaseSwarmAgent.aforward()` merges only 3 tools into ReAct ❌

## Solution

**Fix**: Merge existing `_synapse_additional_tools` with new tools instead of overwriting:

```python
# ✅ AFTER (FIX):
if hasattr(self.actor, '_synapse_additional_tools') and self.actor._synapse_additional_tools:
    # Merge existing tools with new tools (avoid duplicates)
    existing_tool_names = {getattr(t, '__name__', None) or str(t) for t in self.actor._synapse_additional_tools}
    merged_tools = list(self.actor._synapse_additional_tools)
    for tool in tools:
        tool_name = getattr(tool, '__name__', None) or str(tool)
        if tool_name not in existing_tool_names:
            merged_tools.append(tool)
    self.actor._synapse_additional_tools = merged_tools
else:
    self.actor._synapse_additional_tools = tools
```

**Applied to two code paths:**
1. When actor has tool containers (line ~444)
2. When actor has no tool containers (line ~429)

## Impact

**Before Fix:**
- VLM tools registered but not accessible to agents
- Agents couldn't use `inspect_browser_state()` for state identification
- Only 3 tools available instead of 8

**After Fix:**
- All 5 VLM tools + 3 actor tools = 8 tools merged correctly
- Agents can now use VLM tools for visual state inspection
- Tools are properly available during ReAct execution

## Testing

To verify the fix works:
1. Check logs for: `🔧 Merged X new tools with Y existing tools → Z total`
2. Verify agent logs show all 8 tools available
3. Test that `inspect_browser_state()` can be called by BrowserExecutor
4. Confirm VLM tools appear in ReAct tool dict

## Related Files

- `Synapse/core/synapse_core.py` - Fixed `_inject_actor_tools()`
- `uv/src/uv/services/swarm_service.py` - Sets VLM tools (no changes needed)
- `surface/src/surface/agents/base_agent.py` - Merges tools (no changes needed)
