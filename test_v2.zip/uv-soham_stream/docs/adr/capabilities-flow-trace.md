# Capabilities Flow Trace

**Date:** 2026-01-30  
**Context:** Understanding where agent capabilities come from  

---

## The Question

When TodoCreatorAgent optimizes the DAG and says:
```
KEEP: task_4 | REASON: Uses existing BrowserExecutor capability for message extraction
```

**WHERE do these "BrowserExecutor capabilities" come from?**

---

## The Flow

### 1. Agent Creation (surface_synapse/integration.py:240-244)

```python
agents = {
    "BrowserExecutor": BrowserExecutorAgent(max_iters=max_iters),
    "TerminalExecutor": TerminalExecutorAgent(max_iters=max_iters),
    "WebSearchAgent": WebSearchAgent(max_iters=max_iters),
}
```

**Note:** Agents are created BUT no capabilities are explicitly set!

### 2. AgentConfig Creation (surface_synapse/integration.py:317-330)

```python
actors.append(
    AgentConfig(
        name=agent_name,
        agent=agent_instance,
        architect_prompts=[str(architect_path)] if architect_exists else [],
        auditor_prompts=[str(auditor_path)] if auditor_exists else [],
        architect_tools=architect_research_tools,
        auditor_tools=auditor_terminal_tools,
        enable_architect=enable_architect,
        enable_auditor=enable_auditor,
        # Note: NO capabilities parameter!
    )
)
```

**Note:** `AgentConfig` is created WITHOUT any `capabilities` parameter!

### 3. Conductor Initialization (Synapse/core/conductor.py:~1800-1870)

During Conductor `__init__`, the `ToolShed` is created:

```python
# Line ~1821
self.tool_shed = ToolShed(
    metadata_tool_registry=self.metadata_tool_registry,
    config=self.config
)

# Line ~1823
self.agentic_tool_selector = AgenticToolSelector(
    tool_shed=self.tool_shed,
    lm=self.lm
)
```

The `ToolShed` contains a `CapabilityIndex` which:
- Discovers tools from agents
- Extracts capabilities from tool names and descriptions
- Builds a capability registry

### 4. Capability Discovery (Synapse/core/tool_shed.py)

The `CapabilityIndex` auto-discovers capabilities by:
1. Scanning tool signatures
2. Analyzing tool names (e.g., `navigate_to_url` → "navigation" capability)
3. Parsing tool descriptions for keywords
4. Building semantic capability mappings

Example:
```python
# BrowserExecutor tools → Discovered capabilities
initialize_browser → ["browser", "automation", "web"]
navigate_to_url → ["browser", "navigation", "web"]
click_element → ["browser", "interaction", "clicking"]
type_text → ["browser", "interaction", "typing", "forms"]
take_screenshot → ["browser", "capture", "verification"]
# ... etc
```

### 5. Actor Creation with Capabilities (Synapse/core/conductor.py:4260-4273)

When creating actors for TodoCreatorAgent:

```python
for name, config in self.actors.items():
    if config.enabled:
        # Try to get capabilities from config
        capabilities = config.capabilities or []
        
        # If not set, try metadata
        if not capabilities and config.metadata:
            capabilities = config.metadata.get('capabilities', [])
        
        # Create actor with capabilities
        actors.append(Actor(
            name=name,
            capabilities=capabilities,  # ← This is where capabilities go
            description=self._get_agent_description(name, config)
        ))
```

**The Problem:** Since `AgentConfig` doesn't have `capabilities` set, and `metadata` is also empty, **the capabilities list is EMPTY!**

---

## Current State: CAPABILITIES ARE EMPTY!

When you see in the logs:
```
KEEP: task_4 | REASON: Uses existing BrowserExecutor capability for message extraction
```

This is **TodoCreatorAgent's LLM inferring** capabilities from:
1. Agent name ("BrowserExecutor" → probably has browser capabilities)
2. Agent description (from `_get_agent_description`)
3. Context/reasoning (not from actual capability list)

**The actual `capabilities` list passed to TodoCreatorAgent is EMPTY** because `AgentConfig` doesn't define it!

---

## The Solution: Add Capabilities to AgentConfig

### Option 1: Extract from Agent Signature/Tools

Modify `surface_synapse/integration.py` to extract capabilities from agent:

```python
# For BrowserExecutor
if hasattr(agent_instance, 'TOOLS'):
    capabilities = list(set([
        tool.__name__.split('_')[0]  # e.g., navigate → "navigate"
        for tool in agent_instance.TOOLS
    ]))
elif hasattr(agent_instance, 'capabilities'):
    capabilities = agent_instance.capabilities
else:
    # Infer from agent name
    capabilities = _infer_capabilities_from_name(agent_name)

# Pass to AgentConfig
actor_config = AgentConfig(
    name=agent_name,
    agent=agent_instance,
    capabilities=capabilities,  # ← ADD THIS!
    ...
)
```

### Option 2: Define in Agent Class

Add to `surface/src/surface/agents/browser_executor.py`:

```python
class BrowserExecutorAgent(BaseSwarmAgent):
    """BrowserExecutor: Browser automation and web interaction specialist."""
    
    AGENT_NAME = "BrowserExecutor"
    SIGNATURE_CLASS = BrowserExecutorSignature
    
    # Define capabilities explicitly
    CAPABILITIES = [
        "browser",
        "web",
        "navigation",
        "interaction",
        "clicking",
        "typing",
        "forms",
        "scraping",
        "automation",
        "testing",
        "screenshots",
        "javascript",
        "cookies",
        "authentication"
    ]
```

Then in wrapper:

```python
class BrowserExecutorAgent(dspy.Module):
    # Expose capabilities from base agent
    capabilities = BaseBrowserExecutorAgent.CAPABILITIES
```

### Option 3: Dynamic Discovery (Current - ToolShed)

Keep using ToolShed's capability discovery, but **pass discovered capabilities to AgentConfig**:

```python
# In create_surface_swarm after creating agents
for agent_name, agent_instance in agents.items():
    # Discover capabilities from ToolShed
    discovered_caps = tool_shed.capability_index.get_agent_capabilities(agent_name)
    
    # Create AgentConfig with capabilities
    actors.append(
        AgentConfig(
            name=agent_name,
            agent=agent_instance,
            capabilities=discovered_caps,  # ← From ToolShed!
            ...
        )
    )
```

---

## Recommendation

**Use Option 2 (Explicit Definition) + pass to AgentConfig**

Reasons:
1. ✅ Clear and explicit
2. ✅ No magic/inference needed
3. ✅ TodoCreatorAgent gets accurate capabilities
4. ✅ Works independently of ToolShed
5. ✅ Easy to maintain and update

---

## Summary

**Current:** Capabilities are **EMPTY** when passed to TodoCreatorAgent  
**Reason:** `AgentConfig` doesn't include capabilities parameter  
**Effect:** TodoCreatorAgent infers capabilities from names/descriptions  
**Solution:** Add explicit capabilities to agents and pass via AgentConfig  
