# ADR: Single Active Agent View with Auto-Switching

**Status:** Accepted  
**Date:** 2026-02-01  
**Deciders:** Architecture Team (A-Team Review)  
**Supersedes:** unified-agent-session-embedding.md  
**Context:** Show ONLY the active agent in center panel - auto-switch based on which agent is yielding logs  

---

## Context

**User Requirement:**
> "Center: AGENT VIEWS... this needs to be on need basis... the agent that is yielding logs should only be visible... so if browser then only browser and if terminal then only terminal... whichever is active agent it should show only that tool"

**Translation:**
- Show ONLY ONE agent at a time
- Automatically switch to whichever agent is currently active
- No manual switching - automatic based on agent activity

---

## Decision

**Implement single active agent view with automatic switching based on agent activity.**

When any agent sends an event, it automatically becomes the visible agent in the center panel.

---

## Architecture

### **Backend: Agent Activation System**

```python
class AgentSessionManager:
    def __init__(self, websocket_manager):
        self.active_agent = None  # Only ONE active agent
    
    async def activate_agent(self, agent_type: AgentType):
        """Activate agent - makes it visible."""
        if self.active_agent != agent_type:
            await self.deactivate_agent(self.active_agent)
        
        self.active_agent = agent_type
        await self.websocket_manager.broadcast({
            "type": "agent_activated",
            "agent": agent_type.value
        })
    
    async def broadcast_agent_event(self, agent_type, event_type, data):
        """Broadcast event and auto-activate agent."""
        # Auto-activate if not already active
        if self.active_agent != agent_type:
            await self.activate_agent(agent_type)
        
        await self.websocket_manager.broadcast({
            "type": "agent_event",
            "agent": agent_type.value,
            "event_type": event_type,
            "data": data
        })
```

### **Frontend: Single View Container**

```javascript
class AgentViewManager {
    constructor() {
        this.views = new Map();
        this.activeAgentName = null;
    }
    
    switchToAgent(agentName) {
        // Hide all views
        this.views.forEach(view => {
            view.element.style.display = 'none';
        });
        
        // Show active agent
        const agentView = this.views.get(agentName);
        if (agentView) {
            agentView.element.style.display = 'flex';
            this.activeAgentName = agentName;
            agentView.handler.initialize();
        }
    }
    
    handleAgentActivated(event) {
        this.switchToAgent(event.agent);
    }
}
```

---

## Key Feature: Auto-Activation

When any agent sends an event, it automatically becomes the active/visible agent:

```python
# BrowserExecutor navigates
await manager.broadcast_agent_event(
    AgentType.BROWSER,
    "navigate",
    {"url": "https://google.com"}
)
# → Browser view automatically appears in Electron!

# TerminalExecutor outputs
await manager.broadcast_agent_event(
    AgentType.TERMINAL,
    "output",
    {"output": "test passed\n"}
)
# → Terminal view automatically appears in Electron!
```

---

## Benefits

### **Simpler Architecture**
- ✅ Only ONE view active at a time
- ✅ No manual switching logic
- ✅ Lower resource usage
- ✅ Cleaner code

### **Better UX**
- ✅ Clear focus on active agent
- ✅ No clutter (only relevant view shown)
- ✅ Automatic switching (no user action needed)
- ✅ Smooth transitions

### **Easier Implementation**
- ✅ 3 hours faster than multi-view (9-12 hours vs 12-15 hours)
- ✅ Less state management
- ✅ Simpler debugging
- ✅ Fewer edge cases

---

## Implementation

### **Phase 1: Core Infrastructure** (3-4 hours)

**Backend:**
- Create `AgentSessionManager` with activation system
- Implement `activate_agent()` and `deactivate_agent()`
- Auto-activation in `broadcast_agent_event()`

**Frontend:**
- Create `AgentViewManager` with single view container
- Implement `switchToAgent()` for automatic switching
- Create all agent views (hidden by default)

### **Phase 2: Agent Integrations** (5-6 hours)

**BrowserExecutor:**
- Update `navigate_to_url()` to use manager
- Electron BrowserView integration
- Auto-activation on navigation

**TerminalExecutor:**
- Update `stream_terminal_output()` to use manager
- xterm.js integration
- Auto-activation on output

**WebSearchAgent:**
- Broadcast search results via manager
- Results panel rendering
- Auto-activation on search

**PlannerAgent:**
- Broadcast planning steps via manager
- Plan visualizer
- Auto-activation on planning

### **Phase 3: Polish** (1-2 hours)

- Smooth transitions
- Loading states
- Error handling
- Testing

---

## WebSocket Protocol

### **Agent Activation**
```json
{
  "type": "agent_activated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-01T10:30:00Z"
}
```

### **Agent Event (triggers auto-activation)**
```json
{
  "type": "agent_event",
  "agent": "TerminalExecutor",
  "event_type": "output",
  "data": { "output": "test passed\n" }
}
```

### **Agent Deactivation**
```json
{
  "type": "agent_deactivated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-01T10:35:00Z"
}
```

---

## User Experience Flow

### **Example: Multi-Agent Task**

**User:** "Search for Python tutorials and open the first result"

1. **WebSearchAgent activates:**
   - Sends search query event
   - Frontend automatically switches to search view
   - User sees: Search results panel

2. **BrowserExecutor activates:**
   - Sends navigate event
   - Frontend automatically switches to browser view
   - User sees: Chrome browser opening result

3. **TerminalExecutor activates:**
   - Sends command output
   - Frontend automatically switches to terminal view
   - User sees: Terminal running commands

**All automatic - no manual switching!**

---

## UI Layout

```html
<div class="center-workspace">
  <!-- Only ONE view visible at a time -->
  
  <!-- BrowserExecutor View (hidden by default) -->
  <div class="agent-view agent-view-browser" style="display: none;">
    <div class="agent-view-header">
      <span>🌐 BrowserExecutor</span>
    </div>
    <div class="agent-view-content">
      <!-- BrowserView attached here -->
    </div>
  </div>
  
  <!-- TerminalExecutor View (hidden by default) -->
  <div class="agent-view agent-view-terminal" style="display: none;">
    <div class="agent-view-header">
      <span>⚡ TerminalExecutor</span>
    </div>
    <div class="agent-view-content">
      <!-- xterm.js attached here -->
    </div>
  </div>
  
  <!-- Other agents... -->
</div>
```

---

## CSS for Smooth Transitions

```css
.agent-view {
    display: none;
    flex-direction: column;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
}

.agent-view[style*="display: flex"] {
    opacity: 1;
}
```

---

## Comparison with Multi-View Approach

| Aspect | Multi-View | Single View (This ADR) |
|--------|-----------|----------------------|
| **Views Visible** | All agents | Only active agent |
| **Switching** | Manual or complex | Automatic |
| **Resource Usage** | High (all views) | Low (one view) |
| **Complexity** | High | Low |
| **Implementation** | 12-15 hours | 9-12 hours |
| **User Experience** | Cluttered | Clean, focused |

---

## Security Considerations

### **Low Risk**
- ✅ All views are read-only
- ✅ No user input to agents
- ✅ WebSocket already secured
- ✅ Process isolation maintained
- ✅ Lower resource usage (one view active)

---

## Performance Impact

| Metric | Current | With Single View |
|--------|---------|-----------------|
| Agents Visible | 0 | 1 (only active) |
| Memory Usage | ~300MB | ~500MB |
| CPU Usage | ~5% | ~8% |
| Development Time | 0 | 9-12 hours |

---

## Success Criteria

- ✅ Only ONE agent visible at a time
- ✅ Automatic switching when agent becomes active
- ✅ Smooth transitions between agents
- ✅ Clear indicator of active agent (right sidebar)
- ✅ All agent types supported
- ✅ Implementation complete in < 12 hours

---

## Future Enhancements

- Picture-in-picture for background agents
- Agent history/replay
- Manual agent selection (override auto-switching)
- Split-screen for two agents

---

## Related Decisions

- [unified-agent-session-embedding.md](./unified-agent-session-embedding.md) - Original multi-view approach (superseded)
- [electron-browserview-true-embedding.md](./electron-browserview-true-embedding.md) - BrowserExecutor details
- [A-Team Review: Single Active Agent View](../review/A_TEAM_SINGLE_ACTIVE_AGENT_VIEW.md) - Complete technical discussion

---

## References

- Electron BrowserView: https://www.electronjs.org/docs/latest/api/browser-view
- xterm.js: https://xtermjs.org/
- WebSocket Protocol: https://developer.mozilla.org/en-US/docs/Web/API/WebSocket

---

## Notes

**Team Consensus:**
- Alex: "Single view with auto-switching is simpler and cleaner"
- Jordan: "Auto-activation on event broadcast eliminates manual switching"
- Casey: "Much easier frontend - just show/hide views"
- Morgan: "Lower resource usage, easier to monitor"

**Key Insight:** User wants to see what's happening NOW, not everything at once. Single active view with automatic switching based on agent activity is the perfect solution.

**Decision:** Implement single active agent view with auto-switching. Timeline: 9-12 hours.
