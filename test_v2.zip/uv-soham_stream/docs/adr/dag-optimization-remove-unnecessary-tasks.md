# ADR: DAG Optimization - Remove Unnecessary Tasks

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: TodoCreatorAgent processing TaskDAGs with 70+ unnecessary tasks

## Problem

Even after fixing the ResearchAgent and TaskBreakdownAgent to understand that capabilities are existing actors, the generated DAGs still contained **too many unnecessary tasks** (70+ tasks instead of 5-10).

**Example**: For "Summarize WhatsApp conversations" with `browser_interaction` and `summarization` capabilities:

```
❌ 70 tasks including:
- Install selenium, webdriver-manager, chromedriver
- Create browser_automation.py, selenium_helper.py, webdriver_utils.py
- Install transformers, torch, tensorflow, sentencepiece
- Create summarizer.py, model_loader.py, text_processor.py
- Write authentication handler, session manager, cookie manager
- Create logging utils, config parser, error handlers
- ...60+ more tasks building infrastructure
```

**Should be**:
```
✅ 5-6 tasks:
1. BrowserExecutor: Open web.whatsapp.com
2. Wait for user QR authentication
3. BrowserExecutor: Navigate to group
4. BrowserExecutor: Extract messages
5. Summarizer: Summarize conversations
6. Display summary to user
```

## Root Cause

The TaskBreakdownAgent, despite updated signatures, was still generating implementation tasks because:
1. LLMs are trained on "how to build things from scratch" patterns
2. The default behavior is to be thorough and include all steps
3. No **active pruning** was happening after task generation

Even with clear instructions, the LLM would generate the full list "just to be safe."

## Solution: Add DAG Optimization Step to TodoCreatorAgent

### New Step 0: Optimize DAG Before Actor Assignment

Added a new optimization phase **before** actor assignment that:
1. Analyzes all tasks in the DAG
2. Identifies tasks that build capabilities that already exist
3. Removes unnecessary tasks
4. Preserves only workflow tasks that USE existing capabilities

### Implementation

#### 1. New Signature: `OptimizeDAGSignature`

```python
class OptimizeDAGSignature(dspy.Signature):
    """Optimize DAG by removing unnecessary tasks and combining redundant ones.
    
    CONTEXT: Available capabilities are EXISTING actors (BrowserExecutor, Summarizer, etc.).
    Tasks that install libraries or write code to build these capabilities should be REMOVED.
    """
    
    tasks_summary = dspy.InputField(
        desc="Summary of all tasks in the DAG with their descriptions and types"
    )
    available_capabilities = dspy.InputField(
        desc="List of EXISTING capabilities/actors. These are ALREADY IMPLEMENTED - "
        "any tasks trying to build/install these should be removed."
    )
    
    optimization_plan = dspy.OutputField(
        desc="List of task IDs to REMOVE or COMBINE with reasoning. "
        "REMOVE tasks that:\n"
        "1. Install libraries/tools for capabilities that already exist\n"
        "2. Write code to implement capabilities that already exist\n"
        "3. Load ML models for capabilities that already exist\n"
        "4. Are redundant or duplicate work\n"
        "5. Setup development environment when not needed\n\n"
        "KEEP tasks that:\n"
        "1. Use existing actors/capabilities\n"
        "2. Are necessary workflow steps\n"
        "3. Validate or test the results"
    )
```

#### 2. New Method: `_optimize_dag()`

```python
def _optimize_dag(self, dag: TaskDAG, actors: List[Actor]) -> TaskDAG:
    """
    Optimize DAG by removing unnecessary tasks.
    
    1. Extract all capabilities from actors
    2. Generate summary of all tasks
    3. Call optimizer LLM to identify tasks to remove
    4. Parse optimization plan
    5. Remove identified tasks from DAG
    6. Return optimized DAG
    """
    # Extract capabilities
    all_capabilities = set()
    for actor in actors:
        all_capabilities.update(actor.capabilities)
    
    # Create tasks summary
    tasks_summary = [
        f"ID: {task.id} | NAME: {task.name} | TYPE: {task.type.value} | "
        f"DESC: {task.description[:100]}"
        for task in dag.tasks.values()
    ]
    
    # Call optimizer
    result = self.dag_optimizer(
        tasks_summary="\n".join(tasks_summary),
        available_capabilities=", ".join(sorted(all_capabilities))
    )
    
    # Parse and apply removals
    tasks_to_remove = set()
    for line in result.optimization_plan.split("\n"):
        if line.startswith("REMOVE:"):
            task_ids = [tid.strip() for tid in 
                       line.split("|")[0].replace("REMOVE:", "").strip().split(",")]
            tasks_to_remove.update(task_ids)
    
    # Remove tasks
    for task_id in tasks_to_remove:
        if task_id in dag.tasks:
            del dag.tasks[task_id]
            # Remove from dependencies
            for other_task in dag.tasks.values():
                if task_id in other_task.dependencies:
                    other_task.dependencies.remove(task_id)
    
    return dag
```

#### 3. Updated Workflow

```python
def create_executable_dag(self, dag, available_actors, ...):
    logger.info(f"Tasks: {dag.total_tasks}, Actors: {len(available_actors)}")
    
    # Convert actors
    actors = [Actor(...) for a in available_actors]
    
    # Step 0: Optimize DAG (NEW!)
    logger.info("Step 0: Optimizing DAG (removing unnecessary tasks)...")
    original_task_count = dag.total_tasks
    dag = self._optimize_dag(dag, actors)
    removed_count = original_task_count - dag.total_tasks
    logger.info(f"Optimization: {removed_count} tasks removed, {dag.total_tasks} remaining")
    
    # Step 1: Assign actors
    logger.info("Step 1: Assigning actors to tasks...")
    assignments = self._assign_actors_to_tasks(dag, actors)
    
    # Step 2: Validate DAG
    # Step 3: Fix issues
    ...
```

## Expected Behavior

### Before Optimization

```
Creating executable DAG for: Implementation Plan Execution
Tasks: 70, Actors: 4

Assigning actors to 70 tasks...
```

### After Optimization

```
Creating executable DAG for: Implementation Plan Execution
Tasks: 70, Actors: 4

Step 0: Optimizing DAG (removing unnecessary tasks)...
Optimization plan generated:
REMOVE: task_01, task_02, task_03, ... (install selenium tasks)
REMOVE: task_15, task_16, task_17, ... (create browser automation code)
REMOVE: task_30, task_31, task_32, ... (install transformers tasks)
REMOVE: task_45, task_46, task_47, ... (load ML models)
KEEP: task_60 (BrowserExecutor: Open WhatsApp Web)
KEEP: task_61 (Wait for user authentication)
KEEP: task_62 (BrowserExecutor: Extract messages)
KEEP: task_63 (Summarizer: Summarize text)

Optimization complete: 64 tasks removed, 6 tasks remaining

Step 1: Assigning actors to 6 tasks...
```

## What Gets Removed

### Installation Tasks
- `pip install selenium webdriver-manager chromedriver`
- `pip install transformers torch tensorflow sentencepiece`
- `pip install beautifulsoup4 requests lxml`
- Any package installation for capabilities that already exist

### Code Writing Tasks
- `Create browser_automation.py with Selenium WebDriver code`
- `Create summarizer.py loading BART model`
- `Write authentication handler`
- `Create config parser`, `error handlers`, `logging utils`
- Any task that creates code for existing capabilities

### Model/Asset Loading
- `Download BART model weights`
- `Load T5 tokenizer`
- `Initialize ChromeDriver binary`
- Any asset loading for existing capabilities

### Development Environment
- `Setup virtual environment`
- `Configure IDE settings`
- `Install linters and formatters`
- Any development setup tasks

## What Gets Kept

### Workflow Tasks Using Existing Actors
- `BrowserExecutor: Open web.whatsapp.com`
- `BrowserExecutor: Navigate to group`
- `BrowserExecutor: Extract message elements`
- `Summarizer: Summarize extracted text`

### User Interaction
- `Wait for user to scan QR code`
- `Prompt user for input`
- `Display results to user`

### Validation/Testing
- `Verify messages were extracted`
- `Validate summary quality`
- `Check for errors`

## Benefits

1. ✅ **Massive Task Reduction**: 70+ tasks → 5-10 tasks
2. ✅ **Correct Focus**: Only workflow tasks, not infrastructure building
3. ✅ **Faster Execution**: Fewer tasks = faster completion
4. ✅ **Clearer Intent**: DAG shows actual workflow, not implementation details
5. ✅ **Better Actor Assignment**: Actors assigned to meaningful tasks only
6. ✅ **Less Confusion**: User sees what's actually happening

## Edge Cases

### When Tasks Should NOT Be Removed

1. **New Code for Business Logic**: If task creates application-specific code (not general infrastructure), keep it
   ```
   KEEP: "Create WhatsApp message parser for specific group format"
   REMOVE: "Create general Selenium browser automation framework"
   ```

2. **Configuration Files**: Application-specific config should be kept
   ```
   KEEP: "Create config.yaml with WhatsApp group name and user list"
   REMOVE: "Create selenium_config.py with WebDriver settings"
   ```

3. **Data Processing**: Custom data transformations should be kept
   ```
   KEEP: "Parse WhatsApp messages into structured format"
   REMOVE: "Create generic text preprocessing pipeline"
   ```

## Alternatives Considered

1. **Fix TaskBreakdownAgent Better**: Already tried, LLMs still generate extra tasks
2. **Post-Process in Example Script**: Not reusable, should be in agent
3. **Manual Pruning**: Not scalable, needs automation
4. **Stricter Signatures**: Already very strict, LLMs still verbose

## Trade-offs

### Advantages
- Dramatically reduces unnecessary tasks
- Focuses on actual workflow
- Reusable optimization logic

### Disadvantages
- Adds one more LLM call (cost/latency)
- Requires parsing optimization plan text
- May occasionally remove a needed task (but can be fixed in validation)

## Related ADRs

- `capabilities-are-existing-actors-not-code-to-write.md`: Why capabilities shouldn't be built
- `todo-creator-agent-implementation.md`: TodoCreatorAgent's role
- `prevent-react-tool-bypass.md`: Ensuring proper agent behavior

## Conclusion

The TodoCreatorAgent now includes a **DAG optimization step** that removes unnecessary tasks before actor assignment. This ensures that only workflow tasks using existing capabilities remain, dramatically reducing DAG size from 70+ tasks to 5-10 meaningful tasks.

The optimization happens automatically and intelligently, understanding that capabilities like `browser_interaction` and `summarization` are **existing actors** that should be **used**, not **built**.
