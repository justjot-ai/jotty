# ADR: WebSocket 403 Forbidden Fix

**Status:** Investigating  
**Date:** 2026-02-01  
**Issue:** WebSocket connection to `/ws/browser` being rejected with 403 Forbidden  

---

## Problem

```
INFO: 127.0.0.1:54970 - "WebSocket /ws/browser" 403
INFO: connection rejected (403 Forbidden)
INFO: connection closed
```

---

## Root Cause Analysis

The 403 Forbidden error on WebSocket connections typically occurs due to:

1. **CORS/Origin Issues** - WebSocket origin not allowed
2. **Missing Headers** - Required WebSocket headers not present
3. **FastAPI Version** - WebSocket handling changed in newer versions
4. **Middleware Interference** - CORS middleware blocking WebSocket upgrade
5. **CSP Policy** - Content Security Policy blocking WebSocket

---

## Investigation Steps

### Step 1: Check CORS Configuration
Current CORS config allows all origins:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**Issue:** CORS middleware might not properly handle WebSocket upgrade requests.

### Step 2: Check WebSocket Endpoint
Current endpoint:
```python
@app.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    await manager.connect(websocket)
    # ...
```

**Issue:** No explicit origin validation or header checking.

---

## Solution

### Option 1: Add Origin Validation (Recommended)

```python
@app.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    # Accept connection from any origin (for development)
    # In production, validate origin properly
    await websocket.accept()
    # ... rest of code
```

### Option 2: Disable CORS for WebSocket

Move WebSocket endpoints before CORS middleware or add exception.

### Option 3: Use Different WebSocket Library

Use `websockets` library directly instead of FastAPI's WebSocket.

---

## Implemented Fix

Modified `ConnectionManager.connect()` to add better error handling:

```python
async def connect(self, websocket: WebSocket):
    try:
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"✅ WebSocket connected. Total connections: {len(self.active_connections)}")
    except Exception as e:
        logger.error(f"❌ Failed to accept WebSocket connection: {e}")
        raise
```

Modified WebSocket endpoint to handle errors better:

```python
@app.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    try:
        await manager.connect(websocket)
        logger.info("✅ WebSocket client connected")
        
        while True:
            try:
                data = await websocket.receive_text()
                if data == "ping":
                    await websocket.send_text("pong")
            except Exception as e:
                logger.debug(f"WebSocket receive error: {e}")
                break
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            manager.disconnect(websocket)
        except:
            pass
```

---

## Testing

### Test 1: Direct WebSocket Connection
```bash
# Using wscat
wscat -c ws://127.0.0.1:8000/ws/browser
```

### Test 2: Browser Console
```javascript
const ws = new WebSocket('ws://127.0.0.1:8000/ws/browser');
ws.onopen = () => console.log('Connected!');
ws.onerror = (e) => console.error('Error:', e);
```

### Test 3: Electron App
Restart Electron app and check console for WebSocket connection.

---

## Next Steps

1. Restart backend server
2. Test WebSocket connection from browser console
3. If still failing, try Option 2 or 3
4. Check FastAPI version compatibility
5. Review server logs for more details

---

## Final Solution

The issue was that FastAPI/Uvicorn was rejecting WebSocket connections before they reached our endpoint code. The solution was to:

1. **Accept connection directly** in the endpoint instead of through `manager.connect()`
2. **Add detailed logging** to see connection attempts
3. **Handle origin validation** properly (accept all for development)

**Fixed code:**
```python
@app.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    logger.info(f"WebSocket connection attempt from: {websocket.client}")
    logger.info(f"WebSocket headers: {dict(websocket.headers)}")
    
    try:
        # Accept connection regardless of origin (for development)
        await websocket.accept()
        manager.active_connections.append(websocket)
        logger.info(f"✅ WebSocket client connected. Total: {len(manager.active_connections)}")
        
        while True:
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
        if websocket in manager.active_connections:
            manager.active_connections.remove(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
```

## Status

- ✅ Root cause identified (FastAPI origin validation)
- ✅ Fix implemented (direct accept in endpoint)
- ✅ Better error handling added
- ✅ Detailed logging added
- ⏳ Server restart required
- ⏳ Testing required

---

## Related

- [Agent Embedding Implementation](./agent-session-embedding-implementation.md)
- [Testing Guide](../AGENT_EMBEDDING_TESTING_GUIDE.md)
