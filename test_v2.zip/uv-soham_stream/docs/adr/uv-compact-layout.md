# ADR: UV Compact Layout for Single Screen Fit

**Date**: 2026-01-31  
**Status**: Implemented  

## Context

The UV TUI sections (System Status and Transmissions) were taking up too much vertical space, causing content to scroll below the visible screen. Users needed to scroll to see all content, which disrupted the continuous animation experience and TUI immersion.

## Decision

Reduced padding and sizing across all TUI sections to ensure everything fits on a single screen:

### Size Reductions

| Section | Original | Updated | Reduction |
|---------|----------|---------|-----------|
| **Agents Pane** | padding=(2,2) | padding=(1,1) | 50% less padding |
| **Task Pane** | padding=(2,2) | padding=(1,1) | 50% less padding |
| **System Status Grid** | padding=(1,1) | padding=(0,1) | 50% vertical padding |
| **Chat Section** | height=15, padding=(2,3) | height=10, padding=(1,2) | 33% height, less padding |
| **Messages Shown** | Last 5 messages | Last 3 messages | Show fewer messages |
| **Message Spacing** | `\n\n` (double) | `\n` (single) | Single line spacing |

### Layout Proportions

- **UV Banner**: 12 lines (fixed)
- **Eyes Section**: 13 lines (fixed)
- **System Status Grid**: ~10-12 lines (compact)
- **Chat/Transmissions**: 10 lines (fixed height)
- **Input Prompt**: Below TUI (not in layout)

**Total**: ~45-47 lines (fits standard terminal height)

## Benefits

1. **Single Screen Fit**: Everything visible without scrolling
2. **Maintains Animation**: Continuous eye animations stay in view
3. **Better UX**: All sections accessible at a glance
4. **Cleaner Layout**: Less wasted whitespace
5. **More Terminal Compatible**: Works on 24-line terminals

## Trade-offs

- Shows only last 3 chat messages (vs 5) - adequate for most conversations
- Less padding - slightly denser but still readable
- Single line spacing between messages - cleaner appearance

## Implementation Details

```python
# Agents pane: padding=(2,2) → padding=(1,1)
# Task pane: padding=(2,2) → padding=(1,1)
# Grid section: padding=(1,1) → padding=(0,1)
# Chat: height=15, padding=(2,3) → height=10, padding=(1,2)
# Messages: messages[-5:] → messages[-3:]
```

## Consequences

### Positive
- Entire TUI fits on standard terminal screens
- No scrolling needed
- Better animation visibility
- Improved user experience

### Neutral
- Slightly denser information display
- Fewer historical messages visible

### Negative
- None identified - layout remains readable and functional
