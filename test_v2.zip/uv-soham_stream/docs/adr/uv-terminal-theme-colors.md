# ADR: UV Terminal Theme-Aware Colors

**Date**: 2026-01-31  
**Status**: Implemented  

## Context

The UV TUI was using custom hex color codes (#8be9fd, #f1fa8c, #a3b8ef, etc.) that were optimized for dark terminal backgrounds. Users with light/white terminal backgrounds experienced poor contrast and readability issues.

## Decision

Replaced all custom hex color codes with Rich's semantic color names that automatically adapt to the terminal's theme:

### Color Mapping

| Original Hex | Semantic Color | Usage |
|-------------|----------------|-------|
| `#50fa7b` | `green` | Success messages, "done" status |
| `#ff6e6e` | `red` | Errors, anomalies |
| `#8be9fd` | `cyan` | Commands, prompts, "active" status |
| `#a3b8ef` | `blue` | Agent name, titles, sections |
| `#ffb86c` | `yellow` | Warnings, "waiting" status |
| `#f1fa8c` | `yellow` | User input prompts |
| `#6272a4` | `dim` | Borders, "idle" status |
| `#f8f8f2` | `white` | Table values |

### Benefits

1. **Automatic Adaptation**: Colors automatically adjust based on terminal's light/dark theme
2. **High Contrast**: Terminal-native colors ensure proper contrast on any background
3. **Consistency**: Uses standard terminal palette that users are familiar with
4. **Accessibility**: Better readability for users with various terminal color schemes

## Implementation

- Updated all `[#xxxxxx]` color codes to `[color_name]` format
- Updated all `bold #xxxxxx` to `bold color_name`
- Updated all `border_style="#xxxxxx"` to `border_style="color_name"`
- Updated all `style="#xxxxxx"` to `style="color_name"`

## Consequences

### Positive
- Works on both light and dark terminal backgrounds
- Better accessibility and readability
- Follows terminal UI best practices
- No custom theme configuration needed

### Neutral
- Colors may appear slightly different across terminal emulators
- Less control over exact color shades

### Negative
- None identified
