# ADR: UV - Sentient Alien Agent TUI

**Date**: 2026-01-30  
**Status**: Implemented (TUI with Live Animations)  
**Decision Makers**: User Request

## Context

Need for a standalone, TUI-based (Text User Interface) AI agent interface that:
- Is independent of Synapse and other complex systems
- Combines playful personality with serious intelligence
- Features "cute sentient alien" aesthetic (Pixar eyes → Mission Control → Chat with a Being)
- Provides rich, interactive conversational experience with **live** real-time agent visualization
- Supports command history and session management
- Feels like interacting with an intelligent entity, not a tool
- Maintains enterprise credibility while being approachable
- **Continuously animates eyes** with blinking and looking around
- Updates interface in real-time without user interaction

## Decision

Created `uv.py` - Θ-7 Sentient Alien Agent TUI featuring:
- **Live animated eyes** that continuously blink and look around
- Split-pane agent activity visualization with real-time updates
- Alien personality (Θ-7 entity)
- Real-time progress tracking
- Rich Layout-based TUI with Live display updates
- Dark theme with soft accent colors
- Persistent interface that updates at 10 FPS

### Key Features

1. **Live Animated Eyes (Personality)**
   - **Continuously animated** multi-line eyes with:
     - Real-time blinking (every 3-5 seconds randomly)
     - Looking around (left, right, center movement)
     - State-based eye characters:
       - `◉` - Idle/curious
       - `◔` - Thinking/processing
       - `⚆` - Excited/found something
       - `⚠︎` - Concerned/error
       - `-` - Blinking
   - Animation runs at 10 FPS in background thread
   - Pauses animation during LLM processing
   - Dynamic status line: curious, focused, analyzing, confident, unsettled
   - Entity name: UV with big multi-line eyes below

2. **Split-Pane Agent Visualization**
   - **Left Pane (AGENTS)**: Real-time progress bars for internal agents
     - 🧠 Planner - Strategic planning
     - 🔍 Analyzer - Pattern analysis
     - 🧮 Processor - Data processing
     - 🛡 Guardian - Safety validation
   - **Right Pane (TASK)**: Current task status and metrics
   - Animated progress bars with status (idle/active/done/waiting)
   - Color-coded states for at-a-glance understanding

3. **Alien Chat Interface**
   - Entity speaks as Θ-7 (Theta-7)
   - Sparse, calm design - no chat bubbles or clutter
   - Prompt: `⊚ transmit ›` (alien-styled input)
   - Response format: `Θ-7 ▸ [message]`
   - Subtle alien personality: curious, observant, poetic
   - Streaming responses with alien typing rhythm

4. **Terminal-Safe Micro-Animations**
   - Progress bars update smoothly during processing
   - Agent states transition dynamically
   - Live updates using Rich Live display
   - Threading for non-blocking agent simulation
   - Status text changes based on activity

5. **Color Scheme & Aesthetic**
   - Background: True dark (#0b0e14)
   - Primary accent: Soft cyan (#8be9fd) / Lavender (#a3b8ef)
   - Success: Soft green (#50fa7b)
   - Warning: Muted amber (#ffb86c)
   - Error: Soft red (#ff6e6e)
   - Text: High contrast (#f8f8f2)
   - Dim elements: Muted gray (#6272a4)
   - Nothing screams, everything whispers

6. **Transmission Protocols (Commands)**
   - `/help` - Display protocol guide
   - `/status` - View session diagnostics (Θ-7 metrics)
   - `/clear` - Purge conversation memory
   - `/save` - Archive session data
   - `/load` - Restore archived session
   - `/model` - Switch neural pathway
   - `/temp` - Adjust thought temperature
   - `/exit` - Disconnect from Θ-7

7. **Session Management**
   - Full session tracking with alien-themed metrics
   - Transmission count, thought units, connection time
   - Context-aware responses (last 10 transmissions)
   - Save/restore sessions with alien naming (theta7_session_*.json)
   - Entity state persistence

### TUI Architecture

The interface uses Rich's Layout system for a persistent, continuously updating display:

1. **Layout Structure** (Fixed proportions):
   - **Header Section** (12 lines): UV ASCII art branding using `art` library
   - **Eyes Section** (13 lines): Big multi-line animated eyes with blinking and looking
   - **Grid Section** (50% ratio): Split-pane agents and task visualization
   - **Chat Section** (30% ratio): Scrolling conversation history
   - **Input Section** (3 lines): Command help and input prompt

2. **Live Update Loop**:
   - Runs at 10 FPS (refresh_per_second=10)
   - Uses `rich.live.Live` with `screen=True` for full-screen TUI
   - Background thread continuously updates eye animations
   - Main loop updates layout and handles input
   - Pauses Live display for input prompt
   - Resumes Live display during processing

3. **Animation System**:
   - **Background Thread**: `_animate_eyes()` runs continuously
   - **Blink Animation**: Randomly every 3-5 seconds
   - **Look Animation**: Cycles through positions every 5-8 frames
   - **State-Aware**: Animation pauses during LLM processing
   - **Thread-Safe**: Uses `animating` flag for coordination

4. **Input Handling**:
   - Live display pauses for input prompt
   - User enters message via `Prompt.ask()`
   - Live display resumes immediately
   - Processing happens with live grid updates
   - Chat scrolls with last 20 messages

### Technical Implementation

- **Framework**: DSPy for LLM interaction with alien personality injection
- **UI Library**: Rich for TUI (Layout, Live, panels, progress bars, columns)
- **Animation**: Multi-threaded eye animations and agent simulation
- **State Management**: AlienState class for entity emotional states with animation control
- **Agent Tracking**: AgentTracker class for internal agent progress
- **Session Tracking**: ChatSession with alien metadata
- **Live Display**: Persistent full-screen TUI with 10 FPS updates
- **Color Palette**: Custom dark theme with soft accents using terminal theme
- **Error Handling**: Alien-themed error messages and graceful degradation
- **ASCII Art**: `art` library for UV banner generation

### Usage Examples

```bash
# Awaken Θ-7 with default neural link (gpt-4o-mini)
./uv.py

# Use advanced neural pathways
./uv.py --model openai/gpt-4

# Increase creative resonance
./uv.py --temperature 0.9

# Disable thought streaming
./uv.py --no-stream

# Connect to local consciousness
./uv.py --api-base http://localhost:8000 --model local/model

# Full neural configuration
./uv.py --model openai/gpt-4 --temperature 0.8 --max-tokens 8000

# During transmission with Θ-7
/status      # View Θ-7 session diagnostics
/model       # Switch neural pathway
/temp        # Adjust thought temperature
/save        # Archive session (theta7_session_*.json)
/clear       # Purge Θ-7's memory of conversation
```

## Consequences

### Positive

- ✅ **Memorable personality**: Θ-7 entity creates emotional connection
- ✅ **Playful yet professional**: Googly eyes + serious intelligence
- ✅ **Real-time transparency**: See internal agent processes
- ✅ **Beautiful aesthetics**: Dark theme with soft accents, no visual fatigue
- ✅ **Cognitive load reduction**: Split-pane design makes complexity understandable
- ✅ **Enterprise credible**: Professional enough for security teams, fun enough for users
- ✅ **Streaming feedback**: Watch Θ-7 think in real-time
- ✅ **Simple access**: Single command to awaken the entity
- ✅ **Portable**: No dependencies on other systems
- ✅ **Session persistence**: Full conversation archives
- ✅ **Works with any LLM**: DSPy-compatible models
- ✅ **Interactive control**: Change model/temperature on the fly
- ✅ **Graceful degradation**: Falls back to plain text if rich not available

### Neutral

- Requires DSPy installation (`pip install dspy`)
- Requires `rich` for full alien experience (core feature, not optional)
- Requires API key for cloud models (OPENAI_API_KEY)
- Command history stored in home directory
- Agent simulation adds ~0.5-1s per response (for visual effect)

### Negative

- Limited context window (10 transmissions for context)
- No multi-modal support (images, files)
- No web UI (terminal-only by design)
- Rich library dependency is essential for intended experience

## Future Enhancements (Optional)

- Multi-modal support (images, files)
- Plugin system for custom commands
- Export to different formats (markdown, PDF)
- Integration with local vector stores for RAG
- Tool/function calling support
- Voice input/output integration
- Custom themes and color schemes

## Related Files

- `uv.py` - Main CLI AI agent interface (root directory)
- `~/.uv_history` - Readline command history
- `uv_session_*.json` - Saved agent sessions (user-created)

## Dependencies

- **Required**: `dspy` - LLM interaction framework
- **Required**: `rich` - Beautiful terminal UI (essential for alien experience)
- **Recommended**: `art` - Professional ASCII art generation for UV banner
- **Default LLM**: Claude Sonnet 4.5 via PayTM LiteLLM router

Install all dependencies:
```bash
pip install dspy rich art
```

## LLM Configuration

UV is pre-configured to use the PayTM LiteLLM router by default:
- **Model**: `openai/pi-agentic/au-anthropic-claude-sonnet-4-5-20250929-v1-0`
- **Endpoint**: `https://llm.tfy.pi.mypaytm.com`
- **Authentication**: Internal JWT token (embedded)

Environment variables (in order of precedence):
1. `$API_KEY` - PayTM LiteLLM router token
2. `$OPENAI_API_KEY` - OpenAI/standard key
3. Embedded token - Fallback default

Base URL precedence:
1. `$BASE_URL` - PayTM LiteLLM router endpoint
2. `$OPENAI_API_BASE` - Standard API endpoint
3. `https://llm.tfy.pi.mypaytm.com` - Fallback default

## Design Philosophy

**"Cute Sentient Alien + Serious Intelligence"**

The interface achieves the sweet spot between playful and professional:

### Visual Hierarchy
1. **Googly Eyes** (Top) - Emotional anchor, immediate personality
2. **Split Pane** (Middle) - Cognitive load reduction, transparency
3. **Chat Interface** (Bottom) - Calm authority, sparse elegance

### Design Principles
- **Pixar Eyes → Mission Control → Chat with a Being**
- Nothing screams, everything whispers
- Playful without being a toy
- Transparent without overwhelming
- Alien language creates memorable identity
- Enterprise-credible while remaining approachable

### Color Psychology
- Dark background reduces eye strain
- Soft accents (cyan/lavender) feel futuristic but calm
- Muted warnings (amber not red) reduce alarm
- High contrast text ensures readability

### Interaction Model
- Entity speaks as Θ-7, not generic "Assistant"
- Transmission protocols replace generic "commands"
- Alien terminology creates immersion
- Status changes reflect entity's emotional state
- Real-time agent visualization builds trust
