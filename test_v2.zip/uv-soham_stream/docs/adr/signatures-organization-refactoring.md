# ADR: Signatures Organization Refactoring

**Status:** Implemented  
**Date:** 2026-01-29  
**Decision Makers:** Development Team

## Context

DSPy signatures were originally defined inline within agent files:
- `research_agent.py` had `ResearchAgentSignature`
- `task_breakdown_agent.py` had 3 signatures (`ExtractTasksSignature`, `IdentifyDependenciesSignature`, `OptimizeWorkflowSignature`)
- `todo_creator_agent.py` had 3 signatures (`ActorAssignmentSignature`, `DAGValidationSignature`, `DAGFixSignature`)

This created several issues:
1. **Poor Separation of Concerns**: Agent logic mixed with signature definitions
2. **Hard to Reuse**: Signatures couldn't be easily imported by other modules
3. **Discoverability**: Hard to find all available signatures
4. **Maintainability**: Changes required navigating large agent files

The existing `signatures/` directory only had research signatures, indicating an incomplete migration.

## Decision

**Moved all DSPy signatures to dedicated files in `Synapse_new/signatures/` directory.**

### Organization Structure

```
signatures/
├── __init__.py                          # Central exports
├── research_signatures.py               # 7 signatures for research
├── task_breakdown_signatures.py         # 3 signatures for task breakdown
└── todo_creator_signatures.py           # 3 signatures for TodoCreator
```

### Signature Distribution

**Research Signatures (7):**
- `ResearchAgentSignature` - Main orchestration
- `GenerateResearchPlan` - Plan generation
- `AnalyzeSearchResults` - Search analysis
- `SynthesizeFindings` - Findings synthesis
- `DecideNextAction` - Action decision
- `DeepDiveLibrary` - Library deep-dive
- `OrchestrateResearch` - Flow orchestration

**Task Breakdown Signatures (3):**
- `ExtractTasksSignature` - Task extraction
- `IdentifyDependenciesSignature` - Dependency identification
- `OptimizeWorkflowSignature` - Workflow optimization

**TodoCreator Signatures (3):**
- `ActorAssignmentSignature` - Actor assignment
- `DAGValidationSignature` - DAG validation
- `DAGFixSignature` - DAG fixing

### Import Pattern

Agents import signatures they need:

```python
from ..signatures.todo_creator_signatures import (
    ActorAssignmentSignature,
    DAGValidationSignature,
    DAGFixSignature
)
```

Central export for external use:

```python
from Synapse_new.signatures import ActorAssignmentSignature
```

## Implementation

### Steps Taken

1. **Created new signature files:**
   - `task_breakdown_signatures.py` - Moved 3 signatures from `task_breakdown_agent.py`
   - `todo_creator_signatures.py` - Moved 3 signatures from `todo_creator_agent.py`

2. **Updated existing files:**
   - `research_signatures.py` - Added `ResearchAgentSignature` from `research_agent.py`
   - `signatures/__init__.py` - Added all new signature exports

3. **Updated agent files:**
   - `research_agent.py` - Added import, removed signature
   - `task_breakdown_agent.py` - Added imports, removed signatures
   - `todo_creator_agent.py` - Added imports, removed signatures

4. **Verified:**
   - All imports work correctly
   - No linter errors
   - Agents still function properly

### Changes Summary

**Files Created:**
- `signatures/task_breakdown_signatures.py` (112 lines)
- `signatures/todo_creator_signatures.py` (71 lines)

**Files Modified:**
- `signatures/__init__.py` (+12 exports)
- `signatures/research_signatures.py` (+13 lines)
- `agents/research_agent.py` (-13 lines, +2 imports)
- `agents/task_breakdown_agent.py` (-105 lines, +5 imports)
- `agents/todo_creator_agent.py` (-68 lines, +5 imports)

**Net Effect:**
- **Removed ~186 lines** from agent files (cleaner agents)
- **Added ~196 lines** to signature files (organized signatures)
- **+1 export file** (SIGNATURES_ORGANIZATION.md)

## Consequences

### Positive

1. **Clean Separation**: Agents focus on logic, signatures are in dedicated files
2. **Better Organization**: All signatures in one place, easy to discover
3. **Improved Reusability**: Signatures can be imported independently
4. **Easier Maintenance**: Update signatures without touching agent code
5. **Better Documentation**: Centralized signature catalog
6. **Testing**: Can test signatures independently

### Negative

1. **More Files**: 3 signature files vs 0 (but better organization)
2. **Import Overhead**: Need to import signatures explicitly (but clearer dependencies)
3. **Initial Learning Curve**: Developers need to know where signatures live

### Mitigation

1. **Documentation**: Created `SIGNATURES_ORGANIZATION.md` as reference
2. **Central Import**: `signatures/__init__.py` provides single import point
3. **Consistent Pattern**: All agents follow same import pattern

## Verification

All tests passed:

```bash
✓ All signature imports successful
✓ All agent imports successful
✅ All refactoring completed successfully!

Signatures organized:
  • research_signatures.py (7 signatures)
  • task_breakdown_signatures.py (3 signatures)
  • todo_creator_signatures.py (3 signatures)
```

No linter errors in any modified files.

## Alternatives Considered

### 1. Keep Signatures in Agent Files
**Pros:** No extra files, everything in one place  
**Cons:** Poor separation, hard to reuse, large files  
**Verdict:** ❌ Original problem

### 2. Single signatures.py File
**Pros:** One file to import from  
**Cons:** Would grow very large (300+ lines), hard to navigate  
**Verdict:** ❌ Doesn't scale

### 3. Signatures in __init__.py
**Pros:** Simple, one place  
**Cons:** Pollutes namespace, hard to maintain  
**Verdict:** ❌ Anti-pattern

### 4. Separate Package (synapse_signatures)
**Pros:** Complete isolation  
**Cons:** Over-engineering, unnecessary complexity  
**Verdict:** ❌ Too complex for current needs

## Future Enhancements

1. **Signature Versioning**: Track signature changes for compatibility
2. **Signature Testing**: Unit tests for signature validation
3. **Signature Optimization**: DSPy optimization for each signature
4. **Signature Registry**: Dynamic signature discovery and registration
5. **Signature Metrics**: Track usage and performance of each signature

## Integration Impact

**No breaking changes**:
- Agents import signatures internally
- External API unchanged
- All existing code continues to work

**Migration path for custom agents**:
```python
# Before
from agents.todo_creator_agent import ActorAssignmentSignature

# After
from Synapse_new.signatures import ActorAssignmentSignature
```

## Documentation

Created comprehensive documentation:
- `signatures/SIGNATURES_ORGANIZATION.md` - Full catalog and usage guide
- This ADR - Design decisions and rationale

Updated:
- `signatures/__init__.py` - Comprehensive exports

## Testing

Verified all imports work:
```python
# All signatures importable
from Synapse_new.signatures import (
    ResearchAgentSignature,
    ExtractTasksSignature,
    ActorAssignmentSignature,
    # ... all 13 signatures
)

# All agents work
from Synapse_new import (
    ResearchAgent,
    TaskBreakdownAgent,
    TodoCreatorAgent
)
```

## Acceptance Criteria

- [x] All signatures moved to `signatures/` directory
- [x] Organized by agent/purpose
- [x] Central export from `__init__.py`
- [x] Agents updated with correct imports
- [x] No linter errors
- [x] All imports verified working
- [x] Documentation created
- [x] ADR written

## References

- Related: Clean architecture principles
- Related: Separation of concerns
- Pattern: Module organization
- Tool: DSPy signatures
