# ADR: Browser Command Response Payload (Full Data)

## Status
Accepted

## Context
Browser commands (get_text, click, etc.) are executed in Electron and the response is sent to Python via WebSocket. The backend and agent need more than `success: true/false` to act correctly:
- **get_text**: The agent needs the actual `text` content (and `text_length`) so it can reason about the page. When a selector is used and the element is not found, we should return `success: false`, `found: false`, and `error`.
- **click**: When the element is not found, we must return `success: false` and `found: false` (not `success: true`). Selectors like `[title='Soham Paytm']` must be passed safely so quote escaping does not break the injected script.

## Decision
- **get_text**: Response always includes `success`. On success: include `text`, `text_length`; when a selector is used also include `found: true` and `selector`. When selector is used and element is not found: return `success: false`, `found: false`, `selector`, `error: "Element not found: ..."`. The full result (including `text`) is sent to Python; the renderer does not strip any keys.
- **click**: Use `JSON.stringify(selector)` in the main process when injecting the selector into `executeJavaScript`, so selectors containing quotes (e.g. `[title='Soham Paytm']`) work. Return `success`, `found`, `selector` so the backend can tell whether the element was found. When element is not found, return `success: false`, `found: false`, `selector`, `error`.
- **Renderer**: Send the full `result` object from the main process to Python (no stripping). Log get_text with `text_length` and click with `found`/`selector` so we can confirm the payload.

## All browser tools – result fields

| Command | Success response fields | Failure response fields |
|--------|--------------------------|--------------------------|
| navigate | success, url | success, error |
| get_url | success, url, title | success, error |
| click | success, found, selector | success, found, selector, error |
| type | success, found?, selector? | success, found, selector, error |
| press_key | success, found?, selector? | success, found, selector, error |
| scroll | success, found?, selector? | success, found, selector, error |
| execute_js | success, result | success, error |
| get_content | success, content, content_length, found?, selector? | success, found, selector, error |
| get_text | success, text, text_length, found?, selector? | success, found, selector, error |
| wait_for_selector | success, found, selector | success, found, selector, error |
| screenshot | success, screenshot | success, error |
| verify_text_contains | success, selector, actualText, verified | success, error |
| search_and_select | success, selected, searchText, method | success, error, selector? |
| get_element_bounds | success, found, selector, bounds | success, found, selector, error |
| fill | success, found, selector | success, found, selector, error |
| select | success, found, selector | success, found, selector, error |
| check | success, found, selector | success, found, selector, error |
| hover | success, found?, selector? | success, found, selector, error |

When a selector is used and the element is not found, all selector-based commands return success: false, found: false, selector, and error. get_content and get_element_bounds treat null content/bounds as not found.

## Consequences
- Backend and agent receive full data (text for get_text, result for execute_js, content for get_content, found/selector for click, etc.). Click and all selector commands correctly return success: false when the element is not found. Selectors with quotes work reliably via JSON.stringify.
