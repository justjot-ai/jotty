# Dynamic Agent Detection in Electron UI

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: Electron app dynamic UI based on actual Synapse agents

## Problem

The Electron UI had **static, pre-defined agent terminals** (Browser, Terminal, WebSearch, Planner) regardless of which agents Synapse actually used for a task. This created several issues:

1. **Cluttered UI**: Showing 4 terminals when only 1-2 agents were active
2. **Misleading UX**: Empty terminals implied agents were doing nothing
3. **Not Scalable**: Adding new agents required HTML changes
4. **Disconnected**: UI didn't reflect actual Synapse execution

## Solution

Implement **dynamic agent detection** that:
1. Parses log files to discover which agents Synapse created
2. Dynamically creates terminal UI elements only for active agents
3. Routes log lines to the appropriate agent terminal
4. Shows real-time agent activity accurately

## Implementation

### Backend: Agent Detection API

**New Endpoint**: `GET /api/agents/{session_id}`

```python
@app.get("/api/agents/{session_id}")
async def get_active_agents(session_id: str):
    """Extract list of active agents from log file"""
    # Parse log file for: "Created X executor agents: ['Agent1', 'Agent2', ...]"
    # Return agent info with icons, types, and tasks
```

**Response Format**:
```json
{
  "session_id": "20260131_161220",
  "agents": [
    {
      "name": "BrowserExecutor",
      "icon": "🌐",
      "type": "browser",
      "task": "Web automation"
    },
    {
      "name": "TerminalExecutor",
      "icon": "⌘",
      "type": "terminal",
      "task": "Command execution"
    },
    {
      "name": "WebSearchAgent",
      "icon": "🔍",
      "type": "search",
      "task": "Research & information"
    },
    {
      "name": "Orchestrator",
      "icon": "🧠",
      "type": "planner",
      "task": "Task orchestration"
    }
  ]
}
```

### Frontend: Dynamic Terminal Creation

**Flow**:
```javascript
1. User sends task
2. Wait 500ms for log file creation
3. Fetch agents: GET /api/agents/{session_id}
4. Clear agent grid
5. Create terminal for each agent dynamically
6. Stream logs to appropriate terminals
```

**Key Functions**:

```javascript
// Fetch agents and create terminals
async fetchAndCreateAgentTerminals() {
  const response = await fetch(`/api/agents/${this.sessionId}`);
  const data = await response.json();
  
  data.agents.forEach((agent, index) => {
    const terminal = this.createAgentTerminal(agent, index);
    agentsGrid.appendChild(terminal);
  });
}

// Create terminal element
createAgentTerminal(agent, index) {
  // Returns DOM element with:
  // - Agent icon, name, task
  // - Empty content area
  // - Status indicator
}

// Route log lines to correct terminal
appendLogLine(line) {
  // Detect agent name from log line
  // Find matching terminal
  // Append log to that terminal
  // Auto-scroll
}
```

### Log Line Routing

Logs are routed to terminals based on agent name detection:

```javascript
if (line.includes('BrowserExecutor')) {
  targetTerminal = 'terminal-browserexecutor';
} else if (line.includes('TerminalExecutor')) {
  targetTerminal = 'terminal-terminalexecutor';
} else if (line.includes('WebSearchAgent')) {
  targetTerminal = 'terminal-websearchagent';
} else {
  targetTerminal = 'terminal-orchestrator'; // default
}
```

## Example Execution

### Task: "Search for Python testing frameworks"

**1. Synapse creates agents** (from log):
```
Created 3 executor agents: ['BrowserExecutor', 'TerminalExecutor', 'WebSearchAgent']
```

**2. Frontend fetches agents**:
```
GET /api/agents/20260131_161220
→ Returns 4 agents (3 executors + Orchestrator)
```

**3. UI dynamically creates terminals**:
```
┌─────────────┬─────────────┬─────────────┬─────────────┐
│ 🌐 Browser  │ ⌘ Terminal  │ 🔍 Search   │ 🧠 Planner  │
│             │             │             │             │
│ (inactive)  │ (inactive)  │ (inactive)  │ (inactive)  │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

**4. Logs stream to appropriate terminals**:
```
Log: "WebSearchAgent executing..."
→ Routes to Search terminal

Log: "Synapse coordination..."
→ Routes to Planner terminal
```

**5. Only active terminals show content**:
```
┌─────────────┬─────────────┬─────────────┬─────────────┐
│ 🌐 Browser  │ ⌘ Terminal  │ 🔍 Search   │ 🧠 Planner  │
│             │             │ ✓ ACTIVE    │ ✓ ACTIVE    │
│ (inactive)  │ (inactive)  │ Searching...│ Planning... │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

## Benefits

### 1. Clean UI
- Only shows terminals for agents actually being used
- No clutter from unused agents

### 2. Accurate Representation
- UI matches actual Synapse execution
- Users see exactly what's happening

### 3. Scalable
- New agents automatically appear when added to Synapse
- No HTML changes needed

### 4. Better UX
- Clear visual feedback on agent activity
- Focused attention on active agents

## Agent Detection Logic

### Parsing Strategy

The system looks for this specific log pattern:
```
Created X executor agents: ['Agent1', 'Agent2', 'Agent3']
```

Example from actual log:
```
2026-01-31 16:12:19,999 - surface_synapse.integration - INFO - 
   Created 3 executor agents: ['BrowserExecutor', 'TerminalExecutor', 'WebSearchAgent']
```

### Agent Mapping

```python
agent_info_map = {
    'BrowserExecutor': {
        'icon': '🌐',
        'type': 'browser',
        'task': 'Web automation'
    },
    'TerminalExecutor': {
        'icon': '⌘',
        'type': 'terminal',
        'task': 'Command execution'
    },
    'WebSearchAgent': {
        'icon': '🔍',
        'type': 'search',
        'task': 'Research & information'
    }
}
```

### Fallback Handling

If agent not in map:
```python
{
    'icon': '🤖',
    'type': 'agent',
    'task': 'Task execution'
}
```

## Log Routing Logic

### Detection Keywords

- **BrowserExecutor**: `line.includes('BrowserExecutor')` or `'browserexecutor'`
- **TerminalExecutor**: `line.includes('TerminalExecutor')` or `'terminalexecutor'`
- **WebSearchAgent**: `line.includes('WebSearchAgent')` or `'websearchagent'`
- **Default**: Routes to Orchestrator terminal

### Example Routing

```
Log: "2026-01-31 16:12:43 - BrowserExecutor - INFO - Navigating to..."
→ Routed to BrowserExecutor terminal

Log: "2026-01-31 16:12:44 - Synapse.core.conductor - INFO - Task planning..."
→ Routed to Orchestrator terminal (default)
```

## UI States

### 1. Loading State (Initial)
```html
<div class="agents-loading">
  <div class="loading-icon">⏳</div>
  <div class="loading-text">Starting task execution...</div>
</div>
```

### 2. Terminals Created (After agent fetch)
```html
<div class="agent-terminal-ws" data-agent-name="WebSearchAgent">
  <div class="agent-terminal-header">
    <div class="agent-terminal-icon">🔍</div>
    <div class="agent-terminal-name">WebSearchAgent</div>
    <div class="agent-terminal-status pending">Inactive</div>
  </div>
  <div class="agent-terminal-content">
    <!-- Logs appear here -->
  </div>
</div>
```

### 3. Terminal Active (Receiving logs)
```html
<div class="agent-terminal-ws active working">
  ...
  <div class="agent-terminal-status working">Working...</div>
  <div class="agent-terminal-content">
    <div class="log-stream">
      <div class="log-line">Log line 1...</div>
      <div class="log-line">Log line 2...</div>
      ...
    </div>
  </div>
</div>
```

## Browser Screenshot Handling

Browser screenshots are now routed dynamically:

```javascript
updateBrowserView(screenshotBase64) {
  // Find BrowserExecutor terminal dynamically
  const browserTerminal = document.getElementById('terminal-browserexecutor');
  
  // Create/update screenshot image
  let screenshotImg = browserTerminal.querySelector('.browser-screenshot-ws');
  if (!screenshotImg) {
    screenshotImg = document.createElement('img');
    screenshotImg.className = 'browser-screenshot-ws';
    browserTerminal.appendChild(screenshotImg);
  }
  
  screenshotImg.src = `data:image/png;base64,${screenshotBase64}`;
}
```

## Performance Considerations

### API Call Timing
- 500ms delay after task submission to ensure log file exists
- Single API call per task
- Cached agent list for entire task duration

### DOM Manipulation
- Batch terminal creation (single grid clear + append all)
- Efficient log line appending (no re-rendering)
- Auto-scroll only when new content added

### Memory
- Minimal overhead (4-6 terminals typically)
- Log lines use simple text nodes
- No unnecessary data storage

## Error Handling

### If log file doesn't exist
```javascript
// Falls back to empty grid with loading state
// Retries on next log stream connection
```

### If agent fetch fails
```javascript
// Keeps existing terminals or shows loading
// Logs error to console
// User can still see backend response
```

### If agent not recognized
```javascript
// Uses default agent info:
// Icon: 🤖, Type: agent, Task: "Task execution"
```

## Future Enhancements

### High Priority
1. **Real-time agent status** - Show "Working", "Complete", "Idle" based on log activity
2. **Agent collaboration graph** - Visualize which agents called which
3. **Per-agent logs toggle** - Show/hide logs for specific agents

### Medium Priority
4. **Agent performance metrics** - Show execution time, token usage per agent
5. **Historical agent usage** - Track which agents are used most often
6. **Custom agent icons** - Allow configuration of agent appearance

### Low Priority
7. **Agent drag-and-drop** - Reorder terminals in grid
8. **Agent filtering** - Hide specific agents from view
9. **Export agent logs** - Download logs for specific agent

## Testing

### Manual Test Checklist

1. **Task with all 3 executors**:
   ```
   Task: "Navigate to python.org, search for 'testing', and summarize"
   Expected: 4 terminals (Browser, Terminal, Search, Orchestrator)
   ```

2. **Task with only WebSearch**:
   ```
   Task: "What are the top Python testing frameworks?"
   Expected: 2 terminals (Search, Orchestrator)
   ```

3. **Task with only Terminal**:
   ```
   Task: "List files in current directory"
   Expected: 2 terminals (Terminal, Orchestrator)
   ```

4. **Verify log routing**:
   - BrowserExecutor logs go to Browser terminal
   - TerminalExecutor logs go to Terminal terminal
   - WebSearchAgent logs go to Search terminal
   - Other logs go to Orchestrator terminal

5. **Verify browser screenshots**:
   - Screenshots appear in BrowserExecutor terminal (not separate box)
   - Screenshots update in real-time

## Migration Notes

### Breaking Changes
- HTML now starts with empty agent grid
- Static terminal IDs no longer exist
- Agent terminals created dynamically

### Backward Compatibility
- Old screenshots code updated to find terminals dynamically
- Fallback to default behavior if agent fetch fails
- Works with existing backend/log format

## Related Files

- `surface_synapse/server.py` - Agent detection API endpoint
- `electron-app/src/renderer/js/app.js` - Dynamic terminal creation
- `electron-app/src/renderer/index.html` - Empty agent grid
- `electron-app/src/renderer/css/styles.css` - Loading state styles

## Success Criteria

✅ **UI shows only active agents**  
✅ **Logs route to correct terminals**  
✅ **New agents appear automatically**  
✅ **No hardcoded agent list in HTML**  
✅ **Scalable for future agents**  

## Conclusion

Dynamic agent detection makes the Electron UI **adaptive and intelligent**. It shows exactly what Synapse is doing, no more, no less. As Synapse evolves and adds new agents, the UI automatically adapts without code changes.

**Status**: ✅ **COMPLETE AND READY TO TEST**
