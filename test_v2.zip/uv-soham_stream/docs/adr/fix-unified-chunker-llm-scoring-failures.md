# ADR: Fix Unified Chunker LLM Scoring Failures

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: task_1769861041817_2026-01-31_17-34-25.log

## Problem

The `UnifiedChunker`'s LLM-based relevance scoring was failing consistently with JSON parsing errors:

```
Expecting value: line 1 column 1 (char 0)
```

**Symptoms**:
- 69 consecutive LLM scoring failures in a single session
- All chunks received neutral score (0.5), defeating the purpose of relevance scoring
- Poor error messages that didn't show what the LLM actually returned
- No fallback mechanism for when LLM scoring fails

**Root Cause**:
The LLM (Claude Sonnet 4.5) was returning empty strings or malformed JSON instead of the expected relevance scores, and the error handling didn't provide enough detail or fallback options.

## Solution

### 1. Improved Error Handling & Logging

Enhanced error messages to show actual LLM responses:

```python
if not scores_json or scores_json.strip() == "":
    logger.warning(
        f"⚠️ LLM returned empty scores for batch {i} "
        f"(failure {self.failure_count}/{self.max_failures_before_fallback})"
    )
```

Added detailed JSON parsing error logging:

```python
except json.JSONDecodeError as json_err:
    logger.warning(
        f"⚠️ JSON parsing failed for batch {i}: {json_err}\n"
        f"   Raw response: {scores_json[:200]}..."
    )
```

### 2. Enhanced DSPy Signature

Made the output format requirements more explicit:

```python
scores: str = dspy.OutputField(
    desc="JSON dict mapping chunk_index to relevance score 0.0-1.0. "
    "MUST be valid JSON. Example: {\"0\": 0.8, \"1\": 0.5, \"2\": 0.9}. "
    "DO NOT include any text before or after the JSON object."
)
```

### 3. Failure Tracking

Added failure counter to track consecutive LLM scoring failures:

```python
self.failure_count = 0
self.max_failures_before_fallback = 5
```

### 4. Heuristic Fallback Scoring

Implemented a simple but reasonable heuristic scorer when LLM fails:

```python
def _heuristic_score(self, query: str, chunks: List[ContentChunk]) -> Dict[int, float]:
    """
    Fallback heuristic scoring when LLM fails.
    
    Uses simple rules:
    1. Earlier chunks get slightly higher scores (recency bias)
    2. Chunks with more content get slightly higher scores
    3. All scores in 0.4-0.6 range to maintain some variance
    """
```

### 5. Automatic Fallback After Repeated Failures

After 5 consecutive failures, the system automatically switches to heuristic scoring:

```python
if self.failure_count >= self.max_failures_before_fallback:
    logger.warning("⚠️ Too many LLM scoring failures, switching to heuristic scoring")
    return self._heuristic_score(query, chunks)
```

## Benefits

1. **Better Debugging**: Clear error messages showing what the LLM returned
2. **Resilience**: System continues to work even when LLM scoring fails
3. **Graceful Degradation**: Heuristic scoring is better than uniform 0.5 scores
4. **Automatic Recovery**: Switches to fallback after repeated failures
5. **Self-Healing**: Failure count decreases on successful parses

## Trade-offs

- Heuristic scoring is not semantic (position + length based)
- Still relies on LLM when available, which may continue to fail
- Failure threshold (5) is somewhat arbitrary

## Future Improvements

If LLM scoring continues to fail:

1. Investigate DSPy configuration and model compatibility
2. Try different prompting strategies or simpler signatures
3. Consider switching to embedding-based similarity scoring
4. Add configurable timeout/retry logic for LLM calls
5. Investigate if the model needs specific JSON mode enabled

## Files Modified

- `Synapse/core/unified_chunker.py`: Enhanced error handling, added heuristic fallback

## Related Issues

- Observed in: `logs/electron_tasks/task_1769861041817_2026-01-31_17-34-25.log:2348`
- 69 failures across batches 0-240
