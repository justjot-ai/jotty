# ADR: Skip Library Research for Existing Capabilities

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: ResearchAgent still researching implementation details when capabilities exist

## Problem

Even after updating all signatures to clarify that capabilities are existing actors, the `ResearchAgent` was still **researching how to implement** capabilities that already exist.

**Observed Behavior**:
```
Available Capabilities: browser_interaction, summarization

ResearchAgent actions:
✅ [TOOL] generate_research_plan
❌ [TOOL] research_library: selenium - installation and basic usage
❌ [TOOL] research_library: playwright - WhatsApp Web automation  
❌ [WEB CRAWL] https://github.com/GabriellBP/whatsapp-web-scraping/master/main.py
❌ [WEB CRAWL] https://github.com/GabriellBP/whatsapp-web-scraping/tree/master/utils
❌ [TOOL] research_library: transformers - text summarization models
```

**Why This Is Wrong**:
- If `browser_interaction` exists, we DON'T need to research Selenium/Playwright
- If `summarization` exists, we DON'T need to research transformers/BART
- We should only research WORKFLOW, not IMPLEMENTATION

## Root Cause

The `ResearchAgent` uses DSPy ReAct orchestration, which **autonomously decides** which tools to call. Even with updated signatures saying "don't research libraries for existing capabilities", the ReAct agent would still call `research_library` tool because:

1. **LLM Training Bias**: LLMs are trained on "how to build things" patterns
2. **Thoroughness Instinct**: ReAct agents tend to be thorough and research everything
3. **No Active Filtering**: No logic prevented library research when capability exists

## Solution: Active Filtering in `research_library` Tool

### Implementation

Added **capability-aware filtering** directly in the `_tool_research_library` method:

```python
def _tool_research_library(self, library_name: str, aspect: str) -> str:
    """Tool: Research a specific library."""
    logger.info(f"[TOOL] research_library: {library_name} - {aspect}")
    
    # Check if this library is for a capability we already have
    library_lower = library_name.lower()
    capabilities_lower = self.context.available_capabilities.lower()
    
    # Skip research if library is for existing capability
    if any([
        (library_lower in ["selenium", "playwright", "puppeteer"] and 
         "browser_interaction" in capabilities_lower),
        (library_lower in ["transformers", "bart", "t5", "gpt"] and 
         "summarization" in capabilities_lower),
        (library_lower in ["beautifulsoup", "scrapy", "requests"] and 
         "web_search" in capabilities_lower)
    ]):
        skip_message = (
            f"Skipping {library_name} research - capability already exists. "
            f"Available capabilities: {self.context.available_capabilities}"
        )
        logger.info(f"[RESEARCH AGENT] {skip_message}")
        self._record_step(
            "LibraryResearcher",
            f"skip {library_name} (capability exists)",
            skip_message
        )
        return skip_message
    
    # Otherwise, proceed with library research
    query = self.library_researcher(library_name=library_name, aspect=aspect)
    # ...
```

### Mapping: Library → Capability

| Library | Capability | Reason |
|---------|-----------|--------|
| Selenium, Playwright, Puppeteer | `browser_interaction` | Browser automation tools |
| transformers, BART, T5, GPT | `summarization` | Text summarization/generation models |
| BeautifulSoup, Scrapy, requests | `web_search` | Web scraping/HTTP tools |

### Updated Tool Description

```python
dspy.Tool(
    func=self._tool_research_library,
    name="research_library",
    desc="Deep-dive into a specific library ONLY if capability doesn't exist. "
    "DO NOT use for libraries that implement existing capabilities (e.g., Selenium when browser_interaction exists). "
    "Provide library_name and aspect."
)
```

## Expected Behavior After Fix

### Before (Wasted Research)

```
Available Capabilities: browser_interaction, summarization

Research Steps:
1. ✅ generate_research_plan
2. ❌ research_library: selenium (wasted time)
3. ❌ research_library: playwright (wasted time)
4. ❌ research_library: transformers (wasted time)
5. ✅ synthesize_findings

Result: 5 steps, 3 wasted
Time: 2-3 minutes (due to web searches)
```

### After (Efficient Research)

```
Available Capabilities: browser_interaction, summarization

Research Steps:
1. ✅ generate_research_plan
2. ⚠️  research_library: selenium → SKIPPED (capability exists)
3. ⚠️  research_library: playwright → SKIPPED (capability exists)
4. ⚠️  research_library: transformers → SKIPPED (capability exists)
5. ✅ synthesize_findings

Result: 5 steps, 0 wasted
Time: 30 seconds (no web searches needed)
```

## Logs Example

**Before**:
```
2026-01-29 22:00:44 - [🔍 WEB CRAWL] START | url=https://raw.githubusercontent.com/GabriellBP/whatsapp-web-scraping/master/main.py
2026-01-29 22:00:44 - [🔍 WEB CRAWL] COMPLETE | result_length=3727
```

**After**:
```
2026-01-29 22:00:44 - [RESEARCH AGENT] Skipping selenium research - capability already exists. Available capabilities: browser_interaction, summarization
```

## Benefits

1. ✅ **Faster Research**: No time wasted on unnecessary library research
2. ✅ **Lower Costs**: Fewer web search API calls
3. ✅ **Clearer Intent**: Research log shows only workflow research
4. ✅ **Correct Focus**: Agent focuses on WORKFLOW, not implementation
5. ✅ **Better Plans**: Implementation plans describe workflows, not coding projects

## Edge Cases

### When Library Research SHOULD Happen

Even with capabilities available, research library if:

1. **Different Purpose**: Library serves a different purpose than the capability
   ```
   Capability: summarization
   Library Research: pyyaml (for config parsing) ✅ ALLOW
   ```

2. **Complementary Tool**: Library complements the capability
   ```
   Capability: browser_interaction
   Library Research: pandas (for data analysis) ✅ ALLOW
   ```

3. **Capability Gap**: Task needs something not covered by capabilities
   ```
   Capabilities: browser_interaction
   Task: "Train ML model on scraped data"
   Library Research: scikit-learn ✅ ALLOW (no ML capability)
   ```

### When to Extend the Mapping

Add new mappings when:
- New common libraries emerge (e.g., new browser automation tool)
- New capabilities are added to the system
- Patterns show repeated unnecessary research

## Alternatives Considered

1. **Remove `research_library` Tool Entirely**: Too drastic, needed for tasks without capabilities
2. **Stricter Signatures Only**: Already tried, LLMs still called the tool
3. **Pre-Filter Tool List**: Complex to maintain, capability-specific tool lists
4. **Post-Processing Filter**: Would still waste time/API calls

## Trade-offs

### Advantages
- Immediate time/cost savings
- Clear logging of skipped research
- Maintains library research capability when needed

### Disadvantages
- Hardcoded library-to-capability mapping (needs maintenance)
- May miss edge cases where research is actually needed
- Doesn't prevent ReAct from trying (just returns early)

## Future Improvements

1. **Dynamic Mapping**: Learn library-to-capability mappings from past research
2. **Capability Inference**: Automatically infer which libraries map to which capabilities
3. **Smarter ReAct Prompting**: Train ReAct to not even attempt calls when capabilities exist

## Related ADRs

- `capabilities-are-existing-actors-not-code-to-write.md`: Why capabilities shouldn't be built
- `prevent-react-tool-bypass.md`: Ensuring proper agent behavior
- `dag-optimization-remove-unnecessary-tasks.md`: Removing unnecessary tasks from DAG

## Conclusion

The `ResearchAgent` now **actively filters out** library research for capabilities that already exist. When the ReAct agent tries to research Selenium with `browser_interaction` available, the tool returns immediately with "Skipping - capability exists" instead of performing unnecessary web searches.

This results in faster research, lower costs, and implementation plans that focus on WORKFLOW (using existing actors) rather than IMPLEMENTATION (building from scratch).
