# Synapse File Persistence Inventory

**Date:** February 5, 2026  
**Status:** Active  
**Purpose:** Document all file paths where Synapse persists information and what data is stored

## Base Directory Structure

All persistence happens under `output_base_dir` (default: `./outputs`). When `create_run_folder=True`, files are stored in timestamped folders like `outputs/run_YYYYMMDD_HHMMSS/`.

### Global vs Run-Specific State

**Global State** (shared across all runs):
- Stored in `{output_base_dir}/global/synapse_state/`
- Includes: Memories, Q-Tables, Brain State
- These persist across all runs and are shared

**Run-Specific State** (per run folder):
- Stored in `{output_base_dir}/run_YYYYMMDD_HHMMSS/synapse_state/`
- Includes: TODOs, Environment, Episodes, Test Aggregator, User Feedback, TD(λ) State
- These are specific to each run and not shared

## File Persistence Locations

### 1. Session Management (`SessionManager`)

**Base Path:** `{output_base_dir}/run_YYYYMMDD_HHMMSS/` or `{output_base_dir}/` (if `create_run_folder=False`)

#### 1.1 Configuration Snapshot
- **Path:** `{session_dir}/config_snapshot.json`
- **Content:** Complete SynapseConfig serialized as JSON
- **Purpose:** Record configuration used for this session
- **Format:** JSON with dataclass serialization

#### 1.2 Session State

**Note:** Global state (memories, Q-tables, brain_state) is stored in `{output_base_dir}/global/synapse_state/` and shared across all runs. Run-specific state is stored in `{session_dir}/synapse_state/`.

##### Memories (GLOBAL - Shared Across Runs)
- **Path:** `{output_base_dir}/global/synapse_state/memories/shared_memory.json`
- **Content:** Shared hierarchical memory across all agents
  - Memory levels (episodic, semantic, procedural)
  - Content, context, goal, value, timestamp
  - All memory attributes dynamically serialized

- **Path:** `{output_base_dir}/global/synapse_state/memories/agent_memories/{agent_name}.json`
- **Content:** Per-agent hierarchical memories
  - Same structure as shared memory
  - One file per agent (e.g., `SQLGenerator.json`, `BusinessTermResolver.json`)

##### Q-Tables (GLOBAL - Shared Across Runs)
- **Path:** `{output_base_dir}/global/synapse_state/q_tables/q_predictor_state.json`
- **Content:** Q-learning predictor state
  - Q-table entries (state-action pairs → Q-values)
  - Experience buffer
  - Tier structure (tier1_working, tier2_clusters, tier3_archive)
  - Learning parameters (alpha, gamma, epsilon)
  - Last episode reward
  - Timestamp

- **Path:** `{output_base_dir}/global/synapse_state/q_tables/q_predictor_buffer.json`
- **Content:** Experience buffer for Q-learning
  - Experience tuples (state, action, reward, next_state)
  - Buffer size
  - Timestamp

- **Path:** `{output_base_dir}/global/synapse_state/q_tables/agentic_tag_index.json`
- **Content:** Agentic tag index state
  - Tag statistics
  - Tag-to-entries mapping
  - Entry-to-tags mapping
  - Clusters
  - Tag utility scores
  - Search performance metrics

##### Brain State (GLOBAL - Shared Across Runs)
- **Path:** `{output_base_dir}/global/synapse_state/brain_state/consolidated_memories.json`
- **Content:** Brain consolidation state
  - Brain type
  - Preset configuration
  - Chunk size
  - Consolidation count
  - Sleep interval
  - All brain attributes dynamically serialized
  - Timestamp

##### TODOs (Markovian) (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/markovian_todos/todo_state.json`
- **Content:** Complete TODO state
  - Root task
  - TODO ID
  - All subtasks with full details:
    - Task ID, description, actor
    - Status, priority, estimated reward
    - Confidence, attempts, max_attempts
    - Progress, dependencies, blocks
    - Started/completed timestamps
    - Estimated duration
    - Intermediary values (dynamic)
    - Predicted next task, duration, reward
    - Failure reasons, result, error
  - Execution order
  - Completed/failed task IDs
  - Current task ID
  - Estimated remaining steps
  - Completion probability
  - Timestamp

- **Path:** `{session_dir}/synapse_state/markovian_todos/todo_display.md` (RUN-SPECIFIC)
- **Content:** Rich markdown display of TODO state
  - Progress overview
  - Currently in-progress tasks
  - Pending tasks queue (sorted by priority × Q-value)
  - Recently completed tasks
  - Failed tasks with reasons
  - State insights (average Q-value, duration, failure rate)
  - Auto-generated, no hardcoded formatting

##### Environment State (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/env/env.md`
- **Content:** Environment context tracking
  - Goal context
  - Environment updates with timestamps
  - Automatically summarized when >10KB
  - Thread-safe append operations

- **Path:** `{session_dir}/synapse_state/env/env_history.json` (RUN-SPECIFIC)
- **Content:** History of environment snapshots
  - Array of snapshots with:
    - Content (full text)
    - Timestamp
    - Size in bytes
    - Line count
  - Max 10 snapshots retained

##### Episode History (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/episode_history/episode_{episode_num}.json`
- **Content:** Complete episode trajectory
  - Episode number
  - Metadata (total episodes, iteration, etc.)
  - Full trajectory (list of steps)
  - Trajectory length
  - Timestamp

##### Test Aggregator (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/test_aggregator/test_aggregator.json`
- **Content:** Bayesian test aggregator state
  - Episode count
  - Test pass counts (per test)
  - Test total counts (per test)
  - Test quality correlation
  - Timestamp

##### User Feedback (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/user_feedback/user_feedback.json`
- **Content:** Human feedback for learning
  - Array of feedback entries:
    - Task ID
    - Reward value
    - Reason
    - Timestamp (ISO format)

##### TD(λ) Learner State (RUN-SPECIFIC)
- **Path:** `{session_dir}/synapse_state/td_lambda/td_lambda_state.json`
- **Content:** Temporal difference learning state
  - Eligibility traces
  - Values at access
  - Current goal
  - Access sequence
  - Timestamp

#### 1.3 Results
- **Path:** `{session_dir}/results/query_results.json`
- **Content:** Query execution results
  - Results from database queries or other operations
  - JSON format

#### 1.4 Logs
- **Path:** `{session_dir}/logs/raw/{log_type}_{timestamp}.log`
- **Content:** Raw log files
  - Timestamped log files
  - Various log types (raw, debug, etc.)

- **Path:** `{session_dir}/logs/beautified/`
- **Content:** Beautified/formatted log files
  - Processed logs for better readability

- **Path:** `{session_dir}/logs/debug/`
- **Content:** Debug log files
  - Detailed debugging information

### 2. Persistence Manager (`PersistenceManager` in `synapse_core.py`)

**Base Path:** `{base_path}` (configurable, defaults to `~/.synapse/my_project`)

#### 2.1 Global State
- **Path:** `{base_path}/state.json`
- **Content:** Global Synapse state
  - Complete state dictionary
  - JSON format with default string serialization

#### 2.2 Memories
- **Path:** `{base_path}/memories/{agent_name}.json`
- **Content:** Per-agent memory
  - HierarchicalMemory serialized to dict
  - All memory levels and content

#### 2.3 Offline Learning
- **Path:** `{base_path}/offline.json`
- **Content:** Offline learner state
  - OfflineLearner serialized to dict
  - Batch learning data

#### 2.4 Backups
- **Path:** `{base_path}/backups/backup_{episode}_{timestamp}/`
- **Content:** Periodic backups
  - Copies of state.json
  - Copies of all memory files
  - Created every N episodes (configurable)
  - Old backups cleaned up (max_backups limit)

### 3. Vault (`Vault` in `persistence.py`)

**Base Path:** `{base_output_dir}/synapse_state/`

Same structure as SessionManager's synapse_state, but managed by Vault class. See section 1.2 for details.

### 4. Q-Learning (`LLMQPredictor` in `q_learning.py`)

#### 4.1 Q-Learning State
- **Path:** `{path}` (passed to `save_state()` method)
- **Content:** Complete Q-learning state
  - Q-table (state-action → Q-value mappings)
  - Experience buffer
  - Agentic tag index (embedded)
  - Strategy statistics
  - Prediction history
  - Learning parameters
  - Timestamp

#### 4.2 Agentic Tag Index
- **Path:** `{path}` (separate file or embedded in Q-state)
- **Content:** Tag index state
  - Version number
  - Tag statistics
  - Tag-to-entries mapping
  - Entry-to-tags mapping
  - Clusters
  - Tag utility scores
  - Search metrics
  - Timestamp

### 5. Environment Manager (`EnvironmentManager`)

**Base Path:** `{config.env_dir}` or `{synapse_dir}/env` or `outputs/synapse_state/env`

#### 5.1 Environment File
- **Path:** `{env_dir}/env.md`
- **Content:** Environment context
  - Markdown format
  - Goal context header
  - Timestamped environment updates
  - Auto-summarized when >10KB

#### 5.2 Environment History
- **Path:** `{env_dir}/env_history.json`
- **Content:** Snapshot history
  - Array of environment snapshots
  - Each snapshot: content, timestamp, size_bytes, line_count
  - Max 10 snapshots retained

### 6. Roadmap (`Roadmap` in `roadmap.py`)

#### 6.1 Checkpoints
- **Path:** `{checkpoint_dir}/{checkpoint_id}.json`
- **Content:** Roadmap checkpoint
  - Episode ID
  - Timestamp
  - AgenticState serialized
  - DecomposedQFunction serialized
  - MarkovianTODO serialized

### 7. Adaptive Limit Learner (`AdaptiveLimitLearner`)

#### 7.1 Learned Limits
- **Path:** `{filepath}` (configurable)
- **Content:** Learned model limits
  - Per-model learned limits:
    - Actual limit value
    - Learned from error flag
    - Timestamp
    - Confidence score

### 8. Unified Reward Calculator (`UnifiedRewardCalculator`)

#### 8.1 User Feedback
- **Path:** `{path}` (passed to `save_user_feedback()`)
- **Content:** User feedback entries
  - Array of feedback:
    - Task ID
    - Reward value
    - Reason
    - Timestamp (ISO format)

### 9. Config Learner (`ConfigLearner`)

#### 9.1 Config Backup
- **Path:** `{backup_path}` (configurable)
- **Content:** Configuration backup
  - Complete config dictionary
  - Created before applying updates

#### 9.2 Config File
- **Path:** `{config_path}` (from `__init__`)
- **Content:** Updated configuration
  - Configuration after learning updates
  - JSON format

### 10. File Storage (`TieredFileStorage`)

**Base Path:** Configurable (default: `/tmp/synapse_shared`)

#### 10.1 Registry
- **Path:** `{base_path}/registry.json`
- **Content:** File registry
  - FileReference objects indexed by file_id
  - Path index mapping
  - Storage tier information

#### 10.2 File Storage Tiers
- **HOT:** `{base_path}/hot/{file_id}_{filename}`
  - Raw files, 0-1 day old
  - Instant access

- **WARM:** `{base_path}/warm/{file_id}_{filename}`
  - Raw files, 1-7 days old
  - Fast access

- **COLD:** `{base_path}/cold/{file_id}_{filename}.gz`
  - Gzip compressed, 7-30 days old
  - Medium access

- **ARCHIVE:** `{base_path}/archive/{month}_{year}.tar.gz`
  - Monthly tar.gz bundles, 30+ days old
  - Slow access

**Content:** Binary files (images, audio, documents, etc.)
- Original filename preserved
- Content type (MIME)
- Checksum (SHA256)
- Metadata dictionary
- Access tracking

### 11. Synapse Fixes (`SynapseFixes`)

#### 11.1 Default Prompts
- **Path:** `{default_architect_path}` (configurable)
- **Content:** Default architect prompt
  - Markdown prompt text

- **Path:** `{default_auditor_path}` (configurable)
- **Content:** Default auditor prompt
  - Markdown prompt text

### 12. Conductor (`Conductor`)

#### 12.1 Prompt Updates
- **Path:** `{prompt_path}` (from actor config)
- **Content:** Updated prompts
  - Architect prompts
  - Auditor prompts
  - Updated by SwarmLearner based on performance

## Summary Statistics

### Total File Types Persisted:
1. **Configuration:** 3 files (snapshot, config, backup)
2. **Memory:** 1+ files (shared + per-agent)
3. **Q-Learning:** 3 files (state, buffer, tag index)
4. **Brain State:** 1 file
5. **TODOs:** 2 files (JSON state + markdown display)
6. **Environment:** 2 files (markdown + history JSON)
7. **Episodes:** N files (one per episode)
8. **Test Aggregator:** 1 file
9. **User Feedback:** 1 file
10. **TD(λ) State:** 1 file
11. **Results:** 1 file
12. **Logs:** Multiple files (raw, beautified, debug)
13. **File Storage:** Registry + tiered storage files
14. **Checkpoints:** N files (one per checkpoint)
15. **Learned Limits:** 1 file
16. **Prompts:** 2+ files (defaults + updated prompts)

### Data Formats:
- **JSON:** Most state files (indented, default=str serialization)
- **Markdown:** TODO display, environment context, prompts
- **Binary:** File storage tiers (raw or compressed)
- **Logs:** Text files

### Key Design Principles:
1. **No Hardcoding:** All paths configurable via SynapseConfig
2. **Human-Readable:** JSON instead of pickle
3. **Extensible:** Dynamic serialization, no hardcoded schemas
4. **Thread-Safe:** Locking for concurrent access
5. **Auto-Save:** Configurable intervals
6. **Auto-Load:** Resume from previous session
7. **Backup Support:** Automatic backups with cleanup
8. **Tiered Storage:** Hot/Warm/Cold/Archive for files

## Notes

- All paths are relative to `output_base_dir` unless otherwise specified
- Timestamped run folders created when `create_run_folder=True`
- `latest/` symlink points to most recent run folder
- Old runs cleaned up based on `max_runs_to_keep`
- Auto-save happens every N iterations (configurable)
- State can be auto-loaded on startup if `auto_load_on_start=True`
