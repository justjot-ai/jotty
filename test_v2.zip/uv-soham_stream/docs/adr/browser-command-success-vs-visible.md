# ADR: Browser Command "Success" vs User-Visible Action

## Status
Accepted

## Context
Browser commands (click, type, press_key, etc.) are executed in the Electron main process against the BrowserView's webContents. The backend reports "success" when:
- The element was found (for selector-based commands) and the action was applied (e.g. element.click(), or sendInputEvent was sent).

The user may see nothing change in the UI even when every command returns success. Causes:

1. **BrowserView not visible**: The BrowserView was hidden (e.g. card scrolled out of view, or never shown for this task). Commands run in that webContents and succeed, but the user is not looking at that view (or it has zero size / off-screen bounds).
2. **Wrong bounds**: When the browser card was off-screen or just created, getBoundingClientRect() could return coordinates outside the window or zero size, so the BrowserView was positioned where the user cannot see it.
3. **Wrong element**: The agent targeted an element that exists (e.g. generic `div[role='textbox']`) but it was the search box instead of the message box, so the visible effect was not what the user expected.

## Decision
- **Ensure browser is visible before every command**: The renderer calls `ensureBrowserVisibleForCommand()` at the start of each browser command. If the browser was hidden (e.g. due to scroll) or not yet shown, we show it and update bounds so the user sees the BrowserView when the command runs.
- **Scroll card into view before bounds**: When showing the browser, we scroll the browser card into view (`scrollIntoView`) and then read bounds, so the BrowserView is positioned on-screen.
- **Success semantics**: "Success" means the command was executed in the BrowserView's webContents. If the user still sees nothing, possible causes are wrong element (e.g. search vs message box—see whatsapp-web-message-box-selector ADR), or a timing/DOM issue in the page.

## Consequences
- Click/type/press_key no longer run against a hidden or off-screen BrowserView when the user has the workspace open; the browser is shown and positioned first.
- Retry or follow-up tasks that send click/type without a prior set_visible still get the browser shown so the user can see the actions.
