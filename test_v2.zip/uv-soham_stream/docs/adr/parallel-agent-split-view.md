# ADR: Parallel Agent Split View for Simultaneous Execution

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** User request to show both browser and terminal side-by-side during parallel execution

## Problem

Currently, the UI shows only one active agent at a time. When multiple agents execute in parallel (e.g., BrowserExecutor and TerminalExecutor), the UI switches between them, replacing one view with another. This makes it impossible to see both agents working simultaneously.

## Decision

Implement a split-view layout that can display multiple agents side-by-side when they are active in parallel:

1. **Layout Strategy:**
   - Single agent active: Full-screen view (current behavior)
   - Two agents active: 50/50 horizontal split
   - Three agents active: Grid layout (2x2 with one empty)
   - Four agents active: 2x2 grid

2. **Implementation Changes:**
   - Modify `AgentViewManager` to track multiple active agents
   - Update `switchToAgent()` to `activateAgent()` - additive instead of exclusive
   - Add `deactivateAgent()` to remove specific agents from view
   - Implement dynamic grid layout based on active agent count
   - Maintain smooth transitions when agents activate/deactivate

3. **CSS Layout:**
   - Use CSS Grid for flexible multi-agent layout
   - Apply `.split-view-2`, `.split-view-3`, `.split-view-4` classes
   - Ensure each agent view maintains proper aspect ratio

## Consequences

### Positive
- Users can see multiple agents working simultaneously
- Better visibility into parallel execution
- More intuitive understanding of multi-agent workflows

### Negative
- Each agent view gets less screen space when multiple are active
- Potential performance impact with multiple active views (especially browser screenshots)
- More complex state management in AgentViewManager

## Implementation Notes

- Browser screenshot capture should continue at 2 FPS to minimize overhead
- Terminal views should remain performant with xterm.js
- Smooth transitions when agents activate/deactivate
- Graceful handling of edge cases (rapid activation/deactivation)
