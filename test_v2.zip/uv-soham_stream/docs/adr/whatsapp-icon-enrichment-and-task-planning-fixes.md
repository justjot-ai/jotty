# ADR: WhatsApp Icon Enrichment and Task Planning Fixes

## Status
Accepted

## Context

Two critical bugs were identified during WhatsApp Web automation:

### Bug 1: Can't Find + Icon
WhatsApp Web uses icon-only buttons (e.g., the "+" button for attachments) that appear as empty buttons (`button ""`) in the AXTree accessibility tree. The LLM cannot identify these buttons because they lack accessible names, causing failures when trying to interact with icon-only UI elements.

### Bug 2: Wrong Execution Order
When the task requires "send file to contact", the LLM sees both:
- The task description mentioning "send file"
- The attach button visible on screen

This causes the LLM to skip directly to attaching a file before finding and selecting the contact first. The agent attempts to attach files before establishing the correct conversation context, leading to task failures.

## Decision

### Fix 1: Auto-Enrich Unnamed Interactive Elements
During AXTree serialization, automatically enrich unnamed interactive elements (buttons, links, etc.) by making CDP calls to extract semantic attributes:

1. **Detection**: When serializer encounters a button/link with no accessible name (`name=""`)
2. **Enrichment**: Make CDP calls to read:
   - `data-icon` attribute
   - `data-tooltip` attribute  
   - `data-testid` attribute
   - `aria-label` attribute
3. **Format**: Display enriched buttons as `button "[icon:plus]"` instead of `button ""`
4. **Performance**: Uses `DOM.resolveNode` → `Runtime.callFunctionOn` pattern, adds ~30ms per page read

### Fix 2: Task Planner Step
Add a task planning step that runs **once** before the action loop:

1. **Planning Phase**: 
   - Analyze the full task
   - Create a numbered, sequential plan (e.g., "1. Search Sarah → 2. Select from results → 3. Click attach → 4. Select file → 5. Send message")
   - Display plan with progress markers (`/`)

2. **Execution Phase**:
   - Show the plan at every step
   - LLM follows plan in sequence
   - Mark `plan_step_complete: true` when each sub-task finishes
   - Prevents skipping steps by maintaining explicit sequence

## Consequences

### Positive
- **Bug 1 Fix**: LLM can now identify and interact with icon-only buttons reliably
- **Bug 2 Fix**: Tasks execute in correct order, preventing premature actions
- Better task success rate for WhatsApp Web automation
- More predictable agent behavior

### Negative
- **Bug 1 Fix**: Adds ~30ms latency per page read (acceptable trade-off)
- **Bug 2 Fix**: Adds planning overhead before execution starts
- Requires maintaining attribute extraction logic for different web apps

## Implementation Notes

### Icon Enrichment
- Implemented during tree serialization phase
- CDP calls: `DOM.resolveNode` → `Runtime.callFunctionOn`
- Attributes checked in order: `data-icon`, `data-tooltip`, `data-testid`, `aria-label`
- Format: `[icon:value]` where value comes from first found attribute

### Task Planner
- Runs once before action loop begins
- Creates numbered plan with clear sequence
- Plan displayed with each action step
- Progress tracking via `plan_step_complete` flag
- Prevents action execution until previous step marked complete
