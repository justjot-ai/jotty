# ADR: Fix NoneType Iteration Error for Actor Dependencies

**Status:** Implemented  
**Date:** 2026-01-31  
**Priority:** HIGH  
**Context:** TypeError when iterating over actor dependencies that were None

---

## 🚨 **Error**

```python
File "/Users/anshulchauhan/Tech/term/Synapse/core/conductor.py", line 5135, in _build_actor_context
    for dep_name in actor_config.dependencies:
                    ^^^^^^^^^^^^^^^^^^^^^^^^^
TypeError: 'NoneType' object is not iterable
```

### When It Occurred

When building actor context in the conductor, specifically when trying to collect previous outputs from dependencies.

---

## Root Cause

### Problem 1: `dependencies` Defaults to `None`

In `agent_config.py`:

```python
@dataclass
class AgentConfig:
    ...
    dependencies: Optional[List[str]] = None  # ❌ Defaults to None
```

When an actor is created without explicit dependencies, the field is `None`, not an empty list.

### Problem 2: Code Assumed Non-None Dependencies

In `conductor.py` line 5135:

```python
for dep_name in actor_config.dependencies:  # ❌ Crashes if None
    ...
```

The code directly iterated over `dependencies` without checking if it was `None`.

---

## Solution

### Two-Layer Fix

#### Fix 1: Default to Empty List (Root Cause)

Changed the default value in `AgentConfig`:

```python
@dataclass
class AgentConfig:
    ...
    dependencies: Optional[List[str]] = field(default_factory=list)  # ✅ Empty list, not None
```

**Benefits:**
- ✅ Safer default - can always iterate
- ✅ Consistent with Python best practices (mutable defaults use `field(default_factory=...)`)
- ✅ Prevents future similar errors

#### Fix 2: Defensive Check (Defense in Depth)

Added guard in `conductor.py`:

```python
# Check if dependencies exists and is not None
if actor_config.dependencies:
    for dep_name in actor_config.dependencies:
        logger.debug(f"        Checking dependency: {dep_name}")
        ...
else:
    logger.debug(f"      No dependencies defined for actor {actor_config.name}")
```

**Benefits:**
- ✅ Defense in depth - works even if dependencies is None
- ✅ Better logging - explicit message when no dependencies
- ✅ Handles legacy actors that might have None dependencies

---

## Why Both Fixes?

### Belt and Suspenders Approach

1. **Fix 1 (default_factory)** - Prevents the problem at the source
2. **Fix 2 (defensive check)** - Handles edge cases and legacy code

This follows the principle of **defense in depth** - multiple layers of protection against the same failure mode.

---

## Example

### Before (Crash)

```python
# Actor created without dependencies
actor = AgentConfig(
    name="BrowserExecutor",
    agent=browser_agent,
    architect_prompts=[],
    auditor_prompts=[]
    # dependencies not specified → defaults to None
)

# Later in conductor
for dep_name in actor.dependencies:  # 💥 TypeError: 'NoneType' object is not iterable
    ...
```

### After (Safe)

```python
# Actor created without dependencies
actor = AgentConfig(
    name="BrowserExecutor",
    agent=browser_agent,
    architect_prompts=[],
    auditor_prompts=[]
    # dependencies not specified → defaults to []
)

# Later in conductor
if actor.dependencies:  # ✅ Empty list evaluates to False
    for dep_name in actor.dependencies:
        ...
else:
    logger.debug("No dependencies")  # ✅ Graceful handling
```

---

## Files Changed

### `Synapse/core/agent_config.py`

**Line 51:** Changed default from `None` to `field(default_factory=list)`

**Before:**
```python
dependencies: Optional[List[str]] = None
```

**After:**
```python
dependencies: Optional[List[str]] = field(default_factory=list)  # Default to empty list, not None
```

### `Synapse/core/conductor.py`

**Lines 5135-5141:** Added defensive check before iteration

**Before:**
```python
for dep_name in actor_config.dependencies:
    logger.debug(f"        Checking dependency: {dep_name}")
    if dep_name in self.shared_context.get('actor_outputs', {}):
        previous_outputs[dep_name] = self.shared_context['actor_outputs'][dep_name]
        logger.debug(f"          ✅ Added output for {dep_name}")
```

**After:**
```python
# Check if dependencies exists and is not None
if actor_config.dependencies:
    for dep_name in actor_config.dependencies:
        logger.debug(f"        Checking dependency: {dep_name}")
        if dep_name in self.shared_context.get('actor_outputs', {}):
            previous_outputs[dep_name] = self.shared_context['actor_outputs'][dep_name]
            logger.debug(f"          ✅ Added output for {dep_name}")
else:
    logger.debug(f"      No dependencies defined for actor {actor_config.name}")
```

---

## Testing

### Verify Empty List Default

```python
from Synapse.core.agent_config import AgentConfig

# Create actor without dependencies
actor = AgentConfig(
    name="TestActor",
    agent=my_agent,
    architect_prompts=[],
    auditor_prompts=[]
)

print(actor.dependencies)  # Should print: []
print(type(actor.dependencies))  # Should print: <class 'list'>
```

### Verify Iteration Safety

```python
# Should not crash
for dep in actor.dependencies:
    print(dep)  # No output, but no error
```

---

## Related Issues

This pattern (None vs empty list) might exist in other fields. Check:
- `capabilities`
- `architect_prompts`
- `auditor_prompts`
- `architect_tools`
- `auditor_tools`
- `feedback_rules`

Currently:
- ✅ `architect_prompts` - defaults to `[]` (via `__post_init__`)
- ✅ `auditor_prompts` - defaults to `[]` (via `__post_init__`)
- ✅ `architect_tools` - defaults to `[]` (via `field(default_factory=list)`)
- ✅ `auditor_tools` - defaults to `[]` (via `field(default_factory=list)`)
- ⚠️  `capabilities` - defaults to `None`
- ⚠️  `feedback_rules` - defaults to `None`
- ✅ `dependencies` - **FIXED** to default to `[]`

---

## Best Practices

### For List Fields in Dataclasses

```python
# ❌ BAD - mutable default
my_list: List[str] = []

# ❌ BAD - None requires checks everywhere
my_list: Optional[List[str]] = None

# ✅ GOOD - empty list, safe to iterate
my_list: List[str] = field(default_factory=list)

# ✅ ALSO GOOD - if None has semantic meaning
my_list: Optional[List[str]] = None
# But then ALWAYS check before iterating:
if my_list:
    for item in my_list:
        ...
```

### When to Use None vs Empty List

**Use `None`** when:
- Absence of value has different meaning than empty
- Example: `metadata: Optional[Dict] = None` - no metadata vs empty metadata

**Use empty list** when:
- Absence means "no items"
- Example: `dependencies: List[str] = field(default_factory=list)` - no dependencies

---

## Summary

Fixed `TypeError: 'NoneType' object is not iterable` when iterating over actor dependencies:

1. **Root cause fix**: Changed `dependencies` default from `None` to `field(default_factory=list)` in `AgentConfig`
2. **Defensive fix**: Added guard check before iteration in `conductor.py`

Both fixes together provide robust protection against this class of errors.

---

## Verification

After this fix:
- ✅ Actors without dependencies work correctly
- ✅ Actors with dependencies work correctly
- ✅ Better logging when no dependencies present
- ✅ No linter errors
