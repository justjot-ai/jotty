# ADR: Synapse Expand Terminal Grid Design

**Date:** 2026-02-02  
**Status:** Implemented  
**Context:** Electron UI Enhancement

## Decision

Implemented the Synapse Expand terminal grid design pattern in the Electron app, featuring:

1. **Dynamic Grid Expansion**: Active terminals expand to 1.8x size while inactive ones shrink to 0.35 opacity
2. **Smooth Transitions**: 0.5s cubic-bezier animations for all grid changes
3. **Visual Hierarchy**: Clear distinction between active, complete, and inactive terminals
4. **4-Terminal Grid**: 2x2 grid layout with intelligent expansion based on focus

## Implementation

### CSS Changes

**agent-views.css:**
- Updated `.agent-view` with opacity 0.35 and scale(0.97) for inactive state
- Added `.agent-view.active` with full opacity and scale(1) for focused state
- Added `.agent-view.complete` with 0.85 opacity for finished tasks
- Enhanced box shadows and border colors for visual feedback

**styles.css:**
- Added `.focus-0` through `.focus-3` classes for grid expansion
- Updated grid transition to 0.5s cubic-bezier(0.16, 1, 0.3, 1)
- Synchronized `.agent-terminal-ws` styling with agent-view pattern

### JavaScript Changes

**agent-view-manager.js:**
- Added `focusedAgentIndex` tracking
- Implemented `setFocusedAgent()` method
- Updated `activateAgent()` to set focus on activation
- Enhanced `updateContainerLayout()` to apply focus classes
- Updated `deactivateAgent()` to handle active class removal

## Visual Design

### Grid Expansion Pattern
```
Normal (2x2):     Focus-0:          Focus-1:
┌──────┬──────┐   ┌────────┬────┐   ┌────┬────────┐
│  0   │  1   │   │   0*   │ 1  │   │ 0  │   1*   │
├──────┼──────┤   ├────────┼────┤   ├────┼────────┤
│  2   │  3   │   │   2    │ 3  │   │ 2  │   3    │
└──────┴──────┘   └────────┴────┘   └────┴────────┘
```

### Opacity States
- **Inactive**: 0.35 opacity, scale(0.97)
- **Active**: 1.0 opacity, scale(1), glowing border
- **Complete**: 0.85 opacity, green border glow

## Benefits

1. **Better Focus**: Clear visual indication of which agent is currently active
2. **Smooth UX**: Fluid animations create professional feel
3. **Space Efficiency**: Inactive terminals are visible but de-emphasized
4. **Visual Feedback**: Color-coded borders show terminal state at a glance

## References

- Source Design: `/Users/anshulchauhan/Downloads/synapse-expand (1).html`
- Implementation: `electron-app/src/renderer/`
