# Chess Best Move Task - Comprehensive Fix TODO

**Based on**: RCA Analysis + Algorithmic Bug Analysis  
**Created**: 2026-01-28  
**Status**: Implementation Plan

---

## 📋 Overview

This document consolidates fixes needed for the chess-best-move task failure, combining:
1. **Process/System Failures** (from RCA)
2. **Implementation Bugs** (from algorithmic analysis)

---

## 🔴 Priority 1: CRITICAL - Blocks Task Completion

### 1.1 Fix Web Search Tools ✅ FIXED
- **Issue**: Missing `open_source_web_tool` module causing web_search to fail
- **Impact**: Architect cannot research solutions
- **Fix Applied**: 
  - Added dependency validation in `__synapse_validate__()` method
  - Added dependency checks in all web search methods (web_search, web_search_and_crawl, web_crawl)
  - Improved error messages to guide users to install: `pip install duckduckgo-search requests beautifulsoup4`
  - Enhanced conductor initialization to validate dependencies before enabling web search tools
- **Files Modified**: 
  - `Synapse/core/web_search_tools.py` - Added dependency validation
  - `Synapse/core/conductor.py` - Added validation check before enabling provider
- **Dependencies Required**: `duckduckgo-search`, `requests`, `beautifulsoup4` (already in pyproject.toml)
- **Test**: Verify web_search works in Architect pre-planning phase

### 1.2 Install Stockfish by Default
- **Issue**: Stockfish never installed, required for chess move calculation
- **Impact**: Cannot calculate best moves even with correct FEN
- **Fix**: Add to Docker base image or installation script
  ```bash
  apt-get install -y stockfish
  ```
- **Files**: Dockerfile, installation scripts
- **Test**: Verify Stockfish available at `/usr/games/stockfish` or `/usr/bin/stockfish`

### 1.3 Fix FEN Coordinate Reversal Bug
- **Issue**: Image rows processed top-to-bottom but FEN ranks are bottom-to-top
- **Impact**: Pieces appear on wrong ranks, invalid position
- **Fix**: Reverse board rows when building FEN or process bottom-to-top
  ```python
  # In puzzle_to_fen(), after building board array:
  fen_rows = []
  for row in reversed(board):  # Reverse here
      # ... convert to FEN ...
      fen_rows.append(fen_row)
  ```
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 118-139)
- **Test**: Verify FEN matches actual board position

### 1.4 Add Circuit Breaker to Auditor
- **Issue**: Auditor watched agent fail for 18 minutes without intervention
- **Impact**: Wasted time, no recovery mechanism
- **Fix**: Implement failure detection and intervention
  ```python
  if consecutive_failures >= 3:
      halt_and_replan()
  if time_used > 0.25 * time_budget and progress == 0:
      escalate_to_expert()
  ```
- **Files**: `Synapse/core/inspector.py`, Auditor agent prompts
- **Test**: Verify Auditor intervenes after 3 failures

---

## 🟠 Priority 2: HIGH - Significantly Improves Success Rate

### 2.1 Fix Background Color Estimation
- **Issue**: Average color includes piece pixels, biasing background estimate
- **Impact**: Poor template matching, misclassification
- **Fix**: Use corner/edge regions or median filtering
  ```python
  # Instead of: avg_color = square_array.mean(axis=(0, 1))
  # Use corners only:
  corner_size = square_size // 4
  corners = [
      square_array[:corner_size, :corner_size],
      square_array[:corner_size, -corner_size:],
      square_array[-corner_size:, :corner_size],
      square_array[-corner_size:, -corner_size:]
  ]
  avg_color = np.median([c.mean(axis=(0,1)) for c in corners], axis=0)
  ```
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 91-94)
- **Test**: Verify background color matches actual square background

### 2.2 Improve Image Comparison Metric
- **Issue**: MSE sensitive to lighting/color, not shape
- **Impact**: Misclassification, empty squares preferred over pieces
- **Fix**: Replace MSE with SSIM or normalized cross-correlation
  ```python
  from skimage.metrics import structural_similarity as ssim
  score = 1 - ssim(img1, img2, multichannel=True)
  ```
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 48-56)
- **Test**: Verify better piece classification accuracy

### 2.3 Add Position Validation
- **Issue**: No validation that detected position is legal
- **Impact**: Invalid positions passed to engine
- **Fix**: Add chess position validation
  ```python
  def validate_position(board):
      # Check: exactly 2 kings, no pawns on ranks 1/8, etc.
      if board.king_count() != 2:
          raise ValueError("Invalid position: wrong king count")
      # ... more checks ...
  ```
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh`
- **Test**: Verify invalid positions are rejected

### 2.4 Fix Minimax Evaluation Bugs
- **Issue**: Evaluation perspective flips, checkmate wrong, depth calculation off
- **Impact**: Wrong move selection in custom implementations
- **Fix**: 
  - Always evaluate from White's perspective
  - Fix checkmate evaluation (return +10000 if Black mated, -10000 if White mated)
  - Fix depth calculation (don't double-decrement)
- **Files**: `app/analyze_chess_board.py` (lines 74-115)
- **Test**: Verify correct move selection in test positions

### 2.5 Enhance Architect Prompts
- **Issue**: Doesn't require research phase or feasibility validation
- **Impact**: Agent tries infeasible approaches
- **Fix**: Add mandatory research phase to Architect prompts
  ```markdown
  ## MANDATORY PRE-EXECUTION STEPS:
  1. Research Phase (if domain unfamiliar):
     - Use web_search to find existing solutions
     - Look for libraries, tools, or established methods
     - Estimate complexity and time required
  2. Feasibility Check:
     - Can this be done with available tools?
     - Are there dependencies to install?
     - Is this a solved problem?
  ```
- **Files**: `surface_synapse/architect/codemaster_agent.md`
- **Test**: Verify Architect performs research before execution

### 2.6 Enable Inter-Agent Consultation
- **Issue**: CodeMaster never consulted DomainExpert for chess tasks
- **Impact**: Missing domain expertise
- **Fix**: Implement mandatory consultation for specialized domains
  ```python
  if task_domain == "chess":
      consult_agent("DomainExpert", "How do I solve chess problems?")
  ```
- **Files**: `Synapse/core/shared_context.py`, agent communication logic
- **Test**: Verify DomainExpert consulted for chess tasks

---

## 🟡 Priority 3: MEDIUM - Improves Robustness & Learning

### 3.1 Fix Template Matching Assumptions
- **Issue**: Hardcoded font path, fixed positioning, assumes square size
- **Impact**: Runtime errors, poor matching
- **Fix**: 
  - Add font fallback mechanism
  - Make piece positioning configurable
  - Validate square size matches actual
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 22-46)
- **Test**: Verify works with different fonts and image sizes

### 3.2 Improve Square Extraction
- **Issue**: Assumes perfect grid, no perspective correction, no border handling
- **Impact**: Misalignment, missed pieces
- **Fix**: 
  - Detect actual board boundaries
  - Add perspective correction
  - Handle board margins/borders
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 71-89)
- **Test**: Verify works with rotated/perspective images

### 3.3 Fix Mate-in-2 Logic
- **Issue**: Only checks if we can mate after one opponent move, doesn't verify all responses
- **Impact**: Returns non-forcing moves
- **Fix**: Verify ALL opponent responses lead to mate-in-1
  ```python
  for move in board.legal_moves:
      board.push(move)
      all_responses_lead_to_mate = True
      for opp_move in board.legal_moves:
          board.push(opp_move)
          has_mate = any(board.is_checkmate() for our_move in board.legal_moves)
          board.pop()
          if not has_mate:
              all_responses_lead_to_mate = False
              break
      board.pop()
      if all_responses_lead_to_mate:
          best_moves.append(move.uci())
  ```
- **Files**: `app/chess_solver.py` (lines 30-53)
- **Test**: Verify correct mate-in-2 detection

### 3.4 Enhance Auditor Prompts
- **Issue**: No failure thresholds or intervention triggers
- **Impact**: No quality gates or re-planning
- **Fix**: Add failure detection and intervention rules
  ```markdown
  ## FAILURE DETECTION & INTERVENTION:
  1. Circuit Breaker Rules:
     - If same error occurs 3 times → HALT and re-plan
     - If no progress after 25% of time budget → ESCALATE
  2. Quality Gates:
     - After each major step, validate output
     - If validation fails, don't proceed
  ```
- **Files**: `surface_synapse/auditor/codemaster_agent.md`
- **Test**: Verify Auditor intervenes appropriately

### 3.5 Improve Task Planner
- **Issue**: Tasks too abstract, no research phase, no validation checkpoints
- **Impact**: Poor task breakdown, no fallbacks
- **Fix**: 
  - Make tasks concrete and testable
  - Always include research phase
  - Add validation checkpoints
  - Include fallback tasks
- **Files**: `surface_synapse/task_planner/task_decomposition.md`
- **Test**: Verify task breakdown includes research and validation

### 3.6 Implement Strategy Timeout
- **Issue**: Agent stuck on one approach for 18 minutes
- **Impact**: No fallback, wasted time
- **Fix**: Max 5 minutes per approach, force re-planning
  ```python
  if time_spent_on_strategy > 300:  # 5 minutes
      abort_strategy()
      try_alternative_approach()
  ```
- **Files**: `Synapse/core/dynamic_task_planner.py`
- **Test**: Verify switches strategies after timeout

---

## 🔵 Priority 4: LOW - Nice to Have / Long-term

### 4.1 Activate Memory System ✅ FIXED
- **Issue**: No learning from failures
- **Impact**: Same mistakes repeated
- **Fix Applied**: 
  - Enhanced `store_with_outcome()` to automatically extract patterns to semantic memory for failures
  - Added automatic consolidation triggers when failures accumulate (≥3 failures)
  - Enhanced memory retrieval to prioritize semantic patterns before episodic memories
  - Added logging for pattern extraction and memory operations
  - Modified failure storage to use `outcome="failure"` which triggers automatic pattern extraction
- **Files Modified**: 
  - `Synapse/core/cortex.py` - Enhanced pattern extraction logging
  - `Synapse/core/conductor.py` - Added automatic consolidation triggers, enhanced memory retrieval
- **Test**: Verify memory updates and retrieval

### 4.2 Enable Q-Learning Logging ✅ FIXED
- **Issue**: No Q-table updates visible
- **Impact**: No strategy learning
- **Fix Applied**: 
  - Added comprehensive logging in `add_experience()` and `_update_q_value()` methods
  - Implemented strategy performance tracking with statistics (success rate, avg reward, avg Q-value)
  - Added failure penalty mechanism (1.5x penalty factor for rewards < 0.2)
  - Log Q-value updates with state, action, reward, TD error, and strategy name
  - Log strategy performance summaries every 10 executions
- **Files Modified**: 
  - `Synapse/core/q_learning.py` - Added logging and strategy tracking
- **Test**: Verify Q-values update correctly

### 4.3 Implement Shapley Credit Assignment
- **Issue**: Can't determine which agent/decision caused failure
- **Impact**: No blame attribution or learning
- **Fix**: Implement Shapley value calculation for credit assignment
- **Files**: New module for credit assignment
- **Test**: Verify correct attribution of failures

### 4.4 Add Chess Library Discovery
- **Issue**: ToolShed doesn't suggest chess libraries
- **Impact**: Missing existing solutions
- **Fix**: Add chess library discovery to ToolShed
  ```python
  if "chess" in task_description:
      suggest_library("chess-board-recognition")
      suggest_library("python-chess")
  ```
- **Files**: `Synapse/core/tool_shed.py`
- **Test**: Verify library suggestions appear

### 4.5 Fix Hardcoded FEN Metadata
- **Issue**: Assumes White to move, both sides can castle, no en passant
- **Impact**: Wrong FEN metadata
- **Fix**: Detect actual castling rights, en passant, and turn from image
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (line 142)
- **Test**: Verify correct FEN metadata

### 4.6 Add Error Handling for Font
- **Issue**: Hardcoded font path may not exist
- **Impact**: Runtime errors
- **Fix**: Check if font exists, provide fallback
  ```python
  font_paths = ["/fonts/noto.ttf", "/usr/share/fonts/...", ...]
  for path in font_paths:
      if os.path.exists(path):
          font = ImageFont.truetype(path, size)
          break
  else:
      font = ImageFont.load_default()
  ```
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (line 39)
- **Test**: Verify works without noto.ttf

### 4.7 Add Ambiguous Case Handling
- **Issue**: No tie-breaking when multiple pieces have similar MSE
- **Impact**: Unreliable detection
- **Fix**: 
  - Implement tie-breaking logic
  - Add confidence thresholds
  - Provide fallback strategies
- **Files**: `terminal-bench/tasks/chess-best-move/solution.sh` (lines 100-113)
- **Test**: Verify handles ambiguous cases

---

## ✅ Testing & Validation

### Test Case: Re-run chess-best-move Task

**Expected Behavior After Fixes**:
1. ✅ Architect searches "python chess board image to FEN" (< 30 seconds)
2. ✅ Finds template matching approach
3. ✅ SysOps installs Stockfish
4. ✅ CodeMaster implements template matching
5. ✅ Extracts FEN successfully (with coordinate fix)
6. ✅ Uses Stockfish to find best move
7. ✅ Writes move to /app/move.txt
8. ✅ Task completes in < 5 minutes

**Metrics to Track**:
- Time to First Web Search: Should be < 30 seconds
- Number of Strategy Changes: Should be 1-2 (not 0)
- Inter-Agent Consultations: Should be ≥ 1
- Memory Updates: Should log failure pattern
- Q-Table Updates: Should penalize failed strategies
- Task Completion Time: Should be < 5 minutes (vs 18+ timeout)

---

## 📊 Implementation Priority Summary

| Priority | Count | Focus Area |
|----------|-------|------------|
| P1: Critical | 4 | System blockers, coordinate bugs |
| P2: High | 6 | Core algorithm fixes, prompt improvements |
| P3: Medium | 6 | Robustness, learning systems |
| P4: Low | 7 | Long-term improvements |

**Total**: 23 fixes identified

---

## 🎯 Success Criteria

**Before**: 18-minute timeout, 0% success  
**After**: 3-5 minute completion, 95%+ success

**Key Improvements**:
1. ✅ Architect researches solutions (web search works)
2. ✅ Agent tries proven approach (template matching)
3. ✅ Auditor intervenes if stuck (circuit breaker)
4. ✅ Agents consult each other (DomainExpert helps)
5. ✅ System learns from failures (memory + Q-learning)
6. ✅ FEN extraction works correctly (coordinate fix)
7. ✅ Move calculation accurate (Stockfish + validation)

---

## 📝 Notes

- **Dependencies**: Some fixes depend on others (e.g., web search fix enables Architect research)
- **Testing**: Each fix should be tested independently before integration
- **Rollout**: Prioritize P1 fixes first, then P2, etc.
- **Monitoring**: Track metrics to validate improvements

---

**Document Version**: 1.0  
**Last Updated**: 2026-01-28  
**Status**: Ready for Implementation
