# ADR: Base Agent Separation of Concerns Refactoring

**Date:** 2026-01-30  
**Status:** Implemented  
**Context:** Architectural refactoring to improve separation of concerns in agent design

## Problem

The original `BaseSwarmAgent` violated separation of concerns by:

1. **Tight coupling to terminal tools** - Base class had terminal-specific logic
2. **Tool-type knowledge** - Base class knew about specific tool types (terminal vs browser vs search)
3. **Extensibility issues** - Adding new tool types required modifying base class
4. **Single Responsibility violation** - Base class handled both generic ReAct logic AND tool-specific setup

### Original Bad Design

```python
class BaseSwarmAgent:
    def _uses_terminal_tools(self) -> bool:
        # Base class checking for specific tool names!
        terminal_tool_names = {'initialize_terminal', 'send_terminal_command', ...}
        ...
    
    def forward(self, instruction, terminal_session=None, ...):
        uses_terminal = self._uses_terminal_tools()  # Bad!
        if uses_terminal:
            terminal_state = get_terminal_state()  # Terminal-specific!
        ...
```

## Solution: Template Method Pattern

### New Architecture

**BaseSwarmAgent**: Pure ReAct agent with callbacks/logging
- Generic ReAct execution
- Compression retry logic
- Callback management
- **Hook method**: `_prepare_for_execution(**kwargs) -> dict`

**Individual Agents**: Handle their own tool-specific setup
- Provide: name, signature, tools (already done)
- **New**: Initialize tool-specific state in `__init__`
- **New**: Create wrapped tools if needed
- **New**: Override `_prepare_for_execution()` to provide tool-specific context

### Implementation

#### 1. BaseSwarmAgent (Simplified)

```python
class BaseSwarmAgent(dspy.Module):
    def _prepare_for_execution(self, **kwargs) -> dict:
        """Hook for subclasses to prepare tool-specific state.
        Returns dict with any additional context for execution."""
        return {}
    
    def forward(self, instruction, conversation_history="", **kwargs):
        # Let subclasses prepare tool-specific state
        execution_context = self._prepare_for_execution(**kwargs)
        
        # Pass execution_context to generate
        result = self.generate(
            instruction=instruction,
            conversation_history=conversation_history,
            **execution_context  # Includes terminal_state for TerminalExecutor
        )
        return result
```

#### 2. TerminalExecutorAgent (Tool-Specific Setup)

```python
class TerminalExecutorAgent(BaseSwarmAgent):
    def __init__(self, max_iters: int = 50):
        # Initialize terminal session in __init__
        self._terminal_session_id = self.DEFAULT_SESSION
        result = initialize_terminal(session_id=self._terminal_session_id)
        set_terminal_session(self._terminal_session_id)
        
        # Pass tools to base agent
        super().__init__(max_iters=max_iters, tools=self._TERMINAL_TOOLS)
    
    def _prepare_for_execution(self, **kwargs) -> dict:
        """Prepare terminal state for execution."""
        terminal_state_result = get_terminal_state()
        terminal_state = terminal_state_result.get("output", "")
        return {"terminal_state": terminal_state}
```

#### 3. BrowserExecutorAgent & WebSearchAgent (No Extra Setup)

```python
class BrowserExecutorAgent(BaseSwarmAgent):
    # Just define tools - base agent handles the rest!
    TOOLS = [initialize_browser, navigate_to_url, click_element, ...]
    
    # No need to override _prepare_for_execution() - returns {}
```

#### 4. Signatures

```python
# TerminalExecutorSignature - HAS terminal_state field
class TerminalExecutorSignature(dspy.Signature):
    instruction: str = dspy.InputField(...)
    terminal_state: str = dspy.InputField(...)  # Provided by _prepare_for_execution
    conversation_history: str = dspy.InputField(...)

# BrowserExecutorSignature - NO terminal_state field
class BrowserExecutorSignature(dspy.Signature):
    instruction: str = dspy.InputField(...)
    conversation_history: str = dspy.InputField(...)  # No terminal_state!

# WebSearchSignature - NO terminal_state field  
class WebSearchSignature(dspy.Signature):
    instruction: str = dspy.InputField(...)
    conversation_history: str = dspy.InputField(...)  # No terminal_state!
```

## Benefits

### 1. **Separation of Concerns**
- Base agent: Generic ReAct logic only
- Individual agents: Tool-specific setup only

### 2. **Open/Closed Principle**
- Base agent is closed for modification
- Open for extension via `_prepare_for_execution()` hook

### 3. **Extensibility**
Adding new tool types (e.g., DatabaseExecutor):
```python
class DatabaseExecutorAgent(BaseSwarmAgent):
    def __init__(self):
        self.db_connection = connect_to_database()
        wrapped_tools = self._wrap_db_tools()
        super().__init__(tools=wrapped_tools)
    
    def _prepare_for_execution(self, **kwargs):
        return {"db_state": self.db_connection.status()}
```

### 4. **Single Responsibility**
- Each class has one reason to change
- Base agent: ReAct execution changes
- Terminal agent: Terminal tool changes

### 5. **Cleaner Signatures**
- Each agent has signature matching its needs
- No unnecessary fields for non-relevant agents

## Files Modified

### Core Refactoring
- `surface/src/surface/agents/base_agent.py` - Simplified, removed terminal-specific logic
- `surface/src/surface/agents/terminal_executor.py` - Added __init__ with session setup
- `surface/src/surface/agents/browser_executor.py` - No changes needed
- `surface/src/surface/agents/web_search.py` - No changes needed

### Signatures
- `surface/src/surface/signatures/terminal_executor_signature.py` - Kept terminal_state
- `surface/src/surface/signatures/browser_executor_signature.py` - Removed terminal_state
- `surface/src/surface/signatures/web_search_signature.py` - Removed terminal_state

### Wrappers
- `surface_synapse/agents/terminal_executor_agent.py` - Updated to not pass terminal_session
- `surface_synapse/agents/browser_executor_agent.py` - Updated to not pass terminal_session
- `surface_synapse/agents/web_search_agent.py` - Updated to not pass terminal_session

## Design Pattern: Template Method

This refactoring implements the **Template Method Pattern**:

```
BaseSwarmAgent.forward():
    1. Prepare execution (HOOK - overridable)
    2. Execute ReAct (TEMPLATE - fixed)
    3. Handle compression retry (TEMPLATE - fixed)
    4. Return result (TEMPLATE - fixed)
```

Subclasses can customize step 1 without changing steps 2-4.

## Migration Guide

### Old Way (Coupled)
```python
# Base agent knew about terminals
agent = TerminalExecutorAgent()
result = agent.forward(instruction, terminal_session=session)
```

### New Way (Decoupled)
```python
# Agent manages its own session
agent = TerminalExecutorAgent()  # Session initialized in __init__
result = agent.forward(instruction)  # No terminal_session needed!
```

## Testing

Run the solve_task script to verify:
```bash
./scripts/run_solve_task.sh "execute ls command"
./scripts/run_solve_task.sh "navigate to google.com"
./scripts/run_solve_task.sh "search for Python tutorials"
```

## Impact

✅ **Cleaner architecture** - Clear separation between generic and tool-specific logic  
✅ **Better extensibility** - Easy to add new tool types  
✅ **Reduced coupling** - Base agent independent of tool implementations  
✅ **Single responsibility** - Each class has one job  
✅ **Cleaner signatures** - Only relevant fields per agent  
✅ **No breaking changes** - Wrapper agents maintain backward compatibility

## Related ADRs

- `executor-agent-signature-fix.md` - Initial bug fix that revealed architectural issues
