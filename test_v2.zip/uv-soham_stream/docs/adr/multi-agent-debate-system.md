# ADR: Multi-Agent Debate System Design

**Date:** 2026-01-28  
**Status:** Proposed  
**Deciders:** A-Team

## Context

Users need a system where multiple agents can debate and discuss solutions to problems before execution. This is different from the current Synapse system which:
- Selects agents based on task requirements
- Executes tasks sequentially/parallelly
- Validates outputs post-execution

The debate system should enable:
- **Pre-execution deliberation**: Agents discuss approaches before committing to a solution
- **Perspective diversity**: Different agents bring different viewpoints
- **Consensus building**: Agents converge on a solution through structured debate
- **Transparency**: Users can see the reasoning process

## Decision

Design a **Debate Orchestrator** system that:
1. Accepts user-defined agents with debate personas
2. Facilitates structured multi-round debates
3. Tracks arguments, counter-arguments, and consensus
4. Produces a final solution based on debate outcomes

## Design Overview

### Core Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Debate Orchestrator                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Debate Round │  │ Consensus    │  │ Solution     │     │
│  │ Manager      │  │ Builder      │  │ Synthesizer  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
┌─────────────────────────────────────────────────────────────┐
│              Agent Communication Layer                       │
│  (SmartAgentSlack for message routing)                      │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   Agent 1    │  │   Agent 2    │  │   Agent N    │
│  (Persona)   │  │  (Persona)   │  │  (Persona)   │
└──────────────┘  └──────────────┘  └──────────────┘
```

### 1. Agent Definition

**DebateAgentConfig** extends `AgentConfig` with:
- `persona`: Debate personality (e.g., "conservative", "innovative", "pragmatic", "theoretical")
- `debate_role`: Role in debate (e.g., "advocate", "skeptic", "synthesizer", "validator")
- `argumentation_style`: How agent argues ("evidence-based", "principle-based", "practical")
- `consensus_threshold`: When agent agrees (0.0-1.0)
- `max_rounds`: Maximum rounds agent will participate

### 2. Debate Structure

**DebateRound**:
- Round number
- Topic/Question for this round
- Agent contributions (who said what)
- Argument relationships (supports, contradicts, refines)
- Round conclusion (if any)

**DebateFlow**:
- **Opening Statements**: Each agent presents initial position
- **Rebuttal Phase**: Agents respond to others' arguments
- **Deep Dive**: Focused discussion on key points
- **Synthesis**: Agents attempt to reconcile differences
- **Consensus Check**: Determine if agreement reached

### 3. Argument Tracking

**Argument Graph**:
- Nodes: Individual arguments/statements
- Edges: Relationships (supports, contradicts, refines, questions)
- Metadata: Agent, round, confidence, evidence

**Consensus Metrics**:
- Agreement score (0.0-1.0) per agent pair
- Overall consensus level
- Remaining disagreements
- Key decision points

### 4. Debate Orchestrator

**Responsibilities**:
1. **Round Management**: 
   - Determine debate flow (fixed vs adaptive)
   - Select which agents speak in each round
   - Manage turn-taking and time limits

2. **Argument Analysis**:
   - Extract key claims from agent responses
   - Identify contradictions and agreements
   - Track evidence and reasoning chains

3. **Consensus Detection**:
   - Monitor agreement levels
   - Detect when debate converges
   - Identify irreconcilable differences

4. **Solution Synthesis**:
   - Combine agreed-upon elements
   - Highlight areas of disagreement
   - Produce final recommendation

### 5. Communication Protocol

**Message Types**:
- `OPENING_STATEMENT`: Initial position
- `REBUTTAL`: Response to another agent's argument
- `EVIDENCE`: Supporting data/facts
- `QUESTION`: Request for clarification
- `CONCESSION`: Agreement with another agent
- `SYNTHESIS`: Attempt to reconcile views

**Message Format**:
```python
{
    "type": "REBUTTAL",
    "from_agent": "Agent1",
    "to_agent": "Agent2",
    "round": 2,
    "content": "...",
    "references": ["argument_id_123"],  # What it responds to
    "confidence": 0.8,
    "evidence": [...]
}
```

### 6. Debate Strategies

**Fixed Rounds**:
- Predefined number of rounds
- Each agent speaks once per round
- Structured progression through phases

**Adaptive Rounds**:
- Continue until consensus or max rounds
- Skip agents who have nothing new to add
- Focus rounds on unresolved disagreements

**Consensus-Driven**:
- Stop early if consensus reached
- Extend rounds if progress being made
- Escalate if deadlocked

### 7. Integration with Synapse

**Pre-Execution Debate**:
- Run debate before task execution
- Use debate outcome to inform Architect
- Pass consensus solution to Conductor

**Post-Execution Review**:
- Debate after execution to validate results
- Compare actual outcomes to predicted outcomes
- Learn from discrepancies

**Standalone Mode**:
- Pure debate without execution
- Useful for planning and strategy
- Output: structured recommendation document

## Configuration

```yaml
debate_system:
  enable: true
  mode: "pre_execution"  # pre_execution, post_execution, standalone
  
  orchestrator:
    max_rounds: 10
    round_timeout: 300  # seconds
    consensus_threshold: 0.7
    adaptive_rounds: true
    
  agents:
    - name: "ConservativeAgent"
      persona: "conservative"
      role: "skeptic"
      argumentation_style: "risk-focused"
      consensus_threshold: 0.8
      
    - name: "InnovativeAgent"
      persona: "innovative"
      role: "advocate"
      argumentation_style: "possibility-focused"
      consensus_threshold: 0.6
      
  flow:
    phases:
      - name: "opening"
        rounds: 1
        all_agents: true
        
      - name: "rebuttal"
        rounds: 3
        adaptive: true
        
      - name: "synthesis"
        rounds: 2
        focus_on: "disagreements"
        
      - name: "consensus"
        rounds: 1
        check_agreement: true
```

## Data Structures

### DebateState
```python
@dataclass
class DebateState:
    problem: str
    agents: List[DebateAgentConfig]
    rounds: List[DebateRound]
    argument_graph: ArgumentGraph
    consensus_score: float
    status: DebateStatus  # IN_PROGRESS, CONSENSUS, DEADLOCKED, TIMEOUT
    final_solution: Optional[Solution]
```

### DebateRound
```python
@dataclass
class DebateRound:
    round_number: int
    phase: str
    contributions: List[AgentContribution]
    argument_relationships: List[ArgumentEdge]
    conclusion: Optional[str]
    timestamp: datetime
```

### AgentContribution
```python
@dataclass
class AgentContribution:
    agent_name: str
    message_type: MessageType
    content: str
    references: List[str]  # Argument IDs this responds to
    confidence: float
    evidence: List[Evidence]
    timestamp: datetime
```

### Solution
```python
@dataclass
class Solution:
    agreed_elements: List[str]
    disagreed_elements: List[str]
    recommendation: str
    confidence: float
    agent_agreement: Dict[str, float]  # agent -> agreement score
    reasoning: str
```

## Workflow

### 1. Initialization
```
User defines problem
User defines agents (or uses defaults)
Debate Orchestrator initializes:
  - Creates DebateState
  - Registers agents with SmartAgentSlack
  - Sets up argument graph
```

### 2. Opening Round
```
For each agent:
  - Present problem
  - Agent generates opening statement
  - Extract key arguments
  - Add to argument graph
```

### 3. Rebuttal Rounds
```
While not consensus and rounds < max:
  - Identify key disagreements from argument graph
  - Select agents to respond (those with opposing views)
  - Agents generate rebuttals
  - Update argument graph
  - Recalculate consensus score
```

### 4. Synthesis Round
```
- Identify common ground
- Highlight remaining disagreements
- Agents attempt synthesis
- Check if consensus improved
```

### 5. Consensus Check
```
- Calculate final consensus score
- If >= threshold:
    → Generate solution from agreed elements
- Else:
    → Generate solution highlighting disagreements
    → Optionally continue debate or escalate
```

### 6. Solution Generation
```
- Extract all agreed-upon elements
- Synthesize into coherent solution
- Document disagreements
- Produce final recommendation
```

## Integration Points

### With Synapse Conductor
- **Input**: Problem statement
- **Output**: Debate solution → Architect plan → Execution
- **Feedback Loop**: Post-execution debate validates results

### With SmartAgentSlack
- Use existing message routing
- Extend with debate-specific message types
- Track argument relationships in message metadata

### With Memory System
- Store debate outcomes in memory
- Learn from successful debate patterns
- Retrieve similar past debates for context

## Benefits

1. **Better Solutions**: Multiple perspectives lead to more robust solutions
2. **Transparency**: Users see reasoning process
3. **Risk Mitigation**: Skeptical agents catch potential issues
4. **Learning**: System learns from debate patterns
5. **Flexibility**: Works standalone or integrated with execution

## Trade-offs

### Pros
- More thorough analysis before execution
- Reduces blind spots
- Builds consensus naturally

### Cons
- Additional latency (debate time)
- Higher token costs (multiple agent interactions)
- May not converge (deadlock scenarios)

## Future Enhancements

1. **Debate Templates**: Pre-defined debate structures for common problem types
2. **Expert Agents**: Specialized agents for specific domains
3. **Debate Learning**: Learn optimal debate strategies from past debates
4. **Visualization**: UI to visualize argument graph and debate flow
5. **Human-in-the-Loop**: Allow human to intervene or guide debate

## Open Questions

1. How to handle agents that consistently disagree?
2. Should debate be mandatory or optional per task?
3. How to balance debate thoroughness vs speed?
4. Can debate outcomes be cached for similar problems?
5. How to handle agents with conflicting personas?

## References

- Synapse A-Team review system (existing pattern)
- SmartAgentSlack communication layer
- Argumentation theory and multi-agent systems research
- Consensus algorithms (Byzantine fault tolerance)
