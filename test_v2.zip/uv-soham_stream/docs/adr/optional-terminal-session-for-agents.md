# Optional Terminal Session for Non-Terminal Agents

**Status:** Implemented  
**Date:** 2026-01-29  
**Context:** Surface Swarm Agents Architecture

## Decision

Modified `BaseSwarmAgent.forward()` and `BaseSwarmAgent.astream()` to make terminal session optional for agents that don't use terminal tools (like BrowserExecutor).

## Problem

When running the BrowserExecutor example:

```python
agent = BrowserExecutorAgent(max_iters=50)
result = agent.forward(
    instruction="Navigate to example.com...",
    terminal_session=None,  # BrowserExecutor doesn't need this
    conversation_history=""
)
```

**Error received:**
```
ValueError: Terminal session must be provided.
```

**Why this is wrong:**
- BrowserExecutor only uses browser automation tools (selenium)
- It has NO terminal tools in its TOOLS list
- Requiring terminal session makes no sense for browser-only agent
- Forces unnecessary dependency on terminal infrastructure

## Root Cause

In `BaseSwarmAgent.forward()`:

```python
def forward(self, instruction, terminal_session=None, ...):
    if terminal_session is not None:
        self.set_session(terminal_session)
    
    if self.terminal_session is None:
        raise ValueError("Terminal session must be provided.")  # ❌ Always required!
    
    terminal_state = get_terminal_state()  # ❌ Always called!
```

**Problems:**
1. ❌ **Always requires** terminal session regardless of agent type
2. ❌ **Always calls** `get_terminal_state()` even if not needed
3. ❌ Prevents creation of specialized non-terminal agents
4. ❌ Tight coupling between agents and terminal infrastructure

## Solution

Added `_uses_terminal_tools()` method to detect if agent needs terminal:

```python
def _uses_terminal_tools(self) -> bool:
    """Check if this agent uses terminal tools."""
    terminal_tool_names = {
        'send_terminal_command', 
        'get_terminal_state', 
        'get_incremental_output'
    }
    agent_tool_names = {
        tool.__name__ 
        for tool in self._tools_list 
        if hasattr(tool, '__name__')
    }
    return bool(terminal_tool_names & agent_tool_names)
```

### Updated `forward()` Method

```python
def forward(self, instruction, terminal_session=None, ...):
    # Only require terminal session if agent uses terminal tools
    uses_terminal = self._uses_terminal_tools()
    
    if terminal_session is not None:
        self.set_session(terminal_session)
    
    # ✅ Only check if agent actually needs terminal
    if uses_terminal and self.terminal_session is None:
        raise ValueError(
            f"Terminal session must be provided for {self.AGENT_NAME} "
            "(uses terminal tools)."
        )
    
    # ✅ Only get terminal state if needed
    if uses_terminal and self.terminal_session is not None:
        terminal_state_result = get_terminal_state()
        terminal_state = terminal_state_result.get("output", "")
    else:
        terminal_state = ""  # Empty for non-terminal agents
```

### Updated `astream()` Method

Same logic applied to async streaming version.

## Implementation Details

### Detection Logic

**Terminal tools checked:**
- `send_terminal_command`
- `get_terminal_state`
- `get_incremental_output`

**How it works:**
1. Get set of terminal tool names
2. Get set of agent's tool names
3. Check intersection (set & operator)
4. Returns `True` if any terminal tools present

### Agent Classification

| Agent | Uses Terminal | Requires Session |
|-------|--------------|------------------|
| CodeMaster | ✅ Yes | ✅ Required |
| DataMind | ✅ Yes | ✅ Required |
| SysOps | ✅ Yes | ✅ Required |
| SecureSentry | ✅ Yes | ✅ Required |
| ScienceCore | ✅ Yes | ✅ Required |
| DomainExpert | ✅ Yes | ✅ Required |
| **BrowserExecutor** | ❌ **No** | ❌ **Optional** |

### Validation

```bash
$ poetry run python -c "
from surface.agents.browser_executor import BrowserExecutorAgent
agent = BrowserExecutorAgent()
print('Uses terminal:', agent._uses_terminal_tools())
"

✅ Uses terminal: False
```

## Benefits

### 1. Separation of Concerns
- Agents only depend on tools they actually use
- No forced coupling to terminal infrastructure
- Clear intent through tool declaration

### 2. Flexibility
- Easy to create specialized agents
- Browser-only agents don't need terminal setup
- Future agents can use any tool combination

### 3. Better Error Messages
```python
# Before:
ValueError: Terminal session must be provided.

# After (for terminal agents):
ValueError: Terminal session must be provided for CodeMaster (uses terminal tools).
```

### 4. Performance
- No unnecessary `get_terminal_state()` calls for non-terminal agents
- Reduced overhead for browser-only operations

### 5. Correctness
- Agents correctly represent their dependencies
- Type safety through runtime checking
- Self-documenting through tool inspection

## Backward Compatibility

**Existing agents:** ✅ **No changes required**
- All existing agents use terminal tools
- Detection automatically identifies them
- Behavior identical to before

**API:** ✅ **No breaking changes**
- `terminal_session` parameter still exists
- Still optional in signature
- Only enforcement logic changed

## Usage Examples

### BrowserExecutor (No Terminal Needed)

```python
from surface.agents import BrowserExecutorAgent

agent = BrowserExecutorAgent(max_iters=50)

# ✅ Works! No terminal session needed
result = agent.forward(
    instruction="Navigate to example.com and extract title",
    terminal_session=None,  # OK for browser-only agent
    conversation_history=""
)
```

### CodeMaster (Terminal Required)

```python
from surface.agents import CodeMasterAgent

agent = CodeMasterAgent(max_iters=50)

# ❌ Raises error - terminal required
result = agent.forward(
    instruction="Run pytest tests",
    terminal_session=None,  # ERROR!
    conversation_history=""
)
# ValueError: Terminal session must be provided for CodeMaster (uses terminal tools).

# ✅ Correct usage
result = agent.forward(
    instruction="Run pytest tests",
    terminal_session=my_session,  # OK
    conversation_history=""
)
```

## Future Possibilities

This change enables:

### 1. Mixed-Capability Agents
```python
class WebScraperAgent(BaseSwarmAgent):
    TOOLS = [
        # Browser tools only
        initialize_browser,
        navigate_to_url,
        get_element_text,
        close_browser
    ]
    # Automatically detected as non-terminal agent
```

### 2. API-Only Agents
```python
class APIClientAgent(BaseSwarmAgent):
    TOOLS = [
        # Custom API tools
        make_api_request,
        parse_json_response,
        handle_auth
    ]
    # No terminal, no browser
```

### 3. Database Agents
```python
class DatabaseAgent(BaseSwarmAgent):
    TOOLS = [
        # Database tools
        execute_query,
        get_schema,
        optimize_query
    ]
    # Pure database operations
```

## Testing

### Test Cases

1. ✅ BrowserExecutor with `terminal_session=None` succeeds
2. ✅ BrowserExecutor detection returns `False`
3. ✅ CodeMaster with `terminal_session=None` raises error
4. ✅ CodeMaster detection returns `True`
5. ✅ Terminal state only fetched when needed
6. ✅ Error messages include agent name

### Validation Commands

```bash
# Test BrowserExecutor doesn't need terminal
poetry run python surface/example_browser_simple.py

# Test existing agents still work
poetry run python surface/example_code_master.py
```

## Consequences

**Positive:**
- ✅ More flexible agent architecture
- ✅ Better separation of concerns
- ✅ Clearer error messages
- ✅ Performance improvement (no unnecessary calls)
- ✅ Enables specialized agents

**Trade-offs:**
- Additional runtime check (`_uses_terminal_tools()`)
- Slightly more complex logic in base agent
- Need to maintain terminal tool name list

**Risks Mitigated:**
- ✅ Backward compatible (no breaking changes)
- ✅ Tested with existing agents
- ✅ Clear documentation of behavior
- ✅ Helpful error messages guide users

## Related

- `agent-tool-assignment-refactoring.md` - Tool assignment architecture
- `browser-automation-tools.md` - Browser tools implementation
- `browser-executor-examples.md` - Example implementations

## Migration Guide

**For new agents:**

```python
class MyAgent(BaseSwarmAgent):
    AGENT_NAME = "MyAgent"
    SIGNATURE_CLASS = MySignature
    
    # Just declare your tools
    TOOLS = [
        # Your tools here
        # Terminal session requirement auto-detected
    ]
```

**For users:**

```python
# If agent uses terminal tools (auto-detected):
result = agent.forward(
    instruction="...",
    terminal_session=session  # Required
)

# If agent doesn't use terminal tools:
result = agent.forward(
    instruction="...",
    terminal_session=None  # OK!
)
```

No migration needed - everything just works! ✅
