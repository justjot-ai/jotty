# Fix ErrorSolutionExtractor Method Name, Inspector Timeout, Terminal Initialization, and MultiRoundValidator Issues

**Status**: Implemented  
**Date**: 2026-01-30  
**Decision**: Fixed four critical bugs causing system failures

## Context

System was experiencing fatal errors during actor execution:

1. **AttributeError**: `'ErrorSolutionExtractor' object has no attribute 'extract_solution'`
   - Location: `Synapse/core/conductor.py:6470`
   - Impact: Fatal error on retry logic, preventing error recovery

2. **Inspector Timeout**: BrowserExecutor auditor was timing out after 180s
   - Root cause: Event loop detection issue in `surface_synapse/integration.py:895`
   - Symptom: `RuntimeError: no running event loop` when called from `asyncio.to_thread()`

3. **TypeError**: `initialize_terminal() got an unexpected keyword argument 'session_id'`
   - Location: `surface/src/surface/agents/terminal_executor.py:47`
   - Impact: TerminalExecutor agent fails to initialize during setup

4. **AttributeError**: `'MultiRoundValidator' object has no attribute '_vote_consistency'`
   - Location: `Synapse/core/inspector.py:1415`
   - Impact: Actor validation fails after auditor completes validation

## Issues

### Issue 1: Wrong Method Name in Conductor
```python
# WRONG (line 6470)
solution = await error_extractor.extract_solution(
    error_message=error_str,
    task_description=task.description,
    actor_name=actor_config.name,
    ...
)

# CORRECT (actual method signature in error_solution_extractor.py:55)
def extract_solutions(self, error: str, search_results: str, context: dict) -> list:
```

**Problems:**
- Method name is `extract_solutions()` (plural), not `extract_solution()` (singular)
- Parameters don't match actual signature (missing `search_results`, wrong param names)
- This code was redundant - proper error research already exists at line 6899

### Issue 2: Event Loop Detection in Integration
```python
# PROBLEM (line 895)
loop = asyncio.get_running_loop()  # Raises RuntimeError in thread pool
```

When inspector calls DSPy agent via `asyncio.to_thread()`, it runs in a thread pool thread without an event loop. If the agent's tools call `solve_task_sync()`, the event loop check fails.

## Decision

### Fix 1: Terminal Initialization Parameter Name
**File**: `surface/src/surface/agents/terminal_executor.py:47`

**Before:**
```python
result = initialize_terminal(session_id=self._terminal_session_id)
```

**After:**
```python
result = initialize_terminal(session_name=self._terminal_session_id)
```

**Rationale:**
- The function signature uses `session_name` not `session_id`
- Parameter name mismatch caused immediate failure during agent initialization
- Function definition: `terminal_tools.py:38` uses `session_name: Optional[str] = None`

### Fix 2: Remove Redundant/Incorrect Error Extraction
**File**: `Synapse/core/conductor.py:6461-6472`

**Before:**
```python
except Exception as e:
    last_error = e
    error_str = str(e)
    logger.warning(f"❌ {actor_config.name} failed (attempt {attempt + 1}): {error_str[:200]}")
    
    # Use ErrorSolutionExtractor to get solutions
    from Synapse.core.error_solution_extractor import ErrorSolutionExtractor
    error_extractor = ErrorSolutionExtractor()
    
    solution = await error_extractor.extract_solution(...)  # ❌ WRONG METHOD
    
    error_context_accumulated.append({...})
```

**After:**
```python
except Exception as e:
    last_error = e
    error_str = str(e)
    logger.warning(f"❌ {actor_config.name} failed (attempt {attempt + 1}): {error_str[:200]}")
    
    # Record error for retry (auto error research handled in _execute_actor)
    error_context_accumulated.append({
        'attempt': attempt + 1,
        'error': error_str,
        'solution': 'Will retry with error context',
        'should_retry': True
    })
```

**Rationale:**
- Removed incorrect `extract_solution()` call (doesn't exist)
- Proper error research with `extract_solutions()` already exists at line 6899 in `_execute_actor()`
- Avoids duplicate/conflicting error handling logic

### Fix 3: Initialize Missing Attribute in MultiRoundValidator
**File**: `Synapse/core/inspector.py:1366-1368`

**Before:**
```python
def __init__(self, agents: List[InspectorAgent], config: SynapseConfig):
    self.agents = agents
    self.config = config
```

**After:**
```python
def __init__(self, agents: List[InspectorAgent], config: SynapseConfig):
    self.agents = agents
    self.config = config
    # Initialize vote consistency checker (used in validate())
    self._vote_consistency = dspy.ChainOfThought(ReasoningVoteConsistencySignature)
```

**Rationale:**
- The `validate()` method at line 1415 uses `self._vote_consistency` but it wasn't initialized
- `InspectorAgent` has this same attribute (line 304) and `MultiRoundValidator` needs it too
- Used for detecting reasoning-vote contradictions and correcting them

### Fix 4: Improve Event Loop Detection
**File**: `surface_synapse/integration.py:893-925`

**Change:**
```python
# Enhanced error message matching
except RuntimeError as e:
    # No running loop in THIS thread (could be called from thread pool)
    # Safe to create and run in new loop
    if "no running event loop" in str(e).lower() or "no running loop" in str(e).lower():
        logger.info("📌 Running directly (no async context in current thread)")
        try:
            return _run_in_new_loop()
        except RuntimeError as inner_e:
            if "shutdown" in str(inner_e).lower() or "interpreter" in str(inner_e).lower():
                logger.warning(f"⚠️ Shutdown during task execution: {inner_e}")
                return None
            raise
    raise
```

**Rationale:**
- Better error message matching for various RuntimeError formats
- Clarified logging: "no async context in current thread" (not "no async context")
- Handles being called from `asyncio.to_thread()` thread pool correctly

## Consequences

### Positive
- ✅ TerminalExecutor agent now initializes correctly
- ✅ MultiRoundValidator can now perform vote consistency checks
- ✅ Eliminates `AttributeError` on actor retry logic
- ✅ Inspector agents no longer timeout from event loop issues
- ✅ Cleaner error handling (removed duplicate logic)
- ✅ Proper error research still happens (line 6899 with web search + `extract_solutions()`)

### Negative
- None - these were pure bug fixes

## Verification

**Test Case 1: Run with BrowserExecutor**
```bash
python surface_synapse/example_solve_task.py \
  "Open google.com and search for 'python asyncio'"
```

**Expected:**
- No `AttributeError` on retry
- Inspector completes within timeout
- Proper error research if failures occur

**Test Case 2: Check Correct Method Usage**
```bash
# Verify only correct usage remains
grep -n "extract_solutions" Synapse/core/conductor.py
# Should show line 6899 with correct parameters
```

## Related

- **Terminal tools definition**: `surface/src/surface/tools/terminal_tools.py:38`
- **Vote consistency signature**: `Synapse/core/inspector.py:123` (`ReasoningVoteConsistencySignature`)
- **InspectorAgent usage**: `Synapse/core/inspector.py:304` (same attribute initialization)
- **Correct usage reference**: `Synapse/core/conductor.py:6899` (auto error research with web search)
- **Method definition**: `Synapse/core/error_solution_extractor.py:55`
- **Inspector implementation**: `Synapse/core/inspector.py:845` (`asyncio.to_thread()` usage)

## Notes

The inspector uses `asyncio.to_thread()` to run DSPy agents (which are synchronous) from async context. This is correct and should be preserved. The fix ensures that if tools within the agent call `solve_task_sync()`, they handle the thread pool context properly.
