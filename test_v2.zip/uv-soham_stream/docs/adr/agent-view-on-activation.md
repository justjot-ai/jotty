# ADR: Show Agent View Only on Activation

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Dynamic Agent View Display

## Decision

Show agent views (especially BrowserExecutor) only when the agent is activated by the backend, and return to empty state when deactivated.

## Problem

Previously, the browser view was shown by default even when no agent was active. This was confusing because:
- Browser view appeared before BrowserExecutor was activated
- Users couldn't tell when an agent actually started working
- Empty browser canvas was shown unnecessarily

## Solution

### Changes Made

**File**: `electron-app/src/renderer/js/agent-view-manager.js`

#### 1. Initialize with Empty State

```javascript
initialize() {
  // Create all agent views (hidden by default)
  this.createView('BrowserExecutor', 'browser', '🌐');
  this.createView('TerminalExecutor', 'terminal', '⚡');
  this.createView('WebSearchAgent', 'search', '🔍');
  this.createView('PlannerAgent', 'planner', '🧠');

  // DON'T show any view by default - wait for agent activation
  this.showEmptyState();
}
```

#### 2. Added Empty State Method

```javascript
showEmptyState() {
  console.log('Showing empty state - no agent active');
  
  // Hide all views
  this.views.forEach((view, name) => {
    view.element.style.display = 'none';
    view.element.style.opacity = '0';
  });
  
  this.activeAgentName = null;
  
  // Container shows empty space (background visible)
  this.container.style.display = 'flex';
  this.container.style.alignItems = 'center';
  this.container.style.justifyContent = 'center';
}
```

#### 3. Handle Deactivation

```javascript
handleAgentDeactivated(event) {
  const { agent } = event;
  console.log(`Agent deactivated: ${agent}`);
  
  // If this was the active agent, return to empty state
  if (this.activeAgentName === agent) {
    console.log(`Active agent ${agent} deactivated - returning to empty state`);
    this.showEmptyState();
  }
}
```

## User Experience Flow

### Before Agent Activation
```
┌─────────────────────────────────────┐
│                                     │
│                                     │
│         (empty space)               │
│                                     │
│                                     │
└─────────────────────────────────────┘
```

### After Agent Activation (e.g., BrowserExecutor)
```
┌─────────────────────────────────────┐
│  🌐 Browser View                    │
│  ┌───────────────────────────────┐  │
│  │                               │  │
│  │   Chrome Browser Content      │  │
│  │   (CDP Screenshot Stream)     │  │
│  │                               │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
```

### After Agent Deactivation
```
┌─────────────────────────────────────┐
│                                     │
│                                     │
│         (empty space)               │
│                                     │
│                                     │
└─────────────────────────────────────┘
```

## WebSocket Events

### Agent Activated
```json
{
  "type": "agent_activated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-02T00:39:02.190771"
}
```

**Action**: Show browser view in center panel

### Agent Deactivated
```json
{
  "type": "agent_deactivated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-02T00:42:15.543210"
}
```

**Action**: Hide browser view, return to empty state

## Debug Output

### Console Logs

**On Initialization:**
```
✅ AgentViewManager initialized - waiting for agent activation
Showing empty state - no agent active
```

**On Agent Activation:**
```
🔍 [DEBUG] WebSocket message received: {
  "type": "agent_activated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-02T00:39:02.190771"
}
🔍 [DEBUG] Agent activated: BrowserExecutor
Switching to agent: BrowserExecutor
```

**On Agent Deactivation:**
```
🔍 [DEBUG] WebSocket message received: {
  "type": "agent_deactivated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-02T00:42:15.543210"
}
🔍 [DEBUG] Agent deactivated: BrowserExecutor
Active agent BrowserExecutor deactivated - returning to empty state
Showing empty state - no agent active
```

## Benefits

1. **Clear Visual Feedback**: Users can see exactly when an agent starts working
2. **No Confusion**: Empty state clearly indicates "waiting for agent"
3. **Clean UI**: No unnecessary placeholder content
4. **Responsive**: Immediate visual feedback on agent activation/deactivation
5. **Scalable**: Works for all agent types (Browser, Terminal, Search, Planner)

## Agent Types Supported

- **BrowserExecutor** (🌐): Shows CDP-based Chrome embedding
- **TerminalExecutor** (⚡): Shows xterm.js terminal
- **WebSearchAgent** (🔍): Shows search results
- **PlannerAgent** (🧠): Shows execution plan

## Implementation Details

### State Management
- `activeAgentName`: Tracks currently active agent (null when empty)
- `views`: Map of all agent views (created but hidden)
- `container`: Center workspace container

### Transitions
- **Empty → Agent**: Fade in agent view (50ms delay)
- **Agent → Empty**: Immediate hide, return to empty state
- **Agent → Agent**: Cross-fade between agents

### CSS
- Empty state uses flexbox centering
- Agent views use `display: flex` when active
- Smooth opacity transitions (0.3s)

## Testing

To test:
1. Start backend and Electron app
2. Enter a task that uses BrowserExecutor
3. Watch center panel:
   - Starts empty
   - Shows browser when `agent_activated` received
   - Returns to empty when `agent_deactivated` received

## Related

- `agent-embedding-complete.md` - CDP browser embedding
- `electron-debug-mode-logging.md` - Debug logging
- `single-active-agent-view.md` - Single agent view architecture

## Future Enhancements

- Smooth transitions between agents
- Agent queue indicator (show next agent waiting)
- Mini-preview of inactive agents
- Agent history/timeline view
