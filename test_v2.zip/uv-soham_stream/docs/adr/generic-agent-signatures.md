# ADR: Generic Agent Signatures (No Hardcoded Actors)

**Status:** ✅ IMPLEMENTED  
**Date:** 2026-01-30  
**Type:** Architecture Improvement  

---

## Context

The TaskBreakdownAgent and DAG optimization signatures contained hardcoded actor names:
- "BrowserExecutor"
- "TerminalExecutor"
- "WebSearchAgent"  
- "Summarizer" (which doesn't even exist!)

### Problems:

1. **Not Generic:** System hardcoded to 3 specific agents
2. **Misleading Examples:** Signatures mentioned "Summarizer" which doesn't exist
3. **Not Extensible:** Adding new agents requires updating signatures
4. **LLM Confusion:** TaskBreakdownAgent created tasks for non-existent actors

### Evidence from Logs:

```
❌ Actor assignment mismatch: task_5 "Summarizer: Summarize synapse group conversations" 
   is assigned to TerminalExecutor instead of Summarizer actor
```

The LLM followed the signature examples and created a "Summarizer" task, but this actor doesn't exist!

---

## Decision

**Make all signatures GENERIC** - remove hardcoded actor names and use generic placeholders.

### Changes Made:

#### 1. `task_breakdown_signatures.py`

**BEFORE:**
```python
"The plan references actors like BrowserExecutor, Summarizer - these ALREADY EXIST"
"1. If plan says 'BrowserExecutor does X' → create ONE task 'BrowserExecutor: X'"
"2. If plan says 'Summarizer does Y' → create ONE task 'Summarizer: Y'"
"TASK: Summarizer: Summarize conversations | TYPE: implementation"
```

**AFTER:**
```python
"The plan references actors by name - these ALREADY EXIST in the system"
"1. If plan says 'ActorX does Y' → create ONE task 'ActorX: Y'"
"2. Use actor names exactly as mentioned in the plan"
"TASK: ActorName: Complete workflow step | TYPE: implementation"
```

#### 2. `dag_optimization_signatures.py`

**BEFORE:**
```python
"CONTEXT: Available capabilities are EXISTING actors (BrowserExecutor, Summarizer, etc.)."
"KEEP tasks that: Use existing actors/capabilities (e.g., 'BrowserExecutor: Open URL', 'Summarizer: Summarize text')"
"KEEP: task_id_5 | REASON: Uses existing BrowserExecutor capability"
```

**AFTER:**
```python
"CONTEXT: Available capabilities are EXISTING actors in the system."
"KEEP tasks that: Use existing actors/capabilities to complete workflow steps"
"KEEP: task_id_5 | REASON: Uses existing actor capability for workflow step"
```

---

## Benefits

### 1. Generic System
- ✅ Works with ANY set of actors
- ✅ No hardcoded assumptions
- ✅ Easy to add new agents

### 2. No False Actors
- ✅ Removed "Summarizer" references
- ✅ LLM won't create tasks for non-existent actors
- ✅ Validation errors eliminated

### 3. Extensible
- ✅ Add new agents without changing signatures
- ✅ System adapts to available actors automatically
- ✅ Future-proof architecture

### 4. Clearer Intent
- ✅ "ActorX" and "ActorName" are clearly placeholders
- ✅ No confusion about which actors exist
- ✅ Examples are generic

---

## How It Works Now

### Actor Discovery (Runtime):

```
Goal → TaskBreakdownAgent
  ↓
TaskBreakdownAgent sees: "Use existing actors in the system"
  ↓
LLM infers: Must use generic approach, check what actors are mentioned in plan
  ↓
Creates tasks: "BrowserExecutor: Navigate", "TerminalExecutor: Execute"
  ↓
TodoCreatorAgent validates against ACTUAL available actors
  ↓
Assignments: task_1 → BrowserExecutor, task_2 → TerminalExecutor ✅
```

No hardcoded assumptions!

---

## Bug Fix: _extract_task_features()

### Error:
```
❌ Error: EnhancedAgenticAgentSelector._extract_task_features() takes 2 positional arguments but 3 were given
```

### Root Cause:
Line 3397 in `conductor.py` was calling:
```python
task_features = self.enhanced_agent_selector._extract_task_features(
    task.description,  # ❌ Extra argument
    task.goal          # ❌ Extra argument
)
```

But the method signature is:
```python
def _extract_task_features(self, task: 'SubtaskState') -> str:
    # Only accepts 'task', not description/goal separately
```

### Fix:
```python
task_features = self.enhanced_agent_selector._extract_task_features(task)  # ✅
```

---

## Testing

### Test Case: "Calculate 3+4"

**Before:**
```
❌ Creates "Summarizer: Calculate result" task
❌ Validation error: Summarizer actor doesn't exist
❌ Falls back to TerminalExecutor
```

**After:**
```
✅ Creates "TerminalExecutor: Calculate 3+4" task
✅ Validation passes (actor exists)
✅ Task executes successfully
```

---

## Files Modified

1. **`Synapse/signatures/task_breakdown_signatures.py`**
   - Removed: "BrowserExecutor", "Summarizer", "TerminalExecutor", "WebSearchAgent" mentions
   - Replaced with: "ActorX", "ActorName" (generic placeholders)
   - 4 replacements

2. **`Synapse/signatures/dag_optimization_signatures.py`**
   - Removed: Specific actor examples
   - Made: Generic capability references
   - 3 replacements

3. **`Synapse/core/conductor.py`**
   - Fixed: `_extract_task_features()` call (line 3397)
   - Removed: Extra arguments
   - 1 fix

---

## Related ADRs

- `capabilities-flow-trace.md` - How capabilities are discovered
- `synapse-new-integration-complete.md` - Multi-agent TODO flow

---

## Approval

**Decision:** APPROVED & IMPLEMENTED  
**Rationale:** Makes system generic and extensible, fixes false actor references  
**Risk Level:** NONE (removes invalid hardcoding)  
**Rollback Plan:** Git revert (though unnecessary - improvement only)  

---

## Summary

Removed all hardcoded actor names from signatures:
- ❌ "Summarizer" (doesn't exist)
- ❌ "BrowserExecutor" (hardcoded)
- ❌ "TerminalExecutor" (hardcoded)
- ❌ "WebSearchAgent" (hardcoded)

Replaced with generic placeholders:
- ✅ "ActorX"
- ✅ "ActorName"
- ✅ "existing actors in the system"

**Result:** System is now generic, extensible, and actor-agnostic! ✅
