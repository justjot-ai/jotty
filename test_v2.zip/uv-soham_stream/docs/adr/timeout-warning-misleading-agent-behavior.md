# ADR: Timeout Warning Causing Misleading Agent Behavior

**Status**: Fixed  
**Date**: 2026-02-09  
**Context**: BrowserExecutor agent was seeing "0 seconds remaining" timeout warning and incorrectly assuming it couldn't execute, leading to premature task completion

## Problem

When BrowserExecutor was called for later tasks in a sequence, it received a timeout warning saying "You have only 0 seconds remaining (100% of time used)" and immediately finished the task without attempting execution, even though it still had its own execution timeout available.

### Observed Behavior

**Logs showed:**
```
🚨 CRITICAL TIMEOUT WARNING for BrowserExecutor: 100% elapsed, 0s remaining
💭 REASONING: I'm at 100% timeout with 0 seconds remaining - this is a critical situation.
Since I'm out of time, I need to immediately mark this task as complete...
```

**Root Cause:**
- The timeout warning refers to the **Conductor's total timeout** (900 seconds for entire task sequence)
- By the time BrowserExecutor is called for task_3_task_4_task_5, previous tasks (task_1, task_2, architect/auditor calls) have consumed the 900 seconds
- BrowserExecutor still has its own **execution timeout** (900 seconds) to complete its task
- The warning message "0 seconds remaining" is misleading - it means the overall budget is exhausted, not that the agent can't execute
- Agent misinterpreted this as "I have 0 seconds to execute" and immediately finished

## Solution

**File**: `Synapse/core/timeouts.py`

Enhanced timeout warning messages to clarify:
1. The timeout refers to the **overall task budget**, not the agent's execution timeout
2. The agent **still has its own execution timeout** to complete the current task
3. The agent should work efficiently but can still execute operations

### Changes Made

**Before:**
```
🚨 CRITICAL TIMEOUT WARNING 🚨
You have only 0 seconds remaining (100% of time used).

IMMEDIATE ACTIONS REQUIRED:
1. STOP adding new functionality
2. TEST what you have RIGHT NOW
...
```

**After:**
```
🚨 CRITICAL TIMEOUT WARNING 🚨
The overall task budget has reached 100% (0 seconds remaining for the entire task sequence).

NOTE: You still have your own execution timeout to complete the current task. This warning
indicates the overall task budget is running low, not that you cannot execute.

IMMEDIATE ACTIONS REQUIRED:
1. Prioritize completing the current task efficiently
2. Focus on core functionality - skip non-essential features
...
You can still execute browser operations and complete your assigned task. Work efficiently
but don't assume you're out of time - you have your own execution timeout.
```

## Impact

**Before Fix:**
- Agents saw "0 seconds remaining" and immediately finished tasks
- Tasks were marked complete even though core functionality wasn't executed
- Agents didn't attempt browser operations when timeout warning appeared

**After Fix:**
- Agents understand they still have execution time available
- Agents prioritize efficiency but continue executing
- Tasks are completed properly even when overall budget is exhausted

## Related Files

- `Synapse/core/timeouts.py` - Timeout warning messages (fixed)
- `Synapse/core/conductor.py` - Timeout warning injection (no changes needed)
- `Synapse/core/synapse_core.py` - Parameter filtering and injection (no changes needed)

## Testing

To verify the fix works:
1. Run a multi-task sequence that consumes most of the Conductor timeout
2. Check that later tasks still execute properly when timeout warning appears
3. Verify agents don't prematurely finish when they see timeout warnings
4. Confirm agents understand they have their own execution timeout
