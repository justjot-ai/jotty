# ADR: Parallel Task Auditor Validation

## Status
Accepted

## Date
2026-02-02

## Context

A critical bug was discovered where parallel tasks were being marked as complete without any auditor validation. This allowed tasks to pass even when they were only partially completed.

### The Bug

In the parallel execution path (conductor.py lines 3300-3360), tasks were:
1. Marked complete if execution didn't throw an Exception
2. Using a hardcoded reward formula: `0.2 * len(non_exception_results)`
3. **Completely skipping auditor validation**

### Evidence

When running a task to "send a meme on WhatsApp":
- BrowserExecutor opened WhatsApp, found the chat, clicked attachment
- But couldn't actually upload the file (tool limitation)
- Agent reported `task_complete=True` with `collaboration_actions.status="partially_complete"`
- Conductor blindly trusted `task_complete=True` and marked task complete
- No auditor validation was run because tasks were parallel

### Contrast with Sequential Path

The sequential execution path (lines 3562-3590) properly:
- Called `_run_auditor_stream()` for validation
- Used `ParallelTestGenerator` for LLM-based test validation
- Only marked tasks complete if auditor passed

## Decision

Add independent auditor validation for each parallel task. A task is only marked complete if:
1. Execution doesn't throw an Exception, AND
2. Auditor validation passes

If auditor fails, the task is marked as **failed** (not complete).

## Implementation

```python
# For each parallel task result:
for (ptask, actor_config, _, _, _), result in zip(parallel_results, results):
    if isinstance(result, Exception):
        self.todo.fail_task(ptask.task_id, str(result))
    else:
        # 🎯 CRITICAL FIX: Run auditor INDEPENDENTLY
        async for auditor_event in self._run_auditor_stream(actor_config, result, ptask):
            # Process auditor events...
            if auditor_event.get("type") == "auditor_result":
                auditor_passed = auditor_event.get("passed", False)
        
        if auditor_passed:
            self.todo.complete_task(ptask.task_id, result)  # VALIDATED completion
        else:
            self.todo.fail_task(ptask.task_id, "Auditor validation failed")  # FAILED
```

## Consequences

### Positive
- Parallel tasks now have the same validation rigor as sequential tasks
- `ParallelTestGenerator` (LLM-based validation) now runs for parallel tasks
- Partial completions are properly caught and marked as failures
- Rewards are computed per-task based on actual validation results

### Negative
- Parallel execution will take longer due to auditor validation per task
- More LLM calls (one auditor per task)

### Neutral
- Existing tests updated to verify the fix
- New test file: `tests/test_parallel_auditor_validation.py`

## Files Changed
- `Synapse/core/conductor.py` - Added auditor validation in parallel path
- `tests/test_parallel_auditor_validation.py` - New test file
