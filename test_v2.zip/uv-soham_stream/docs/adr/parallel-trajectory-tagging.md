# ADR: Parallel Trajectory Tagging

**Date:** 2026-01-31  
**Status:** Implemented  
**Context:** Performance optimization for trajectory parsing

## Problem

Trajectory parsing was bottlenecked by sequential LLM calls for tagging attempts. Each attempt took 3-4 seconds to tag, resulting in:

- **31 attempts**: ~2.5 minutes total (from log analysis)
- **Linear time complexity**: O(n) where n = number of attempts
- **Poor user experience**: Long wait times for trajectory analysis

Example from logs:
```
12:35:57 - Attempt 1: tag='exploratory', tool='initialize_browser'
12:36:01 - Attempt 2: tag='exploratory', tool='navigate_to_url'
12:36:05 - Attempt 3: tag='error', tool='wait_for_element'
...
12:38:24 - Attempt 31: tag='answer', tool='finish'
```

Total: ~147 seconds for 31 attempts (~4.7s per attempt)

## Decision

Implement **parallel trajectory tagging** using `ThreadPoolExecutor`:

1. **Phase 1 - Data Collection** (fast, no LLM calls):
   - Sequentially collect all attempt data from trajectory
   - Extract tool names, observations, thoughts, etc.

2. **Phase 2 - Parallel Tagging** (concurrent LLM calls):
   - Submit all tagging tasks to thread pool
   - Process up to `max_workers` (default: 10) attempts concurrently
   - Collect and sort results by attempt number

### API Changes

```python
def parse_trajectory(
    self,
    result: Any,
    tool_name_filter: Optional[str] = None,
    expected_outcome: Optional[str] = None,
    parallel: bool = True,           # NEW: Enable parallel tagging
    max_workers: int = 10             # NEW: Concurrency limit
) -> List[TaggedAttempt]:
```

**Default behavior**: Parallel mode enabled for >1 attempts

## Implementation

### Key Components

1. **`_tag_attempts_parallel`**: Concurrent tagging with ThreadPoolExecutor
   - Submits all tagging tasks at once
   - Handles errors gracefully (falls back to 'exploratory')
   - Maintains attempt order via sorting

2. **`_tag_attempts_sequential`**: Fallback for single attempt or disabled parallel
   - Same behavior as old implementation
   - Used when `parallel=False` or only 1 attempt

3. **`_tag_single_attempt`**: Wrapper for parallel executor
   - Adapts existing `_tag_attempt` method
   - Used by ThreadPoolExecutor

### Error Handling

- If any tagging task fails, creates fallback `TaggedAttempt` with:
  - `tag='exploratory'`
  - `execution_status='uncertain'`
  - `reasoning=f"Tagging failed: {error}"`

## Benefits

### Performance Improvements

- **Time complexity**: O(n) → O(1) for n attempts
- **Expected speedup**: ~10x for 10+ attempts (limited by max_workers)
- **31 attempts**: 147s → ~15s (10 workers, 3 batches)
- **Scalability**: Handles large trajectories efficiently

### Other Benefits

- **Backward compatible**: Existing callers work unchanged
- **Configurable**: Can disable parallel mode if needed
- **Robust**: Error handling prevents failures from blocking other tags
- **Ordered output**: Results sorted by attempt number

## Trade-offs

### Pros
- Massive performance improvement for multi-attempt trajectories
- No code changes needed in callers
- Graceful degradation on errors

### Cons
- Increased memory usage (all futures held in memory)
- Thread overhead for very small trajectories (mitigated by auto-disable for single attempt)
- Potential rate limiting issues with LLM API (configurable via max_workers)

## Testing Strategy

Test scenarios:
1. ✅ Single attempt (should use sequential path)
2. ✅ Multiple attempts (should use parallel path)
3. ✅ Parallel vs sequential parity (same results)
4. ✅ Error handling (partial failures don't block others)
5. ✅ Result ordering (maintained despite parallel execution)

## Alternatives Considered

### 1. Async/await with asyncio
**Rejected**: More complex, DSPy may not be async-ready

### 2. Batch LLM calls
**Rejected**: Requires LLM API support, less flexible

### 3. Cache-based optimization
**Future enhancement**: Could complement parallel execution

## Migration

**No migration required** - Changes are backward compatible:
- Existing callers automatically use parallel mode
- Can opt-out with `parallel=False` if needed

## Metrics

**Before**: 31 attempts in ~147 seconds (4.7s/attempt)  
**After**: 31 attempts in ~15 seconds (0.5s/attempt) *[estimated with 10 workers]*  
**Speedup**: ~10x

## Related Files

- `Synapse/core/trajectory_parser.py` - Implementation
- `Synapse/core/synapse_core.py` - Main caller (line 778)

## A-Team Review

**Turing**: Architecture is clean - two-phase approach separates concerns well  
**Sutton**: Parallel RL trajectory analysis is standard practice in modern RL  
**Chomsky**: Semantic independence verified - attempts don't depend on each other  
**Consensus**: ✅ Implement with default parallel=True

## Future Enhancements

1. **Adaptive concurrency**: Auto-tune max_workers based on LLM rate limits
2. **Result caching**: Cache tags for identical observations
3. **Batch API support**: Use batch endpoints if available
4. **Progress reporting**: Emit progress updates during parallel tagging
