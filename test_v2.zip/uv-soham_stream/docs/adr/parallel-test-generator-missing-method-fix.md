# ADR: Fix ParallelTestGenerator Missing generate_and_run Method

**Date**: 2026-01-31  
**Status**: Implemented

## Context

The Synapse conductor was calling `ParallelTestGenerator.generate_and_run()` method at line 7822 in `Synapse/core/conductor.py`, but this method didn't exist in the `ParallelTestGenerator` class. This caused a recurring AttributeError across multiple runs:

```
'ParallelTestGenerator' object has no attribute 'generate_and_run'
```

The `ParallelTestGenerator` class only had:
- `generate_tests()` - async method to generate test cases
- `generate_tests_sync()` - sync version of test generation
- `_generate_single_batch()` - internal async helper

## Decision

Added the missing `generate_and_run()` async method to `ParallelTestGenerator` class that:

1. **Generates test cases** using the existing `generate_tests()` method
2. **Runs validations** against actual results using a new `_run_validation()` helper
3. **Returns structured results** with pass/fail counts

### Implementation Details

**Method Signature**:
```python
async def generate_and_run(
    task_description: str,
    expected_output: str,
    domain: str,
    actual_result: Any,
    num_tests: int = 5
) -> Dict[str, Any]
```

**Validation Methods Supported**:
- `file_exists` - checks for file creation indicators
- `content_match` - simple string matching
- `regex_match` - pattern matching
- `format_check` - format indicator checking
- Default: content matching fallback

**Return Structure**:
```python
{
    "results": List[Dict],  # Each test with passed/failed status
    "total_tests": int,
    "passed": int,
    "failed": int
}
```

## Consequences

### Positive
- ✅ Fixes the AttributeError that was breaking test generation
- ✅ Maintains async pattern consistent with existing methods
- ✅ Provides flexible validation methods for different test types
- ✅ Returns detailed test results for aggregation
- ✅ No breaking changes to existing code

### Negative
- ⚠️ Basic validation logic may need enhancement for complex test scenarios
- ⚠️ Error handling assumes string-convertible results

## Implementation

**File Modified**: `Synapse/core/parallel_test_generator.py`

**Methods Added**:
1. `generate_and_run()` - main async method (lines 186-268)
2. `_run_validation()` - validation helper (lines 270-309)

## Related Issues

This error appeared in multiple synapse output logs:
- `synapse_outputs/run_20260131_173453/synapse_state/episode_history/episode_1.json`
- `synapse_outputs/run_20260131_165439/synapse_state/q_tables/q_predictor_buffer.json`
- Multiple other historical runs dating back to 2026-01-30

## Testing

The method integrates with:
- `HybridTestAggregator` in conductor.py (line 7830)
- Existing test generation pipeline
- Parallel test execution workflow

No additional unit tests created as this fixes a missing integration point in the existing test flow.
