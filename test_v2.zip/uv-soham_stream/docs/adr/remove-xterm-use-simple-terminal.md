# ADR: Remove xterm.js, Use Simple Terminal Display

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Simplify terminal display by removing xterm.js dependency

## Decision

Removed xterm.js completely and use the simple HTML-based terminal display for all terminal output.

## Changes

### Removed from HTML
- xterm.css link
- xterm.js script
- xterm-addon-fit.js script
- Terminal/FitAddon global setup

### Simplified TerminalViewHandler

**Before:** Complex xterm.js initialization with retry logic, FitAddon, ResizeObserver, etc.

**After:** Simple HTML display:
```javascript
initialize() {
  this.container.innerHTML = `
    <div class="terminal-fallback">
      <div class="terminal-fallback-header">
        <span>⚡ Terminal Output</span>
      </div>
      <div class="terminal-fallback-content"></div>
    </div>
  `;
  this.fallbackContent = document.getElementById('terminal-fallback-content');
  this.initialized = true;
}
```

### Updated CSS
- Removed warning banner styling
- Changed header colors from warning (yellow) to normal (cyan)

## Benefits

✅ **Simpler:** No complex xterm.js initialization  
✅ **Faster:** Immediate display, no loading delays  
✅ **Smaller:** No xterm.js bundle (~500KB saved)  
✅ **Reliable:** No CDN or loading issues  
✅ **Maintainable:** Less code to maintain  

## Trade-offs

⚠️ **No ANSI colors:** Terminal output is plain text  
⚠️ **No cursor:** No blinking cursor or interactive features  
⚠️ **Basic scrolling:** Simple div scrolling vs xterm scrollback  

## Implementation

The simple terminal:
- Strips ANSI escape codes
- Displays plain text output
- Auto-scrolls to bottom
- Monospace font
- Dark theme

## Result

Clean, simple terminal display that works immediately without any dependencies or loading delays.

## Related Files

- `/electron-app/src/renderer/index.html` - Removed xterm scripts
- `/electron-app/src/renderer/js/agent-view-manager.js` - Simplified handler
- `/electron-app/src/renderer/css/agent-views.css` - Updated styles
