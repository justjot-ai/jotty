# ADR: Preserve All Auth Data on Browser Reset

## Status
Accepted

## Date
2026-02-02

## Context
Users had to log in every time the Electron app was restarted or a new task was executed. The `browser-reset` IPC handler was clearing `localStorage`, `indexDB`, `serviceworkers`, and `cachestorage` while only preserving cookies.

Modern web applications store authentication tokens in various storage mechanisms:
- **Cookies**: Traditional session cookies
- **localStorage**: JWT tokens, OAuth tokens, session identifiers
- **IndexedDB**: Complex auth data (e.g., WhatsApp Web stores auth here)
- **sessionStorage**: Session-scoped auth data (not persisted anyway)

## Decision
Modify the `browser-reset` handler to only clear non-auth storage types:
- **Clear**: `serviceworkers`, `cachestorage` (don't contain auth data)
- **Preserve**: `cookies`, `localstorage`, `indexdb` (contain auth tokens)

## Code Change
```javascript
// Before (clearing auth data)
await browserView.webContents.session.clearStorageData({
  storages: ['localstorage', 'indexdb', 'serviceworkers', 'cachestorage']
});

// After (preserving auth data)
await browserView.webContents.session.clearStorageData({
  storages: ['serviceworkers', 'cachestorage']
});
```

## Consequences

### Positive
- Users only need to log in once per website
- Session persistence works as expected across app restarts
- Works with all modern auth mechanisms (cookies, JWT, OAuth, WebAuthn)

### Negative
- Stale cache from previous tasks might slightly affect performance (minimal)
- If a user wants to truly "log out" they need to use explicit logout or clear cookies manually

### Neutral
- The `browser-clear-cookies` handler remains available for explicit cookie clearing when needed
- Session partition data is stored at `~/Library/Application Support/uv/Partitions/browser-agent/`

## Session Data Location
The persistent session uses Electron's partition system:
- Path: `<userData>/Partitions/browser-agent/`
- Contains: Cookies, IndexedDB, Local Storage, Session Storage, etc.
