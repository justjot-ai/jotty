# RCA: Content Too Large for Compression Error

**Date**: 2026-02-05  
**Status**: Analysis Complete  
**Issue**: `❌ Content too large for compression: 94619 tokens. Maximum compressor input: 1000 tokens`

## Context

During context building, the system attempts to compress content that exceeds the maximum input size:

```
2026-02-05 17:00:56.917 | ERROR | Synapse.core.unified_compression:334 | ❌ Content too large for compression: 94619 tokens. Maximum compressor input: 1000 tokens (model_context=8000, target=5000, safety=2000).
```

The error message suggests using `ContentIngestionPipeline.process()` instead, which handles chunking automatically.

## 5 Whys Root Cause Analysis

### Why 1: Why is content too large for compression?
**Answer**: The content being compressed (94,619 tokens) exceeds the maximum compressor input limit (1,000 tokens).

### Why 2: Why is there a 1,000 token limit?
**Answer**: The compressor is designed to work within model context windows (8,000 tokens), with a target of 5,000 tokens and 2,000 token safety margin, leaving only 1,000 tokens for input.

### Why 3: Why is 94,619 tokens being passed to the compressor?
**Answer**: The code is calling `UnifiedCompressor.compress()` directly on large content without chunking it first.

### Why 4: Why isn't the content being chunked before compression?
**Answer**: The code path is using the low-level `UnifiedCompressor.compress()` method instead of the higher-level `ContentIngestionPipeline.process()` which handles chunking automatically.

### Why 5: Why is the wrong API being used?
**Answer**: Either the developer wasn't aware of the pipeline API, or the code was written before the pipeline existed, or there was a misunderstanding about which API to use for large content.

## Root Cause

**The root cause is**: Using the wrong API - `UnifiedCompressor.compress()` directly on large content instead of `ContentIngestionPipeline.process()` which handles chunking automatically.

## Current Implementation

**Error Location**: `Synapse/core/unified_compression.py` (line 334)

```python
if current_tokens > max_compressor_input:
    error_msg = (
        f"❌ Content too large for compression: {current_tokens} tokens. "
        f"Maximum compressor input: {max_compressor_input} tokens "
        f"(model_context={model_context}, target={target}, safety={safety}). "
        f"\n\n"
        f"🔧 FIX: Use ContentIngestionPipeline.process() instead of UnifiedCompressor.compress(). "
        f"The pipeline will automatically chunk the content first."
    )
    logger.error(f"❌ {error_msg}")
    raise ValueError(error_msg)
```

**Where it's being called incorrectly**: Need to find call sites using `UnifiedCompressor.compress()` directly.

## Suggested Fixes

### Fix 1: Use ContentIngestionPipeline.process() Instead (Recommended)
**Location**: Find call sites using `UnifiedCompressor.compress()` directly

```python
# Change from:
compressor = UnifiedCompressor(config)
compressed_content = compressor.compress(large_content)

# To:
from Synapse.core.content_ingestion import ContentIngestionPipeline
pipeline = ContentIngestionPipeline(config)
compressed_content = await pipeline.process(large_content)
```

### Fix 2: Add Automatic Chunking to UnifiedCompressor
**Location**: `Synapse/core/unified_compression.py`

Add automatic chunking when content is too large:

```python
def compress(self, content: str, ...) -> str:
    """Compress content with automatic chunking if needed."""
    current_tokens = self._estimate_tokens(content)
    
    if current_tokens > max_compressor_input:
        # Automatically chunk and compress
        logger.info(f"📦 Content too large ({current_tokens} tokens), chunking automatically...")
        return self._compress_chunked(content)
    
    # Normal compression for small content
    return self._compress_single(content)

def _compress_chunked(self, content: str) -> str:
    """Chunk large content and compress each chunk."""
    chunks = self._chunk_content(content, max_tokens=max_compressor_input)
    compressed_chunks = []
    
    for chunk in chunks:
        compressed = self._compress_single(chunk)
        compressed_chunks.append(compressed)
    
    # Combine compressed chunks
    return self._combine_compressed_chunks(compressed_chunks)
```

### Fix 3: Increase Maximum Input Size (Not Recommended)
**Location**: `Synapse/core/unified_compression.py`

```python
# Increase max_compressor_input calculation
max_compressor_input = model_context - target - safety
# Could increase, but this doesn't solve the root problem
```

**Note**: This doesn't solve the fundamental issue - very large content still needs chunking.

## Implementation Priority

1. **High**: Fix 1 (Use Pipeline) - Correct solution, uses existing infrastructure
2. **Medium**: Fix 2 (Auto-chunking) - Good if we want UnifiedCompressor to be smarter
3. **Low**: Fix 3 (Increase Limit) - Doesn't solve the problem, just delays it

## Consequences

### Positive
- ✅ Large content will be handled correctly
- ✅ Automatic chunking prevents errors
- ✅ Better compression quality (chunked compression)
- ✅ Uses existing, tested pipeline infrastructure

### Considerations
- ⚠️ Need to find all call sites using UnifiedCompressor.compress()
- ⚠️ Pipeline may have different return format
- ⚠️ May need to update error handling
- ⚠️ Performance impact of chunking (may be slower but necessary)

## Testing

1. **Unit Test**: Pass large content to ContentIngestionPipeline → Should chunk and compress
2. **Unit Test**: Pass small content → Should compress normally
3. **Integration Test**: Build context with large content → Should not raise ValueError
4. **Performance Test**: Measure compression time for large vs small content

## Files to Modify

- Find call sites using `UnifiedCompressor.compress()` directly
- `Synapse/core/content_ingestion.py` - Verify pipeline API
- `Synapse/core/unified_compression.py` - Optionally add auto-chunking

## Additional Notes

The error message itself is helpful - it tells developers exactly what to do. Consider:
1. Making this a warning instead of error if we can auto-chunk
2. Adding automatic fallback to pipeline if content is too large
3. Documenting which API to use for different scenarios
