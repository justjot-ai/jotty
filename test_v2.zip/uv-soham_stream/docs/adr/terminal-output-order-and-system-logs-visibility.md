# ADR: Terminal Output Order Fix and System Logs Visibility

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Electron UI - Agent view manager

## Problems

### Problem 1: Terminal Output in Reverse Order

Terminal output was appearing in reverse chronological order (newest at bottom, oldest at top) instead of the expected order (newest at top).

**Root Cause:**
```javascript
// OLD CODE - WRONG
this.fallbackContent.appendChild(line);  // Adds to bottom
this.fallbackContent.scrollTop = this.fallbackContent.scrollHeight;  // Scrolls to bottom
```

The CSS uses `flex-direction: column-reverse` to show newest items at top, but the code was using `appendChild` (adds to bottom) instead of `insertBefore` (adds to top).

### Problem 2: System Logs Visibility Timing

System logs were being hidden too early (when agents activated) instead of when agent screens were ready.

**Old Behavior:**
- System logs hidden immediately when agent activated
- User couldn't see task progress during agent initialization
- System logs disappeared before browser/terminal screens were ready

**Desired Behavior:**
- System logs visible during task startup and agent initialization
- System logs hidden only when agent screens (browser/terminal) are ready and displaying content
- No collapsible bar - completely hidden when agents are displaying

## Solutions

### Fix 1: Terminal Output Order

Changed from `appendChild` to `insertBefore` to match the CSS `column-reverse` layout:

```javascript
// NEW CODE - CORRECT
this.fallbackContent.insertBefore(line, this.fallbackContent.firstChild);  // Prepend to top
this.fallbackContent.scrollTop = 0;  // Keep scroll at top
```

**Result:**
- ✅ Newest terminal output appears at top
- ✅ Matches expected chronological order
- ✅ Consistent with system logs display pattern

### Fix 2: System Logs Visibility Timing

Changed when system logs are hidden - wait until agent handlers are initialized and displaying content:

```javascript
// OLD CODE - WRONG (in activateAgent)
if (this.activeAgents.size === 0) {
  this.hideSystemLogs();  // Hide immediately when first agent activates
}

// NEW CODE - CORRECT (in activateAgent and handleAgentEvent)
// In activateAgent:
if (agentView.handler.isInitialized()) {
  this.hideSystemLogs();  // Only hide if handler already initialized
}

// In handleAgentEvent:
agentView.handler.handleEvent(event_type, data);
if (agentView.handler.isInitialized() && this.systemLogsContainer) {
  this.hideSystemLogs();  // Hide after first event processed
}
```

**Changes Made:**
1. Removed collapsible bar HTML from `showSystemLogs()`
2. Changed `hideSystemLogs()` to use `display: none` instead of CSS classes
3. Moved `hideSystemLogs()` call to happen AFTER agent handler is initialized
4. Updated `handleAgentEvent()` to hide system logs after first event is processed
5. System logs continue to receive events until hidden

**Result:**
- ✅ System logs visible during task startup
- ✅ System logs show agent initialization progress
- ✅ System logs hidden only when agent screens are ready
- ✅ No collapsible bar - clean transition
- ✅ User sees continuous feedback from start to agent display

## Files Changed

- `electron-app/src/renderer/js/agent-view-manager.js`
  - Fixed `TerminalViewHandler.appendToFallback()` - use `insertBefore` instead of `appendChild`
  - Fixed `hideSystemLogs()` - use `display: none` instead of collapse
  - Updated `showSystemLogs()` - removed collapsible bar HTML
  - Updated `toggleSystemLogs()` - made it a no-op
  - Removed event count update logic

## Testing

### Test Terminal Output Order
1. Start a task that uses TerminalExecutor
2. Verify terminal output appears with newest at top
3. Check that output is in correct chronological order

### Test System Logs Visibility
1. Start with welcome screen - system logs should be visible
2. Start a task - system logs should remain visible showing task progress
3. Wait for agent screens (browser/terminal) to initialize
4. System logs should disappear once agent screens are displaying content
5. Verify no collapsible bar is visible
6. Complete task - system logs should reappear

## Benefits

- ✅ Terminal output in correct order (newest at top)
- ✅ Cleaner UI when agents are active (no system logs bar)
- ✅ Consistent display pattern across all views
- ✅ Less visual clutter
- ✅ Better user experience

## Related

- System logs use `flex-direction: column-reverse` in CSS
- Terminal view matches this pattern for consistency
- Agent views now have full screen space when active
