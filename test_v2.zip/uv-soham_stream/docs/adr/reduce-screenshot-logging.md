# ADR: Reduce Screenshot Capture Logging

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Console Log Cleanup

## Decision

Remove verbose console logging from screenshot capture to reduce console noise during normal operation.

## Problem

The screenshot capture was logging every operation (every 500ms):

```
📸 Capturing screenshot...
✅ Screenshot captured, size: 217216 bytes
🖼️ Image loaded, rendering to canvas...
📐 Container size: 329x836
📐 Image size: 800x513
📐 Canvas element: <canvas...>
🎨 Drawing at (0, 312.514375) with scale 0.41125
✅ Canvas rendered successfully!
[Repeats every 500ms]
```

This caused:
- ❌ Console spam (7 logs every 500ms = 14 logs/second)
- ❌ Hard to see important logs
- ❌ Performance impact (logging overhead)
- ❌ Difficult debugging (signal lost in noise)

## Solution

### Keep Only Error Logs

**File**: `electron-app/src/renderer/js/agent-view-manager.js`

#### Before (Verbose)
```javascript
async captureScreenshot() {
  console.log('📸 Capturing screenshot...');
  console.log('✅ Screenshot captured, size:', result.data.length, 'bytes');
  console.log('🖼️ Image loaded, rendering to canvas...');
  console.log(`📐 Container size: ${containerWidth}x${containerHeight}`);
  console.log(`📐 Image size: ${img.width}x${img.height}`);
  console.log(`📐 Canvas element:`, this.screenshotCanvas);
  console.log(`🎨 Drawing at (${x}, ${y}) with scale ${scale}`);
  console.log('✅ Canvas rendered successfully!');
}
```

#### After (Silent Success, Log Errors)
```javascript
async captureScreenshot() {
  // No logging for normal operation
  
  // Only log errors
  img.onerror = (error) => {
    console.error('Failed to load screenshot image:', error);
  };
  
  catch (error) {
    console.error('Screenshot capture error:', error);
  }
}
```

### Changes Made

1. **Removed**: All success/info logs from screenshot capture
2. **Removed**: Container size, image size, canvas element logs
3. **Removed**: Drawing position and scale logs
4. **Kept**: Error logs only
5. **Added**: Image load error handler

### Other Cleanup

Also removed verbose logs from:
- Placeholder hiding
- CDP domain enabling

## Logging Philosophy

### Log Levels

**Always Log:**
- ✅ Errors and exceptions
- ✅ Connection state changes (connect/disconnect)
- ✅ Important user actions
- ✅ Task completion/failure

**Never Log (in production):**
- ❌ Routine operations (screenshot capture)
- ❌ Render updates
- ❌ Size calculations
- ❌ Drawing operations

**Debug Mode Only:**
- 🔍 Detailed event data
- 🔍 State transitions
- 🔍 Performance metrics

## Console Output

### Before (Every 500ms)
```
📸 Capturing screenshot...
✅ Screenshot captured, size: 217216 bytes
🖼️ Image loaded, rendering to canvas...
📐 Container size: 329x836
📐 Image size: 800x513
📐 Canvas element: <canvas id="browser-canvas"...>
🎨 Drawing at (0, 312.514375) with scale 0.41125
✅ Canvas rendered successfully!
```

### After (Silent)
```
[No logs during normal operation]

[Only if error occurs:]
❌ Screenshot capture error: Connection lost
```

## Benefits

1. **Clean Console**: Only important information visible
2. **Better Performance**: Less logging overhead
3. **Easier Debugging**: Signal not lost in noise
4. **Professional**: Production-ready logging
5. **Focused**: See what matters

## When to See Logs

**You will see logs for:**
- CDP connection established/closed
- Navigation events
- User actions
- Errors and failures

**You won't see logs for:**
- Screenshot capture (happens automatically)
- Canvas rendering (visual feedback sufficient)
- Size calculations (not user-facing)

## Debug Mode

If detailed logging is needed, enable debug mode in app.js:
```javascript
this.debugMode = true;
```

This provides detailed event logging without screenshot spam.

## Related

- `electron-debug-mode-logging.md` - Debug mode implementation
- `agent-cleanup-on-completion.md` - Cleanup logging
- `electron-chrome-embedding-screenshot-streaming.md` - Screenshot implementation

## Lesson Learned

**Log strategically:**
- Log state changes, not state
- Log errors, not success (success is the default)
- Log user actions, not system operations
- Use visual feedback instead of console logs when possible

**The best log is no log** - if the feature works, silence is golden.
