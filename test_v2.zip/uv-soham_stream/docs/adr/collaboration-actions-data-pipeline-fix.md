# ADR: Collaboration Actions Data Pipeline Fix

## Status
Accepted

## Date
2026-02-02

## Context

Critical bug discovered where inter-agent communication via `collaboration_actions` was completely broken. When an agent like WebSearchAgent found meme URLs and tried to share them with BrowserExecutor:

1. **WebSearchAgent correctly outputted** `collaboration_actions` with meme URLs in its DSPy Prediction `_store`
2. **But BrowserExecutor never received them** - it hallucinated a fake URL instead
3. **Task was marked complete** without the meme actually being sent

### Root Causes Identified

1. **EpisodeResult never yielded**: `synapse_core.arun()` created `EpisodeResult` with the full DSPy Prediction but never yielded it to the conductor. The conductor received `True/False` instead of the actual data.

2. **Wrong target agent name**: WebSearchAgent's collaboration_actions specified `"target_agent": "WhatsAppManager"` but the actual browser agent is named `BrowserExecutor`. There was no validation or resolution.

3. **No target validation**: `_handle_knowledge_share_stream` sent messages to non-existent agents without any validation against the agent directory.

4. **Environment truncation**: Even if collaboration worked, `env.md` summarizer truncated URLs to "https://preview.redd.it/..." making them unusable.

### Evidence from Logs

```
# WebSearchAgent had the correct URLs in _store
Line 1004: _store['collaboration_actions'] = [{"action": "share_knowledge", "target_agent": "WhatsAppManager", 
"data": {"meme_urls": ["https://preview.redd.it/ugw9rzlbt3wf1.jpeg", ...]}}]

# But conductor received bool instead of Prediction  
Line 925: [IOManager PREP] result type: <class 'bool'>
Line 934: ⚠️ Could not extract fields from bool

# No collaboration actions were ever processed
# "🤝 Processing collaboration actions" never appeared in logs
```

## Decision

### Fix 1: Yield EpisodeResult from synapse_core.arun()

Added at the end of `synapse_core.arun()` after creating `EpisodeResult`:

```python
# 🔥 A-TEAM CRITICAL FIX: Actually YIELD the EpisodeResult!
logger.info(f"[🔍 EPISODE RESULT] Yielding EpisodeResult with output type: {type(actor_output)}")
yield {
    "type": "result", 
    "result": episode_result, 
    "module": "Synapse.core.synapse_core", 
    "message": f"I am returning the episode result for {self.agent_config.name}"
}
```

### Fix 2: Target Agent Resolution with Fuzzy Matching

Added `_resolve_target_agent()` method in conductor that:
- Validates target_agent against agent_directory
- Falls back to keyword matching (e.g., "WhatsApp*" → "BrowserExecutor")
- Matches by agent capabilities
- Checks task assignments
- Broadcasts to all if no match found

### Fix 3: Enhanced Agent Directory with Task Assignments

Modified `_agent_directory` injection to include current task assignments:

```python
enhanced_directory[agent_name] = {
    ...original_info,
    'current_tasks': [
        {'task_id': 'task_3', 'description': 'Send meme to WhatsApp', 'status': 'pending'}
    ]
}
```

This helps agents know which agent to target for collaboration.

## Consequences

### Positive
- Inter-agent communication now works correctly
- Agents receive full DSPy Prediction data including `collaboration_actions`
- Invalid target agents are resolved to correct ones
- Agents can see which tasks are assigned to which agents
- Better debugging via enhanced logging

### Negative
- Additional JSON serialization overhead for enhanced directory
- Fuzzy matching could potentially match wrong agents (mitigated by checking agent_directory)

### Risks
- Existing code that relied on `result if result is not None else True` behavior may break
- Need to verify all code paths that receive results handle EpisodeResult properly

## Files Changed

1. `Synapse/core/synapse_core.py` - Yield EpisodeResult at end of arun()
2. `Synapse/core/conductor.py`:
   - Added `_resolve_target_agent()` method
   - Updated `_handle_knowledge_share_stream()` to use resolution
   - Enhanced `_agent_directory` with task assignments
   - Added collaboration action processing inside `aforward` code path (before early return)
3. `uv/src/uv/api/v1/perform.py` - Added JSON serialization for EpisodeResult
4. `uv/src/uv/api/v1/websocket_agents.py`:
   - Fixed dead WebSocket cleanup in `broadcast()` method
   - Added `finally` block to ensure disconnection cleanup always happens
   - This fixes silent command failures when Electron WebSocket reconnects
5. `electron-app/src/renderer/js/app.js`:
   - Added browser pre-activation: detects when BrowserExecutor starts a task
   - Automatically calls `moveBrowserToTopAndShow()` BEFORE commands arrive
   - Added `ensureWebSocketConnected()` for proactive reconnection
   - Reduced WebSocket reconnect delay from 3s to 1s
6. `surface_synapse/agent_session_manager.py`:
   - Updated `broadcast_message()` to return connection count
   - Now warns when no active connections before broadcast
7. `surface/src/surface/tools/browser_tools.py`:
   - Updated `_send_browser_command_sync()` to check broadcast status
   - Now returns failure if no active connections (instead of fake success)

## Testing

To verify the fix works:
1. Run a task that requires inter-agent collaboration
2. Check logs for "🤝 Processing collaboration actions"
3. Verify IOManager receives non-bool result type
4. Confirm target agent resolution in logs

## Related Issues

- Task completion without actual execution
- LLM hallucinating URLs when correct URLs were available
- Environment summarization truncating critical data
