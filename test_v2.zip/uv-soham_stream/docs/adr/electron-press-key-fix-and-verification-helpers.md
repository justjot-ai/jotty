# ADR: Fix Electron Press Key and Add Verification Helpers

## Status
Accepted

## Date
2026-02-02

## Context

The BrowserExecutor agent was sending messages to wrong contacts in WhatsApp Web. Investigation revealed:

1. **Root Cause**: The `electron_press_key` function was using wrong key codes. It mapped 'Enter' to '\r' (character code) but `sendInputEvent` with `keyDown`/`keyUp` expects key names like 'Return' or 'Enter'.

2. **Secondary Issue**: The agent had no way to verify that actions had the intended effect. It would press Enter, assume it worked, and proceed without verification.

3. **Symptom**: Agent typed "soham" in search, pressed Enter (which didn't register), then immediately found an already-open chat's message box and sent "hi" to the wrong person.

## Decision

### Fix 1: Correct the key mapping in Electron

**Before** (broken):
```javascript
const keyMapping = {
  'Enter': '\r',     // WRONG - sendInputEvent expects key names
  'Tab': '\t',       // WRONG
  ...
};
```

**After** (fixed):
```javascript
const keyNameMapping = {
  'Enter': 'Return',  // Correct key name for Electron
  'Tab': 'Tab',
  ...
};

// Also send 'char' event for Enter to trigger input
if (key === 'Enter') {
  browserView.webContents.sendInputEvent({
    type: 'char',
    keyCode: '\r',
    modifiers: eventModifiers
  });
}
```

### Fix 2: Add verification helpers

Added two new tools:

1. **`electron_verify_text_contains(selector, expected_text, timeout)`**
   - Polls an element until expected text appears
   - Returns `verified: true/false` so agent can confirm actions worked

2. **`electron_search_and_select(search_box_selector, search_text, ...)`**
   - Compound action that handles the full search flow
   - Types text, waits for results, uses ArrowDown+Enter to select
   - More reliable than individual steps

### Fix 3: Focus element before pressing key

The press_key handler now accepts a `selector` parameter and focuses the element first using JavaScript before sending key events.

## Consequences

### Positive
- Enter key now actually works in WhatsApp Web and other apps
- Agents can verify their actions had the intended effect
- The `search_and_select` helper provides reliable search selection pattern
- Focus is properly set before key events

### Negative
- Agents need to be updated to use verification patterns
- Small added latency from verification steps

## Files Changed
- `electron-app/src/main.js` - Fixed key mapping, added verification handlers
- `electron-app/src/preload.js` - Added API bindings
- `electron-app/src/renderer/js/app.js` - Added command routing
- `surface/src/surface/tools/browser_tools.py` - Added Python wrapper functions

## Verification Pattern for Agents

Agents should now use this pattern:

```python
# Old pattern (broken):
electron_type("soham", selector=search_box)
electron_press_key("Enter")  # May not work!
electron_type("hi", selector=message_box)
electron_press_key("Enter")

# New pattern (reliable):
result = electron_search_and_select(
    search_box_selector="div[data-tab='3']",
    search_text="soham",
    use_arrow_navigation=True
)
if result.get('success'):
    # Verify the chat opened
    verify_result = electron_verify_text_contains(
        selector="header span[title]",
        expected_text="soham"
    )
    if verify_result.get('verified'):
        electron_type("hi", selector=message_box)
        electron_press_key("Enter")
```
