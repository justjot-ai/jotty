# ADR: Fix Electron UI Display Issues (TODOs & Log Streaming)

**Date:** 2026-01-31  
**Status:** Implemented  
**Context:** Tasks not showing in Electron UI, system logs not streaming

## Problem

Tasks created by Synapse were not appearing in the Electron UI's TODO panel, despite being logged and tracked correctly in the system.

## Root Causes Identified

1. **Server Code Error**: Logger was used before being defined (line 47 vs line 56)
2. **Session Registration**: After server restart, `active_task_logs` dictionary was empty, so existing log files weren't found
3. **Task Description Extraction**: Regex patterns weren't matching the log format correctly for extracting task descriptions

## Solutions Implemented

### 1. Fixed Logger Initialization Order
```python
# Moved logging setup before imports that use it
logging.basicConfig(...)
logger = logging.getLogger(__name__)

# Then import modules that may use logger
try:
    from surface.tools.browser_tools import set_screenshot_callback
except Exception as e:
    logger.warning(f"Browser tools not available: {e}")
```

### 2. Added Fallback Log File Discovery
```python
# Check active_task_logs first, then fallback to scanning logs directory
if session_id in active_task_logs:
    log_file = Path(active_task_logs[session_id])
else:
    # Scan logs/electron_tasks for matching files
    logs_dir = project_root / "logs" / "electron_tasks"
    matching_logs = list(logs_dir.glob(f"task_{session_id}_*.log"))
    if matching_logs:
        log_file = sorted(matching_logs, key=lambda x: x.stat().st_mtime, reverse=True)[0]
```

### 3. Improved Task Description Extraction
```python
# Extract descriptions from TASK BREAKDOWN section
breakdown_pattern = r"TASK:\s+([^:]+):\s+([^\|]+)\s+\|\s+TYPE:\s+\w+\s+\|\s+DESC:\s+([^\n\.]+)"

# Match ADD_TASK lines with task_id and actor
task_pattern = r"ADD_TASK: MarkovianTODO \| task_id=(\w+) \| actor=(\w+) \| description_length=\d+"

# Use extracted descriptions for tasks
if len(task_descriptions) == 1:
    description = list(task_descriptions.values())[0]
```

### 4. Added Task Status Tracking
```python
# Track "in_progress" status
executing_pattern = r"🎯 Executing (\w+) \(attempt \d+/\d+\)"

# Track "completed" status  
complete_pattern = r"✅ EXECUTE_ACTOR COMPLETE: actor=(\w+)"

# Track "failed" status
fail_pattern = r"❌.*actor=(\w+)"
```

## Result

- Tasks now display in Electron UI with correct descriptions
- Task statuses update dynamically (pending → in_progress → completed/failed)
- System works even after server restarts
- Example output:
  ```json
  {
    "id": "task_1",
    "actor": "TerminalExecutor",
    "description": "Retrieve and return today's date (2026-01-31)",
    "status": "in_progress"
  }
  ```

## Files Modified

- `surface_synapse/server.py`: Fixed logger initialization, added fallback log discovery, improved task extraction

### 5. Fixed WebSocket Log Streaming

Added same fallback logic to WebSocket endpoint:
```python
# Check active_task_logs first, then scan logs directory
if session_id in active_task_logs:
    log_file_path = Path(active_task_logs[session_id])
else:
    logs_dir = project_root / "logs" / "electron_tasks"
    matching_logs = list(logs_dir.glob(f"task_{session_id}_*.log"))
    if matching_logs:
        log_file_path = sorted(matching_logs, key=lambda x: x.stat().st_mtime, reverse=True)[0]
```

### 6. Support for Multiple TASK Formats

Now handles both log formats:
- `TASK: SystemExecutor: Get current date | TYPE: ...` (with name)
- `TASK: Provide current date | TYPE: ...` (without name)

## Testing

### Test REST API (Tasks)
```bash
curl -s "http://127.0.0.1:8765/api/artifacts/1769857656693" | python3 -m json.tool
```

### Test WebSocket (Log Streaming)
```python
import asyncio, websockets, json

async def test():
    async with websockets.connect("ws://127.0.0.1:8765/ws/logs/1769857656693") as ws:
        for _ in range(5):
            data = json.loads(await ws.recv())
            print(f"{data['type']}: {data['content'][:60]}")

asyncio.run(test())
```

## Results

Both APIs now work correctly:
- ✅ Tasks display with proper descriptions and status
- ✅ Logs stream in real-time via WebSocket
- ✅ Works even after server restarts (fallback to file scanning)
