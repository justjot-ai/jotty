# ADR: Base LLM Capabilities Automatically Added to All Actors

**Status:** Active  
**Date:** 2026-01-30  
**Context:** Enhancement to capability inference system

---

## Decision

All actors in Synapse now automatically receive base LLM capabilities during capability inference, since all actors are LLM-based agents powered by DSPy.

---

## Base Capabilities Added

Every actor automatically gets these fundamental capabilities:

- `text_understanding` - Parse and comprehend natural language
- `text_generation` - Produce coherent text responses
- `summarization` - Condense information into key points
- `reasoning` - Apply logical thinking and inference
- `analysis` - Examine patterns and draw insights
- `natural_language_processing` - Handle language-based tasks

---

## Implementation

Updated `GenericAgentRegistry._llm_infer_capabilities()`:

```python
base_llm_capabilities = [
    "text_understanding",
    "text_generation",
    "summarization",
    "reasoning",
    "analysis",
    "natural_language_processing"
]
```

**Flow:**
1. Define base LLM capabilities
2. LLM infers specialized capabilities (actor-specific)
3. Combine base + specialized
4. Deduplicate while preserving order
5. Return combined list

**Fallback:**
- If LLM inference fails, return base capabilities only
- No longer returns empty list on failure

---

## Rationale

### Why This Change?

1. **Accurate Representation**
   - All Synapse actors use DSPy LLMs
   - They inherently have language understanding/generation capabilities
   - Should be reflected in capability system

2. **Better Task Assignment**
   - Tasks requiring "summarization" can be assigned to any actor
   - No artificial limitations on LLM agent capabilities
   - More flexible task routing

3. **Graceful Degradation**
   - Even if specialized capability inference fails
   - Actors still have base capabilities
   - Better than returning empty list

4. **Realistic Modeling**
   - Every LLM can understand text, generate responses, reason
   - System should recognize this truth
   - Prevents underestimating actor capabilities

---

## Scope

**Applied To:** LLM-inferred capabilities only  
**NOT Applied To:** Explicitly specified capabilities

This ensures:
- User-provided capability lists remain untouched
- LLM-inferred actors get complete capability picture
- No breaking changes to existing explicit configurations

---

## Example

### Before
```python
# LLM inferred only specialized capabilities
Actor: BrowserExecutor
Capabilities: ["web_browsing", "selenium", "screenshot"]
# Missing: Can't be assigned "summarize this webpage" task
```

### After
```python
# LLM infers specialized + adds base
Actor: BrowserExecutor
Capabilities: [
    "text_understanding",      # Base (auto-added)
    "text_generation",         # Base (auto-added)
    "summarization",          # Base (auto-added)
    "reasoning",              # Base (auto-added)
    "analysis",               # Base (auto-added)
    "natural_language_processing",  # Base (auto-added)
    "web_browsing",           # Specialized (LLM-inferred)
    "selenium",               # Specialized (LLM-inferred)
    "screenshot"              # Specialized (LLM-inferred)
]
# Now: Can handle "summarize this webpage" task!
```

---

## Impact

### Positive
✅ More accurate capability representation  
✅ Better task assignment flexibility  
✅ No more empty capability lists on inference failure  
✅ Reflects reality of LLM-based agents  

### Neutral
- Capability lists are longer (more entries)
- Minimal performance impact (list concatenation)

### Risks
- None identified (base capabilities are universally true for LLM agents)

---

## Testing

Verify:
1. LLM-inferred actors have base capabilities
2. Explicitly specified capabilities unchanged
3. Deduplication works correctly
4. Fallback returns base capabilities on error

---

## Related

- `docs/adr/actor-capability-generation-flow.md` - Complete capability system documentation
- `Synapse/core/generic_agent_registry.py` - Implementation
- `Synapse/agents/todo_creator_agent.py` - Uses capabilities for task assignment

---

## Future Considerations

- Allow configuration of base capability list
- Different base capabilities for different actor types
- Capability validation (verify actor can actually perform capability)
- Capability hierarchy (parent-child relationships)
