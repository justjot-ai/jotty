# ADR: Task Breakdown Agent Selection for PresentationBuilder

**Status**: Implemented  
**Date**: 2026-02-05  
**Context**: TaskBreakdownAgent generating tasks for TerminalExecutor related to slide creation instead of using PresentationBuilder agent

## Problem

When users requested PowerPoint/presentation tasks, the `TaskBreakdownAgent` was generating tasks assigned to `TerminalExecutor` instead of `PresentationBuilder`, even though `PresentationBuilder` is a specialized agent designed for presentation creation.

**Example from logs**:
```
TASK: TerminalExecutor: Read existing PowerPoint file and apply fancy styling/design enhancements
TASK: TerminalExecutor: Read markdown content from evaluation-folder-explanation.md and optimization-pipeline-mathematical-formulation.md
TASK: TerminalExecutor: Create new slide with markdown content...
```

This caused validation warnings:
```
⚠️ Actor assignment mismatch: task_2_3_4 involves presentation operations but is assigned to "TerminalExecutor" instead of "PresentationBuilder"
⚠️ Potential capability mismatch: TerminalExecutor may not have PowerPoint manipulation capabilities required for task_2_3_4
```

## Root Cause

The `ExtractTasksSignature` in `TaskBreakdownAgent` had hardcoded agent selection rules that only mentioned:
- BrowserExecutor (for WhatsApp/web browsing)
- TerminalExecutor (for terminal/shell commands)
- WebSearchAgent (for web search)

It did **not** include `PresentationBuilder` or other specialized agents (`ImageGenerator`, `AudioHandler`), so when the LLM encountered PowerPoint/presentation tasks, it defaulted to `TerminalExecutor` as the closest match for "file operations."

## Solution

Updated `ExtractTasksSignature` in `/Synapse/signatures/task_breakdown_signatures.py` to include all specialized agents in the agent selection rules:

1. **Added PresentationBuilder** for PowerPoint/presentation tasks
2. **Added ImageGenerator** for image generation/creation tasks
3. **Added AudioHandler** for audio processing tasks

**Changes**:
- Updated `AGENT SELECTION` section in the signature docstring (lines 27-34)
- Updated `CRITICAL AGENT SELECTION` section in the output field description (lines 67-74)
- Added presentation task examples (lines 81-83)

## Impact

- PowerPoint/presentation tasks will now correctly be assigned to `PresentationBuilder` during task breakdown
- Reduces validation warnings about actor assignment mismatches
- Ensures tasks are routed to the correct specialized agent from the start
- `TodoCreatorAgent` will still validate and reassign if needed, but initial assignments will be more accurate

## Related Files

- `/Synapse/signatures/task_breakdown_signatures.py` - Updated signature with agent selection rules
- `/Synapse/agents/task_breakdown_agent.py` - Uses the updated signature
- `/Synapse/agents/presentation_builder.py` - PresentationBuilder agent definition
