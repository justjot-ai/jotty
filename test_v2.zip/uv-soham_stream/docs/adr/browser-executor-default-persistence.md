# ADR: Browser Executor Default Session Persistence

**Date:** 2026-01-30  
**Status:** Implemented

## Context

Previously, users had to explicitly specify in their instruction that they wanted persistent browser sessions:

```python
instruction = """
1. Initialize browser with PERSISTENT PROFILE named "whatsapp_session"
   Use: initialize_browser_with_profile("whatsapp_session", headless=False)
2. Navigate to site...
"""
```

This had several problems:

### User Experience Issues

1. **Verbose Instructions** - Users had to include boilerplate about profiles
2. **Cognitive Overhead** - Users had to understand profiles, paths, and persistence
3. **Easy to Forget** - Users would forget to specify profile, losing authentication
4. **Not Intuitive** - Modern browsers save sessions by default, why shouldn't our agent?

### Developer Pain Points

```python
# User question:
"why i need to send this in prompt can i not make it default use this only"
```

The user was right - this should be the default behavior, not something you configure in every instruction.

## Decision

**Make session persistence the DEFAULT behavior** of the BrowserExecutor agent.

Users should get persistent sessions automatically without having to ask for them, just like regular browsers work.

### Implementation Strategy

1. **Update System Prompt** - Instruct agent to use persistent profiles by default
2. **Set Default Profile** - Use `'default_session'` as the standard profile name
3. **Simplify Instructions** - Users just say "open WhatsApp" - no profile configuration
4. **Document Clearly** - Make it obvious that persistence is automatic

## Changes

### BrowserExecutor Agent Updates

#### Added Default Profile Constant

```python
class BrowserExecutorAgent(BaseSwarmAgent):
    AGENT_NAME = "BrowserExecutor"
    SIGNATURE_CLASS = BrowserExecutorSignature
    
    # Default profile for persistent sessions
    DEFAULT_PROFILE = "default_session"  # NEW
```

#### Updated System Prompt

**Added DEFAULT SESSION PERSISTENCE section:**

```
DEFAULT SESSION PERSISTENCE:
• By DEFAULT, always use initialize_browser_with_profile() instead of initialize_browser()
• Default profile name: 'default_session' (use this unless user specifies another)
• This AUTOMATICALLY persists authentication, cookies, and browser state
• Users don't need to ask for persistence - it's the default behavior!
• Profile location: ~/.browser_executor/profiles/default_session/
• Only use regular initialize_browser() if user explicitly asks for NO persistence
```

**Updated WORKFLOW to use profiles by default:**

```
WORKFLOW:
1. Initialize browser with PERSISTENT PROFILE using initialize_browser_with_profile('default_session', headless=...)
2. Navigate to target URL...
[rest of workflow]
7. Close browser when done (profile auto-saves!)
```

**Updated BEST PRACTICES:**

```
BEST PRACTICES:
• ALWAYS start with initialize_browser_with_profile('default_session', headless=...) by default
• Session persistence is automatic - users get this by default!
[rest of best practices]
```

**Enhanced AUTHENTICATION & SESSION PERSISTENCE:**

```
AUTHENTICATION & SESSION PERSISTENCE:
• PERSISTENCE IS AUTOMATIC! Always use initialize_browser_with_profile() by default
• Default profile: 'default_session' (or user-specified profile name)
• NEVER delete cookies unless explicitly requested
• Authentication persists across runs automatically with profiles
• Users authenticate ONCE and stay logged in forever!
```

**Added EXAMPLES section:**

```
EXAMPLES:
1. Simple task (automatic persistence):
   initialize_browser_with_profile('default_session', headless=False)
   navigate_to_url('https://example.com')
   # Authentication from previous run is already there!

2. Named profile for specific use case:
   initialize_browser_with_profile('whatsapp_work', headless=False)
   # This profile keeps separate WhatsApp work authentication

3. No persistence (rare, only if explicitly requested):
   initialize_browser(headless=True)
   # Fresh browser, no saved state
```

### Example Updates

#### Before (Verbose)

```python
instruction = """
Demonstrate WhatsApp authentication persistence:

1. Initialize browser with PERSISTENT PROFILE named "whatsapp_session"
   Use: initialize_browser_with_profile("whatsapp_session", headless=False)
   IMPORTANT: headless=False so you can see and scan QR code if needed!

2. Navigate to https://web.whatsapp.com

3. Check if already logged in:
   - If QR code shows: Wait for user to scan it (authentication will be saved)
   - If already logged in: Great! Authentication persisted from last run!

[... 15 more lines of detailed instructions ...]
"""
```

#### After (Simple)

```python
instruction = """
Open WhatsApp Web and check authentication status:

1. Open web.whatsapp.com
2. Check if already authenticated (if QR code shows, wait for user to scan)
3. Verify you can see chats
4. Take a screenshot named "whatsapp_session.png"

Note: The browser will automatically use a persistent profile, so authentication
will be saved and restored across runs. You only need to scan QR code once!
"""
```

**Reduction:** From 25+ lines to 8 lines - **70% less boilerplate!**

## Benefits

### For Users

1. ✅ **Simpler Instructions** - Just say what you want to do, not how to persist it
2. ✅ **Less Cognitive Load** - Don't need to understand profiles/persistence
3. ✅ **Can't Forget** - Persistence happens automatically
4. ✅ **Intuitive** - Works like regular browsers (Chrome, Firefox, etc.)
5. ✅ **Less Typing** - No boilerplate about profiles in every instruction

### For Developers

1. ✅ **Fewer Support Questions** - "How do I persist sessions?"
2. ✅ **Better Default** - Persistence is what people expect
3. ✅ **Cleaner Examples** - Less explanation needed
4. ✅ **Professional** - Matches industry expectations

### Comparison

| Aspect | Before | After |
|--------|--------|-------|
| Instruction length | 25+ lines | 8 lines |
| Boilerplate | High | Minimal |
| User knowledge required | Profiles, paths, functions | Just the task |
| Chance of forgetting persistence | High | Zero |
| Matches browser behavior | No | Yes |

## User Experience

### Before: Multi-Step Mental Model

```
User thinks:
1. "I want to open WhatsApp"
2. "Wait, I need persistence"
3. "How do I specify a profile?"
4. "What should I name it?"
5. "Where is it saved?"
6. "Do I use headless=True or False?"
7. Finally writes 25-line instruction
```

### After: Natural Expression

```
User thinks:
1. "I want to open WhatsApp"
2. Writes simple instruction
3. Done!

The agent handles persistence automatically.
```

## Behavior Examples

### Example 1: WhatsApp

**User instruction:**
```
Open web.whatsapp.com
```

**What the agent does:**
```python
# Automatically uses persistent profile
initialize_browser_with_profile('default_session', headless=False)
navigate_to_url('https://web.whatsapp.com')
# Authentication from last run is already there!
```

**First run:** User scans QR code  
**Second run:** Already logged in ✨

### Example 2: Multiple Accounts

**User instruction:**
```
Open WhatsApp Web using my work account profile
```

**What the agent does:**
```python
# Agent understands to use a named profile
initialize_browser_with_profile('whatsapp_work', headless=False)
navigate_to_url('https://web.whatsapp.com')
```

**Result:** Work account authentication persists separately from personal

### Example 3: Fresh Session (Rare)

**User instruction:**
```
Open example.com without any saved session (fresh browser)
```

**What the agent does:**
```python
# User explicitly requested no persistence
initialize_browser(headless=True)
navigate_to_url('https://example.com')
```

**Result:** Fresh browser, no cookies

## Implementation Details

### Profile Management

**Default profile location:**
```
~/.browser_executor/profiles/default_session/
```

**What gets saved automatically:**
- Cookies (authentication tokens)
- Local storage
- Session storage  
- Browser history
- Form autofill data
- Site permissions
- Browser settings

### Agent Decision Logic

The agent's system prompt now teaches it to:

1. **Default case**: Use `initialize_browser_with_profile('default_session', ...)`
2. **Named profile**: If user mentions "work", "personal", etc., use that name
3. **No persistence**: Only if user explicitly asks for "fresh" or "no session"

### Backward Compatibility

Old instructions still work! If user explicitly specifies:
```
initialize_browser_with_profile("whatsapp_session", ...)
```

The agent will use that profile name instead of the default.

## Security Considerations

### Profile Storage

- **Location:** `~/.browser_executor/profiles/`
- **Permissions:** User-only access (0700)
- **Contents:** Same as regular browser profile

### Best Practices

1. ✅ **Separate profiles** for different accounts/uses
2. ✅ **Named profiles** for sensitive accounts (banking, etc.)
3. ✅ **Default profile** for general use
4. ✅ **Fresh browser** (no profile) for one-time tasks

### Example: Banking

```
Open my bank website using the secure_banking profile
```

The agent will use `initialize_browser_with_profile('secure_banking', ...)` keeping banking auth separate from default profile.

## Migration Guide

### For Existing Code

**Old code:**
```python
instruction = """
1. Initialize browser with profile "my_profile"
   Use: initialize_browser_with_profile("my_profile", headless=False)
2. Navigate to site
"""
```

**New code:**
```python
instruction = """
Open the site using my_profile
"""
```

The agent figures out the profile name from your natural language!

### For Documentation

Update docs to emphasize:
- ✅ Persistence is automatic
- ✅ Just describe what you want
- ✅ Agent handles the details

## Consequences

### Positive

1. ✅ **Dramatically simpler user experience**
2. ✅ **70% less boilerplate in instructions**
3. ✅ **Matches user expectations** (like regular browsers)
4. ✅ **Fewer errors** (can't forget to enable persistence)
5. ✅ **Better onboarding** (less to explain)
6. ✅ **More professional** (industry standard behavior)

### Negative

1. ⚠️ Users might not realize sessions are persisted
2. ⚠️ Default profile might accumulate data from different sites
3. ⚠️ Need to document how to use fresh browser if needed

### Mitigation

- Document default persistence behavior clearly
- Provide examples of using named profiles for separation
- Explain how to request fresh browser when needed

## Future Enhancements

### Potential Improvements

1. **Profile Auto-Naming** - Agent creates profiles based on site/task
   ```
   "Open Gmail" → profile: 'gmail'
   "Open LinkedIn" → profile: 'linkedin'
   ```

2. **Profile Management Commands**
   ```
   "List my browser profiles"
   "Delete the old_test profile"
   "Switch to work profile"
   ```

3. **Profile Encryption** - Encrypt sensitive profiles
   ```python
   initialize_browser_with_profile('banking', encrypted=True, password='...')
   ```

4. **Profile Sync** - Sync profiles across machines
   ```
   Profiles saved to cloud, available everywhere
   ```

## Testing

### Verify Default Behavior

```bash
cd /Users/anshulchauhan/Tech/term

# First run - simple instruction
poetry run python surface/example_browser_simple.py

# Check profile was created
ls ~/.browser_executor/profiles/default_session/

# Second run - should reuse session
poetry run python surface/example_browser_simple.py
```

### Verify Named Profiles

```python
instruction = "Open WhatsApp using work_account profile"
# Should create/use ~/.browser_executor/profiles/work_account/
```

### Verify Fresh Browser

```python
instruction = "Open example.com with a fresh browser (no saved session)"
# Should use initialize_browser() without profile
```

## Documentation Updates

Updated the following files:

1. ✅ `surface/src/surface/agents/browser_executor.py` - System prompt
2. ✅ `surface/example_browser_simple.py` - Simplified example
3. ✅ `docs/adr/browser-executor-default-persistence.md` - This ADR
4. 📝 TODO: Update `surface/BROWSER_PERSISTENCE_GUIDE.md`
5. 📝 TODO: Update `surface/WHATSAPP_PERSISTENCE_HOWTO.md`
6. 📝 TODO: Update `surface/FILE_OUTPUT_GUIDE.md`

## Related ADRs

- [Browser Authentication Persistence](browser-authentication-persistence.md)
- [Browser Executor Examples](browser-executor-examples.md)
- [Browser Executor File Output](browser-executor-file-output.md)

## References

- Browser Profile Management (Chrome, Firefox)
- User Experience Best Practices
- Convention over Configuration principle

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Prompted by:** User question "why i need to send this in prompt can i not make it default"  
**Implementation:** Complete  
**Files Modified:**
- `surface/src/surface/agents/browser_executor.py`
- `surface/example_browser_simple.py`
