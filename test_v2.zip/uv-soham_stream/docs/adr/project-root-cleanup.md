# ADR: Project Root Cleanup

## Status
Accepted

## Context
The project root directory contained numerous documentation and temporary files that cluttered the workspace and made it difficult to identify essential configuration files. Following the project's modular structure guidelines, these files needed to be organized into appropriate folders.

## Decision
Reorganized all files from the project root into their respective folders:

### Files Moved to `docs/adr/` (ADR Documentation)
- `WEBSOCKET_FIX_APPLIED.md` → `docs/adr/websocket-fix-applied.md`
- `WEBSOCKET_REAL_FIX.md` → `docs/adr/websocket-real-fix.md`
- `ASYNC_BROADCAST_FIX.md` → `docs/adr/async-broadcast-fix.md`
- `BROWSER_SEPARATE_WINDOW_EXPLAINED.md` → `docs/adr/browser-separate-window-explained.md`
- `IMPLEMENTATION_COMPLETE.md` → `docs/adr/implementation-complete.md`
- `CDP_EMBEDDING_IMPLEMENTATION_COMPLETE.md` → `docs/adr/cdp-embedding-implementation-complete.md`
- `CDP_RESTART_REQUIRED.md` → `docs/adr/cdp-restart-required.md`
- `FINAL_FIX_PYTHON_PATH.md` → `docs/adr/final-fix-python-path.md`
- `CDP_STARTUP_INITIALIZATION.md` → `docs/adr/cdp-startup-initialization.md`
- `BROWSERVIEW_POSITIONING_FIX.md` → `docs/adr/browserview-positioning-fix.md`
- `ELECTRON_DEVTOOLS_ENABLED.md` → `docs/adr/electron-devtools-enabled.md`
- `TEST_AGENT_EMBEDDING.md` → `docs/adr/test-agent-embedding.md`
- `AGENT_EMBEDDING_WORKING.md` → `docs/adr/agent-embedding-working.md`
- `BROWSER_VIEW_BUTTON.md` → `docs/adr/browser-view-button.md`

### Files Moved to `docs/` (General Documentation)
- `QUICK_START_ELECTRON.md` → `docs/QUICK_START_ELECTRON.md`
- `ELECTRON_UV_MIGRATION.md` → `docs/ELECTRON_UV_MIGRATION.md`

### Files Moved to `working/` (Temporary/Output Files)
- `output.txt` → `working/output.txt`

### Files Moved to `scripts/` (Scripts)
- `uv.py` → `scripts/uv.py`

### Files Kept in Root (Essential Configuration)
- `README.md` - Project readme
- `pyproject.toml` - Python project configuration
- `uv.lock` - UV package lock file
- `poetry.lock` - Poetry lock file
- `build-requirements.txt` - Build requirements
- `.gitignore` - Git ignore rules
- `.gitmodules` - Git submodules configuration

## Consequences

### Positive
- Clean and organized project root with only essential configuration files
- All ADR documentation consolidated in `docs/adr/` following project conventions
- Improved discoverability of documentation
- Easier to identify project configuration files
- Follows established project structure guidelines

### Negative
- Any hardcoded paths referencing the old locations will need to be updated
- Git history for moved files will require `--follow` flag to trace

## Notes
- All file moves preserve git history
- Naming convention changed from `UPPERCASE_WITH_UNDERSCORES.md` to `lowercase-with-hyphens.md` for consistency with existing ADR files
- The `working/` folder serves as a temporary workspace for output and intermediate files
