# ADR: TerminalExecutor Agent Implementation

**Date:** 2026-01-30  
**Status:** Implemented

## Context

Following the successful implementation of `BrowserExecutorAgent`, we need a similar specialized agent for terminal automation tasks. Many workflows require systematic command execution, log analysis, script running, and system operations that would benefit from a dedicated terminal automation agent.

### User Request

> "@surface/src/surface/agents/browser_executor.py now create a similar agent called terminal_executor using terminal tools just like browser executor"

## Decision

**Create a new `TerminalExecutorAgent`** similar to `BrowserExecutorAgent` but specialized for terminal automation and command execution.

### Why This Approach?

1. **Consistency** - Follows the same pattern as BrowserExecutor
2. **Specialization** - Focused tools for terminal operations only
3. **Automatic Features** - Session persistence, compression retry, file output
4. **Clear Purpose** - Dedicated agent for command-line automation
5. **No Tool Overlap** - Terminal tools only (no browser, no web search)

## Implementation

### 1. Created TerminalExecutorSignature

**File:** `surface/src/surface/signatures/terminal_executor_signature.py`

```python
class TerminalExecutorSignature(dspy.Signature):
    """Execute terminal automation tasks: command execution, 
    shell scripting, system operations."""

    instruction: str = dspy.InputField(
        desc="The terminal automation task to complete"
    )

    terminal_state: str = dspy.InputField(
        desc="Current terminal output and state"
    )

    conversation_history: str = dspy.InputField(
        desc="Previous conversation context",
        default=""
    )

    analysis: str = dspy.OutputField(
        desc="Analysis of the terminal task and requirements"
    )

    plan: str = dspy.OutputField(
        desc="Step-by-step plan for command execution sequence"
    )

    commands: str = dspy.OutputField(
        desc="JSON array of terminal commands to execute"
    )

    task_complete: bool = dspy.OutputField(
        desc="True when terminal automation task is fully completed"
    )

    reasoning: str = dspy.OutputField(
        desc="Technical reasoning for the command execution approach"
    )

    collaboration_actions: str = dspy.OutputField(
        desc="JSON array of collaboration actions",
        default="[]"
    )
```

**Key Features:**
- Structured inputs for instruction and terminal state
- Step-by-step planning outputs
- Command execution in JSON format
- Collaboration support

### 2. Created TerminalExecutorAgent

**File:** `surface/src/surface/agents/terminal_executor.py`

```python
class TerminalExecutorAgent(BaseSwarmAgent):
    """TerminalExecutor: Terminal automation and command execution specialist."""

    AGENT_NAME = "TerminalExecutor"
    SIGNATURE_CLASS = TerminalExecutorSignature
    
    DEFAULT_SESSION = "surface_default_terminal"
    
    TOOLS = [
        initialize_terminal,
        close_terminal,
        send_terminal_command,
        get_terminal_state,
        get_incremental_output
    ]
```

**Tools Available:**
- `initialize_terminal` - Start terminal session (auto-initialized)
- `close_terminal` - Clean session termination
- `send_terminal_command` - Execute shell commands
- `get_terminal_state` - Get current terminal output
- `get_incremental_output` - Get new output since last check

### 3. Comprehensive System Prompt

The agent has extensive guidance on:

**Terminal Capabilities:**
- Command execution strategies
- File and directory operations
- Process management
- Log analysis and parsing
- Multi-step command workflows
- Environment and path management

**Command Types Covered:**
- File operations: ls, cat, grep, find, cp, mv, rm
- System info: ps, top, df, free, uname, hostname
- Networking: curl, wget, ping, netstat, dig
- Package management: apt, yum, brew, pip, npm
- Process control: kill, pkill, jobs, bg, fg
- Text processing: grep, sed, awk, cut, sort, uniq
- Compression: tar, gzip, zip, unzip
- Git operations: clone, pull, push, commit, status
- Script execution: bash, python, node

**Best Practices:**
- Check command output status
- Use appropriate timeouts
- Handle multi-line output
- Parse structured output
- Chain commands for efficiency
- Monitor long-running processes
- Clean up resources

**Timeout Guidelines:**
```python
# Quick commands (ls, pwd): duration=1-2s
# File operations (cat, grep): duration=2-5s
# Network ops (curl, wget): duration=10-30s
# Package install (apt, pip): duration=30-120s
# Long builds: duration=120+s
```

### 4. Automatic Features

Like BrowserExecutor, TerminalExecutor includes:

#### Session Persistence
```python
# Terminal auto-initializes on first command
send_terminal_command("ls -la")  # No explicit init needed!

# State persists across commands
send_terminal_command("cd /tmp")
send_terminal_command("pwd")  # Still in /tmp
```

#### Compression Retry
- Automatic handling of context length errors
- Intelligent compression using AgenticCompressor
- Trajectory preservation across retries
- Up to 3 retry attempts

#### File Output
- Instructions saved to timestamped files
- Output saved in both TXT and JSON formats
- Working directory: `surface/working/terminal_outputs/`

### 5. Example Implementation

**File:** `surface/examples/example_terminal_simple.py`

```python
from surface.agents.terminal_executor import TerminalExecutorAgent

# Configure DSPy
dspy.settings.configure(lm=dspy_lm)

# Create agent
agent = TerminalExecutorAgent(max_iters=50)

# Simple instruction
instruction = """
Analyze the current directory:
1. Show the current working directory
2. List all Python files
3. Count how many Python files there are
4. Show the size of the largest Python file
5. Provide a brief summary
"""

# Execute - auto-initialization happens!
result = agent(
    instruction=instruction,
    terminal_state="",
    conversation_history=""
)
```

**Output files:**
- `instruction_TIMESTAMP.txt` - Saved instruction
- `output_TIMESTAMP.txt` - Human-readable output
- `output_TIMESTAMP.json` - Structured JSON output

### 6. Updated Exports

**`surface/src/surface/signatures/__init__.py`:**
```python
from .terminal_executor_signature import TerminalExecutorSignature

__all__ = [
    # ... other signatures ...
    "TerminalExecutorSignature"
]
```

**`surface/src/surface/agents/__init__.py`:**
```python
# TerminalExecutor is optional (requires pexpect)
try:
    from .terminal_executor import TerminalExecutorAgent
    _TERMINAL_EXECUTOR_AVAILABLE = True
except ImportError:
    TerminalExecutorAgent = None
    _TERMINAL_EXECUTOR_AVAILABLE = False

if _TERMINAL_EXECUTOR_AVAILABLE:
    __all__.append("TerminalExecutorAgent")
```

## Benefits

### 1. Specialized Terminal Automation

**Before:**
```python
# CodeMaster had terminal tools + web search tools
# Generic agent for all coding tasks
```

**After:**
```python
# TerminalExecutor has ONLY terminal tools
# Focused on command execution and system operations
```

### 2. Clear Separation of Concerns

| Agent | Tools | Purpose |
|-------|-------|---------|
| **BrowserExecutor** | Browser tools only | Web automation |
| **TerminalExecutor** | Terminal tools only | Command execution |
| **CodeMaster** | Terminal + Web | General coding |
| **DataMind** | Terminal + Web | ML/Data science |

### 3. Automatic Features

All built-in, no configuration:
- ✅ Session persistence
- ✅ Compression retry
- ✅ File output
- ✅ Trajectory preservation

### 4. Consistent Pattern

Same structure as BrowserExecutor:
- Signature with structured inputs/outputs
- Specialized system prompt
- Tool-specific focus
- Example files
- Comprehensive documentation

## Usage Examples

### Simple Command Execution

```python
from surface.agents.terminal_executor import TerminalExecutorAgent

agent = TerminalExecutorAgent(max_iters=50)

result = agent(
    instruction="List all Python files and count them",
    terminal_state="",
    conversation_history=""
)
```

### Multi-Step Workflow

```python
instruction = """
1. Create a temporary directory
2. Download a file into it
3. Extract the archive
4. List the contents
5. Clean up
"""

result = agent(instruction=instruction, terminal_state="")
```

### Log Analysis

```python
instruction = """
Analyze the system logs:
1. Check /var/log/syslog for errors in the last hour
2. Count how many errors occurred
3. Show the most common error messages
4. Provide a summary
"""

result = agent(instruction=instruction, terminal_state="")
```

### System Monitoring

```python
instruction = """
Monitor system resources:
1. Show current CPU usage
2. Show memory usage
3. List top 5 processes by CPU
4. Check disk space
5. Summarize system health
"""

result = agent(instruction=instruction, terminal_state="")
```

## Comparison: TerminalExecutor vs BrowserExecutor

| Aspect | TerminalExecutor | BrowserExecutor |
|--------|------------------|-----------------|
| **Primary Tools** | pexpect terminal | Selenium browser |
| **Session Type** | Shell session | Browser session |
| **Persistence** | Shell state | Cookies/profile |
| **Auto-init** | ✅ Yes | ✅ Yes |
| **Compression** | ✅ Yes | ✅ Yes |
| **File Output** | ✅ Yes | ✅ Yes |
| **Use Cases** | Commands, scripts | Web automation |
| **Dependencies** | pexpect | selenium |
| **System Deps** | None | Browser drivers |

## Testing

### Run Example

```bash
cd /Users/anshulchauhan/Tech/term

# Run terminal automation example
poetry run python surface/examples/example_terminal_simple.py
```

### Expected Output

```
================================================================================
🖥️  Terminal Automation with Automatic Persistence
================================================================================

✨ Session persistence is AUTOMATIC!
   Commands execute in persistent shell
   Working directory and state persist automatically
   No configuration needed - just works!

================================================================================

🚀 Starting terminal automation with persistent session...
📋 Task: Directory analysis with terminal commands

📄 Instruction saved to: surface/working/terminal_outputs/instruction_20260130_143000.txt

================================================================================
✅ TERMINAL AUTOMATION COMPLETED!
================================================================================

📊 Result Summary:
--------------------------------------------------------------------------------
... command execution results ...
--------------------------------------------------------------------------------

💾 Output (TXT) saved to: surface/working/terminal_outputs/output_20260130_143000.txt
💾 Output (JSON) saved to: surface/working/terminal_outputs/output_20260130_143000.json

================================================================================
🎉 TERMINAL AUTOMATION WITH AUTOMATIC FEATURES
================================================================================

✨ Features that worked automatically:
   ✅ Session persistence - commands in same shell
   ✅ Compression retry - handled context length (if needed)
   ✅ File output - saved instruction and results

💡 Run again to see session state persists!
================================================================================
```

## Implementation Checklist

- ✅ Created TerminalExecutorSignature
- ✅ Created TerminalExecutorAgent with comprehensive system prompt
- ✅ Configured terminal tools (5 tools)
- ✅ Added automatic session persistence
- ✅ Inherits compression retry from BaseSwarmAgent
- ✅ Created example_terminal_simple.py
- ✅ Updated signatures/__init__.py
- ✅ Updated agents/__init__.py
- ✅ Created ADR documentation
- ✅ Documented usage examples
- ✅ Tested basic functionality

## Future Enhancements

### Potential Improvements

1. **Enhanced Output Parsing**
   - Structured log parsing
   - JSON/CSV output extraction
   - Error pattern recognition

2. **Command Templating**
   - Pre-defined command templates
   - Parameterized commands
   - Safe command validation

3. **Process Monitoring**
   - Long-running process tracking
   - Progress bars for downloads
   - Resource usage monitoring

4. **Script Generation**
   - Auto-generate shell scripts
   - Python script execution
   - Multi-language support

5. **Error Recovery**
   - Automatic retry with backoff
   - Fallback commands
   - State recovery

## Related ADRs

- [Terminal Tools Pexpect Migration](terminal-tools-pexpect-migration.md)
- [Hardcoded Profile Transparent Persistence](hardcoded-profile-transparent-persistence.md)
- [Built-in Automatic Compression](built-in-automatic-compression.md)

## References

- BrowserExecutor Agent: `surface/src/surface/agents/browser_executor.py`
- Terminal Tools: `surface/src/surface/tools/terminal_tools.py`
- pexpect Documentation: https://pexpect.readthedocs.io/
- BaseSwarmAgent: `surface/src/surface/agents/base_agent.py`

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Prompted by:** User: "now create a similar agent called terminal_executor using terminal tools just like browser executor"  
**Implementation:** Complete  
**Files Created:**
- `surface/src/surface/signatures/terminal_executor_signature.py` - Signature class
- `surface/src/surface/agents/terminal_executor.py` - Agent implementation
- `surface/examples/example_terminal_simple.py` - Example usage
- `docs/adr/terminal-executor-agent-implementation.md` - This ADR

**Files Modified:**
- `surface/src/surface/signatures/__init__.py` - Added export
- `surface/src/surface/agents/__init__.py` - Added export with optional import

**Result:** New TerminalExecutor agent with automatic session persistence, compression retry, and file output! 🎉
