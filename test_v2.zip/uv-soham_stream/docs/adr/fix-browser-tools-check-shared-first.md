# ADR: Fix Browser Tools to Check Shared Instance First

**Status:** Fixed  
**Date:** 2026-01-30  
**Context:** Browser initialization was creating new instances despite shared browser

---

## Problem

Even after implementing the property bag pattern with `set_shared_browser()`, agents were still creating new browser instances:

```
Integration: Create shared browser → set_shared_browser(driver)
Agent Task 1: Calls initialize_browser() → Creates NEW browser ❌
Agent Task 2: Calls initialize_browser() → Creates ANOTHER new browser ❌
```

**Root Cause**: The `initialize_browser()` and `initialize_browser_with_profile()` functions didn't check if a shared browser already exists. They always created a new browser instance.

---

## Solution

Modified browser initialization functions to check for shared browser **first**:

### Before (Always Creates New)

```python
def initialize_browser(...):
    # Always creates new browser with profile
    return initialize_browser_with_profile(
        profile_name="default_session",
        ...
    )
```

### After (Uses Shared if Exists)

```python
def initialize_browser(...):
    global _shared_browser_driver
    
    # 🆕 Check for shared browser first
    if _shared_browser_driver is not None:
        logger.info(f"🔄 Using existing shared browser: {id(_shared_browser_driver)}")
        return {
            "status": "success",
            "message": "Using shared browser instance",
            "is_shared": True,
            "browser_id": id(_shared_browser_driver),
            "current_url": _shared_browser_driver.current_url
        }
    
    # No shared browser, create new one
    logger.info("🆕 No shared browser found, creating new one")
    return initialize_browser_with_profile(...)
```

Same fix applied to `initialize_browser_with_profile()`.

---

## Flow After Fix

```
Integration:
  1. Create shared browser → webdriver.Chrome()
  2. Register it → set_shared_browser(driver)

Agent Task 1:
  1. Agent calls initialize_browser()
  2. ✅ Finds shared browser
  3. ✅ Returns shared instance (no new browser created)
  4. Uses shared browser → Login to website

Agent Task 2:
  1. Agent calls initialize_browser()
  2. ✅ Finds SAME shared browser
  3. ✅ Returns shared instance (no new browser created)
  4. Uses shared browser → ✅ Still logged in!
```

---

## Implementation

### Modified Functions

1. **`initialize_browser()`**
   - Added check for `_shared_browser_driver` at the start
   - Returns shared browser info if exists
   - Only creates new browser if no shared one exists

2. **`initialize_browser_with_profile()`**
   - Added check for `_shared_browser_driver` at the start
   - Returns shared browser (ignores profile parameter)
   - Only creates new browser if no shared one exists

### Return Value When Using Shared Browser

```python
{
    "status": "success",
    "message": "Using shared browser instance",
    "is_shared": True,  # ← Indicates this is the shared browser
    "browser_id": id(_shared_browser_driver),
    "current_url": _shared_browser_driver.current_url
}
```

The agent receives confirmation it's using the shared browser.

---

## Benefits

✅ **Prevents Duplicate Browsers**: Agent tools reuse shared instance  
✅ **State Persistence**: Login, cookies, tabs all maintained  
✅ **Resource Efficiency**: One browser instead of N browsers  
✅ **Transparent to Agent**: Agent code doesn't need to change  
✅ **Safe Fallback**: Still creates browser if no shared one exists  

---

## Log Output

### Before Fix
```
2026-01-30 23:25:40 | 🌐 Initializing browser with profile: default_session
2026-01-30 23:25:41 | ✅ Browser initialized with profile: default_session
                     ← Created NEW browser despite shared one existing!
```

### After Fix
```
2026-01-30 23:26:15 | 🔄 Using existing shared browser instance: 140123456789
2026-01-30 23:26:15 | Shared browser is alive: True
                     ← Using shared browser! ✅
```

---

## Testing

Verify shared browser reuse:

```bash
./scripts/run_solve_task.sh "Visit example.com, then visit google.com"
```

Check logs - should see:
- First task: "Using existing shared browser"
- Second task: "Using existing shared browser"
- No "Initializing browser with profile" messages

---

## Files Changed

- `surface/src/surface/tools/browser_tools.py`
  - Modified `initialize_browser()` - Added shared browser check
  - Modified `initialize_browser_with_profile()` - Added shared browser check

---

## Related

- `docs/adr/property-bag-shared-instances.md` - Overall property bag pattern
- `surface_synapse/integration.py` - Where shared browser is created

---

## Summary

Fixed browser tools to check for shared browser instance **before** creating a new one. This ensures the property bag pattern works correctly and agents reuse the same browser across all tasks, maintaining state and authentication.
