# ADR: Fix Browser View Positioning in Center Grid

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Browser view layout in Electron UI

## Problem

The browser view was displaying as a **full-screen overlay** instead of being contained within the **center grid section** of the 3-column workspace layout.

**User Issue:**
> "why is browser view separate page than section in main page"

**Root Cause:**
The `.agent-view` CSS had `position: absolute` with `top: 0; left: 0; right: 0; bottom: 0`, which made it break out of the normal document flow and overlay the entire viewport.

## Layout Structure

```
┌─────────────────────────────────────────────────────┐
│ Title Bar (Toolbar)                                 │
├──────────┬──────────────────────────┬───────────────┤
│          │                          │               │
│  Left    │  Center Grid (Agents)    │  Right        │
│  Sidebar │  ← Browser should be     │  Sidebar      │
│  (Tasks) │     here, not fullscreen │  (Memory)     │
│          │                          │               │
└──────────┴──────────────────────────┴───────────────┘
```

## Solution

### Change 1: Agent View Positioning

**File:** `electron-app/src/renderer/css/agent-views.css`

```css
/* Before */
.agent-view {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}

/* After */
.agent-view {
  position: relative;
  /* Removed absolute positioning */
}
```

### Change 2: Container Positioning

**File:** `electron-app/src/renderer/css/styles.css`

```css
.agents-grid-workspace {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  position: relative;  /* Added to contain relative children */
}
```

## Result

✅ Browser view now stays within center grid section  
✅ Left sidebar (Tasks) remains visible  
✅ Right sidebar (Memory) remains visible  
✅ Browser view respects 3-column layout  
✅ No fullscreen overlay  

## Technical Details

### CSS Positioning Hierarchy

```
.workspace-state (grid container)
  └─ .center-workspace (grid column 2)
      └─ .agents-grid-workspace (position: relative)
          └─ .agent-view (position: relative)
              └─ Browser CDP content
```

### Why This Works

1. **`position: relative`** on `.agent-view` keeps it in the document flow
2. **`position: relative`** on `.agents-grid-workspace` creates a positioning context
3. Views stack naturally within the center column
4. Grid layout maintains 3-column structure

## Testing

**Before Fix:**
- Browser view overlays entire window
- Sidebars hidden behind browser view
- Fullscreen appearance

**After Fix:**
- Browser view contained in center section
- Sidebars visible on left and right
- Proper 3-column layout maintained

## Related

- Browser embedding: `docs/CDP_BROWSER_EMBEDDING_COMPLETE.md`
- Agent view system: `electron-app/src/renderer/js/agent-view-manager.js`
