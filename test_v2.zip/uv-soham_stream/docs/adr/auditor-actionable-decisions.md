# ADR: Auditor Actionable Decisions (Retry/Stop/Re-evaluate)

## Status
Proposed

## Context

Currently, the task-level auditor (`_run_auditor_stream()`) only returns a binary `passed`/`failed` decision with feedback. When a task fails, it's simply marked as failed via `todo.fail_task()`, and retries happen indirectly through the main loop picking up `PENDING` tasks again.

**Problem**: The auditor has rich context about WHY a task failed (test results, reasoning, confidence) but cannot make intelligent decisions about WHAT TO DO NEXT.

## Proposed Solution

Enhance the auditor to return a **strategy** (action + reasoning + execution guidance) instead of just pass/fail:

### Strategy Components

The auditor should return a comprehensive strategy that includes:
1. **Action**: What to do (pass/retry/stop/re_evaluate)
2. **Reasoning**: Why this action was chosen (strategic analysis)
3. **Execution Guidance**: How to execute the action (specific instructions)

### 1. **Retry Strategy**
- **When**: Task failed but failure is recoverable (e.g., transient error, minor issue)
- **Strategy Components**:
  - **Action**: `retry`
  - **Reasoning**: Why retry makes sense (e.g., "Network timeout, likely transient")
  - **Execution Guidance**: 
    - What feedback to inject into next attempt
    - What to change in the approach
    - Which parameters to modify
    - Expected improvements
- **Behavior**: 
  - Mark task as `PENDING` (retryable)
  - Inject strategy guidance into task context for next attempt
  - Task will be picked up by main loop in next iteration
- **Use Cases**: 
  - Network timeouts
  - Minor validation issues that can be fixed
  - Low confidence failures (< 0.6) where retry might succeed

### 2. **Stop Strategy**
- **When**: Task failed and should NOT be retried (e.g., fundamental incompatibility, impossible task)
- **Strategy Components**:
  - **Action**: `stop`
  - **Reasoning**: Why retry is futile (e.g., "Task requires capabilities not available in any actor")
  - **Execution Guidance**: 
    - What makes this task impossible
    - What would be needed to make it possible (for future reference)
    - Alternative approaches if any
- **Behavior**:
  - Mark task as `FAILED` with `attempts >= max_attempts` (permanent failure)
  - Add to `failed_tasks` set
  - Task will NOT be picked up again by main loop
- **Use Cases**:
  - Task is fundamentally impossible with current actors
  - Critical test failures that indicate design flaw
  - High confidence failures (> 0.8) where retry is unlikely to help
  - Task violates system constraints

### 3. **Re-evaluate Strategy**
- **When**: Task failed but might succeed with different breakdown/actor assignment
- **Strategy Components**:
  - **Action**: `re_evaluate`
  - **Reasoning**: Why re-evaluation is needed (e.g., "Wrong actor assigned, task needs BrowserExecutor not TerminalExecutor")
  - **Execution Guidance**:
    - Which actors should be considered (with capabilities)
    - How task should be broken down differently
    - What dependencies were wrong
    - Specific instructions for TaskBreakdownAgent
    - Specific instructions for TodoCreatorAgent
- **Behavior**:
  1. Extract original task description/context
  2. Call `TaskBreakdownAgent` with strategy guidance
  3. Call `TodoCreatorAgent` with actor suggestions from strategy
  4. Convert new `ExecutableDAG` to `MarkovianTODO` tasks
  5. Insert new tasks into TODO (replacing or alongside original)
  6. Mark original task as `SKIPPED` or `FAILED` (replaced)
- **Use Cases**:
  - Wrong actor was assigned (e.g., TerminalExecutor instead of BrowserExecutor)
  - Task needs to be broken down differently
  - Multiple actors needed for collaboration
  - Task dependencies were incorrect

## Architecture Design

### Enhanced Auditor Result Structure

```python
@dataclass
class AuditorStrategy:
    """Comprehensive strategy from auditor with action, reasoning, and execution guidance."""
    passed: bool
    reward: float
    confidence: float
    feedback: str
    
    # Strategy components
    action: str  # "pass", "retry", "stop", "re_evaluate"
    reasoning: str  # Strategic reasoning: WHY this action was chosen
    execution_guidance: Dict[str, Any]  # HOW to execute the action
    
    # Execution guidance structure (varies by action):
    # For "retry":
    #   {
    #       "feedback_to_inject": str,
    #       "approach_changes": str,
    #       "parameter_modifications": Dict,
    #       "expected_improvements": str
    #   }
    # For "stop":
    #   {
    #       "why_impossible": str,
    #       "requirements_missing": List[str],
    #       "alternative_approaches": List[str]
    #   }
    # For "re_evaluate":
    #   {
    #       "suggested_actors": List[Dict],  # [{name, capabilities, reasoning}]
    #       "breakdown_instructions": str,  # For TaskBreakdownAgent
    #       "assignment_instructions": str,  # For TodoCreatorAgent
    #       "dependency_corrections": Dict[str, List[str]]
    #   }
```

### Modified `_run_auditor_stream()` Signature

```python
async def _run_auditor_stream(
    self,
    actor_config: ActorConfig,
    result: Any,
    task: TodoItem
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Returns auditor_result event with strategy:
    {
        "type": "auditor_result",
        "passed": bool,
        "reward": float,
        "confidence": float,
        "feedback": str,
        "strategy": {
            "action": "pass" | "retry" | "stop" | "re_evaluate",
            "reasoning": str,  # Strategic reasoning for action choice
            "execution_guidance": Dict[str, Any]  # Action-specific guidance
        }
    }
    """
```

### Strategy Generation Logic (LLM-Based)

Add a new DSPy signature for strategy generation:

```python
class AuditorStrategySignature(dspy.Signature):
    """Generate comprehensive strategy (action + reasoning + execution guidance) after task validation.
    
    You are a strategic advisor. Don't just decide WHAT to do - explain WHY and HOW.
    """
    
    test_results = dspy.InputField(desc="Test results with pass/fail, reasoning, and priority")
    task_description = dspy.InputField(desc="Original task description")
    actor_assigned = dspy.InputField(desc="Actor that executed the task with capabilities")
    failure_analysis = dspy.InputField(desc="Detailed analysis of why task failed")
    available_actors = dspy.InputField(desc="List of all available actors with capabilities (JSON)")
    attempt_count = dspy.InputField(desc="How many times this task has been attempted")
    task_context = dspy.InputField(desc="Additional context: dependencies, previous outputs, etc.")
    
    action = dspy.OutputField(
        desc="One of: 'pass' (if passed), 'retry' (retry same task), 'stop' (permanent failure), 're_evaluate' (re-breakdown task)"
    )
    
    reasoning = dspy.OutputField(
        desc="""Strategic reasoning for action choice. Use compound logical reasoning:
        - Analyze test results and failure patterns
        - Consider actor capabilities vs. task requirements
        - Evaluate retry potential vs. fundamental issues
        - Think about alternative approaches
        Explain WHY this action is optimal given the evidence."""
    )
    
    execution_guidance = dspy.OutputField(
        desc="""JSON object with action-specific execution guidance.
        
        For 'retry':
        {
            "feedback_to_inject": "Specific feedback for actor on what to change",
            "approach_changes": "How to modify the approach",
            "parameter_modifications": {"param": "value"},
            "expected_improvements": "What should improve on retry"
        }
        
        For 'stop':
        {
            "why_impossible": "Why this task cannot succeed",
            "requirements_missing": ["capability1", "capability2"],
            "alternative_approaches": ["approach1", "approach2"]
        }
        
        For 're_evaluate':
        {
            "suggested_actors": [
                {"name": "ActorName", "capabilities": ["cap1"], "reasoning": "why this actor"}
            ],
            "breakdown_instructions": "Specific instructions for TaskBreakdownAgent",
            "assignment_instructions": "Specific instructions for TodoCreatorAgent",
            "dependency_corrections": {"task_id": ["corrected_deps"]}
        }
        
        For 'pass': {} (empty)
        """
    )
```

### Integration Points

#### 1. In `conductor.py` (line ~3643)

```python
# After auditor completes
auditor_passed, auditor_reward, auditor_feedback = None, 0.0, ""
auditor_action = None  # NEW
auditor_action_reasoning = None  # NEW
re_evaluation_context = None  # NEW

async for auditor_event in self._run_auditor_stream(...):
    if auditor_event.get("type") == "auditor_result":
        auditor_passed = auditor_event.get("passed")
        auditor_reward = auditor_event.get("reward", 0.0)
        auditor_feedback = auditor_event.get("feedback", "")
        auditor_action = auditor_event.get("action", "retry" if not auditor_passed else "pass")  # NEW
        auditor_action_reasoning = auditor_event.get("action_reasoning", "")  # NEW
        re_evaluation_context = auditor_event.get("re_evaluation_context")  # NEW

# Handle action
if auditor_passed:
    # Existing success handling
    ...
elif auditor_action == "retry":
    # Mark as PENDING for retry (with feedback injection)
    self.todo.mark_for_retry(task.task_id, auditor_feedback)
elif auditor_action == "stop":
    # Permanent failure
    self.todo.fail_task(task.task_id, auditor_feedback, permanent=True)
elif auditor_action == "re_evaluate":
    # Trigger re-evaluation flow
    async for event in self._re_evaluate_task_stream(task, re_evaluation_context):
        yield event
```

#### 2. New Method: `_re_evaluate_task_stream()`

```python
async def _re_evaluate_task_stream(
    self,
    failed_task: SubtaskState,
    re_evaluation_context: Dict
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Re-evaluate a failed task by sending it back through task breakdown flow.
    
    Flow:
    1. Extract original goal/context from failed task
    2. Add failure analysis to context
    3. Call TaskBreakdownAgent with enhanced context
    4. Call TodoCreatorAgent with updated actor suggestions
    5. Convert new ExecutableDAG to tasks
    6. Insert new tasks into TODO
    7. Mark original task as replaced
    """
    yield {"module": "Synapse.core.conductor", "message": f"Re-evaluating task {failed_task.task_id}..."}
    
    # Extract original goal
    original_goal = failed_task.description
    failure_notes = re_evaluation_context.get("re_evaluation_notes", "")
    
    # Enhance goal with failure context
    enhanced_goal = f"""
{original_goal}

RE-EVALUATION CONTEXT:
Previous attempt failed with: {failure_notes}
Suggested improvements: {re_evaluation_context.get("suggested_actors", [])}
"""
    
    # Call TaskBreakdownAgent
    task_dag = self.task_breakdown_agent.forward(implementation_plan=enhanced_goal)
    
    # Get suggested actors from context
    suggested_actors = re_evaluation_context.get("suggested_actors", [])
    
    # Call TodoCreatorAgent with actor hints
    executable_dag = self.todo_creator_agent.create_executable_dag(
        dag=task_dag,
        available_actors=self._get_actor_dicts(),
        actor_hints=suggested_actors  # NEW parameter
    )
    
    # Convert to TODO tasks
    new_task_ids = []
    for task_id, task in executable_dag.assignments.items():
        new_task_id = f"{failed_task.task_id}_reeval_{task_id}"
        self.todo.add_task(
            task_id=new_task_id,
            description=task.description,
            actor=task.actor.name,
            depends_on=[f"{failed_task.task_id}_reeval_{dep}" for dep in task.depends_on],
            priority=failed_task.priority
        )
        new_task_ids.append(new_task_id)
    
    # Mark original as replaced
    self.todo.mark_task_replaced(failed_task.task_id, new_task_ids)
    
    yield {"module": "Synapse.core.conductor", "message": f"Re-evaluation complete: created {len(new_task_ids)} new tasks"}
```

#### 3. Enhanced `MarkovianTODO` Methods

```python
def mark_for_retry(self, task_id: str, feedback: str):
    """Mark task for retry with feedback context."""
    if task_id in self.subtasks:
        task = self.subtasks[task_id]
        task.status = TaskStatus.PENDING
        task.retry_feedback = feedback  # NEW: Store feedback for next attempt
        task.attempts += 1

def mark_task_replaced(self, old_task_id: str, new_task_ids: List[str]):
    """Mark task as replaced by new tasks."""
    if old_task_id in self.subtasks:
        task = self.subtasks[old_task_id]
        task.status = TaskStatus.SKIPPED
        task.replaced_by = new_task_ids  # NEW: Track replacement
```

## Benefits

1. **Intelligent Retry**: Auditor decides when retry makes sense vs. permanent failure
2. **Self-Correction**: Re-evaluation allows system to fix wrong actor assignments
3. **Reduced Waste**: Stop action prevents infinite retry loops
4. **Better Learning**: Action decisions provide training signal for future tasks

## Trade-offs

### Pros
- More intelligent failure handling
- Self-healing system (re-evaluation)
- Better resource utilization (stop vs. retry)
- Richer feedback loop

### Cons
- Additional LLM call for action decision (cost)
- More complex state management (replaced tasks, retry feedback)
- Potential for infinite re-evaluation loops (need safeguards)

## Safeguards

1. **Max Re-evaluations**: Limit re-evaluation attempts per task (e.g., max 2)
2. **Action Confidence Threshold**: Only re-evaluate if confidence > 0.7
3. **Retry Budget**: Track total retries across all actions
4. **Circular Dependency Detection**: Prevent re-evaluation from creating cycles

## Implementation Priority

1. **Phase 1**: Add action decision to auditor (retry/stop)
2. **Phase 2**: Implement re-evaluation flow
3. **Phase 3**: Add safeguards and monitoring
4. **Phase 4**: Learn from action decisions (RL)

## Alternative Approaches Considered

### Option A: Hardcoded Rules
- **Rejected**: Too brittle, doesn't adapt to context

### Option B: Separate Action Agent
- **Rejected**: Adds latency, auditor already has context

### Option C: User-Provided Action Policies
- **Considered**: Could be configurable, but defaults should be intelligent

## Decision

**Proceed with LLM-based action decision** integrated into auditor, with safeguards to prevent infinite loops.
