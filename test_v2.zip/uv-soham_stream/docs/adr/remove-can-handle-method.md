# ADR: Remove can_handle Method from Actor Class

**Status:** Implemented  
**Date:** 2026-01-29  
**Decision Makers:** Development Team

## Context

The `Actor` class initially had a `can_handle(task: Task)` method that pre-filtered actors based on a static task type → capability mapping:

```python
def can_handle(self, task: Task) -> bool:
    task_capability_map = {
        TaskType.SETUP: ["setup", "installation", "environment", "coding"],
        TaskType.IMPLEMENTATION: ["coding", "implementation", "programming"],
        TaskType.TESTING: ["testing", "validation", "qa"],
        # ...
    }
    required_caps = task_capability_map.get(task.task_type, [])
    return any(cap in self.capabilities for cap in required_caps)
```

This method was used to filter actors before passing them to the LLM:
```python
capable_actors = [a for a in actors if a.can_handle(task)]
```

## Decision

**Removed the `can_handle` method and pass all actors directly to the LLM for evaluation.**

The LLM now receives all available actors for every task and makes intelligent assignment decisions based on:
- Task type and description
- Actor capabilities
- Current workload
- Context and reasoning

## Rationale

### Why Remove It?

1. **Trust the LLM**: Modern LLMs (GPT-4o, GPT-4o-mini) are highly capable of matching tasks to actors based on capabilities without pre-filtering.

2. **Static Mapping Limitations**: The hardcoded mapping was rigid:
   ```python
   TaskType.SETUP: ["setup", "installation", "environment", "coding"]
   ```
   - What if an actor has "devops" but needs to do setup?
   - What if an actor has "automation" which is relevant for setup?
   - Mapping requires constant maintenance

3. **Reduced Flexibility**: Pre-filtering prevented creative assignments:
   - An actor with "scripting" could handle EXECUTION tasks but was filtered out
   - An actor with "automation" could do SETUP but wasn't included

4. **False Sense of Optimization**: While it reduced tokens per call, it:
   - Added code complexity
   - Required maintenance
   - Limited LLM's reasoning capability

5. **Simplicity**: Removing 20+ lines of mapping logic for cleaner code.

## Implementation

### Changes Made

1. **Actor Class**
   ```python
   # Before
   @dataclass
   class Actor:
       name: str
       capabilities: List[str]
       def can_handle(self, task: Task) -> bool: ...
   
   # After
   @dataclass
   class Actor:
       name: str
       capabilities: List[str]
   ```

2. **Assignment Logic**
   ```python
   # Before
   capable_actors = [a for a in actors if a.can_handle(task)]
   result = self.actor_assigner(available_actors=str(capable_actors))
   
   # After
   result = self.actor_assigner(available_actors=str(actors))
   ```

3. **Updated Documentation**
   - `TODO_CREATOR_GUIDE.md` - Removed capability mapping section
   - `docs/adr/todo-creator-agent-implementation.md` - Updated implementation details

## Consequences

### Positive

1. **Simpler Code**: Removed ~20 lines of mapping logic
2. **More Flexible**: LLM can make creative assignments
3. **Less Maintenance**: No mapping to update when adding task types
4. **Better Reasoning**: LLM sees full context and makes informed decisions
5. **Easier to Extend**: Adding new actors or task types is simpler

### Negative

1. **Higher Token Usage**: LLM sees all actors for every task
   - Before: ~2-3 actors per task
   - After: All actors (e.g., 5-10) per task
   - Impact: 2-3x more tokens per assignment call

2. **Potential Cost Increase**: 
   - Example: 50 tasks × 10 actors × 50 tokens = 25,000 tokens
   - vs: 50 tasks × 2 actors × 50 tokens = 5,000 tokens
   - Estimated cost increase: ~$0.10-0.20 per DAG (gpt-4o-mini)

3. **Slightly Slower**: More tokens = longer LLM processing time

### Mitigation

1. **Use Efficient Models**: gpt-4o-mini is cheap (~$0.15/1M input tokens)
2. **Batch Processing**: Future optimization could batch multiple tasks
3. **Caching**: Could cache actor assignments for similar tasks
4. **Monitor Costs**: Track actual cost impact in production

## Cost Analysis

### Before (with filtering)
```
50 tasks, 10 actors available, ~2-3 capable per task
- Tokens per task: ~200 (2-3 actors)
- Total tokens: 50 × 200 = 10,000
- Cost (gpt-4o-mini): ~$0.0015
```

### After (no filtering)
```
50 tasks, 10 actors available, all sent to LLM
- Tokens per task: ~500 (10 actors)
- Total tokens: 50 × 500 = 25,000
- Cost (gpt-4o-mini): ~$0.0038
```

**Increased cost per DAG: ~$0.0023 (less than a penny)**

## Alternatives Considered

### 1. Keep can_handle with Configurable Mapping
**Pros:** Flexibility + filtering  
**Cons:** Still requires maintenance, added complexity  
**Verdict:** ❌ Doesn't address core issues

### 2. LLM-Based Pre-filtering
**Pros:** Intelligent filtering  
**Cons:** Requires extra LLM call, negating cost benefits  
**Verdict:** ❌ More expensive than direct assignment

### 3. Hybrid Approach (Soft Filtering)
**Pros:** Include all actors but mark "recommended"  
**Cons:** Complex prompt engineering  
**Verdict:** ❌ Over-engineered

### 4. Remove Pre-filtering (Chosen)
**Pros:** Simple, flexible, trusts LLM  
**Cons:** Slightly higher cost  
**Verdict:** ✅ Best trade-off

## Migration Path

No breaking changes for external users. Internal changes only:
- Actors no longer need `can_handle` method
- All actors are evaluated for all tasks

## Testing

Verified removal:
```bash
✓ Actor class works without can_handle
✓ Assignment logic functions correctly
✓ LLM receives all actors
✓ No linter errors
✅ All tests passed
```

## Acceptance Criteria

- [x] Removed `can_handle` method from Actor class
- [x] Updated assignment logic to pass all actors
- [x] Updated documentation
- [x] Verified functionality works
- [x] No breaking changes
- [x] Cost impact documented

## References

- Related: `todo_creator_agent.py` implementation
- Related: `TODO_CREATOR_GUIDE.md` documentation
- Pattern: Trust LLM reasoning over hardcoded logic
- Trade-off: Simplicity + flexibility vs. token cost

## Future Considerations

If cost becomes an issue at scale:
1. Implement smart caching of assignments
2. Use lighter models for simple tasks
3. Batch multiple task assignments in one LLM call
4. Track which actors typically handle which task types and use as hints

For now, the cost increase (~$0.002 per DAG) is negligible compared to the benefits of simpler, more maintainable code.
