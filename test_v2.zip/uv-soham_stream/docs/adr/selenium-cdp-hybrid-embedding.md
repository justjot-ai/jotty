# ADR: Selenium + CDP Hybrid for Chrome Embedding

**Status:** Approved  
**Date:** 2026-02-01  
**Deciders:** A-Team (unanimous)

---

## Context

User requested Puppeteer migration to enable true Chrome instance embedding in Electron UI. Full Puppeteer migration would require 3 months of work, rewriting 2000 lines of code, and losing battle-tested Selenium features.

---

## Decision

Implement **Selenium + CDP Hybrid** approach:
- **Selenium remains PRIMARY controller** (backend agent automation)
- **Electron becomes PASSIVE viewer** (UI display via CDP)
- **Chrome instance is shared** (Selenium controls, Electron views)

---

## Architecture

```
Python Backend (Selenium) → Chrome Process ← Electron UI (CDP read-only)
        ↓                                              ↑
    Controls                                      Views Only
```

---

## Implementation

### Backend (Week 1)
```python
# browser_tools.py
def get_cdp_endpoint() -> Dict[str, Any]:
    """Expose CDP WebSocket URL for Electron."""
    return _browser_state["driver"].get_cdp_details()

def enable_electron_embedding() -> Dict[str, Any]:
    """Broadcast CDP endpoint to Electron."""
    cdp_url = get_cdp_endpoint()
    _broadcast_browser_event_sync("cdp_ready", {"ws_url": cdp_url})
    return {"status": "success", "cdp_url": cdp_url}
```

### Frontend (Week 2)
```javascript
// agent-view-manager.js
class BrowserViewHandler {
  async handleCdpReady(data) {
    this.cdpClient = await CDP({ target: data.ws_url });
    await this.cdpClient.Page.enable();
    // Subscribe to events, display screenshots
    // NEVER send commands
  }
}
```

---

## Consequences

### Positive
- ✅ True Chrome embedding in Electron
- ✅ Keep all Selenium features
- ✅ 4 weeks vs 3 months
- ✅ Low risk (additive, not replacement)

### Negative
- ❌ Two control mechanisms (managed via strict boundaries)
- ❌ Additional CDP dependency in Electron

---

## Timeline
- Week 1: Backend CDP exposure
- Week 2: Electron CDP client
- Week 3: Integration & testing
- Week 4: Deployment & docs

---

## Alternatives Rejected

1. **Full Playwright Migration** - 3 months, high risk, loses features
2. **VNC/Screen Capture** - Platform-specific, latency issues
3. **Screenshot Streaming** - User explicitly rejected
4. **Separate Window** - User wants true embedding
