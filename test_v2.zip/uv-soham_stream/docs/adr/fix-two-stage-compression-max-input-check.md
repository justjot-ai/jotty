# Fix: Two-Stage Compression Missing Max Input Check

**Date**: 2026-02-05  
**Status**: Implemented  
**Related**: `rca-content-compression-too-large-error.md`

## Context

The error logs show that even when using `ContentIngestionPipeline.process()`, the two-stage compression path was failing:

```
2026-02-05 18:27:51.111 | ERROR | Synapse.core.unified_compression:334 | ❌ Content too large for compression: 99687 tokens. Maximum compressor input: 1000 tokens
2026-02-05 18:27:51.111 | ERROR | Synapse.core.content_ingestion:367 | ❌ Two-stage compression failed: Content too large for compression: 99687 tokens.
```

## Problem

In `ContentIngestionPipeline.process()`, the two-stage compression path (lines 333-369) had a bug:

1. **Missing validation**: After chunking, the code checked if `chunked_tokens > max_tokens` but didn't check if `chunked_tokens <= max_compressor_input`
2. **Direct compression call**: It called `self.compressor.compress()` on chunked content without verifying it fits within the compressor's input limit
3. **No fallback**: When compression failed, it just logged an error and returned chunked content, but didn't attempt recursive processing

## Root Cause

The chunker (`UnifiedChunker.chunk_and_select()`) can return content that:
- Is smaller than the original content
- But still larger than `max_compressor_input` (the compressor's input limit)
- And larger than `max_tokens` (the target output size)

The code only checked the second condition (`chunked_tokens > max_tokens`) but not the first (`chunked_tokens > max_compressor_input`).

## Solution

Added validation and recursive processing in the two-stage compression path:

1. **Recalculate `max_compressor_input`**: For the two-stage path, recalculate the compressor input limit based on the adjusted max_tokens
2. **Check before compressing**: Verify that chunked content fits within `max_compressor_input` before calling `compress()`
3. **Recursive chunking**: If chunked content is still too large, recursively call `self.process()` which will **chunk again** if needed, then compress
4. **Recursion depth limit**: Added `_recursion_depth` parameter (max 5) to prevent infinite loops
5. **Better error handling**: More informative logging about what's happening at each stage

## Implementation

**File**: `Synapse/core/content_ingestion.py` (lines 330-369)

### Before:
```python
if chunked_tokens > max_tokens:
    # Directly compress without checking max_compressor_input
    compressed = await self.compressor.compress(chunked, max_tokens, ...)
```

### After:
```python
if chunked_tokens > max_tokens:
    # Recalculate max_compressor_input for two-stage
    max_compressor_input_two_stage = self.model_context_window - adjusted_max_tokens - self.safety_margin
    
    if chunked_tokens > max_compressor_input_two_stage:
        # Recursively process through pipeline - will CHUNK AGAIN if still too large
        recursive_result = await self.process(
            chunked, max_tokens, ..., 
            _recursion_depth=_recursion_depth + 1
        )
        # Recursive call goes through same decision tree:
        # - If still too large → chunks again
        # - If fits compressor → compresses
        # - If fits budget → passes through
    else:
        # Safe to compress directly
        compressed = await self.compressor.compress(chunked, adjusted_max_tokens, ...)
```

**Key improvement**: The recursive call to `self.process()` goes through the **same decision logic**, so if the chunked content is still too large, it will chunk again automatically.

## Benefits

1. ✅ **Prevents errors**: No more "content too large" errors in two-stage compression
2. ✅ **Handles edge cases**: Recursively chunks again if content is still too large after first chunking
3. ✅ **Automatic chunking**: Recursive call uses same decision logic, so it chunks again automatically if needed
4. ✅ **Recursion safety**: Depth limit (5) prevents infinite loops
5. ✅ **Better compression**: Multiple stages of chunking + compression when needed
6. ✅ **Clearer logging**: More informative messages about recursion depth and what's happening

## Testing

1. **Unit test**: Pass content that chunks to size > max_compressor_input but < original → Should recursively process
2. **Integration test**: Large content (100k+ tokens) → Should complete without errors
3. **Edge case**: Content that requires multiple recursive passes → Should handle gracefully

## Related Files

- `Synapse/core/content_ingestion.py` - Main fix
- `Synapse/core/unified_compression.py` - Error message (unchanged, but now shouldn't be triggered)
- `docs/adr/rca-content-compression-too-large-error.md` - Related RCA

## Notes

- The recursive approach ensures we always respect `max_compressor_input` limits
- Each recursive call will chunk further if needed, then compress
- The processing path in `IngestionResult` will show the recursive path (e.g., "chunk+recursive_chunk+compress")
