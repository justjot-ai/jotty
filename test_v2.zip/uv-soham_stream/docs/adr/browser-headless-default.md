# Browser Headless Mode by Default

**Status**: Implemented  
**Date**: 2026-01-31

## Context

The browser automation tools were defaulting to visible (non-headless) mode, which would show browser windows during automated tasks. This is unnecessary for automated workflows and can be distracting for users.

## Decision

Changed the default `headless` parameter from `False` to `True` in both browser initialization functions:

- `initialize_browser()` in `surface/src/surface/tools/browser_tools.py`
- `initialize_browser_with_profile()` in the same file

## Impact

- **Positive**: Browser will run in headless mode by default, making it invisible to users during automated tasks
- **Backward Compatibility**: Users can still explicitly set `headless=False` if they need to see the browser for debugging purposes
- **Environment Variable**: The `BROWSER_HEADLESS` environment variable override still works as before

## Implementation

Updated default parameters:
```python
headless: bool = True  # Changed from False
```

Updated documentation strings to reflect the new default value.

## Usage

Default (headless):
```python
initialize_browser()  # Runs in headless mode
```

Debugging (visible):
```python
initialize_browser(headless=False)  # Shows browser window
```
