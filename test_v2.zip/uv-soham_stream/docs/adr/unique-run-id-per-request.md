# ADR: Unique Run ID Per Request and Conductor State Isolation

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** /perform API endpoint  
**Implementation:** Primary fix (Conductor isolation) completed

## Problem

The `/perform` API endpoint in `uv` has **two related issues** causing state leakage between requests:

### Issue 1: Shared Conductor Instance (Primary Issue)

The `SwarmService` creates a **singleton Conductor instance** that is reused across all API requests:

```python
# uv/src/uv/services/swarm_service.py
class SwarmService:
    def __init__(self):
        self._swarm = None  # Single Conductor instance
    
    @property
    def swarm(self):
        return self._swarm  # Same instance returned for all requests
```

**Evidence from logs:**
```
2026-02-02 02:14:46 | 🚀 RUN: Conductor | episode=1 | goal_length=94
2026-02-02 02:18:22 | 🚀 RUN: Conductor | episode=2 | goal_length=94
```

The episode counter increments across requests, proving the same Conductor is reused.

**Consequences:**
- ❌ Episode counter increments across requests
- ❌ Shared context persists between requests
- ❌ Task completion state leaks between requests
- ❌ Memory/learning state accumulates across requests
- ❌ "Tasks already completed" messages appear in new requests

### Issue 2: Run ID Collision (Secondary Issue)

Even if Conductor instances were isolated, the run ID uses timestamp with only second-level precision (`run_%Y%m%d_%H%M%S`):

**Consequences:**
- ❌ Concurrent requests within same second get same run directory
- ❌ Log file collisions
- ❌ Output file overwrites

## Current Implementation

```python
# Synapse/core/conductor.py:2888
ts = datetime.now().strftime("run_%Y%m%d_%H%M%S")
output_dir = str(Path(base) / ts)
```

This creates directories like:
- `synapse_outputs/run_20260202_021327/`
- `synapse_outputs/run_20260202_021327/` (collision if within same second!)

## Solution

### Solution 1: Isolate Conductor State Per Request (Critical)

**Option A: Create New Conductor Per Request** (Recommended)
- Create a fresh Conductor instance for each `/perform` request
- Ensures complete state isolation
- Clean episode counter, shared context, task state

**Option B: Reset Conductor State Between Requests**
- Add `reset()` method to Conductor to clear state
- Less clean, harder to maintain
- Risk of missing state variables

**Recommendation:** Option A - Create new Conductor per request

### Solution 2: Add Unique Run ID (Important)

Add microseconds and/or UUID to ensure uniqueness:

### Option 1: Microseconds (Simple)
```python
ts = datetime.now().strftime("run_%Y%m%d_%H%M%S_%f")
output_dir = str(Path(base) / ts)
```

Creates: `run_20260202_021327_123456/`

### Option 2: UUID Suffix (Most Robust)
```python
import uuid
ts = datetime.now().strftime("run_%Y%m%d_%H%M%S")
run_id = f"{ts}_{uuid.uuid4().hex[:8]}"
output_dir = str(Path(base) / run_id)
```

Creates: `run_20260202_021327_a3f8b2c1/`

### Option 3: Sequential Counter (Session-Based)
```python
# In Conductor.__init__
self.run_counter = 0

# In run() method
self.run_counter += 1
ts = datetime.now().strftime("run_%Y%m%d_%H%M%S")
run_id = f"{ts}_{self.run_counter:04d}"
output_dir = str(Path(base) / run_id)
```

Creates: `run_20260202_021327_0001/`

## Recommendation

### Primary Fix: Conductor Isolation

**Create new Conductor per request** in `TaskService`:

```python
# uv/src/uv/services/task_service.py
class TaskService:
    def __init__(self, swarm_config):
        """Store config instead of swarm instance"""
        self.swarm_config = swarm_config
    
    async def execute_task_stream(self, instruction, context):
        # Create fresh Conductor for this request
        from Synapse.core.conductor import Conductor
        swarm = Conductor(
            actors=self.swarm_config['actors'],
            config=self.swarm_config['config'],
            context_providers=self.swarm_config['context_providers'],
            # ... other config
        )
        
        # Execute with isolated state
        async for event in swarm.run(goal=instruction):
            yield event
```

### Secondary Fix: Unique Run IDs

**Use UUID suffix** in `Synapse/core/conductor.py`:

```python
import uuid
ts = datetime.now().strftime("run_%Y%m%d_%H%M%S")
run_id = f"{ts}_{uuid.uuid4().hex[:8]}"
output_dir = str(Path(base) / run_id)
```

**Benefits:**
- ✅ Guaranteed uniqueness even across multiple Conductor instances
- ✅ No collision risk
- ✅ Short (8 chars) and readable
- ✅ No state management needed
- ✅ Works with distributed systems

## Implementation

### Phase 1: Conductor Isolation (✅ COMPLETED)

**Changes Made:**

1. **SwarmService** (`uv/src/uv/services/swarm_service.py`):
   - Changed from storing `_swarm` (Conductor instance) to `_swarm_config` (dict)
   - Added `_shared_resources` to store browser/terminal that persist across requests
   - Added `create_conductor()` method to create fresh Conductor instances
   - Updated `initialize_stream()` to store config instead of creating Conductor
   - Updated `cleanup_stream()` to clean shared resources

2. **TaskService** (`uv/src/uv/services/task_service.py`):
   - Changed constructor to accept `swarm_service` instead of `swarm` instance
   - Updated `execute_task_stream()` to create fresh Conductor per request
   - Updated `execute_task()` to create fresh Conductor per request
   - Updated all internal methods to accept `swarm` parameter

3. **Perform API** (`uv/src/uv/api/v1/perform.py`):
   - Updated both endpoints to pass `swarm_service` to TaskService
   - Added comments explaining the fix

**Result:**
- ✅ Each request creates a fresh Conductor with `episode=1`
- ✅ No state leakage between requests
- ✅ Shared resources (browser, terminal) still persist
- ✅ "Tasks already completed" issue resolved

### Phase 2: Unique Run IDs (TODO)
1. Update `Synapse/core/conductor.py` line ~2888
2. Add UUID import at top of file
3. Test concurrent requests get unique directories

## Impact

- **Breaking Change**: No (directory name format changes but no API changes)
- **Performance**: Negligible (UUID generation is fast)
- **Compatibility**: Existing run directories remain valid
- **Testing**: Verify concurrent requests get unique directories

## Alternatives Considered

- **Timestamp only**: Not unique enough (current problem)
- **Full UUID**: Too long for directory names
- **Sequential counter**: Requires state management, doesn't work across instances
- **Microseconds**: Better but still has tiny collision risk with high concurrency

## Testing

### Verify Conductor Isolation
```bash
# Send two identical requests
curl -X POST http://localhost:8000/api/v1/perform \
  -H "Content-Type: application/json" \
  -d '{"task": "test task"}'

# Check logs - episode should be 1 for BOTH requests
grep "episode=" uv/a.txt | tail -2
# Expected: episode=1, episode=1 (not episode=1, episode=2)
```

### Verify Unique Run IDs
```bash
# Send concurrent requests
for i in {1..5}; do
  curl -X POST http://localhost:8000/api/v1/perform \
    -H "Content-Type: application/json" \
    -d '{"task": "test '$i'"}' &
done
wait

# Check run directories - should all be unique
ls -la synapse_outputs/
```

## Notes

- The Electron UI doesn't send a run_id - it's generated server-side
- Each `/perform` request should create a **new Conductor instance** with fresh state
- The swarm service should store **config/factory**, not the Conductor instance
- Browser and terminal resources can still be shared (they're stateless tools)
