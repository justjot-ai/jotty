# ADR: Parallel Execution Event Streaming

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Enable real-time event streaming during parallel agent execution

## Problem

The backend was executing agents in parallel using `asyncio.gather()`, but the UI was not showing both agents simultaneously. Analysis of logs revealed:

```
2026-02-02 01:53:10.727 | INFO | 🚀 PARALLEL EXECUTION: Executing 2 tasks simultaneously
2026-02-02 01:53:23.159 | INFO | ⏳ Executing 2 tasks in parallel...
2026-02-02 01:57:10.386 | INFO | ✅ PARALLEL EXECUTION COMPLETE | 2 tasks | duration=227.22s
```

**Root Cause:** The parallel execution wrapper was consuming events without yielding them:

```python
async def execute_task_wrapper(actor_cfg, tsk, ctx, kw, actor_ctx):
    result = None
    async for event in self._execute_actor_with_retry(...):
        # Consume events but don't yield them (parallel execution)  ← PROBLEM!
        if isinstance(event, dict) and event.get("type") == "result":
            result = event.get("result")
    return result
```

This meant:
- ✅ Tasks were executing in parallel (backend)
- ❌ Events were being swallowed (no streaming)
- ❌ UI only saw sequential activation/deactivation

## Decision

Replace `asyncio.gather()` with event-streaming parallel execution:

### New Approach

1. **Create event queues** for each parallel task
2. **Start tasks as background tasks** using `asyncio.create_task()`
3. **Stream events in real-time** by polling all queues
4. **Yield events immediately** to the UI

### Implementation

```python
# Create event queues for each task
task_queues = {}
task_results = {}

# Start all tasks as background tasks
async def run_task_with_queue(ptask, actor_cfg, ctx, kw, actor_ctx):
    queue = asyncio.Queue()
    task_queues[ptask.task_id] = queue
    result = None
    try:
        async for event in self._execute_actor_with_retry(...):
            # Put event in queue for streaming
            await queue.put(event)
            if isinstance(event, dict) and event.get("type") == "result":
                result = event.get("result")
        task_results[ptask.task_id] = result
    finally:
        await queue.put(None)  # Signal completion

# Start all tasks
tasks = []
for ptask, actor_config, context, kw, actor_ctx in parallel_results:
    task = asyncio.create_task(run_task_with_queue(...))
    tasks.append((ptask, task))

# Stream events from all tasks in real-time
active_tasks = set(ptask.task_id for ptask, _ in tasks)
while active_tasks:
    for task_id in list(active_tasks):
        queue = task_queues[task_id]
        try:
            event = await asyncio.wait_for(queue.get(), timeout=0.01)
            if event is None:
                active_tasks.remove(task_id)
            else:
                yield event  # Stream to UI!
        except asyncio.TimeoutError:
            pass
    await asyncio.sleep(0.01)
```

## Benefits

✅ **Real-time streaming:** Events from all parallel tasks stream immediately  
✅ **UI sees parallel execution:** Both agents activate simultaneously  
✅ **Non-blocking:** Uses async queues, no blocking waits  
✅ **Fair scheduling:** Round-robin polling of all task queues  
✅ **Error handling:** Exceptions captured per-task  

## Trade-offs

⚠️ **Slightly more complex:** More code than simple `asyncio.gather()`  
⚠️ **Polling overhead:** Small CPU overhead from queue polling (mitigated with 0.01s sleep)  

## Result

Now when parallel tasks execute:
- ✅ Backend executes in parallel (unchanged)
- ✅ Events stream in real-time (NEW!)
- ✅ UI shows both agents simultaneously (NEW!)

## Testing

Restart the server and run a task that triggers parallel execution:

```bash
cd uv
./run_server.sh
```

Then in Electron app, you should see:
- Both BrowserExecutor and TerminalExecutor activate simultaneously
- Both agent views visible in split-screen
- Real-time updates from both agents

## Related Files

- `/Synapse/core/conductor.py` - Parallel execution logic (lines 3190-3280)
- `/electron-app/src/renderer/js/agent-view-manager.js` - UI split-view logic
- `/docs/adr/parallel-agent-split-view.md` - UI split-view implementation

## Related Issues

- Fixes: "why not seeing both....i want top down and not side by side"
- Root cause was backend not streaming events, not UI issue
