# ADR: Terminal Output Order Fix

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Fix terminal output displaying in reverse order

## Problem

Terminal output was displaying in reverse order (newest at top, oldest at bottom) instead of the expected chronological order (oldest at top, newest at bottom).

## Root Cause

The `.terminal-fallback-content` div was inheriting or defaulting to a layout that reversed the order of child elements. Without explicit `flex-direction: column`, the browser may have been applying a different layout or inheriting from parent styles.

## Decision

Add explicit CSS to ensure normal top-to-bottom order:

```css
.terminal-fallback-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  font-size: 13px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-all;
  display: flex;
  flex-direction: column; /* Ensure normal order (top to bottom) */
}
```

## Implementation

The JavaScript code was already correct:
```javascript
appendToFallback(text) {
  const line = document.createElement('div');
  line.className = 'terminal-fallback-line';
  line.textContent = cleanText;
  this.fallbackContent.appendChild(line);  // Appends to end
  
  // Auto-scroll to bottom
  this.fallbackContent.scrollTop = this.fallbackContent.scrollHeight;
}
```

The fix ensures the CSS layout matches the JavaScript append behavior.

## Result

✅ **Correct order:** Oldest output at top, newest at bottom  
✅ **Auto-scroll:** Automatically scrolls to show latest output  
✅ **Chronological:** Matches expected terminal behavior  

## Testing

Restart Electron app and run a task with terminal output. Verify:
- First command appears at top
- Subsequent output appears below
- Latest output is at bottom
- Auto-scrolls to show latest

## Related Files

- `/electron-app/src/renderer/css/agent-views.css` - Terminal CSS (line 358)
- `/electron-app/src/renderer/js/agent-view-manager.js` - Terminal handler (line 745)

## Notes

This is a simple CSS fix to ensure consistent behavior across all browsers and prevent inheritance of reverse flex-direction from other elements.
