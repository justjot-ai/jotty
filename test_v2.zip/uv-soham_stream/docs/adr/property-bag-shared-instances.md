# ADR: Property Bag Pattern for Shared Actor Instances

**Status:** Implemented  
**Date:** 2026-01-30  
**Context:** Persistent state across actor invocations

---

## Problem

Browser and terminal agents lose state between invocations because Synapse creates fresh instances dynamically:

```
Task 1 (BrowserExecutor): Login to website A, download data
  → Browser Instance #1 created → Has auth session

Task 2 (DataProcessor): Process data  
  → No browser needed

Task 3 (BrowserExecutor): Upload to website B
  → Browser Instance #2 created → Lost auth session! ❌
```

**Root Cause**: Each actor invocation creates a new browser/terminal instance, losing:
- Authentication sessions (cookies, tokens)
- Open tabs and window state
- Downloaded files and form data
- Navigation history

---

## Solution: Property Bag (Service Locator Pattern)

Leverage Synapse's existing `context_providers` mechanism to share persistent instances across all actor invocations.

### Architecture

```
integration.py (Bootstrap)
  ↓
1. Create shared browser instance (Selenium WebDriver)
2. Register via set_shared_browser()
3. Pass to Conductor as context_providers
  ↓
Conductor
  ↓
Actor Invocation #1 → Uses shared browser → Maintains state
Actor Invocation #2 → Uses SAME shared browser → State persists! ✅
Actor Invocation #3 → Uses SAME shared browser → Still has auth!
```

---

## Implementation

### 1. Browser Tools Module (`surface/src/surface/tools/browser_tools.py`)

Added shared browser management:

```python
# Global browser instances
_browser_driver = None  # Session-specific (old)
_shared_browser_driver = None  # Persistent across invocations (new)

def set_shared_browser(driver) -> None:
    """Register a shared browser instance for all invocations."""
    global _shared_browser_driver, _browser_driver
    _shared_browser_driver = driver
    _browser_driver = driver
    logger.info(f"🌐 Shared browser instance set: {id(driver)}")

def get_browser_driver():
    """Get current browser (shared > session-specific)."""
    return _shared_browser_driver or _browser_driver

def initialize_browser(...):
    """Initialize browser - returns shared instance if exists."""
    # 🆕 Check for shared browser first
    if _shared_browser_driver is not None:
        logger.info(f"🔄 Using existing shared browser: {id(_shared_browser_driver)}")
        return {"status": "success", "is_shared": True, ...}
    
    # No shared browser, create new one
    return initialize_browser_with_profile(...)

def initialize_browser_with_profile(...):
    """Initialize with profile - returns shared instance if exists."""
    # 🆕 Check for shared browser first
    if _shared_browser_driver is not None:
        logger.info(f"🔄 Using shared browser (ignoring profile)")
        return {"status": "success", "is_shared": True, ...}
    
    # No shared browser, create with profile
    ...
```

**Key Change**: All browser initialization functions now check for shared browser **first** before creating a new instance. This prevents the agent's ReAct loop from creating new browsers.

### 2. Integration Setup (`surface_synapse/integration.py`)

Create and register shared instances at startup:

```python
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from surface.tools import set_shared_browser
from pathlib import Path

# Create persistent browser with profile
chrome_options = Options()
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

# Use persistent profile (same as browser_tools default)
default_profile_dir = Path.home() / ".browser_executor" / "profiles" / "default_session"
default_profile_dir.mkdir(parents=True, exist_ok=True)
chrome_options.add_argument(f'--user-data-dir={default_profile_dir}')

# Anti-detection options
chrome_options.add_argument('--disable-blink-features=AutomationControlled')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])

shared_browser = webdriver.Chrome(options=chrome_options)

# Register it globally
set_shared_browser(shared_browser)

# Create property bag
property_bag = {
    'browser': shared_browser,
    'browser_profile_path': str(default_profile_dir),
    'terminal_session': "surface_default_terminal",
    'browser_tabs': {},
    'session_data': {}
}

# Pass to Conductor
swarm = Conductor(
    actors=actors,
    context_providers=property_bag,  # ← Property bag!
    ...
)
```

**Important**: The shared browser now uses the same profile directory as `browser_tools` (`~/.browser_executor/profiles/default_session`), ensuring cookies and sessions persist across runs.

### 3. Conductor Integration (Existing)

Conductor already supports `context_providers`:

```python
# Conductor.__init__
self.context_providers = context_providers or {}

# Available for parameter resolution
resolution_context = {
    'context_providers': self.context_providers,
    ...
}
```

---

## Benefits

### ✅ State Persistence

```python
# Task 1: Login
BrowserExecutor.execute("Login to website A")
# → shared_browser has auth cookies

# Task 2: Process data
DataProcessor.execute("Transform data")
# → shared_browser still alive, still has cookies

# Task 3: Upload
BrowserExecutor.execute("Upload to website B")
# → shared_browser STILL has cookies! ✅
```

### ✅ Resource Efficiency

- **Before**: N browser instances for N tasks (expensive!)
- **After**: 1 browser instance shared across all tasks

### ✅ Session Management

- **Cookies persist automatically** (saved to `~/.browser_executor/profiles/default_session/`)
- **Open tabs remain available** within a run
- **Form state preserved**
- **Authentication sessions maintained** - login once, works across runs!
- **Profile persistence** - Browser state survives even after closing the browser

### ✅ Zero Code Changes in Tools

Browser tools automatically use shared instance via `get_browser_driver()`. No changes needed in individual tool functions.

---

## Usage

### Automatic (Default)

When using `create_surface_swarm()`, shared browser is automatically created:

```python
swarm = create_surface_swarm()
# Shared browser already set up!
```

### Manual Control

Access shared instances from property bag:

```python
# In architect/auditor prompts or custom code
browser = context_providers['browser']
current_url = browser.current_url
cookies = browser.get_cookies()
```

### Custom Instances

Add your own shared objects:

```python
property_bag = {
    'browser': shared_browser,
    'terminal_session': "my_session",
    'database_connection': db_conn,  # Custom!
    'api_client': my_client,  # Custom!
    'cache': redis_client  # Custom!
}
```

---

## Property Bag Contents

Default property bag includes:

| Key | Type | Description |
|-----|------|-------------|
| `browser` | `webdriver.Chrome` | Shared Selenium WebDriver instance |
| `browser_profile_path` | `str` | Path to persistent browser profile (`~/.browser_executor/profiles/default_session`) |
| `terminal_session` | `str` | Persistent terminal session name |
| `browser_tabs` | `dict` | Track open tabs by name |
| `session_data` | `dict` | Store arbitrary session data |

**Browser Profile**: Uses `~/.browser_executor/profiles/default_session` which means:
- Cookies saved to disk automatically
- Login sessions persist across runs
- Browser preferences and history saved
- Extensions and settings maintained

You can add more as needed!

---

## Future Enhancements

1. **Lifecycle Management**: Auto-close browser on swarm shutdown
2. **Multiple Browsers**: Support multiple browser instances (e.g., different profiles)
3. **State Snapshots**: Save/restore browser state between runs
4. **Connection Pooling**: Pool of browser instances for parallel execution
5. **Health Checks**: Detect and replace crashed browser instances

---

## Related Patterns

- **Service Locator**: Property bag acts as service locator for shared services
- **Singleton**: Shared browser is effectively a singleton per swarm
- **Dependency Injection**: Conductor injects shared instances into actors

---

## Testing

Verify state persistence:

```bash
./scripts/run_solve_task.sh "Login to example.com, then navigate to profile page"
# Check that login persists across navigation
```

---

## Files Changed

- `surface/src/surface/tools/browser_tools.py` - Added shared browser support
- `surface/src/surface/tools/__init__.py` - Exported new functions
- `surface_synapse/integration.py` - Create and register shared instances
- `Synapse/core/conductor.py` - Already supports context_providers (no changes)

---

## Summary

Property bag pattern solves the state persistence problem by:
1. Creating shared instances at startup
2. Registering them globally via `set_shared_browser()`
3. Passing them to Conductor as `context_providers`
4. All actor invocations use the SAME instances

**Result**: Authentication, tabs, cookies, and state persist across all browser tasks! 🎉
