# ADR: Browser Auto-Move to Top on Command Received

## Status
Accepted

## Context
When multiple agent cards are displayed in the grid (e.g., BrowserExecutor, WebSearch, Test Generator, Terminal), adding new cards pushes existing ones down. The BrowserView was being hidden when the Browser card moved to position 4 or beyond (outside the 2x2 viewport).

This caused confusion during iteration 2+ of task execution - browser actions were executing in the backend but the user couldn't see them because the BrowserView was hidden due to scroll position.

## Decision
Automatically move the Browser card to the top of the grid and ensure the BrowserView is visible whenever browser commands are received from the backend.

### Changes
1. **agent-view-manager.js**: Added `moveBrowserToTopAndShow()` method that:
   - Moves the browser card to the front of the container
   - Resets the `browserHiddenDueToScroll` flag
   - Shows the native BrowserView

2. **app.js**: Modified `handleBrowserCommand()` to call `moveBrowserToTopAndShow()` at the start of command processing

## Consequences

### Positive
- Users can always see browser actions when they're being executed
- Better visibility of what the agent is doing in the browser
- No manual intervention needed to show the browser during execution

### Negative
- Grid will reorder when browser commands are received (may cause brief visual shift)
- Browser card will always take priority position when active

## Implementation
```javascript
// agent-view-manager.js
async moveBrowserToTopAndShow() {
  const moduleBox = this.moduleBoxes.get('BrowserExecutor');
  if (!moduleBox || !moduleBox.element) return;
  
  this.moveBoxToFront(moduleBox.element);
  
  if (this.browserHiddenDueToScroll || !this.browserViewVisible) {
    this.browserHiddenDueToScroll = false;
    this.browserToggleShown = false;
    await this.showNativeBrowser();
  }
}

// app.js - in handleBrowserCommand()
if (this.agentViewManager) {
  await this.agentViewManager.moveBrowserToTopAndShow();
}
```
