# Fix RewardBreakdown Attribute Name Mismatch

**Date**: 2026-01-31  
**Status**: Fixed  
**Context**: Bug fix in conductor.py environment tracking

## Problem

The conductor was attempting to access non-existent attributes on the `RewardBreakdown` object when tracking task completion in the environment manager:

- Tried to access: `reward_breakdown.quality_score`
- Tried to access: `reward_breakdown.progress_score`  
- Tried to access: `reward_breakdown.cooperation_score`

But the actual `RewardBreakdown` dataclass (defined in `Synapse/core/unified_reward.py`) has different attribute names:

```python
@dataclass
class RewardBreakdown:
    total: float
    quality: float          # NOT quality_score
    cooperation: float      # NOT cooperation_score
    learning: float         # NOT progress_score
    user: Optional[float]
    weights: Dict[str, float]
```

This caused an `AttributeError` at runtime: `'RewardBreakdown' object has no attribute 'quality_score'`

## Solution

Updated `Synapse/core/conductor.py` (lines 3504-3506) to use the correct attribute names:

```python
# Before:
completion_info.append(f"  - Quality Score: {reward_breakdown.quality_score:.2f}")
completion_info.append(f"  - Progress Score: {reward_breakdown.progress_score:.2f}")
completion_info.append(f"  - Cooperation Score: {reward_breakdown.cooperation_score:.2f}")

# After:
completion_info.append(f"  - Quality Score: {reward_breakdown.quality:.2f}")
completion_info.append(f"  - Learning Score: {reward_breakdown.learning:.2f}")
completion_info.append(f"  - Cooperation Score: {reward_breakdown.cooperation:.2f}")
```

## Impact

- ✅ Environment tracking now correctly logs reward breakdown components
- ✅ No more AttributeError warnings in logs
- ✅ Better alignment with unified reward system terminology ("learning" instead of "progress")

## Files Changed

- `Synapse/core/conductor.py` - Fixed attribute access in environment tracking
