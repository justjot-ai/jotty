# ADR: Capabilities Are Existing Actors - Don't Write Code to Build Them

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: ResearchAgent, TaskBreakdownAgent, and TodoCreatorAgent planning workflow

## Problem

**Critical Misunderstanding**: The planning agents were treating `available_capabilities` as **features to BUILD** instead of **existing executors to USE**.

### Example of the Problem

**User Request**: "Summarize my WhatsApp group conversations"

**Available Capabilities**: `['browser_interaction', 'web_automation', 'summarization']`

**What the Agent Did** ❌:
```
Research Phase:
- Researched "Selenium installation and setup"
- Researched "Playwright for WhatsApp Web automation"
- Researched "Transformers library for text summarization"
- Researched "BART and T5 models"

Implementation Plan:
1. Install selenium==4.15.0
2. Install webdriver_manager
3. Create browser_automation.py with Selenium WebDriver code
4. Install transformers==4.35.0
5. Install torch/tensorflow
6. Create summarizer.py loading BART model
7. Write message extraction logic
8. Integrate components

DAG Tasks:
TASK 1: pip install selenium webdriver_manager
TASK 2: Create browser_automation.py
TASK 3: pip install transformers torch
TASK 4: Create summarizer.py
TASK 5: Load BART model weights
... (20+ more tasks writing code from scratch)
```

**What the Agent Should Have Done** ✅:
```
Research Phase:
- Research WORKFLOW: What's the sequence? (open web.whatsapp.com → QR auth → navigate → extract → summarize)
- Research WHAT TO DO, not HOW TO BUILD

Implementation Plan:
1. BrowserExecutor: Open web.whatsapp.com
2. Wait for user to scan QR code (user authenticates with THEIR phone)
3. BrowserExecutor: Navigate to clawdbot-test group
4. BrowserExecutor: Extract message elements from DOM
5. Summarizer: Summarize extracted conversations

DAG Tasks:
TASK 1: BrowserExecutor: Open WhatsApp Web | CAPABILITY: browser_interaction
TASK 2: Wait for user QR authentication | CAPABILITY: browser_interaction
TASK 3: BrowserExecutor: Navigate to group | CAPABILITY: browser_interaction
TASK 4: BrowserExecutor: Extract messages | CAPABILITY: browser_interaction
TASK 5: Summarizer: Summarize text | CAPABILITY: summarization
```

## Root Cause

The signatures didn't clearly communicate that:
1. **Capabilities are EXISTING executors** (like `BrowserExecutor`, `Summarizer`)
2. **These are ALREADY IMPLEMENTED** - they work NOW
3. **Don't write code to build them** - USE them directly

The agents thought:
> "I have `browser_interaction` capability, so I need to research how to DO browser automation using Selenium"

When they should have thought:
> "I have `browser_interaction` capability, which means there's ALREADY a BrowserExecutor that can do browser automation. I just need to USE it!"

## Solution: Clarify Capabilities Are Existing Actors

### Updated All Signatures

#### 1. ResearchAgentSignature
```python
available_capabilities = dspy.InputField(
    desc="List of execution capabilities available (comma-separated). "
    "IMPORTANT: These are EXISTING capabilities/executors that are ALREADY IMPLEMENTED. "
    "Do NOT write code to build these from scratch. "
    "Example: 'browser_interaction' means there's ALREADY an executor that can control browsers - just USE it, don't code Selenium. "
    "Example: 'summarization' means there's ALREADY a summarizer - just USE it, don't load BART/T5 models."
)

research_plan = dspy.OutputField(
    desc="..."
    "CRITICAL RULES:\n"
    "- Available capabilities are EXISTING actors/executors - USE them, don't BUILD them from scratch\n"
    "- If 'browser_interaction' capability exists → plan should be 'BrowserExecutor opens web.whatsapp.com', NOT 'Install Selenium and write code'\n"
    "- If 'summarization' capability exists → plan should be 'Summarizer summarizes text', NOT 'Install transformers and load BART model'\n"
    "- The plan describes a WORKFLOW of tasks for existing actors, NOT a coding project"
)
```

#### 2. GenerateResearchPlan
```python
available_capabilities = dspy.InputField(
    desc="List of EXISTING execution capabilities/actors. "
    "These capabilities are ALREADY IMPLEMENTED - do NOT write code to build them."
)

research_plan = dspy.OutputField(
    desc="..."
    "CRITICAL: Capabilities are EXISTING executors, NOT things to code:\n"
    "- 'browser_interaction' = there's ALREADY a BrowserExecutor that can control browsers\n"
    "- 'summarization' = there's ALREADY a Summarizer that can summarize text\n"
    "- 'web_search' = there's ALREADY a WebsearchExecutor that can search the web\n"
    "APPROACH:\n"
    "- Research WHAT TO DO, not HOW TO BUILD. Focus on: What steps? What order? What data to extract?\n"
    "- Example: WhatsApp → Research: What is the flow? (open web.whatsapp.com, QR auth, navigate to group, extract messages, summarize)\n"
    "- Do NOT research: 'What libraries to use', 'How to install Selenium', 'How to load BART model'\n"
    "- Focus on WORKFLOW: What actions? What sequence? What to extract?"
)
```

#### 3. SynthesizeFindings
```python
implementation_plan = dspy.OutputField(
    desc="..."
    "- CRITICAL: Available capabilities are EXISTING actors/executors that are ALREADY WORKING - USE them, don't BUILD them\n"
    "- DO NOT create code to implement capabilities that already exist\n"
    "- Example: If 'browser_interaction' exists → plan should be 'BrowserExecutor opens WhatsApp Web', NOT 'pip install selenium; write browser_bot.py'\n"
    "- Example: If 'summarization' exists → plan should be 'Summarizer summarizes text', NOT 'pip install transformers; load BART model'\n"
    "- The plan should describe a WORKFLOW of tasks for existing actors, NOT a coding project\n"
    "- WhatsApp example: '1. BrowserExecutor: open web.whatsapp.com, 2. Wait for user QR auth, 3. BrowserExecutor: navigate to group, 4. BrowserExecutor: extract messages, 5. Summarizer: summarize conversations'\n"
    "- NOT: '1. Install selenium, 2. Write automation script, 3. Install transformers, 4. Write summarizer'"
)
```

#### 4. ExtractTasksSignature (TaskBreakdownAgent)
```python
tasks_list = dspy.OutputField(
    desc="..."
    "1. Actionable and specific (e.g., 'BrowserExecutor: Open web.whatsapp.com', 'Summarizer: Summarize extracted text')\n"
    "..."
    "4. Use EXISTING actors/executors - don't create code to build them\n"
    "CRITICAL: If the implementation plan describes using existing capabilities (browser_interaction, summarization), "
    "create tasks that USE those capabilities via their actors (BrowserExecutor, Summarizer), "
    "do NOT create tasks to install libraries or write code to build those capabilities.\n\n"
    "Format as: TASK: [Actor: action] | TYPE: [type] | DESC: [description] | CAPABILITY: [capability used]\n\n"
    "Example for WhatsApp automation:\n"
    "TASK: BrowserExecutor: Open WhatsApp Web | TYPE: implementation | DESC: Navigate to web.whatsapp.com | CAPABILITY: browser_interaction\n"
    "TASK: Wait for user QR authentication | TYPE: implementation | DESC: Display QR and wait for user scan | CAPABILITY: browser_interaction\n"
    "TASK: BrowserExecutor: Extract messages | TYPE: implementation | DESC: Scrape conversation messages from DOM | CAPABILITY: browser_interaction\n"
    "TASK: Summarizer: Summarize conversations | TYPE: implementation | DESC: Summarize extracted messages | CAPABILITY: summarization"
)
```

## Expected Behavior After Fix

### WhatsApp Summarization Example

**Input**:
```
Task: "Summarize my WhatsApp group conversations"
Available Capabilities: ['browser_interaction', 'web_automation', 'summarization', 'text_analysis']
```

**Research Phase** ✅:
```
Research Questions:
- What is the WhatsApp Web URL?
- What is the authentication flow? (QR code scanning)
- How to navigate to a specific group?
- What DOM elements contain messages?
- What sequence of actions is needed?

Research Focus: WORKFLOW, not implementation details
```

**Implementation Plan** ✅:
```
Workflow for WhatsApp Group Conversation Summarization:

1. BrowserExecutor: Open WhatsApp Web
   - Navigate to web.whatsapp.com
   - Capability: browser_interaction

2. User Authentication via QR Code
   - Display QR code
   - User scans with their phone (THEIR account, THEIR permission)
   - Wait for successful authentication
   - Capability: browser_interaction

3. BrowserExecutor: Navigate to Group
   - Find and click "clawdbot-test" group
   - Capability: browser_interaction

4. BrowserExecutor: Extract Conversations
   - Scroll to load messages
   - Extract message elements from DOM
   - Parse sender names, timestamps, message content
   - Filter for participants: madhur, vijay, narendra
   - Capability: browser_interaction

5. Summarizer: Generate Summary
   - Pass extracted conversations to Summarizer
   - Generate concise summary of key topics
   - Capability: summarization

6. Present Summary to User
   - Display or save summary
```

**DAG Tasks** ✅:
```
TASK 1: BrowserExecutor: Open WhatsApp Web
  TYPE: implementation
  CAPABILITY: browser_interaction
  DESC: Navigate to web.whatsapp.com

TASK 2: Wait for User QR Authentication
  TYPE: implementation
  CAPABILITY: browser_interaction
  DESC: Display QR code, wait for user to scan with phone

TASK 3: BrowserExecutor: Navigate to clawdbot-test Group
  TYPE: implementation
  CAPABILITY: browser_interaction
  DESC: Find and open the specified group
  DEPENDS_ON: TASK 2

TASK 4: BrowserExecutor: Extract Message Elements
  TYPE: implementation
  CAPABILITY: browser_interaction
  DESC: Scroll messages, extract text, sender, timestamp
  DEPENDS_ON: TASK 3

TASK 5: Summarizer: Summarize Conversations
  TYPE: implementation
  CAPABILITY: summarization
  DESC: Generate summary from extracted messages
  DEPENDS_ON: TASK 4

TASK 6: Present Summary to User
  TYPE: validation
  DESC: Display or save the generated summary
  DEPENDS_ON: TASK 5
```

## Key Distinction

### ❌ WRONG: Capabilities as Features to Build
```
Capability: browser_interaction
Agent thinks: "I need to learn how to do browser automation"
Research: "Selenium installation", "WebDriver setup", "Playwright API"
Plan: Install libraries, write code, implement browser automation
Tasks: pip install, create files, write scripts
```

### ✅ RIGHT: Capabilities as Existing Executors
```
Capability: browser_interaction
Agent thinks: "There's a BrowserExecutor already available that can do this"
Research: "WhatsApp Web workflow", "What steps needed?", "What to extract?"
Plan: BrowserExecutor opens URL, user authenticates, BrowserExecutor extracts data
Tasks: BrowserExecutor: [action], BrowserExecutor: [action], Summarizer: [action]
```

## Analogy

**Wrong Framing** (Before):
```
Boss: "You have a car available"
Worker: "Great! Let me research how to build a car from scratch!"
         *researches engine design, wheel manufacturing, assembly line setup*
```

**Right Framing** (After):
```
Boss: "You have a car available"
Worker: "Perfect! I'll use the car to drive to the destination"
         *researches the route, traffic conditions, parking*
```

## Benefits

1. ✅ **Correct Plans**: Task-based workflows, not coding projects
2. ✅ **No Wasted Research**: Focus on workflow, not library APIs
3. ✅ **Proper Task Breakdown**: Tasks use actors, not build features
4. ✅ **Faster Execution**: No installation, compilation, or setup
5. ✅ **Clear Responsibilities**: Each task maps to an existing actor/capability
6. ✅ **User Expectations**: Users expect automation, not software development

## Capability Examples

| Capability | Means | NOT |
|------------|-------|-----|
| `browser_interaction` | BrowserExecutor exists and can control browsers | Install Selenium/Playwright and write automation code |
| `summarization` | Summarizer exists and can summarize text | Install transformers and load BART/T5 model |
| `web_search` | WebsearchExecutor exists and can search web | Install requests/beautifulsoup and write scraper |
| `coding` | CodeMaster exists and can write/execute code | Set up IDE and development environment |
| `shell` | TerminalExecutor exists and can run commands | Install bash/zsh and configure shell |

## Related ADRs

- `ai-assistant-delegation-context.md`: Understanding the AI assistant's role
- `prevent-react-tool-bypass.md`: Ensuring agents use tools
- `capability-aware-research-agent.md`: Constraining plans to available capabilities
- `todo-creator-agent-implementation.md`: Actor assignment and validation

## Conclusion

**Capabilities = Existing Actors/Executors that are ALREADY WORKING**

The agents must understand that when they receive `available_capabilities`, these are NOT features to build from scratch, but EXISTING tools/actors/executors to USE directly in task workflows.

Research should focus on **WHAT TO DO** (workflow, sequence, data), not **HOW TO BUILD** (libraries, installation, coding).
