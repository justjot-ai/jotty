# Comparison: Prism Synapse vs Surface Synapse

## Key Differences (Updated Check)

### 1. AgentConfig Parameter Name ⚠️ STILL DIFFERENT
- **prism_synapse**: Still uses `actor=` parameter
  ```python
  AgentConfig(
      name="BusinessTermResolver",
      actor=BusinessTermResolver(),  # ← Still uses 'actor'
      ...
  )
  ```
- **surface_synapse**: Uses `agent=` parameter (correct)
  ```python
  AgentConfig(
      name="TerminusAgent",
      agent=terminus_agent,  # ← Uses 'agent' (correct)
      ...
  )
  ```
- **Status**: prism_synapse still uses `actor=` which may work if using `prism.Synapse.core.*` path (different version) but should be updated to `agent=` for consistency.

### 2. Metadata Provider
- **prism_synapse**: Has PrismMetadata provider
  ```python
  metadata = PrismMetadata(data_dir=metadata_dir)
  swarm = Conductor(
      actors=actors,
      metadata_provider=metadata,  # ← Has metadata provider
      ...
  )
  ```
- **surface_synapse**: Uses `None` for metadata provider
  ```python
  swarm = Conductor(
      actors=actors,
      metadata_provider=None,  # ← No metadata provider
      ...
  )
  ```

### 3. Parameter Mappings
- **prism_synapse**: No parameter_mappings specified
- **surface_synapse**: Has parameter_mappings
  ```python
  parameter_mappings={
      "instruction": ["goal", "query"],
      "terminal_session": ["terminal_session"],
  },
  outputs=["analysis", "plan", "commands", "task_complete", "reasoning"],
  ```

### 4. DSPy Configuration
- **prism_synapse**: Uses PrismConfig
  ```python
  from prism.config.config import PrismConfig
  config = PrismConfig()
  lm = dspy.LM(
      model=config.model,
      api_key=config.api_key,
      api_base=config.base_url,
      max_tokens=32000,
      temperature=0.0
  )
  ```
- **surface_synapse**: Direct configuration
  ```python
  lm = dspy.LM(
      model=model_name,
      api_key=api_key,
      api_base=api_base,
      temperature=temperature,
      max_tokens=32000,
  )
  ```

### 5. Tools Configuration
- **prism_synapse**: 
  - Has execute_query tool setup
  - Uses `architect_tools=None` and `auditor_tools=None`
  - Relies on auto-discovery from metadata
- **surface_synapse**:
  - Uses `architect_tools=[]` and `auditor_tools=[]`
  - Tools are built into agents

### 6. Outputs Specification
- **prism_synapse**: No explicit outputs specified
- **surface_synapse**: Explicitly specifies outputs
  ```python
  outputs=["analysis", "plan", "commands", "task_complete", "reasoning"]
  ```

### 7. Import Paths
- **prism_synapse**: Uses `prism.Synapse.core.*`
  ```python
  from prism.Synapse.core.conductor import Conductor
  ```
- **surface_synapse**: Tries both paths with fallback
  ```python
  try:
      from Synapse.core.conductor import Conductor
  except ImportError:
      from prism.Synapse.core.conductor import Conductor
  ```

## Current Status After Update

### Still Different:
1. **AgentConfig parameter**: prism_synapse still uses `actor=`, but imports from `prism.Synapse.core.agent_config` which expects `agent=`
2. **Tools**: prism_synapse uses `None`, surface_synapse uses `[]`
3. **Parameter mappings**: Only surface_synapse has them
4. **Outputs**: Only surface_synapse specifies outputs

### Same:
1. Both use `enable_architect=True` and `enable_auditor=True`
2. Both have similar SynapseConfig setup
3. Both have global architect/auditor

## Critical Issue

**prism_synapse imports from `prism.Synapse.core.agent_config` which expects `agent=` but the code uses `actor=`**. This will cause a TypeError unless:
- There's a compatibility layer
- The import path resolves to a different version
- There's a `__post_init__` that handles both

## Recommendations

1. **URGENT: Fix prism_synapse**: Change `actor=` to `agent=` in all AgentConfig calls (lines 225, 239, 253)
2. **Add parameter_mappings to prism_synapse**: If agents need parameter mapping from `goal` to their specific parameters
3. **Standardize tools**: Change `architect_tools=None` to `architect_tools=[]` for consistency
4. **Consider adding outputs**: Explicit outputs help with parameter resolution in Synapse
