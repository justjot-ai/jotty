# ADR: Browser Command Request-Response Pattern

## Status
Accepted

## Date
2026-02-02

## Context

The browser command system was using a **fire-and-forget** pattern:
1. Backend sends command to Electron via WebSocket
2. Backend immediately returns `{"success": true, "message": "Command sent"}` 
3. Backend has **no way to know** if command actually executed

This caused critical bugs:
- Commands showed `duration=0.001s` (impossible for real browser operations)
- Agent believed commands succeeded when they actually failed silently
- Tasks marked complete without actual browser actions occurring
- WebSocket disconnection caused silent failures

## Decision

Implement a proper **bidirectional request-response pattern**:

```
Backend                    WebSocket                   Electron
   |                          |                           |
   |-- 1. Register request ---|                           |
   |-- 2. Send command ------>|--- command + request_id ->|
   |                          |                           |-- 3. Execute
   |                          |<-- response + request_id -|<- 4. Send result
   |<- 5. Deliver response ---|                           |
   |-- 6. Return result ----->                            |
```

### Components

1. **BrowserCommandResponseQueue** (`agent_session_manager.py`)
   - Thread-safe pending request registry
   - Async/sync wait mechanisms with timeout
   - Request cancellation and cleanup

2. **WebSocket Handler** (`websocket_agents.py`)
   - Parse incoming JSON messages from Electron
   - Route `browser_command_response` to response queue

3. **Browser Tools** (`browser_tools.py`)
   - Register request before sending
   - Wait for actual response with configurable timeout
   - Return real execution result, not fake "sent" message

4. **Electron App** (`app.js`)
   - Execute browser command via BrowserView API
   - Capture actual result (success/failure, data)
   - Send response back with matching request_id

## Consequences

### Positive
- Commands now return **actual execution results**
- Timeouts properly detected (not instant fake success)
- Errors from browser propagate to agent
- Agent can make informed decisions based on real outcomes
- Silent failures eliminated

### Negative
- Slightly higher latency (must wait for execution)
- More complex code paths
- Potential for timeout errors on slow operations

### Neutral
- Default timeout: 30 seconds (configurable per command)
- Poll interval for sync waiting: 50ms

## Files Changed

1. `surface_synapse/agent_session_manager.py`
   - Added `PendingRequest` dataclass
   - Added `BrowserCommandResponseQueue` class
   - Added `get_browser_response_queue()` function

2. `uv/src/uv/api/v1/websocket_agents.py`
   - Added JSON message parsing in WebSocket handler
   - Added `handle_websocket_message()` function
   - Routes `browser_command_response` to queue

3. `surface/src/surface/tools/browser_tools.py`
   - Complete rewrite of `_send_browser_command_sync()`
   - Registers request → sends → waits for response → returns result

4. `electron-app/src/renderer/js/app.js`
   - Enhanced `sendBrowserCommandResponse()` with logging
   - Proper error handling for WebSocket state

## Verification

After these changes, logs should show:
```
📤 [ElectronBrowser] Sent command: click | request_id=abc123... | connections=1
⏳ [ElectronBrowser] Waiting for response: abc123... (click)
📥 [Browser Response] request_id=abc123 | success=true
✅ [ElectronBrowser] Command completed: click | request_id=abc123...
[🛠️ TOOL CALL] electron_click COMPLETE | duration=0.523s  <- REAL duration
```

Instead of previous fake:
```
📤 [ElectronBrowser] Sent command: click (connections: 1)
[🛠️ TOOL CALL] electron_click COMPLETE | duration=0.001s  <- FAKE duration
```
