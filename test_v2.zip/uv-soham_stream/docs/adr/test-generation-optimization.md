# Test Generation and Validation Optimization

**Date**: 2026-01-31  
**Status**: Implemented  
**Major Update**: 2026-01-31 23:00 - Added LLM-based semantic validation

## Context

### Initial Problems
The parallel test generator had multiple issues:
- Creating 76 test cases per task (5 batches × ~15 tests)
- All tests failing due to rigid string matching
- Task descriptions included environment context wrapping
- No flexibility based on task complexity
- String matching couldn't handle semantic equivalence

### Example of String Matching Failure
```
Expected: "Report indicating 3 unread messages found with count"
Actual: "Completed."
Result: FAIL (even though task may have succeeded)
```

## Decision

Implemented two optimizations:

### 1. Reduced Batch Count
- Changed from 5 batches to **2 batches**
- Modified default `num_tests` parameter in:
  - `generate_tests()`: Line 66
  - `generate_and_run()`: Line 191

### 2. Flexible Test Count Based on Complexity
- Updated prompt to generate **3-5 tests max** per batch
- LLM decides count based on task complexity:
  - Simple tasks: 2-3 tests
  - Complex tasks: 4-5 tests
- Hard cap of 5 tests per batch to prevent explosion

### 3. Strip Environment Context
- Added logic in conductor to extract core instruction
- Strips "Current State" environment wrapping before test generation
- Sends only the essential task description to test generator
- Logs character reduction for debugging

## Consequences

### Positive
- Reduced test generation from ~76 to ~10 test cases
- Fewer LLM calls (5 → 2 batches)
- Faster test execution
- More focused and relevant test cases
- Cleaner task descriptions without environment noise

### Neutral
- LLM determines test count flexibility (3-5 range)
- May generate fewer tests for simple tasks (acceptable)

### 4. Enhanced Failed Test Logging
- Added detailed logging for failed tests in conductor
- Logs include:
  - Test name and priority
  - Validation method used
  - Expected vs actual output (truncated to 100 chars)
  - Error message if present
- Also added debug-level logging in test generator itself

### 5. Fixed Test Validation Logic (Critical Bug Fix)
- **Problem**: Tests were comparing raw `EpisodeResult` object strings against expected outputs
- **Solution**: Extract meaningful output from result objects before validation
  - Extracts `rationale`, `answer`, or last `observation` from EpisodeResult
  - Handles dict results by looking for common keys (output, result, answer)
  - Falls back to string representation only as last resort
- **Validation method normalization**: Map LLM-generated custom methods to standard ones
  - `page_load_check` → `content_match`
  - `element_count_match` → `content_match`
  - `zero_state_check` → `content_match`
- **Updated prompt**: Explicitly constrain LLM to use only 4 standard validation methods

### 6. LLM-Based Semantic Validation (Major Improvement) 🎯
**Problem**: String matching is too rigid and fails even when tasks succeed
- `"Completed."` ≠ `"Report indicating 3 unread messages"`
- Cannot understand semantic equivalence
- Fails on formatting differences

**Solution**: Replace string matching with LLM semantic validation
- **Model**: Uses default configured LM (same model as rest of Synapse)
- **Parallel execution**: Each test validated independently in parallel
- **Semantic understanding**: LLM judges if actual output meets expected criteria
- **Reasoning**: Each validation includes explanation of pass/fail

**New Validation Flow**:
```python
test_name = "test_unread_messages_detected"
expected_criteria = "Report indicating 3 unread messages found"
actual_output = "Found 3 new messages from: John, Mary, Bob"

# LLM validator runs
result = validator(test_name, expected_criteria, actual_output)
# Returns: (passed=True, reasoning="Output correctly reports 3 messages with details")
```

**Benefits**:
- **Semantic matching**: Understands intent, not just exact strings
- **Parallel execution**: All tests validated simultaneously (faster)
- **Explainable**: Each pass/fail has LLM reasoning
- **Cost effective**: Reuses existing LM configuration
- **Fast**: Parallel validation with existing model

**Implementation Details**:
- New `LLMTestValidationSignature` DSPy signature
- `_validate_test_llm()` method for each test
- Uses `asyncio.gather()` for parallel execution
- Fallback to string matching if LLM fails
- Uses default configured LM (no separate model instance needed)

### OLD (Deprecated): Fixed Test Validation Logic (String-based)
- **Problem**: Tests were comparing raw `EpisodeResult` object strings against expected outputs
- **Solution**: Extract meaningful output from result objects before validation
  - Extracts `rationale`, `answer`, or last `observation` from EpisodeResult
  - Handles dict results by looking for common keys (output, result, answer)
  - Falls back to string representation only as last resort
- **Validation method normalization**: Map LLM-generated custom methods to standard ones
  - `page_load_check` → `content_match`
  - `element_count_match` → `content_match`
  - `zero_state_check` → `content_match`
- **Updated prompt**: Explicitly constrain LLM to use only 4 standard validation methods

## Consequences

### Benefits Summary
1. **Fewer tests**: 76 → ~10 test cases (87% reduction)
2. **Semantic validation**: LLM understands meaning, not just strings
3. **Parallel validation**: All tests run simultaneously
4. **Explainable results**: LLM reasoning for each pass/fail
5. **Debugging visibility**: Full test details in logs
6. **Accurate extraction**: Gets meaningful output from EpisodeResult
7. **Cost effective**: Reuses existing LM (no extra cost)
8. **Fast**: Parallel validation = quick results

## Files Modified
- `Synapse/core/parallel_test_generator.py`: Prompt, defaults, and failed test logging
- `Synapse/core/conductor.py`: Environment context stripping and failed test logging

## Notes
- Tests are LLM-generated and executed in parallel
- **Supported validation methods**: file_exists, content_match, regex_match, format_check
- Test aggregation uses HybridTestAggregator for scoring
- Failed tests logged at WARNING level for visibility
- All test details available in debug logs
- Result extraction handles EpisodeResult, dicts, and primitive values
- Custom validation methods automatically normalized to standard ones

## Evolution of Fixes

### Bug #1: Raw Object Comparison
**Problem**: Comparing `"EpisodeResult(output=Prediction(..."` strings  
**Fix**: Extract structured data from result objects

### Bug #2: Generic Output
**Problem**: Only extracted `"Completed."` (too generic)  
**Fix**: Prioritize trajectory observations (most detailed)

### Bug #3: Rigid String Matching
**Problem**: `"Completed."` vs `"Report indicating 3 unread messages"` = FAIL  
**Fix**: LLM semantic validation with default configured model

## Expected Results Next Run

With LLM semantic validation:
```
Test 1: test_unread_messages_detected
  Expected: Report indicating 3 unread messages found
  Actual: Found 3 new messages from: John, Mary, Bob
  LLM Reasoning: ✅ Output correctly identifies 3 unread messages and provides sender details, meeting the expected criteria.
  Result: PASS

Test 2: test_status_report_format  
  Expected: Final report communicating status in readable format
  Actual: Found 3 new messages from: John, Mary, Bob
  LLM Reasoning: ✅ Output presents information in clear, human-readable format with specific details.
  Result: PASS
```

**Expected pass rate**: 70-90% (vs 0% with string matching)

## Lenient Testing Philosophy (2026-01-31 23:57)

### Problem
Tests were failing even when tasks completed successfully:
- Task: "Check for unread messages on WhatsApp Web"
- Result: "Successfully checked, found 0 unread messages"
- Test: FAILED ❌ (expected "identifies unread indicators" not "zero messages")

This is wrong - the task **succeeded**, it just found no data!

### Solution: Lenient Validation
Updated LLM validation prompt to be more forgiving:

**Key Principles:**
1. **Focus on task completion**, not exact format
2. **Pass if task completed successfully**, even with empty/zero results
3. **Pass if agent attempted task and reported results**, even if results are empty
4. **Only fail if task clearly failed, errored, or was not attempted**

**Example:**
```
Task: "Check for unread messages"
Result: "Checked successfully, found 0 unread messages"
Old: FAIL ❌ (expected "identifies indicators")
New: PASS ✅ (task completed, reported results)
```

### Improved Extraction for Prediction Objects
Also enhanced extraction to better handle DSPy Prediction objects:
- Detects `Prediction` class and extracts fields properly
- Gets `rationale`, `answer`, `response`, or `result` from Prediction
- Falls back to trajectory extraction for ReAct agents
- Truncates long Prediction dumps to avoid noise

**Expected impact**: 90%+ pass rate for successfully completed tasks
