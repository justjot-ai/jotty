# Error Solution Extractor: Skip Operational Errors

**Date:** 2026-01-31  
**Status:** Implemented  
**Context:** Error solution extractor was running for non-fixable operational errors

## Problem

The `ErrorSolutionExtractor` was being triggered for all errors, including operational errors like `TimeoutError`, `ConnectionError`, etc. These errors:

1. **Cannot be fixed with code changes** - They're runtime/environment issues, not bugs
2. **Waste API calls** - Web search for "TimeoutError python fix" is not useful
3. **Return 0 solutions** - The LLM correctly identifies no code fix is needed
4. **Add latency** - Each search takes ~1-7 seconds unnecessarily

Example from logs:
```
❌ Actor BrowserExecutor failed: 
🔍 Auto error research for: 
[WEB SEARCH] duration=1.288s
✅ Extracted 0 solutions for error
⚠️ Auto error research failed: 
```

The error message was also empty because `str(TimeoutError())` returns `""`.

## Root Causes

### Issue 1: Empty Error Messages
```python
logger.error(f"❌ Actor {actor_config.name} failed: {actor_error}")
# TimeoutError has no message, so this logs: "failed: "
```

### Issue 2: No Filtering for Operational Errors
All errors triggered auto-research, even non-fixable ones like:
- `TimeoutError` - Execution took too long
- `ConnectionError` - Network issues
- `KeyboardInterrupt` - User cancellation
- `MemoryError` - Resource exhaustion

## Solution

### Part 1: Build Complete Error Messages
```python
error_type = type(actor_error).__name__
error_msg = str(actor_error)
if not error_msg or len(error_msg.strip()) == 0:
    error_msg = error_type  # Use type if message is empty
full_error_msg = f"{error_type}: {error_msg}" if error_msg != error_type else error_type
```

Now logs show: `TimeoutError: TimeoutError` instead of empty string.

### Part 2: Skip Operational Errors
```python
SKIP_ERROR_RESEARCH = (
    'TimeoutError',
    'asyncio.TimeoutError',
    'ConnectionError',
    'ConnectionRefusedError',
    'ConnectionResetError',
    'KeyboardInterrupt',
    'SystemExit',
    'MemoryError',
    'ResourceWarning'
)

should_skip_research = error_type in SKIP_ERROR_RESEARCH
if should_skip_research:
    logger.info(f"⏭️ Skipping error research for {error_type} (operational error, not code bug)")
    raise actor_error
```

### Part 3: Better Search Queries
```python
# Before: " python solution fix" (empty error)
# After: "TimeoutError TimeoutError BrowserExecutor python fix"
search_query = f"{error_type} {error_msg} {actor_config.name} python fix"
```

## Error Categories

### ❌ Skip Auto-Research (Operational)
- `TimeoutError` - Increase timeout or optimize operation
- `ConnectionError` - Network/service issues
- `KeyboardInterrupt` - User cancelled
- `MemoryError` - Resource limits
- `SystemExit` - Intentional exit

### ✅ Run Auto-Research (Code Bugs)
- `ImportError` - Missing dependency
- `AttributeError` - Wrong API usage
- `TypeError` - Incorrect types
- `ValueError` - Invalid values
- `SyntaxError` - Code errors
- `NameError` - Undefined variables

## Impact

✅ **Performance**: Saves 1-7 seconds per timeout (no unnecessary web search)  
✅ **Cost**: Reduces API calls for non-fixable errors  
✅ **Accuracy**: Only researches fixable code bugs  
✅ **Logging**: Clear error messages even for exceptions with no message  
✅ **User Experience**: Faster retries for operational errors

## Example Behavior

### Before
```
❌ Actor BrowserExecutor failed: 
🔍 Auto error research for: 
[WEB SEARCH] " python solution fix" (1.3s)
✅ Extracted 0 solutions
⚠️ Auto error research failed
❌ BrowserExecutor failed (attempt 1)
🎯 Executing BrowserExecutor (attempt 2/3)
```

### After
```
❌ Actor BrowserExecutor failed: TimeoutError: TimeoutError
⏭️ Skipping error research for TimeoutError (operational error, not code bug)
❌ BrowserExecutor failed (attempt 1)
🎯 Executing BrowserExecutor (attempt 2/3)
```

**Time saved**: ~6 seconds per timeout

## Files Modified

- `Synapse/core/conductor.py` - Added operational error filtering and improved error message construction (lines 7049-7077)

## Related

- Error solution extractor is still fully functional for actual code bugs
- When `ImportError`, `AttributeError`, etc. occur, auto-research still runs
- This is a smart filter, not a disable of the feature
