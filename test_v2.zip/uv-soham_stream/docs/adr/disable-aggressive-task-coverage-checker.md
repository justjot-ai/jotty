# ADR: Disable Aggressive Task Coverage Checker

**Status:** Disabled  
**Date:** 2026-01-30  
**Context:** Task coverage checker incorrectly marking all tasks as complete

---

## Problem

After completing task_1 (opening WhatsApp Web), the system automatically marked tasks 2, 3, and 4 as complete even though they weren't actually done:

```
Task 1: Navigate to WhatsApp Web → ✅ COMPLETED
Task 2: Read messages from group → ❌ Marked complete (not actually done!)
Task 3: Extract message content → ❌ Marked complete (not actually done!)
Task 4: Summarize messages → ❌ Marked complete (not actually done!)
```

**Logs:**
```
2026-01-30 23:27:51.949 | 🔗 Related task 'task_2' covered by completed work; marking complete
2026-01-30 23:27:57.266 | 🔗 Related task 'task_3' covered by completed work; marking complete
2026-01-30 23:28:08.075 | 🔗 Related task 'task_4' covered by completed work; marking complete
```

---

## Root Cause

**Task Coverage Checker** (lines 3635-3651 in `Synapse/core/conductor.py`):

```python
# After completing a task, check if other pending tasks are "covered"
if auditor_passed and result and self.task_coverage_checker:
    completed_work = str(result)[:2000]
    for other_task_id, other_task in self.todo.subtasks.items():
        if other_task.status == TaskStatus.PENDING and other_task.actor == task.actor:
            # Ask LLM: "Does completed_work cover pending_task?"
            coverage = self.task_coverage_checker(
                completed_work=completed_work,
                pending_task=other_task.description[:500],
                goal_context=goal[:500]
            )
            if coverage.is_covered:
                # Mark pending task as complete!
                self.todo.complete_task(other_task_id, {'implied_by': task.task_id})
```

**Why It Failed:**

1. **Overly Broad Inference**: LLM incorrectly inferred that "opening WhatsApp Web" covers "reading messages" and "summarizing"
2. **Context Truncation**: Only passes 500 chars of task description and goal, losing important details
3. **Same Actor Assumption**: Assumes that if tasks share an actor, completing one might cover others
4. **No Verification**: Doesn't verify if the task was actually completed, just asks LLM opinion

**Example of Bad Inference:**
```
Completed: "Navigated to https://web.whatsapp.com"
Pending: "Read messages from 'synapse' group"
LLM Decision: "✅ Covered!" ← WRONG! Just opening the site doesn't mean messages were read
```

---

## Solution

**Disabled the task coverage checker** by commenting out lines 3636-3651:

```python
# DISABLED: Too aggressive - incorrectly marks all tasks as covered
# if auditor_passed and result and self.task_coverage_checker:
#     completed_work = str(result)[:2000]
#     for other_task_id, other_task in self.todo.subtasks.items():
#         ...
```

---

## Impact

### Before (Buggy)
```
Iteration 1:
  Task 1: Open WhatsApp Web → ✅ COMPLETED
  Task 2: Auto-marked complete (not actually done) ❌
  Task 3: Auto-marked complete (not actually done) ❌
  Task 4: Auto-marked complete (not actually done) ❌

Result: All tasks "complete" but only first one actually done!
```

### After (Fixed)
```
Iteration 1:
  Task 1: Open WhatsApp Web → ✅ COMPLETED

Iteration 2:
  Task 2: Read messages → Will actually execute ✅

Iteration 3:
  Task 3: Extract content → Will actually execute ✅

Iteration 4:
  Task 4: Summarize → Will actually execute ✅

Result: All tasks actually completed properly!
```

---

## Why This Feature Existed

**Original Intent**: Optimize execution by detecting when one task's completion implicitly satisfies other tasks.

**Valid Use Case:**
```
Task 1: "Get list of all Python files in /src"
Task 2: "Count how many Python files exist in /src"

Completing Task 1 might return:
  "Found 25 Python files: file1.py, file2.py, ..."

Task 2 could be marked complete since the count (25) is in the result.
```

**Why It Failed**: The LLM was too liberal in determining coverage, especially for complex multi-step tasks.

---

## Better Alternatives

If we want to re-enable this optimization in the future:

### Option 1: Explicit Output Matching
Only mark task as covered if completed work **explicitly produces** the pending task's required output:

```python
# Task 2 requires: message_list
# Task 1 output: {"messages": [...]}
if "messages" in task1_output:
    mark_task2_complete()  # Output explicitly available
```

### Option 2: Stricter LLM Prompt
Make the coverage check much more conservative:

```
Only return is_covered=True if:
1. The completed work EXPLICITLY contains the exact information needed
2. No additional actions are required
3. The pending task would be redundant if executed

If there's ANY doubt, return is_covered=False
```

### Option 3: User Confirmation
Ask user before auto-completing tasks:

```
Task 1 completed. I think these tasks might also be done:
  - Task 2: Read messages (Reason: Messages visible in output)
  
Mark these as complete? [y/N]
```

### Option 4: Auditor Verification
Have the auditor verify that auto-completed tasks' goals were actually met.

---

## Recommendation

**Leave disabled** until we can implement Option 2 (Stricter LLM Prompt) with extensive testing. The risk of incorrectly skipping tasks is too high.

---

## Files Changed

- `Synapse/core/conductor.py` - Lines 3636-3651 commented out

---

## Testing

Run tasks with multiple steps and verify each step actually executes:

```bash
./scripts/run_solve_task.sh "Go to website A, extract data, process it, upload to website B"
```

Should see 4 separate task executions, not just first one with others auto-completing.

---

## Related Issues

- Task breakdown should create more atomic tasks that can't be "covered" by others
- DAG optimizer was already disabled - this is another optimization that was too aggressive
- Need better task completion verification in general

---

## Summary

Disabled overly aggressive task coverage checker that was incorrectly marking all pending tasks as complete after completing the first task. Tasks will now execute properly in sequence without premature completion.
