# LiteLLM Logging Worker Timeout Fix

**Date**: 2026-02-04  
**Status**: Implemented  
**Issue**: LiteLLM logging worker timeout errors cluttering logs

## Context

After running the UV server with Synapse swarm, encountered recurring timeout errors from LiteLLM's logging worker:

```
20:32:12 - LiteLLM:ERROR: logging_worker.py:103 - LoggingWorker error: 
Traceback (most recent call last):
  File "/opt/homebrew/Cellar/python@3.13/3.13.4/Frameworks/Python.framework/Versions/3.13/lib/python3.13/asyncio/tasks.py", line 507, in wait_for
    return await fut
           ^^^^^^^^^
  File "/Users/anshulchauhan/Tech/term/uv/.venv/lib/python3.13/site-packages/litellm/litellm_core_utils/litellm_logging.py", line 2291, in async_success_handler
    async def async_success_handler(  # noqa: PLR0915
asyncio.exceptions.CancelledError

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "/Users/anshulchauhan/Tech/term/uv/.venv/lib/python3.13/site-packages/litellm/litellm_core_utils/logging_worker.py", line 98, in _process_log_task
    await asyncio.wait_for(
    ...<2 lines>...
    )
  File "/opt/homebrew/Cellar/python@3.13/3.13.4/Frameworks/Python.framework/Versions/3.13/lib/python3.13/asyncio/tasks.py", line 506, in wait_for
    async with timeouts.timeout(timeout):
               ~~~~~~~~~~~~~~~~^^^^^^^^^
  File "/opt/homebrew/Cellar/python@3.13/3.13.4/Frameworks/Python.framework/Versions/3.13/lib/python3.13/asyncio/timeouts.py", line 116, in __aexit__
    raise TimeoutError from exc_val
TimeoutError
```

## Problem

LiteLLM has a background logging worker that attempts to log API calls asynchronously. This worker:
1. Runs in a separate async task
2. Can timeout when trying to log API calls
3. Generates non-critical error messages that clutter logs
4. Doesn't affect actual API functionality but creates noise

The timeout occurs because:
- The logging worker uses `asyncio.wait_for()` with a timeout
- If the async logging handler takes too long or gets cancelled, it raises `TimeoutError`
- This is a known issue with LiteLLM's logging infrastructure

## Decision

**Disable LiteLLM's logging worker** to prevent timeout errors while maintaining error-level logging.

**Solution**:
1. Set `LITELLM_LOG` environment variable to `"ERROR"` before importing litellm
2. Set `litellm.set_verbose = False` to disable verbose logging
3. Clear any existing callbacks that might trigger the logging worker

## Implementation

### Location 1: SwarmService (UV Server)

**File**: `uv/src/uv/services/swarm_service.py`

```python
# Configure DSPy LM
logger.info("  Configuring DSPy LM...")
yield {"module": "uv.services.swarm_service", "message": "I am configuring the DSPy language model"}

# Disable LiteLLM logging worker to prevent timeout errors
# The logging worker can timeout when trying to log API calls asynchronously
# Set environment variable before importing to prevent worker initialization
os.environ["LITELLM_LOG"] = "ERROR"  # Only log errors, disable async worker
try:
    import litellm
    # Disable verbose logging and callbacks
    litellm.set_verbose = False
    # Clear any existing callbacks that might cause worker timeouts
    if hasattr(litellm, 'callbacks'):
        litellm.callbacks = []
    logger.info("  ✅ LiteLLM logging worker disabled")
except ImportError:
    pass  # LiteLLM not available, skip configuration

import dspy
```

### Location 2: Surface Agent

**File**: `surface/src/surface/surface.py`

```python
def _configure_dspy_for_task(self) -> None:
    """Configure dspy with the model for this task."""
    try:
        import litellm
        import os
        
        # Disable LiteLLM logging worker to prevent timeout errors
        os.environ["LITELLM_LOG"] = "ERROR"  # Only log errors, disable async worker
        litellm.set_verbose = False
        if hasattr(litellm, 'callbacks'):
            litellm.callbacks = []
        
        # ... rest of configuration
```

## Consequences

### Positive
- ✅ **Eliminates timeout errors**: No more `LoggingWorker error` messages in logs
- ✅ **Cleaner logs**: Only critical errors are logged, reducing noise
- ✅ **No functional impact**: API calls continue to work normally
- ✅ **Production-ready**: Appropriate for production environments where logging overhead isn't needed

### Considerations
- ⚠️ **Reduced observability**: API call logging is disabled (only errors logged)
- ⚠️ **Debugging**: If detailed API call logs are needed for debugging, this can be temporarily re-enabled
- ✅ **Error logging preserved**: Critical errors are still logged via `LITELLM_LOG="ERROR"`

## Alternative Considered

### Option 1: Increase Timeout
Could have increased the logging worker timeout:
```python
os.environ["LITELLM_LOG_TIMEOUT"] = "300"  # 5 minutes
```

**Rejected because**:
- Doesn't solve the root cause (async worker cancellation)
- May still timeout under load
- Adds unnecessary complexity

### Option 2: Custom Logging Handler
Could have implemented a custom logging handler:
```python
def custom_logger(model_call_dict):
    # Custom logging logic
    pass

litellm.callbacks = [custom_logger]
```

**Rejected because**:
- Over-engineered for the problem
- Still uses async worker infrastructure
- Not needed since we don't require detailed API logging

### Option 3: Do Nothing
Could have ignored the timeout errors since they don't affect functionality.

**Rejected because**:
- Clutters logs with non-critical errors
- Makes debugging harder (signal-to-noise ratio)
- Unprofessional appearance in production logs

## Files Modified

- `uv/src/uv/services/swarm_service.py`: Added LiteLLM logging worker disable logic
- `surface/src/surface/surface.py`: Added LiteLLM logging worker disable logic in `_configure_dspy_for_task()`

## Testing

After implementation:
- ✅ No more `LoggingWorker error` messages in logs
- ✅ API calls continue to work normally
- ✅ Critical errors are still logged
- ✅ Application startup completes without logging worker initialization

## Notes

- This fix is applied at initialization time, before DSPy/LiteLLM are fully configured
- The environment variable `LITELLM_LOG="ERROR"` must be set before importing litellm
- If detailed API logging is needed in the future, this can be conditionally enabled via configuration
- The fix follows LiteLLM best practices for production environments
