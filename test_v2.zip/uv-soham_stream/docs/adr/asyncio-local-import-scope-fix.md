# ADR: Fix Parallel Execution AsyncIO Issues

**Status**: Implemented  
**Date**: 2026-02-02  
**Context**: Parallel execution failures in Conductor

## Problems

### Problem 1: asyncio Local Import Scope Issue

Parallel execution in `Synapse.core.conductor` was failing with error:
```
cannot access local variable 'asyncio' where it is not associated with a value
```

Error occurred at line 3226 when calling `asyncio.gather()`.

**Root Cause:**

Python scoping issue caused by redundant local import:

1. `asyncio` imported at module level (line 42)
2. Redundant `import asyncio` at line 3950 inside the `run()` method
3. Python treats `asyncio` as local variable in function scope
4. Reference to `asyncio.gather()` at line 3226 (before line 3950) fails because Python sees the local import later and treats the variable as uninitialized

### Problem 2: AsyncGenerator vs Coroutine

After fixing Problem 1, a new error appeared:
```
An asyncio.Future, a coroutine or an awaitable is required
```

**Root Cause:**

`_execute_actor_with_retry()` returns an `AsyncGenerator[Dict[str, Any], Any]`, not a coroutine. The parallel execution code was trying to pass the async generator directly to `asyncio.gather()`, which only accepts coroutines, futures, or awaitables.

## Solutions

### Solution 1: Remove Redundant Import

**Removed redundant local import at line 3950**

The module-level import (line 42) is sufficient for all uses within the function.

**Before:**
```python
# Line 42: Module level
import asyncio

# Line 3226: First usage (fails due to local scope)
results = await asyncio.gather(...)

# Line 3950: Redundant local import
import asyncio
if hasattr(self, '_consolidation_task'):
    self._consolidation_task = asyncio.create_task(...)
```

**After:**
```python
# Line 42: Module level
import asyncio

# Line 3226: Works correctly
results = await asyncio.gather(...)

# Line 3948: Uses module-level import
if hasattr(self, '_consolidation_task'):
    self._consolidation_task = asyncio.create_task(...)
```

### Solution 2: Wrap AsyncGenerator in Coroutine

**Created wrapper coroutine to consume async generator**

The wrapper consumes all events from the async generator and extracts the final result (matching the sequential execution path).

**Before:**
```python
parallel_results.append((
    ptask,
    actor_config,
    self._execute_actor_with_retry(  # Returns AsyncGenerator
        actor_config, ptask, context, kwargs, actor_context_dict
    )
))

results = await asyncio.gather(
    *[coro for _, _, coro in parallel_results],  # Fails: AsyncGenerator not coroutine
    return_exceptions=True
)
```

**After:**
```python
# Create wrapper coroutine that consumes the async generator
async def execute_task_wrapper(actor_cfg, tsk, ctx, kw, actor_ctx):
    """Wrapper to consume async generator and return final result."""
    result = None
    async for event in self._execute_actor_with_retry(
        actor_cfg, tsk, ctx, kw, actor_ctx
    ):
        # Extract result from final event (same as sequential path)
        if isinstance(event, dict) and event.get("type") == "result":
            result = event.get("result")
    return result

parallel_results.append((
    ptask,
    actor_config,
    execute_task_wrapper(  # Returns coroutine
        actor_config, ptask, context, kwargs, actor_context_dict
    )
))

results = await asyncio.gather(
    *[coro for _, _, coro in parallel_results],  # Works: coroutine
    return_exceptions=True
)
```

## Impact

- ✅ Parallel execution now works correctly
- ✅ Proper handling of async generators in parallel context
- ✅ Consistent result extraction between sequential and parallel paths
- ✅ No functional changes to execution logic
- ✅ Cleaner code without redundant imports

## Related

- Error logs: `uv/a.txt` lines 607-608, 2616-2618
- File: `Synapse/core/conductor.py`
- Function: `async def run()`
- Related method: `async def _execute_actor_with_retry()`
