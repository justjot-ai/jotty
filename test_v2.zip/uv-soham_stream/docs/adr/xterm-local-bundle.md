# ADR: Load xterm.js from Local Bundle Instead of CDN

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** xterm.js CDN loading failures causing fallback display

## Problem

xterm.js was loading from CDN (`https://cdn.jsdelivr.net/npm/xterm@5.3.0/`), which:
- Failed to load reliably
- Caused 50 retries before fallback
- Degraded user experience
- Required network connection

## Decision

Load xterm.js from local node_modules instead of CDN.

### Changes

**Before (CDN):**
```html
<!-- xterm.js CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/xterm@5.3.0/css/xterm.css">

<!-- xterm.js library -->
<script src="https://cdn.jsdelivr.net/npm/xterm@5.3.0/lib/xterm.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.js"></script>
```

**After (Local):**
```html
<!-- xterm.js CSS (loaded from node_modules) -->
<link rel="stylesheet" href="../../node_modules/xterm/css/xterm.css">

<!-- xterm.js library (loaded from node_modules) -->
<script src="../../node_modules/xterm/lib/xterm.js"></script>
<script src="../../node_modules/xterm-addon-fit/lib/xterm-addon-fit.js"></script>
```

### Dependencies

Already installed in `package.json`:
```json
{
  "dependencies": {
    "xterm": "^5.3.0",
    "xterm-addon-fit": "^0.8.0",
    "xterm-addon-web-links": "^0.9.0"
  }
}
```

## Consequences

### Positive
- ✅ xterm.js always available (no CDN dependency)
- ✅ Works offline
- ✅ Faster loading (local files)
- ✅ No network requests for xterm
- ✅ Consistent version control
- ✅ No retry delays

### Negative
- ⚠️ Slightly larger bundle size (~500KB)
- ⚠️ Need to manage xterm updates manually

### Neutral
- Fallback display still available if something goes wrong
- No code changes needed (just HTML paths)

## Testing

After restarting Electron app:

1. **Verify xterm loads:**
   ```javascript
   // In DevTools console
   console.log(window.Terminal);
   console.log(window.TerminalAddons);
   // Should show objects, not undefined
   ```

2. **Check Network tab:**
   - No requests to cdn.jsdelivr.net
   - xterm files loaded from file:// protocol

3. **Test terminal:**
   - Activate TerminalExecutor
   - Verify terminal displays with full xterm.js features
   - No fallback warning should appear

## Rollout

1. ✅ Update HTML to load from node_modules
2. ⏳ Restart Electron app
3. ⏳ Verify xterm loads successfully
4. ⏳ Test terminal functionality

## Future Considerations

- Keep xterm version updated in package.json
- Consider using webpack/bundler for better optimization
- May want to lazy-load xterm if not needed immediately

## Related Files

- `/electron-app/src/renderer/index.html` - Updated script/link paths
- `/electron-app/package.json` - xterm dependencies
- `/electron-app/src/renderer/js/agent-view-manager.js` - Fallback still available

## Action Required

**Restart the Electron app** for changes to take effect:

```bash
cd electron-app
npm start
# or
./scripts/run_electron_app.sh
```

After restart, xterm.js will load from local files and terminal will work immediately without retries.
