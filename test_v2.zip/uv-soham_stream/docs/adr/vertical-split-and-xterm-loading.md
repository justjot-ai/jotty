# ADR: Vertical Split Layout and xterm.js Loading Fix

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** User reported not seeing both agents simultaneously and wanted vertical (top-down) split

## Problem

Two issues identified:

1. **Layout Direction:** User wanted vertical split (top/bottom) instead of horizontal (side-by-side)
2. **xterm.js Loading:** Terminal handler failed to initialize because xterm.js wasn't loaded from CDN yet
3. **Sequential Execution:** Agents were running sequentially, not in parallel (backend issue)

## Root Cause Analysis

### Issue 1: Sequential Agent Execution

From the logs:
```
agent_activated: BrowserExecutor
agent_deactivated: BrowserExecutor  ← Browser finishes first
agent_activated: TerminalExecutor   ← Then terminal starts
```

**This is NOT a UI issue.** The backend is running agents sequentially, not in parallel. The UI correctly shows whichever agent is active, but only one agent is active at a time.

### Issue 2: xterm.js Loading Race Condition

xterm.js loads from CDN asynchronously:
```html
<script src="https://cdn.jsdelivr.net/npm/xterm@5.3.0/lib/xterm.js"></script>
```

When terminal handler tries to initialize immediately, xterm.js might not be loaded yet, causing:
```
xterm.js not loaded yet, will initialize when available
```

### Issue 3: Layout Direction

User preference is vertical split (top/bottom) for better screen utilization on wide monitors.

## Decision

### 1. Change Layout to Vertical Split

**Before:**
```css
/* Horizontal split */
.agents-grid-workspace.split-view-2 {
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr;
}
```

**After:**
```css
/* Vertical split (top-down) */
.agents-grid-workspace.split-view-2 {
  grid-template-columns: 1fr;
  grid-template-rows: 1fr 1fr;
}
```

### 2. Fix xterm.js Loading with Retry Logic

**Before:**
```javascript
if (!window.Terminal || !window.TerminalAddons) {
  console.warn('xterm.js not loaded yet, will initialize when available');
  return;
}
```

**After:**
```javascript
if (!window.Terminal || !window.Terminal.Terminal || 
    !window.TerminalAddons || !window.TerminalAddons.FitAddon) {
  console.warn('xterm.js not loaded yet, will retry...');
  setTimeout(() => this.initialize(), 100);
  return;
}
```

### 3. Queue Terminal Events During Initialization

**Before:** Events were dropped if terminal wasn't ready

**After:** Events are queued and retried after initialization:
```javascript
handleOutput(data) {
  if (!this.terminal) {
    this.initialize();
    if (!this.terminal) {
      setTimeout(() => this.handleOutput(data), 100);
      return;
    }
  }
  this.terminal.write(data.output);
}
```

## Backend Fix Required

**IMPORTANT:** To see both agents simultaneously, the backend must:

1. **Keep agents active in parallel:**
   ```python
   # DON'T deactivate browser before starting terminal
   await broadcast_agent_event({"type": "agent_activated", "agent": "BrowserExecutor"})
   # ... browser does work ...
   # DON'T send agent_deactivated yet
   
   await broadcast_agent_event({"type": "agent_activated", "agent": "TerminalExecutor"})
   # ... terminal does work ...
   
   # Only deactivate when both are done
   await broadcast_agent_event({"type": "agent_deactivated", "agent": "BrowserExecutor"})
   await broadcast_agent_event({"type": "agent_deactivated", "agent": "TerminalExecutor"})
   ```

2. **Or use async execution:**
   ```python
   # Run agents in parallel
   async with asyncio.TaskGroup() as tg:
       tg.create_task(browser_executor.execute())
       tg.create_task(terminal_executor.execute())
   ```

## Consequences

### Positive
- Vertical split better utilizes screen space on wide monitors
- xterm.js loading is more robust with retry logic
- Terminal events are queued and not dropped
- UI correctly handles parallel agents when backend sends them

### Negative
- Backend needs to be updated to actually run agents in parallel
- Retry logic adds small delay (100ms) when xterm.js is loading

## Testing

### Test xterm.js Loading
1. Open DevTools Network tab
2. Throttle network to "Slow 3G"
3. Reload page
4. Verify terminal still initializes (with retries)

### Test Vertical Split
1. Activate two agents simultaneously (requires backend fix)
2. Verify they appear top/bottom, not side-by-side
3. Check each gets 50% height

### Test Event Queueing
1. Send terminal output immediately after activation
2. Verify output appears (not dropped)
3. Check console for retry messages

## Next Steps

1. **Backend:** Update agent execution to keep agents active in parallel
2. **Backend:** Don't deactivate agents until they're truly done
3. **Backend:** Consider async/await for parallel agent execution
4. **UI:** Monitor for any other CDN loading race conditions
5. **Consider:** Loading xterm.js locally instead of from CDN

## Related Files

- `/electron-app/src/renderer/css/styles.css` - Layout change
- `/electron-app/src/renderer/js/agent-view-manager.js` - xterm.js loading fix
- Backend agent execution code (needs update for parallel execution)
