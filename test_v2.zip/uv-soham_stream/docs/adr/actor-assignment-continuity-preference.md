# Actor Assignment Continuity Preference

**Date**: 2026-01-31  
**Status**: ⚠️ DEPRECATED - Removed on 2026-02-08

## Context

When multiple agents have the same capabilities for a task, the assignment logic was distributing tasks based on workload balancing alone. This caused fragmented task execution where related tasks were assigned to different agents.

### Example Issue

For task: "Summarize messages of whatsapp group synapse"

**Breakdown**:
- Task 1: Navigate to synapse group → BrowserExecutor ✅
- Task 2: Extract messages → BrowserExecutor ✅
- Task 3: Summarize messages → **TerminalExecutor** ❌

**Problem**: Both BrowserExecutor and TerminalExecutor have `summarization` capability, but Task 3 was assigned to TerminalExecutor instead of BrowserExecutor, breaking the natural flow.

**Why This Matters**:
- BrowserExecutor already has the context from Tasks 1 & 2
- TerminalExecutor would need to work with data from a different agent
- User experience feels fragmented rather than continuous

## Decision

Modified the actor assignment logic to **prefer continuity** when multiple actors have the same capabilities:

### 1. Enhanced ActorAssignmentSignature

Updated prompt to explicitly prioritize continuity:

```python
"""
Consider:
- Task type and requirements
- Actor capabilities and expertise match
- Actor workload (if multiple tasks)
- **CONTINUITY PREFERENCE**: When multiple actors have the SAME capabilities for this task,
  STRONGLY PREFER the actor that has been assigned the most recent tasks. This creates
  a natural flow and feels like continuation rather than fragmented work.

Assignment Priority:
1. Match capabilities (required)
2. If multiple actors match, prefer the one with recent task assignments
3. Balance workload only if no recent assignments exist
"""
```

### 2. Enhanced Assignment Context

Changed from simple workload counts to rich history:

**Before**:
```python
current_assignments=str(actor_workload)  # {"BrowserExecutor": 2, "TerminalExecutor": 0}
```

**After**:
```python
current_assignments=str(actor_history)  
# {
#   "BrowserExecutor": {
#     "task_count": 2,
#     "recent_tasks": [
#       {"task_id": "task_1", "task_name": "Navigate to synapse group"},
#       {"task_id": "task_2", "task_name": "Extract messages"}
#     ]
#   },
#   "TerminalExecutor": {
#     "task_count": 0,
#     "recent_tasks": []
#   }
# }
```

This provides the LLM with enough context to make informed continuity decisions.

## Benefits

1. **Natural Flow**: Related tasks stay with the same agent
2. **Context Preservation**: Agent retains working context from previous tasks
3. **Better UX**: Feels like continuous work rather than fragmented handoffs
4. **Smarter Assignment**: LLM can see the task history and make better decisions
5. **Maintains Load Balancing**: Only applies when capabilities match

## Assignment Logic

```
IF multiple actors have required capability:
    1. Check recent_tasks for each actor
    2. Prefer actor with most recent assignments
    3. Fall back to workload balancing if no clear preference
ELSE:
    Assign to the only capable actor
```

## Expected Behavior

For the WhatsApp summarization example:

- Task 1: BrowserExecutor (first task, browser capability)
- Task 2: BrowserExecutor (continuation, browser capability)
- Task 3: **BrowserExecutor** ✅ (continuation, both have summarization but Browser has recent tasks)

## Files Modified

- `Synapse/signatures/todo_creator_signatures.py`: Enhanced `ActorAssignmentSignature` with continuity guidance
- `Synapse/agents/todo_creator_agent.py`: Changed `actor_workload` to `actor_history` with task tracking

## Trade-offs

**Pros**:
- Better task continuity
- Improved context utilization
- More intuitive task flow

**Cons**:
- Slightly more data passed to LLM (negligible)
- May create temporary load imbalance (acceptable for continuity)

## Related Issues

- Fixes: Task 3 (TextSummarizer) being assigned to TerminalExecutor instead of BrowserExecutor
- Improves: Overall multi-agent task distribution and user experience

---

## ⚠️ DEPRECATION NOTICE (2026-02-08)

**Status**: REMOVED

**Reason**: Continuity preference was causing incorrect agent assignments when capabilities were empty or misparsed. It allowed agents without required capabilities to be selected based on recent task history, leading to task failures.

**Replacement**: Agent assignment now focuses solely on capability matching:
- Only assign actors with REQUIRED capabilities
- Reject actors that lack required capabilities
- Balance workload only among capable actors

**See**: `docs/adr/browser-executor-selection-and-data-accuracy-issues.md` for details on why continuity preference was removed.

**Files Modified**:
- `Synapse/signatures/todo_creator_signatures.py`: Removed continuity preference from `ActorAssignmentSignature`
- `Synapse/agents/todo_creator_agent.py`: Removed `actor_history` tracking and `current_assignments` parameter
