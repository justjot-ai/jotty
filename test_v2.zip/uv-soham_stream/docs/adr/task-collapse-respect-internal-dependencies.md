# ADR: Task Collapse with Same-Actor Merging

## Status
Accepted (2026-02-02), Updated (2026-02-02)

## Context
The `_collapse_consecutive_tasks` method in `TodoCreatorAgent` merges consecutive tasks by the same actor. The key question was: should tasks with internal dependencies (within the same actor group) be merged?

## Decision
**Same-actor groups ALWAYS merge**, regardless of internal dependencies:
1. If tasks have the **same actor** → MERGE (actor handles execution order internally)
2. **External dependencies** (on tasks from different actors) are preserved
3. The merged task description contains all sub-tasks, so the actor knows the execution order

### Rationale
When the same actor executes multiple tasks, they can manage the internal execution order. For example, if tasks 1→2→3→4 are all assigned to ActorA, merging them into one task is efficient - ActorA will execute them in order based on the merged description.

## Implementation

### Key Methods
- `_has_internal_dependencies(dag, task_ids)` - Checks for internal deps (used for logging)
- `_merge_task_group(dag, task_ids, actor, ...)` - Merges tasks, collects ALL external deps

### Algorithm
```
For each consecutive group of tasks by same actor:
  1. If single task → keep as is
  2. If multiple tasks → ALWAYS merge (same actor handles order)
  3. Collect ALL external dependencies from ALL merged tasks
```

## Scenarios

| Tasks | Actors | Dependencies | Result |
|-------|--------|--------------|--------|
| 1,2,3,4 | A,A,A,A | 2→1, 3→2, 4→3 | `1_2_3_4` (all merge, no external deps) |
| 1,2,3,4 | A,B,A,A | 3→2, 4→2 | `1`, `2`, `3_4` (3_4 depends on 2) |
| 1,2,3,4 | A,A,A,B | 2→1, 3→2 | `1_2_3`, `4` (split by actor change) |

## Consequences

### Positive
- Fewer tasks = fewer LLM calls
- Same actor can optimize internal execution
- External dependencies correctly preserved

### Negative
- Merged task descriptions can be long
- Actor must understand sub-task ordering from description

## Related
- A-Team Review: `docs/review/A_TEAM_TASK_COLLAPSE_DEPENDENCY_REVIEW.md`
- Tests: `tests/test_task_collapse_dependencies.py` (12 tests)
- Code: `Synapse/agents/todo_creator_agent.py`
