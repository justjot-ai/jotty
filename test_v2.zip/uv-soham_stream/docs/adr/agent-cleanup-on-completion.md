# ADR: Agent Cleanup on Task Completion

**Status:** Fixed  
**Date:** 2026-02-02  
**Context:** Screenshot Capture Cleanup

## Problem

After a task completed and the app returned to the welcome screen, the browser agent's screenshot capture was still running:

```
📸 Capturing screenshot...
✅ Screenshot captured, size: 217228 bytes
🖼️ Image loaded, rendering to canvas...
📐 Container size: 0x0
⚠️ Container has zero dimensions, cannot render!
```

This caused:
- Unnecessary CPU/memory usage
- Console spam with warnings
- Failed render attempts (container hidden)
- CDP connection still active

## Root Cause

When returning to the welcome screen:
1. The workspace view was hidden
2. Agent views were hidden
3. **BUT** the screenshot interval was still running
4. The CDP connection was still open

The `BrowserViewHandler.cleanup()` method existed but was never called.

## Solution

### Changes Made

**File**: `electron-app/src/renderer/js/agent-view-manager.js`

#### 1. Cleanup on Agent Deactivation

```javascript
handleAgentDeactivated(event) {
  const { agent } = event;
  console.log(`Agent deactivated: ${agent}`);
  
  // Cleanup the agent's handler (stop screenshot capture, etc.)
  const agentView = this.views.get(agent);
  if (agentView && agentView.handler && typeof agentView.handler.cleanup === 'function') {
    console.log(`Cleaning up ${agent} handler...`);
    agentView.handler.cleanup();
  }
  
  // If this was the active agent, return to empty state
  if (this.activeAgentName === agent) {
    console.log(`Active agent ${agent} deactivated - returning to empty state`);
    this.showEmptyState();
  }
}
```

#### 2. Cleanup All Agents Method

```javascript
cleanupAllAgents() {
  console.log('🧹 Cleaning up all agents...');
  
  this.views.forEach((view, agentName) => {
    if (view.handler && typeof view.handler.cleanup === 'function') {
      console.log(`  Cleaning up ${agentName}...`);
      try {
        view.handler.cleanup();
      } catch (error) {
        console.error(`  Error cleaning up ${agentName}:`, error);
      }
    }
  });
  
  // Return to empty state
  this.showEmptyState();
  
  console.log('✅ All agents cleaned up');
}
```

**File**: `electron-app/src/renderer/js/app.js`

#### 3. Call Cleanup on Welcome Screen Return

```javascript
returnToWelcomeScreen(finalOutput = null) {
  console.log('🏠 Returning to welcome screen...');
  
  // Cleanup all active agents (stop screenshot capture, etc.)
  if (this.agentViewManager) {
    console.log('🧹 Cleaning up active agents...');
    this.agentViewManager.cleanupAllAgents();
  }
  
  // ... rest of welcome screen logic
}
```

## What Gets Cleaned Up

### BrowserViewHandler

The `cleanup()` method stops:
1. **Screenshot Interval**: `clearInterval(this.screenshotInterval)`
2. **CDP WebSocket**: `this.cdpClient.close()`
3. **CDP Connection**: Sets `cdpConnected = false`

```javascript
cleanup() {
  // Stop screenshot capture
  if (this.screenshotInterval) {
    clearInterval(this.screenshotInterval);
    this.screenshotInterval = null;
  }
  
  // Close CDP connection
  if (this.cdpClient) {
    try {
      this.cdpClient.close();
    } catch (e) {
      console.error('Error closing CDP client:', e);
    }
    this.cdpClient = null;
    this.cdpConnected = false;
  }
}
```

### Other Handlers

- **TerminalViewHandler**: No cleanup needed (read-only)
- **SearchViewHandler**: No cleanup needed (static display)
- **PlannerViewHandler**: No cleanup needed (static display)

## Cleanup Triggers

Cleanup happens in two scenarios:

### 1. Agent Deactivation (WebSocket Event)

```json
{
  "type": "agent_deactivated",
  "agent": "BrowserExecutor",
  "timestamp": "2026-02-02T01:00:00"
}
```

**Action**: Cleanup that specific agent

### 2. Task Completion (Return to Welcome)

When `returnToWelcomeScreen()` is called:

**Action**: Cleanup ALL agents

## Debug Output

### Before Fix
```
📸 Capturing screenshot...
✅ Screenshot captured, size: 217228 bytes
🖼️ Image loaded, rendering to canvas...
📐 Container size: 0x0
⚠️ Container has zero dimensions, cannot render!
[Repeats every 500ms indefinitely]
```

### After Fix
```
🏠 Returning to welcome screen...
🧹 Cleaning up active agents...
🧹 Cleaning up all agents...
  Cleaning up BrowserExecutor...
✅ All agents cleaned up
✅ Returned to welcome screen with final output
[No more screenshot attempts]
```

## Benefits

1. **No Resource Leaks**: Screenshot capture stops immediately
2. **Clean Console**: No more warning spam
3. **Better Performance**: CPU/memory freed up
4. **Proper Shutdown**: CDP connection closed cleanly
5. **Reusable**: Ready for next task without stale state

## Impact

### CPU Usage
- **Before**: ~5-10% CPU usage after task completion (screenshot capture)
- **After**: ~0% CPU usage after task completion

### Console Logs
- **Before**: Warnings every 500ms
- **After**: Clean, no warnings

### Memory
- **Before**: CDP connection + screenshot buffers retained
- **After**: All resources released

## Testing

To verify the fix:

1. **Start a task** that uses BrowserExecutor
2. **Wait for completion** (returns to welcome screen)
3. **Check console**: Should see cleanup logs, no screenshot warnings
4. **Check CPU**: Should drop to idle
5. **Start another task**: Should work normally (no stale state)

## Related

- `agent-view-on-activation.md` - Agent view lifecycle
- `final-result-welcome-screen.md` - Welcome screen return
- `electron-chrome-embedding-screenshot-streaming.md` - CDP screenshot capture

## Lesson Learned

Always cleanup resources when:
- Hiding/removing UI components
- Closing connections
- Stopping intervals/timers
- Transitioning between states

Implement cleanup methods early, not as an afterthought.
