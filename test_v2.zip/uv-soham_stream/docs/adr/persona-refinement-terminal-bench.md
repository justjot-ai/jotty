# ADR: Persona Refinement for Terminal-Bench Tasks

**Date:** 2026-01-10  
**Status:** Accepted  
**Deciders:** A-Team (Marcus, Sarah, Viktor, Luna, Raj)

## Context

The terminal-bench benchmark suite contains 241 tasks across various categories (machine-learning, system-administration, security, games, etc.). Each task was assigned personas based on keyword matching, resulting in:

- **Problem:** Average of 5.75 personas per task (too many)
- **Issue:** Generic assignments that didn't reflect optimal team composition
- **Consequence:** Noise in persona-to-task mapping, making it hard to identify the right experts

## Decision

Implement a refined persona assignment strategy that:

1. **Designates a Lead Persona** for each task (primary owner of the problem domain)
2. **Limits team size** to 3-5 personas max (1 lead + up to 4 supports)
3. **Uses hierarchical selection:**
   - Category → Primary persona (40% weight)
   - Technical domain analysis → Specialized personas (30% weight)
   - Output/goal type → Supporting personas (20% weight)
   - Tags → Enhancement (10% weight)

### Selection Algorithm

```python
def refine_personas(task):
    # Step 1: Get category-based primary personas (max 2)
    primaries = CATEGORY_PRIMARY_MAP[task.category][:2]
    
    # Step 2: Score specialized personas via instruction analysis
    for persona in SPECIALIZED_PERSONAS:
        score = match_patterns(task.instruction, persona.patterns)
        if score > threshold:
            primaries.insert(0, persona)  # More specific = higher priority
    
    # Step 3: Add knowledge-domain based supports (max 3)
    supports = [DOMAIN_SUPPORT_MAP[d] for d in task.knowledge_domains]
    
    # Step 4: Combine, dedupe, remove overlaps, cap at 5
    return prioritize_and_cap(primaries + supports, max=5)
```

### Category to Lead Persona Mapping

| Category | Primary Persona(s) |
|----------|-------------------|
| machine-learning | ML Engineer, Data Scientist |
| model-training | ML Engineer, Data Scientist |
| scientific-computing | Research Scientist, Data Scientist |
| system-administration | System Administrator, DevOps Engineer |
| security | Security Engineer, Cryptographer |
| games | Game Developer, Software Engineer |
| software-engineering | Software Engineer, Backend Engineer |
| debugging | Software Engineer, QA Engineer |
| data-science | Data Scientist, Data Engineer |

### Knowledge Domain to Support Mapping

| Knowledge Domain | Supporting Persona |
|-----------------|-------------------|
| Docker/Kubernetes | DevOps Engineer |
| PyTorch/TensorFlow | ML Engineer |
| SQL | Database Administrator |
| Cryptography | Cryptographer |
| Linux/QEMU | System Administrator |
| HTML/CSS | Frontend Engineer |
| Bioinformatics | Bioinformatics Scientist |
| Financial | Financial Engineer |

## Consequences

### Positive

- **Reduced average personas:** 5.75 → 3.65 per task (36% reduction)
- **Clear ownership:** Each task now has a designated lead persona
- **Better signal:** Persona assignments reflect actual task requirements
- **Team composition:** Realistic team sizes (3-5 experts vs 8+ generic)

### Lead Persona Distribution (Post-Refinement)

| Lead Persona | Count | Percentage |
|-------------|-------|------------|
| Software Engineer | 63 | 26.1% |
| Security Engineer | 34 | 14.1% |
| Data Scientist | 26 | 10.8% |
| Research Scientist | 23 | 9.5% |
| System Administrator | 19 | 7.9% |
| Game Developer | 11 | 4.6% |
| ML Engineer | 10 | 4.1% |
| Database Administrator | 10 | 4.1% |

### Negative

- **Potential under-assignment:** Some edge cases may need manual review
- **Pattern dependency:** Effectiveness depends on instruction keyword coverage

## Implementation

- **Script:** `refine_personas.py`
- **Input:** `terminal-bench-personas-enhanced.yaml`
- **Output:** `terminal-bench-personas-refined.yaml`
- **Review:** `review/persona-refinement-strategy-review.md`

## References

- A-Team Review Meeting: `review/persona-refinement-strategy-review.md`
- Original Analysis: `analyze_task_personas.py`
- Enhanced Analysis: `analyze_persona_subcategories_enhanced.py`
