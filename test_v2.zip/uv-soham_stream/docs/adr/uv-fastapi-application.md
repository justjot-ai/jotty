# ADR: UV FastAPI Web Application

**Status**: Implemented  
**Date**: 2026-01-31  
**Author**: Anshul Chauhan

## Context

Created a new modular FastAPI web application called "uv" with Poetry for dependency management. The application follows modern Python best practices and provides a production-ready REST API with authentication.

## Decision

Implemented a complete FastAPI application with the following structure:

### Architecture

```
uv/
├── src/uv/                    # Source code
│   ├── api/                   # API routes (v1)
│   │   └── v1/
│   │       ├── health.py      # Health check endpoints
│   │       ├── auth.py        # Authentication
│   │       └── users.py       # User management
│   ├── core/                  # Core utilities
│   │   └── security.py        # Password hashing/verification
│   ├── db/                    # Database layer
│   │   ├── base.py           # Base models
│   │   ├── session.py        # Session management
│   │   └── models/           # SQLAlchemy models
│   ├── schemas/               # Pydantic schemas
│   │   ├── auth.py
│   │   └── user.py
│   ├── services/              # Business logic
│   │   ├── auth_service.py
│   │   └── user_service.py
│   ├── utils/                 # Utilities
│   ├── config.py              # Configuration
│   ├── dependencies.py        # FastAPI dependencies
│   └── main.py                # Application entry
├── tests/                     # Test suite
├── pyproject.toml             # Poetry configuration
├── .env.example               # Environment template
└── run_server.sh              # Startup script
```

### Key Features

1. **Authentication System**
   - JWT-based authentication
   - Password hashing with bcrypt
   - Token refresh mechanism
   - OAuth2 password flow

2. **Database Layer**
   - SQLAlchemy async ORM
   - Support for SQLite (dev) and PostgreSQL (prod)
   - Repository pattern implementation
   - Automatic timestamp tracking

3. **API Structure**
   - Versioned API (v1)
   - Health check endpoints
   - User management
   - Authentication endpoints
   - Automatic OpenAPI documentation

4. **Configuration**
   - Environment-based configuration
   - Pydantic Settings for validation
   - Support for .env files
   - CORS configuration

5. **Testing**
   - Pytest with async support
   - Test fixtures for database
   - Test client setup
   - Coverage support

6. **Development Tools**
   - Black for formatting
   - Ruff for linting
   - MyPy for type checking
   - Poetry for dependency management

### Technology Stack

- **FastAPI**: Web framework
- **Uvicorn**: ASGI server
- **SQLAlchemy**: ORM with async support
- **Pydantic**: Data validation
- **python-jose**: JWT handling
- **passlib**: Password hashing
- **pytest**: Testing framework
- **Poetry**: Dependency management

## Consequences

### Positive

1. **Production-Ready**: Includes authentication, database, and testing
2. **Modular Design**: Clean separation of concerns
3. **Type Safety**: Full typing with Pydantic and MyPy
4. **Async Support**: Fully async for better performance
5. **Easy Testing**: Comprehensive test suite included
6. **Auto Documentation**: Swagger UI and ReDoc built-in
7. **Scalable**: Service layer pattern for business logic
8. **Secure**: JWT auth, password hashing, CORS support

### Negative

1. **Initial Complexity**: More setup than a simple app
2. **Learning Curve**: Requires understanding of FastAPI patterns
3. **Database Migration**: Needs Alembic setup for production

## Usage

### Installation

```bash
cd uv
poetry install
cp .env.example .env
```

### Running

```bash
# Using script
./run_server.sh

# Or directly
poetry run uvicorn uv.main:app --reload
```

### Testing

```bash
cd uv
poetry run pytest
poetry run pytest --cov=uv --cov-report=html
```

### API Access

- **API**: http://localhost:8000
- **Docs**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Endpoints

- `GET /health` - Health check
- `POST /api/v1/auth/register` - Register user
- `POST /api/v1/auth/login` - Login
- `GET /api/v1/users/me` - Get current user
- `PUT /api/v1/users/me` - Update user

## Integration

The UV application is standalone but can be integrated with:
- Synapse system for orchestration
- Surface agents for tool execution
- Terminal-bench for benchmarking

## Future Enhancements

1. Database migrations with Alembic
2. Redis caching layer
3. WebSocket support
4. Rate limiting
5. File upload endpoints
6. Admin panel
7. Email verification
8. Role-based access control (RBAC)
9. API key authentication
10. Prometheus metrics

## References

- FastAPI: https://fastapi.tiangolo.com
- SQLAlchemy: https://www.sqlalchemy.org
- Poetry: https://python-poetry.org
- Pydantic: https://docs.pydantic.dev
