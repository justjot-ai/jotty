# ADR: Task Breakdown at Workflow Level, Not Technical Implementation Level

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: TaskBreakdownAgent creating 40+ technical tasks instead of 5-10 workflow tasks

## Problem

Even with a perfect implementation plan describing a simple 5-step workflow, the `TaskBreakdownAgent` was creating 40+ granular technical tasks.

**Example**:

**Implementation Plan** (Perfect - 5 steps):
```
Workflow for WhatsApp Conversation Summarization:

1. BrowserExecutor: Open WhatsApp Web
   - Navigate to web.whatsapp.com
   
2. User Authentication via QR Code
   - User scans QR with their phone
   - Wait for successful authentication
   
3. BrowserExecutor: Navigate to Group
   - Find and open clawdbot-test group
   
4. BrowserExecutor: Extract Conversations
   - Scroll and extract message elements
   - Parse sender, timestamp, content
   
5. Summarizer: Generate Summary
   - Summarize extracted conversations
```

**Generated DAG** (Wrong - 43 tasks):
```
TASK_01: Setup project directory structure
TASK_02: Create requirements.txt
TASK_03: Install selenium package
TASK_04: Install webdriver-manager
TASK_05: Create browser_automation.py
TASK_06: Import necessary libraries
TASK_07: Define WebDriver class
TASK_08: Create initialize_driver() method
TASK_09: Configure Chrome options
TASK_10: Setup headless mode
...
TASK_40: Parse message elements
TASK_41: Extract text from DOM
TASK_42: Call summarization API
TASK_43: Display results
```

**Should be** (5-6 tasks):
```
TASK_01: BrowserExecutor: Open WhatsApp Web
TASK_02: Wait for user QR authentication
TASK_03: BrowserExecutor: Navigate to clawdbot-test group
TASK_04: BrowserExecutor: Extract message elements
TASK_05: Summarizer: Summarize conversations
TASK_06: Display summary to user
```

## Root Cause

The `TaskBreakdownAgent` was treating the implementation plan as a **coding project specification** rather than a **workflow description**.

It was breaking down each workflow step into:
1. Setup/installation tasks
2. File creation tasks
3. Code writing tasks
4. Configuration tasks
5. Execution tasks

This made sense **IF** we were building the capabilities from scratch, but we're **NOT** - we're using existing actors!

## Solution: Extract Tasks at Workflow Level Only

### Updated `ExtractTasksSignature`

**Before** (encouraged breaking down):
```python
"""Extract granular tasks from an implementation plan...

INCLUDE:
- Environment setup (pip install, dependencies)
- File creation (source code, config files, tests)
- Code implementation (functions, classes, modules)
- Script execution (running the main implementation)
"""
```

**After** (workflow level only):
```python
"""Extract WORKFLOW tasks from an implementation plan - NOT implementation details.

The plan references actors like BrowserExecutor, Summarizer - these ALREADY EXIST.

CRITICAL: Extract ONLY the HIGH-LEVEL WORKFLOW steps. Do NOT break down into technical subtasks.

WRONG APPROACH (Too Granular):
❌ "Install selenium", "Create browser_bot.py", "Setup WebDriver"
❌ Breaking "BrowserExecutor: Open WhatsApp Web" into 10 subtasks

RIGHT APPROACH (Workflow Level):
✅ "BrowserExecutor: Open WhatsApp Web"
✅ "Wait for user QR authentication"
✅ "BrowserExecutor: Navigate to group"

RULES:
1. If plan says "BrowserExecutor does X" → create ONE task "BrowserExecutor: X"
2. Do NOT create tasks to install libraries/tools
3. Do NOT break workflow steps into technical subtasks
4. Keep tasks at the SAME LEVEL as described in the plan
5. If plan has 5 steps → output should have ~5 tasks (not 50)
"""
```

### Key Changes

#### 1. **Explicit Instruction: Count the Steps**

```python
tasks_list = dspy.OutputField(
    desc="...
    If plan has 5 steps → output should have ~5 tasks (not 50)
    ...
    IMPORTANT: Count the workflow steps in the plan. 
    Your output should have approximately THE SAME NUMBER of tasks."
)
```

#### 2. **Clear Examples of Wrong vs. Right**

```python
WRONG APPROACH (Too Granular):
❌ "Install selenium", "Create browser_bot.py", "Setup WebDriver", "Configure Chrome options"
❌ Breaking "BrowserExecutor: Open WhatsApp Web" into 10 subtasks

RIGHT APPROACH (Workflow Level):
✅ "BrowserExecutor: Open WhatsApp Web"
✅ "Wait for user QR authentication"
✅ "BrowserExecutor: Navigate to group"
✅ "BrowserExecutor: Extract messages"
✅ "Summarizer: Summarize conversations"
```

#### 3. **Explicit Exclusions**

```python
EXCLUDE (These should NEVER appear):
- Installation tasks (pip install, npm install, apt-get)
- Code creation tasks (Create X.py, Write function Y)
- Configuration tasks (Setup config.yaml, Configure settings)
- Library/model loading (Load BART model, Initialize WebDriver)
- Environment setup (virtual environment, IDE setup)
```

#### 4. **One-to-One Mapping Rule**

```python
RULES:
1. If plan says "BrowserExecutor does X" → create ONE task "BrowserExecutor: X"
2. If plan says "Summarizer does Y" → create ONE task "Summarizer: Y"
3. Do NOT break workflow steps into technical subtasks
```

## Expected Behavior After Fix

### WhatsApp Summarization Example

**Implementation Plan** (Input):
```markdown
Workflow for WhatsApp Conversation Summarization (5 steps):

1. BrowserExecutor: Open WhatsApp Web
2. User Authentication via QR Code  
3. BrowserExecutor: Navigate to Group
4. BrowserExecutor: Extract Conversations
5. Summarizer: Generate Summary
```

**Task DAG** (Output - Should have ~5-6 tasks):
```
TASK_01: BrowserExecutor: Open WhatsApp Web
  TYPE: implementation
  DESC: Navigate to web.whatsapp.com
  DEPENDENCIES: []

TASK_02: Wait for user QR authentication
  TYPE: implementation
  DESC: Wait for user to scan QR code
  DEPENDENCIES: [TASK_01]

TASK_03: BrowserExecutor: Navigate to clawdbot-test group
  TYPE: implementation
  DESC: Find and open the specified group
  DEPENDENCIES: [TASK_02]

TASK_04: BrowserExecutor: Extract message elements
  TYPE: implementation
  DESC: Scrape conversation messages from DOM
  DEPENDENCIES: [TASK_03]

TASK_05: Summarizer: Summarize conversations
  TYPE: implementation
  DESC: Generate summary from extracted messages
  DEPENDENCIES: [TASK_04]

TASK_06: Display summary to user
  TYPE: validation
  DESC: Show the generated summary
  DEPENDENCIES: [TASK_05]
```

**Result**: 6 tasks (matches 5 workflow steps + 1 display step)

## Comparison: Before vs. After

| Aspect | Before | After |
|--------|--------|-------|
| **Task Count** | 43 tasks | 6 tasks |
| **Level** | Technical (pip install, create files) | Workflow (actor actions) |
| **Matches Plan** | No (plan has 5 steps, DAG has 43) | Yes (plan has 5 steps, DAG has ~6) |
| **Actor Usage** | Creates new code/tools | Uses existing actors |
| **Dependencies** | Complex (40+ edges) | Simple (linear 5-6 steps) |
| **Execution Time** | Hours (if executed literally) | Minutes (actual workflow) |

## Benefits

1. ✅ **Task Count Matches Plan**: 5 plan steps → ~5 tasks
2. ✅ **Workflow Level**: Tasks describe what to do, not how to code it
3. ✅ **Uses Existing Actors**: Tasks reference BrowserExecutor, Summarizer
4. ✅ **Simple Dependencies**: Mostly linear workflow
5. ✅ **Clearer Intent**: DAG shows actual workflow, not implementation details
6. ✅ **Faster Execution**: 6 workflow tasks vs. 43 technical tasks
7. ✅ **Easier to Understand**: User can see what will happen

## Why This Matters

### Without This Fix
```
User sees DAG with 43 tasks:
"Install selenium... create browser_bot.py... setup WebDriver... configure options..."

User thinks: "Wait, I thought we had browser_interaction capability? 
              Why are we installing Selenium?"
```

### With This Fix
```
User sees DAG with 6 tasks:
"BrowserExecutor: Open WhatsApp Web... Wait for QR auth... Navigate to group... 
 Extract messages... Summarizer: Summarize..."

User thinks: "Perfect! That's exactly the workflow I expected."
```

## Implementation Notes

### No Capabilities Passed to TaskBreakdownAgent

As per user request, we **DO NOT pass** actor capabilities to the `TaskBreakdownAgent`. 

Instead, we rely on:
1. **Clear signature instructions**: Extract workflow-level tasks only
2. **Examples in prompt**: Show correct vs. incorrect task extraction
3. **Counting guidance**: "If plan has 5 steps → ~5 tasks"

The agent infers from the plan text itself:
- Sees "BrowserExecutor: Open WhatsApp Web" → Creates ONE task with that exact description
- Sees "Summarizer: Generate Summary" → Creates ONE task with that exact description

### Why Not Pass Capabilities?

Passing capabilities could:
1. Confuse the agent (too much information)
2. Tempt it to "be helpful" by adding setup tasks
3. Make it try to validate if capabilities exist (not its job)

Better approach: **Keep TaskBreakdownAgent simple** - just extract what the plan says, at the same granularity level.

## Related ADRs

- `capabilities-are-existing-actors-not-code-to-write.md`: Why capabilities are actors, not things to build
- `dag-optimization-remove-unnecessary-tasks.md`: Second-pass optimization at TodoCreatorAgent level
- `skip-library-research-for-existing-capabilities.md`: Skip researching libraries for existing capabilities

## Conclusion

The `TaskBreakdownAgent` now extracts tasks at **workflow level**, creating approximately **one task per workflow step** in the implementation plan. 

For a 5-step workflow, it creates ~5-6 tasks (not 43).

Tasks reference **existing actors** (BrowserExecutor, Summarizer) and describe **what to do**, not **how to code it**.

The DAG now accurately reflects the intended workflow and matches the user's mental model of the task.
