# Test Validator Model Configuration Fix

**Date**: 2026-01-31  
**Status**: Implemented  
**Update**: 2026-01-31 23:30 - Added explicit credential passing  

## Context

After implementing LLM-based semantic validation for tests, encountered error:
```
litellm.BadRequestError: LLM Provider NOT provided. 
Pass in the LLM provider you are trying to call. 
You passed model=azure-paytm-east-us2/paytm-gpt-4o-mini
```

## Problem

Attempted to create a dedicated LM instance for the test validator with incorrect format:
```python
# ❌ WRONG: Missing provider prefix
validator_lm = dspy.LM(model='azure-paytm-east-us2/paytm-gpt-4o-mini')
```

This failed because:
1. **Missing provider prefix**: litellm requires `openai/` prefix for Azure OpenAI models
2. Correct format: `openai/azure-paytm-east-us2/paytm-gpt-4o-mini`
3. Without the prefix, litellm doesn't know which provider to use

## Decision

**Fix the model string format**: Add the `openai/` provider prefix

**Before** (Wrong):
```python
# ❌ Missing provider prefix
validator_lm = dspy.LM(model='azure-paytm-east-us2/paytm-gpt-4o-mini')
```

**After** (Correct):
```python
# ✅ Correct format with openai/ prefix
validator_lm = dspy.LM(model='openai/azure-paytm-east-us2/paytm-gpt-4o-mini')
with dspy.context(lm=validator_lm):
    self.validator = dspy.ChainOfThought(LLMTestValidationSignature)
```

This allows the validator to use the cheap/fast 4o-mini model specifically for test validation.

## Consequences

### Positive
- **Correct provider format**: litellm now recognizes the Azure OpenAI provider
- **Cost effective**: Uses 4o-mini specifically for test validation (~$0.15/1M tokens)
- **Fast**: 4o-mini has high throughput for parallel test validation
- **Dedicated model**: Test validation doesn't interfere with other LLM calls
- **Same as trajectory_parser**: Consistent model usage for cheap/fast operations

### Learning
- **litellm format**: Azure OpenAI models need `openai/` prefix
- Format: `openai/<deployment-name>/<model-name>`
- Without prefix, litellm cannot determine the provider

## Alternative Considered

Could have fixed the Azure model configuration:
```python
validator_lm = dspy.LM(
    model='azure/gpt-4o-mini',
    api_base=os.getenv('AZURE_API_BASE'),
    api_version='2024-02-15-preview',
    api_key=os.getenv('AZURE_API_KEY')
)
```

**Rejected because**:
- Adds complexity
- Requires environment variable management
- No significant benefit over using default LM
- Default LM is already fast/cheap enough

## Final Solution (Update #2)

After discovering that credentials weren't being passed, implemented explicit credential passing:

```python
# Get credentials from environment
api_key = os.getenv("LITELLM_API_KEY") or os.getenv("OPENAI_API_KEY")
api_base = os.getenv("LITELLM_BASE_URL") or os.getenv("OPENAI_API_BASE")

if api_key and api_base:
    validator_lm = dspy.LM(
        model='openai/azure-paytm-east-us2/paytm-gpt-4o-mini',
        api_key=api_key,
        api_base=api_base
    )
else:
    # Fallback to default credentials from dspy.configure
    validator_lm = dspy.LM(model='openai/azure-paytm-east-us2/paytm-gpt-4o-mini')
```

## Environment Variables Used

The UV server (`run_server.sh`) uses these environment variables (from `.env`):
- `LITELLM_API_KEY`: JWT token for authentication
- `LITELLM_BASE_URL`: `https://llm.tfy.pi.mypaytm.com`
- `SYNAPSE_MODEL`: Model name (default: Claude Sonnet 4.5)

The test validator and trajectory_parser now read these same variables.

## Files Modified
- `Synapse/core/parallel_test_generator.py`: Added explicit credential passing
- `Synapse/core/synapse_core.py`: Added explicit credential passing for trajectory_parser

## Notes
- Credentials are read from environment variables set by swarm_service
- Falls back to default DSPy configuration if env vars not set
- Both trajectory_parser and test_validator use same credential approach
- Works seamlessly with UV server's existing configuration
