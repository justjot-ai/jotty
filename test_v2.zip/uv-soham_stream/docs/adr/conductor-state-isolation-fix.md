# ADR: Conductor State Isolation Fix

**Status:** Implemented  
**Date:** 2026-02-02  
**Issue:** Tasks showing as "already completed" on new requests

## Problem Summary

The `/perform` API was reusing the same Conductor instance across all requests, causing:
- Episode counter incrementing across requests (episode=1, episode=2, etc.)
- Shared context persisting between requests
- Task completion state leaking between requests
- "Tasks already completed" messages appearing in new requests

## Root Cause

```python
# OLD CODE - WRONG
class SwarmService:
    def __init__(self):
        self._swarm = None  # Single Conductor instance
    
    @property
    def swarm(self):
        return self._swarm  # Same instance for all requests
```

The SwarmService created a **singleton Conductor** at startup, and every API request reused it.

## Solution

Refactored to store **configuration** instead of Conductor instance, creating a fresh Conductor per request:

```python
# NEW CODE - CORRECT
class SwarmService:
    def __init__(self):
        self._swarm_config = None  # Store config, not instance
        self._shared_resources = None  # Browser/terminal persist
    
    def create_conductor(self):
        """Create fresh Conductor with isolated state."""
        return Conductor(**self._swarm_config)
```

## Files Changed

1. `uv/src/uv/services/swarm_service.py` - Store config, create Conductors
2. `uv/src/uv/services/task_service.py` - Create fresh Conductor per request
3. `uv/src/uv/api/v1/perform.py` - Pass swarm_service instead of swarm

## Testing

Run the test to verify isolation:

```bash
cd /Users/anshulchauhan/Tech/term
python tests/test_conductor_isolation.py
```

Expected output:
```
✅ Fresh Conductor has episode=0
✅ Fresh Conductor has episode=0 (isolated state)
✅ Different Conductor instances created
✅ ALL TESTS PASSED
```

## Verification in Production

After deploying, check logs for two consecutive requests:

```bash
# Both should show episode=1 (not episode=1, episode=2)
grep "RUN: Conductor" uv/a.txt | tail -2
```

Expected:
```
🚀 RUN: Conductor | episode=1 | goal_length=94
🚀 RUN: Conductor | episode=1 | goal_length=94  # Same episode!
```

## Benefits

- ✅ Complete state isolation between requests
- ✅ No "tasks already completed" errors
- ✅ Clean episode counter (always starts at 1)
- ✅ No shared context leakage
- ✅ Shared resources (browser, terminal) still work

## Trade-offs

- **Initialization Cost**: Each request creates a new Conductor (~0.1s overhead)
- **Memory**: Slightly higher memory usage (temporary Conductor per request)
- **Benefit**: Worth it for correctness and isolation

## Related

- See `docs/adr/unique-run-id-per-request.md` for full context
- Next: Add UUID to run IDs to prevent directory collisions
