# ADR: Browser Stale Process Cleanup

**Date**: 2026-02-01  
**Status**: Implemented

## Context

The browser automation tools were experiencing failures when initializing new browser sessions with the error:

```
session not created: Chrome instance exited
```

Investigation revealed:
- 12 stale ChromeDriver processes running (some from days ago)
- 1 active headless Chrome session from 1:25 AM still running
- Multiple Chrome Helper processes not properly terminated
- No cleanup mechanism on program exit or error

## Problem

Browser processes were not being properly cleaned up when:
1. The program exits unexpectedly
2. Browser initialization fails
3. Sessions are not explicitly closed
4. Signal interrupts (SIGTERM, SIGINT) occur

This led to resource leaks and prevented new browser sessions from starting.

## Decision

Implemented a multi-layered cleanup strategy:

### 1. Automatic Cleanup on Exit
- Added `atexit` handler to cleanup all browser instances
- Added signal handlers for SIGTERM and SIGINT
- Ensures cleanup even on unexpected program termination

### 2. Stale Process Cleanup Function
- Created `cleanup_stale_browser_processes()` function
- Kills orphaned ChromeDriver processes
- Kills headless Chrome instances from browser_executor
- Kills associated Chrome Helper processes

### 3. Automatic Recovery
- Enhanced `initialize_browser_with_profile()` to detect stale process errors
- Automatically attempts cleanup when "Chrome instance exited" error occurs
- Provides suggestion to retry after cleanup

### 4. Manual Cleanup Script
- Created `scripts/cleanup_browser_processes.sh`
- Provides manual cleanup option for users
- Can be run independently of Python code

## Implementation

### Changes to `browser_tools.py`:

1. Added imports:
```python
import atexit
import signal
import sys
```

2. Added cleanup handlers:
```python
def _cleanup_all_browsers()
def _signal_handler(signum, frame)
atexit.register(_cleanup_all_browsers)
signal.signal(signal.SIGTERM, _signal_handler)
signal.signal(signal.SIGINT, _signal_handler)
```

3. Added stale process cleanup:
```python
def cleanup_stale_browser_processes() -> Dict[str, Any]
```

4. Enhanced error handling in `initialize_browser_with_profile()`:
- Detects stale process errors
- Automatically runs cleanup
- Provides actionable error messages

### New Files:

- `scripts/cleanup_browser_processes.sh` - Manual cleanup script

## Consequences

### Positive:
- Browser processes are automatically cleaned up on exit
- Stale processes no longer block new sessions
- Better error messages with automatic recovery
- Manual cleanup option available
- Resource leaks prevented

### Negative:
- Slight overhead from signal handlers
- Cleanup may kill legitimate Chrome instances if profile paths match
- Force kill (-9) doesn't allow graceful shutdown

## Alternatives Considered

1. **Context Managers**: Would require refactoring all browser usage code
2. **Process Monitoring**: Too complex, adds unnecessary overhead
3. **Unique Profile Paths**: Doesn't solve the root cleanup issue
4. **Graceful Shutdown**: Attempted but unreliable with stale processes

## Testing

Verified:
- [x] All stale processes killed successfully
- [x] Browser initialization works after cleanup
- [x] atexit handler registered correctly
- [x] Signal handlers work (SIGTERM, SIGINT)
- [x] Error detection and auto-cleanup functional

## Notes

- The cleanup script uses `pkill -9` which is forceful but necessary for stale processes
- Browser profile directory: `~/.browser_executor/profiles/`
- ChromeDriver cache: `~/.cache/selenium/chromedriver/`
