# ADR: Browser Reset Preserves Auth Data

## Status
Accepted

## Context
The browser reset function was performing a full data wipe on each task reset:
- Clearing all cookies (destroys login sessions)
- Clearing localStorage/sessionStorage (destroys auth tokens)
- Clearing browser cache (unnecessary)

This was problematic because users need to re-authenticate on every task, losing session state across tasks.

## Decision
Simplify `reset_browser_state()` to only:
1. Close extra tabs (keep only one)
2. Navigate to `about:blank`
3. Reset zoom to 100%

**Removed operations:**
- Cookie clearing
- localStorage/sessionStorage clearing
- Browser cache clearing via CDP

## Rationale
- Users authenticate once and expect sessions to persist
- Each task should start with a clean tab, not a clean browser profile
- Auth persistence improves UX and reduces friction for multi-task workflows

## Consequences
- **Positive:** User auth persists across tasks, faster workflow
- **Negative:** Tasks may see leftover DOM state if they navigate to same URLs (mitigated by about:blank reset)
