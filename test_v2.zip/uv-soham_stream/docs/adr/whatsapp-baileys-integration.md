# ADR: WhatsApp Integration via Baileys Library

## Status
~~Implemented~~ **REMOVED/DISABLED** - WhatsAppExecutor has been disabled. WhatsApp tasks now use BrowserExecutor via WhatsApp Web automation.

## Context
The user requested WhatsApp integration following the same architecture as the existing browser executor agent. The browser executor uses WebSocket communication between Python backend and Electron app, with the browser embedded as a BrowserView in the UI.

WhatsApp integration requires:
- Sending/receiving messages programmatically
- Managing chats and groups
- Handling media (images, documents, audio)
- Real-time message events
- Authentication via QR code (like WhatsApp Web)

## Decision
Implement WhatsApp integration using the **Baileys** library (https://baileys.wiki/docs/intro/), which provides:
- Native WebSocket protocol to WhatsApp servers (not browser automation)
- Multi-device support via QR code authentication
- Full API for messages, chats, groups, and media
- Real-time event streams for incoming messages

### Architecture
The integration follows the same pattern as browser executor:

```
Python Agent → whatsapp_tools.py → WebSocket → Electron → WhatsAppService (Baileys) → WhatsApp
                     ↓                              ↓
              response queue ←──────────────────────┘
```

### Components

#### Python Backend
1. **`whatsapp_tools.py`** - Tool functions that send commands via WebSocket:
   - Connection: `whatsapp_connect()`, `whatsapp_disconnect()`, `whatsapp_get_status()`
   - Messages: `whatsapp_send_message()`, `whatsapp_send_image()`, `whatsapp_send_document()`, etc.
   - Chats: `whatsapp_get_chats()`, `whatsapp_get_messages()`, `whatsapp_search_messages()`
   - Contacts: `whatsapp_get_contacts()`, `whatsapp_check_number_exists()`
   - Groups: `whatsapp_get_groups()`, `whatsapp_create_group()`, `whatsapp_leave_group()`

2. **`whatsapp_executor.py`** - DSPy ReAct agent using WhatsApp tools

3. **`whatsapp_executor_signature.py`** - DSPy signature for the agent

4. **`agent_session_manager.py`** - Added `WHATSAPP` to `AgentType` enum and WhatsApp response queue

5. **`websocket_agents.py`** - Handler for `whatsapp_command_response` messages

#### Electron App
1. **`whatsapp-service.js`** - Baileys integration service:
   - Connection management with persistent auth state
   - QR code generation for authentication
   - All WhatsApp operations (send, receive, groups, etc.)
   - Event broadcasting to renderer process

2. **`main.js`** - IPC handlers for WhatsApp commands (25+ handlers)

3. **`preload.js`** - Exposed `whatsappAPI` to renderer:
   - All command methods (connect, send, get, etc.)
   - `onEvent()` for real-time events from main process

4. **`app.js`** - WebSocket message handler for `whatsapp_command`:
   - Routes commands to `whatsappAPI`
   - Sends responses via `whatsapp_command_response`

5. **`agent-view-manager.js`** - WhatsApp module card UI:
   - Status indicator (connecting, connected, etc.)
   - QR code display for authentication
   - User info display when connected
   - Message display area

6. **`agent-views.css`** - WhatsApp-specific styles

### Dependencies Added
- `baileys` ^6.7.9 - WhatsApp Web API
- `qrcode` ^1.5.3 - QR code generation
- `pino` ^8.16.2 - Logging (required by Baileys)

### Authentication Flow
1. User triggers `whatsapp_connect()` via agent
2. Baileys initiates connection and generates QR code
3. QR code displayed in WhatsApp card in Electron UI
4. User scans QR with WhatsApp mobile app
5. Connection established, auth state persisted to `userData/whatsapp-auth/`
6. Subsequent connections auto-authenticate (no QR needed)

### Message Flow (Request-Response)
1. Python tool generates unique `request_id`
2. Command registered in `WhatsAppCommandResponseQueue`
3. Command broadcast via WebSocket to Electron
4. Electron executes via Baileys service
5. Response sent back with same `request_id`
6. Python receives response, returns to agent

### Limitations
- **Message History**: Baileys doesn't store message history. Messages received in real-time are displayed, but retrieving past messages requires database integration.
- **Contact List**: Contacts are discovered through messages, not available immediately.
- **Media Download**: Requires message storage integration to track media keys.

## Consequences

### Positive
- Same architecture as browser executor - consistent, maintainable
- Native WhatsApp protocol - fast, reliable
- Persistent authentication - QR scan once
- Real-time message events
- Full control over messaging automation

### Negative
- Requires Electron app running for WhatsApp operations
- No built-in message history (would need database)
- WhatsApp may ban accounts used for automation/spam
- Auth must be refreshed if logged out from phone

### Risks
- WhatsApp ToS - using unofficial API could result in account ban
- Rate limiting - excessive message sending may trigger blocks
- Privacy concerns - ensure user consent for automation

## Usage Example

```python
# In Python agent
from surface.tools.whatsapp_tools import (
    whatsapp_connect,
    whatsapp_get_status,
    whatsapp_send_message
)

# Check/establish connection
status = whatsapp_get_status()
if status['status'] != 'connected':
    whatsapp_connect()  # User scans QR in Electron UI

# Send message
result = whatsapp_send_message('1234567890', 'Hello from UV!')
print(f"Message sent: {result['message_id']}")
```

## Synapse Integration

The WhatsApp executor is fully integrated with Synapse swarm system:

### Files Added
- `surface_synapse/agents/whatsapp_executor_agent.py` - Synapse wrapper agent
- `surface_synapse/architect/whatsappexecutor_agent.md` - Planning guidance
- `surface_synapse/auditor/whatsappexecutor_agent.md` - Verification guidance

### Registration
- Added to `surface_synapse/agents/__init__.py` exports
- Added to `surface_synapse/integration.py` agent creation
- ~~Synapse auto-selects WhatsAppExecutor for WhatsApp-related tasks~~ **REMOVED**: WhatsAppExecutor has been disabled. WhatsApp tasks now use BrowserExecutor via WhatsApp Web.

### Architect Role
- Assesses task feasibility before execution
- Verifies connection status
- Validates recipient numbers
- Plans message delivery strategy

### Auditor Role
- Verifies message delivery (message_id, timestamp)
- Validates connection stability
- Checks data quality for retrieval operations
- Categorizes failures for learning (AUTH_REQUIRED, RECIPIENT_INVALID, etc.)

## Related
- [Browser Executor Architecture](./electron-native-browser-embedding.md)
- [WebSocket Communication Pattern](./browser-command-request-response-pattern.md)
- [Baileys Documentation](https://baileys.wiki/docs/intro/)
