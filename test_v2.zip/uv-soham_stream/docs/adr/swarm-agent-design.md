# ADR: Minimal Swarm Agent Design for Terminal-Bench

**Date:** 2026-01-10  
**Status:** Accepted  
**Deciders:** A-Team

## Context

The original persona system had 19 different personas with significant overlap:
- Software Engineer, Backend Engineer, Frontend Engineer (overlap)
- Data Scientist, ML Engineer, Research Scientist (overlap)
- System Administrator, DevOps Engineer (overlap)
- Security Engineer, Cryptographer (overlap)

This led to:
- Average 5.75 personas per task
- Unclear responsibility boundaries
- Redundant skill assignments

## Decision

Consolidate into **6 minimal, non-overlapping swarm agents**:

| Agent | Domain | Tasks |
|-------|--------|-------|
| **CodeMaster** | Code, algorithms, debugging | 72 |
| **DataMind** | ML, data science, ETL | 52 |
| **SysOps** | Systems, infra, file ops | 44 |
| **SecureSentry** | Security, cryptography | 22 |
| **ScienceCore** | Scientific computing, math | 31 |
| **DomainExpert** | Games, finance, media | 20 |

## Agent Skill Boundaries

### CodeMaster
```
✓ Algorithm implementation
✓ Code debugging
✓ Performance optimization
✓ Build system issues (code-focused)
✗ ML model training → DataMind
✗ System configuration → SysOps
```

### DataMind
```
✓ ML model training
✓ Data preprocessing
✓ Feature engineering
✓ Dataset manipulation
✗ Mathematical proofs → ScienceCore
✗ System setup → SysOps
```

### SysOps
```
✓ Linux administration
✓ Container/Docker management
✓ Network configuration
✓ File operations
✗ Application code → CodeMaster
✗ Security exploits → SecureSentry
```

### SecureSentry
```
✓ Vulnerability analysis
✓ Cryptographic algorithms
✓ Penetration testing
✓ Hash/password operations
✗ General coding → CodeMaster
✗ System setup → SysOps
```

### ScienceCore
```
✓ Mathematical algorithms
✓ Scientific simulations
✓ Bioinformatics
✓ Signal processing
✗ ML pipelines → DataMind
✗ Pure coding → CodeMaster
```

### DomainExpert
```
✓ Game logic and AI
✓ Puzzle solving
✓ Financial modeling
✓ Media processing
✗ General algorithms → CodeMaster
✗ ML training → DataMind
```

## Routing Rules

1. Each task has **1 primary agent**
2. Max **1 secondary agent** for complex tasks
3. No task should have more than 2 agents

```
Primary Assignment:
  category → agent mapping (deterministic)

Secondary Assignment:
  if task spans domains → add support agent
```

## Consequences

### Positive
- 68% reduction in agent assignments (5.75 → 1.3 per task)
- Clear ownership - every task has one primary owner
- No skill overlap between agents
- Simpler routing logic

### Negative
- Some edge cases may need manual review
- Less granularity (e.g., Frontend vs Backend merged into CodeMaster)

## Files Created

- `terminal-bench-swarm-agents.yaml` - Agent definitions
- `terminal-bench-swarm-tasks.yaml` - Task-to-agent mapping
- `review/swarm-agent-design-review.md` - A-Team review

## Migration Path

Old Persona → New Agent:
```
Software Engineer     → CodeMaster
Backend Engineer      → CodeMaster
Frontend Engineer     → CodeMaster
Web Developer         → CodeMaster
Compiler Engineer     → CodeMaster
QA Engineer           → CodeMaster

Data Scientist        → DataMind
ML Engineer           → DataMind
Data Engineer         → DataMind

System Administrator  → SysOps
DevOps Engineer       → SysOps

Security Engineer     → SecureSentry
Cryptographer         → SecureSentry

Research Scientist    → ScienceCore
Bioinformatics Sci    → ScienceCore

Game Developer        → DomainExpert
Financial Engineer    → DomainExpert
```
