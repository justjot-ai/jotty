# ADR: Consecutive Task Collapsing by Actor

**Status:** Implemented  
**Date:** 2026-01-31  
**Context:** TodoCreatorAgent task optimization

## Problem

When the TodoCreatorAgent assigns actors to tasks, it often creates many small consecutive tasks for the same actor. This leads to:
- Excessive task overhead and context switching
- Inefficient execution flow
- More complex task tracking

Example: Tasks [1,2,3,4,5] with assignments [A,A,A,B,A] creates 5 separate tasks when tasks 1,2,3 could be handled together.

## Decision

Implemented automatic collapsing of consecutive tasks assigned to the same actor in `TodoCreatorAgent._collapse_consecutive_tasks()`.

### Algorithm

1. Get topological order of all tasks
2. Group consecutive tasks by assigned actor
3. For groups with >1 task, create a combined task:
   - **ID:** `task_1_2_3` (underscore-joined)
   - **Name:** Concatenated names (truncated to 200 chars)
   - **Description:** All descriptions combined with headers
   - **Dependencies:** External dependencies of first task only
   - **Dependents:** All external dependents of last task
   - **Commands/Files:** All commands and files merged
   - **Priority:** Maximum priority from group
4. Remove original tasks from DAG
5. Update adjacency list and dependencies

### Example

**Before:**
```
task_1 (Actor A) -> task_2 (Actor A) -> task_3 (Actor A) -> task_4 (Actor B) -> task_5 (Actor A)
```

**After:**
```
task_1_2_3 (Actor A) -> task_4 (Actor B) -> task_5 (Actor A)
```

Result: 5 tasks → 3 tasks

## Implementation Location

- **File:** `Synapse/agents/todo_creator_agent.py`
- **Method:** `_collapse_consecutive_tasks()`
- **Called:** After actor assignment, before validation (Step 1.5)

## Benefits

1. **Reduced overhead:** Fewer task transitions and context switches
2. **Better batching:** Related work grouped together
3. **Simpler tracking:** Fewer tasks to monitor
4. **Preserved dependencies:** External dependencies maintained correctly

## Trade-offs

- Combined tasks have longer descriptions
- Slightly less granular progress tracking
- Task names can become long (mitigated by 200 char limit)

## Error Handling

If topological sort fails (cycle detected), collapsing is skipped and original DAG is returned unchanged with warning logged.
