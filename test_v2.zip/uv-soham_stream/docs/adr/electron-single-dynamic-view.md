# ADR: Electron Single Dynamic View

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: Simplified to single transforming view

## Decision

Removed view toggle functionality and kept only the dynamic view system. The app now has a single, elegant transformation from welcome screen to workspace, triggered automatically by the user's first message.

## Rationale

### Why Single View
1. **Simpler UX**: No cognitive load choosing between views
2. **Natural Flow**: Transformation feels like natural progression
3. **Reduced Complexity**: Less code to maintain
4. **Clear Purpose**: Welcome → Work is intuitive
5. **No Confusion**: Users don't need to understand multiple layouts

### Why Not Multiple Views
- Toggle button adds unnecessary complexity
- Most users would stick with one view
- View preference management adds overhead
- Two layouts require synchronized updates
- Transformation already provides the "two modes" users need

## Implementation Changes

### Removed Components

**HTML:**
- Removed view toggle button from toolbar
- Removed entire `.container.classic-view` (old vertical layout)
- Removed entire `.container.grid-view` (old expansion grid)
- Kept only `.container.dynamic-view`

**JavaScript:**
- Removed `currentView` property
- Removed `setupViewToggle()` method
- Removed `toggleView()` method
- Removed `applyView()` method
- Removed `handleSendMessage()` method (old view)
- Removed `sendMessage()` method (old view)
- Removed event listeners for classic/grid views
- Removed session ID sync for removed views

**CSS:**
- Simplified `.container` base styles
- Removed `.container.classic-view` styling
- Removed `.container.grid-view` styling
- Kept only dynamic view styles

### Current Architecture

**One View, Two States:**
1. **Welcome State**: Large googly eyes (60%) + chat input (40%)
2. **Workspace State**: 3-column grid with agent terminals

**State Transition:**
- Triggered by first message
- Irreversible (by design)
- Smooth 0.5s fade animation
- Automatic, no user action needed

## File Changes Summary

### HTML
- **Before**: 671 lines (3 complete views)
- **After**: 357 lines (1 dynamic view)
- **Removed**: 314 lines (47% reduction)

### JavaScript
- Removed ~150 lines of view switching logic
- Simplified initialization
- Focused on welcome → workspace flow
- Cleaner, more maintainable

### CSS
- Kept dynamic view styles (~700 lines)
- Removed view switching logic
- Dead code for old views remains but harmless
- Can be cleaned up in future refactor

## User Experience

### App Launch
```
User opens app
    ↓
Sees large googly eyes + simple input
    ↓
Types first message
    ↓
Eyes fade out → Workspace fades in
    ↓
Full agent monitoring interface
```

### No Going Back
- Once transformed, stays in workspace mode
- If user wants simple view, they restart app
- This is intentional: work mode is persistent
- Restart is rare, so this is acceptable

## Benefits

### For Users
- **Zero Configuration**: No buttons to click
- **Intuitive**: Transformation feels natural
- **Focused**: No distraction from toggle options
- **Clear State**: Either chatting or working

### For Developers
- **Less Code**: Easier to maintain
- **Single Source of Truth**: One layout to update
- **Simpler Testing**: Only one transformation to test
- **Better Performance**: Less DOM, less event listeners

### For Design
- **Coherent**: One visual language
- **Progressive**: Reveals complexity gradually
- **Memorable**: Transformation creates "wow" moment
- **Professional**: Workspace matches enterprise tools

## Trade-offs

### Lost Features
- No way to switch back to simple view (must restart)
- No legacy vertical layout option
- No professional grid without transformation
- View preference no longer persisted

### Why Acceptable
- Restart is fast and easy
- Transformation is delightful, not annoying
- Most users prefer consistency over options
- Simplicity > Flexibility for this use case

## Future Considerations

### If Users Request Toggle
- Could add "Simple Mode" button in toolbar
- Would reset to welcome state (no restart needed)
- Would be hidden until after transformation
- Would confirm before resetting state

### Alternative States
- Could add "Focus Mode" (center stage only)
- Could add "Debug Mode" (logs and internals)
- Could add "Dashboard Mode" (metrics focus)
- All would be separate from welcome → workspace flow

## Success Metrics

### Simplicity
- **Goal**: 95%+ users understand transformation immediately
- **Metric**: No support questions about "how to switch views"
- **Indicator**: Natural adoption

### Performance
- **Goal**: Transformation completes in < 1 second
- **Metric**: Time from click to workspace visible
- **Indicator**: Smooth, no jank

### Retention
- **Goal**: Users don't restart app to see eyes again
- **Metric**: Restart frequency
- **Indicator**: Workspace is sufficient for ongoing work

## Files Modified

- `electron-app/src/renderer/index.html`
  - Removed view toggle button
  - Removed classic-view container (entire section)
  - Removed grid-view container (entire section)
  - Kept only dynamic-view

- `electron-app/src/renderer/css/styles.css`
  - Simplified .container base styles
  - Removed view switching styles
  - Kept dynamic view styles

- `electron-app/src/renderer/js/app.js`
  - Removed currentView property
  - Removed all view toggle methods
  - Removed old event listeners
  - Simplified initialization
  - Focused on welcome → workspace flow

## Conclusion

The app now has a single, elegant transformation that feels like a natural progression from casual chat to serious work. The removal of view toggle complexity makes the app easier to understand, maintain, and use.
