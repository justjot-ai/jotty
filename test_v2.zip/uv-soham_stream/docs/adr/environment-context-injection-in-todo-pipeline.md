# ADR: Environment Context Injection in TODO Creation Pipeline

**Status:** Implemented  
**Date:** 2026-01-31  
**Author:** A-Team  
**Component:** Synapse TODO Creation & Execution Pipeline

## Context

The TODO creation and execution pipeline involves multiple stages:
1. Pre-execution research (DomainExpert)
2. Task breakdown (TaskBreakdownAgent)
3. Actor assignment (TodoCreatorAgent)
4. Task execution (Inspector agents - Architect/Auditor)

Previously, these agents received instructions/plans without any awareness of the current execution state. This meant:
- Agents couldn't see what had been done previously
- No context about current environment state
- Redundant work and suboptimal decisions
- Lack of continuity across execution phases

## Decision

We integrated the **Environment Manager** into the entire TODO pipeline, ensuring all instructions are wrapped with current environment context.

### Implementation Pattern

**Format:**
```
Instruction
<original instruction>

Current State
<output of get_current_env()>
```

### Integration Points

All integration points where instructions/descriptions are wrapped with environment context:

#### 1. Conductor Initialization

Added Environment Manager to Conductor:

```python
# In Conductor.__init__()
from Synapse import create_environment_manager
self.env_manager = create_environment_manager(
    self.config,
    goal_context="Synapse multi-agent task execution"
)
# Add to config so Inspector agents can access it
self.config.env_manager = self.env_manager
```

#### 2. Helper Method

Created `_wrap_instruction_with_env_context()` in Conductor:

```python
def _wrap_instruction_with_env_context(self, instruction: str) -> str:
    """Wrap instruction with current environment context."""
    if not self.env_manager:
        return instruction
    
    current_env = self.env_manager.get_current_env()
    
    return f"""Instruction
{instruction}

Current State
{current_env}"""
```

#### 3. Task Breakdown

**File:** `Synapse/core/conductor.py` (line ~4244)

```python
# Before
task_dag = self.task_breakdown_agent.forward(implementation_plan=goal)

# After  
enhanced_goal = self._wrap_instruction_with_env_context(goal)
task_dag = self.task_breakdown_agent.forward(implementation_plan=enhanced_goal)
```

#### 4. Pre-Execution Research

**File:** `Synapse/core/conductor.py` (line ~4663)

```python
# Before
research_instruction = f"""RESEARCH NEED ANALYSIS..."""

# After
base_research_instruction = f"""RESEARCH NEED ANALYSIS..."""
research_instruction = self._wrap_instruction_with_env_context(base_research_instruction)
```

#### 5. Actor Execution Context

**File:** `Synapse/core/inspector.py` (line ~750)

```python
# After building base_context, add environment state
env_manager = getattr(self.config, 'env_manager', None)
if env_manager:
    current_env = env_manager.get_current_env()
    if current_env:
        env_context_section = f"\n\n=== CURRENT ENVIRONMENT STATE ===\n{current_env}\n"
        base_context += env_context_section
```

This ensures Architect and Auditor agents see current environment state during execution.

#### 6. Task Execution (Actor Level)

**File:** `Synapse/core/conductor.py` (line ~6684)

When individual tasks are sent to actors for execution, wrap the task description with environment context:

```python
async def _execute_actor(self, actor_config, task, context, kwargs, actor_context_dict):
    """Execute actor with parameter resolution."""
    
    # 🌍 Wrap task description with environment context
    if self.env_manager and hasattr(task, 'description') and task.description:
        original_description = task.description
        enhanced_description = self._wrap_instruction_with_env_context(original_description)
        
        # Create new TodoItem with enhanced description
        from dataclasses import replace
        task = replace(task, description=enhanced_description)
        
        logger.info(f"🌍 Enhanced task description with environment context")
    
    # ... rest of execution logic
```

This ensures every actor receives:
- The specific task description
- Full environment context (all previous executions)
- Research findings
- Task completion history
- Error context

### Environment Tracking

Added tracking at key execution points:

#### Execution Start
```python
self.env_manager.add_to_current_env(f"🚀 Starting new execution | Goal: {goal[:200]}")
```

#### TODO Creation Complete
```python
self.env_manager.add_to_current_env(
    f"✅ TODO creation complete:\n"
    f"  - Tasks created: {len(task_dag.tasks)}\n"
    f"  - Actor assignments: {len(executable_dag.assignments)}\n"
    f"  - DAG validation: {'✅ Passed' if executable_dag.validation_passed else '⚠️ Issues found'}"
)
```

#### Task Completion
```python
self.env_manager.add_to_current_env(
    f"✅ Task completed | ID: {task.task_id} | Actor: {task.actor}\n"
    f"   Result: {result_preview}"
)
```

#### Task Failure
```python
self.env_manager.add_to_current_env(
    f"❌ Task failed | ID: {task.task_id} | Actor: {task.actor}\n"
    f"   Error: {str(error)[:200]}"
)
```

## Files Modified

### 1. `Synapse/core/conductor.py`

**Changes:**
- Added Environment Manager initialization (line ~1235)
- Added `_wrap_instruction_with_env_context()` helper method (line ~4337)
- **Wrapped goal for TaskBreakdownAgent** (line ~4244)
- **Wrapped research instruction for pre-execution research** (line ~4695)
- **Wrapped task description in `_execute_actor()`** (line ~6684) ← NEW
- Added environment tracking at:
  - Execution start (line ~2957)
  - TODO creation complete (line ~4325)
  - Task success/failure (line ~3145-3175)

### 2. `Synapse/core/inspector.py`

**Changes:**
- Added environment context to base_context (line ~758)
- Environment state included in all Architect/Auditor executions

## Benefits

### 1. Continuity Across Phases
Agents see what happened before:
- Pre-execution research sees initial goal
- Task breakdown sees research findings
- Actors see previous task results
- Auditors see execution history

### 2. Better Decision Making
With full context, agents can:
- Avoid redundant research
- Make informed task breakdowns
- Better actor assignments
- More accurate validation

### 3. Error Recovery
Environment context helps:
- Understand error patterns
- See what was tried before
- Make better retry decisions
- Track resolution progress

### 4. Debugging
Environment history provides:
- Complete execution timeline
- Decision-making context
- Error context with preceding events
- Audit trail for analysis

## Example Flow

### Phase 1: Pre-Execution Research

**Input to DomainExpert:**
```
Instruction
RESEARCH NEED ANALYSIS (Pre-Execution):
Goal: Create a web scraper for news articles
... [full research instruction]

Current State
# Environment Context
**Goal:** Synapse multi-agent task execution
**Created:** 2026-01-31 10:00:00
**Last Updated:** 2026-01-31 10:00:00

## Environment Updates

### [2026-01-31 10:00:00]
🚀 Starting new execution | Goal: Create a web scraper for news articles
```

**Result:** DomainExpert researches web scraping libraries with full context.

### Phase 2: Task Breakdown

**Input to TaskBreakdownAgent:**
```
Instruction
Create a web scraper for news articles

Current State
# Environment Context
... [previous state]

### [2026-01-31 10:01:30]
✅ Pre-execution research complete:
  - Researched BeautifulSoup4, Scrapy, Selenium
  - Identified best practices for web scraping
  - Documented rate limiting requirements
```

**Result:** Task breakdown aware of research findings, creates better DAG.

### Phase 3: Task Execution (Actor Level)

**Input to Actor (e.g., CodeMaster, BrowserExecutor, etc.):**
```
Instruction
Create a Python script to scrape news articles from example.com

Current State
# Environment Context
... [full history including]
- Initial goal: Create a web scraper for news articles
- Research findings: BeautifulSoup4, rate limiting requirements
- TODO creation: 5 tasks created
- Task 1 completed: Environment setup
- Task 2 completed: Install dependencies (beautifulsoup4, requests)
- Now executing Task 3: Create scraper script
```

**Result:** Actor sees full context - knows what's been researched, what's been done, and what needs to be done.

### Phase 4: Validation (Architect/Auditor)

**Input to Architect/Auditor:**
```
EXECUTION METADATA:
execution_status: completed
has_data: true
... [other metadata]

=== CURRENT ENVIRONMENT STATE ===
# Environment Context
... [full history including all previous phases]
```

**Result:** Architect and Auditor validate with complete context of all previous work.

## Performance Considerations

### Context Size
- Environment context grows over time
- Auto-summarization (every 1 minute) prevents bloat
- Typical size: 1-10KB (after summarization)
- Max before summarization: 50KB (configurable)

### Memory Impact
- Minimal: ~5-10KB per execution
- Shared across all agents (no duplication)
- Auto-pruned via summarization

### LLM Token Usage
- Adds ~250-2500 tokens per instruction (depending on history)
- Offset by better decisions (fewer retries)
- Summarization keeps it manageable

## Configuration

All configurable via `SynapseConfig`:

```python
config = SynapseConfig()
config.env_summarization_interval = 60  # Seconds (default: 60)
config.env_max_size_bytes = 50000  # Bytes (default: 50KB)
config.env_min_lines = 100  # Lines before summarization
```

## Testing

### Manual Testing
1. Run any Synapse execution
2. Check `outputs/synapse_state/env/env.md`
3. Verify context injection in logs

### Verification Points
- ✅ Environment Manager initialized
- ✅ Instructions wrapped with context
- ✅ Agents receive environment state
- ✅ Events tracked throughout execution
- ✅ Auto-summarization prevents bloat

## Future Enhancements

Possible improvements (not implemented):

1. **Per-Agent Context:** Separate environment contexts per agent
2. **Context Filtering:** Filter environment to relevant sections only
3. **Context Compression:** More aggressive compression strategies
4. **Context Caching:** Cache environment state to reduce reads
5. **Context Visualization:** Web UI to view environment timeline

## Related ADRs

- `environment-manager-cot-summarization.md` - Environment Manager implementation
- `actor-capability-generation-flow.md` - Actor generation (could benefit from env context)

## Conclusion

Integrating Environment Manager into the TODO pipeline provides continuous context across all execution phases. This improves decision-making, reduces redundant work, aids error recovery, and provides better debugging capabilities.

**Key Pattern:**
```python
# Anywhere instructions are passed:
enhanced_instruction = self._wrap_instruction_with_env_context(instruction)
agent.execute(enhanced_instruction)
```

**Status:** ✅ Fully Implemented and Integrated

---

**Implementation Summary:**
- 2 files modified (conductor.py, inspector.py)
- 1 helper method added
- 5 integration points updated:
  1. Task breakdown (goal wrapping)
  2. Pre-execution research (instruction wrapping)
  3. Inspector context building (environment state injection)
  4. **Actor execution (task description wrapping)** ← NEW
  5. Environment tracking (event logging)
- 6 tracking points added
- Full context continuity achieved across ALL execution phases
