# ADR: Clean Browser View - Remove Headers and Activity Log

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Browser view UI simplification

## Problem

The browser view had unnecessary UI elements that cluttered the display:

1. **Agent header** - "Active" badge and "BrowserExecutor" title
2. **Status bar** - "Connected to Chrome" indicator with URL bar
3. **Activity log panel** - Bottom panel showing browser events
4. **Manual activation** - Required clicking "Browser" button to show

**User Feedback:**
> "when i click browser button then i see browser images.......it should be by default enabled.......also remove activity log and header with ACTIVE ....BROWSER EXECTUOR.....ALSO REMOVE CONNECTED TO CHORME HEADER AS WELL"

## Solution

### 1. Removed Agent Header

**Before:**
```html
<div class="terminal-header-ws agent-view-header">
  <div class="terminal-status-ws active">Active</div>
  <span class="terminal-agent-name-ws">🌐 BrowserExecutor</span>
</div>
```

**After:**
```html
<!-- Header removed entirely -->
```

### 2. Removed Status Bar and URL Bar

**Before:**
```html
<div class="browser-status-bar">
  <div class="status-indicator">
    <span class="status-dot status-connected"></span>
    <span class="status-text">Connected to Chrome</span>
  </div>
  <div class="browser-url-bar">
    <span class="url-icon">🔒</span>
    <span class="url-text">https://example.com</span>
  </div>
</div>
```

**After:**
```html
<!-- Status bar removed entirely -->
```

### 3. Removed Activity Log Panel

**Before:**
```html
<div class="browser-activity-panel">
  <div class="activity-header">
    <span class="activity-icon">📋</span>
    <span>Activity Log</span>
  </div>
  <div class="activity-list">
    <!-- Activity items -->
  </div>
</div>
```

**After:**
```html
<!-- Activity panel removed entirely -->
```

### 4. Show Browser View by Default

**Before:**
```javascript
initialize() {
  // Create views (all hidden)
  this.createView('BrowserExecutor', 'browser', '🌐');
  // ... other views
}
```

**After:**
```javascript
initialize() {
  // Create views
  this.createView('BrowserExecutor', 'browser', '🌐');
  // ... other views
  
  // Show browser view by default
  this.switchToAgent('BrowserExecutor');
}
```

## Final UI Structure

```html
<div class="browser-cdp-view">
  <div class="browser-display">
    <canvas id="browser-canvas" class="browser-canvas"></canvas>
    <div class="browser-placeholder">
      <div class="placeholder-icon">🌐</div>
      <div class="placeholder-text">Connecting to Chrome...</div>
    </div>
  </div>
</div>
```

**That's it!** Just the canvas with a minimal placeholder.

## Code Changes

### File: `electron-app/src/renderer/js/agent-view-manager.js`

1. **Simplified `initialize()` in `BrowserViewHandler`:**
   - Removed status bar HTML
   - Removed URL bar HTML
   - Removed activity panel HTML
   - Kept only canvas and placeholder

2. **Removed DOM references:**
   ```javascript
   // Removed:
   this.statusEl = document.getElementById('cdp-status');
   this.urlBarEl = document.getElementById('browser-url-bar');
   this.urlTextEl = document.getElementById('browser-url');
   this.activityListEl = document.getElementById('browser-activity-list');
   ```

3. **Made methods no-ops:**
   ```javascript
   updateStatus(type, message) {
     console.log(`[Browser Status] ${type}: ${message}`);
   }
   
   addActivity(text, url = null) {
     console.log(`[Browser Activity] ${text}`);
   }
   ```

4. **Removed header from `createView()`:**
   - No more "Active" badge
   - No more agent name display

5. **Auto-show browser view:**
   ```javascript
   initialize() {
     // ... create views ...
     this.switchToAgent('BrowserExecutor'); // Show by default
   }
   ```

## Result

✅ **Clean, minimal UI** - Just the browser canvas  
✅ **No clutter** - No headers, status bars, or logs  
✅ **Auto-visible** - Shows immediately on page load  
✅ **Full-screen canvas** - Maximum space for browser view  
✅ **Console logging** - Activity still logged to DevTools  

## User Experience

### Before
```
┌─────────────────────────────────────────┐
│ Active | 🌐 BrowserExecutor             │ ← Header
├─────────────────────────────────────────┤
│ ● Connected to Chrome | 🔒 example.com  │ ← Status bar
├─────────────────────────────────────────┤
│                                         │
│         Browser Canvas (60%)            │
│                                         │
├─────────────────────────────────────────┤
│ 📋 Activity Log                         │ ← Activity panel
│ - Navigated to...                       │
│ - Clicked button...                     │
└─────────────────────────────────────────┘
```

### After
```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│         Browser Canvas (100%)           │
│                                         │
│                                         │
└─────────────────────────────────────────┘
```

**Pure, distraction-free browser view!** 🎨

## Testing

1. **Restart Electron**
2. **Expected:** Browser view shows immediately (no button click needed)
3. **Expected:** No headers, no status bars, no activity log
4. **Expected:** Just the browser canvas filling the center section

## Related

- Browser embedding: `docs/CDP_BROWSER_EMBEDDING_COMPLETE.md`
- Layout fix: `docs/adr/electron-center-grid-fullscreen-events.md`
