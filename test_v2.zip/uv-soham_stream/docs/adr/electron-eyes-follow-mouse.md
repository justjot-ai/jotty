# Electron UI Eyes Follow Mouse Cursor

**Status:** Implemented  
**Date:** 2026-01-31

## Context

The Electron UI features animated eyes in the welcome state, but they were only performing random looking around animations and blinking. The user requested that the eyes should follow the mouse cursor for a more interactive and engaging experience.

## Decision

Enhanced the `AnimationController` in `animations.js` to track mouse movements and move the pupils accordingly. The implementation:

1. **Dual Eye Support**: Updated the controller to handle both old eyes (`.left-eye`, `.right-eye`) and welcome state eyes (`.left-eye-welcome`, `.right-eye-welcome`)

2. **Mouse Tracking**: Enhanced `trackMouseMovement()` method to:
   - Calculate the angle and distance between mouse cursor and eye center
   - Move pupils dynamically using trigonometric calculations
   - Limit movement to prevent pupils from going outside the eye boundaries
   - Use larger movement range for welcome eyes (25px max) vs old eyes (15px max)

3. **Animation Consistency**: Updated `blink()` and `lookAround()` methods to work with both eye types

4. **Smooth Transitions**: Optimized CSS transition for `.pupil-welcome` from `all 0.3s ease` to `transform 0.15s ease-out` for more responsive mouse tracking

## Implementation Details

### JavaScript Changes (`animations.js`)

- Added welcome eye element references in constructor
- Enhanced mouse tracking with dual eye support
- Improved blink animation to handle both eye types
- Updated look around animation for both eye types

### CSS Changes (`styles.css`)

- Added blinking animation for welcome eyes
- Optimized pupil transition for smoother tracking

## Benefits

- More engaging and interactive user experience
- Eyes feel "alive" and responsive to user actions
- Maintains existing random animations (blinking, looking around)
- Gracefully handles both old and new eye implementations

## Technical Notes

- Uses `Math.atan2()` for angle calculation between cursor and eye center
- Uses `Math.hypot()` for distance calculation
- Movement is scaled and capped to keep pupils within eye boundaries
- Welcome eyes have 1.67x larger movement range for better visibility on larger eyes
- Transition timing is optimized at 150ms for responsive feel
