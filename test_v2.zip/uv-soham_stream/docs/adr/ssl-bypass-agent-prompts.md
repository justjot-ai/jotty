# ADR: SSL Bypass Instructions in Agent Prompts & Dockerfiles

**Date:** 2026-01-13  
**Status:** Accepted  
**Context:** Docker containers in terminal-bench often fail SSL verification

## Problem

Docker containers used in terminal-bench tasks frequently encounter SSL certificate verification failures:

```
curl: (60) SSL certificate problem: unable to get local issuer certificate
```

This causes tasks like `chess-best-move` to fail during Docker build when downloading external resources.

## Decision

### Part 1: Agent Prompts (surface_synapse)

Add SSL bypass instructions to all surface_synapse agent prompts (architect and auditor):

- `surface_synapse/architect/swarm_level.md` - Swarm-level guidance
- `surface_synapse/architect/sysops_agent.md` - SysOps specific instructions
- `surface_synapse/auditor/swarm_level.md` - Post-execution validation
- `surface_synapse/auditor/sysops_agent.md` - Error recovery guidance

### Part 2: Task Dockerfiles (terminal-bench)

Fixed all Dockerfiles with network commands:

**curl --insecure added:**
- `tasks/chess-best-move/Dockerfile`
- `tasks/make-mips-interpreter/Dockerfile`
- `tasks/make-doom-for-mips/Dockerfile`
- `tasks/home-server-https/Dockerfile`
- `tasks/gpt2-codegolf/Dockerfile` (2 commands)

**wget --no-check-certificate added:**
- `tasks/pcap-to-netflow/Dockerfile`
- `tasks/incompatible-python-fasttext/Dockerfile`
- `tasks/implement-eigenvectors-from-eigenvalues-research-paper/Dockerfile`
- `tasks/build-tcc-qemu/Dockerfile`
- `tasks/build-initramfs-qemu/Dockerfile`

### SSL Bypass Commands Reference
| Tool | Command |
|------|---------|
| curl | `curl --insecure URL` or `curl -k URL` |
| wget | `wget --no-check-certificate URL` |
| git | `GIT_SSL_NO_VERIFY=1 git clone URL` |
| pip | `pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org` |
| npm | `NODE_TLS_REJECT_UNAUTHORIZED=0 npm install` |

## Consequences

**Positive:**
- Task Dockerfiles now build without SSL errors
- Agents will proactively use SSL bypass flags during execution
- Reduces task failures due to certificate issues
- Better error recovery when SSL errors occur

**Negative:**
- Slightly less secure (SSL verification disabled)
- Acceptable tradeoff for isolated Docker task environments

## References
- curl error 60: https://curl.se/docs/sslcerts.html
