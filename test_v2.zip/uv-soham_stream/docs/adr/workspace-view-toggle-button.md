# ADR: Workspace View Toggle Button

**Date:** 2026-02-02  
**Status:** Implemented  
**Context:** Electron UI Enhancement

## Decision

Added a toolbar button to toggle the visibility of the three-column workspace view sidebars, allowing users to maximize the center agent terminal area when needed.

## Implementation

### UI Changes

**HTML (index.html):**
- Added workspace view button to title bar center
- Button includes grid icon (4 squares) and "Workspace" label
- Initially hidden, only shown when in workspace mode

### JavaScript Changes

**app.js:**
- Added `workspaceViewBtn` property to track button element
- Implemented `toggleWorkspaceView()` method to toggle sidebar visibility
- Button shows on transition to workspace mode
- Button hides when returning to welcome screen
- Button state (active/inactive) reflects current view state

### CSS Changes

**styles.css:**
- Added `.sidebars-collapsed` class for workspace state
- Collapsed state sets sidebar columns to 0px width
- Smooth 0.3s transition for grid column changes
- Added `.toolbar-btn.active` styling for button active state
- Sidebars fade out with opacity transition when collapsed

## Behavior

### Button States
1. **Hidden**: When in welcome screen (before first message)
2. **Inactive**: When workspace is visible with sidebars expanded
3. **Active**: When workspace is visible with sidebars collapsed

### Toggle Action
- **Expanded → Collapsed**: Hides left and right sidebars, maximizes center area
- **Collapsed → Expanded**: Shows sidebars, restores three-column layout

### Visual Feedback
- Button highlights with cyan border when active
- Smooth grid transition (0.3s ease)
- Sidebar opacity fades during transition
- Tooltip updates based on state

## Use Cases

1. **Focus Mode**: Hide sidebars to focus on agent terminal output
2. **Small Screens**: Maximize space on smaller displays
3. **Presentation**: Clean view for demos or screen sharing
4. **Quick Toggle**: Fast keyboard-free way to adjust layout

## Benefits

1. **Flexible Layout**: Users can choose between full context or focused view
2. **Space Efficiency**: Maximize terminal viewing area when needed
3. **Non-Destructive**: Sidebar content preserved, just hidden
4. **Smooth UX**: Animated transitions feel polished

## Technical Details

### Grid Layout
```css
/* Normal */
grid-template-columns: 240px 1fr 260px;

/* Collapsed */
grid-template-columns: 0px 1fr 0px;
```

### Button Icon
- 4-square grid icon representing workspace layout
- SVG with 2x2 rect arrangement
- 14x14px size matching other toolbar buttons

## Future Enhancements

Potential improvements:
- Keyboard shortcut (e.g., Ctrl+B)
- Remember user's preference across sessions
- Animate individual sidebars (left/right separately)
- Add to context menu

## References

- Implementation: `electron-app/src/renderer/`
- Related: Synapse Expand Terminal Grid (ADR)
