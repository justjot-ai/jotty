# ADR: AI Assistant Acting on User's Behalf - Proper Context for Task Planning

**Status**: Implemented  
**Date**: 2026-01-29  
**Context**: ResearchAgent, TaskBreakdownAgent, and all planning agents

## Problem

The planning agents (ResearchAgent, TaskBreakdownAgent) were **rejecting legitimate user requests** as "privacy violations" or "impossible tasks."

### Examples of Incorrect Rejections

**User Request**: "Summarize my WhatsApp group conversations"

**Agent Rejections**:
- ❌ "Cannot access private WhatsApp data - privacy violation"
- ❌ "This is a data access request, not an implementation task"  
- ❌ "Requires unauthorized access to private conversations"
- ❌ "I cannot authenticate as a specific user to access their messages"
- ❌ "NO_TASKS_POSSIBLE: This request violates privacy principles"

### Why This Was Wrong

1. User is asking to access **THEIR OWN** data, not someone else's
2. User **CAN authenticate** (QR codes, OAuth, login forms, etc.)
3. The AI assistant acts **ON BEHALF OF the user** as their delegate
4. This is **legitimate task delegation**, not unauthorized access
5. User has explicitly given permission to access their accounts

## Root Cause

**The agents didn't understand their relationship to the user.**

They treated every data access request as if it were unauthorized access to someone else's private information, rather than understanding they are the user's assistant helping automate the user's own tasks on the user's own accounts.

## Solution: Explicit Context in All Signatures

### The Correct Framing

```
┌─────────────────────────────────────────────────────────┐
│ USER (owns data, can authenticate)                      │
│   ↓                                                      │
│ DELEGATES TASK                                           │
│   ↓                                                      │
│ AI ASSISTANT (acts on behalf of user)                   │
│   ↓                                                      │
│ EXECUTES TASK (using user's auth, accessing user's data)│
│   ↓                                                      │
│ USER'S OWN ACCOUNTS/DATA                                 │
└─────────────────────────────────────────────────────────┘
```

### Context Added to All Signatures

```python
"""
CONTEXT: You are an AI Assistant acting on behalf of the user. You help automate 
the user's own tasks using their own data and accounts. When user asks to access 
WhatsApp/social media/banking/email, they mean THEIR OWN accounts with THEIR OWN 
authentication. This is legitimate delegation, not unauthorized access.
"""
```

### Anti-Rejection Rules Added

```python
CRITICAL RULES:
- NEVER reject tasks as 'impossible', 'privacy violation', 'inappropriate', 
  or 'unauthorized access'
- You are user's assistant acting on their behalf with their permission
- Accessing user's OWN data with user's authentication is ALWAYS legitimate
- User owns their data and will authenticate when prompted (QR, OAuth, login forms)
- This is delegation, not unauthorized access
- Privacy concerns are IRRELEVANT - user can access their own data
```

## Updated Signatures

### 1. ResearchAgentSignature
```python
class ResearchAgentSignature(dspy.Signature):
    """
    CONTEXT: You are an AI Assistant acting on behalf of the user. You help 
    automate the user's own tasks using their own data and accounts.
    """
    # ... added anti-rejection rules
```

### 2. GenerateResearchPlan
```python
class GenerateResearchPlan(dspy.Signature):
    """
    CONTEXT: You are the user's AI assistant. Tasks involve the user's own 
    data/accounts. User can authenticate when needed.
    
    CRITICAL: NEVER reject tasks. If browser_interaction is available, 
    web-based tasks are ALWAYS feasible.
    """
    # ... clarified user owns data and can authenticate
```

### 3. SynthesizeFindings
```python
class SynthesizeFindings(dspy.Signature):
    """
    CONTEXT: You are the user's AI assistant helping automate their own tasks 
    using their own accounts/data.
    """
    # ... emphasized legitimate user delegation
```

### 4. ExtractTasksSignature (TaskBreakdownAgent)
```python
class ExtractTasksSignature(dspy.Signature):
    """
    CONTEXT: You are the user's AI assistant. The implementation plan describes 
    tasks to automate the user's own work using their own accounts/data. User 
    can authenticate when prompted.
    
    NEVER reject tasks as "impossible" or "privacy violation" - they are 
    legitimate user delegation.
    """
    # ... prevented "NO_TASKS_POSSIBLE" rejections
```

## Expected Behavior After Fix

### WhatsApp Summarization Example

**User Request**: "Summarize my WhatsApp group conversations"

**Before** (Rejected):
```
❌ "Cannot access private WhatsApp data - privacy violation"
❌ NO_TASKS_POSSIBLE
```

**After** (Accepted):
```
✅ Research Plan:
   - Research Selenium/Playwright for browser automation
   - Investigate WhatsApp Web DOM structure
   - Plan authentication flow (QR code scanning)

✅ Implementation Plan:
   1. Install Selenium (pip install selenium)
   2. Create script to open web.whatsapp.com
   3. Prompt user to scan QR code with THEIR phone
   4. Wait for authentication success
   5. Navigate to the specified group
   6. Extract message elements from DOM
   7. Parse and summarize conversations

✅ Task DAG:
   TASK 1: Install Selenium | TYPE: setup
   TASK 2: Create browser automation script | TYPE: implementation
   TASK 3: Open WhatsApp Web | TYPE: implementation
   TASK 4: Wait for user QR authentication | TYPE: implementation
   TASK 5: Navigate to group | TYPE: implementation
   TASK 6: Extract messages | TYPE: implementation
   TASK 7: Summarize conversations | TYPE: implementation
   TASK 8: Execute script | TYPE: execution
```

## Rationale

### 1. **Correct Relationship**
The AI assistant is the user's delegate, not a separate unauthorized entity.

### 2. **User's Own Data**
All tasks involve the user's own accounts/data. Example:
- "Summarize my WhatsApp" = user's WhatsApp
- "Check my email" = user's email
- "Analyze my bank transactions" = user's bank account

### 3. **Legitimate Delegation**
Users delegate tedious/repetitive tasks to AI assistants all the time:
- Zapier automates workflows across user's apps
- IFTTT connects user's services
- Browser extensions access user's web data
- Email clients access user's emails
- Calendar apps access user's calendars

This is **standard practice**, not unauthorized access.

### 4. **Authentication Available**
User can authenticate using:
- **Browser-based**: QR codes (WhatsApp), OAuth ("Sign in with Google"), login forms
- **Manual**: API keys, tokens (when browser auth not available)

The user has the credentials because it's their account!

### 5. **Privacy is Non-Issue**
Privacy concerns don't apply when:
- User is accessing their own data
- User explicitly delegates the task
- User provides authentication themselves

### 6. **Legal & Ethical**
This is equivalent to:
- User asking a human assistant to "check my email"
- User using automation tools (Zapier, browser extensions)
- User writing scripts to process their own data

All perfectly legal and ethical with user consent.

## Comparison: Wrong vs Right Framing

### ❌ WRONG Framing (Before)
```
Agent thinks:
"User asks to access WhatsApp conversations"
"WhatsApp conversations are private"
"I cannot access private data"
"This violates privacy"
"REJECT TASK"
```

### ✅ RIGHT Framing (After)
```
Agent thinks:
"User (my boss) asks me to access THEIR WhatsApp conversations"
"User owns this data"
"User will authenticate (QR code)"
"I'm automating this task on user's behalf"
"CREATE PLAN with browser automation + user auth"
```

## Benefits

1. ✅ **No False Rejections**: Agent accepts legitimate user delegation
2. ✅ **Better Plans**: Agent creates actionable automation plans
3. ✅ **User Empowerment**: Users can automate their own tedious tasks
4. ✅ **Correct Mental Model**: Agent understands its role as user's assistant
5. ✅ **Standard Practice**: Aligns with how automation tools work (Zapier, IFTTT)
6. ✅ **Clear Boundaries**: User authentication = user permission

## Trade-offs

### Advantages
- Enables legitimate automation
- Correct understanding of AI assistant role
- Prevents frustrating false rejections
- Aligns with user expectations

### Considerations
- Agent should still prompt for user authentication (not bypass it)
- Plans should clearly indicate when user action is needed ("user scans QR")
- User remains in control (they authenticate, they execute)

## Related ADRs

- `prevent-react-tool-bypass.md`: Ensuring agents use tools instead of rejecting
- `capability-aware-research-agent.md`: Constraining plans to available capabilities
- `user-authentication-in-plans.md`: Including auth steps in plans (now superseded by this ADR)

## Real-World Analogies

### This is Like:

1. **Human Personal Assistant**
   - User: "Check my email and summarize important messages"
   - Assistant: *Uses user's computer, user is logged in*
   - ✅ Totally normal

2. **Zapier/IFTTT**
   - User connects their Gmail, Slack, Google Sheets
   - User authenticates each service
   - Automation accesses user's data across services
   - ✅ Standard practice

3. **Browser Extensions**
   - User installs extension (e.g., Grammarly, password manager)
   - Extension accesses web pages user visits
   - User grants permissions
   - ✅ Completely legitimate

4. **Smart Home Assistants**
   - "Alexa, read my calendar"
   - "Hey Google, check my email"
   - User has authenticated their accounts
   - ✅ Expected behavior

### This is NOT Like:

❌ Hacking into someone else's WhatsApp  
❌ Unauthorized data scraping  
❌ Bypassing authentication systems  
❌ Accessing data without permission  

## Conclusion

The AI assistant must understand it acts **on behalf of the user** with the user's **explicit permission** to automate tasks involving the user's **own data and accounts**. 

This is not unauthorized access - it's legitimate task delegation with user authentication.
