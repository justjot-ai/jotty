# ADR: Broadcast Final Output to WebSocket for Electron UI

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Return to welcome screen after task completion

## Problem

When a task completed with "🎯 FINAL SWARM OUTPUT", the Electron UI did not return to the googly eye view. The task completion event was being logged in the backend but not reaching the frontend.

**User Feedback:**
> "also not routed to googly eye view was on three section layout"

## Root Cause

The `/perform/stream` endpoint streams events via **Server-Sent Events (SSE)**, but the Electron UI listens for events via **WebSocket** (`/ws/browser`). The `final_output` event was being yielded by the task service and sent via SSE, but it was **not being broadcast to WebSocket clients**.

### Event Flow (Before Fix)

```
Task Service → SSE Stream → Electron (via HTTP)
                ❌ NOT → WebSocket → Electron Frontend
```

The frontend's WebSocket listener never received the `final_output` event, so `returnToWelcomeScreen()` was never called.

## Solution

Broadcast the `final_output` event to all WebSocket clients when it's generated in the SSE stream.

### Implementation

**File:** `uv/src/uv/api/v1/perform.py`

```python
async def event_generator():
    """Generate SSE events - yield immediately as they come."""
    import json
    from .websocket_agents import get_websocket_manager
    
    ws_manager = get_websocket_manager()
    
    try:
        async for event in task_service.execute_task_stream(
            instruction=request.task,
            context=request.context
        ):
            # Broadcast to WebSocket clients (for Electron UI)
            if event.get("type") == "final_output":
                await ws_manager.broadcast(event)
                logger.info(f"📡 Broadcasted final_output to WebSocket clients")
            
            # Format as SSE and yield immediately (no buffering)
            event_str = f"data: {json.dumps(event)}\n\n"
            yield event_str.encode('utf-8')
    except Exception as e:
        # ... error handling
```

### Event Flow (After Fix)

```
Task Service → SSE Stream → Electron (via HTTP)
            ↓
            → WebSocket Broadcast → Electron Frontend ✅
```

Now the `final_output` event reaches the frontend's WebSocket listener, which triggers `returnToWelcomeScreen()`.

## Benefits

✅ **Task completion detected** - Frontend receives `final_output` event  
✅ **Automatic return** - UI switches back to welcome screen  
✅ **Shows final output** - Agent's answer displayed in googly eye view  
✅ **Dual delivery** - Event sent via both SSE and WebSocket  
✅ **No breaking changes** - SSE stream still works as before  

## Testing

1. **Send a task** (e.g., "Open WhatsApp")
2. **Wait for completion** (backend logs "🎯 FINAL SWARM OUTPUT")
3. **Expected:** Backend logs `📡 Broadcasted final_output to WebSocket clients`
4. **Expected:** Frontend logs `🎯 Task completed! Returning to welcome screen...`
5. **Expected:** UI fades out workspace, shows welcome screen with final output

## Console Output

**Backend:**
```
🎯 FINAL SWARM OUTPUT: No output
📡 Broadcasted final_output to WebSocket clients
```

**Frontend:**
```
📨 WebSocket message received: {type: 'final_output', output: 'No output', ...}
🎯 Task completed! Returning to welcome screen...
🏠 Returning to welcome screen...
✅ Returned to welcome screen with final output
```

## Alternative Approaches Considered

### 1. Use Only WebSocket (No SSE)
**Rejected:** Would require rewriting the entire streaming architecture. SSE works well for HTTP clients.

### 2. Poll for Task Completion
**Rejected:** Inefficient and adds latency. Real-time events are better.

### 3. Send via Both SSE and WebSocket from Task Service
**Rejected:** Would tightly couple task service to WebSocket manager. Current approach keeps concerns separated.

## Related

- Task service: `uv/src/uv/services/task_service.py`
- WebSocket manager: `uv/src/uv/api/v1/websocket_agents.py`
- Frontend handler: `electron-app/src/renderer/js/app.js`
- Welcome screen return: `docs/adr/electron-return-to-welcome-on-completion.md`
