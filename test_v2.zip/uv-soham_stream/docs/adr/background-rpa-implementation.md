# ADR: Background RPA Implementation

**Date:** 2026-02-04  
**Status:** Proposed  
**Context:** User wants RPA automation that runs in background without interrupting daily work

## Problem

User needs RPA (Robotic Process Automation) capabilities that:
1. Run in the background without blocking user's daily work
2. Execute browser/terminal/app automation tasks concurrently
3. Use virtual displays or headless browsers to avoid GUI interference
4. Support task queuing and scheduling
5. Allow user to continue working while RPA performs actions

**Current Limitations:**
- Tasks execute synchronously via `solve_task_sync()`
- Browser automation uses visible browser windows (interferes with user)
- No task queue system for background execution
- No virtual display support for GUI automation

## Solution

Implement a modular background RPA system with:

### Architecture Components

1. **Background Task Queue**: Priority queue for RPA tasks
2. **Virtual Display Manager**: Xvfb/Xephyr for Linux, similar for macOS/Windows
3. **Background RPA Service**: Service that processes queue in background threads
4. **Headless Browser Support**: Option to run browsers headlessly or in virtual displays
5. **Task Status API**: Endpoints to monitor and control background tasks

### Key Design Decisions

#### 1. Virtual Display Isolation
- **Linux**: Use Xvfb (X Virtual Framebuffer) for headless GUI
- **macOS**: Use Quartz Display Services or headless Chrome
- **Windows**: Use headless Chrome or virtual desktop
- Isolate RPA browser sessions from user's display

#### 2. Task Queue System
- Priority queue (FIFO with optional priority)
- Task persistence (survive restarts)
- Task status tracking (pending, running, completed, failed)
- Retry mechanism for failed tasks

#### 3. Background Execution
- Separate thread pool for RPA tasks
- Non-blocking API endpoints
- WebSocket updates for task progress
- Resource limits (CPU, memory, concurrent tasks)

#### 4. Browser Isolation
- Separate browser profiles for RPA
- Headless mode option
- Virtual display option
- Cookie/session persistence per task

## Implementation Plan

### Module Structure

```
rpa/
├── __init__.py
├── background_service.py      # Main background RPA service
├── task_queue.py              # Task queue implementation
├── virtual_display.py         # Virtual display manager
├── task_executor.py           # Task execution wrapper
└── models.py                  # Task models and schemas
```

### Integration Points

1. **With Existing Executors**:
   - Wrap BrowserExecutor with virtual display support
   - Wrap TerminalExecutor with background execution
   - Maintain compatibility with existing agent system

2. **With Server API**:
   - Add `/api/rpa/tasks` endpoints
   - WebSocket for task updates
   - Task status monitoring

3. **With Synapse**:
   - Use existing Conductor for task planning
   - Leverage existing agent selection
   - Integrate with memory system

## Benefits

1. **Non-Intrusive**: User can continue working while RPA runs
2. **Scalable**: Queue system handles multiple tasks
3. **Reliable**: Task persistence and retry mechanisms
4. **Observable**: Status tracking and progress updates
5. **Modular**: Clean separation of concerns

## Trade-offs

1. **Resource Usage**: Virtual displays consume memory/CPU
2. **Complexity**: Additional system components to maintain
3. **Platform Support**: Different implementations for OS platforms
4. **Debugging**: Harder to debug headless/virtual display issues

## Configuration

```yaml
rpa:
  enabled: true
  max_concurrent_tasks: 3
  virtual_display:
    enabled: true
    width: 1920
    height: 1080
    depth: 24
  browser:
    headless: true
    virtual_display: true
  task_queue:
    persistence: true
    max_retries: 3
    retry_delay: 60
```

## Testing

- Unit tests for task queue
- Integration tests for virtual display
- End-to-end tests for background execution
- Performance tests for concurrent tasks

## Related

- `environment_manager.py`: Background thread pattern reference
- `surface_synapse/integration.py`: Task execution integration
- `surface/src/surface/agents/`: Executor agents
