# ADR: Browser Card Expands to Full Center During Activity, Then Hides

## Status
Accepted

## Context
During browser automation (WhatsApp Web, forms, etc.) the user should see the browser clearly. When the task is done, the browser should be hidden so the workspace returns to the normal grid.

## Decision
- **During browser activity**: When any browser command runs (navigate, click, type, etc.), the browser card is expanded to fill the whole center-workspace (middle section). Other agent cards are hidden. The BrowserView is shown and its bounds are updated to match the expanded card so the user sees the browser full-size.
- **When done**: When the task completes (final result / return to welcome screen), we collapse the browser from full center (remove fullscreen classes) and hide the BrowserView.

Implementation:
- CSS: `.agents-grid-workspace.browser-fullscreen-active` hides non-browser cards; `#module-box-BrowserExecutor.browser-card-expanded` fills the center (position absolute, inset 0, 100% size).
- `expandBrowserToFullCenter()` adds those classes at the start of each browser command.
- `collapseBrowserFromFullCenter()` removes classes and calls `hideNativeBrowser()` when returning to welcome or on task completion.

## Consequences
- User sees the browser in the full middle section during automation; when done, the browser is hidden and the grid returns to normal.
