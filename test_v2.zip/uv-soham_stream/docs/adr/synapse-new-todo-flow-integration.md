# ADR: Synapse_new TODO Flow Integration

**Date:** 2026-01-30  
**Status:** Implemented  
**Context:** Universal Task Solver Script (`run_solve_task.sh`)

## Context

The current Synapse `_initialize_todo_from_goal` method uses:
- `DynamicTaskPlanner` for LLM-based goal decomposition
- `MarkovianTODO` structure for task management
- Agent selection via `AgenticAgentSelector`

However, Synapse_new has a more sophisticated multi-agent flow:
- **TaskBreakdownAgent**: Breaks implementation plans into DAG workflows
- **TodoCreatorAgent**: Validates DAG, assigns actors, fixes issues
- **Domain entities**: `Task`, `TaskDAG`, `TaskType`, `TaskStatus`
- **DSPy Chain of Thought** reasoning for task breakdown

## Decision

Replace the entire TODO breakdown flow in Synapse's `conductor.py` with the Synapse_new approach:

### Components Copied from Synapse_new → Synapse

1. **Domain Entities** (`Synapse/domain/entities/`)
   - `task_types.py` - TaskType and TaskStatus enums
   - `task.py` - Task data class with dependencies
   - `task_dag.py` - TaskDAG for managing task graphs

2. **Agents** (`Synapse/agents/`)
   - `task_breakdown_agent.py` - Breaks plans into DAG
   - `todo_creator_agent.py` - Validates DAG and assigns actors

3. **Signatures** (`Synapse/signatures/`)
   - `task_breakdown_signatures.py` - Extract tasks, identify dependencies, optimize workflow
   - `todo_creator_signatures.py` - Actor assignment, DAG validation, DAG fixing
   - `dag_optimization_signatures.py` - DAG optimization

### New `_initialize_todo_from_goal` Flow

```python
async def _initialize_todo_from_goal(self, goal: str, kwargs: Dict):
    """
    Initialize TODO using Synapse_new multi-agent flow.
    
    Flow:
    1. Use goal as implementation plan (or optionally call a planner first)
    2. TaskBreakdownAgent: Break plan into TaskDAG
    3. TodoCreatorAgent: Validate DAG and assign actors
    4. Convert ExecutableDAG to MarkovianTODO for execution
    """
    
    # Step 1: Create TaskBreakdownAgent
    breakdown_agent = TaskBreakdownAgent()
    
    # Step 2: Break down goal into DAG
    task_dag = breakdown_agent.forward(implementation_plan=goal)
    
    # Step 3: Create Actor list from available agents
    actors = [
        Actor(
            name=name,
            capabilities=config.capabilities or [],
            description=self._get_agent_description(name, config)
        )
        for name, config in self.actors.items()
        if config.enabled
    ]
    
    # Step 4: Create TodoCreatorAgent and get executable DAG
    todo_creator = TodoCreatorAgent()
    executable_dag = todo_creator.forward(task_dag=task_dag, actors=actors)
    
    # Step 5: Convert ExecutableDAG to MarkovianTODO
    self._convert_dag_to_markovian_todo(executable_dag)
```

## Benefits

### 1. **Multi-Agent Reasoning**
   - TaskBreakdownAgent uses Chain of Thought for task extraction
   - TodoCreatorAgent uses ReAct for validation and fixing
   - More intelligent than single-agent decomposition

### 2. **Structured DAG Management**
   - Explicit Task entities with types, statuses, dependencies
   - DAG validation (cycle detection, feasibility checks)
   - Automatic issue fixing

### 3. **Better Actor Assignment**
   - Capability-based matching
   - Considers task dependencies
   - Validates actor availability

### 4. **Separation of Concerns**
   - Task breakdown: Pure planning logic
   - TODO creation: Pure orchestration logic
   - Clear domain model (Task, TaskDAG)

### 5. **Reusable Components**
   - TaskDAG can be serialized, visualized, analyzed
   - Agents can be used independently
   - Domain entities are framework-agnostic

## Implementation Details

### Directory Structure Created

```
Synapse/
├── domain/
│   ├── __init__.py
│   └── entities/
│       ├── __init__.py
│       ├── task_types.py
│       ├── task.py
│       └── task_dag.py
├── agents/
│   ├── __init__.py
│   ├── task_breakdown_agent.py
│   └── todo_creator_agent.py
└── signatures/
    ├── __init__.py
    ├── task_breakdown_signatures.py
    ├── todo_creator_signatures.py
    └── dag_optimization_signatures.py
```

### Import Changes

All imports updated from:
```python
from ..domain.entities import Task, TaskDAG
from ..signatures.xxx import YYY
```

To:
```python
from Synapse.domain.entities import Task, TaskDAG
from Synapse.signatures.xxx import YYY
```

### Integration Points

1. **Conductor.__init__()**: Initialize breakdown and creator agents
2. **_initialize_todo_from_goal()**: New implementation using agents
3. **_convert_dag_to_markovian_todo()**: Bridge between DAG and TODO

## Consequences

### Positive

✅ **More intelligent task breakdown** - Chain of Thought reasoning  
✅ **Better validation** - Automated DAG validation and fixing  
✅ **Cleaner architecture** - Separation of concerns  
✅ **Reusable components** - Agents can be used elsewhere  
✅ **Better testing** - Domain entities are easy to test  

### Negative

⚠️ **Additional LLM calls** - Two agents instead of one  
⚠️ **More complex** - Need to understand DAG structure  
⚠️ **Migration needed** - Existing MarkovianTODO usage must be preserved  

### Mitigations

- Keep MarkovianTODO as execution engine (don't replace)
- Add conversion layer: ExecutableDAG → MarkovianTODO
- Make agents optional: Fallback to original flow if agents fail
- Cache DAG results to avoid redundant LLM calls

## Usage Example

### Before (Old Flow)
```python
# Uses DynamicTaskPlanner directly
plan = self._task_planner.decompose_goal_sync(goal, agents, context)
self.todo.initialize_from_plan(plan.to_dict())
```

### After (New Flow)
```python
# Step 1: Break down into DAG
breakdown_agent = TaskBreakdownAgent()
task_dag = breakdown_agent.forward(implementation_plan=goal)

# Step 2: Validate and assign actors
todo_creator = TodoCreatorAgent()
executable_dag = todo_creator.forward(task_dag=task_dag, actors=actors)

# Step 3: Convert to MarkovianTODO
self._convert_dag_to_markovian_todo(executable_dag)
```

## Statistics

**Files Copied:** 9  
**New Directories:** 3  
**Lines of Code:** ~2000  
**Agents:** 2 (TaskBreakdownAgent, TodoCreatorAgent)  
**Signatures:** 6  
**Domain Entities:** 4  

## Testing

```bash
# Test imports
python3 -c "from Synapse.domain.entities import Task, TaskDAG; from Synapse.agents import TaskBreakdownAgent, TodoCreatorAgent; print('✅ Success')"

# Test script with new flow
./scripts/run_solve_task.sh "What is 2+2?" --max-iters 5
```

## References

- Synapse_new implementation: `/Synapse_new/`
- Original conductor: `/Synapse/core/conductor.py`
- ADR for script: `docs/adr/solve-task-universal-entrypoint.md`

---

**Result:** More intelligent, structured, and maintainable TODO breakdown flow with multi-agent reasoning and explicit DAG management.
