# Browser Authentication Persistence

**Status:** Implemented  
**Date:** 2026-01-30  
**Context:** BrowserExecutor Agent Enhancement

## Decision

Added authentication persistence capabilities to BrowserExecutor agent to maintain login sessions across browser restarts and application sessions.

## Problem

**User reported:** "When I authenticate for one request, why do I need to authenticate for the next request?"

**Root causes:**
1. Agent was calling `delete_all_cookies()` which removed authentication
2. No mechanism to save/restore authentication state
3. Each browser session started fresh with no cookies
4. Authentication had to be redone every time

**Impact:**
- Wasted time re-authenticating
- Annoying user experience
- Broke automated workflows
- Made unattended automation impossible

## Solution

### 1. Updated Agent Prompt

Added explicit instructions to BrowserExecutor system prompt:

```
AUTHENTICATION & SESSION PERSISTENCE:
• NEVER delete cookies unless explicitly requested by the user
• Cookies contain authentication state and should be preserved
• Use save_cookies_to_file() after login to persist authentication
• Use load_cookies_from_file() to restore authentication
• Use initialize_browser_with_profile() for automatic persistence
• Only use delete_all_cookies if user specifically asks to log out
```

### 2. Added Persistence Functions

Implemented 5 new browser tools:

#### Cookie-Based Persistence (Lightweight)

**`save_cookies_to_file(session_name, cookies_dir=None)`**
- Saves current browser cookies to pickle file
- Default location: `~/.browser_executor/cookies/{session_name}.pkl`
- Lightweight - only saves cookies
- Fast to save/load

**`load_cookies_from_file(session_name, cookies_dir=None, domain=None)`**
- Loads previously saved cookies into browser
- Optionally navigates to domain first (recommended)
- Restores authentication state
- Returns count of loaded cookies

#### Profile-Based Persistence (Comprehensive)

**`initialize_browser_with_profile(profile_name, browser_type="chrome", ...)`**
- Initializes browser with persistent profile directory
- Default location: `~/.browser_executor/profiles/{profile_name}/`
- Saves everything: cookies, history, preferences, extensions
- Automatic - no manual save/load needed
- Most comprehensive solution

#### Session Management

**`list_saved_sessions(cookies_dir=None)`**
- Lists all saved cookie sessions
- Returns session names and count
- Useful for managing multiple accounts

**`delete_saved_session(session_name, cookies_dir=None)`**
- Deletes saved cookie file
- Clean up old/expired sessions
- Manual cleanup when needed

### 3. File Structure

```
~/.browser_executor/
├── cookies/              # Cookie files (lightweight)
│   ├── github_work.pkl
│   ├── gmail_personal.pkl
│   └── api_tokens.pkl
└── profiles/             # Browser profiles (comprehensive)
    ├── production/
    │   ├── Default/
    │   ├── Cache/
    │   └── ...
    └── testing/
        └── ...
```

## Implementation Details

### Cookie Persistence

**Save Process:**
```python
# Get cookies from browser
cookies = driver.get_cookies()

# Serialize to file
with open(file_path, 'wb') as f:
    pickle.dump(cookies, f)
```

**Load Process:**
```python
# Load from file
with open(file_path, 'rb') as f:
    cookies = pickle.load(f)

# Add to browser
for cookie in cookies:
    driver.add_cookie(cookie)

# Refresh to apply
driver.refresh()
```

**Key Points:**
- Must navigate to domain before loading cookies
- Cookies only work on their original domain
- Failed cookies logged but don't stop process
- Returns count of successful/failed loads

### Profile Persistence

**Chrome:**
```python
options = webdriver.ChromeOptions()
options.add_argument(f"--user-data-dir={profile_path}")
driver = webdriver.Chrome(options=options)
```

**Firefox:**
```python
options = webdriver.FirefoxOptions()
options.add_argument("-profile")
options.add_argument(str(profile_path))
driver = webdriver.Firefox(options=options)
```

**Key Points:**
- Profile directory created automatically
- Saves on browser close
- Loads on browser start
- Includes everything (cookies, history, extensions, passwords)

### Error Handling

All functions return structured dictionaries:

```python
{
    "status": "success" | "error" | "partial",
    "error": None | "error message",
    # ... function-specific fields
}
```

**Graceful degradation:**
- Failed cookies logged but don't fail entire load
- Missing files return clear error messages
- Invalid profiles create new profiles

## Usage Patterns

### Pattern 1: Cookie Method (Simple)

```python
agent = BrowserExecutorAgent()

# First time - authenticate and save
instruction_save = """
1. Navigate to https://github.com and login
2. Save cookies as "github_session"
3. Close browser
"""
agent(instruction=instruction_save)

# Future runs - load and use
instruction_load = """
1. Initialize browser
2. Load cookies "github_session" with domain "https://github.com"
3. Navigate to https://github.com/settings  # Already logged in!
"""
agent(instruction=instruction_load)
```

### Pattern 2: Profile Method (Automatic)

```python
agent = BrowserExecutorAgent()

# First time - authenticate (auto-saved)
instruction_init = """
1. Initialize browser with profile "github_work"
2. Login to GitHub
3. Close browser  # Profile saved automatically
"""
agent(instruction=instruction_init)

# Future runs - just works!
instruction_reuse = """
1. Initialize browser with profile "github_work"
2. Navigate to GitHub  # Already authenticated!
"""
agent(instruction=instruction_reuse)
```

### Pattern 3: Multiple Accounts

```python
# Save multiple accounts
save_cookies_to_file("github_personal")
save_cookies_to_file("github_work")

# Switch between them
load_cookies_from_file("github_personal", "https://github.com")
load_cookies_from_file("github_work", "https://github.com")
```

## Benefits

### For Users

✅ **Authenticate once** - Never retype credentials  
✅ **Faster workflows** - Skip login steps  
✅ **Multiple accounts** - Easy account switching  
✅ **Unattended automation** - No manual intervention  
✅ **Better UX** - Persistent sessions like real browsing  

### For Developers

✅ **Simple API** - 5 intuitive functions  
✅ **Flexible** - Choose cookies (lightweight) or profiles (comprehensive)  
✅ **Secure** - Files stored in user home directory  
✅ **Cross-platform** - Works on Mac, Linux, Windows  
✅ **Well-documented** - Examples and guide included  

## Security Considerations

### Cookie Files

**Storage:**
- Saved as Python pickle files
- Location: `~/.browser_executor/cookies/`
- Permissions: User-only read/write
- Contains: Session tokens, auth cookies

**Risks:**
- ⚠️ Pickle files can contain sensitive data
- ⚠️ Could be accessed if system compromised
- ⚠️ Should be treated like passwords

**Mitigations:**
- ✅ Stored in user home directory (protected)
- ✅ Not world-readable
- ✅ User controls what gets saved
- ✅ Can delete anytime

### Browser Profiles

**Storage:**
- Full browser profile directory
- Location: `~/.browser_executor/profiles/`
- Contains: Everything a browser stores

**Risks:**
- ⚠️ May include saved passwords
- ⚠️ May include browsing history
- ⚠️ Larger attack surface than cookies

**Mitigations:**
- ✅ Same security as regular browser profiles
- ✅ User controls what gets saved
- ✅ Can use headless mode
- ✅ Can clear history/passwords if needed

### Best Practices

**Recommended:**
```python
# ✅ Use descriptive session names
save_cookies_to_file("production_api_auth")

# ✅ Clean up old sessions
delete_saved_session("old_test_session")

# ✅ Use profiles for long-term
initialize_browser_with_profile("automated_bot")
```

**Avoid:**
```python
# ❌ Generic names
save_cookies_to_file("session1")

# ❌ Sharing cookie files between users
# Each user should have their own

# ❌ Storing sensitive credentials in code
# Let agent handle authentication interactively
```

## Testing

### Test Cases

1. ✅ Save cookies after authentication
2. ✅ Load cookies in new session
3. ✅ Cookies work across app restarts
4. ✅ Profile saves automatically
5. ✅ Profile restores automatically
6. ✅ Multiple sessions don't interfere
7. ✅ List sessions returns correct count
8. ✅ Delete session removes file
9. ✅ Invalid session name handled gracefully
10. ✅ Missing file returns clear error

### Example Test

```bash
# Run persistence examples
poetry run python surface/example_browser_persistence.py

# Verify files created
ls ~/.browser_executor/cookies/
ls ~/.browser_executor/profiles/

# Rerun - should use saved authentication
poetry run python surface/example_browser_persistence.py
```

## Documentation

### Files Created

1. **`surface/BROWSER_PERSISTENCE_GUIDE.md`**
   - Complete user guide
   - All three methods explained
   - Common use cases
   - Troubleshooting

2. **`surface/example_browser_persistence.py`**
   - Working examples
   - Cookie method demo
   - Profile method demo
   - Session management demo

3. **`docs/adr/browser-authentication-persistence.md`**
   - This document
   - Technical details
   - Design decisions

### Updated Files

1. **`surface/src/surface/tools/browser_tools.py`**
   - Added 5 persistence functions
   - 500+ lines of implementation
   - Full docstrings

2. **`surface/src/surface/agents/browser_executor.py`**
   - Updated TOOLS list (29 tools now)
   - Updated system prompt
   - Added persistence guidance

3. **`surface/src/surface/tools/__init__.py`**
   - Exported new persistence functions
   - Graceful import fallbacks

## Comparison: Cookies vs Profiles

| Feature | Cookie Files | Browser Profiles |
|---------|-------------|-----------------|
| **Size** | Small (~KB) | Large (~MB) |
| **Speed** | Fast | Moderate |
| **Persistence** | Cookies only | Everything |
| **Setup** | Manual save/load | Automatic |
| **Use Case** | Simple auth | Long-term sessions |
| **Best For** | API tokens, quick switching | Daily automation, extensions |

## Future Enhancements

### Possible Additions

1. **Encryption**
   - Encrypt cookie files at rest
   - Use keyring for passwords
   - Add encryption passphrase option

2. **Cloud Sync**
   - Sync profiles across machines
   - S3/Google Drive integration
   - Team profile sharing

3. **Session Expiry**
   - Auto-detect expired sessions
   - Re-authenticate automatically
   - Expiry warnings

4. **Profile Management**
   - Export/import profiles
   - Profile templates
   - Profile comparison

5. **Multi-Browser Support**
   - Share sessions between Chrome/Firefox
   - Convert cookie formats
   - Cross-browser testing

## Consequences

**Positive:**
- ✅ Solves major user pain point
- ✅ Makes unattended automation possible
- ✅ Improves user experience significantly
- ✅ Enables complex workflows
- ✅ Supports multiple accounts/sessions
- ✅ Works across restarts
- ✅ Well-documented with examples

**Trade-offs:**
- New directory in user home (~/.browser_executor)
- Files contain sensitive data (must protect)
- Pickle files (Python-specific format)
- Need to manage old sessions (can accumulate)

**Risks Mitigated:**
- ✅ Cookie cleanup removed from agent prompt
- ✅ Clear error messages for missing files
- ✅ Graceful handling of expired cookies
- ✅ User controls what gets saved

## Related

- `browser-automation-tools.md` - Original browser tools
- `agent-tool-assignment-refactoring.md` - Tool architecture
- `BROWSER_PERSISTENCE_GUIDE.md` - User guide
- `example_browser_persistence.py` - Working examples

## Validation

```bash
# Create persistence example
poetry run python surface/example_browser_persistence.py

# Check created files
ls ~/.browser_executor/cookies/      # Should see .pkl files
ls ~/.browser_executor/profiles/     # Should see profile dirs

# Verify persistence
# 1. Run example - authenticates
# 2. Close browser
# 3. Run again - should stay authenticated!
```

**Status:** ✅ Tested and working
