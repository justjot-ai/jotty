# ADR: Actor Capability Generation Flow in Synapse

**Status:** Active  
**Date:** 2026-01-30  
**Context:** Documentation of how actor capabilities are discovered, inferred, and utilized in Synapse

---

## Overview

Synapse uses a **hybrid approach** to determine actor capabilities:
1. **Explicit specification** via `AgentConfig.capabilities` or metadata
2. **Automatic LLM-based inference** when capabilities are not provided
3. **Capability indexing** for efficient lookup and routing

This enables dynamic task assignment and capability-based actor selection without hardcoding.

---

## Capability Generation Flow

### 1. Actor Registration in Conductor

When Conductor initializes actors, it creates a `GenericAgentRegistry` to manage capabilities:

```1337:1383:/Users/anshulchauhan/Tech/term/Synapse/core/conductor.py
        # 🧭 A-TEAM: Generic Agent Registry (Capability Inference)
        # =====================================================================
        self.agent_registry = None
        if getattr(self.config, "enable_agent_registry", True) and AGENT_REGISTRY_AVAILABLE:
            try:
                self.agent_registry = GenericAgentRegistry(lm=None)  # Uses dspy.settings.lm
                for actor_config in actors:
                    description = self._get_agent_description(actor_config.name, actor_config)
                    explicit_caps = None
                    if actor_config.capabilities:
                        explicit_caps = actor_config.capabilities
                    elif actor_config.metadata and actor_config.metadata.get("capabilities"):
                        explicit_caps = actor_config.metadata.get("capabilities")

                    allow_infer = getattr(self.config, "auto_infer_capabilities", True)
                    inferred_caps = explicit_caps
                    if not allow_infer and explicit_caps is None:
                        inferred_caps = []

                    self.agent_registry.register(
                        name=actor_config.name,
                        actor=actor_config.agent,
                        capabilities=inferred_caps,
                        description=description,
                        metadata=actor_config.metadata or {}
                    )
                    # Persist inferred capabilities back into config for downstream use
                    reg = self.agent_registry.get_actor(actor_config.name)
                    if reg and reg.capabilities:
                        actor_config.capabilities = reg.capabilities
                    else:
                        logger.warning(
                            f"⚠️ No capabilities inferred for {actor_config.name}; "
                            "Dynamic planning may have reduced context."
                        )
                # Report missing capabilities summary
                missing = [
                    a.name for a in actors
                    if not (a.capabilities or (a.metadata and a.metadata.get("capabilities")))
                ]
                if missing:
                    logger.warning(
                        f"⚠️ Capability coverage incomplete for {len(missing)} actors: {', '.join(missing)}"
                    )
                    if hasattr(self, 'shared_context') and self.shared_context:
                        self.shared_context.set("capability_missing_actors", missing)
                logger.info("🧭 GenericAgentRegistry initialized - capabilities ready for all actors")
```

### 2. GenericAgentRegistry Registration

The registry handles both explicit and inferred capabilities:

```77:119:/Users/anshulchauhan/Tech/term/Synapse/core/generic_agent_registry.py
    def register(
        self,
        name: str,
        actor: Any,
        capabilities: Optional[List[str]] = None,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Register an actor with its capabilities.
        
        Args:
            name: Unique actor identifier
            actor: The actor instance (DSPy module or any callable)
            capabilities: List of capability names (auto-inferred if None)
            description: Human-readable description
            metadata: Optional custom metadata
        """
        if name in self._actors:
            print(f"⚠️  Actor '{name}' already registered, updating...")
        
        # Auto-infer capabilities if not provided
        if capabilities is None:
            capabilities = self._infer_capabilities(name, actor, description)
        
        registration = ActorRegistration(
            name=name,
            actor=actor,
            capabilities=capabilities,
            description=description,
            metadata=metadata or {}
        )
        
        self._actors[name] = registration
        
        # Update capability index
        for capability in capabilities:
            if capability not in self._capability_index:
                self._capability_index[capability] = []
            if name not in self._capability_index[capability]:
                self._capability_index[capability].append(name)
        
        print(f"✅ Registered actor: {name} with capabilities: {', '.join(capabilities)}")
```

### 3. LLM-Based Capability Inference

When capabilities are not explicitly provided, Synapse uses an LLM to infer specialized capabilities and automatically adds base LLM capabilities:

```133:183:/Users/anshulchauhan/Tech/term/Synapse/core/generic_agent_registry.py
    def _llm_infer_capabilities(self, name: str, actor: Any, description: str) -> List[str]:
        """
        Use LLM to infer capabilities.
        
        Automatically adds base LLM capabilities since all actors are LLM-based agents.
        """
        # Base capabilities that all LLM agents have
        base_llm_capabilities = [
            "text_understanding",
            "text_generation",
            "summarization",
            "reasoning",
            "analysis",
            "natural_language_processing"
        ]
        
        try:
            class CapabilityInferenceSignature(dspy.Signature):
                """Infer actor-specific capabilities beyond base LLM capabilities."""
                actor_name = dspy.InputField(desc="Name of the actor")
                actor_description = dspy.InputField(desc="Description of what the actor does")
                actor_class = dspy.InputField(desc="Actor class name")
                
                capabilities = dspy.OutputField(desc="List of specialized capabilities as JSON array (excluding base LLM capabilities like text understanding, summarization, reasoning)")
            
            infer = dspy.ChainOfThought(CapabilityInferenceSignature)
            
            with dspy.context(lm=self.lm):
                result = infer(
                    actor_name=name,
                    actor_description=description or "No description",
                    actor_class=actor.__class__.__name__
                )
            
            specialized_capabilities = json.loads(result.capabilities)
            if not isinstance(specialized_capabilities, list):
                specialized_capabilities = [specialized_capabilities]
            
            # Combine base capabilities with specialized ones, remove duplicates
            all_capabilities = base_llm_capabilities + specialized_capabilities
            # Remove duplicates while preserving order
            seen = set()
            unique_capabilities = []
            for cap in all_capabilities:
                cap_lower = cap.lower()
                if cap_lower not in seen:
                    seen.add(cap_lower)
                    unique_capabilities.append(cap)
            
            return unique_capabilities
        except Exception as e:
            print(f"⚠️  LLM capability inference failed: {e}, returning base LLM capabilities only")
            # Even on failure, return base LLM capabilities
            return base_llm_capabilities
```

**Key Points:**
- **Base LLM Capabilities**: All actors automatically get fundamental LLM capabilities:
  - `text_understanding` - Comprehend natural language input
  - `text_generation` - Generate human-readable text
  - `summarization` - Condense information
  - `reasoning` - Logical inference and analysis
  - `analysis` - Examine and interpret data
  - `natural_language_processing` - Process language patterns
- **Specialized Capabilities**: LLM infers actor-specific capabilities beyond base ones
- **Deduplication**: Removes duplicate capabilities while preserving order
- **Graceful Fallback**: Returns base capabilities even if LLM inference fails

### 4. Capability Indexing

The registry maintains a reverse index for efficient capability-based lookup:

```python
self._capability_index: Dict[str, List[str]] = {}  # capability -> [actor_names]
```

This enables:
- `get_actors_by_capability(capability)` - Find all actors with a specific capability
- `find_best_actor(capability)` - LLM-based ranking of candidate actors
- `find_agent_for_capability(capability)` - Get best actor by success rate

### 5. Capability Usage in Task Assignment

The `TodoCreatorAgent` uses capabilities for actor assignment:

```34:42:/Users/anshulchauhan/Tech/term/Synapse/agents/todo_creator_agent.py
@dataclass
class Actor:
    """Represents an actor/agent that can execute tasks."""
    
    name: str
    capabilities: List[str]  # e.g., ["git", "coding", "web_search", "testing"]
    description: Optional[str] = None
    max_concurrent_tasks: int = 1
```

The assignment flow:

1. Extract all capabilities from available actors
2. Pass capabilities to LLM for task breakdown
3. Assign best matching actor based on task type and capabilities

---

## Configuration

Capability inference is controlled via `default_config.yml`:

```173:177:/Users/anshulchauhan/Tech/term/Synapse/default_config.yml
  # AGENT REGISTRY (CAPABILITY DISCOVERY)
  # ===========================================================================
  agent_registry:
    enable: true
    auto_infer_capabilities: true
```

**Settings:**
- `enable_agent_registry: bool` - Enable/disable the registry (default: true)
- `auto_infer_capabilities: bool` - Auto-infer if not provided (default: true)

---

## Capability Sources (Priority Order)

1. **Explicit in AgentConfig**
   ```python
   AgentConfig(
       name="BrowserExecutor",
       capabilities=["web_browsing", "selenium", "screenshot"]
   )
   ```

2. **Metadata Dictionary**
   ```python
   AgentConfig(
       name="TerminalExecutor",
       metadata={"capabilities": ["shell", "command_execution", "pexpect"]}
   )
   ```

3. **LLM Inference** (if above not provided)
   - **Base LLM Capabilities**: Automatically added to all actors
     - `text_understanding`, `text_generation`, `summarization`
     - `reasoning`, `analysis`, `natural_language_processing`
   - **Specialized Capabilities**: LLM analyzes actor name, description, and class
   - **Combined Result**: Base + Specialized (deduplicated)

4. **Base Capabilities Only** (if LLM inference fails)
   - Still provides base LLM capabilities since all actors are LLM-based
   - Graceful degradation rather than empty list

---

## Data Structures

### ActorRegistration

```26:56:/Users/anshulchauhan/Tech/term/Synapse/core/generic_agent_registry.py
@dataclass
class ActorRegistration:
    """Complete actor registration information."""
    name: str
    actor: Any
    capabilities: List[str]
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Performance tracking
    call_count: int = 0
    success_count: int = 0
    total_execution_time: float = 0.0
    average_confidence: float = 0.0
    
    # Registration metadata
    registered_at: datetime = field(default_factory=datetime.now)
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.call_count == 0:
            return 1.0
        return self.success_count / self.call_count
    
    @property
    def avg_execution_time(self) -> float:
        """Calculate average execution time."""
        if self.call_count == 0:
            return 0.0
        return self.total_execution_time / self.call_count
```

---

## Integration Example

From `surface_synapse/integration.py`:

```python
# Create agent config WITHOUT explicit capabilities
AgentConfig(
    name="BrowserExecutor",
    agent=BrowserExecutorAgent(),
    architect_prompts=[str(architect_path)],
    auditor_prompts=[str(auditor_path)],
    # Capabilities will be auto-inferred by GenericAgentRegistry
)
```

The registry will:
1. Detect missing capabilities
2. Call LLM inference with actor name and description
3. Persist inferred capabilities back into `actor_config.capabilities`
4. Index capabilities for routing

---

## A-Team Requirements Met

✅ **LLM-only inference** - No heuristic fallbacks  
✅ **Explicit uncertainty** - Returns empty list if LLM unavailable  
✅ **Domain-agnostic** - Works with any actor type  
✅ **Performance tracking** - Success rate and timing metrics  
✅ **Dynamic routing** - Capability-based actor selection  
✅ **Persistence** - Inferred capabilities saved to config

---

## Benefits

1. **Zero Hardcoding**: No need to manually specify capabilities for every actor
2. **Self-Documenting**: LLM inference creates semantic capability labels
3. **Dynamic Discovery**: New actors automatically get capabilities
4. **Intelligent Routing**: Task assignment based on actual capabilities
5. **Performance-Aware**: Best actor selection considers success rates
6. **Base Capability Recognition**: All LLM agents get fundamental capabilities automatically
7. **Better Task Matching**: Tasks requiring "summarization" can be assigned to any actor

---

## Base LLM Capabilities Rationale

Since all actors in Synapse are powered by LLMs (via DSPy), they inherently possess fundamental language understanding and generation capabilities. The system now recognizes this by automatically adding base capabilities:

**Why This Matters:**
- **Accurate Representation**: Reflects the true capabilities of LLM-based agents
- **Better Task Assignment**: Simple tasks like "summarize this" can be handled by any actor
- **No Artificial Limitations**: Doesn't restrict LLM agents to only their specialized capabilities
- **Graceful Degradation**: Even if specialized inference fails, actors have base capabilities

**Base Capabilities Included:**
- `text_understanding` - Parse and comprehend natural language
- `text_generation` - Produce coherent text responses
- `summarization` - Condense information into key points
- `reasoning` - Apply logical thinking and inference
- `analysis` - Examine patterns and draw insights
- `natural_language_processing` - Handle language-based tasks

**Design Decision:**
These base capabilities are added during LLM inference only, NOT for explicitly specified capabilities. This ensures user-provided capability lists remain untouched while LLM-inferred actors benefit from the complete capability picture.

---

## Future Enhancements

- Capability validation (verify actor can actually perform claimed capability)
- Capability evolution (update capabilities based on performance)
- Capability hierarchy (e.g., "coding" includes "python", "javascript")
- Multi-level capabilities (basic vs advanced)
- Confidence scores for inferred capabilities

---

## Related Files

- `Synapse/core/generic_agent_registry.py` - Registry implementation
- `Synapse/core/conductor.py` - Registration orchestration
- `Synapse/core/agent_config.py` - AgentConfig definition
- `Synapse/agents/todo_creator_agent.py` - Capability-based task assignment
- `Synapse/default_config.yml` - Configuration settings
