# ADR: WhatsApp Baileys Rate Limit – Alternatives and Mitigations

## Status
Proposed

## Context
The WhatsApp agent uses **Baileys** (Node.js library) in the Electron app for WhatsApp Web API integration. We are experiencing **rate limits when connecting** (e.g. status 405, IP/connection throttling). Baileys uses the unofficial WhatsApp Web protocol; repeated connection attempts or multiple sessions from the same IP can trigger WhatsApp’s anti-abuse measures.

Current mitigations in `whatsapp-service.js`:
- Reconnect cap (3 attempts), exponential backoff, 405 handling and user-facing “wait 5 minutes” message.
- These reduce retry storms but do not remove the underlying rate-limit risk.

## Alternatives Considered

### 1. Stay on Baileys – Stronger Mitigations
- **Pairing code instead of QR**: Use Baileys pairing-code flow to reduce “new connection” footprint and avoid repeated QR scans.
- **Longer backoff and cooldown**: e.g. 10–15 min cooldown after max reconnect, and longer exponential backoff (e.g. 5m, 10m, 20m) before treating as “error”.
- **Single persistent session**: Avoid multiple connect/disconnect cycles; keep one session and reuse it; only reconnect when necessary (e.g. after `loggedOut` or explicit user disconnect).
- **Proxy (optional)**: Run Baileys behind a residential or mobile proxy to reduce IP-based rate limits (adds cost and ops; still unofficial).

**Pros:** No stack change; fits current architecture.  
**Cons:** Still unofficial; WhatsApp can tighten limits or change protocol anytime.

---

### 2. Switch to Another Unofficial Library
- **whatsapp-web.js**: Puppeteer-based, uses real WhatsApp Web in a browser. Different code path than Baileys; may have different rate-limit behaviour. Heavier (Chrome/Chromium). Actively maintained; larger community.
- **Venom-bot**: Similar browser-based approach. Less widely used than whatsapp-web.js.
- **Baileys-Pro**: Fork of Baileys with extra features. Same protocol as Baileys; likely same rate-limit surface; may have different connection/retry defaults.

**Pros:** whatsapp-web.js gives a different “client” fingerprint (browser vs WebSocket).  
**Cons:** All remain unofficial; account/device bans still possible; whatsapp-web.js requires Electron + Puppeteer/Chromium (we already have Electron).

---

### 3. Hosted “Unofficial” API (e.g. Whapi.Cloud, similar)
- Third-party services that run Baileys (or similar) in the cloud and expose an HTTP/WebSocket API. They often provide **per-account proxies** and handle retries/backoff.
- Example: Whapi.Cloud positions as Baileys alternative with dedicated proxies, live support, and reduced “blocking” risk.

**Pros:** Offload connection/rate-limit handling; dedicated IP/proxy per number.  
**Cons:** Cost, vendor lock-in, data flows through third party; still not official; ToS risk remains.

---

### 4. Official WhatsApp Business API (Cloud API)
- **Meta WhatsApp Cloud API** via Meta’s platform or a **Business Solution Provider (BSP)** (e.g. Twilio, 360dialog, MessageBird).
- Conversation-based pricing; many **in-session messages are free**; template messages and certain categories are paid. No “connection rate limit” in the same sense as Web; rate limits are throughput-based and documented.

**Pros:** No connection rate limits like Baileys; compliant; scalable; webhooks, templates, supported flows.  
**Cons:** Requires Business Account, approval, and (for some use cases) template approval; different product (business number, optional templates); may not suit “personal WhatsApp” automation.

---

## Decision
- **Short term:** Harden current Baileys usage (see below) before changing stack.
- **Medium term:** If rate limits persist, evaluate **WhatsApp Cloud API** for any business/personal use that can be mapped to a Business Account; otherwise evaluate **hosted unofficial API** (e.g. Whapi.Cloud) for dedicated proxy and managed connections.
- **Alternative stack:** Only consider **whatsapp-web.js** (or similar) if we explicitly want a browser-based client to diversify from Baileys’ WebSocket path; accept heavier runtime and maintenance.

### Recommended Immediate Mitigations (Baileys)
1. **Prefer pairing code over QR** where possible to reduce “new device” connection churn.
2. **Increase backoff** after failure (e.g. 5m / 10m / 20m) and enforce a **cooldown** (e.g. 10–15 min) before allowing “Connect” again after max retries.
3. **Persist a single session**: avoid unnecessary `disconnect`/`connect` cycles; reconnect only on real disconnect or logout.
4. **Optional:** Document or add **proxy** support for users who hit IP-based limits (advanced/ops).

## Consequences
- Implementing mitigations keeps the current architecture and avoids migration cost.
- Moving to Cloud API implies product/UX and possibly pricing changes (business number, templates).
- Any unofficial path (Baileys, whatsapp-web.js, or hosted) carries ToS and ban risk; document this for operators and users.

## Related
- [WhatsApp Baileys Integration](./whatsapp-baileys-integration.md)
- [WhatsApp Web Message Box Selector](./whatsapp-web-message-box-selector.md)
- Meta WhatsApp Business Platform: https://developers.facebook.com/docs/whatsapp
- Baileys: https://baileys.wiki/docs/intro/
