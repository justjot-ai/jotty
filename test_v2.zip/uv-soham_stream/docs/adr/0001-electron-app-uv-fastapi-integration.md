# ADR 0001: Electron App UV FastAPI Integration

**Date:** 2026-02-01

**Status:** Implemented

## Context

The Electron desktop app (`electron-app/`) was using a custom backend server (`surface_synapse/server.py`) running on port 8765. We needed to consolidate backends and use the UV FastAPI application (`uv/`) running on port 8000 instead.

## Decision

Migrated the Electron app to use the UV FastAPI server with the following changes:

### Backend Changes
1. **No new full endpoints**: Used existing `/api/v1/perform` endpoint for core task execution
2. **Minimal UI stubs**: Added `electron_support.py` with stub endpoints for:
   - `/api/agents/{session_id}` - Returns default agent list
   - `/api/artifacts/{session_id}` - Returns empty artifacts
   - `/ws/browser` - WebSocket stub for browser screenshots
   - `/ws/logs/{session_id}` - WebSocket stub for log streaming

### Frontend Changes (Electron App)
1. **API endpoint**: Changed from `/api/chat` to `/api/v1/perform`
2. **Port**: Changed from 8765 to 8000
3. **Request format**: 
   ```javascript
   // Old
   { message: "...", session_id: "..." }
   
   // New
   { task: "...", context: { session_id: "..." } }
   ```
4. **Response format**: Adapted to handle `PerformTaskResponse` structure
5. **Session management**: Moved to local file-based storage (session save/load)

### Startup Script Changes
- `run_electron_app.sh` now starts UV FastAPI server using `./uv/run_server.sh`
- Waits for server at `http://127.0.0.1:8000` instead of `http://127.0.0.1:8765`
- Backend PID tracking updated for new server

## Consequences

### Positive
- Single unified FastAPI backend for both API and Electron app
- Uses production-ready UV FastAPI server with proper structure
- Core task execution works via `/perform` endpoint
- Electron app maintains backward compatibility for UI elements

### Negative
- Some UI features are stubs (log streaming, browser screenshots, artifacts)
- Session statistics not yet implemented in UV backend
- Full feature parity requires future implementation

### Future Work
- Implement real-time log streaming in UV backend
- Add browser screenshot WebSocket support
- Implement session statistics tracking
- Add artifact (Q-tables, todos, env files) endpoints

## Implementation Files

### Modified
- `scripts/run_electron_app.sh` - Updated to start UV server
- `electron-app/src/main.js` - Updated API calls to use `/perform`
- `electron-app/src/renderer/js/app.js` - Updated WebSocket URLs
- `uv/src/uv/config.py` - Updated CORS to allow all origins
- `uv/src/uv/main.py` - Added electron_support router

### Created
- `uv/src/uv/api/v1/electron_support.py` - Stub endpoints for UI features
