# ADR: User Communication Agent

**Date:** 2026-02-02  
**Status:** Accepted  
**Author:** Synapse Team

## Context

Synapse needed a way to generate clear, concise, and actionable communications to users about task status and results. The existing agents (TaskBreakdownAgent, TodoCreatorAgent) handle task decomposition and execution, but there was no dedicated component for user-facing communication.

## Decision

Create a new DSPy Chain of Thought agent (`UserCommunicationAgent`) that:

1. Takes task description and context as input
2. Analyzes the task state and generates appropriate communication
3. Outputs communication type, message, suggested actions, and priority
4. Uses two signatures:
   - `UserCommunicationSignature`: Main communication generation
   - `CommunicationPrioritySignature`: Priority determination

## Design Choices

### Single vs Multi-Step Reasoning

**Chosen:** Single ChainOfThought per concern (communication vs priority)

**Rationale:** The A-Team review concluded that communication generation doesn't require multi-step task decomposition like TaskBreakdownAgent. A single ChainOfThought with proper output fields is sufficient.

### Communication Types

Defined six types: `PROGRESS`, `COMPLETION`, `ERROR`, `CLARIFICATION`, `WAITING`, `INFO`

These cover all common user communication scenarios while remaining generic.

### Optional LM

The agent supports both explicit LM injection and using `dspy.settings.lm`, following the pattern established by TodoCreatorAgent.

### Factory Function

Included `create_user_communication_agent()` for testability and consistency with existing patterns.

## A-Team Review Summary

| Reviewer | Position | Accepted |
|----------|----------|----------|
| Young MIT Graduate | Simple modular design | ✅ |
| Cursor Engineering Head | Separate handling for types | ✅ (via output fields) |
| Claude Code Lead | ChainOfThought handles logic | ✅ |
| RL/Optimization | Added next_actions field | ✅ |
| Product/UX | Concise output constraints | ✅ |
| QA/Validation | Factory function for testing | ✅ |

## Files Created

- `Synapse/agents/user_communication_agent.py` - Agent implementation
- `Synapse/signatures/user_communication_signatures.py` - DSPy signatures
- `tests/test_user_communication_agent.py` - Unit tests

## Files Modified

- `Synapse/agents/__init__.py` - Export new agent
- `Synapse/signatures/__init__.py` - Export new signatures
- `Synapse/core/io_manager.py` - Added user_message fields to SwarmResult
- `Synapse/core/conductor.py` - Integrated UserCommunicationAgent for final output

## Usage Example

### Standalone Usage

```python
from Synapse.agents import create_user_communication_agent

agent = create_user_communication_agent()

# Basic usage
communication = agent.generate(
    task_description="Analyze sales data and create summary report",
    context="Status: completed. Output: Report with 150 rows analyzed."
)

print(communication)
# [COMPLETION] Analysis complete. Generated summary report covering 150 data rows.

# With priority
communication = agent.generate_with_priority(
    task_description="Deploy to production",
    context="Status: failed. Error: Connection timeout.",
    task_importance="Critical path - release deadline tomorrow"
)

print(communication.priority)  # HIGH
print(communication.should_notify)  # True
```

### Via Conductor (SwarmResult)

The agent is automatically integrated into the Conductor. After a swarm run, the SwarmResult includes user-friendly communication:

```python
async for event in conductor.run(goal="Analyze the dataset"):
    if event.get("type") == "result":
        result = event["result"]
        
        # Access user-friendly message
        print(result["user_message"])  # "Analysis complete. Found 3 insights..."
        print(result["user_message_type"])  # "COMPLETION"
        print(result["suggested_actions"])  # ["Review the insights", "Export to CSV"]
```

## Consequences

**Positive:**
- Clear separation of concerns (communication vs execution)
- Consistent user messaging across Synapse
- Testable via factory function and dependency injection
- Follows established DSPy patterns

**Negative:**
- Additional LLM calls for communication generation
- May need tuning for specific use cases

## Future Considerations

1. Add communication templates for common scenarios
2. Add multi-language support for international users
3. Integrate with notification systems
