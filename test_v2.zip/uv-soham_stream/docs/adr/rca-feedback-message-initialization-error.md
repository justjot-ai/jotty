# RCA: FeedbackMessage Initialization Error - Wrong Parameter Names

**Date**: 2026-02-05  
**Status**: ✅ Implemented  
**Issue**: `Failure routing failed: FeedbackMessage.__init__() got an unexpected keyword argument 'from_actor'`

## Context

During failure routing, the code attempts to create a `FeedbackMessage` with incorrect parameter names:

```
2026-02-05 17:14:17.882 | ERROR | Synapse.core.conductor:6051 | Failure routing failed: FeedbackMessage.__init__() got an unexpected keyword argument 'from_actor'
```

**Location**: `Synapse/core/agentic_feedback_router.py` lines 120-130

```python
message = FeedbackMessage(
    from_actor=failing_actor_name,  # ❌ Wrong parameter name
    to_actor=target_agent,          # ❌ Wrong parameter name
    content=f"Error: {error_message}\n\nCooperation Strategy: {result.cooperation_strategy}",
    feedback_type=feedback_type_enum,
    context={...}
)
```

## 5 Whys Root Cause Analysis

### Why 1: Why is FeedbackMessage being created with wrong parameters?
**Answer**: The `agentic_feedback_router.py` code uses `from_actor` and `to_actor`, but `FeedbackMessage` expects `source_actor` and `target_actor`.

### Why 2: Why are the parameter names different?
**Answer**: The FeedbackMessage dataclass was defined with `source_actor` and `target_actor`, but the feedback router code was written using different names (`from_actor`/`to_actor`).

### Why 3: Why wasn't the feedback router updated to match?
**Answer**: Either the FeedbackMessage API changed after the router was written, or the router was written with incorrect assumptions about the API, or there was a copy-paste error from another similar class.

### Why 4: Why wasn't this caught during development/testing?
**Answer**: The failure routing code path may not be frequently executed, or tests don't cover this specific error scenario, or the error is silently caught and logged.

### Why 5: Why is there inconsistency in naming conventions?
**Answer**: Different parts of the codebase may have been written at different times, or by different developers, without consistent API documentation or type checking.

## Root Cause

**The root cause is**: Parameter name mismatch between `FeedbackMessage` dataclass definition and its usage in `agentic_feedback_router.py`.

## Current Implementation

**In `Synapse/core/feedback_channel.py`** (line 44-69):
```python
@dataclass
class FeedbackMessage:
    source_actor: str      # ✅ Correct parameter name
    target_actor: str      # ✅ Correct parameter name
    feedback_type: FeedbackType
    content: str
    context: Dict[str, Any] = field(default_factory=dict)
    # ... other fields
```

**In `Synapse/core/agentic_feedback_router.py`** (line 120-130):
```python
message = FeedbackMessage(
    from_actor=failing_actor_name,  # ❌ Wrong: should be source_actor
    to_actor=target_agent,           # ❌ Wrong: should be target_actor
    content=f"Error: {error_message}\n\nCooperation Strategy: {result.cooperation_strategy}",
    feedback_type=feedback_type_enum,
    context={...}
)
```

**Correct usage example** (from `Synapse/core/conductor.py` line 1192):
```python
fb = FeedbackMessage(
    source_actor=message.from_agent,  # ✅ Correct
    target_actor=target_actor_name,  # ✅ Correct
    feedback_type=FeedbackType.RESPONSE,
    content=str(message.data),
    # ...
)
```

## Suggested Fixes

### Fix 1: Update Parameter Names in agentic_feedback_router.py (Recommended)
**Location**: `Synapse/core/agentic_feedback_router.py` (line 120-130)

```python
# Change from:
message = FeedbackMessage(
    from_actor=failing_actor_name,
    to_actor=target_agent,
    content=f"Error: {error_message}\n\nCooperation Strategy: {result.cooperation_strategy}",
    feedback_type=feedback_type_enum,
    context={
        'reasoning': result.reasoning,
        'cooperation_strategy': result.cooperation_strategy,
        'failing_actor_goal': failing_actor_goal,
    }
)

# To:
message = FeedbackMessage(
    source_actor=failing_actor_name,  # ✅ Fixed
    target_actor=target_agent,        # ✅ Fixed
    content=f"Error: {error_message}\n\nCooperation Strategy: {result.cooperation_strategy}",
    feedback_type=feedback_type_enum,
    context={
        'reasoning': result.reasoning,
        'cooperation_strategy': result.cooperation_strategy,
        'failing_actor_goal': failing_actor_goal,
    }
)
```

### Fix 2: Add Parameter Aliases to FeedbackMessage (Alternative)
**Location**: `Synapse/core/feedback_channel.py`

If we want to support both naming conventions:

```python
@dataclass
class FeedbackMessage:
    source_actor: str = field(default="")
    target_actor: str = field(default="")
    
    def __post_init__(self):
        # Support aliases for backward compatibility
        if hasattr(self, 'from_actor') and not self.source_actor:
            self.source_actor = self.from_actor
        if hasattr(self, 'to_actor') and not self.target_actor:
            self.target_actor = self.to_actor
```

**Note**: This is more complex and not recommended - better to fix the call site.

## Implementation Priority

1. **High**: Fix 1 (Update Parameter Names) - Simple, correct solution
2. **Low**: Fix 2 (Add Aliases) - Unnecessary complexity

## Consequences

### Positive
- ✅ Failure routing will work correctly
- ✅ Feedback messages will be created successfully
- ✅ Agents will receive error feedback as intended
- ✅ Consistent API usage across codebase

### Considerations
- ⚠️ Need to verify no other call sites use wrong parameter names
- ⚠️ May want to add type checking/validation
- ⚠️ Consider adding unit tests for FeedbackMessage creation

## Testing

1. **Unit Test**: Create FeedbackMessage with correct parameters → Should succeed
2. **Unit Test**: Create FeedbackMessage with wrong parameters → Should raise TypeError
3. **Integration Test**: Trigger failure routing → Should create feedback messages successfully
4. **Regression Test**: Verify agents receive feedback messages correctly

## Files to Modify

- `Synapse/core/agentic_feedback_router.py` - Fix parameter names (line 120-130)
- Consider adding type hints/validation to FeedbackMessage

## Additional Notes

This error pattern suggests we should:
1. Add type checking (mypy/pyright) to catch these errors early
2. Use IDE autocomplete/type hints more consistently
3. Add unit tests for dataclass initialization
4. Document API contracts more clearly
