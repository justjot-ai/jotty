# ADR: UV Directory Cleanup and Organization

**Date:** 2026-02-01  
**Status:** Implemented  
**Context:** UV directory cleanup and file organization

## Decision

Cleaned up the `uv/` directory by organizing files into appropriate folders based on their purpose, while maintaining necessary configuration and build files in the root.

## Changes Made

### 1. Created New Structure
- Created `uv/examples/` directory for example scripts and clients

### 2. Moved Documentation Files
Moved the following files from `uv/` to `docs/`:
- `EVENT_STREAMING_IMPLEMENTATION.md` - Event streaming architecture documentation
- `PERFORMANCE.md` - Performance optimization documentation
- `QUICK_START.md` - Quick start guide
- `async_generator_conversion_checklist.md` - Async conversion tracking
- `modules_referenced_in_log.txt` - Module reference list

### 3. Moved Example Files
Moved the following files from `uv/` to `uv/examples/`:
- `example_perform_client.py` - Python client example
- `example_perform_stream.sh` - Streaming shell example
- `example_perform.sh` - Basic shell example

### 4. Moved Log Files
Moved the following files from `uv/` to `logs/`:
- `a.txt` - Server log output

### 5. Files Kept in UV Root
The following essential files remain in `uv/`:
- `b.txt` - Current log file (as requested)
- `.dockerignore`, `.env.example`, `.gitignore` - Configuration
- `docker-compose.yml`, `Dockerfile` - Container setup
- `Makefile` - Build automation
- `pyproject.toml` - Python project configuration
- `README.md` - Main documentation
- `run_server.sh` - Server startup script
- `src/` - Source code directory
- `tests/` - Test directory

## Final Structure

```
uv/
├── .dockerignore
├── .env.example
├── .gitignore
├── b.txt                    # Current log (kept as requested)
├── docker-compose.yml
├── Dockerfile
├── Makefile
├── pyproject.toml
├── README.md
├── run_server.sh
├── examples/                # NEW: Example scripts
│   ├── example_perform_client.py
│   ├── example_perform_stream.sh
│   └── example_perform.sh
├── src/
│   └── uv/
│       ├── api/
│       ├── config.py
│       ├── core/
│       ├── db/
│       ├── dependencies.py
│       ├── main.py
│       ├── schemas/
│       ├── services/
│       └── utils/
└── tests/
    ├── conftest.py
    ├── test_auth.py
    ├── test_health.py
    ├── test_perform.py
    └── test_users.py
```

## Rationale

1. **Separation of Concerns**: Documentation, examples, and logs are now in dedicated locations
2. **Cleaner Root**: UV root directory now only contains essential configuration and build files
3. **Better Organization**: Developers can easily find examples and documentation in standard locations
4. **Maintainability**: Clear structure makes it easier to maintain and extend the project
5. **Project Standards**: Follows the project's modular approach and folder structure conventions

## Consequences

### Positive
- Cleaner, more organized directory structure
- Easier to navigate and find files
- Better separation between code, configuration, examples, and documentation
- Follows project conventions for documentation and examples

### Neutral
- Developers need to update any hardcoded paths to moved files
- Example scripts now in `examples/` subdirectory

### Negative
- None identified

## Notes

- `b.txt` was explicitly kept in the UV root as requested by the user
- All essential configuration files remain in the root for proper tooling support
- The cleanup maintains the modular structure required by project standards
