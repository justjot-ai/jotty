# Async Broadcast Fix - Coroutine Never Awaited

**Date:** 2026-02-01  
**Issue:** `RuntimeWarning: coroutine '_broadcast_browser_event' was never awaited`  
**Status:** Fixed - Restart Required  

---

## Problem

The browser and terminal tools were trying to call async functions from synchronous code:

```python
# ❌ This doesn't work in sync context
import asyncio
asyncio.create_task(_broadcast_browser_event(...))
# RuntimeWarning: coroutine '_broadcast_browser_event' was never awaited
```

**Result:** Events were never broadcast to Electron, so no browser/terminal views appeared!

---

## Root Cause

The browser/terminal tools are **synchronous functions** (called by DSPy agents), but they were trying to call **async broadcast functions**. 

When there's no event loop running, `asyncio.create_task()` fails and the coroutine is never executed.

---

## Solution

Created synchronous wrapper functions that handle async calls properly:

```python
def _broadcast_browser_event_sync(event_type: str, data: Dict[str, Any]):
    """Works in synchronous context by running in background thread."""
    
    async def _do_broadcast():
        await manager.broadcast_agent_event(AgentType.BROWSER, event_type, data)
    
    # Try existing event loop
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_do_broadcast())
        else:
            loop.run_until_complete(_do_broadcast())
    except RuntimeError:
        # No event loop, run in new thread
        def run_in_thread():
            asyncio.run(_do_broadcast())
        
        thread = threading.Thread(target=run_in_thread, daemon=True)
        thread.start()
```

---

## Files Modified

1. ✅ `surface/src/surface/tools/browser_tools.py`
   - Changed `_broadcast_browser_event` (async) → `_broadcast_browser_event_sync` (sync)
   - Updated all calls to use sync version

2. ✅ `surface/src/surface/tools/terminal_tools.py`
   - Changed `_broadcast_terminal_event` (async) → `_broadcast_terminal_event_sync` (sync)
   - Updated all calls to use sync version

---

## How to Apply

### Step 1: Restart Server (Terminal 106)

```bash
Ctrl+C
./run_server.sh
```

### Step 2: Restart Electron (Terminal 104)

```bash
Ctrl+C
npm start
```

### Step 3: Test

Send in Electron:
```
"Open Google"
```

**Server logs should show:**
```
✅ Navigation successful
Agent activated: BrowserExecutor  ← Should see this now!
📡 Agent event: BrowserExecutor.navigate  ← Should see this now!
```

**NO MORE:**
```
❌ RuntimeWarning: coroutine '_broadcast_browser_event' was never awaited
```

---

## Why This Works

### Before (Broken)
```
navigate_to_url() [sync]
  → asyncio.create_task(_broadcast_browser_event())
    → RuntimeError: No event loop
      → Coroutine never awaited ❌
        → No event broadcast
          → No browser view in Electron
```

### After (Fixed)
```
navigate_to_url() [sync]
  → _broadcast_browser_event_sync()
    → Creates background thread
      → asyncio.run(_do_broadcast())
        → await manager.broadcast_agent_event() ✅
          → Event broadcast to Electron
            → Browser view appears! ✅
```

---

## Complete Fix Chain

All issues have been fixed:

1. ✅ **WebSocket endpoint** - Added to correct server (`uv/main.py`)
2. ✅ **Python path** - Added project root to sys.path
3. ✅ **AgentSessionManager** - Initialized in lifespan
4. ✅ **Async broadcast** - Fixed sync/async mismatch ← THIS FIX!

---

## Test Checklist

After restart, verify:

- [ ] No RuntimeWarning in server logs
- [ ] Server logs show: `✅ AgentSessionManager initialized`
- [ ] Server logs show: `Agent activated: BrowserExecutor`
- [ ] Server logs show: `📡 Agent event: BrowserExecutor.navigate`
- [ ] Electron shows browser view in center panel
- [ ] Browser view shows actual Chrome browser
- [ ] Auto-switching works between agents

---

## Summary

**Problem:** Async functions called from sync context  
**Solution:** Created sync wrapper functions with thread-based execution  
**Status:** Ready to test after restart  

**This is the final piece! After restart, everything should work!** 🚀

---

## Quick Restart Commands

```bash
# Terminal 106
Ctrl+C
./run_server.sh

# Terminal 104
Ctrl+C
npm start

# Test
"Open Google"
```

**You should see the browser in Electron now!** 🎉
