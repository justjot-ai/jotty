# ADR: WebSearch Agent UI Display Fix

## Status
Accepted

## Date
2026-02-02

## Context
The WebSearch agent was not appearing in the Electron UI like BrowserExecutor and TerminalExecutor agents. When running tasks that involved web search, the WebSearch module box was not being created or displayed in the agent grid.

## Problem
Root cause analysis revealed TWO issues:

### Issue 1: Module Name Mismatch (SSE Events)
1. **Backend**: `WebSearchAgent` class has `AGENT_NAME = "WebSearch"` (in `surface/src/surface/agents/web_search.py`)
2. **Events**: When events are emitted via SSE, they use module names like `surface.agents.websearch`
3. **UI Mapping**: The `agent-view-manager.js` moduleMapping only had `'WebSearchAgent'` and `'web_search_agent'`

The `getModuleKey()` function checks if the mapping key is a **substring** of the module name:
- `"browserexecutor"` IS a substring of `"surface.agents.browserexecutor"` ✓
- `"websearchagent"` is NOT a substring of `"surface.agents.websearch"` ✗

### Issue 2: Missing WebSocket Event Broadcasting
Unlike BrowserExecutor and TerminalExecutor tools which broadcast events via WebSocket to the Electron UI (using `_broadcast_browser_event_sync` and `_broadcast_terminal_event_sync`), the WebSearch tools (`web_search.py`) had no event broadcasting mechanism.

## Decision
Fix both issues:
1. Add the correct key variants to the UI module mapping
2. Add WebSocket event broadcasting to web search tools

### Changes Made

#### Part 1: UI Module Mapping Fix

1. **agent-view-manager.js - Module Mapping** (lines 74-79):
   - Added `'WebSearch'` and `'websearch'` keys to moduleMapping

2. **agent-view-manager.js - Event Handling**:
   - Added special handling for WebSearch agent events via WebSocket (similar to Browser and Terminal)
   - Routes WebSearch events to `handleWebSearchEvent()` method

3. **agent-view-manager.js - New Methods**:
   - `handleWebSearchEvent()` - Handles search queries and results
   - `displaySearchQuery()` - Shows search query in module box
   - `displaySearchResults()` - Shows search results in module box
   - `appendSearchLog()` - Appends log messages to search output area
   - `escapeHtml()` - For safe HTML rendering

4. **agent-view-manager.js - Module Box Creation**:
   - Updated `createModuleBox()` to create a proper search output area for WebSearch
   - Added `searchOutput` field to module box object

5. **app.js - Agent Indicator Mapping**:
   - Updated `updateActiveAgentIndicator()` to map all WebSearch variants to 'search'

6. **agent-views.css**:
   - Added CSS styles for `.module-search-content` and `.search-output-area`
   - Added styles for search query lines, results containers, and log lines

#### Part 2: WebSocket Event Broadcasting

7. **surface/src/surface/tools/web_search.py**:
   - Added `_broadcast_websearch_event_sync()` function (similar to browser/terminal)
   - Imported `AgentSessionManager` and `AgentType` from `surface_synapse`
   - Added broadcast calls in `web_search()`:
     - `query` event when search starts
     - `results` event when search completes (with formatted results for UI)
   - Added broadcast calls in `scrape_website()`:
     - `scrape` event when scraping starts and completes

## Consequences

### Positive
- WebSearch agent now appears in the UI with its own module box
- Search queries and results are displayed in real-time via WebSocket
- Consistent with BrowserExecutor and TerminalExecutor handling
- Agent status indicator in sidebar properly shows WebSearch activity
- WebSearch module box auto-creates and moves to front when search operations occur

### Negative
- Additional mapping variants to maintain (minor)
- Small overhead from WebSocket broadcasting (negligible)

## Notes
- The fix maintains backward compatibility - existing `WebSearchAgent` and `web_search_agent` keys are still supported
- WebSocket events use `AgentType.WEBSEARCH` enum which maps to `"WebSearchAgent"`
- The server must be restarted for the web_search.py changes to take effect
