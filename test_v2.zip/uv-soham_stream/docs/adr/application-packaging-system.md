# ADR: Application Packaging System

**Date**: 2026-02-02  
**Status**: Implemented  
**Context**: User requested a script to package both Electron app and UV application with subpackages into a distributable window application

## Decision

Created a comprehensive multi-platform application packaging system that bundles:
- Python backend (UV + Synapse + Surface + surface_synapse)
- Electron frontend with embedded browser and terminal
- Platform-specific installers for Windows, macOS, and Linux

## Implementation

### Components Created

1. **`scripts/build_application.py`**: Main Python build orchestrator
   - Handles dependency installation
   - Bundles Python backend using PyInstaller
   - Integrates backend with Electron resources
   - Builds platform-specific distributables

2. **`scripts/build_app.sh`**: Unix/macOS build wrapper
   - Prerequisite checking
   - User-friendly CLI interface
   - Color-coded output

3. **`scripts/build_app.bat`**: Windows build wrapper
   - Windows-compatible prerequisite checking
   - Batch script interface

4. **`build-requirements.txt`**: Build dependencies
   - PyInstaller and build tools

5. **`docs/BUILD_GUIDE.md`**: Comprehensive documentation
   - Platform-specific instructions
   - Troubleshooting guide
   - CI/CD integration examples

### Build Process Flow

```
1. Clean artifacts
2. Install Python dependencies (Poetry)
3. Install Node.js dependencies (npm)
4. Bundle Python backend (PyInstaller)
   ├── UV FastAPI server
   ├── Synapse core
   ├── Surface package
   └── surface_synapse integration
5. Copy backend to Electron resources
6. Update Electron configuration
7. Create platform-specific startup scripts
8. Build Electron app (electron-builder)
9. Copy final artifacts to dist/
10. Generate distribution README
```

### PyInstaller Specification

- **Entry Point**: `uv/src/uv/main.py`
- **Included Packages**: UV, Synapse, Surface, surface_synapse
- **Data Files**: Config files, prompts, templates
- **Hidden Imports**: uvicorn, fastapi, selenium, dspy, anthropic, openai, litellm

### Electron Integration

- Backend bundled in `resources/backend/`
- Startup scripts launch backend before UI
- Environment variables configured for localhost communication
- Backend PID tracked for cleanup

## Rationale

### Why PyInstaller?

- Creates standalone executables
- Handles complex dependency trees
- Cross-platform support
- No Python installation required on target system

### Why Electron Builder?

- Industry standard for Electron packaging
- Supports all major platforms
- Auto-update capabilities
- Code signing support

### Architecture Decisions

1. **Backend as Resource**: Bundle backend with Electron rather than separate installer
   - Simpler deployment
   - Single installation process
   - Guaranteed version compatibility

2. **Startup Scripts**: Platform-specific scripts to launch backend
   - Ensures backend starts before UI
   - Handles environment setup
   - Manages process lifecycle

3. **Modular Build System**: Separate Python script with shell wrappers
   - Reusable Python logic
   - Platform-specific convenience wrappers
   - Easy CI/CD integration

## Usage

### Quick Build

```bash
# macOS/Linux
./scripts/build_app.sh --platform mac

# Windows
scripts\build_app.bat --platform win
```

### Clean Build

```bash
./scripts/build_app.sh --clean --platform all
```

### Manual Build

```bash
python scripts/build_application.py --platform mac --project-root .
```

## Output Structure

```
dist/
├── UV-1.0.0.dmg              # macOS installer
├── UV Setup 1.0.0.exe        # Windows installer
├── UV-1.0.0.AppImage         # Linux AppImage
└── README.txt                # Distribution readme
```

## Platform Support

| Platform | Format | Size (approx) | Code Signing |
|----------|--------|---------------|--------------|
| macOS    | DMG    | 200-300 MB    | Optional     |
| Windows  | NSIS   | 150-250 MB    | Optional     |
| Linux    | AppImage| 200-300 MB   | N/A          |

## Dependencies

### Build Time
- Python 3.13+
- Node.js 18+
- Poetry
- PyInstaller
- electron-builder

### Runtime (Bundled)
- All Python packages
- Node.js runtime (Electron)
- Chrome/Chromium (Electron)

## Future Enhancements

1. **Auto-Updates**: Integrate electron-updater
2. **Code Signing**: Automated signing pipeline
3. **Notarization**: macOS notarization for Gatekeeper
4. **Portable Builds**: ZIP/TAR distributions
5. **Docker Builds**: Containerized build environment
6. **Size Optimization**: Reduce bundle size through tree-shaking

## Alternatives Considered

### Alternative 1: Separate Installers
- **Rejected**: More complex deployment, version mismatch risks

### Alternative 2: Docker Container
- **Rejected**: Not suitable for desktop application distribution

### Alternative 3: Web Application
- **Rejected**: Requires server deployment, loses desktop integration

## Testing

### Build Testing
```bash
# Test build for current platform
./scripts/build_app.sh

# Verify output exists
ls -la dist/
```

### Distribution Testing
1. Install on clean system without dev tools
2. Verify backend starts
3. Test all UI features
4. Check browser embedding
5. Verify terminal functionality

## Rollout

1. Test builds on all platforms
2. Create GitHub release with artifacts
3. Update documentation
4. Announce to users

## Maintenance

- Update PyInstaller spec when adding dependencies
- Keep electron-builder configuration current
- Test builds with each major dependency update
- Monitor bundle size growth

## References

- PyInstaller: https://pyinstaller.org/
- electron-builder: https://www.electron.build/
- Electron: https://www.electronjs.org/

## Notes

- Build scripts follow project's modular structure
- All scripts placed in `scripts/` directory
- Documentation in `docs/` directory
- Follows user rules for project organization
- Uses `poetry install --only main` instead of deprecated `--no-dev` flag

## Known Issues & Fixes

### Poetry `--no-dev` Deprecated (Fixed)
- **Issue**: Poetry 1.2+ deprecated `--no-dev` flag
- **Fix**: Changed to `--only main` for installing production dependencies
- **Date**: 2026-02-02
