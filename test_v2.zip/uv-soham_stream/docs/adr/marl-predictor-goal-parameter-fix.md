# MARL Predictor Goal Parameter Fix

**Date:** 2026-01-31  
**Status:** Fixed  
**Context:** MARL prediction was failing with missing required argument

## Problem

The `LLMTrajectoryPredictor.predict()` method was failing with error:
```
⚠️ MARL prediction failed: LLMTrajectoryPredictor.predict() missing 1 required positional argument: 'goal'
```

## Root Cause

In `Synapse/core/conductor.py` line 6986, the `predict()` method was being called without the required `goal` parameter:

```python
marl_prediction = self.trajectory_predictor.predict(
    current_state=current_state,
    acting_agent=actor_config.name,
    proposed_action={'task': task.description},
    other_agents=other_agents
    # Missing: goal parameter
)
```

The `predict()` method signature requires 5 parameters including `goal`:
- `current_state: Dict[str, Any]`
- `acting_agent: str`
- `proposed_action: Dict[str, Any]`
- `other_agents: List[str]`
- `goal: str` ← **This was missing**

## Solution

Added the `goal` parameter to the predict call using the goal from kwargs with task description as fallback:

```python
marl_prediction = self.trajectory_predictor.predict(
    current_state=current_state,
    acting_agent=actor_config.name,
    proposed_action={'task': task.description},
    other_agents=other_agents,
    goal=kwargs.get('goal', task.description)  # ← Added
)
```

## Impact

- ✅ MARL trajectory prediction now works correctly
- ✅ Agents receive proper collaboration suggestions
- ✅ Predictive multi-agent coordination is fully functional
- ✅ No breaking changes - uses sensible fallback

## Files Modified

- `Synapse/core/conductor.py` - Added goal parameter to predict() call (line 6991)
