# ADR: DevTools Only in Dev Mode

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Electron DevTools visibility

## Problem

DevTools was set to always open automatically for debugging purposes, which is not ideal for production use.

**User Request:**
> "close elctron js debug mode"

## Solution

Only open DevTools when running in development mode with the `--dev` flag.

### Changes

**File:** `electron-app/src/main.js`

**Before:**
```javascript
mainWindow.once('ready-to-show', () => {
  mainWindow.show();
  mainWindow.setFullScreen(true);
  
  // Always open DevTools for debugging
  mainWindow.webContents.openDevTools();
});
```

**After:**
```javascript
mainWindow.once('ready-to-show', () => {
  mainWindow.show();
  mainWindow.setFullScreen(true);
  
  // Open DevTools only in dev mode
  if (process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools();
  }
});
```

## Usage

### Production Mode (No DevTools)
```bash
cd electron-app
npm start
```

### Development Mode (With DevTools)
```bash
cd electron-app
npm start -- --dev
```

Or update `package.json`:
```json
{
  "scripts": {
    "start": "electron .",
    "dev": "electron . --dev"
  }
}
```

Then run:
```bash
npm run dev
```

## Benefits

✅ **Clean production UI** - No DevTools cluttering the interface  
✅ **Easy debugging** - Still accessible with `--dev` flag  
✅ **Professional appearance** - Users see clean interface  
✅ **Keyboard shortcut** - Can still open with `Cmd+Option+I` (Mac) or `Ctrl+Shift+I` (Windows/Linux)  

## Manual DevTools Access

Even without `--dev` flag, users can still open DevTools manually:

- **Mac:** `Cmd + Option + I`
- **Windows/Linux:** `Ctrl + Shift + I`
- **Menu:** View → Toggle Developer Tools (if menu is enabled)

## Testing

1. **Restart Electron without `--dev` flag:**
   ```bash
   npm start
   ```
   **Expected:** No DevTools panel

2. **Restart with `--dev` flag:**
   ```bash
   npm start -- --dev
   ```
   **Expected:** DevTools opens automatically

## Related

- Main process: `electron-app/src/main.js`
- Package scripts: `electron-app/package.json`
