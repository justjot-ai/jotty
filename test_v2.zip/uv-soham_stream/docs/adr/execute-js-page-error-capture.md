# ADR: Execute JS – Capture page exception and send to backend

## Status
Accepted

## Context
When `execute_js` ran a script that threw inside the page, Electron’s `executeJavaScript` rejected with a generic message (e.g. “Script failed to execute, this normally means an error was thrown. Check the renderer console for the error.”). Only that generic string was returned to the backend, so the real JS exception (message, name, stack) was never sent and debugging was hard.

## Decision
- Run the user script inside the page via a wrapper that uses `new Function(userScript)()` inside a try/catch in the page.
- On throw, the wrapper returns a structured object `{ __ok: false, message, name, stack }` instead of letting the exception propagate to Electron.
- Main process maps that to `{ success: false, error, errorName, errorStack }` and sends it to the renderer/backend unchanged.
- User script is injected as `JSON.stringify(script)` so no escaping issues in the wrapper.

## Consequences
- Backend and renderer receive the actual page exception message and optional stack when `execute_js` fails.
- Renderer logs include `error` and `errorName` in the “Sent response” line for failed execute_js.
- Any failure of the wrapper itself (e.g. script not runnable by `new Function`) still surfaces as a normal JS error and is captured the same way.
