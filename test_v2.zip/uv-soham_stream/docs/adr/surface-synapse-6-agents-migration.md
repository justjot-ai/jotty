# ADR: Surface Synapse Migration to 6 Swarm Agents

## Status
Accepted

## Date
2026-01-10

## Context
The `surface_synapse` package previously used 2 agents from `custom_terminus2`:
- `TerminusAgent` - Terminal operations
- `WebSearcherAgent` - Web search operations

This created a dependency on `custom_terminus2` which was planned for deletion.
Additionally, the new Surface system has 6 specialized swarm agents that provide
better task coverage with non-overlapping skills.

## Decision
Migrate `surface_synapse` to use the 6 new swarm agents from the `surface` package:

1. **CodeMaster** - Software engineering, algorithms, debugging
2. **DataMind** - ML/data science, model training, ETL
3. **SysOps** - System administration, Docker, networking
4. **SecureSentry** - Security, cryptography, vulnerabilities
5. **ScienceCore** - Scientific computing, mathematics
6. **DomainExpert** - Games, finance, media, scheduling

Each agent has both terminal AND web search tools available.

## Changes Made
1. Created 6 new agent wrapper files in `surface_synapse/agents/`
2. Updated `integration.py` - Synapse auto-selects agents (no hardcoded mapping)
3. Created architect/auditor prompts for all 6 agents
4. Updated `__init__.py` files to export new agents
5. Removed old `terminus_agent.py` and `web_searcher_agent.py`
6. Removed old architect/auditor prompts

## Agent Selection
Synapse automatically selects the appropriate agent(s) for each task using:
- **AgenticToolSelector**: LLM-based tool/agent selection (no regex/keywords)
- **AgenticFeedbackRouter**: Routes feedback between agents intelligently
- **AgenticParameterResolver**: Maps parameters automatically using semantics

No hardcoded task-category-to-agent mapping needed!

## Consequences
### Positive
- No dependency on `custom_terminus2` (can be deleted)
- Better task specialization with 6 domain-focused agents
- Each agent has full tool access (terminal + web search)
- Automatic agent selection via Synapse's agentic components (not hardcoded)

### Negative
- More complex swarm configuration
- Need to maintain 6 sets of prompts instead of 2

## File Structure
```
surface_synapse/
├── agents/
│   ├── code_master_agent.py
│   ├── data_mind_agent.py
│   ├── sys_ops_agent.py
│   ├── secure_sentry_agent.py
│   ├── science_core_agent.py
│   ├── domain_expert_agent.py
│   └── synapse_surface_agent.py
├── architect/
│   ├── codemaster_agent.md
│   ├── datamind_agent.md
│   ├── sysops_agent.md
│   ├── securesentry_agent.md
│   ├── sciencecore_agent.md
│   ├── domainexpert_agent.md
│   └── swarm_level.md
├── auditor/
│   └── (matching prompts)
└── integration.py
```
