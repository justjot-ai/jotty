# ADR: TodoCreator Agent Implementation

**Status:** Implemented  
**Date:** 2026-01-29  
**Decision Makers:** Development Team

## Context

After implementing the research pipeline with ResearchAgent and TaskBreakdownAgent, we needed a way to:
1. Assign actors to tasks based on their capabilities
2. Validate the DAG structure for execution readiness
3. Automatically fix common DAG issues
4. Prepare the DAG for actual execution

Without this component, the DAG was just a plan without executable assignments, making it unclear which agent/actor should handle which task.

## Decision

Implemented **TodoCreatorAgent** as a DSPy ReAct orchestrator that:

### Core Capabilities

1. **Actor Assignment**
   - Evaluates all actors for each task using LLM reasoning
   - Considers task type, actor capabilities, and workload balance
   - LLM intelligently matches capabilities to task requirements

2. **Task Collapsing** *(Added 2026-01-31)*
   - Automatically collapses consecutive tasks assigned to the same actor
   - Reduces task overhead and context switching
   - Combines tasks while preserving external dependencies
   - Example: Tasks [1,2,3,4,5] with actors [A,A,A,B,A] → [1_2_3,4,5]
   - See: [consecutive-task-collapsing.md](./consecutive-task-collapsing.md)

3. **DAG Validation**
   - Structural validation: cycles, missing dependencies, orphaned tasks
   - LLM-based semantic validation: feasibility, actor match, execution order
   - Returns clear list of issues with descriptions

4. **Automatic Fixing**
   - Remove circular dependencies (remove_edge)
   - Add missing dependencies (add_edge)
   - Reassign actors for load balancing (reassign_actor)
   - Mark infeasible tasks as skipped (mark_skipped)
   - Iterative fixing (configurable max iterations)

5. **Visualization**
   - Task-actor assignments grouped by actor
   - Shows workload distribution
   - Displays dependencies and task details

### Architecture

```
TodoCreatorAgent (ReAct)
├── ActorAssignmentSignature (CoT)
│   └── Considers: task type, actor capabilities, workload
├── DAGValidationSignature (CoT)
│   └── Checks: cycles, dependencies, assignments
└── DAGFixSignature (CoT)
    └── Applies: remove/add edges, reassign, skip
```

### Key Design Decisions

1. **ReAct Pattern**
   - Chose DSPy ReAct for orchestration (though currently using direct module calls)
   - Allows future expansion with tools for more complex validation

2. **Capability-Based Matching**
   - Defined task type → capability mapping
   - Actors can have multiple capabilities
   - Flexible matching allows one actor to handle multiple task types

3. **Iterative Fixing**
   - Max iterations configurable (default: 5)
   - Validates after each fix iteration
   - Stops when valid or max iterations reached

4. **ExecutableDAG Output**
   - Wraps TaskDAG with assignments
   - Includes validation status and issues
   - Tracks applied fixes for transparency

## Implementation Details

### Actor Class

```python
@dataclass
class Actor:
    name: str
    capabilities: List[str]
    description: Optional[str] = None
    max_concurrent_tasks: int = 1
```

### ExecutableDAG Class

```python
@dataclass
class ExecutableDAG:
    dag: TaskDAG
    assignments: Dict[str, Actor]  # task_id -> Actor
    validation_passed: bool
    validation_issues: List[str]
    fixes_applied: List[str]
```

### Usage Flow

```python
# 1. Define actors
actors = [
    {"name": "CodeMaster", "capabilities": ["coding", "implementation"]},
    {"name": "TestEngineer", "capabilities": ["testing", "validation"]}
]

# 2. Create agent
todo_creator = create_todo_creator_agent(lm=lm)

# 3. Generate executable DAG
# This will:
#   - Assign actors to tasks (Step 1)
#   - Collapse consecutive tasks by same actor (Step 1.5)
#   - Validate DAG structure (Step 2)
executable_dag = todo_creator.create_executable_dag(
    dag=dag,
    available_actors=actors,
    max_fix_iterations=5
)

# 4. Check results
if executable_dag.validation_passed:
    # Ready to execute!
    # Note: DAG may have fewer tasks due to collapsing
    print(f"Collapsed to {executable_dag.dag.total_tasks} tasks")
```

## Consequences

### Positive

1. **Automated Assignment**: No manual task-to-actor mapping needed
2. **Self-Healing**: Automatically fixes common DAG issues
3. **Load Balancing**: Distributes tasks considering actor workload
4. **Transparency**: Clear reporting of issues and fixes
5. **Flexible**: Easy to add new actor types and capabilities
6. **Integration**: Seamlessly fits into research → breakdown → assignment pipeline

### Negative

1. **LLM Dependency**: Requires LLM calls for assignment and validation
2. **Cost**: Multiple LLM calls per task (assignment + validation + fixing)
3. **Fix Limitations**: May not fix all issues within max iterations
4. **Capability Mapping**: Static mapping may not fit all task types

### Mitigation

1. **LLM Cost**: Use smaller models (gpt-4o-mini) for assignment tasks
2. **Fix Iterations**: Make configurable, allow manual intervention if needed
3. **Capability Extension**: Easy to extend `can_handle()` method for custom logic
4. **Caching**: Could cache actor assignments for similar tasks (future)

## Files Created

1. `/Synapse_new/agents/todo_creator_agent.py` - Main agent implementation
2. `/Synapse_new/example_todo_creator.py` - Usage example
3. `/Synapse_new/TODO_CREATOR_GUIDE.md` - Comprehensive documentation
4. Updated `/Synapse_new/README.md` - Added TodoCreator section

## Alternatives Considered

### 1. Simple Rule-Based Assignment
**Pros:** Fast, deterministic, no LLM cost  
**Cons:** No reasoning, poor load balancing, can't handle edge cases  
**Verdict:** ❌ Too rigid for complex workflows

### 2. Manual Assignment
**Pros:** Human oversight, perfect matches  
**Cons:** Slow, error-prone, doesn't scale  
**Verdict:** ❌ Defeats automation purpose

### 3. Reinforcement Learning
**Pros:** Learns optimal assignments over time  
**Cons:** Requires training data, complex, slow  
**Verdict:** ❌ Over-engineered for current needs

### 4. Graph Neural Network
**Pros:** Learns task-actor relationships  
**Cons:** Requires training, not interpretable  
**Verdict:** ❌ Future consideration if LLM costs become prohibitive

## Integration

### Full Pipeline

```
User Query
    ↓
ResearchAgent (ReAct)
    ↓ implementation_plan.txt
TaskBreakdownAgent (CoT)
    ↓ TaskDAG (task_dag.json)
TodoCreatorAgent (ReAct) ← available_actors
    ↓ ExecutableDAG (executable_dag.json)
TaskExecutor (future)
    ↓ Results
```

### Example Commands

```bash
# Run research + breakdown + todo creation
python -m Synapse_new.example_todo_creator

# Generated files:
# - executable_dag.json (full DAG with assignments)
# - actor_assignments.txt (visualization)
# - execution_plan.txt (stage-by-stage plan)
```

## Future Enhancements

1. **Caching**: Cache actor assignments for similar task patterns
2. **Learning**: Track successful assignments to improve future matching
3. **Optimization**: Multi-objective optimization (time, cost, quality)
4. **Constraints**: Support for actor constraints (timezone, cost, availability)
5. **Parallel Assignment**: Assign multiple tasks in parallel for speed
6. **Custom Validators**: Pluggable validation rules for domain-specific checks

## Testing

Basic import and functionality test:
```bash
python3 -c "from Synapse_new import TodoCreatorAgent, Actor, ExecutableDAG; print('✓')"
```

Full integration test:
```bash
python -m Synapse_new.example_todo_creator
```

## References

- Related: `task_breakdown_agent.py` - Generates the input DAG
- Related: `dynamic_task_planner.py` - Inspiration for actor structure
- Pattern: DSPy ReAct orchestration
- Domain: Task assignment, graph validation, automated fixing

## Acceptance Criteria

- [x] Actor class with capability-based matching
- [x] ExecutableDAG with assignments and validation status
- [x] TodoCreatorAgent with assignment, validation, and fixing
- [x] Visualization of task-actor assignments
- [x] Example usage script
- [x] Comprehensive documentation
- [x] Integration with existing pipeline
- [x] Successful import test
- [x] No linter errors
