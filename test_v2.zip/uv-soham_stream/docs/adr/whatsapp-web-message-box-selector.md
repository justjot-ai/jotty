# ADR: WhatsApp Web Message Box Selector (Avoid Search Box)

## Status
Accepted

## Context
When automating "send message to contact on WhatsApp Web", the agent:
1. Opens WhatsApp Web, clicks the search box, types the contact name, presses Enter.
2. Tries to click the **message compose box** (right pane) to type the message.
3. If the specific selector for the message box fails (e.g. `div[contenteditable='true'][data-tab='10']` not found), the agent falls back to a generic selector like `div[contenteditable='true'][role='textbox']`.

WhatsApp Web has **two** contenteditable textboxes:
- **Search box** (left pane): chat list search.
- **Message compose box** (right pane): where you type the actual chat message.

`document.querySelector('div[contenteditable="true"][role="textbox"]')` returns the **first** matching element in DOM order. The left pane (search) often comes before the right pane (main chat), so the first match is the **search box**. The agent then types the full message into the search box and presses Enter—which does not send a chat message. All browser commands report `success: true`, so the system reports "message sent" even though it was never sent.

## Decision
- **Scope the message compose box to the main chat pane** so we never target the search box.
- Prefer selectors that are unique to the right pane, e.g.:
  - `#main div[contenteditable='true'][role='textbox']` (message input inside `#main`)
  - or `#main footer div[contenteditable='true']` if structure uses a footer.
- Do **not** use a global selector like `div[contenteditable='true'][role='textbox']` when the intent is "type in the chat message box" on WhatsApp Web.
- BrowserExecutor prompt is updated to state: for WhatsApp Web message composition, use a selector scoped to `#main` so the message input (right pane) is targeted, not the search box (left pane).

## Consequences
- Reduces false "message sent" when the text was actually typed into search.
- Agent may need to wait for the chat to open (so `#main` contains the conversation) before using the scoped selector.
- If WhatsApp Web changes its DOM (e.g. removes `#main`), the selector may need to be updated.
