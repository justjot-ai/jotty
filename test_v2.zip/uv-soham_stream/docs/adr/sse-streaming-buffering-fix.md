# ADR: SSE Streaming Buffering Fix

## Status
Proposed

## Context
When calling the `/api/v1/perform/stream` endpoint, events are not streamed in real-time. Instead, all events are buffered and sent at once after the task completes (~48 seconds delay observed). This defeats the purpose of Server-Sent Events (SSE) streaming.

## Problem Analysis

### Observed Behavior
```bash
curl --location 'http://localhost:8000/api/v1/perform/stream' \
  --header 'Content-Type: application/json' \
  --data '{"task": "Open whatsapp web"}' \
  --no-buffer -v
```

- Request connects immediately
- Headers are correct (`content-type: text/event-stream`, `X-Accel-Buffering: no`)
- **All data arrives at once after ~48 seconds** (see `{ [4477 bytes data]` in curl output)
- Events should stream progressively, not in bulk

### Root Cause
The issue is in the async generator chain:

1. **Conductor.run()** → yields events (✅ correct)
2. **TaskService.execute_task_stream()** → async for over conductor (✅ correct)
3. **perform.py event_generator()** → async for over task service (✅ correct)
4. **FastAPI StreamingResponse** → async for over event_generator (❌ **buffering here**)

The problem is that **async generators don't automatically flush**. Python's async iteration collects multiple yields before sending them to the ASGI server.

### Why This Happens
- Async generators are lazy and can batch yields for efficiency
- FastAPI/Uvicorn don't force immediate transmission of each yield
- The `yield` in Python async generators doesn't guarantee immediate network transmission
- Need explicit flushing mechanism

## Solution

### Option 1: Add Explicit Flush Points (Recommended)
Add `await asyncio.sleep(0)` after each yield to force event loop to process the yield:

```python
async def event_generator():
    async for event in task_service.execute_task_stream(...):
        event_str = f"data: {json.dumps(event)}\n\n"
        yield event_str.encode('utf-8')
        await asyncio.sleep(0)  # Force flush to client
```

**Pros:**
- Minimal code change
- Forces immediate transmission
- No performance impact (sleep(0) just yields control)

**Cons:**
- Adds extra await in hot path

### Option 2: Use Queue-Based Streaming
Replace async generator with asyncio.Queue for explicit control:

```python
async def event_generator():
    queue = asyncio.Queue()
    
    async def producer():
        async for event in task_service.execute_task_stream(...):
            await queue.put(event)
        await queue.put(None)  # Sentinel
    
    asyncio.create_task(producer())
    
    while True:
        event = await queue.get()
        if event is None:
            break
        yield f"data: {json.dumps(event)}\n\n".encode('utf-8')
```

**Pros:**
- Explicit control over event flow
- Clear separation of producer/consumer

**Cons:**
- More complex code
- Extra task overhead

### Option 3: Use Starlette's BackgroundTask
Let Starlette handle the streaming:

```python
from starlette.background import BackgroundTask

async def stream_events(queue):
    async for event in task_service.execute_task_stream(...):
        await queue.put(event)
    await queue.put(None)

async def event_generator():
    queue = asyncio.Queue()
    background = BackgroundTask(stream_events, queue)
    # ... consume from queue
```

**Pros:**
- Framework-native approach

**Cons:**
- More complex
- Still needs queue

## Decision
**Use Option 1** - Add `await asyncio.sleep(0)` after each yield.

This is the simplest, most direct fix that forces the async event loop to process each yield immediately.

## Implementation

### Files to Modify
1. `/Users/anshulchauhan/Tech/term/uv/src/uv/api/v1/perform.py`
   - Add `await asyncio.sleep(0)` in both `event_generator()` functions

### Changes

```python
# In perform_task_stream() and perform_task()
async def event_generator():
    import json
    import asyncio  # Add import
    
    try:
        async for event in task_service.execute_task_stream(...):
            event_str = f"data: {json.dumps(event)}\n\n"
            yield event_str.encode('utf-8')
            await asyncio.sleep(0)  # ⚡ FORCE IMMEDIATE FLUSH
    except Exception as e:
        # ... error handling
```

## Testing

### Manual Test
```bash
# Should see events streaming progressively, not all at once
curl -N --location 'http://localhost:8000/api/v1/perform/stream' \
  --header 'Content-Type: application/json' \
  --data '{"task": "Open whatsapp web"}'
```

### Expected Behavior
- Events appear progressively as they're generated
- No 48-second delay before first event
- Each event visible immediately after yield

## Consequences

### Positive
- Real-time streaming works as intended
- Better UX in Electron app (progressive updates)
- Minimal code change
- No performance impact

### Negative
- Extra `await` in hot path (negligible cost)
- Need to remember this pattern for future streaming endpoints

## References
- [FastAPI Streaming Response](https://fastapi.tiangolo.com/advanced/custom-response/#streamingresponse)
- [Python Async Generators](https://peps.python.org/pep-0525/)
- [SSE Specification](https://html.spec.whatwg.org/multipage/server-sent-events.html)
