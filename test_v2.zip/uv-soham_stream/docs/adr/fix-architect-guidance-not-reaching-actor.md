# ADR: Fix Architect Guidance Not Reaching Actor

**Status:** Implemented  
**Date:** 2026-01-31  
**Priority:** CRITICAL  
**Context:** Architect insights were being collected but never delivered to actors

---

## 🚨 **Critical Bug Discovered**

The **Architect pattern was completely broken** - architect insights were being collected but filtered out before reaching actors.

### The Problem

**Flow that was happening:**

1. **Architect explores** (lines 564-574) and generates:
   - 📊 Exploration findings
   - 💡 Recommendations
   - ⚠️  Data quality notes

2. **Insights stored in context** (lines 710-713):
   ```python
   # ✅ FIX: Store injections in context for logging ONLY - DON'T add to kwargs!
   # DSPy modules don't accept these parameters
   if injected_context:
       self.context['_injected_context'] = "\n".join(injected_context)
   if injected_instructions:
       self.context['_injected_instructions'] = "\n".join(injected_instructions)
   ```

3. **Insights filtered out** (lines 1694-1697):
   ```python
   internal_params = {
       '_injected_context',        # ❌ REMOVED!
       '_injected_instructions'    # ❌ REMOVED!
   }
   actor_kwargs = {k: v for k, v in kwargs.items() if k not in internal_params}
   ```

4. **Actor called WITHOUT guidance** (line 1713):
   ```python
   result = await self.actor(**actor_kwargs)  # 💥 No architect insights!
   ```

### Impact

❌ **Architect was completely ineffective**
- Architect explored data sources
- Generated valuable insights and recommendations
- But actors never saw any of it!

❌ **Wasted compute and time**
- Architect LLM calls executed
- Results discarded
- Actors made decisions without guidance

❌ **Lower quality results**
- Actors operated without context
- Missed data quality issues
- Ignored recommendations

---

## Root Cause

The original comment said:

> "DSPy modules don't accept these parameters"

This is **correct** - DSPy modules have specific signatures and don't accept arbitrary keyword arguments. However, the solution was **wrong**:

- ❌ **Wrong:** Store insights in context for "logging only"
- ✅ **Right:** Inject insights into the **actual input field** that the actor processes

---

## Solution

### Inject Guidance into Input Field

Instead of passing architect insights as separate parameters, we **enhance the input field** with the guidance:

```python
# Find which input field the actor uses
input_key = None
for key in ['question', 'query', 'goal', 'task', 'input']:
    if key in kwargs:
        input_key = key
        break

if input_key:
    original_input = kwargs[input_key]
    
    # Prepend architect guidance to the input
    guidance_parts = []
    if injected_context:
        guidance_parts.append("\n".join(injected_context))
    if injected_instructions:
        guidance_parts.append("\n".join(injected_instructions))
    
    if guidance_parts:
        architect_guidance = "\n\n".join(guidance_parts)
        enhanced_input = f"{architect_guidance}\n\n---\n\n{original_input}"
        kwargs[input_key] = enhanced_input
        logger.info(f"💡 Injected architect guidance into '{input_key}' field")
```

### Example Enhancement

**Original Input:**
```
Analyze the sales data for Q4 2025
```

**Enhanced Input (with BOTH Architect guidance AND Learned instructions):**
```
📊 Architect Exploration Findings:
- Dataset contains 1,234 records spanning Oct-Dec 2025
- Sales data includes 3 product categories across 5 regions

💡 Architect Recommendations:
- Focus on regional comparisons to identify growth opportunities
- Consider seasonal trends in Q4 (holiday season impact)

⚠️  Data Quality Notes:
- 12 records have missing region data - may need imputation
- Product category "Other" accounts for only 0.3% of sales

---

📚 Learned Instructions from Previous Episodes:
LEARNED: Always check for timezone consistency in date columns
LEARNED: Validate numeric ranges before aggregation to catch outliers
LEARNED: Include confidence intervals when presenting statistical results

---

Analyze the sales data for Q4 2025
```

### Injection Ordering

The enhancements are applied in this order:

1. **Line 440:** `_inject_learned_instructions()` - Historical lessons from previous episodes
2. **Lines 445-700:** Architect runs - Generates current episode guidance
3. **Lines 708-742:** Architect guidance injection - Current episode context

**Final Structure:**
```
[Architect Guidance - Current Episode]
---
[Learned Instructions - Historical Wisdom]
---
[Original Input]
```

This ordering is optimal:
- ✅ Most current/relevant guidance first (architect)
- ✅ Historical lessons second (learned instructions)  
- ✅ Original task last (clear separation)

---

## Benefits

### ✅ Architect Guidance Actually Works Now

Actors receive the context and recommendations the Architect provides.

### ✅ Compatible with DSPy

By injecting into the input field (not as separate params), DSPy modules accept it naturally.

### ✅ Better Decision Making

Actors have full context:
- What data is available
- Data quality issues to watch for
- Recommended approaches
- Potential pitfalls

### ✅ No Wasted Compute

Architect LLM calls now have impact - their insights are used.

### ✅ Improved Result Quality

With architect guidance, actors:
- Make better-informed decisions
- Avoid known data quality issues
- Follow recommended approaches
- Handle edge cases properly

---

## Implementation Details

### Input Field Detection

We check for common input field names in order:

```python
for key in ['question', 'query', 'goal', 'task', 'input']:
    if key in kwargs:
        input_key = key
        break
```

This handles different actor signatures:
- `question` - QA agents
- `query` - Search/retrieval agents  
- `goal` - Goal-oriented agents
- `task` - Task executors
- `input` - Generic agents

### Guidance Format

```
{architect_context}

{architect_instructions}

---

{original_input}
```

The `---` separator makes it clear where guidance ends and the original task begins.

### Fallback Behavior

If no recognized input field is found:
```python
logger.warning("⚠️  Could not inject architect guidance - no recognized input field found")
```

The actor still executes (without guidance) rather than failing.

### Logging

We still log the guidance to context for debugging:
```python
if injected_context:
    self.context['_injected_context'] = "\n".join(injected_context)
if injected_instructions:
    self.context['_injected_instructions'] = "\n".join(injected_instructions)
```

But now it's **also** injected into the actor's input.

---

## Testing

### Manual Verification

Check logs for:
```
💡 Injected architect guidance into 'task' field (234 chars)
```

### Actor Input Inspection

If using debug mode, print `kwargs[input_key]` to verify guidance is present.

### Result Quality

Compare actor outputs before/after fix:
- Actors should make better decisions
- Fewer data quality issues missed
- Better handling of edge cases

---

## Files Changed

### `Synapse/core/synapse_core.py`

#### Fix 1: Architect Guidance Injection (Lines 708-743)

**Before:**
```python
# Store injections in context for logging ONLY - DON'T add to kwargs!
if injected_context:
    self.context['_injected_context'] = "\n".join(injected_context)
if injected_instructions:
    self.context['_injected_instructions'] = "\n".join(injected_instructions)
```

**After:**
```python
# Inject architect guidance into the actor's input field
if injected_context or injected_instructions:
    # Store in context for logging
    ...
    
    # Find which input field the actor uses
    input_key = None
    for key in ['question', 'query', 'goal', 'task', 'input']:
        if key in kwargs:
            input_key = key
            break
    
    if input_key:
        # Prepend architect guidance to the input
        ...
        enhanced_input = f"{architect_guidance}\n\n---\n\n{original_input}"
        kwargs[input_key] = enhanced_input
```

#### Fix 2: Learned Instructions Injection (Lines 1503-1535)

**Before:**
```python
def _inject_learned_instructions(self, kwargs: Dict) -> Dict:
    instructions = []
    for source in ['actor', 'architect', 'auditor']:
        for inst in self.learned_instructions[source]:
            instructions.append(f"LEARNED: {inst}")
    
    if instructions:
        # Store in context, NOT in kwargs!
        self.context['_learned_instructions'] = "\n".join(instructions)
    
    return kwargs  # Return unchanged!
```

**After:**
```python
def _inject_learned_instructions(self, kwargs: Dict) -> Dict:
    instructions = []
    for source in ['actor', 'architect', 'auditor']:
        for inst in self.learned_instructions[source]:
            instructions.append(f"LEARNED: {inst}")
    
    if instructions:
        # Store in context for logging
        learned_text = "\n".join(instructions)
        self.context['_learned_instructions'] = learned_text
        
        # Also inject into input field
        input_key = None
        for key in ['question', 'query', 'goal', 'task', 'input']:
            if key in kwargs:
                input_key = key
                break
        
        if input_key:
            learned_section = f"📚 Learned Instructions:\n{learned_text}"
            enhanced_input = f"{learned_section}\n\n---\n\n{original_input}"
            kwargs[input_key] = enhanced_input
    
    return kwargs
```

---

## Related Issues

### Same Bug in Learned Instructions

The **same pattern** was found in `_inject_learned_instructions()`:

**Before:**
```python
if instructions:
    # Store in context, NOT in kwargs!
    self.context['_learned_instructions'] = "\n".join(instructions)

return kwargs  # Return unchanged!
```

**After:**
```python
if instructions:
    # Store in context for logging
    learned_text = "\n".join(instructions)
    self.context['_learned_instructions'] = learned_text
    
    # Also inject into input field
    input_key = None
    for key in ['question', 'query', 'goal', 'task', 'input']:
        if key in kwargs:
            input_key = key
            break
    
    if input_key:
        learned_section = f"📚 Learned Instructions from Previous Episodes:\n{learned_text}"
        enhanced_input = f"{learned_section}\n\n---\n\n{original_input}"
        kwargs[input_key] = enhanced_input
        logger.info(f"📚 Injected {len(instructions)} learned instructions")

return kwargs
```

Now actors receive both:
- 💡 Architect guidance (current episode)
- 📚 Learned instructions (from previous episodes)

### Impact

This bug may have contributed to:
- Suboptimal actor decisions
- Data quality issues going unnoticed
- Architect recommendations being ignored
- Higher retry rates due to lack of guidance
- **Actors repeating mistakes** (learned instructions not applied)

---

## Future Enhancements

### 1. Smarter Injection Strategy

Different formats for different actor types:
- QA agents: Add to context section
- Code agents: Add as comments
- Task planners: Add as constraints

### 2. Guidance Compression

If architect guidance is very long, summarize key points:
```python
if len(architect_guidance) > MAX_GUIDANCE_LENGTH:
    architect_guidance = compress_guidance(architect_guidance)
```

### 3. Selective Injection

Allow actors to specify which guidance they want:
```python
class MyActor:
    guidance_preferences = {
        'context': True,
        'recommendations': True,
        'data_quality': False  # I handle this myself
    }
```

### 4. Guidance Effectiveness Tracking

Track whether architect guidance improved outcomes:
```python
self.metrics['architect_guidance_impact'] = {
    'with_guidance': success_rate_with,
    'without_guidance': success_rate_without,
    'improvement': improvement_percentage
}
```

---

## Lessons Learned

### ❌ Don't Collect Data You Don't Use

If architect insights aren't reaching actors, **don't run the architect**. It wastes compute and time.

### ❌ "Logging Only" Is a Red Flag

If something is valuable enough to collect, it's valuable enough to use.

### ✅ Enhance Input Fields for DSPy Compatibility

When DSPy modules have strict signatures, enhance the **input content** rather than adding parameters.

### ✅ Verify End-to-End Flow

Test that data flows all the way through:
1. Architect generates guidance ✓
2. Guidance stored in context ✓
3. **Guidance reaches actor** ← This was missing!

---

## Summary

**Critical bug:** Architect insights AND learned instructions were collected but never delivered to actors due to incorrect "DSPy compatibility" workaround.

**Fix:** Inject both architect guidance and learned instructions directly into the actor's input field (question/query/task/etc) instead of trying to pass as separate parameters.

**Impact:** 
- ✅ Architect pattern now actually works - actors receive guidance, context, and data quality warnings
- ✅ Learned instructions now applied - actors benefit from previous episodes' lessons
- ✅ Better decision making with full context from both sources

---

## Verification

After this fix, you should see in logs:

```
💡 Injected architect guidance into 'task' field (234 chars)
📚 Injected 3 learned instructions into 'task' field
```

And actors should make better-informed decisions with:
- 💡 Current architect guidance (exploration findings, recommendations, data quality notes)
- 📚 Learned instructions from previous episodes (accumulated wisdom)
