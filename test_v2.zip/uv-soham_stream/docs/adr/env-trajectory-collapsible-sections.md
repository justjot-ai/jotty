# ADR: Collapsible Trajectory Sections in env.md

**Status:** Implemented  
**Date:** 2026-01-31  
**Context:** User reported that trajectory information in `env.md` was not being collapsed, making the file verbose and hard to read.

## Problem

The `env.md` file tracks environment context and agent trajectories. Previously, all trajectory information (ReAct steps, attempts, observations) was written in full detail without any collapsing mechanism. The file was growing verbose but not reaching the 20MB threshold needed to trigger auto-summarization.

### Root Cause

In `Synapse/core/synapse_core.py` (lines 823-866), trajectory information was added with the comment "NO TRUNCATION - let auto-summarization handle compression". However:

1. **Auto-summarization threshold too high**: EnvironmentManager was configured to only summarize when file exceeds 20MB
2. **Typical files stay below threshold**: Most sessions produce files around 10-100KB
3. **No visual collapsing**: All detailed trajectory steps were always expanded

This resulted in `env.md` files with hundreds of lines of expanded trajectory details that were difficult to navigate.

**Note:** Threshold has now been lowered to 10KB (from 20MB) to trigger summarization more frequently.

## Solution

Applied a two-part solution:

### Part 1: Collapsible Sections
Added HTML `<details>` tags to create collapsible sections for:

1. **Attempt details**: Wrapped in `<details><summary>📋 Show attempt details</summary>`
2. **ReAct trajectory details**: Wrapped in `<details><summary>🔍 Show ReAct trajectory details</summary>`

### Part 2: Lower Summarization Threshold
Reduced auto-summarization threshold from **20MB → 10KB**:

- Old: `env_max_size_bytes = 20_971_520` (20MB) - rarely triggered
- New: `env_max_size_bytes = 10_240` (10KB) - triggers frequently
- Also reduced `min_lines_before_summarize` from 100 → 50 lines

### Changes Made

**File:** `Synapse/core/synapse_core.py`

- Added `<details>` and `<summary>` HTML tags around verbose trajectory content
- Kept high-level summary visible (total attempts, ReAct steps count)
- Full details are collapsed by default but expandable on demand

### Benefits

✅ **Improved readability**: env.md files are now much more scannable  
✅ **Automatic compression**: Files now auto-summarize at 10KB instead of 20MB  
✅ **Faster context refresh**: More frequent summarization keeps context relevant  
✅ **Backward compatible**: Works with all markdown viewers that support HTML  
✅ **Preserves full information**: All details still available when needed  
✅ **No data loss**: Full trajectory information still logged for summarization  
✅ **Better UX**: Users can expand sections they care about

## Implementation Details

### Collapsible HTML Sections

**File:** `Synapse/core/synapse_core.py`

```markdown
🎯 **Action Trajectory** (Agent: BrowserExecutor)
  - Total attempts: 11
<details>
<summary>📋 Show attempt details</summary>

    #1: exploratory | Tool: initialize_browser | Status: uncertain | Output: {...}
    #2: exploratory | Tool: navigate_to_url | Status: uncertain | Output: {...}
    ...
</details>
  - ReAct steps: 14
<details>
<summary>🔍 Show ReAct trajectory details</summary>

    Step 1 Thought: I need to start by initializing...
    Step 1 Observation: {...}
    ...
</details>
  - Output fields: trajectory, reasoning, analysis, plan, commands
```

### Auto-Summarization Threshold

**File:** `Synapse/core/environment_manager.py`

```python
# Old (rarely triggered)
self.max_size_before_summarize = getattr(config, 'env_max_size_bytes', 20_971_520)  # 20MB
self.min_lines_before_summarize = getattr(config, 'env_min_lines', 100)

# New (triggers frequently for typical sessions)
self.max_size_before_summarize = getattr(config, 'env_max_size_bytes', 10_240)  # 10KB
self.min_lines_before_summarize = getattr(config, 'env_min_lines', 50)
```

**Impact:**
- Auto-summarization now triggers after ~50-100 lines of trajectory
- Typical sessions will see 2-5 summarizations instead of never
- LLM-based CoT summarization keeps context fresh and relevant

## Alternatives Considered

1. **Lower summarization threshold**: ✅ **CHOSEN** - Now triggers at 10KB. Accepted trade-off of more frequent LLM calls for better context management
2. **Truncate trajectory**: Would lose valuable debugging information
3. **Separate files**: Would complicate environment tracking and context management
4. **Disable trajectory logging**: Would remove valuable execution history
5. **Only use collapsible sections without lowering threshold**: Would help readability but not address file growth

## Future Enhancements

- Consider adding configurable option to control detail level
- Add metrics about collapsed section sizes
- Implement progressive disclosure (show first N items, collapse rest)

## Testing

- Verified markdown renders correctly with collapsible sections
- Confirmed full trajectory data still available when expanded
- Tested auto-summarization still works with HTML tags
- Validated backward compatibility with existing env.md files
