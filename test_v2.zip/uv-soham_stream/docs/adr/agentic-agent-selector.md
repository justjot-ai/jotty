# ADR: Agentic Agent Selector for Intelligent Task Routing

**Date:** 2026-01-10  
**Status:** Accepted  
**Context:** Synapse Conductor

## Problem

The `Conductor._initialize_todo_from_goal()` method was creating subtasks for **ALL enabled agents** regardless of the task type:

```python
# BEFORE (Bug)
for i, (name, config) in enumerate(self.actors.items()):
    if config.enabled:
        self.todo.add_task(task_id=f"{name}_main", ...)
```

This meant a simple git task like "find lost changes and merge to master" would create 6 sequential tasks:
- CodeMaster_main → DataMind_main → SysOps_main → SecureSentry_main → ScienceCore_main → DomainExpert_main

When only **CodeMaster** was needed.

## Decision

Implement **AgenticAgentSelector** - an LLM-based agent selection mechanism that analyzes the goal and selects only relevant agents.

### Components Added

1. **`AgenticAgentSelector`** class in `tool_shed.py`:
   - Uses DSPy ChainOfThought with `AgentSelectionSignature`
   - Takes goal + available agents with descriptions
   - Returns selected agents + reasoning

2. **Updated `_initialize_todo_from_goal()`** in `conductor.py`:
   - Extracts agent descriptions from config/docstrings
   - Calls AgenticAgentSelector to determine relevant agents
   - Creates tasks only for selected agents
   - Maintains proper dependencies among selected agents

3. **`_get_agent_description()`** helper:
   - Extracts description from config.metadata
   - Falls back to class docstring
   - Has default descriptions for known agent types

## Consequences

### Positive
- Single-domain tasks only invoke relevant agent(s)
- Reduced token usage and latency
- More accurate task routing
- Maintains multi-agent capability for complex tasks

### Negative
- Additional LLM call for agent selection (minimal overhead)
- Requires good agent descriptions for accurate selection

## Example

**Before (Bug):**
```json
{
  "subtasks": {
    "CodeMaster_main": { "status": "completed" },
    "DataMind_main": { "status": "pending" },
    "SysOps_main": { "status": "pending" },
    "SecureSentry_main": { "status": "pending" },
    "ScienceCore_main": { "status": "pending" },
    "DomainExpert_main": { "status": "pending" }
  }
}
```

**After (Fixed):**
```json
{
  "subtasks": {
    "CodeMaster_main": { "status": "pending" }
  }
}
```

## Files Changed

- `Synapse/core/tool_shed.py` - Added `AgenticAgentSelector` class
- `Synapse/core/conductor.py` - Updated `_initialize_todo_from_goal()` method

---

## Related Fix: DSPy ReAct `finish` Tool KeyError

### Problem
DSPy ReAct throws `KeyError: 'finish'` when agent tries to complete a task.

DSPy ReAct adds a built-in `finish` tool in `__init__`:
```python
tools["finish"] = Tool(func=lambda: "Completed.", name="finish", ...)
```

But Surface agents were **overwriting** the tools dict, losing `finish`:
```python
self.generate.tools = self._create_bound_tools()  # ← Overwrites, loses 'finish'
```

### Solution
Preserve DSPy's `finish` tool when updating the tools dict:

```python
new_tools = self._create_bound_tools()
if hasattr(self.generate, 'tools') and 'finish' in self.generate.tools:
    new_tools['finish'] = self.generate.tools['finish']
self.generate.tools = new_tools
```

### Files Changed
- `surface/src/surface/agents/base_agent.py`:
  - Fixed `forward()` method to preserve `finish` tool
  - Fixed `astream()` method to preserve `finish` tool
  - Fixed `restore_tools()` method to preserve `finish` tool
