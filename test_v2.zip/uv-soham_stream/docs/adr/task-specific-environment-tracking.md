# Task-Specific Environment Tracking

**Status**: Fix in Progress  
**Date**: 2026-01-31  
**Context**: Environment files should be per-task, not global

## Problem

Environment context (`env.md`) is being written to a **global file** instead of **task-specific files**. This causes:

1. **Context Mixing**: Different tasks append to the same file
2. **Lost History**: Previous task's environment overwrites current
3. **Confusion**: Can't tell which environment belongs to which task
4. **Artifacts Broken**: UI can't show task-specific environment

### Current Behavior (Broken)

```
outputs/synapse_state/env/env.md  ← All tasks append here (WRONG!)

Task 1 execution → Appends to env.md
Task 2 execution → Appends to env.md  (mixes with Task 1)
Task 3 execution → Appends to env.md  (mixes with Task 1 & 2)
```

### Expected Behavior (Correct)

```
synapse_outputs/
├── run_20260131_161220/
│   └── synapse_state/
│       └── env/
│           └── env.md  ← Task 1's environment
├── run_20260131_161600/
│   └── synapse_state/
│       └── env/
│           └── env.md  ← Task 2's environment
└── run_20260131_162000/
    └── synapse_state/
        └── env/
            └── env.md  ← Task 3's environment
```

## Root Cause

The EnvironmentManager initialization happens in the wrong order:

```python
# conductor.py - Current (WRONG ORDER)
def __init__(...):
    # 1. EnvironmentManager created FIRST
    self.env_manager = EnvironmentManager(config)
    #    ↳ Uses fallback: outputs/synapse_state/env (GLOBAL!)
    
    # 2. Session created LATER
    self.persistence_manager = SessionManager(config)
    #    ↳ Creates: synapse_outputs/run_20260131_161600/
    
    # 3. Try to update EnvironmentManager path (TOO LATE!)
    self.env_manager.env_dir = new_path
    #    ↳ But env.md already created in wrong location!
```

## Solution

### 1. Backend: Read from Run-Specific Directory

Updated `/api/artifacts` endpoint to prioritize run-specific environment:

```python
# Check synapse_outputs/latest/synapse_state/env/ FIRST
latest_run = project_root / "synapse_outputs" / "latest"
if latest_run.exists():
    run_env_dir = latest_run / "synapse_state" / "env"
    # Read env.md from THIS run (task-specific)

# Fallback to global outputs/synapse_state/env/ (deprecated)
```

### 2. Conductor: Fix Initialization Order

The proper fix is in `Synapse/core/conductor.py`:

```python
def __init__(...):
    # 1. Create session FIRST
    if config.create_run_folder:
        self.persistence_manager = SessionManager(config)
        self.synapse_dir = self.persistence_manager.synapse_dir
        
        # 2. Set config.synapse_dir BEFORE creating EnvironmentManager
        config.synapse_dir = self.synapse_dir
    
    # 3. NOW create EnvironmentManager with correct path
    self.env_manager = EnvironmentManager(config)
    #    ↳ Will use: synapse_outputs/run_TIMESTAMP/synapse_state/env/
```

### 3. UI: Show Run-Specific Environment

Frontend prioritizes run-specific environment:

```javascript
// artifacts.env_files array ordered by:
// 1. run_specific: true  (latest run's env.md)
// 2. run_specific: false (global env.md - deprecated)

displayEnvContext(envFiles) {
  // Use first file (run-specific)
  const runEnv = envFiles.find(f => f.run_specific);
  const envMd = runEnv || envFiles[0];
  // Parse and display
}
```

## Implementation Status

### ✅ Completed

1. **Backend API** - Reads from both locations, prioritizes run-specific
2. **Frontend Display** - Shows run-specific environment when available
3. **Documentation** - ADR created

### ⚠️ Pending (Requires Synapse Core Fix)

1. **Conductor Init Order** - Move SessionManager before EnvironmentManager
2. **Config Flow** - Ensure `config.synapse_dir` set before EnvironmentManager init
3. **Global Deprecation** - Remove fallback to `outputs/synapse_state/env/`

## Migration Path

### Phase 1: Dual Support (Current)
- Read from both locations
- Prioritize run-specific
- Allow global as fallback

### Phase 2: Fix Initialization (Next)
- Update Conductor initialization order
- Ensure all new tasks use run-specific paths
- Keep global fallback for old runs

### Phase 3: Deprecate Global (Future)
- Remove global `outputs/synapse_state/env/`
- Only use run-specific paths
- Clean up old global files

## Directory Structure

### Correct Structure (Per-Run)

```
synapse_outputs/
├── latest → run_20260131_162000  (symlink to latest)
├── run_20260131_161220/
│   ├── synapse_state/
│   │   ├── env/
│   │   │   ├── env.md           ← Task 1 environment
│   │   │   └── env_history.json
│   │   ├── q_tables/
│   │   ├── memories/
│   │   └── markovian_todos/
│   ├── logs/
│   ├── results/
│   └── config_snapshot.json
├── run_20260131_161600/
│   └── synapse_state/
│       └── env/
│           └── env.md             ← Task 2 environment (SEPARATE!)
└── run_20260131_162000/
    └── synapse_state/
        └── env/
            └── env.md             ← Task 3 environment (SEPARATE!)
```

### Global Structure (Deprecated)

```
outputs/
└── synapse_state/
    └── env/
        └── env.md  ← All tasks mixed here (DEPRECATED!)
```

## Example: Task Execution

### Task 1: "Hello"
```
Run: synapse_outputs/run_20260131_161220/
Env: synapse_outputs/run_20260131_161220/synapse_state/env/env.md

Content:
# Environment Context
**Goal:** Synapse multi-agent task execution
**Created:** 2026-01-31 16:12:20

## Environment Updates
- Task started: Hello
- Agent: BrowserExecutor selected
- Working directory: /Users/anshul/Tech/term
```

### Task 2: "Search Python"
```
Run: synapse_outputs/run_20260131_161600/
Env: synapse_outputs/run_20260131_161600/synapse_state/env/env.md

Content:
# Environment Context
**Goal:** Synapse multi-agent task execution
**Created:** 2026-01-31 16:16:00

## Environment Updates
- Task started: Search Python
- Agent: WebSearchAgent selected
- Working directory: /Users/anshul/Tech/term
```

**Notice**: Each task has its OWN env.md, not shared!

## Benefits of Task-Specific Environment

### ✅ Clear Separation
- Each task's environment isolated
- No context mixing
- Easy to review specific task's environment

### ✅ Historical Tracking
- Environment preserved per task
- Can review past task environments
- Useful for debugging

### ✅ Artifact Display
- UI shows correct environment for current task
- No confusion about which task's context
- Accurate representation

### ✅ Parallel Execution
- Multiple tasks can run simultaneously
- Each writes to own environment file
- No file contention

## Testing

### Verify Task-Specific Paths

```bash
# Run Task 1
./scripts/run_electron_app.sh
# Enter: "hello"

# Check environment file location
ls -l synapse_outputs/latest/synapse_state/env/env.md
# Should exist in run-specific directory

# Run Task 2
# Enter: "search python"

# Check NEW environment file
ls -l synapse_outputs/latest/synapse_state/env/env.md
# Should be in DIFFERENT run directory

# Verify separation
cat synapse_outputs/run_*/synapse_state/env/env.md
# Each should have different content
```

### Verify UI Display

1. Run task in Electron app
2. Check Environment panel (right sidebar)
3. Verify shows THIS task's environment
4. Not mixed with previous tasks

## Related Files

- `Synapse/core/environment_manager.py` - Environment tracking
- `Synapse/core/conductor.py` - Initialization order (needs fix)
- `Synapse/core/session_manager.py` - Run folder creation
- `surface_synapse/server.py` - Artifact API endpoint
- `electron-app/src/renderer/js/app.js` - Environment display

## Known Issues

### Issue 1: Global Fallback Still Used

**Symptom**: env.md in `outputs/synapse_state/env/` keeps growing

**Cause**: EnvironmentManager initialized before session

**Fix**: Update Conductor initialization order (pending)

### Issue 2: Path Update Too Late

**Symptom**: Logs show path update but file already created globally

**Fix**: Set `config.synapse_dir` before EnvironmentManager creation

### Issue 3: UI Shows Mixed Environment

**Symptom**: Environment panel shows content from multiple tasks

**Cause**: Reading from global file instead of run-specific

**Fix**: API now prioritizes run-specific (✅ done)

## Future Enhancements

1. **Environment Diff** - Show what changed between tasks
2. **Environment Timeline** - Visual timeline of environment updates
3. **Environment Export** - Export specific task's environment
4. **Environment Search** - Search across all task environments
5. **Environment Compare** - Compare environments of different tasks

## Success Criteria

✅ **Each task has own env.md**  
✅ **No context mixing between tasks**  
✅ **UI shows task-specific environment**  
✅ **Historical environments preserved**  
⚠️ **Global path deprecated** (pending Conductor fix)  

## Conclusion

Task-specific environment tracking ensures clean separation of context between different task executions. The backend API fix allows the UI to display correct task-specific environments. The final fix requires updating Conductor initialization order to create environments in the correct location from the start.

**Current Status**: ✅ **API Fixed**, ⚠️ **Conductor Fix Pending**
