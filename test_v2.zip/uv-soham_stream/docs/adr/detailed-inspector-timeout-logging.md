# ADR: Detailed Inspector Timeout Logging

**Date:** 2026-01-31  
**Status:** Implemented

## Context

The Inspector Agent was timing out during validation (TimeoutError), but there was insufficient logging to identify which step was causing the delay:
- Was it the LLM API call?
- Was it DSPy's internal processing?
- Was it tool calls during ReAct iterations?
- Was it data serialization/preparation?

## Decision

Added comprehensive logging throughout the inspector validation pipeline to track:

1. **Input size logging** - Track how much data is being sent
2. **Step-by-step execution logging** - 4 phases of the LLM call
3. **DSPy LM API call logging** - Wrap the LM to log actual API timing
4. **ReAct iteration logging** - Track each ReAct iteration and tool call
5. **Increased timeout** - From 180s (3 min) to 300s (5 min)

## Changes

### 1. Inspector Input Size Logging (`Synapse/core/inspector.py`)

```python
# Log input sizes before LLM call
input_sizes = {}
total_input_chars = 0
for key, value in full_inputs.items():
    if isinstance(value, str):
        size = len(value)
        input_sizes[key] = size
        total_input_chars += size
    elif isinstance(value, list):
        size = sum(len(str(item)) for item in value)
        input_sizes[key] = f"{len(value)} items, {size} chars"
        total_input_chars += size
logger.info(f"    📊 [INPUT SIZES] total_chars={total_input_chars:,} | breakdown={input_sizes}")
```

### 2. Step-by-Step Execution Logging (`Synapse/core/inspector.py`)

```python
logger.info(f"    🔄 [STEP 1/4] Preparing to call DSPy agent...")

def instrumented_agent_call():
    logger.info(f"    🔄 [STEP 2/4] Inside thread, calling self.agent with {len(full_inputs)} inputs...")
    thread_start = time.time()
    result = self.agent(**full_inputs)
    thread_duration = time.time() - thread_start
    logger.info(f"    ✅ [STEP 3/4] Agent call completed in thread | duration={thread_duration:.3f}s")
    return result

logger.info(f"    🔄 [STEP 4/4] Executing in thread with timeout={timeout_seconds}s...")
result = await asyncio.wait_for(
    asyncio.to_thread(instrumented_agent_call),
    timeout=timeout_seconds
)
```

### 3. DSPy LM API Call Logging (`surface_synapse/integration.py`)

```python
# Wrap LM to track API call timing
original_call = lm.__call__
def logged_call(*args, **kwargs):
    api_start = time.time()
    logger.info(f"    🌐 [API CALL START] model={model_name} | args_count={len(args)} | kwargs_keys={list(kwargs.keys())}")
    try:
        result = original_call(*args, **kwargs)
        api_duration = time.time() - api_start
        logger.info(f"    ✅ [API CALL COMPLETE] duration={api_duration:.3f}s | model={model_name}")
        return result
    except Exception as e:
        api_duration = time.time() - api_start
        logger.error(f"    ❌ [API CALL FAILED] duration={api_duration:.3f}s | error={str(e)[:200]}")
        raise
lm.__call__ = logged_call
```

### 4. ReAct Iteration & Tool Call Logging (`Synapse/core/inspector.py`)

```python
# Wrap ReAct agent to log iterations
original_forward = react_agent.forward
def logged_forward(*args, **kwargs):
    logger.info(f"    🔄 [REACT START] agent={self.agent_name} | max_iters={config.max_eval_iters}")
    
    # Wrap tools to log each call
    if hasattr(react_agent, 'tools') and react_agent.tools:
        for tool in react_agent.tools:
            if hasattr(tool, 'func'):
                original_tool = tool.func
                def make_logged_tool(orig_func, tool_name):
                    def logged_tool(*tool_args, **tool_kwargs):
                        tool_start = time.time()
                        logger.info(f"      🔧 [TOOL CALL] {tool_name}")
                        result = orig_func(*tool_args, **tool_kwargs)
                        tool_duration = time.time() - tool_start
                        logger.info(f"      ✅ [TOOL COMPLETE] {tool_name} | duration={tool_duration:.3f}s")
                        return result
                    return logged_tool
                tool.func = make_logged_tool(original_tool, tool.__name__ if hasattr(tool, '__name__') else str(tool))
    
    result = original_forward(*args, **kwargs)
    logger.info(f"    ✅ [REACT COMPLETE] agent={self.agent_name}")
    return result

react_agent.forward = logged_forward
```

## Expected Log Output

With these changes, logs will now show:

```
📊 [INPUT SIZES] total_chars=21,847 | breakdown={'task': 418, 'context': 21429}
🔄 [STEP 1/4] Preparing to call DSPy agent...
🔄 [STEP 4/4] Executing in thread with timeout=300.0s...
🔄 [STEP 2/4] Inside thread, calling self.agent with 2 inputs...
🔄 [REACT START] agent=terminalexecutor_agent | max_iters=10
🌐 [API CALL START] model=azure/gpt-4o-mini | args_count=1 | kwargs_keys=['messages']
✅ [API CALL COMPLETE] duration=2.456s | model=azure/gpt-4o-mini
🔧 [TOOL CALL] execute_command
✅ [TOOL COMPLETE] execute_command | duration=0.234s
🌐 [API CALL START] model=azure/gpt-4o-mini | args_count=1 | kwargs_keys=['messages']
✅ [API CALL COMPLETE] duration=3.123s | model=azure/gpt-4o-mini
✅ [REACT COMPLETE] agent=terminalexecutor_agent
✅ [STEP 3/4] Agent call completed in thread | duration=5.813s
⏱️ [INSPECTOR LLM COMPLETE] duration=5.820s | agent=terminalexecutor_agent
```

## Benefits

1. **Identify bottlenecks** - See exactly which step is slow
2. **Debug API issues** - Track API call timing separately
3. **Monitor tool usage** - See which tools are being called and how long they take
4. **Track input size** - Identify if large inputs are causing issues
5. **Prevent timeouts** - 5-minute timeout gives more headroom

## Important Note

**The process must be restarted** to pick up these changes. The log file showing `timeout=180.0s` was from before these changes were applied.

To restart:
1. Stop the electron app (Ctrl+C in terminal 41)
2. Run `./scripts/run_electron_app.sh` again
3. New logs will show `timeout=300.0s` and detailed step logging
