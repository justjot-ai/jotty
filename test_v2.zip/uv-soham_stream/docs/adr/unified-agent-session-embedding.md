# ADR: Unified Agent Session Embedding Architecture

**Status:** Accepted  
**Date:** 2026-02-01  
**Deciders:** Architecture Team (A-Team Review)  
**Context:** Embed ALL agent sessions (Browser, Terminal, WebSearch, Planner) in Electron UI with seamless, identical approach  

---

## Context

User wants to see ALL agent activities in the Electron UI with a unified, consistent experience.

**Requirements:**
- Replace system logs with agent session views
- Show BrowserExecutor, TerminalExecutor, WebSearchAgent, PlannerAgent activities
- Seamless, identical approach for all agents
- Real-time updates
- Professional UI

---

## Decision

**Implement unified Agent Session Manager (backend) + Agent View Manager (frontend) architecture with standardized WebSocket protocol for all agents.**

---

## Architecture

### **Unified Backend: Agent Session Manager**

```python
class AgentSessionManager:
    """Centralized manager for all agent sessions."""
    
    async def broadcast_agent_event(
        self,
        agent_type: AgentType,
        event_type: str,
        data: Dict[str, Any]
    ):
        """Unified event broadcasting for all agents."""
        await self.websocket_manager.broadcast({
            "type": "agent_event",
            "agent": agent_type.value,
            "event_type": event_type,
            "data": data
        })
```

### **Unified Frontend: Agent View Manager**

```javascript
class AgentViewManager {
    constructor() {
        this.views = new Map();
        this.registerAgentHandlers();
    }
    
    handleAgentEvent(event) {
        const { agent, event_type, data } = event;
        const agentView = this.views.get(agent);
        agentView.handler.handleEvent(event_type, data);
    }
}
```

### **Standardized Protocol**

```json
{
  "type": "agent_event",
  "agent": "BrowserExecutor",
  "event_type": "navigate",
  "data": { "url": "https://..." }
}
```

---

## Agent-Specific Implementations

| Agent | Backend Tech | Frontend View | Events |
|-------|-------------|---------------|--------|
| **BrowserExecutor** | Selenium | BrowserView | navigate, action |
| **TerminalExecutor** | pexpect | xterm.js | output, command |
| **WebSearchAgent** | Tavily API | Results Panel | query, results |
| **PlannerAgent** | LLM | Text Panel | plan, step |

---

## Benefits

### **Unified Approach**
- ✅ Single API for all agents
- ✅ Consistent event handling
- ✅ Standardized protocol
- ✅ Easy to add new agents

### **User Experience**
- ✅ See all agent activities
- ✅ Consistent UI across agents
- ✅ Real-time updates
- ✅ Professional interface

### **Developer Experience**
- ✅ Single codebase
- ✅ Centralized state management
- ✅ Easy debugging
- ✅ Maintainable architecture

---

## Implementation

### **Phase 1: Core Infrastructure** (4-5 hours)

**Backend:**
- Create `AgentSessionManager` class
- Implement event broadcasting
- Integrate with WebSocket manager

**Frontend:**
- Create `AgentViewManager` class
- Implement view registration
- Create handler classes

### **Phase 2: Agent Views** (6-8 hours)

**BrowserExecutor:**
- Electron BrowserView integration
- URL synchronization
- Event handling

**TerminalExecutor:**
- xterm.js integration
- Output streaming
- Command display

**WebSearchAgent:**
- Results panel
- Query display
- Result rendering

**PlannerAgent:**
- Plan visualizer
- Step tracking
- Status updates

### **Phase 3: Integration** (2-3 hours)

- Testing
- Polish
- Error handling
- Documentation

---

## Technical Details

### **Backend: Agent Session Manager**

```python
# surface_synapse/agent_session_manager.py

from enum import Enum
from typing import Dict, Any

class AgentType(Enum):
    BROWSER = "BrowserExecutor"
    TERMINAL = "TerminalExecutor"
    WEBSEARCH = "WebSearchAgent"
    PLANNER = "PlannerAgent"

class AgentSessionManager:
    def __init__(self, websocket_manager):
        self.websocket_manager = websocket_manager
        self.active_agents = {}
    
    async def register_agent(self, agent_type: AgentType, agent_id: str):
        self.active_agents[agent_id] = agent_type
        await self.websocket_manager.broadcast({
            "type": "agent_registered",
            "agent": agent_type.value,
            "agent_id": agent_id
        })
    
    async def broadcast_agent_event(
        self,
        agent_type: AgentType,
        event_type: str,
        data: Dict[str, Any]
    ):
        await self.websocket_manager.broadcast({
            "type": "agent_event",
            "agent": agent_type.value,
            "event_type": event_type,
            "data": data
        })
```

### **Frontend: Agent View Manager**

```javascript
// electron-app/src/renderer/js/agent-view-manager.js

class AgentViewManager {
    constructor() {
        this.views = new Map();
        this.registerAgentHandlers();
    }
    
    registerAgentHandlers() {
        this.views.set('BrowserExecutor', {
            handler: new BrowserViewHandler()
        });
        this.views.set('TerminalExecutor', {
            handler: new TerminalViewHandler()
        });
        this.views.set('WebSearchAgent', {
            handler: new SearchViewHandler()
        });
    }
    
    handleAgentEvent(event) {
        const { agent, event_type, data } = event;
        const agentView = this.views.get(agent);
        if (agentView) {
            agentView.handler.handleEvent(event_type, data);
        }
    }
}
```

---

## WebSocket Protocol

### **Event Types**

**Agent Registration:**
```json
{
  "type": "agent_registered",
  "agent": "BrowserExecutor",
  "agent_id": "browser-001"
}
```

**Agent Event:**
```json
{
  "type": "agent_event",
  "agent": "BrowserExecutor",
  "event_type": "navigate",
  "data": { "url": "https://google.com" }
}
```

**Agent Unregistration:**
```json
{
  "type": "agent_unregistered",
  "agent": "BrowserExecutor",
  "agent_id": "browser-001"
}
```

---

## Security Considerations

### **Low Risk**
- ✅ All views are read-only
- ✅ No user input to agents
- ✅ WebSocket already secured
- ✅ Process isolation maintained

### **Best Practices**
- Event rate limiting
- Input validation
- Error handling
- Logging and monitoring

---

## Performance Impact

| Metric | Current | With Unified System |
|--------|---------|-------------------|
| Agents Visible | 0 | All |
| WebSocket Events | Low | Medium |
| Memory Usage | ~300MB | ~800MB |
| CPU Usage | ~5% | ~10-12% |
| Development Time | 0 | 12-15 hours |

---

## Testing Strategy

### **Unit Tests**
- AgentSessionManager methods
- AgentViewManager methods
- Handler classes

### **Integration Tests**
- Agent registration flow
- Event routing
- View switching

### **E2E Tests**
- Multi-agent scenarios
- Concurrent agents
- Error handling

---

## Success Criteria

- ✅ All agents visible in UI
- ✅ Seamless switching
- ✅ Real-time updates
- ✅ Consistent UI/UX
- ✅ No performance issues
- ✅ Easy to extend
- ✅ Complete in 12-15 hours

---

## Future Enhancements

- Multi-agent view (split-screen)
- Agent history and replay
- Interactive features (pause/resume)
- Analytics dashboard

---

## Related Decisions

- [electron-browserview-true-embedding.md](./electron-browserview-true-embedding.md)
- [A-Team Review: Unified Agent Embedding](../review/A_TEAM_UNIFIED_AGENT_EMBEDDING_PLAN.md)

---

## References

- Electron BrowserView: https://www.electronjs.org/docs/latest/api/browser-view
- xterm.js: https://xtermjs.org/
- WebSocket Protocol: https://developer.mozilla.org/en-US/docs/Web/API/WebSocket

---

## Notes

**Team Consensus:**
- Alex: "Unified architecture is elegant and scalable"
- Jordan: "AgentSessionManager makes integration trivial"
- Casey: "AgentViewManager handles complexity cleanly"
- Morgan: "Secure, maintainable, operationally sound"

**Key Insight:** Instead of separate implementations for each agent, create a unified system with standardized events and consistent UI. This makes adding new agents trivial and provides seamless user experience.

**Decision:** Implement unified architecture for all agents with 12-15 hour timeline.
