# ADR: Complete ANSI Escape Sequence Stripping

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Fix terminal showing raw ANSI escape codes like `[?1034h`

## Problem

The terminal fallback display was showing raw ANSI escape sequences like `[?1034h` instead of stripping them. The original regex only handled color codes (`\x1b[...m`) but not other types of escape sequences.

### Example Issue
```
Output: "The default interactive shell is now zsh.[?1034hbash-3.2$"
                                                   ^^^^^^^^ visible!
```

## Root Cause

The original ANSI stripping regex was too simple:
```javascript
const cleanText = text.replace(/\x1b\[[0-9;]*m/g, '');
```

This only matched:
- `\x1b[` - ESC + [
- `[0-9;]*` - Numbers and semicolons
- `m` - Ending with 'm' (color codes only)

But terminals use many other escape sequences:
- `\x1b[?1034h` - Set mode (h = high)
- `\x1b[?1034l` - Reset mode (l = low)
- `\x1b]0;Title\x07` - Set window title (OSC)
- `\x1b=` - Application keypad mode
- And many more...

## Decision

Implement comprehensive ANSI escape sequence stripping that handles **all** common terminal escape codes.

## Implementation

### New Regex Pattern

```javascript
const cleanText = text
  // CSI sequences: \x1b[...m, \x1b[...h, \x1b[...l, etc.
  .replace(/\x1b\[[0-9;?]*[a-zA-Z]/g, '')
  
  // OSC sequences: \x1b]...\x07 (Operating System Command)
  .replace(/\x1b\][^\x07]*\x07/g, '')
  
  // Other escape sequences: \x1b=, \x1b>
  .replace(/\x1b[=>]/g, '')
  
  // Control characters (except tab, newline, carriage return)
  .replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F]/g, '')
  
  // Normalize line endings
  .replace(/\r\n/g, '\n')
  .replace(/\r/g, '');
```

### Pattern Breakdown

#### 1. CSI Sequences: `\x1b\[[0-9;?]*[a-zA-Z]`
Matches Control Sequence Introducer commands:
- `\x1b[0m` - Reset colors
- `\x1b[31m` - Red color
- `\x1b[?1034h` - Set mode 1034
- `\x1b[2J` - Clear screen
- `\x1b[H` - Move cursor home
- `\x1b[1;32m` - Bold green

**Key addition:** `?` in `[0-9;?]*` to match mode sequences

#### 2. OSC Sequences: `\x1b\][^\x07]*\x07`
Matches Operating System Commands:
- `\x1b]0;Title\x07` - Set window title
- `\x1b]2;Title\x07` - Set icon name

#### 3. Other Escapes: `\x1b[=>]`
Matches special modes:
- `\x1b=` - Application keypad mode
- `\x1b>` - Normal keypad mode

#### 4. Control Characters: `[\x00-\x08\x0B-\x0C\x0E-\x1F]`
Removes non-printable characters except:
- `\x09` (tab)
- `\x0A` (newline)
- `\x0D` (carriage return)

### Additional Improvement

Skip empty lines after cleaning:
```javascript
if (!cleanText.trim()) return;
```

This prevents blank lines from cluttering the terminal.

## Examples

### Before
```
The default interactive shell is now zsh.[?1034hbash-3.2$ 
```

### After
```
The default interactive shell is now zsh.
bash-3.2$
```

## Common ANSI Sequences Handled

| Sequence | Type | Purpose | Now Stripped? |
|----------|------|---------|---------------|
| `\x1b[0m` | CSI | Reset colors | ✅ |
| `\x1b[31m` | CSI | Red color | ✅ |
| `\x1b[?1034h` | CSI | Set mode | ✅ (NEW) |
| `\x1b[?1034l` | CSI | Reset mode | ✅ (NEW) |
| `\x1b[2J` | CSI | Clear screen | ✅ |
| `\x1b[H` | CSI | Cursor home | ✅ |
| `\x1b]0;Title\x07` | OSC | Set title | ✅ (NEW) |
| `\x1b=` | Other | App keypad | ✅ (NEW) |
| `\x1b>` | Other | Normal keypad | ✅ (NEW) |

## Benefits

✅ **Clean output:** No visible escape codes  
✅ **Comprehensive:** Handles all common sequences  
✅ **Readable:** Terminal output is now plain text  
✅ **No clutter:** Empty lines are skipped  

## Trade-offs

⚠️ **No colors:** All formatting is stripped (acceptable for plain text view)  
⚠️ **Regex complexity:** More complex pattern (but well-documented)  

## Testing

Test with various terminal outputs:

```bash
# Test 1: Color codes
echo -e "\x1b[31mRed\x1b[0m Normal"
# Expected: "Red Normal"

# Test 2: Mode sequences
echo -e "Text\x1b[?1034hMore"
# Expected: "Text More"

# Test 3: Title sequences
echo -e "\x1b]0;My Title\x07Text"
# Expected: "Text"

# Test 4: Cursor movements
echo -e "Line1\x1b[HLine2"
# Expected: "Line1 Line2"
```

## Related Files

- `/electron-app/src/renderer/js/agent-view-manager.js` - Terminal handler (line 916)
- `/docs/adr/remove-xterm-use-simple-terminal.md` - Terminal simplification

## References

- [ANSI Escape Codes](https://en.wikipedia.org/wiki/ANSI_escape_code)
- [CSI Sequences](https://en.wikipedia.org/wiki/ANSI_escape_code#CSI_sequences)
- [OSC Sequences](https://invisible-island.net/xterm/ctlseqs/ctlseqs.html#h3-Operating-System-Commands)

## Future Enhancements

- Option to preserve colors (convert ANSI to HTML)
- Configurable stripping level
- Support for 256-color and true-color sequences
