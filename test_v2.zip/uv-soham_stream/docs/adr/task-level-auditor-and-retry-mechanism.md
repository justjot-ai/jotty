# ADR: Task-Level Auditor and Retry Mechanism in Synapse

## Status
Accepted

## Context
Synapse has a built-in task-level auditor that validates task completion, separate from user-provided actor-level auditors. Understanding how this auditor works and how retries are triggered is important for debugging and system behavior.

## Decision

### Task-Level Auditor (Built-in)

**Location**: `Synapse/core/conductor.py::_run_auditor_stream()` (lines 8622-8794)

**Purpose**: Validates task completion using LLM-generated test cases executed in parallel.

**Actions Performed**:

1. **Dynamic Test Generation** (`ParallelTestGenerator`)
   - Uses LLM to generate 3-5 test cases based on task description
   - No hardcoded checklists - all validation is LLM-driven
   - Test cases include: name, expected_output, validation_method, priority

2. **Parallel Test Execution**
   - Executes all generated tests in parallel using `asyncio.gather`
   - Each test uses semantic matching (`LLMTestValidationSignature`)
   - Tests are lenient - focus on task completion, not exact format

3. **Test Result Aggregation** (`HybridTestAggregator`)
   - Aggregates parallel test results into single decision
   - Computes reward (0.0-1.0) and confidence (0.0-1.0)
   - Provides detailed reasoning for pass/fail decision

4. **Validation Decision**
   - Pass criteria: `(reward >= 0.7) and (confidence >= 0.6)`
   - Provides comprehensive feedback with test breakdown
   - Logs all passed/failed tests with LLM reasoning

5. **Feedback Generation**
   - Creates detailed feedback report with:
     - Test aggregation report (X/Y tests passed)
     - Aggregation method and reasoning
     - Individual test results with status and reasoning
     - Summary with reward and confidence

### Retry Mechanism

**Important**: The task-level auditor does NOT directly trigger retries. Retries are handled by separate mechanisms:

#### When Auditor Fails:

1. **Task Marking** (`conductor.py:3791`)
   ```python
   self.todo.fail_task(task.task_id, auditor_feedback)
   ```

2. **Task Status Update** (`roadmap.py:516-522`)
   - If `attempts < max_attempts`: Status set to `PENDING` (retryable)
   - If `attempts >= max_attempts`: Status set to `FAILED` (permanent)

3. **Main Loop Retry** (`conductor.py:3074`)
   - Main loop continues: `while iteration < max_iterations and not all_auditors_passed`
   - Failed tasks with `PENDING` status can be picked up again
   - `get_next_task()` (line 619) selects tasks with `TaskStatus.PENDING`

#### Retry Modules:

1. **Main Execution Loop** (`conductor.py:3074-3990`)
   - Continues iterating until all auditors pass or max iterations
   - Automatically picks up failed tasks that are retryable

2. **Actor Retry Handler** (`conductor.py:_execute_actor_with_retry()` line 7289)
   - Retries actor execution with error context
   - Handles context compression for retries
   - Uses `UniversalRetryHandler` for intelligent retry logic

3. **Feedback Router** (`conductor.py:_route_failure_to_collaborators()` line 3795)
   - Routes auditor feedback to other agents for collaboration
   - Can create new research/collaboration tasks
   - Uses `AgenticFeedbackRouter` for intelligent routing

4. **Dead Letter Queue** (`timeouts.py:DeadLetterQueue`)
   - Stores failed operations for later retry
   - Retries when system recovers
   - Max 3 retry attempts per operation

### Key Differences

| Aspect | Task-Level Auditor | Actor-Level Auditor |
|--------|-------------------|---------------------|
| **Location** | `conductor.py` | `synapse_core.py` |
| **Purpose** | Task completion validation | Actor output quality checks |
| **When Runs** | After task execution | After actor execution |
| **Validation** | LLM-generated parallel tests | User-provided validation prompts |
| **Scope** | Task-level (orchestration) | Actor-level (role-specific) |

## Consequences

### Positive
- Dynamic, LLM-driven validation adapts to different task types
- Parallel test execution is efficient
- Comprehensive feedback helps debugging
- Retry mechanism is robust with multiple fallback strategies

### Negative
- Retry logic is distributed across multiple modules (complexity)
- No direct feedback loop from auditor to retry (indirect via task status)
- Failed tasks may be retried multiple times before permanent failure

## Notes

- The task-level auditor is separate from user-provided actor auditors
- Retries happen automatically through the main loop, not directly triggered by auditor
- Task status (`PENDING` vs `FAILED`) determines retry eligibility
- Multiple retry mechanisms exist for different failure scenarios
