# ADR: Browser File Upload Without Native Dialog

## Status
Accepted

## Date
2026-02-02

## Context

The BrowserExecutor agent was unable to complete file upload tasks (e.g., sending images via WhatsApp Web, attaching files in Gmail/Slack) because:

1. **WhatsApp Web and similar apps** use `<input type="file">` elements that trigger native OS file picker dialogs
2. **Browser automation** (whether Selenium or Electron BrowserView) **cannot interact with native OS dialogs** - they operate only within the browser's DOM
3. The BrowserExecutor **advertised** `file_upload` as a capability but **lacked the actual implementation**

From the logs:
```
[ERROR] I explored every angle I could think of, but I've hit a wall with this one. 
WhatsApp Web needs me to select a file from your computer to send an image, and 
browser automation doesn't have access to download and manage files on your system.
```

## Decision

Implement `electron_upload_file` tool that bypasses the native file picker dialog by:

1. **Reading the file** from the local filesystem using Node.js `fs` module
2. **Converting to base64** for transfer to browser context
3. **Creating a File object** in the browser using the Blob/File API
4. **Setting files on input element** using the DataTransfer API
5. **Dispatching events** (`input`, `change`, `drop`) so the web app receives the file

## Implementation

### 1. Python Tool Function (`browser_tools.py`)

```python
def electron_upload_file(selector: str, file_path: str) -> Dict[str, Any]:
    """Upload a file to input[type=file] without native dialog."""
    return _send_browser_command_sync("upload_file", {
        "selector": selector,
        "filePath": file_path
    }, timeout=60.0)
```

### 2. Electron IPC Handler (`main.js`)

```javascript
ipcMain.handle('browser-upload-file', async (event, { selector, filePath }) => {
  // 1. Read file from disk
  const fileBuffer = fs.readFileSync(filePath);
  const base64Data = fileBuffer.toString('base64');
  
  // 2. Execute in browser context
  await browserView.webContents.executeJavaScript(`
    // Convert base64 to Blob, create File, set on input
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  `);
});
```

### 3. BrowserExecutor Integration (`browser_executor.py`)

- Added `electron_upload_file` to `ELECTRON_TOOLS` list
- Updated system prompt with file upload documentation and examples

## Usage Examples

### WhatsApp Web - Send Image
```python
# Click attachment button to trigger file input
electron_click(selector='[data-icon="attach-menu-plus"]')
# Upload file directly
electron_upload_file('input[type=file]', '/path/to/meme.jpg')
# Click send
electron_click(selector='[data-icon="send"]')
```

### Standard File Upload Form
```python
electron_upload_file('input[name="document"]', '/path/to/file.pdf')
```

## Consequences

### Positive
- **Enables file uploads** in WhatsApp Web, Gmail, Slack, and any other web app
- **No native dialog interaction** - works reliably in automated contexts
- **Works with hidden inputs** - common pattern in modern web apps
- **Supports all file types** with proper MIME type detection
- **Triggers proper events** so web apps receive the file correctly

### Negative
- **File must exist locally** - cannot upload from URLs directly (would need separate download step)
- **Memory usage** - large files are loaded into memory and base64 encoded (2x size)
- **Security considerations** - file paths are passed from Python to Electron

### Mitigations
- Added 60-second timeout for large file operations
- MIME type detection prevents incorrect file handling
- File existence validation before upload attempt

## Supported File Types

| Extension | MIME Type |
|-----------|-----------|
| .jpg/.jpeg | image/jpeg |
| .png | image/png |
| .gif | image/gif |
| .webp | image/webp |
| .pdf | application/pdf |
| .doc/.docx | application/msword |
| .xls/.xlsx | application/vnd.ms-excel |
| .txt | text/plain |
| .csv | text/csv |
| .mp3 | audio/mpeg |
| .mp4 | video/mp4 |

## Files Changed

1. `surface/src/surface/tools/browser_tools.py` - Added `electron_upload_file` function
2. `electron-app/src/main.js` - Added `browser-upload-file` IPC handler
3. `surface/src/surface/agents/browser_executor.py` - Registered tool and updated system prompt

## References

- [DataTransfer API (MDN)](https://developer.mozilla.org/en-US/docs/Web/API/DataTransfer)
- [File API (MDN)](https://developer.mozilla.org/en-US/docs/Web/API/File)
- [Playwright setInputFiles (inspiration)](https://playwright.dev/docs/api/class-filechooser)
