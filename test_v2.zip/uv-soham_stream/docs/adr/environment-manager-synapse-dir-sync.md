# ADR: Environment Manager synapse_dir Synchronization

**Date:** 2026-01-31  
**Status:** Implemented  
**Context:** Bug fix - Environment files writing to wrong directory

## Problem

Environment files (`env.md`) were being written to `outputs/synapse_state/env/` instead of the timestamped run directory (e.g., `synapse_outputs/run_20260131_155119/synapse_state/env/`).

### Root Cause

Timing mismatch in component initialization:

1. **EnvironmentManager** created in `Conductor.__init__()` (line 1239)
   - At this point, `config.synapse_dir` is NOT set
   - Falls back to hardcoded `"outputs/synapse_state/env"`

2. **Persistence Manager (Vault)** created later in `Conductor.solve()` (line 2946)
   - Correctly uses timestamped `output_dir` (e.g., `synapse_outputs/run_20260131_155119`)
   - Sets `self.synapse_dir` internally
   - **Never propagates this to `config.synapse_dir`**

3. Result: EnvironmentManager and Persistence Manager use different directories

## Solution

When Persistence Manager is initialized in `solve()`:

1. **Set `config.synapse_dir`** to `persistence_manager.synapse_dir`
2. **Update EnvironmentManager's paths** if it was already initialized
3. **Migrate existing `env.md`** if it exists at the old location

```python
# Set config.synapse_dir for future components
self.config.synapse_dir = self.persistence_manager.synapse_dir

# Update EnvironmentManager's path if already initialized
if self.env_manager:
    old_env_file = self.env_manager.env_file
    new_env_dir = self.persistence_manager.synapse_dir / "env"
    self.env_manager.env_dir = new_env_dir
    self.env_manager.env_file = new_env_dir / "env.md"
    
    # Migrate existing file if needed
    if old_env_file.exists() and old_env_file != self.env_manager.env_file:
        new_env_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(old_env_file, self.env_manager.env_file)
```

## Benefits

- ✅ All Synapse state files in one timestamped directory
- ✅ Environment context travels with the run
- ✅ Backward compatible (migrates old env files)
- ✅ No breaking changes to other components

## Implementation

**Modified:** `Synapse/core/conductor.py` (lines 2944-2950)

## Testing

Verify that after this fix:
1. `env.md` appears in `synapse_outputs/run_*/synapse_state/env/`
2. All other state files (todos, q_tables, memories) remain in same location
3. Existing env files are migrated if they exist at old location
