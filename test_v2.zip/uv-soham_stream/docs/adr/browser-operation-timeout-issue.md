# ADR: Browser Operation Timeout Issue - Not Caused by TimeBudgetPlanner

**Date:** 2026-02-05  
**Status:** Analysis Complete - Solution Proposed

## Context

User reported timeout issues with BrowserExecutor operations, specifically asking if TimeBudgetPlanner is causing the problem. Analysis of logs and codebase reveals the actual root cause.

## Problem Analysis

### TimeBudgetPlanner Behavior (NOT the cause)
- TimeBudgetPlanner sets actor-level timeout to **120 seconds** for BrowserExecutor (reasonable)
- This is configured at line 390 in logs: `📊 BrowserExecutor: 120.0s`
- Actor-level timeout is properly applied in `conductor.py` line 8241

### Actual Root Cause
Browser operations have **hardcoded 30-second timeouts** in `browser_tools.py`:

1. **ElectronBrowserClient** (line 191):
   ```python
   self._response_timeout = 30.0  # seconds
   ```

2. **Response timeout check** (line 257):
   ```python
   if time.time() - start_time > self._response_timeout:
       return {"success": False, "error": "Command timeout"}
   ```

3. **Sync command function** (line 380):
   ```python
   def _send_browser_command_sync(command: str, params: Dict[str, Any] = None, timeout: float = 30.0):
   ```

### Impact
- Individual browser operations (navigate, wait_for_selector, execute_js) timeout after **30 seconds**
- Even though actor-level timeout is 120s, operations fail at 30s
- This causes repeated failures for slow operations like WhatsApp Web navigation
- Logs show: `"All three attempts (navigate, reload, and execute_js) have timed out after 30 seconds each"`

## Decision

**TimeBudgetPlanner is NOT causing the timeout issue.** The problem is hardcoded operation-level timeouts that are too short for slow browser operations.

## Proposed Solution

### Option 1: Make Browser Operation Timeouts Configurable (Recommended)
- Add `browser_operation_timeout` to `SynapseConfig` (default: 60.0 seconds)
- Pass timeout from config to `ElectronBrowserClient` and `_send_browser_command_sync`
- Allow TimeBudgetPlanner to optionally set operation-level timeouts in addition to actor-level timeouts

### Option 2: Use Adaptive Timeouts
- Leverage existing `AdaptiveTimeout` class in `Synapse/core/timeouts.py`
- Track browser operation latencies
- Dynamically adjust operation timeouts based on observed performance

### Option 3: Increase Default Timeout
- Change default from 30s to 60s or 90s
- Quick fix but less flexible

## Recommended Implementation

**Option 1 + Option 2 Hybrid:**
1. Add configurable timeout with sensible default (60s)
2. Use adaptive timeouts for operations that consistently exceed default
3. Allow TimeBudgetPlanner to override operation timeouts when it sets actor timeouts

## Consequences

### Positive
- Browser operations won't timeout prematurely
- More reliable automation for slow-loading sites (WhatsApp Web, etc.)
- Configurable per use case
- Can leverage existing adaptive timeout infrastructure

### Negative
- Operations may take longer before failing (but this is desired behavior)
- Need to ensure timeout values don't exceed actor-level timeout

## Implementation Details

**Files to Modify:**
1. `Synapse/core/data_structures.py` - Add `browser_operation_timeout` to `SynapseConfig`
2. `surface/src/surface/tools/browser_tools.py`:
   - Make `ElectronBrowserClient._response_timeout` configurable
   - Update `_send_browser_command_sync` to use configurable timeout
   - Pass timeout from config through the call chain
3. `Synapse/core/conductor.py` - Pass browser operation timeout config to browser tools
4. `Synapse/core/time_budget_planner.py` - Optionally extend to set operation-level timeouts

## Related Files
- `Synapse/core/time_budget_planner.py` - Sets actor-level timeouts (working correctly)
- `Synapse/core/conductor.py` - Applies actor-level timeouts (working correctly)
- `surface/src/surface/tools/browser_tools.py` - Contains hardcoded 30s timeouts (needs fix)
- `Synapse/core/timeouts.py` - Contains `AdaptiveTimeout` class (can be leveraged)

## Conclusion

**TimeBudgetPlanner is functioning correctly** - it sets reasonable actor-level timeouts. The timeout issue is caused by hardcoded 30-second operation-level timeouts in browser tools that are too short for slow operations.
