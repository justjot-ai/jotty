# ADR: Browser Executor File Output

**Date:** 2026-01-30  
**Status:** Implemented

## Context

The browser executor example (`surface/example_browser_simple.py`) previously only printed results to console. For production use cases and debugging, users need to:

1. **Persist Instructions** - Save the exact instruction given to the agent for audit trails
2. **Persist Results** - Save agent outputs for analysis, debugging, and record-keeping
3. **Structured Output** - Both human-readable and machine-parseable formats
4. **Timestamp Tracking** - Know when each execution occurred

Without file output:
- ❌ Results lost after console closes
- ❌ No audit trail of what was asked
- ❌ Difficult to debug failures
- ❌ Can't programmatically process results
- ❌ No history of agent executions

## Decision

Enhance the browser executor example to automatically write both instructions and outputs to files with:

1. **Timestamped Files** - Each run creates unique files with timestamp
2. **Dual Format** - Human-readable `.txt` and machine-parseable `.json`
3. **Organized Storage** - Outputs stored in `working/browser_outputs/`
4. **Complete Information** - Instruction, outputs, metadata all saved

## Implementation

### File Structure

```
surface/working/browser_outputs/
├── instruction_20260130_143025.txt    # What was asked
├── output_20260130_143025.txt         # Human-readable result
└── output_20260130_143025.json        # Machine-parseable result
```

### Instruction File Format

```txt
================================================================================
BROWSER EXECUTOR AGENT - INSTRUCTION
================================================================================
Timestamp: 2026-01-30 14:30:25
Session ID: simple_example
================================================================================

[Full instruction text here]

================================================================================
```

### Output Text File Format

```txt
================================================================================
BROWSER EXECUTOR AGENT - OUTPUT
================================================================================
Timestamp: 2026-01-30 14:35:42
Session ID: simple_example
Task Status: SUCCESS
================================================================================

ANALYSIS:
--------------------------------------------------------------------------------
[Agent's analysis of the task]

PLAN:
--------------------------------------------------------------------------------
[Agent's execution plan]

REASONING:
--------------------------------------------------------------------------------
[Agent's reasoning about the approach]

TASK COMPLETE:
--------------------------------------------------------------------------------
True

================================================================================
```

### Output JSON File Format

```json
{
  "timestamp": "2026-01-30T14:35:42.123456",
  "session_id": "simple_example",
  "instruction": "[full instruction]",
  "task_complete": true,
  "analysis": "[agent analysis]",
  "plan": "[agent plan]",
  "reasoning": "[agent reasoning]"
}
```

## Code Changes

### Added Imports

```python
import json
from datetime import datetime
```

### Output Directory Creation

```python
# Create output directory
output_dir = Path(__file__).parent / "working" / "browser_outputs"
output_dir.mkdir(parents=True, exist_ok=True)

# Generate timestamp for filenames
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
```

### Instruction Writing

```python
# Write instruction to file
instruction_file = output_dir / f"instruction_{timestamp}.txt"
print(f"💾 Writing instruction to: {instruction_file}")
with open(instruction_file, 'w', encoding='utf-8') as f:
    f.write("="*80 + "\n")
    f.write("BROWSER EXECUTOR AGENT - INSTRUCTION\n")
    f.write("="*80 + "\n")
    f.write(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write(f"Session ID: simple_example\n")
    f.write("="*80 + "\n\n")
    f.write(instruction)
    f.write("\n\n" + "="*80 + "\n")
```

### Output Writing (Text + JSON)

```python
# Write agent output to file
output_file = output_dir / f"output_{timestamp}.txt"
output_json = output_dir / f"output_{timestamp}.json"

# Text format (human-readable)
with open(output_file, 'w', encoding='utf-8') as f:
    f.write("="*80 + "\n")
    f.write("BROWSER EXECUTOR AGENT - OUTPUT\n")
    f.write("="*80 + "\n")
    f.write(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write(f"Session ID: simple_example\n")
    f.write(f"Task Status: {'SUCCESS' if result.task_complete else 'INCOMPLETE'}\n")
    f.write("="*80 + "\n\n")
    
    f.write("ANALYSIS:\n")
    f.write("-"*80 + "\n")
    f.write(f"{result.analysis}\n\n")
    
    f.write("PLAN:\n")
    f.write("-"*80 + "\n")
    f.write(f"{result.plan}\n\n")
    
    f.write("REASONING:\n")
    f.write("-"*80 + "\n")
    f.write(f"{result.reasoning}\n\n")
    
    f.write("TASK COMPLETE:\n")
    f.write("-"*80 + "\n")
    f.write(f"{result.task_complete}\n\n")
    
    f.write("="*80 + "\n")

# JSON format (machine-parseable)
with open(output_json, 'w', encoding='utf-8') as f:
    json.dump({
        'timestamp': datetime.now().isoformat(),
        'session_id': 'simple_example',
        'instruction': instruction,
        'task_complete': result.task_complete,
        'analysis': result.analysis,
        'plan': result.plan,
        'reasoning': result.reasoning,
    }, f, indent=2, ensure_ascii=False)
```

## Benefits

### For Debugging

1. ✅ **Exact Reproduction** - Know exactly what instruction was given
2. ✅ **Complete Output** - All agent responses saved
3. ✅ **Timestamp Tracking** - When did execution occur
4. ✅ **History** - Compare outputs across runs

### For Production

1. ✅ **Audit Trail** - Record of all agent interactions
2. ✅ **Compliance** - Meet logging requirements
3. ✅ **Monitoring** - Analyze agent performance over time
4. ✅ **Error Analysis** - Debug failures with full context

### For Automation

1. ✅ **JSON Output** - Programmatic access to results
2. ✅ **Batch Processing** - Process multiple runs
3. ✅ **Integration** - Feed results to other systems
4. ✅ **Analytics** - Aggregate success rates, timing, etc.

## Usage Example

### Running the Example

```bash
cd /Users/anshulchauhan/Tech/term
poetry run python surface/example_browser_simple.py
```

### Console Output

```
💾 Writing instruction to: surface/working/browser_outputs/instruction_20260130_143025.txt
🚀 Starting WhatsApp automation with persistent session...

[... agent execution ...]

✅ Task Complete!
💾 Writing output to: surface/working/browser_outputs/output_20260130_143025.txt
💾 Writing JSON output to: surface/working/browser_outputs/output_20260130_143025.json

📝 Outputs saved to:
   - Instruction: surface/working/browser_outputs/instruction_20260130_143025.txt
   - Output (TXT): surface/working/browser_outputs/output_20260130_143025.txt
   - Output (JSON): surface/working/browser_outputs/output_20260130_143025.json
```

### Accessing Results

**Human Reading:**
```bash
cat surface/working/browser_outputs/output_20260130_143025.txt
```

**Programmatic Access:**
```python
import json

with open('surface/working/browser_outputs/output_20260130_143025.json') as f:
    result = json.load(f)
    
print(f"Task completed: {result['task_complete']}")
print(f"Analysis: {result['analysis']}")
```

## File Organization

Files are stored in `surface/working/browser_outputs/` following the project organization rules:

- ✅ Temporary/working files go in `working/`
- ✅ Browser-specific outputs in browser subdirectory
- ✅ Easy to clean up (`rm -rf working/browser_outputs/`)
- ✅ Not tracked in git (covered by `.gitignore`)

## Timestamp Format

Using `%Y%m%d_%H%M%S` format:
- **Sortable** - Files naturally sort chronologically
- **Readable** - Easy to identify when run occurred
- **Collision-resistant** - Different runs within same second are rare
- **Filesystem-safe** - No special characters

## Future Enhancements

### Potential Improvements

1. **Rotation** - Auto-delete old files after N days
2. **Compression** - Gzip old outputs to save space
3. **Streaming** - Write outputs as agent executes
4. **Rich Output** - Include screenshots, tool calls, etc.
5. **Summary File** - Index of all runs with metadata

### Example Enhancement: Rotation

```python
# Clean up files older than 7 days
from datetime import timedelta

cutoff = datetime.now() - timedelta(days=7)
for file in output_dir.glob("*"):
    if file.stat().st_mtime < cutoff.timestamp():
        file.unlink()
```

## Security Considerations

### What Gets Saved

- ✅ Instructions (may contain sensitive URLs/data)
- ✅ Agent outputs (may contain scraped data)
- ✅ Session IDs
- ✅ Timestamps

### What Doesn't Get Saved

- ❌ API keys (not in instruction)
- ❌ Browser cookies (separate storage)
- ❌ Authentication tokens

### Recommendations

1. **Sensitive Data** - Review instructions before sharing files
2. **Access Control** - Output directory is user-only (default permissions)
3. **Cleanup** - Regularly delete old outputs with sensitive data
4. **Git Ignore** - Ensure `working/` is in `.gitignore`

## Testing

### Verify Output Files Created

```bash
cd /Users/anshulchauhan/Tech/term
poetry run python surface/example_browser_simple.py

# Check files exist
ls -lh surface/working/browser_outputs/
```

### Verify JSON Structure

```bash
# Pretty print JSON output
cat surface/working/browser_outputs/output_*.json | python -m json.tool
```

### Verify Text Formatting

```bash
# Read text output
cat surface/working/browser_outputs/output_*.txt
```

## Consequences

### Positive

1. ✅ Complete audit trail of agent executions
2. ✅ Easy debugging with saved instructions/outputs
3. ✅ Machine-readable results (JSON) for automation
4. ✅ Human-readable results (TXT) for review
5. ✅ No data loss when console closes
6. ✅ Historical tracking of agent performance
7. ✅ Professional production-ready pattern

### Negative

1. ⚠️ Disk space usage increases over time
2. ⚠️ Sensitive data may be saved to disk
3. ⚠️ Need to manage file cleanup

### Mitigation

- Regular cleanup of `working/` directory
- User awareness of what data gets saved
- Future enhancement for auto-rotation

## Related ADRs

- [Browser Authentication Persistence](browser-authentication-persistence.md)
- [Project Root Cleanup and Organization](project-root-cleanup-and-organization.md)
- [Browser Executor Examples](browser-executor-examples.md)

## References

- Python `json` module documentation
- Python `datetime` module documentation
- File I/O best practices

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Implementation:** Complete  
**Files Modified:** `surface/example_browser_simple.py`
