# Agent Tool Assignment Refactoring

**Status:** Implemented  
**Date:** 2026-01-29  
**Context:** Surface Swarm Agents Architecture

## Decision

Refactored the base agent architecture to support agent-specific tool assignments rather than hard-coding all tools for every agent. Created a new BrowserExecutor agent with exclusive browser automation tools.

## Context

Previously, all Surface Swarm agents inherited from `BaseSwarmAgent` which hard-coded terminal and web search tools for every agent. This approach violated separation of concerns and made it impossible to create specialized agents with different tool sets (e.g., browser automation).

The requirement was to:
1. Create a new BrowserExecutor agent with only browser automation tools
2. Remove hard-coded tool assignments from base agent
3. Move tool assignments to individual agents
4. Maintain backward compatibility with existing agents

## Implementation

### Base Agent Refactoring

**Modified `base_agent.py`:**
- Added `TOOLS` class variable with default tools (terminal + web search)
- Modified `__init__` to accept `tools` parameter
- Updated `restore_tools()` to work with dynamic tool lists
- Refactored `_create_bound_tools()` to create generic wrappers for any tool

**Key Changes:**
```python
# Class-level tool specification
TOOLS = [
    send_terminal_command, 
    get_terminal_state, 
    get_incremental_output,
    web_search,
    scrape_website
]

# Dynamic tool initialization
def __init__(self, max_iters: int = 50, tools: list = None):
    self._tools_list = tools if tools is not None else self.TOOLS
    self.generate = dspy.ReAct(
        self.SIGNATURE_CLASS,
        tools=self._tools_list,
        max_iters=max_iters
    )
```

### Tool Assignment per Agent

Updated all existing agents to explicitly declare their tools:

**CodeMaster, DataMind, SysOps, SecureSentry, ScienceCore, DomainExpert:**
```python
TOOLS = [
    send_terminal_command,
    get_terminal_state,
    get_incremental_output,
    web_search,
    scrape_website
]
```

**BrowserExecutor (NEW):**
```python
TOOLS = [
    initialize_browser,
    close_browser,
    navigate_to_url,
    click_element,
    type_text,
    get_element_text,
    get_element_attribute,
    open_new_tab,
    switch_to_tab,
    close_current_tab,
    scroll_page,
    take_screenshot,
    execute_javascript,
    hover_over_element,
    wait_for_element,
    get_page_source,
    go_back,
    go_forward,
    refresh_page,
    get_cookies,
    add_cookie,
    delete_all_cookies,
    switch_to_frame,
    switch_to_default_content
]
```

### New Components Created

1. **`browser_executor.py`** - BrowserExecutor agent implementation
2. **`browser_executor_signature.py`** - DSPy signature for browser tasks
3. Updated exports in `__init__.py` files

## Tool Assignment Strategy

| Agent | Tools |
|-------|-------|
| CodeMaster | Terminal + Web Search |
| DataMind | Terminal + Web Search |
| SysOps | Terminal + Web Search |
| SecureSentry | Terminal + Web Search |
| ScienceCore | Terminal + Web Search |
| DomainExpert | Terminal + Web Search |
| **BrowserExecutor** | **Browser Automation Only** |

## Technical Details

### Generic Tool Binding

The new `_create_bound_tools()` method creates generic wrappers dynamically:

```python
def make_bound_tool(func, name):
    def bound_tool(*args, **kwargs):
        # Generic logging and error handling
        result = func(*args, **kwargs)
        return json.dumps(result) if isinstance(result, dict) else str(result)
    
    # Preserve function metadata for DSPy
    bound_tool.__name__ = name
    bound_tool.__doc__ = func.__doc__
    bound_tool.__annotations__ = func.__annotations__
    
    return bound_tool
```

This approach:
- Works with any callable tool
- Preserves function signatures for DSPy ReAct
- Provides consistent logging across all tools
- Handles errors uniformly

### Backward Compatibility

Existing agents continue to work without modification because:
1. Default `TOOLS` class variable maintains original behavior
2. Each agent explicitly overrides with the same tools
3. Base agent fallback ensures compatibility

## Consequences

**Positive:**
- Clear separation of concerns - each agent declares its tools
- Easy to add new specialized agents with different tool sets
- BrowserExecutor has only browser tools (no terminal/web search)
- Consistent tool binding mechanism across all agents
- Maintainable and extensible architecture

**Trade-offs:**
- Each agent file now explicitly imports and declares tools
- More code duplication in tool declarations (but better clarity)
- Slight increase in initialization complexity

**Improvements:**
- No more hard-coded tool assumptions in base agent
- Agent capabilities are now self-documenting
- Tool selection is explicit and intentional

## Future Enhancements

- Tool composition strategies (e.g., terminal + browser)
- Dynamic tool loading based on task requirements
- Tool permission/capability system
- Agent tool usage analytics
- Mixed-capability agents (terminal + browser)

## Related

- `browser-automation-tools.md` - Browser tools implementation
- Surface Swarm architecture documentation
