# ADR: Electron App Modular Refactoring Plan

**Status**: Proposed  
**Date**: February 4, 2026  
**Deciders**: A-Team (Full Consensus)  
**Context**: Electron app needs modular component architecture for maintainability and reusability

---

## Context

The Electron app currently has:
- **main.js**: 2325 lines - God object handling window management, IPC, CDP engine, browser automation, WhatsApp handlers
- **app.js**: 2182 lines - Monolithic class handling UI, WebSocket, business logic, conversation management
- **agent-view-manager.js**: 3000+ lines - Single file managing all agent views and handlers
- **No component architecture**: Everything is hardcoded, no reusability
- **No service layer**: Business logic mixed with IPC handlers and UI code
- **Hardcoded configuration**: Magic numbers and URLs throughout

This makes the codebase:
- ❌ Hard to test (can't test components in isolation)
- ❌ Hard to maintain (changes affect unrelated code)
- ❌ Hard to extend (can't reuse components)
- ❌ Hard to debug (too many responsibilities in single files)

---

## Decision

Refactor the Electron app into a **modular component architecture** with:

1. **Service Layer**: Separate business logic from IPC handlers and UI
2. **Component System**: Reusable UI components
3. **Module Separation**: Split monolithic files into focused modules
4. **Configuration Management**: Extract hardcoded values to config
5. **Error Boundaries**: Proper error handling and recovery
6. **Testable Architecture**: Clear interfaces for testing

---

## Proposed Architecture

### Directory Structure

```
electron-app/
├── src/
│   ├── main/                          # Main process
│   │   ├── index.js                   # Entry point (thin)
│   │   ├── window/
│   │   │   ├── window-manager.js      # Window creation & management
│   │   │   └── browser-view-manager.js # BrowserView positioning
│   │   ├── ipc/
│   │   │   ├── ipc-handlers.js        # IPC route registry
│   │   │   ├── handlers/
│   │   │   │   ├── session-handlers.js
│   │   │   │   ├── browser-handlers.js
│   │   │   │   ├── whatsapp-handlers.js
│   │   │   │   └── window-handlers.js
│   │   │   └── router.js              # IPC routing logic
│   │   ├── services/
│   │   │   ├── browser-service.js     # Browser automation service
│   │   │   ├── cdp-engine.js          # CDP engine (extracted)
│   │   │   ├── whatsapp-service.js    # WhatsApp service (existing, keep)
│   │   │   └── session-service.js    # Session management service
│   │   ├── menu/
│   │   │   └── menu-builder.js        # Menu creation
│   │   └── config/
│   │       └── app-config.js          # App configuration
│   │
│   ├── preload.js                     # IPC bridge (keep as-is)
│   │
│   └── renderer/                      # Renderer process
│       ├── index.html                 # Main HTML (keep)
│       ├── css/                       # Styles (keep)
│       │   ├── styles.css
│       │   └── agent-views.css
│       ├── js/
│       │   ├── app.js                 # Main app (refactored, thin)
│       │   ├── services/              # Renderer services
│       │   │   ├── websocket-service.js
│       │   │   ├── conversation-service.js
│       │   │   ├── task-service.js
│       │   │   └── theme-service.js
│       │   ├── components/            # UI Components
│       │   │   ├── Component.js       # Base component class
│       │   │   ├── ConversationDisplay.js
│       │   │   ├── TaskList.js
│       │   │   ├── Modal.js
│       │   │   ├── ThemeSwitcher.js
│       │   │   ├── ChatInput.js
│       │   │   └── AgentCard.js
│       │   ├── managers/              # View managers
│       │   │   ├── AgentViewManager.js (refactored)
│       │   │   ├── handlers/
│       │   │   │   ├── BrowserViewHandler.js
│       │   │   │   ├── TerminalViewHandler.js
│       │   │   │   ├── SearchViewHandler.js
│       │   │   │   └── PlannerViewHandler.js
│       │   │   └── ViewFactory.js
│       │   └── utils/                # Utilities
│       │       ├── markdown.js
│       │       ├── html-escape.js
│       │       └── event-bus.js
│       └── config/
│           └── renderer-config.js    # Renderer configuration
│
├── config/                           # Shared configuration
│   ├── default-config.json
│   └── config-loader.js
│
└── tests/                            # Tests
    ├── main/
    │   ├── services/
    │   └── ipc/
    └── renderer/
        ├── components/
        └── services/
```

---

## Implementation Plan

### Phase 1: Extract Services (Week 1)

**Goal**: Separate business logic from IPC handlers and UI

#### 1.1 Main Process Services

**Create `src/main/services/browser-service.js`**:
```javascript
/**
 * Browser Automation Service
 * Handles all browser automation logic (extracted from main.js)
 */
class BrowserService {
  constructor(cdpEngine, browserView) {
    this.cdpEngine = cdpEngine;
    this.browserView = browserView;
  }
  
  async navigate(url) { /* ... */ }
  async click(options) { /* ... */ }
  async type(options) { /* ... */ }
  // ... all browser methods
}

module.exports = { BrowserService };
```

**Create `src/main/services/session-service.js`**:
```javascript
/**
 * Session Management Service
 * Handles session creation, saving, loading
 */
class SessionService {
  constructor(app) {
    this.app = app;
    this.sessionsDir = path.join(app.getPath('userData'), 'sessions');
  }
  
  async createSession() { /* ... */ }
  async saveSession(sessionData) { /* ... */ }
  async loadSession(filename) { /* ... */ }
  async clearSession() { /* ... */ }
}

module.exports = { SessionService };
```

**Extract CDP Engine to `src/main/services/cdp-engine.js`**:
- Move CDP engine code from main.js (lines 270-480)
- Make it a standalone service
- Export for use by BrowserService

#### 1.2 Renderer Services

**Create `src/renderer/js/services/websocket-service.js`**:
```javascript
/**
 * WebSocket Service
 * Manages WebSocket connection and message handling
 */
class WebSocketService {
  constructor(url) {
    this.url = url;
    this.ws = null;
    this.listeners = new Map();
  }
  
  connect() { /* ... */ }
  disconnect() { /* ... */ }
  send(data) { /* ... */ }
  on(event, callback) { /* ... */ }
  off(event) { /* ... */ }
}

module.exports = { WebSocketService };
```

**Create `src/renderer/js/services/conversation-service.js`**:
```javascript
/**
 * Conversation Service
 * Manages conversation history and display
 */
class ConversationService {
  constructor() {
    this.messages = [];
  }
  
  addMessage(role, content, metadata) { /* ... */ }
  getMessages() { /* ... */ }
  clearMessages() { /* ... */ }
  buildDisplayHTML(recentCount = 6) { /* ... */ }
}

module.exports = { ConversationService };
```

**Create `src/renderer/js/services/task-service.js`**:
```javascript
/**
 * Task Service
 * Manages task list and display
 */
class TaskService {
  constructor() {
    this.tasks = [];
  }
  
  updateTasks(taskListData) { /* ... */ }
  getTasks() { /* ... */ }
  filterTasks(predicate) { /* ... */ }
  buildTaskListHTML() { /* ... */ }
}

module.exports = { TaskService };
```

**Create `src/renderer/js/services/theme-service.js`**:
```javascript
/**
 * Theme Service
 * Manages theme switching and persistence
 */
class ThemeService {
  constructor() {
    this.currentTheme = 'midnight';
  }
  
  loadTheme() { /* ... */ }
  setTheme(theme) { /* ... */ }
  getTheme() { /* ... */ }
  saveTheme(theme) { /* ... */ }
}

module.exports = { ThemeService };
```

### Phase 2: Create Component System (Week 2)

**Goal**: Build reusable UI components

#### 2.1 Base Component Class

**Create `src/renderer/js/components/Component.js`**:
```javascript
/**
 * Base Component Class
 * Provides lifecycle and event handling for all components
 */
class Component {
  constructor(container, props = {}) {
    this.container = container;
    this.props = props;
    this.state = {};
    this.eventListeners = [];
  }
  
  render() {
    throw new Error('render() must be implemented');
  }
  
  mount() {
    this.render();
    this.onMount();
  }
  
  unmount() {
    this.eventListeners.forEach(({ element, event, handler }) => {
      element.removeEventListener(event, handler);
    });
    this.onUnmount();
  }
  
  setState(newState) {
    this.state = { ...this.state, ...newState };
    this.render();
  }
  
  onMount() {}
  onUnmount() {}
  
  addEventListener(element, event, handler) {
    element.addEventListener(event, handler);
    this.eventListeners.push({ element, event, handler });
  }
}

module.exports = { Component };
```

#### 2.2 UI Components

**Create `src/renderer/js/components/ConversationDisplay.js`**:
```javascript
const { Component } = require('./Component');
const { markdownToHtml } = require('../utils/markdown');
const { escapeHtml } = require('../utils/html-escape');

class ConversationDisplay extends Component {
  constructor(container, props) {
    super(container, props);
    this.conversationService = props.conversationService;
  }
  
  render() {
    const messages = this.conversationService.getMessages();
    const recentMessages = messages.slice(-this.props.recentCount || 6);
    
    this.container.innerHTML = this.buildHTML(recentMessages);
    this.attachEventListeners();
  }
  
  buildHTML(messages) {
    // Extract from app.js buildConversationDisplay()
  }
  
  attachEventListeners() {
    // Handle "View More" button clicks
  }
}

module.exports = { ConversationDisplay };
```

**Create `src/renderer/js/components/TaskList.js`**:
```javascript
const { Component } = require('./Component');

class TaskList extends Component {
  constructor(container, props) {
    super(container, props);
    this.taskService = props.taskService;
  }
  
  render() {
    const tasks = this.taskService.getTasks();
    this.container.innerHTML = this.buildHTML(tasks);
  }
  
  buildHTML(tasks) {
    // Extract from app.js displayTaskListInSidebar()
  }
}

module.exports = { TaskList };
```

**Create `src/renderer/js/components/Modal.js`**:
```javascript
const { Component } = require('./Component');

class Modal extends Component {
  constructor(container, props) {
    super(container, props);
    this.title = props.title || 'Modal';
    this.content = props.content || '';
  }
  
  render() {
    this.container.innerHTML = this.buildHTML();
    this.attachEventListeners();
  }
  
  buildHTML() {
    return `
      <div class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h2>${this.title}</h2>
            <button class="modal-close">×</button>
          </div>
          <div class="modal-body">${this.content}</div>
        </div>
      </div>
    `;
  }
  
  show() {
    this.container.classList.add('show');
  }
  
  hide() {
    this.container.classList.remove('show');
  }
  
  attachEventListeners() {
    const closeBtn = this.container.querySelector('.modal-close');
    this.addEventListener(closeBtn, 'click', () => this.hide());
  }
}

module.exports = { Modal };
```

**Create `src/renderer/js/components/ThemeSwitcher.js`**:
```javascript
const { Component } = require('./Component');

class ThemeSwitcher extends Component {
  constructor(container, props) {
    super(container, props);
    this.themeService = props.themeService;
  }
  
  render() {
    this.container.innerHTML = this.buildHTML();
    this.attachEventListeners();
  }
  
  buildHTML() {
    // Extract theme menu HTML from index.html
  }
  
  attachEventListeners() {
    // Handle theme selection
  }
}

module.exports = { ThemeSwitcher };
```

**Create `src/renderer/js/components/ChatInput.js`**:
```javascript
const { Component } = require('./Component');

class ChatInput extends Component {
  constructor(container, props) {
    super(container, props);
    this.onSend = props.onSend || (() => {});
  }
  
  render() {
    this.container.innerHTML = this.buildHTML();
    this.attachEventListeners();
  }
  
  buildHTML() {
    return `
      <input type="text" class="chat-input" placeholder="Type your message..." />
      <button class="send-btn">Send</button>
    `;
  }
  
  attachEventListeners() {
    const input = this.container.querySelector('.chat-input');
    const sendBtn = this.container.querySelector('.send-btn');
    
    this.addEventListener(input, 'keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.handleSend();
      }
    });
    
    this.addEventListener(sendBtn, 'click', () => this.handleSend());
  }
  
  handleSend() {
    const input = this.container.querySelector('.chat-input');
    const message = input.value.trim();
    if (message) {
      this.onSend(message);
      input.value = '';
    }
  }
}

module.exports = { ChatInput };
```

### Phase 3: Refactor IPC Handlers (Week 2-3)

**Goal**: Make IPC handlers thin wrappers that route to services

#### 3.1 Create IPC Router

**Create `src/main/ipc/router.js`**:
```javascript
/**
 * IPC Router
 * Routes IPC messages to appropriate handlers
 */
class IPCRouter {
  constructor() {
    this.handlers = new Map();
  }
  
  register(channel, handler) {
    this.handlers.set(channel, handler);
  }
  
  async handle(channel, event, ...args) {
    const handler = this.handlers.get(channel);
    if (!handler) {
      throw new Error(`No handler registered for channel: ${channel}`);
    }
    return await handler(event, ...args);
  }
}

module.exports = { IPCRouter };
```

#### 3.2 Create Handler Modules

**Create `src/main/ipc/handlers/browser-handlers.js`**:
```javascript
/**
 * Browser IPC Handlers
 * Thin wrappers that route to BrowserService
 */
class BrowserHandlers {
  constructor(browserService) {
    this.browserService = browserService;
  }
  
  register(ipcMain, router) {
    ipcMain.handle('browser-navigate', async (event, url) => {
      return await this.browserService.navigate(url);
    });
    
    ipcMain.handle('browser-click', async (event, options) => {
      return await this.browserService.click(options);
    });
    
    // ... all browser handlers
  }
}

module.exports = { BrowserHandlers };
```

**Create `src/main/ipc/handlers/session-handlers.js`**:
```javascript
/**
 * Session IPC Handlers
 * Thin wrappers that route to SessionService
 */
class SessionHandlers {
  constructor(sessionService) {
    this.sessionService = sessionService;
  }
  
  register(ipcMain, router) {
    ipcMain.handle('get-session-stats', async () => {
      return await this.sessionService.getStats();
    });
    
    ipcMain.handle('save-session', async (event, sessionData) => {
      return await this.sessionService.saveSession(sessionData);
    });
    
    // ... all session handlers
  }
}

module.exports = { SessionHandlers };
```

### Phase 4: Refactor Main.js (Week 3)

**Goal**: Split main.js into focused modules

#### 4.1 Create Window Manager

**Create `src/main/window/window-manager.js`**:
```javascript
/**
 * Window Manager
 * Handles window creation and lifecycle
 */
class WindowManager {
  constructor(app, config) {
    this.app = app;
    this.config = config;
    this.mainWindow = null;
  }
  
  createWindow() {
    // Extract window creation logic from main.js
  }
  
  setupMenu() {
    // Extract menu creation logic
  }
  
  setupGlobalShortcuts() {
    // Extract global shortcuts logic
  }
}

module.exports = { WindowManager };
```

#### 4.2 Create Browser View Manager

**Create `src/main/window/browser-view-manager.js`**:
```javascript
/**
 * Browser View Manager
 * Handles BrowserView creation and positioning
 */
class BrowserViewManager {
  constructor(mainWindow, session) {
    this.mainWindow = mainWindow;
    this.session = session;
    this.browserView = null;
  }
  
  createBrowserView() {
    // Extract BrowserView creation logic
  }
  
  updateBounds(bounds) {
    // Extract bounds update logic
  }
  
  setVisible(visible) {
    // Extract visibility logic
  }
}

module.exports = { BrowserViewManager };
```

#### 4.3 Refactor main.js to be thin

**Refactor `src/main/index.js`**:
```javascript
const { app } = require('electron');
const { WindowManager } = require('./window/window-manager');
const { BrowserViewManager } = require('./window/browser-view-manager');
const { BrowserService } = require('./services/browser-service');
const { SessionService } = require('./services/session-service');
const { CDPEngine } = require('./services/cdp-engine');
const { IPCRouter } = require('./ipc/router');
const { BrowserHandlers } = require('./ipc/handlers/browser-handlers');
const { SessionHandlers } = require('./ipc/handlers/session-handlers');
const { WhatsAppService } = require('./whatsapp-service');
const config = require('./config/app-config');

let windowManager;
let browserViewManager;
let browserService;
let sessionService;
let cdpEngine;
let ipcRouter;
let whatsappService;

app.whenReady().then(() => {
  // Initialize services
  sessionService = new SessionService(app);
  cdpEngine = new CDPEngine();
  
  // Initialize window
  windowManager = new WindowManager(app, config);
  windowManager.createWindow();
  
  // Initialize browser view
  browserViewManager = new BrowserViewManager(
    windowManager.mainWindow,
    windowManager.session
  );
  browserViewManager.createBrowserView();
  
  // Initialize browser service
  browserService = new BrowserService(cdpEngine, browserViewManager.browserView);
  
  // Initialize WhatsApp service
  whatsappService = new WhatsAppService(app, windowManager.mainWindow);
  
  // Initialize IPC router and handlers
  ipcRouter = new IPCRouter();
  const browserHandlers = new BrowserHandlers(browserService);
  const sessionHandlers = new SessionHandlers(sessionService);
  
  browserHandlers.register(require('electron').ipcMain, ipcRouter);
  sessionHandlers.register(require('electron').ipcMain, ipcRouter);
  
  // ... other handlers
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
```

### Phase 5: Refactor App.js (Week 3-4)

**Goal**: Make app.js use services and components

#### 5.1 Refactor app.js

**Refactor `src/renderer/js/app.js`**:
```javascript
const { WebSocketService } = require('./services/websocket-service');
const { ConversationService } = require('./services/conversation-service');
const { TaskService } = require('./services/task-service');
const { ThemeService } = require('./services/theme-service');
const { ConversationDisplay } = require('./components/ConversationDisplay');
const { TaskList } = require('./components/TaskList');
const { Modal } = require('./components/Modal');
const { ThemeSwitcher } = require('./components/ThemeSwitcher');
const { ChatInput } = require('./components/ChatInput');
const { AgentViewManager } = require('./managers/AgentViewManager');
const config = require('../config/renderer-config');

class SynapseAssistant {
  constructor() {
    // Initialize services
    this.websocketService = new WebSocketService(config.websocketUrl);
    this.conversationService = new ConversationService();
    this.taskService = new TaskService();
    this.themeService = new ThemeService();
    
    // Initialize components
    this.initializeComponents();
    
    // Initialize managers
    this.agentViewManager = new AgentViewManager();
    
    // Setup event listeners
    this.setupEventListeners();
  }
  
  initializeComponents() {
    // Initialize conversation display
    const convContainer = document.getElementById('conversation-display');
    this.conversationDisplay = new ConversationDisplay(convContainer, {
      conversationService: this.conversationService
    });
    this.conversationDisplay.mount();
    
    // Initialize task list
    const taskContainer = document.getElementById('task-list');
    this.taskList = new TaskList(taskContainer, {
      taskService: this.taskService
    });
    this.taskList.mount();
    
    // Initialize modals
    const modalContainer = document.getElementById('modal-container');
    this.detailsModal = new Modal(modalContainer, {
      title: 'Details'
    });
    
    // Initialize theme switcher
    const themeContainer = document.getElementById('theme-switcher');
    this.themeSwitcher = new ThemeSwitcher(themeContainer, {
      themeService: this.themeService
    });
    this.themeSwitcher.mount();
    
    // Initialize chat input
    const chatContainer = document.getElementById('chat-input-container');
    this.chatInput = new ChatInput(chatContainer, {
      onSend: (message) => this.handleSendMessage(message)
    });
    this.chatInput.mount();
  }
  
  setupEventListeners() {
    // Setup WebSocket listeners
    this.websocketService.on('message', (data) => {
      this.handleWebSocketMessage(data);
    });
    
    // Connect WebSocket
    this.websocketService.connect();
  }
  
  async handleSendMessage(message) {
    // Use conversation service
    this.conversationService.addMessage('user', message);
    this.conversationDisplay.render();
    
    // Send via WebSocket
    this.websocketService.send({
      type: 'task',
      task: message
    });
  }
  
  handleWebSocketMessage(data) {
    // Route to appropriate handler
    switch (data.type) {
      case 'task_list':
        this.taskService.updateTasks(data.data);
        this.taskList.render();
        break;
      case 'final_output':
        this.conversationService.addMessage('assistant', data.output);
        this.conversationDisplay.render();
        break;
      // ... other handlers
    }
  }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
  window.app = new SynapseAssistant();
});
```

### Phase 6: Refactor Agent View Manager (Week 4)

**Goal**: Split agent-view-manager.js into focused modules

#### 6.1 Extract Handlers

**Create `src/renderer/js/managers/handlers/BrowserViewHandler.js`**:
```javascript
/**
 * Browser View Handler
 * Handles browser-specific view logic
 */
class BrowserViewHandler {
  constructor(contentElement, agentName) {
    this.contentElement = contentElement;
    this.agentName = agentName;
  }
  
  handleEvent(event) {
    // Browser-specific event handling
  }
  
  updateView(data) {
    // Browser-specific view updates
  }
}

module.exports = { BrowserViewHandler };
```

**Create similar handlers for Terminal, Search, Planner**

#### 6.2 Create View Factory

**Create `src/renderer/js/managers/ViewFactory.js`**:
```javascript
/**
 * View Factory
 * Creates appropriate handlers for agent types
 */
class ViewFactory {
  static createHandler(type, contentElement, agentName) {
    switch (type) {
      case 'browser':
        return new BrowserViewHandler(contentElement, agentName);
      case 'terminal':
        return new TerminalViewHandler(contentElement, agentName);
      case 'search':
        return new SearchViewHandler(contentElement, agentName);
      case 'planner':
        return new PlannerViewHandler(contentElement, agentName);
      default:
        return new DefaultViewHandler(contentElement, agentName);
    }
  }
}

module.exports = { ViewFactory };
```

#### 6.3 Refactor AgentViewManager

**Refactor `src/renderer/js/managers/AgentViewManager.js`**:
```javascript
const { ViewFactory } = require('./ViewFactory');

class AgentViewManager {
  constructor() {
    this.views = new Map();
    this.activeAgents = new Set();
    this.container = null;
  }
  
  initialize() {
    this.container = document.getElementById('agents-grid-workspace');
    this.createOrchestratorBox();
    this.createAllModuleBoxes();
  }
  
  createView(agentName, type, icon) {
    // Use ViewFactory to create handler
    const handler = ViewFactory.createHandler(type, contentElement, agentName);
    
    // Store view
    this.views.set(agentName, {
      element: view,
      type: type,
      icon: icon,
      handler: handler
    });
  }
  
  handleAgentEvent(data) {
    const view = this.views.get(data.agent);
    if (view && view.handler) {
      view.handler.handleEvent(data);
    }
  }
}

module.exports = { AgentViewManager };
```

### Phase 7: Configuration Management (Week 4)

**Goal**: Extract hardcoded values to configuration

#### 7.1 Create Configuration Files

**Create `config/default-config.json`**:
```json
{
  "api": {
    "baseUrl": "http://127.0.0.1:8000",
    "websocketUrl": "ws://127.0.0.1:8000/ws/browser"
  },
  "ui": {
    "titleBarHeight": 40,
    "chatBarHeight": 68,
    "leftSidebarWidth": 240,
    "rightSidebarWidth": 260
  },
  "browser": {
    "defaultTimeout": 10000,
    "scrollDelay": 500,
    "typeDelay": 30
  },
  "websocket": {
    "reconnectDelay": 1000,
    "pingInterval": 30000
  }
}
```

**Create `src/main/config/app-config.js`**:
```javascript
const fs = require('fs');
const path = require('path');

class AppConfig {
  constructor() {
    const configPath = path.join(__dirname, '../../config/default-config.json');
    this.config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
  
  get(path) {
    return path.split('.').reduce((obj, key) => obj?.[key], this.config);
  }
  
  set(path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    const obj = keys.reduce((o, k) => o[k] = o[k] || {}, this.config);
    obj[lastKey] = value;
  }
}

module.exports = new AppConfig();
```

### Phase 8: Error Boundaries (Week 5)

**Goal**: Add proper error handling

#### 8.1 Create Error Boundary Component

**Create `src/renderer/js/components/ErrorBoundary.js`**:
```javascript
const { Component } = require('./Component');

class ErrorBoundary extends Component {
  constructor(container, props) {
    super(container, props);
    this.hasError = false;
    this.error = null;
  }
  
  render() {
    if (this.hasError) {
      this.container.innerHTML = this.buildErrorHTML();
    } else {
      try {
        this.props.children.render();
      } catch (error) {
        this.hasError = true;
        this.error = error;
        this.render();
      }
    }
  }
  
  buildErrorHTML() {
    return `
      <div class="error-boundary">
        <h3>Something went wrong</h3>
        <p>${this.error?.message || 'Unknown error'}</p>
        <button onclick="location.reload()">Reload</button>
      </div>
    `;
  }
}

module.exports = { ErrorBoundary };
```

#### 8.2 Add Error Handling to Services

**Update services to handle errors gracefully**:
```javascript
class WebSocketService {
  connect() {
    try {
      this.ws = new WebSocket(this.url);
      // ... setup
    } catch (error) {
      console.error('WebSocket connection failed:', error);
      this.handleError(error);
    }
  }
  
  handleError(error) {
    // Emit error event
    this.emit('error', error);
    // Attempt recovery
    setTimeout(() => this.connect(), this.config.reconnectDelay);
  }
}
```

---

## Migration Strategy

### Step 1: Create New Structure (No Breaking Changes)
- Create new directories and files alongside existing code
- Keep existing code working
- Gradually move functionality

### Step 2: Extract Services First
- Extract services from main.js and app.js
- Keep IPC handlers calling old code initially
- Test services independently

### Step 3: Update IPC Handlers
- Update IPC handlers to use services
- Remove business logic from handlers
- Test IPC flow

### Step 4: Create Components
- Create component classes
- Replace hardcoded HTML generation with components
- Test components in isolation

### Step 5: Refactor App.js
- Update app.js to use services and components
- Remove business logic from app.js
- Test full flow

### Step 6: Clean Up
- Remove old code
- Update documentation
- Add tests

---

## Testing Strategy

### Unit Tests
- Test services independently (no Electron context needed)
- Test components with mocked dependencies
- Test utilities (markdown, HTML escape)

### Integration Tests
- Test IPC handlers with mocked services
- Test component interactions
- Test service interactions

### E2E Tests
- Test full user flows
- Test WebSocket integration
- Test browser automation

---

## Success Criteria

✅ **Modularity**: Each module has single responsibility  
✅ **Reusability**: Components can be reused across app  
✅ **Testability**: All modules can be tested in isolation  
✅ **Maintainability**: Changes in one module don't affect others  
✅ **Configuration**: No hardcoded values  
✅ **Error Handling**: Proper error boundaries and recovery  
✅ **Documentation**: Clear interfaces and usage examples  

---

## Risks & Mitigation

**Risk**: Breaking existing functionality  
**Mitigation**: Gradual migration, keep old code until new code is tested

**Risk**: Increased complexity  
**Mitigation**: Clear documentation, consistent patterns

**Risk**: Performance impact  
**Mitigation**: Lazy loading, code splitting, performance testing

---

## Timeline

- **Week 1**: Extract services
- **Week 2**: Create component system
- **Week 3**: Refactor IPC handlers and main.js
- **Week 4**: Refactor app.js and agent-view-manager
- **Week 5**: Configuration management and error boundaries
- **Week 6**: Testing and cleanup

**Total**: 6 weeks

---

## References

- A-Team Review: `docs/review/electron-app-modular-refactor-review.md`
- Electron Best Practices: https://www.electronjs.org/docs/latest/tutorial/application-architecture
- Component Patterns: https://github.com/goldbergyoni/javascript-testing-best-practices

---

**Status**: ✅ **APPROVED BY A-TEAM**  
**Next Steps**: Begin Phase 1 implementation
