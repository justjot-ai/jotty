# ADR: UV API /perform Endpoint - Task Execution via Synapse

**Status**: Implemented  
**Date**: 2026-01-31  
**Author**: Anshul Chauhan

## Context

The project has a shell script `./scripts/run_solve_task.sh` that executes tasks using Synapse orchestration with Surface executor agents. This functionality needed to be exposed via a REST API endpoint without depending on the `surface_synapse` package.

## Decision

Created a new FastAPI endpoint `/api/v1/perform` that replicates the functionality of `run_solve_task.sh` by:

1. **Direct Integration**: Uses Synapse and Surface components directly without importing from `surface_synapse`
2. **Embedded Logic**: Copied the swarm creation logic from `surface_synapse/integration.py` into the endpoint
3. **FastAPI Implementation**: Exposed as a POST endpoint with request/response validation

### Implementation Details

#### Endpoint Location

```
uv/src/uv/api/v1/perform.py
```

#### Key Components

1. **Request Model** (`PerformTaskRequest`):
   - `task`: The instruction to execute (required)
   - `context`: Optional context dictionary
   - `model_name`: LLM model (default: Claude Sonnet 4.5)
   - `temperature`: Model temperature (default: 0.1)
   - `max_tokens`: Maximum tokens (default: 64000)
   - `max_iters`: Maximum iterations (default: 50)
   - `enable_memory`: Enable/disable memory system

2. **Response Model** (`PerformTaskResponse`):
   - `success`: Whether task completed successfully
   - `output`: Final output text
   - `agents_used`: List of agents auto-selected by Synapse
   - `execution_time`: Total execution time in seconds
   - `error`: Error message if failed

3. **Swarm Creation** (`create_executor_swarm`):
   - Configures DSPy LM with LiteLLM
   - Creates shared browser instance for BrowserExecutor
   - Initializes 3 Surface executor agents:
     - BrowserExecutor (web automation)
     - TerminalExecutor (command execution)
     - WebSearchAgent (research)
   - Creates AgentConfig for each agent
   - Configures Synapse with recovery and validation
   - Returns Conductor instance

4. **Task Execution** (`run_task_in_swarm`):
   - Enhances goal with context if provided
   - Runs task through Synapse Conductor
   - Handles async/sync context detection
   - Returns structured result dictionary

### Architecture

```
┌─────────────────────────────────────────────────┐
│           FastAPI POST /perform                 │
│                                                 │
│  Request → Validation → Swarm Creation →        │
│  Task Execution → Result Extraction → Response │
└─────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────┐
│         Synapse Conductor (Orchestration)        │
│                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────┐ │
│  │BrowserExecutor TerminalExecutor WebSearchAgent│
│  └─────────────┘  └─────────────┘  └─────────┘ │
│                                                 │
│  • AgenticToolSelector (auto-selects agents)    │
│  • AgenticFeedbackRouter (coordination)         │
│  • AgenticParameterResolver (mapping)           │
└─────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────┐
│              Surface Tools Layer                │
│                                                 │
│  • Browser Tools (Selenium)                     │
│  • Terminal Tools (pexpect)                     │
│  • Web Search Tools (Serper API)                │
└─────────────────────────────────────────────────┘
```

## Implementation Details

### Dependencies

**Referenced (Allowed)**:
- `Synapse` - Core orchestration (Conductor, AgentConfig, SynapseConfig)
- `surface` - Executor agents and tools
- Standard Python libraries (asyncio, pathlib, logging, etc.)

**NOT Referenced** (As Required):
- `surface_synapse` - Integration package not imported

### API Usage Examples

#### Simple Task

```bash
curl -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "What are the top 3 Python web frameworks?"
  }'
```

#### Task with Context

```bash
curl -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Recommend a database",
    "context": {
      "scale": "large",
      "budget": "moderate"
    }
  }'
```

#### Complex Task (Original Use Case)

```bash
curl -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Summarize messages of whatsapp group synapse",
    "max_iters": 50
  }' > output.json
```

#### Custom Configuration

```bash
curl -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Research Docker best practices",
    "temperature": 0.1,
    "max_tokens": 64000,
    "max_iters": 30,
    "enable_memory": true
  }'
```

### Response Format

```json
{
  "success": true,
  "output": "Based on my research, the top Python web frameworks are:\n1. Django...",
  "agents_used": ["WebSearchAgent", "BrowserExecutor"],
  "execution_time": 15.234,
  "error": null
}
```

### Error Handling

1. **Import Errors**: Returns 500 if Synapse/Surface not available
2. **Validation Errors**: Returns 422 for invalid request data
3. **Execution Errors**: Returns 200 with `success=false` and error message
4. **Timeout**: 30-minute timeout for long-running tasks

## Consequences

### Positive

1. **API Access**: Task execution now available via REST API
2. **No surface_synapse Dependency**: Uses direct imports as required
3. **Equivalent Functionality**: Replicates `run_solve_task.sh` behavior
4. **Flexible Configuration**: All parameters configurable via API
5. **Auto Documentation**: Swagger/ReDoc docs generated automatically
6. **Type Safety**: Full Pydantic validation on request/response
7. **Async Support**: Handles both sync and async contexts
8. **Production Ready**: Error handling, logging, timeouts

### Negative

1. **Code Duplication**: Logic copied from `surface_synapse/integration.py`
2. **Maintenance**: Changes to swarm creation need updates in two places
3. **Long Response Times**: Tasks can take minutes to complete
4. **Headless Browser**: Browser runs in headless mode for API (may affect some tasks)
5. **Shared State**: Single swarm instance shared across all requests (thread-safe but sequential)

## Testing

### Unit Tests

```bash
cd uv
poetry run pytest tests/test_perform.py
```

### Manual Testing

```bash
# Start server
cd uv
./run_server.sh

# Run examples
./example_perform.sh
```

### Test Coverage

- Simple task execution
- Task with context
- Validation errors
- Custom parameters
- Response structure

## Performance Optimization

### Swarm Lifecycle

The swarm is now created **once at application startup** and reused for all requests:

1. **Startup**: `lifespan()` in `main.py` calls `initialize_swarm()`
2. **Storage**: Swarm stored in `app.state.synapse_swarm`
3. **Usage**: Each `/perform` request uses the same swarm via `get_swarm()`
4. **Shutdown**: `cleanup_swarm()` closes browser and cleans up resources

### Benefits

- **Fast Requests**: No swarm creation overhead after first initialization
- **Resource Efficiency**: Single browser instance shared across requests
- **Persistent Sessions**: Browser profile persists between tasks
- **Lower Memory**: One set of agents instead of per-request instances

### Configuration

Swarm configuration is loaded from environment variables at startup:

```env
SYNAPSE_MODEL=openai/pi-agentic/au-anthropic-claude-sonnet-4-5-20250929-v1-0
SYNAPSE_TEMPERATURE=0.7
SYNAPSE_MAX_ITERS=50
SYNAPSE_ENABLE_MEMORY=true
LITELLM_API_KEY=your-key
LITELLM_BASE_URL=https://llm.tfy.pi.mypaytm.com
SERPER_API_KEY=your-key
```

Per-request parameters (model, temperature, etc.) in the API request are **ignored** since the swarm is pre-configured. To change these settings, restart the application with updated environment variables.

## Future Enhancements

1. **Swarm Pool**: Multiple swarm instances for concurrent request handling
2. **Streaming Responses**: Stream task progress via WebSocket
3. **Task Queue**: Background task processing with job IDs
4. **Authentication**: Require auth token for /perform endpoint
5. **Rate Limiting**: Prevent abuse with rate limits
6. **Caching**: Cache results for identical tasks
7. **Metrics**: Track agent usage, success rates, execution times
8. **Async Execution**: Return immediately with task ID, poll for results
9. **Browser Options**: Allow headful mode for debugging
10. **Custom Agents**: Support registering custom agents

## Integration

### With UV Application

```python
# Import and use in other endpoints
from uv.api.v1.perform import create_executor_swarm, run_task_in_swarm

# Create shared swarm for session
swarm = create_executor_swarm(...)

# Run multiple tasks
result1 = run_task_in_swarm("Task 1", None, swarm)
result2 = run_task_in_swarm("Task 2", None, swarm)
```

### With External Systems

```python
import httpx

# Call from another service
async with httpx.AsyncClient() as client:
    response = await client.post(
        "http://uv-api:8000/api/v1/perform",
        json={"task": "Research topic"}
    )
    result = response.json()
```

## References

- Original script: `scripts/run_solve_task.sh`
- Original implementation: `surface_synapse/integration.py`
- Synapse docs: `Synapse/README.md`
- Surface docs: `surface/README.md`
- API docs: `uv/README.md`

## Related ADRs

- `uv-fastapi-application.md` - UV FastAPI application setup
