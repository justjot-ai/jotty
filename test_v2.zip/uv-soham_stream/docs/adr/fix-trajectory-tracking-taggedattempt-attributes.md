# Fix: Trajectory Tracking TaggedAttempt Attributes

**Date:** 2026-01-31  
**Status:** Fixed  
**Type:** Bug Fix

## Problem

Trajectory tracking code in `Synapse/core/synapse_core.py` was failing with error:

```
⚠️  Failed to track trajectory in environment: 'TaggedAttempt' object has no attribute 'tool_args'
```

The code was trying to access `attempt.tool_args`, but `TaggedAttempt` dataclass doesn't have this attribute.

## Root Cause

**Incorrect Attribute Reference**

The trajectory tracking code (added for environment manager) was accessing a non-existent attribute:

```python
# ❌ WRONG - tool_args doesn't exist
f"Args: {str(attempt.tool_args)[:80]}"
```

## TaggedAttempt Structure

**Actual Fields** (from `Synapse/core/trajectory_parser.py`):

```python
@dataclass
class TaggedAttempt:
    output: Any                    # The actual output (query, code, config, etc.)
    tag: str                       # 'answer', 'error', or 'exploratory'
    execution_status: str          # 'success', 'failed', 'uncertain'
    execution_result: str          # Full observation from tool
    reasoning: str                 # Thought/reasoning for this attempt
    attempt_number: int = 0
    tool_name: str = ""           # Which tool was called
    timestamp: float = field(default_factory=lambda: datetime.now().timestamp())
```

**Key Point:** `output` contains the actual output/arguments, not `tool_args`.

## Solution

**Fixed Attribute References**

```python
# ✅ CORRECT - Use actual attributes
for attempt in tagged_attempts[:5]:
    output_str = str(attempt.output)[:80] if hasattr(attempt, 'output') and attempt.output else "N/A"
    trajectory_info.append(
        f"    #{attempt.attempt_number}: {attempt.tag} | "
        f"Tool: {attempt.tool_name} | "
        f"Status: {attempt.execution_status} | "  # Added status for better info
        f"Output: {output_str}{'...' if len(str(getattr(attempt, 'output', ''))) > 80 else ''}"
    )
```

## Changes Made

### Before (Broken)
```python
f"Args: {str(attempt.tool_args)[:80]}..."  # ❌ AttributeError
```

### After (Fixed)
```python
output_str = str(attempt.output)[:80] if hasattr(attempt, 'output') and attempt.output else "N/A"
f"Status: {attempt.execution_status} | "
f"Output: {output_str}..."  # ✅ Works correctly
```

## Enhanced Output

**Additional Improvement:** Added `execution_status` to provide more context:

```markdown
# Before fix (would crash):
    #1: answer | Tool: execute_sql | Args: [ERROR]

# After fix (works and better info):
    #1: answer | Tool: execute_sql | Status: success | Output: SELECT * FROM users...
    #2: error | Tool: execute_sql | Status: failed | Output: Syntax error near...
    #3: exploratory | Tool: execute_sql | Status: uncertain | Output: SELECT COUNT...
```

## Files Modified

- ✅ `Synapse/core/synapse_core.py` (line ~820-827) - Fixed attribute access
- ✅ `docs/adr/fix-trajectory-tracking-taggedattempt-attributes.md` - This ADR

## Testing

### Before Fix
```bash
# Would see error in logs:
⚠️  Failed to track trajectory in environment: 'TaggedAttempt' object has no attribute 'tool_args'
```

### After Fix
```bash
# Should see successful tracking:
✅ Tracked trajectory in environment (8 lines)
```

### Verification
```bash
# Check environment file for trajectory info
cat outputs/synapse_state/env/env.md | grep -A 10 "Action Trajectory"

# Expected output:
🎯 **Action Trajectory** (Agent: TrinoAgent)
  - Total attempts: 3
    #1: exploratory | Tool: execute_sql | Status: uncertain | Output: SELECT * ...
    #2: error | Tool: execute_sql | Status: failed | Output: Syntax error...
    #3: answer | Tool: execute_sql | Status: success | Output: SELECT user_id...
```

## Impact

### Before
- ❌ Trajectory tracking would silently fail
- ❌ Environment would miss important execution history
- ❌ Warning logged but no visibility

### After
- ✅ Trajectory tracking works correctly
- ✅ Environment captures complete execution history
- ✅ Better information (added status field)

## Prevention

**Defensive Programming:**

1. ✅ Used `hasattr()` to check attribute existence
2. ✅ Used `getattr()` with default value
3. ✅ Added safe string conversion with fallback to "N/A"

```python
# Safe attribute access
output_str = str(attempt.output)[:80] if hasattr(attempt, 'output') and attempt.output else "N/A"
```

## Related

- Environment Manager implementation
- Trajectory tracking enhancement
- `TaggedAttempt` dataclass structure

## Status

✅ **Fixed** - Trajectory tracking now works correctly with proper attribute access.

## Lesson Learned

**Always verify dataclass structure** before accessing attributes, especially when working with:
- DSPy Predictions
- Custom dataclasses
- Domain-specific attempt structures

**Use defensive programming:**
- `hasattr()` before access
- `getattr()` with defaults
- Try-except blocks for robustness
