# ADR: Return to Welcome Screen After Task Completion

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** UI flow after task completion

## Problem

After a task completes (when backend logs "🎯 FINAL SWARM OUTPUT"), the Electron UI remained in the workspace view showing the browser/agent views. This left the user in a "stuck" state with no clear indication that the task was done.

**User Requests:**
> "Once 🎯 FINAL SWARM OUTPUT ..... go back to googly eye view"
> "in googly eye, show whatever is the final output as agent answer"

## Solution

Automatically return to the **welcome screen** (googly eyes view) when the task completes.

### Implementation

#### 1. Backend Event

The backend already sends a `final_output` event via WebSocket when a task completes:

**File:** `uv/src/uv/services/task_service.py`

```python
logger.info(f"🎯 FINAL SWARM OUTPUT: {final_output}")

# Send via WebSocket
{
    "type": "final_output",
    "output": final_output,
    "success": success,
    ...
}
```

#### 2. Frontend Handler

Added handler for `final_output` event in WebSocket message handler:

**File:** `electron-app/src/renderer/js/app.js`

```javascript
handleWebSocketMessage(data) {
  const { type } = data;

  switch (type) {
    // ... other cases ...
    
    case 'final_output':
      console.log('🎯 Task completed! Returning to welcome screen...');
      this.returnToWelcomeScreen(data.output || data.final_output || 'Task completed successfully!');
      break;
  }
}
```

#### 3. Return to Welcome Method with Final Output Display

```javascript
returnToWelcomeScreen(finalOutput = null) {
  console.log('🏠 Returning to welcome screen...');
  
  const welcomeState = document.getElementById('welcome-state');
  const workspaceState = document.getElementById('workspace-state');
  const welcomeMessageText = document.querySelector('.welcome-message-text');
  
  if (welcomeState && workspaceState) {
    // Fade out workspace
    workspaceState.style.opacity = '0';
    
    setTimeout(() => {
      // Hide workspace, show welcome
      workspaceState.style.display = 'none';
      welcomeState.style.display = 'flex';
      
      // Update welcome message with final output
      if (welcomeMessageText && finalOutput) {
        welcomeMessageText.innerHTML = `
          <div style="margin-bottom: 12px; color: var(--accent-cyan); font-weight: 600;">✅ Task Completed!</div>
          <div style="color: var(--text-primary); line-height: 1.6;">${this.escapeHtml(finalOutput)}</div>
        `;
      }
      
      // Fade in welcome screen
      setTimeout(() => {
        welcomeState.style.opacity = '1';
      }, 50);
      
      // Reset workspace state for next task
      this.isWorkspaceVisible = false;
      
      console.log('✅ Returned to welcome screen with final output');
    }, 300);
  }
}
```

#### 4. Reset Welcome Message on New Task

When starting a new task, the welcome message is reset to the default greeting:

```javascript
async transformToWorkspace(message) {
  // Reset welcome message to default for next time
  if (welcomeMessageText) {
    welcomeMessageText.innerHTML = "Hello! I'm UV, your personal assistant. What would you like to accomplish today?";
  }
  
  // ... transition to workspace ...
}
```

## User Flow

### Before
```
1. User sends task
2. UI switches to workspace (browser/agent views)
3. Task completes → "🎯 FINAL SWARM OUTPUT"
4. UI stays in workspace ❌ (user stuck)
```

### After
```
1. User sends task
2. UI switches to workspace (browser/agent views)
3. Task completes → "🎯 FINAL SWARM OUTPUT"
4. UI automatically returns to welcome screen ✅
5. Welcome screen shows final output as agent answer ✅
6. User can send next task immediately
```

## Visual Transition

```
┌─────────────────────────────────────────┐
│ Workspace (Browser/Agent Views)         │
│                                         │
│ [Task running...]                       │
│                                         │
└─────────────────────────────────────────┘
                    ↓
            (Fade out 300ms)
                    ↓
┌─────────────────────────────────────────┐
│                                         │
│              👁️  👁️                     │
│                UV                       │
│      Your Personal AI Assistant         │
│                                         │
│  ✅ Task Completed!                     │
│  [Final output displayed here...]       │
│                                         │
│  [Input box ready for next task]        │
└─────────────────────────────────────────┘
```

## Benefits

✅ **Clear completion signal** - User knows task is done  
✅ **Shows final output** - Agent's answer displayed in welcome screen  
✅ **Ready for next task** - Welcome screen prompts for new input  
✅ **Smooth transition** - Fade animation feels natural  
✅ **No manual action** - Automatic return, no button click needed  
✅ **Clean state** - Workspace reset for next task  
✅ **Message reset** - Default greeting restored when new task starts  

## Edge Cases

1. **Multiple tasks in queue:** Each task completion triggers return to welcome
2. **WebSocket disconnected:** No return (user already knows something is wrong)
3. **Task fails:** Still returns to welcome (failure is logged elsewhere)

## Testing

1. **Send a task** (e.g., "Open Google")
2. **Wait for completion** (backend logs "🎯 FINAL SWARM OUTPUT")
3. **Expected:** UI fades out workspace, shows welcome screen with googly eyes
4. **Expected:** Console shows: `🎯 Task completed! Returning to welcome screen...`

## Related

- Welcome screen transition: `electron-app/src/renderer/js/app.js`
- Task service: `uv/src/uv/services/task_service.py`
- WebSocket events: `uv/src/uv/api/v1/websocket_agents.py`
