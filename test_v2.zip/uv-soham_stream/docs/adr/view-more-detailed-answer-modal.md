# ADR: View More Button with Detailed Answer Modal

**Date:** 2026-02-02  
**Status:** Accepted  
**Deciders:** A-Team (unanimous)

## Context

When tasks complete, users receive a brief message but the full detailed results (research findings, comparisons, data tables) are only visible in terminal logs that users cannot access.

Example: User asks for flight recommendations, gets "I have options ready" but can't see the actual flight details, prices, and comparisons.

## Decision

Implement a two-part response system:

1. **Short `user_message`** - Concise 2-3 sentence summary (always shown)
2. **Full `detailed_answer`** - Complete markdown breakdown (shown in modal on demand)

### Backend Implementation
- Added `detailed_answer: Optional[str]` to `UserCommunication` dataclass
- Added `detailed_answer` output field to `UserCommunicationSignature`
- Added `detailed_answer` to `SwarmResult` for data flow
- Conductor and task_service pass `detailed_answer` to frontend

### Frontend Implementation
- Added `#details-modal` with markdown-rendered content area
- "View Details" button appears when `detailed_answer` exists
- Simple regex-based markdown-to-HTML converter
- Modal with proper styling, scrolling, and close functionality

## Consequences

### Positive
- Users can access full research results and detailed breakdowns
- UX improved - brief summary by default, details on demand
- No heavy dependencies (no markdown library needed)
- Backwards compatible - old responses without `detailed_answer` work fine

### Negative
- Slightly more complex data structure
- Additional tokens for `detailed_answer` generation
- Simple markdown converter may not handle all edge cases

### Neutral
- Message storage now includes optional `detailed_answer` field
- Modal pattern already existed in codebase

## Related
- A-Team Review: `docs/review/A_TEAM_VIEW_MORE_DETAILED_ANSWER_REVIEW.md`
- Previous ADR: `docs/adr/user-communication-include-key-data.md`
