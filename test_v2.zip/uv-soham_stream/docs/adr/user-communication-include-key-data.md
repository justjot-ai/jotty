# ADR: User Communication Must Include Key Data for Information Tasks

**Date:** 2026-02-02  
**Status:** Accepted  
**Deciders:** A-Team (unanimous)

## Context

When users ask for information, recommendations, or research (e.g., "find flights from Delhi to Singapore"), the `UserCommunicationAgent` was generating vague responses like "I have recommendations ready" instead of including the actual findings.

**Example of the problem:**
- User asked: "Find flights from Delhi to Singapore for tomorrow night"
- Final output contained: "SQ403 (21:45), AI2380 (23:00), 5h 30m-6h 20m, direct flights"
- User message said: "I've researched your options and have 2-3 solid recommendations ready"

This defeats the purpose of user-friendly communication.

## Decision

### Fix 1: Increase Output Preview Limit
**File:** `Synapse/core/conductor.py:4625`  
**Change:** Increased `output_preview` from 500 to 2000 characters

The UserCommunicationAgent needs to see enough of the final output to extract key facts.

### Fix 2: Update Signature Instructions
**File:** `Synapse/signatures/user_communication_signatures.py`  
**Change:** Added explicit instructions for information tasks:

```
CRITICAL FOR INFORMATION TASKS: If the user asked for recommendations, options, 
data, or research, you MUST include the KEY FACTS in your message (names, prices, 
times, numbers, options). Don't say 'I have recommendations' - TELL them the 
recommendations.
```

Also added an example of a data-rich completion message.

## Consequences

### Positive
- User messages now include the actual data users asked for
- Better UX - users don't need to ask follow-up questions
- No additional API calls - just better prompting

### Negative
- Slightly more tokens in the communication context (1500 more chars max)
- User messages may be slightly longer (but still 2-3 sentences)

### Neutral
- No breaking changes to existing behavior
- UI action tasks unchanged (still say "opened WhatsApp" etc.)

## Related
- A-Team Review: `docs/review/A_TEAM_USER_MESSAGE_DETAIL_FIX_REVIEW.md`
