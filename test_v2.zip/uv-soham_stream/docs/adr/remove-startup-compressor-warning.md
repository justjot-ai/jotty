# ADR: Remove Startup Compressor Warning

**Status:** Implemented  
**Date:** 2026-01-31  
**Context:** Unnecessary warning polluting startup logs

---

## Problem

Every time the system starts, a warning appears:

```
WARNING:root:AgenticCompressor not available - compression retry disabled
```

This warning appears even though:
- ✅ The system works fine without AgenticCompressor
- ✅ Compression retry has a fallback (simple truncation)
- ✅ The feature is optional, not critical

**Impact:**
- Pollutes startup logs
- Makes it look like something is broken (it's not)
- Distracts from actual errors/warnings

---

## Root Cause

The warning was logged at **module-level** in `surface/src/surface/utils/compression_retry.py`:

```python
try:
    from core.agentic_compressor import AgenticCompressor
    COMPRESSOR_AVAILABLE = True
except ImportError:
    COMPRESSOR_AVAILABLE = False
    logging.warning("AgenticCompressor not available - compression retry disabled")  # ❌ Logs on import
```

When the module is imported (even indirectly via `surface.utils`), the warning is triggered immediately.

---

## Solution

### Commented Out Module-Level Warning

```python
try:
    from core.agentic_compressor import AgenticCompressor
    COMPRESSOR_AVAILABLE = True
except ImportError:
    COMPRESSOR_AVAILABLE = False
    # Compression retry will fall back to simple truncation if needed
    # logging.warning("AgenticCompressor not available - compression retry disabled")
```

### Rationale

1. **Silent Graceful Degradation**: AgenticCompressor is an optional enhancement, not a requirement
2. **Warning Still Available**: The `CompressionRetryHandler.__init__()` still logs a warning when instantiated without compressor
3. **Clean Startup**: Only shows warnings for actual issues, not optional features

---

## Behavior

### Before
```
$ ./scripts/run_solve_task.sh "task"
WARNING:root:AgenticCompressor not available - compression retry disabled  ← Distracting
2026-01-31 11:05:27,281 - surface.tools.browser_tools - INFO - 🌐 Shared browser instance set
...
```

### After
```
$ ./scripts/run_solve_task.sh "task"
2026-01-31 11:05:27,281 - surface.tools.browser_tools - INFO - 🌐 Shared browser instance set  ← Clean!
...
```

---

## Compression Still Works

### Fallback Behavior

If `AgenticCompressor` is not available and a context length error occurs:

```python
def _compress_simple_truncate(self, text: str, target_tokens: int) -> str:
    """Fallback: Simple truncation if compressor not available."""
    logger.warning("⚠️  No compressor available - using simple truncation")
    # Estimate tokens (rough: 4 chars = 1 token)
    target_chars = target_tokens * 4
    if len(text) > target_chars:
        return text[:target_chars] + "\n\n[Truncated due to length]"
    return text
```

The warning is logged **only when compression is actually needed**, not at startup.

---

## When Warnings Are Still Logged

Warnings are still appropriately logged when:

1. **Handler Instantiated Without Compressor:**
   ```python
   handler = CompressionRetryHandler(lm=None)
   # ⚠️  AgenticCompressor not available - falling back to simple truncation
   ```

2. **Compression Actually Needed:**
   ```python
   # Context length error occurs
   # ⚠️  No compressor available - using simple truncation
   ```

This is **good** - warnings appear when the feature is actually being used, not just imported.

---

## Files Changed

### `surface/src/surface/utils/compression_retry.py`

**Line 25:** Commented out module-level warning

**Before:**
```python
except ImportError:
    COMPRESSOR_AVAILABLE = False
    logging.warning("AgenticCompressor not available - compression retry disabled")
```

**After:**
```python
except ImportError:
    COMPRESSOR_AVAILABLE = False
    # Compression retry will fall back to simple truncation if needed
    # logging.warning("AgenticCompressor not available - compression retry disabled")
```

---

## Benefits

### ✅ Clean Startup Logs

No unnecessary warnings on startup - only real issues are highlighted.

### ✅ Graceful Degradation

System works fine with or without AgenticCompressor - it's an optional enhancement.

### ✅ Warnings When Needed

Warnings still logged when compression is actually attempted without compressor.

### ✅ Better User Experience

Users aren't confused by warnings about optional features they're not using.

---

## Alternative Considered

### Option: Use `logger.debug()` Instead

```python
except ImportError:
    COMPRESSOR_AVAILABLE = False
    logger.debug("AgenticCompressor not available - using fallback compression")
```

**Rejected because:**
- Even debug logs pollute startup in normal operation
- Users running with debug enabled want to see actual debugging info, not import status

---

## Future Enhancements

If AgenticCompressor becomes a **required** feature (not optional), then we should:
1. Add it to `requirements.txt` or `pyproject.toml`
2. Fail fast at startup with a clear error message
3. Provide installation instructions

But currently it's optional, so silent fallback is appropriate.

---

## Related

- `docs/adr/automatic-compression-retry-on-context-errors.md` - Original compression retry implementation
- `docs/adr/built-in-automatic-compression.md` - Built-in compression design

---

## Summary

Removed unnecessary module-level warning about AgenticCompressor not being available. The compressor is an optional enhancement with a working fallback, so startup should be silent. Warnings are still logged when compression is actually needed and the compressor is unavailable.
