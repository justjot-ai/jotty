# ADR: Fix Selenium Missing - Virtual Environment Issue

**Date:** 2026-01-31  
**Status:** Fixed  
**Context:** "No module named 'selenium'" error when starting new tasks

## Problem

After fixing the TODO display issue, new tasks were failing with:
```
Error: No module named 'selenium'
```

User noted: "it was working earlier....check what changed"

## Root Cause

The server was running with **system Python** instead of **Poetry virtual environment Python**:

- ❌ System Python: `/opt/homebrew/bin/python3` (no selenium installed)
- ✅ Venv Python: `.venv/bin/python3` (selenium 4.40.0 installed)

**What changed:** When I manually restarted the server to fix the TODO display issue, I used:
```bash
python3 surface_synapse/server.py
```

This used the system Python instead of the venv Python.

## Investigation

```bash
# Selenium IS in the venv
$ .venv/bin/python3 -c "import selenium; print(selenium.__version__)"
Selenium 4.40.0 found in venv

# But server was using system Python
$ ps aux | grep server.py
/opt/homebrew/Cellar/python@3.13/.../Python surface_synapse/server.py
```

## Solution

Restart server using Poetry's virtual environment:

```bash
cd /Users/anshulchauhan/Tech/term
kill <old_server_pid>
poetry run python surface_synapse/server.py > logs/backend.log 2>&1 &
```

## Evidence of Fix

**Before:**
- ❌ Log: `Error: No module named 'selenium'`
- Browser tools: NOT available

**After:**  
- ✅ Log: `✅ Browser screenshot streaming enabled`
- Browser tools: Available
- Server can import selenium successfully

## Lesson Learned

The project uses **Poetry for dependency management**. The `run_electron_app.sh` script correctly uses:
```bash
poetry run python surface_synapse/server.py
```

Always use `poetry run` when manually starting the server to ensure the virtual environment is active.

## Files Referenced

- `pyproject.toml`: Defines `selenium = ">=4.0.0"` dependency
- `scripts/run_electron_app.sh`: Shows correct way to start server (line 65)
- `logs/backend.log`: Server startup logs

## Prevention

When restarting the server manually:
1. Use `poetry run python` (not just `python3`)
2. Or activate venv first: `source .venv/bin/activate`
3. Or use the provided script: `./scripts/run_electron_app.sh`
