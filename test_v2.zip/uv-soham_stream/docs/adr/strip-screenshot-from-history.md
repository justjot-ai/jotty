# ADR: Strip Screenshot Data from Tool Results in History

## Status
Accepted

## Context
The BrowserExecutor agent was hitting "Input is too long for requested model" errors from AWS Bedrock when taking screenshots during browser automation tasks. Each `electron_screenshot` call returns ~100KB of base64 encoded PNG data, which accumulates in DSPy's conversation history with each tool call.

## Decision
Strip screenshot/image base64 data from tool results before they're added to the conversation history. The actual screenshot is still captured and returned by the tool, but the large base64 string is replaced with a placeholder message before being stored in history.

## Implementation
Added `_strip_screenshot_from_result()` method in `base_agent.py` that:
1. Detects keys containing screenshot data (`screenshot`, `image`, `base64`, `image_data`, `screenshot_data`)
2. Replaces large base64 strings (>1000 chars) with a placeholder: `[screenshot captured - X chars stripped from history]`
3. Called in `_create_bound_tools()` before converting result to string for history

## Consequences
**Positive:**
- Prevents context overflow errors during multi-step browser automation
- Agents can still take unlimited screenshots without hitting token limits
- Minimal performance impact (simple string length check)

**Negative:**
- Model cannot "see" previous screenshots in conversation history
- If model needs to reference previous screenshot content, it must re-take the screenshot

**Mitigations:**
- Model can always take a new screenshot if visual verification is needed
- The placeholder message indicates a screenshot was captured
