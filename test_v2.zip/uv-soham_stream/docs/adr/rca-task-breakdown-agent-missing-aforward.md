# RCA: TaskBreakdownAgent Missing aforward Method

**Date**: 2026-02-05  
**Status**: ✅ Implemented  
**Issue**: `❌ Re-evaluation failed: 'TaskBreakdownAgent' object has no attribute 'aforward'`

## Context

During task re-evaluation, the conductor attempts to call `aforward()` on `TaskBreakdownAgent`, but this method doesn't exist:

```
2026-02-05 17:14:06.255 | ERROR | Synapse.core.conductor:5871 | ❌ Re-evaluation failed: 'TaskBreakdownAgent' object has no attribute 'aforward'
```

**Location**: `Synapse/core/conductor.py` line 5799

```python
task_dag = await self.task_breakdown_agent.aforward(implementation_plan=enhanced_goal)
```

## 5 Whys Root Cause Analysis

### Why 1: Why is aforward() being called?
**Answer**: The conductor code is trying to use async/await pattern to call TaskBreakdownAgent, expecting an async generator method.

### Why 2: Why doesn't the method exist?
**Answer**: `TaskBreakdownAgent` only has a synchronous `forward()` method, not an async `aforward()` method.

### Why 3: Why is there a mismatch between expected async and actual sync method?
**Answer**: The conductor was refactored to use async patterns (likely for streaming/yielding), but TaskBreakdownAgent wasn't updated to match this pattern.

### Why 4: Why wasn't TaskBreakdownAgent updated to be async?
**Answer**: TaskBreakdownAgent inherits from `dspy.Module` which uses synchronous `forward()` by default. Converting to async requires wrapping or creating an async version.

### Why 5: Why wasn't this caught during refactoring?
**Answer**: The re-evaluation code path may not be frequently tested, or the refactoring was done incrementally without updating all dependent code, or tests don't cover this specific scenario.

## Root Cause

**The root cause is**: API mismatch - the conductor expects async `aforward()` method but TaskBreakdownAgent only provides synchronous `forward()` method.

## Current Implementation

**In `Synapse/agents/task_breakdown_agent.py`** (line 54):
```python
def forward(self, implementation_plan: str) -> TaskDAG:
    """Break down implementation plan into executable DAG workflow."""
    # Synchronous implementation
```

**In `Synapse/core/conductor.py`** (line 5799):
```python
task_dag = await self.task_breakdown_agent.aforward(implementation_plan=enhanced_goal)
# Expects async method that doesn't exist
```

**Comparison with BaseSwarmAgent**:
`BaseSwarmAgent` (in `surface/src/surface/agents/base_agent.py`) has both `forward()` and `aforward()` methods, but `TaskBreakdownAgent` doesn't inherit from it.

## Suggested Fixes

### Fix 1: Use Synchronous forward() Method (Recommended)
**Location**: `Synapse/core/conductor.py` (line 5799)

```python
# Change from:
task_dag = await self.task_breakdown_agent.aforward(implementation_plan=enhanced_goal)

# To:
task_dag = self.task_breakdown_agent.forward(implementation_plan=enhanced_goal)
```

**Note**: Remove `await` since `forward()` is synchronous.

### Fix 2: Add aforward() Method to TaskBreakdownAgent
**Location**: `Synapse/agents/task_breakdown_agent.py`

```python
async def aforward(self, implementation_plan: str) -> TaskDAG:
    """
    Async version of forward() for compatibility with async conductor.
    
    Args:
        implementation_plan: Complete implementation plan as string
    
    Returns:
        TaskDAG: Directed Acyclic Graph of tasks with dependencies
    """
    # Run synchronous forward in executor to avoid blocking
    import asyncio
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, self.forward, implementation_plan)
```

### Fix 3: Make TaskBreakdownAgent Async-Compatible
**Location**: `Synapse/agents/task_breakdown_agent.py`

Wrap the entire forward logic in async:

```python
async def aforward(self, implementation_plan: str) -> TaskDAG:
    """Async version that yields progress updates."""
    logger.info("[TASK BREAKDOWN] Starting plan analysis...")
    
    # Step 1: Extract tasks
    logger.info("[TASK BREAKDOWN] Step 1: Extracting granular tasks...")
    tasks_response = await asyncio.to_thread(
        self.extract_tasks, 
        implementation_plan=implementation_plan
    )
    tasks_list = tasks_response.tasks_list
    
    # Step 2: Identify dependencies
    logger.info("[TASK BREAKDOWN] Step 2: Identifying dependencies...")
    deps_response = await asyncio.to_thread(
        self.identify_dependencies,
        tasks_list=tasks_list
    )
    dependencies_graph = deps_response.dependencies_graph
    
    # Step 3: Optimize workflow
    logger.info("[TASK BREAKDOWN] Step 3: Optimizing workflow...")
    tasks_with_deps = f"TASKS:\n{tasks_list}\n\nDEPENDENCIES:\n{dependencies_graph}"
    workflow_response = await asyncio.to_thread(
        self.optimize_workflow,
        tasks_with_dependencies=tasks_with_deps
    )
    optimized_workflow = workflow_response.optimized_workflow
    
    # Step 4: Parse and create DAG (synchronous, fast)
    logger.info("[TASK BREAKDOWN] Step 4: Building DAG structure...")
    dag = self._build_dag(tasks_list, dependencies_graph, optimized_workflow, implementation_plan)
    
    # Step 5: Validate DAG
    is_valid, errors = dag.validate()
    if not is_valid:
        logger.warning(f"[TASK BREAKDOWN] DAG validation issues: {errors}")
    
    return dag
```

## Implementation Priority

1. **High**: Fix 1 (Use Synchronous Method) - Simplest fix, TaskBreakdownAgent doesn't need to be async
2. **Medium**: Fix 2 (Add Async Wrapper) - Good if we want async compatibility without refactoring
3. **Low**: Fix 3 (Full Async Refactor) - Only if we need streaming/progress updates

## Consequences

### Positive
- ✅ Re-evaluation will work correctly
- ✅ Task breakdown will complete successfully
- ✅ No blocking issues if using sync method
- ✅ Simpler code if we don't need async

### Considerations
- ⚠️ If conductor is async, calling sync method may block event loop
- ⚠️ May want async if task breakdown takes long time
- ⚠️ Need to check if other call sites also expect async

## Testing

1. **Unit Test**: Call `forward()` directly → Should return TaskDAG
2. **Integration Test**: Run conductor re-evaluation → Should complete without AttributeError
3. **Performance Test**: Verify sync call doesn't block async event loop significantly

## Files to Modify

- `Synapse/core/conductor.py` - Change `aforward()` to `forward()` (line 5799)
- `Synapse/agents/task_breakdown_agent.py` - Optionally add `aforward()` method if async needed
