# ADR: Remove Browser Button and Fix Placeholder Hiding

**Status:** Implemented  
**Date:** 2026-02-01  
**Context:** Browser view UI improvements

## Problem

1. **Browser button unnecessary** - Since browser view shows by default, the toolbar button to manually show it is redundant
2. **Placeholder not hiding** - The "Connecting to Chrome..." placeholder wasn't being hidden after CDP connected, even though screenshots were being captured

**User Feedback:**
> "i see connecting to browser only......but when i click browser button screenshot open.......remove toolbar button and also fix this browser"

## Root Cause

The placeholder element (`this.placeholderEl`) was being set correctly, but there was no error handling to verify it existed before trying to hide it. Screenshots were working fine, but the placeholder was overlaying them.

## Solution

### 1. Removed Browser Button

**File:** `electron-app/src/renderer/index.html`

```html
<!-- Removed this entire button -->
<button class="toolbar-btn" id="browser-view-btn" data-cmd="/browser">
  Browser
</button>
```

### 2. Removed `/browser` Command

**File:** `electron-app/src/renderer/js/app.js`

```javascript
// Removed from handleCommand():
case '/browser':
  this.showBrowserView();
  break;

// Removed entire method:
showBrowserView() { ... }

// Removed from help text:
/browser   Show browser view
```

### 3. Added Placeholder Hiding Error Handling

**File:** `electron-app/src/renderer/js/agent-view-manager.js`

**Before:**
```javascript
async onCdpConnected(browser_version) {
  console.log('✅ CDP connected successfully');
  this.cdpConnected = true;
    
  // Hide placeholder
  this.placeholderEl.style.display = 'none';
  
  // ... rest of code
}
```

**After:**
```javascript
async onCdpConnected(browser_version) {
  console.log('✅ CDP connected successfully');
  this.cdpConnected = true;
    
  // Hide placeholder with error handling
  if (this.placeholderEl) {
    console.log('🎨 Hiding placeholder...');
    this.placeholderEl.style.display = 'none';
    console.log('✅ Placeholder hidden');
  } else {
    console.error('❌ Placeholder element not found!');
  }
  
  // ... rest of code
}
```

## Benefits

✅ **Cleaner toolbar** - No redundant browser button  
✅ **Better UX** - Browser view shows automatically, no manual action needed  
✅ **Better debugging** - Logs confirm placeholder hiding  
✅ **Error handling** - Graceful failure if placeholder element missing  
✅ **Screenshots visible** - Placeholder no longer overlays canvas  

## Testing

1. **Restart Electron**
2. **Expected:** Browser view shows immediately with WhatsApp
3. **Expected:** No "Connecting to Chrome..." placeholder
4. **Expected:** Screenshots visible on canvas
5. **Expected:** No browser button in toolbar
6. **Expected:** Console shows: `🎨 Hiding placeholder...` and `✅ Placeholder hidden`

## Console Output

**Successful CDP connection:**
```
✅ CDP connected successfully
🎨 Hiding placeholder...
✅ Placeholder hidden
📸 Capturing screenshot...
✅ Screenshot captured, size: 100672 bytes
🖼️ Image loaded, rendering to canvas...
```

## Related

- Browser view initialization: `electron-app/src/renderer/js/agent-view-manager.js`
- Toolbar: `electron-app/src/renderer/index.html`
- Command handling: `electron-app/src/renderer/js/app.js`
