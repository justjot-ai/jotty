# RCA: TODO Tracking Type Mismatch Error

**Date**: 2026-02-05  
**Status**: ✅ Implemented  
**Issue**: `Failed to track TODO creation in environment: sequence item 0: expected str instance, Task found`

## Context

During TODO creation tracking, the code attempts to pass a list containing Task objects to a function expecting strings:

```
2026-02-05 16:52:25.145 | WARNING | Synapse.core.conductor:5095 | Failed to track TODO creation in environment: sequence item 0: expected str instance, Task found
```

**Location**: `Synapse/core/conductor.py` line 5095

## 5 Whys Root Cause Analysis

### Why 1: Why is the type mismatch occurring?
**Answer**: The code is trying to join Task objects as strings, but Task objects need to be converted to strings first.

### Why 2: Why are Task objects being passed instead of strings?
**Answer**: The code is iterating over `task_dag.tasks.items()` which returns Task objects, and trying to use them directly in string operations.

### Why 3: Why isn't the code converting Task objects to strings?
**Answer**: The code builds a `todo_structure` list by appending Task objects or their attributes, but somewhere in the process, Task objects are being passed where strings are expected.

### Why 4: Why is the join() operation receiving Task objects?
**Answer**: The `todo_structure` list likely contains Task objects instead of strings, and when `"\n".join(todo_structure)` is called, Python expects strings but finds Task objects.

### Why 5: Why wasn't this caught during development/testing?
**Answer**: The TODO tracking code path may not be frequently executed, or tests don't cover this specific scenario, or the error is caught and logged as a warning without failing.

## Root Cause

**The root cause is**: Type mismatch in TODO structure building - Task objects are being added to a list that's later joined as strings, without proper string conversion.

## Current Implementation

**In `Synapse/core/conductor.py`** (lines 5065-5096):

```python
todo_structure = []
todo_structure.append("✅ TODO creation complete:")
todo_structure.append(f"  - Tasks created: {len(task_dag.tasks)}")
# ... more string appends ...

# Add each task with full details
for task_id, task in task_dag.tasks.items():  # task is a Task object
    actor = executable_dag.assignments.get(task_id)
    actor_name = actor.name if actor else "Unassigned"
    todo_structure.append(f"\n  **Task {task_id}:** {task.name}")  # ✅ String
    todo_structure.append(f"    - Actor: {actor_name}")  # ✅ String
    todo_structure.append(f"    - Type: {task.task_type.value}")  # ✅ String
    todo_structure.append(f"    - Description: {task.description}")  # ✅ String
    if task.depends_on:
        todo_structure.append(f"    - Dependencies: {', '.join(task.depends_on)}")  # ✅ String

# Later:
async for event in self.env_manager.add_to_current_env_stream("\n".join(todo_structure)):
    # If todo_structure contains non-strings, join() will fail
```

The issue is likely in the `add_to_current_env_stream()` method or in how `task.depends_on` is handled if it contains Task objects instead of strings.

## Suggested Fixes

### Fix 1: Ensure All List Items Are Strings (Recommended)
**Location**: `Synapse/core/conductor.py` (lines 5074-5083)

```python
# Add each task with full details
for task_id, task in task_dag.tasks.items():
    actor = executable_dag.assignments.get(task_id)
    actor_name = actor.name if actor else "Unassigned"
    
    # Ensure all values are strings
    task_name = str(task.name) if task.name else "Unnamed"
    task_type_value = str(task.task_type.value) if hasattr(task.task_type, 'value') else str(task.task_type)
    task_description = str(task.description) if task.description else "No description"
    
    todo_structure.append(f"\n  **Task {task_id}:** {task_name}")
    todo_structure.append(f"    - Actor: {actor_name}")
    todo_structure.append(f"    - Type: {task_type_value}")
    todo_structure.append(f"    - Description: {task_description}")
    
    if task.depends_on:
        # Ensure dependencies are strings
        deps_list = [str(dep) for dep in task.depends_on]
        todo_structure.append(f"    - Dependencies: {', '.join(deps_list)}")
```

### Fix 2: Convert Task Objects to Strings Explicitly
**Location**: `Synapse/core/conductor.py` (line 5090)

```python
# Before joining, ensure all items are strings
todo_structure_str = [str(item) for item in todo_structure]
async for event in self.env_manager.add_to_current_env_stream("\n".join(todo_structure_str)):
    yield event
```

### Fix 3: Fix add_to_current_env_stream to Handle Mixed Types
**Location**: `Synapse/core/environment_manager.py` (if that's where the error occurs)

```python
def add_to_current_env_stream(self, content):
    """Add content to environment, handling mixed types."""
    if isinstance(content, list):
        # Convert all items to strings
        content = "\n".join(str(item) for item in content)
    elif not isinstance(content, str):
        content = str(content)
    
    # Proceed with string content
    ...
```

## Implementation Priority

1. **High**: Fix 1 (Ensure All Strings) - Prevents the issue at the source
2. **Medium**: Fix 2 (Convert Before Join) - Defensive programming
3. **Low**: Fix 3 (Handle in Manager) - May hide other issues

## Consequences

### Positive
- ✅ TODO tracking will work correctly
- ✅ No type errors when joining strings
- ✅ Environment context will be properly updated
- ✅ More robust error handling

### Considerations
- ⚠️ Need to verify task.depends_on contains strings, not Task objects
- ⚠️ May want to add type hints to prevent future issues
- ⚠️ Consider using f-strings consistently for all formatting

## Testing

1. **Unit Test**: Build todo_structure with Task objects → Should convert to strings
2. **Unit Test**: Join todo_structure → Should not raise TypeError
3. **Integration Test**: Create TODO with dependencies → Should track correctly
4. **Type Test**: Verify task.depends_on contains strings, not Task objects

## Files to Modify

- `Synapse/core/conductor.py` - Fix string conversion in TODO tracking (lines 5074-5090)
- Verify `task.depends_on` contains strings in Task entity definition

## Additional Notes

This error suggests:
1. Task.depends_on might contain Task objects instead of task_id strings
2. Need to verify Task entity definition
3. Consider adding type validation to Task entity
4. Add unit tests for TODO structure building
