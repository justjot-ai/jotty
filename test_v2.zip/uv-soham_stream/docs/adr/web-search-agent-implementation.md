# ADR: WebSearch Agent Implementation

**Date:** 2026-01-30  
**Status:** Implemented

## Context

Following the successful implementation of `BrowserExecutorAgent` and `TerminalExecutorAgent`, we need a specialized agent for web search and research tasks. Many workflows require systematic information retrieval, website scraping, research, and data gathering from the web.

### User Request

> "@surface/src/surface/tools/web_search.py also create a new agent for these tools"

## Decision

**Create a new `WebSearchAgent`** similar to BrowserExecutor and TerminalExecutor but specialized for web search and content scraping using the Serper API.

### Why This Approach?

1. **Consistency** - Follows the same pattern as other executor agents
2. **Specialization** - Focused tools for web search and scraping only
3. **Automatic Features** - Compression retry, file output
4. **Clear Purpose** - Dedicated agent for research and information retrieval
5. **No Tool Overlap** - Web search tools only (no browser, no terminal)

## Implementation

### 1. Created WebSearchSignature

**File:** `surface/src/surface/signatures/web_search_signature.py`

```python
class WebSearchSignature(dspy.Signature):
    """Execute web search and content scraping tasks: 
    information retrieval, research, data gathering."""

    instruction: str = dspy.InputField(
        desc="The web search or research task to complete"
    )

    terminal_state: str = dspy.InputField(
        desc="Current terminal output and state (if relevant)"
    )

    conversation_history: str = dspy.InputField(
        desc="Previous conversation context",
        default=""
    )

    analysis: str = dspy.OutputField(
        desc="Analysis of the research task and requirements"
    )

    plan: str = dspy.OutputField(
        desc="Step-by-step plan for search and research strategy"
    )

    commands: str = dspy.OutputField(
        desc="JSON array of web search commands to execute"
    )

    task_complete: bool = dspy.OutputField(
        desc="True when research task is fully completed"
    )

    reasoning: str = dspy.OutputField(
        desc="Technical reasoning for the research approach"
    )

    collaboration_actions: str = dspy.OutputField(
        desc="JSON array of collaboration actions",
        default="[]"
    )
```

### 2. Created WebSearchAgent

**File:** `surface/src/surface/agents/web_search.py`

```python
class WebSearchAgent(BaseSwarmAgent):
    """WebSearch: Web search and content scraping specialist."""

    AGENT_NAME = "WebSearch"
    SIGNATURE_CLASS = WebSearchSignature
    
    TOOLS = [
        web_search,
        scrape_website
    ]
```

**Tools Available:**
- `web_search` - Search the web using Serper API (Google search results)
- `scrape_website` - Scrape website content using Serper API (markdown format)

### 3. Comprehensive System Prompt

The agent has extensive guidance on:

**Research Capabilities:**
- Web search and information retrieval
- Website content scraping and extraction
- Research and fact-finding
- Data gathering from public sources
- Competitive intelligence
- News and trend monitoring
- Academic and technical research
- Market research and analysis

**Search Query Strategies:**
```python
# Specific: precise keywords
"Python asyncio best practices 2024"

# Operators: quotes, exclusions
'"exact phrase" -unwanted'

# Context: relevant details
"machine learning image classification tutorial"

# Timely: date range
"AI developments January 2024"

# Source-specific: include site
"FastAPI authentication site:fastapi.tiangolo.com"
```

**Research Approaches:**

1. **Quick Fact-Finding:**
   - Single targeted search
   - Review top 3-5 results
   - Extract from snippets

2. **Deep Research:**
   - Multiple search queries
   - Identify 5-10 sources
   - Scrape each source
   - Extract detailed info
   - Synthesize summary

3. **Comparative Analysis:**
   - Search each item
   - Search "X vs Y"
   - Scrape comparisons
   - Extract pros/cons
   - Create structured comparison

4. **News/Trend Monitoring:**
   - Search with recent context
   - Focus on news sources
   - Scrape latest articles
   - Summarize developments

5. **Verification:**
   - Search claim
   - Check multiple sources
   - Look for consensus
   - Assess credibility

### 4. Automatic Features

Like BrowserExecutor and TerminalExecutor, WebSearchAgent includes:

#### Compression Retry
- Automatic handling of context length errors
- Intelligent compression using AgenticCompressor
- Trajectory preservation across retries
- Up to 3 retry attempts

#### File Output
- Instructions saved to timestamped files
- Output saved in both TXT and JSON formats
- Working directory: `surface/working/websearch_outputs/`

### 5. Example Implementation

**File:** `surface/examples/example_web_search_simple.py`

```python
from surface.agents.web_search import WebSearchAgent

# Configure DSPy
dspy.settings.configure(lm=dspy_lm)

# Create agent
agent = WebSearchAgent(max_iters=50)

# Research instruction
instruction = """
Research the latest developments in Claude AI:
1. Search for recent news about Anthropic's Claude AI
2. Find information about the latest Claude model
3. What are the key features and capabilities?
4. How does it compare to GPT-4?
5. Provide a comprehensive summary with sources
"""

# Execute - requires SERPER_API_KEY
result = agent(
    instruction=instruction,
    terminal_state="",
    conversation_history=""
)
```

**Output files:**
- `instruction_TIMESTAMP.txt` - Saved instruction
- `output_TIMESTAMP.txt` - Human-readable output
- `output_TIMESTAMP.json` - Structured JSON output

### 6. Updated Exports

**`surface/src/surface/signatures/__init__.py`:**
```python
from .web_search_signature import WebSearchSignature

__all__ = [
    # ... other signatures ...
    "WebSearchSignature"
]
```

**`surface/src/surface/agents/__init__.py`:**
```python
# WebSearch is always available (uses standard http.client)
try:
    from .web_search import WebSearchAgent
    _WEB_SEARCH_AVAILABLE = True
except ImportError:
    WebSearchAgent = None
    _WEB_SEARCH_AVAILABLE = False

if _WEB_SEARCH_AVAILABLE:
    __all__.append("WebSearchAgent")
```

## Benefits

### 1. Specialized Research Automation

**Before:**
```python
# CodeMaster, DataMind had web search + other tools
# Generic agents for various tasks
```

**After:**
```python
# WebSearchAgent has ONLY web search tools
# Focused on research and information retrieval
```

### 2. Clear Separation of Concerns

| Agent | Tools | Purpose |
|-------|-------|---------|
| **WebSearchAgent** | Web search only | Research, information retrieval |
| **BrowserExecutor** | Browser tools only | Web automation, interaction |
| **TerminalExecutor** | Terminal tools only | Command execution |
| **CodeMaster** | Terminal + Web | General coding |

### 3. Automatic Features

All built-in, no configuration:
- ✅ Compression retry
- ✅ File output
- ✅ Trajectory preservation

### 4. Consistent Pattern

Same structure as other executors:
- Signature with structured inputs/outputs
- Specialized system prompt
- Tool-specific focus
- Example files
- Comprehensive documentation

## API Requirements

### Serper API Key

WebSearchAgent requires a **SERPER_API_KEY** environment variable:

```bash
# Get free API key
# Visit https://serper.dev and sign up

# Set environment variable
export SERPER_API_KEY='your_api_key_here'

# Or add to ~/.bashrc or ~/.zshrc
echo 'export SERPER_API_KEY="your_key"' >> ~/.bashrc
```

**Free tier includes:**
- 2,500 searches per month
- Fast Google search results
- Website scraping
- No credit card required

### API Features

**web_search:**
- Returns Google search results
- Organic results with titles, snippets, URLs
- Answer boxes, knowledge graphs
- Related searches
- Geo-location support (country codes)

**scrape_website:**
- Returns website content in markdown
- Clean, structured text
- Handles JavaScript-rendered pages
- Full page extraction

## Usage Examples

### Simple Fact Lookup

```python
from surface.agents.web_search import WebSearchAgent

agent = WebSearchAgent(max_iters=50)

result = agent(
    instruction="What is the latest version of Python?",
    terminal_state="",
    conversation_history=""
)
```

### Deep Research

```python
instruction = """
Research Python async/await best practices:
1. Search for authoritative guides
2. Scrape official documentation
3. Find real-world examples
4. Summarize key recommendations
"""

result = agent(instruction=instruction, terminal_state="")
```

### Comparative Analysis

```python
instruction = """
Compare React vs Vue for web development:
1. Search for comparison articles
2. Scrape technical details
3. Extract pros and cons
4. Create structured comparison
5. Cite sources
"""

result = agent(instruction=instruction, terminal_state="")
```

### News Monitoring

```python
instruction = """
Latest AI news from January 2024:
1. Search for recent AI developments
2. Focus on major announcements
3. Scrape news articles
4. Summarize key events with dates
"""

result = agent(instruction=instruction, terminal_state="")
```

## Comparison: WebSearch vs Other Agents

| Aspect | WebSearchAgent | BrowserExecutor | TerminalExecutor |
|--------|----------------|-----------------|------------------|
| **Primary Tools** | Serper API | Selenium browser | pexpect terminal |
| **Tool Count** | 2 tools | 25+ tools | 5 tools |
| **Use Case** | Research, search | Web automation | Commands, scripts |
| **Dependencies** | None (http.client) | selenium | pexpect |
| **API Key** | SERPER_API_KEY | None | None |
| **System Deps** | None | Browser drivers | None |
| **Compression** | ✅ Yes | ✅ Yes | ✅ Yes |
| **File Output** | ✅ Yes | ✅ Yes | ✅ Yes |

## Testing

### Run Test Suite

```bash
cd /Users/anshulchauhan/Tech/term

# Run tests
poetry run python tests/test_web_search_agent.py
```

### Expected Output

```
================================================================================
WEB SEARCH AGENT TEST SUITE
================================================================================

Test: Import WebSearchAgent
--------------------------------------------------------------------------------
✅ WebSearchAgent imported successfully

Test: Import WebSearchSignature
--------------------------------------------------------------------------------
✅ WebSearchSignature imported successfully

Test: Web Search Tools Available
--------------------------------------------------------------------------------
✅ All web search tools imported successfully
   - web_search
   - scrape_website

Test: Agent Instantiation
--------------------------------------------------------------------------------
✅ WebSearchAgent instantiated correctly
   Agent name: WebSearch
   Tools: web_search, scrape_website

Test: System Prompt Check
--------------------------------------------------------------------------------
✅ System prompt is comprehensive
   Prompt length: 5930 characters
   All required sections present: 11

Test: Module Exports
--------------------------------------------------------------------------------
✅ WebSearchSignature exported from signatures module
✅ WebSearchAgent exported from agents module

Test: SERPER_API_KEY Check
--------------------------------------------------------------------------------
⚠️  SERPER_API_KEY is not set
   Agent will fail on actual searches
   Set with: export SERPER_API_KEY='your_key_here'

================================================================================
TEST RESULTS SUMMARY
================================================================================
✅ PASS: Import WebSearchAgent
✅ PASS: Import WebSearchSignature
✅ PASS: Web Search Tools Available
✅ PASS: Agent Instantiation
✅ PASS: System Prompt Check
✅ PASS: Module Exports
✅ PASS: SERPER_API_KEY Check

Total: 7/7 tests passed

🎉 ALL TESTS PASSED!
```

## Implementation Checklist

- ✅ Created WebSearchSignature
- ✅ Created WebSearchAgent with comprehensive system prompt
- ✅ Configured web search tools (2 tools)
- ✅ Inherits compression retry from BaseSwarmAgent
- ✅ Created example_web_search_simple.py
- ✅ Updated signatures/__init__.py
- ✅ Updated agents/__init__.py
- ✅ Created test suite
- ✅ Created ADR documentation
- ✅ Documented usage examples
- ✅ Tested basic functionality

## Future Enhancements

### Potential Improvements

1. **Enhanced Search Strategies**
   - Image search
   - Video search
   - Academic paper search
   - Patent search

2. **Advanced Parsing**
   - Structured data extraction
   - Table parsing
   - PDF content extraction
   - Code snippet extraction

3. **Result Filtering**
   - Date range filtering
   - Domain filtering
   - Content type filtering
   - Language filtering

4. **Caching**
   - Cache search results
   - Cache scraped content
   - Reduce API calls

5. **Multi-source Aggregation**
   - Combine results from multiple searches
   - Deduplicate information
   - Rank by relevance

## Related ADRs

- [Terminal Executor Agent Implementation](terminal-executor-agent-implementation.md)
- [Browser Executor Agent](browser-executor-agent.md)
- [Built-in Automatic Compression](built-in-automatic-compression.md)

## References

- Serper API Documentation: https://serper.dev/docs
- Web Search Tools: `surface/src/surface/tools/web_search.py`
- BaseSwarmAgent: `surface/src/surface/agents/base_agent.py`

---

**Author:** AI Assistant (Claude Sonnet 4.5)  
**Prompted by:** User: "@surface/src/surface/tools/web_search.py also create a new agent for these tools"  
**Implementation:** Complete  
**Files Created:**
- `surface/src/surface/signatures/web_search_signature.py` - Signature class
- `surface/src/surface/agents/web_search.py` - Agent implementation
- `surface/examples/example_web_search_simple.py` - Example usage
- `tests/test_web_search_agent.py` - Test suite
- `docs/adr/web-search-agent-implementation.md` - This ADR

**Files Modified:**
- `surface/src/surface/signatures/__init__.py` - Added export
- `surface/src/surface/agents/__init__.py` - Added export

**Result:** New WebSearchAgent with automatic compression retry and file output! 🎉
