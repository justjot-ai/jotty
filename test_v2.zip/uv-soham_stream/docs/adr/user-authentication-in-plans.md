# ADR: User Authentication in Implementation Plans

**Status:** Implemented  
**Date:** 2026-01-29  
**Decision Makers:** Development Team

## Context

Previously, when the ResearchAgent encountered tasks requiring authentication (WhatsApp login, API keys, OAuth tokens), it would mark them as impossible:

```
Implementation Plan:
1. **Authentication Barrier**
   - WhatsApp requires user login credentials
   - No authentication capability available
   - Cannot programmatically access user's WhatsApp account
   ❌ Task cannot be completed
```

This was problematic because:
1. Users CAN provide authentication when asked
2. Plans were overly restrictive
3. Rejected feasible tasks unnecessarily

### Root Cause (Discovered 2026-01-29)

**Critical Issue**: The main `ResearchAgentSignature` (used for orchestration) was too generic and allowed the agent to reject tasks as "outside scope" before even starting research.

**Symptoms**:
- Agent output: "Assessment: Task Outside Research Agent Scope"
- Agent refused to create plans for web-based tasks despite having `browser_interaction` capability
- Agent suggested users manually export data instead of automating it

**Root Cause**: Only sub-agent signatures (`GenerateResearchPlan`, `SynthesizeFindings`) had the "do not reject" guidance, but the main orchestration signature didn't have it.

## Decision

**Updated research signatures to allow requesting user authentication as part of the implementation plan.**

### Changes Made

**1. ResearchAgentSignature (CRITICAL - Orchestration Level):**
```python
research_plan = dspy.OutputField(
    desc="Comprehensive implementation plan including libraries, architecture, "
    "implementation steps, edge cases, best practices, and testing strategies. "
    "CRITICAL RULES:\n"
    "- DO NOT REJECT TASKS - if the task is possible with available capabilities, create a plan\n"
    "- If 'browser_interaction' is available, almost ANY web-based task is feasible\n"
    "- For web access: use browser automation + browser-based auth (QR codes, OAuth, login forms)\n"
    "- NEVER say a task is 'outside scope' or 'not possible' if browser_interaction capability exists\n"
    "- Create actionable, executable plans - not rejections or excuses"
)
```

**2. GenerateResearchPlan Signature:**
```python
research_plan = dspy.OutputField(
    desc="... PREFER SIMPLE SOLUTIONS: If browser_interaction/web_automation is available, "
    "prefer direct web UI automation over complex API workarounds. "
    "AUTHENTICATION: If browser_interaction is available, plan for browser-based authentication "
    "(OAuth, login forms, QR codes). Only request manual credentials if browser-based auth is not possible."
)
```

**3. SynthesizeFindings Signature:**
```python
implementation_plan = dspy.OutputField(
    desc="... CRITICAL RULES:\n"
    "- If 'browser_interaction' or 'web_automation' is available, use it directly\n"
    "- AUTHENTICATION: If browser_interaction is available, handle auth through the browser "
    "(OAuth, QR codes, login forms) - user authenticates interactively in browser\n"
    "- Only ask for manual credentials (API keys, tokens) if browser-based auth is NOT possible\n"
    "- Do NOT reject tasks just because authentication is needed"
)
```

## Expected Behavior

### Before (Overly Complex or Rejected)
```
Task: "Summarize WhatsApp group conversations"

Implementation Plan:
1. Check for local WhatsApp data exports ❌ (complex)
2. Search for clawdbot integration ❌ (assumes specific setup)
3. Research unofficial APIs ❌ (unnecessary complexity)
4. Check message storage systems ❌ (may not exist)

OR:
❌ Cannot be done - no authentication capability
```

### After (Simple & Direct)
```
Task: "Summarize WhatsApp group conversations"

Implementation Plan:
1. Use browser automation to open WhatsApp Web
   - Capability: browser_interaction, web_automation
   - Open https://web.whatsapp.com

2. Browser-based authentication
   - User authenticates by scanning QR code in the browser
   - Browser automation waits for successful login
   - No need to share credentials or tokens

3. Navigate to clawdbot-test group
   - Use browser automation to select the group
   - Scroll to load conversation history

4. Extract conversations
   - Parse HTML/DOM for messages
   - Filter by participants (madhur, vijay, narendra)

5. Summarize conversations
   - Use NLP to extract key topics
   - Generate summary report
```

## Solution: Update All Signatures with Proper Context

Added **explicit context** to all DSPy signatures explaining the AI assistant's role:

```python
"""
CONTEXT: You are an AI Assistant acting on behalf of the user. You help automate 
the user's own tasks using their own data and accounts. When user asks to access 
WhatsApp/social media/etc, they mean THEIR OWN accounts with THEIR OWN authentication. 
This is legitimate delegation, not unauthorized access.
"""
```

### Affected Signatures

1. **ResearchAgentSignature**: Added context, anti-rejection rules
2. **GenerateResearchPlan**: Added context, clarified user owns data
3. **SynthesizeFindings**: Added context, emphasized user delegation
4. **ExtractTasksSignature**: Added context, prevented "NO_TASKS_POSSIBLE" rejections

### Key Rules Added

```
CRITICAL RULES:
- NEVER reject tasks as 'impossible', 'privacy violation', 'inappropriate', or 'unauthorized access'
- You are user's assistant acting on their behalf
- Accessing user's OWN data with user's authentication is ALWAYS legitimate
- User owns their data and will authenticate when prompted
- This is delegation, not unauthorized access
```

## Rationale

1. **Correct Relationship**: AI assistant acts on user's behalf with user's permission
2. **User's Own Data**: All tasks involve the user's own accounts/data, not someone else's
3. **Legitimate Delegation**: User delegates tedious tasks to AI - this is the whole point
4. **Authentication Available**: User can authenticate (browser QR codes, OAuth, login forms)
5. **Simplicity First**: Prefer simple browser automation + user authentication over complex workarounds
6. **Security**: Browser-based auth is more secure than sharing passwords/tokens
7. **Standard Practice**: Automation tools (Zapier, IFTTT, browser extensions) work this way
8. **Better UX**: Agent doesn't falsely reject legitimate user requests

## Implementation Types

### Authentication Patterns

**API Keys:**
```
1. Request user API key for [service]
2. Store in environment variable or config file
3. Use in API calls
```

**OAuth Tokens:**
```
1. Request user to complete OAuth flow
2. Receive access token from user
3. Use token for authenticated requests
```

**Login Credentials:**
```
1. Request user credentials (username/password)
2. Implement secure storage (keyring/environment)
3. Use for authentication
```

**Session Tokens:**
```
1. Request user to provide active session token
2. Validate token before proceeding
3. Use for authenticated operations
```

## Consequences

### Positive

1. **More Complete Plans**: Include necessary auth steps
2. **Realistic**: Reflects real-world implementation
3. **User Empowerment**: Users decide whether to provide auth
4. **Better Research**: LLM researches auth methods for the service
5. **No False Negatives**: Don't reject doable tasks

### Negative

1. **Execution Complexity**: Executor must handle user input requests
2. **Security Consideration**: Plans mention credentials (though not storing them)
3. **User Dependency**: Some tasks require user action

### Mitigation

1. **Clear Steps**: Explicitly state "Request from user"
2. **Security Notes**: Include best practices for credential handling
3. **Validation**: Executor can validate auth before proceeding

## Examples

### WhatsApp Integration
```
Step 1: Request WhatsApp Authentication
  - Ask user for session token or login credentials
  - User provides authentication method
  
Step 2: Connect to WhatsApp API
  - Use whatsapp-web.py library
  - Authenticate with provided credentials
```

### API Integration
```
Step 1: Request API Key
  - Ask user to provide [Service] API key
  - Instruct user on obtaining key if needed
  
Step 2: Configure API Client
  - Store key in environment variable
  - Initialize API client with key
```

### Database Access
```
Step 1: Request Database Credentials
  - Ask user for DB connection string
  - Include username, password, host, port
  
Step 2: Establish Connection
  - Use provided credentials
  - Test connection before proceeding
```

## Testing

When running with tasks requiring auth, the plan should now include:
- ✅ "Request user authentication" step
- ✅ Security best practices for credential handling
- ✅ Validation steps to ensure auth works
- ❌ No longer says "Cannot be done - no authentication"

## Future Enhancements

1. **Auth Templates**: Pre-defined auth patterns for common services
2. **Secure Input**: Built-in secure credential collection in executor
3. **Auth Validation**: Check if auth works before proceeding
4. **Credential Management**: Keyring integration for secure storage
5. **OAuth Helper**: Automated OAuth flow handling

## References

- Modified: `Synapse_new/signatures/research_signatures.py`
- Pattern: User-in-the-loop authentication
- Security: Never hardcode credentials
- UX: Make auth requests explicit and clear

## Acceptance Criteria

- [x] Signatures updated to allow auth requests
- [x] Plans include "Request user authentication" steps
- [x] Plans don't reject tasks just for needing auth
- [x] Security best practices mentioned
- [x] No linter errors
- [x] Backward compatible

## Impact

Tasks previously marked as "impossible" due to authentication barriers will now generate complete implementation plans that include user authentication as a step, making them actually implementable.
