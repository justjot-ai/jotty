# ADR: Electron Browser View Integration

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: Electron desktop app integration with Selenium browser automation

## Decision

Embed the Selenium-controlled browser view inside the Electron app's system status section instead of opening it as a separate window. This creates a more integrated, cohesive user experience where the assistant's browser actions are visible within the main UI.

## Implementation

### Backend (Browser Tools)
- Added `_screenshot_callback` global variable for streaming screenshots
- Added `set_screenshot_callback(callback)` function to register callback from server
- Added `_send_screenshot_if_callback()` helper to capture and send screenshots
- Modified `navigate_to_url()` to call screenshot callback after page load
- Screenshots captured as PNG, base64-encoded, and sent to callback

### Backend (FastAPI Server)
- Created `ConnectionManager` class to manage WebSocket connections
- Added `/ws/browser` WebSocket endpoint for browser screenshot streaming
- Implemented `broadcast_screenshot()` to send screenshots to all connected clients
- Set up `startup_event` to register screenshot callback with browser tools
- Screenshot handler creates async task to broadcast to WebSocket clients

### Frontend (HTML)
- Added "Browser View Panel" to grid layout in system status section
- Panel contains placeholder (🌐 icon + "Browser inactive" text) and `<img>` tag
- Panel spans 2 columns (full width below agents and task panels)
- Uses `grid-column: span 2` for responsive layout

### Frontend (CSS)
- Added `.browser-panel`, `.browser-view`, `.browser-placeholder` styles
- Browser panel styled consistently with other panels (tertiary background, borders)
- Screenshot image uses `object-fit: contain` to preserve aspect ratio
- Placeholder shown when browser inactive, hidden when screenshot arrives

### Frontend (JavaScript)
- Added `browserWS` WebSocket connection property to app class
- Implemented `connectBrowserWebSocket()` with auto-reconnect on disconnect
- Added ping/pong keepalive mechanism (30 second interval)
- Implemented `updateBrowserView()` to display base64 screenshot
- WebSocket messages parsed for `browser_screenshot` type
- Placeholder automatically hidden when first screenshot received

## Technical Details

### Screenshot Flow
1. BrowserExecutor navigates to URL using Selenium
2. `navigate_to_url()` calls `_send_screenshot_if_callback()`
3. Callback captures screenshot as PNG using `driver.get_screenshot_as_png()`
4. Screenshot base64-encoded and passed to server's screenshot handler
5. Handler broadcasts to all WebSocket clients via `ConnectionManager`
6. Electron frontend receives WebSocket message and updates `<img>` src
7. Browser view updates in real-time within system status panel

### Benefits
- **Integrated UX**: Browser actions visible within main app window
- **Context awareness**: Users see what the assistant is doing in browser
- **No window management**: No need to manage separate browser windows
- **Real-time feedback**: Screenshot updates as browser navigates
- **Persistent connection**: WebSocket auto-reconnects if disconnected

### Future Enhancements
- Add headless/headed toggle button
- Implement zoom controls for browser view
- Add click-to-interact capabilities
- Stream terminal output alongside browser view
- Add recording/playback of browser actions

## Files Modified

### Created
- None (all modifications to existing files)

### Modified
- `surface/src/surface/tools/browser_tools.py` - Added screenshot callback system
- `surface_synapse/server.py` - Added WebSocket endpoint and connection manager
- `electron-app/src/renderer/index.html` - Added browser view panel
- `electron-app/src/renderer/css/styles.css` - Added browser panel styles
- `electron-app/src/renderer/js/app.js` - Added WebSocket connection and screenshot handling

## Consequences

### Positive
- More cohesive user experience
- Real-time visibility into browser automation
- No separate windows to manage
- Feels like true "personal assistant" watching user's tasks
- Extensible to other automation views (terminal, etc.)

### Negative
- Screenshot streaming adds network overhead
- Requires WebSocket connection in addition to REST API
- Browser must remain visible (not hidden/minimized) for good screenshots
- Screenshot frequency not yet optimized (could cause performance issues)

### Neutral
- Browser still runs as separate Selenium instance
- Screenshots are snapshots, not live interaction
- Requires backend and frontend changes for full integration
