# ADR: Agent Session Manager Multi-Agent Support

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Enable parallel agent execution in UI by supporting multiple active agents

## Problem

Even after fixing the parallel execution event streaming in Conductor, the UI was still showing agents sequentially. Investigation revealed:

```
2026-02-02 02:02:59.393 | Agent activated: BrowserExecutor
2026-02-02 02:03:00.545 | Agent deactivated: BrowserExecutor
2026-02-02 02:03:00.545 | Agent activated: TerminalExecutor
```

**Root Cause:** The `AgentSessionManager` was designed for **single-agent view** and automatically deactivated the previous agent when a new one activated:

```python
# Deactivate previous agent if different
if self.active_agent and self.active_agent != agent_type:
    await self.deactivate_agent(self.active_agent)  # ← PROBLEM!
```

This meant:
- ✅ Conductor executed tasks in parallel
- ✅ Events were streaming from both agents
- ❌ AgentSessionManager was forcing sequential activation

## Decision

Convert `AgentSessionManager` from single-agent to **multi-agent support**:

### Key Changes

1. **Change active agent tracking:**
   - Before: `self.active_agent: Optional[AgentType] = None` (single)
   - After: `self.active_agents: set = set()` (multiple)

2. **Remove auto-deactivation:**
   - Before: Deactivate previous agent when new one activates
   - After: Allow multiple agents to be active simultaneously

3. **Update activation logic:**
   ```python
   async def activate_agent(self, agent_type: AgentType):
       # Skip if already active
       if agent_type in self.active_agents:
           return
       
       # Add to active agents (don't remove others!)
       self.active_agents.add(agent_type)
       
       # Broadcast activation
       await self.websocket_manager.broadcast({
           "type": "agent_activated",
           "agent": agent_type.value,
           "timestamp": datetime.now().isoformat()
       })
       
       logger.info(f"✅ Agent activated: {agent_type.value} (total active: {len(self.active_agents)})")
   ```

4. **Update deactivation logic:**
   ```python
   async def deactivate_agent(self, agent_type: AgentType):
       # Remove from active agents
       self.active_agents.discard(agent_type)
       
       # Broadcast deactivation
       await self.websocket_manager.broadcast({
           "type": "agent_deactivated",
           "agent": agent_type.value,
           "timestamp": datetime.now().isoformat()
       })
       
       logger.info(f"⏸️  Agent deactivated: {agent_type.value} (total active: {len(self.active_agents)})")
   ```

5. **Add new method for multi-agent queries:**
   ```python
   def get_active_agents(self) -> set:
       """Get all currently active agents."""
       return self.active_agents.copy()
   ```

6. **Maintain backward compatibility:**
   ```python
   def get_active_agent(self) -> Optional[AgentType]:
       """Get first active agent (backward compatibility)."""
       return next(iter(self.active_agents)) if self.active_agents else None
   ```

## Benefits

✅ **Parallel execution support:** Multiple agents can be active simultaneously  
✅ **Real-time UI updates:** Both agent views visible at the same time  
✅ **Backward compatible:** Single-agent code still works  
✅ **Simple change:** Minimal code modification  
✅ **Better logging:** Shows total active agents count  

## Trade-offs

⚠️ **Slightly more memory:** Set instead of single reference (negligible)  
⚠️ **Behavior change:** Agents no longer auto-deactivate each other  

## Implementation Details

### Before (Single Agent)
```python
self.active_agent = None  # Only one agent

if self.active_agent and self.active_agent != agent_type:
    await self.deactivate_agent(self.active_agent)  # Force single agent

self.active_agent = agent_type
```

### After (Multi Agent)
```python
self.active_agents = set()  # Multiple agents

# No auto-deactivation!
self.active_agents.add(agent_type)  # Just add to set
```

## Result

Now when parallel tasks execute:
- ✅ Conductor executes in parallel
- ✅ Events stream in real-time
- ✅ AgentSessionManager allows multiple active agents (NEW!)
- ✅ UI shows both agent views simultaneously

## Testing

Restart the server and run a task:

```bash
cd uv
./run_server.sh
```

Expected behavior:
1. Both `BrowserExecutor` and `TerminalExecutor` activate simultaneously
2. Both stay active during parallel execution
3. Both views visible in split-screen
4. Real-time updates from both agents

Check logs for:
```
✅ Agent activated: BrowserExecutor (total active: 1)
✅ Agent activated: TerminalExecutor (total active: 2)  ← Both active!
```

## Related Files

- `/surface_synapse/agent_session_manager.py` - Multi-agent support
- `/Synapse/core/conductor.py` - Parallel execution with event streaming
- `/electron-app/src/renderer/js/agent-view-manager.js` - UI split-view
- `/docs/adr/parallel-execution-event-streaming.md` - Event streaming fix

## Related Issues

- Part 1: Fixed event streaming in Conductor (parallel-execution-event-streaming.md)
- Part 2: Fixed agent session manager (this ADR)
- Together these enable true parallel agent execution with simultaneous UI views
