# Fix Environment Manager Daemon Thread Issue

**Status:** Implemented  
**Date:** 2026-01-31  
**Context:** Environment file collapser not working after 1 minute

## Problem

The Environment Manager's auto-summarization background thread was not working because:

1. The thread is created as a **daemon thread** (`daemon=True`)
2. Daemon threads are **killed when the main process exits**
3. The `solve_task_sync` script completes and exits within 2-3 minutes
4. The daemon thread gets killed before it can complete any summarization cycles

The env.md file was growing to 73KB (384 lines) without being summarized. While this was initially thought to exceed a 50KB threshold, testing revealed authentication failures were preventing summarization. The threshold has now been increased to 20MB to reduce unnecessary LLM calls for smaller files.

## Root Cause Analysis

### Primary Cause: API Authentication Failure

Summarization attempts are **failing silently** due to AuthenticationError:

```
litellm.exceptions.AuthenticationError: The api_key client option must be set 
either by passing api_key to the client or by setting the OPENAI_API_KEY environment variable
```

**The sequence:**
1. File exceeds 50KB threshold
2. `add_to_current_env()` triggers `_summarize_environment()` (line 208)
3. Environment Manager's ChainOfThought summarizer tries to call LLM
4. LiteLLM throws AuthenticationError (no API key configured)
5. Exception is caught and logged on line 308 but not propagated
6. File stays unsummarized at 73KB

**Why authentication fails:**
- Environment Manager creates its own `dspy.ChainOfThought(EnvironmentSummarizationSignature)` on line 74
- This uses `dspy.settings.lm` which may not have API key configured at initialization time
- Even though Conductor configures DSPy later, the Environment Manager's summarizer was created BEFORE that

### Secondary Cause: Daemon Thread

```python
# environment_manager.py line 342-347
self._summarization_thread = threading.Thread(
    target=self._auto_summarize_loop,
    daemon=True,  # ← Makes it worse!
    name="EnvSummarizer"
)
```

**Daemon thread behavior:**
- Killed immediately when main thread/process exits
- Never gets to complete its work in short-lived scripts
- Even if API key was fixed, periodic checks (every 60s) wouldn't execute in < 3min scripts

## Solution

### Fix 1: Lazy-Load Summarizer (Fixes Authentication)

Changed Environment Manager to lazy-load the ChainOfThought summarizer:

**Before:**
```python
# Line 74 - Created at __init__, before DSPy is configured
self.summarizer = dspy.ChainOfThought(EnvironmentSummarizationSignature)
```

**After:**
```python
# Line 74 - Defer creation until first use
self._summarizer = None

# Lines 252-267 - Create on first use, with validation
if self._summarizer is None:
    try:
        self._summarizer = dspy.ChainOfThought(EnvironmentSummarizationSignature)
    except Exception as e:
        logger.error(f"❌ Failed to initialize summarizer: {e}")
        return

# Check if DSPy is actually configured
if not hasattr(dspy.settings, 'lm') or dspy.settings.lm is None:
    logger.warning("⚠️  Skipping summarization - DSPy not configured")
    return
```

**Benefits:**
- Summarizer created only when needed (after DSPy is configured)
- Validates that DSPy has an LM with API key before attempting summarization
- Gracefully skips summarization if not configured (no silent failures)

### Fix 2: atexit Handler (Fixes Daemon Thread)

Added `atexit` handler in Conductor initialization to:

1. Check if env file exceeds size threshold before exit
2. Force final summarization if needed
3. Cleanly stop the background thread

```python
import atexit
env_mgr = self.env_manager
def _finalize_environment():
    if env_mgr and env_mgr.env_file.exists():
        file_size = env_mgr.env_file.stat().st_size
        if file_size > env_mgr.max_size_before_summarize:
            logger.info("🗜️  Triggering final summarization before exit...")
            env_mgr.force_summarize()
        env_mgr.stop_auto_summarization()

atexit.register(_finalize_environment)
```

## Benefits

1. ✅ Env file gets summarized even in short-lived scripts
2. ✅ Clean shutdown of background thread
3. ✅ No manual intervention required
4. ✅ Works for both long-running and short-running processes

## Implementation Details

**File:** `Synapse/core/conductor.py`  
**Lines:** 1249-1267 (after Environment Manager initialization)

**Threshold:** 20MB (20,971,520 bytes) - Updated from 50KB  
**Previous file size:** 73KB (was below old 50KB threshold, now well below 20MB)

## Testing

Manual test confirmed:
- Environment Manager CAN create and start thread successfully
- Thread stays alive in long-running processes
- Thread is killed in short-lived processes (< main exit time)
- atexit handler executes before process termination

## Future Improvements

Consider:
1. Make summarization trigger synchronously when content is added (already exists on line 206-208)
2. Reduce auto-summarization interval from 60s to 10s
3. Make thread non-daemon and implement proper shutdown signals
4. Add metrics for summarization frequency and effectiveness
