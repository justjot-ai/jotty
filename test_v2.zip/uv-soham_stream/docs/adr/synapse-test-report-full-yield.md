# ADR: Synapse Full Test Case and Evaluation Report Yield

**Date**: 2026-02-03  
**Status**: Implemented

## Context

Synapse auditor previously yielded only:
- A single message: how many test cases were generated (e.g. "Generated 4 test cases")
- A single summary on evaluation: "completed 4/4" or "75%" / "Test aggregation complete: reward=..., confidence=..."

Users need visibility into each test condition (e.g. "Check if agent started whatsapp web") and a full evaluation report string instead of a one-line summary.

## Decision

1. **Per-test conditions on generation**  
   In `generate_tests_stream`, after building the test list, yield one message per test:  
   `Created Test N: <condition>` where condition is `expected_output` or `name` (e.g. "Created Test 1: Check if agent started whatsapp web").

2. **Full execution report after run**  
   In `generate_and_run_stream`, after running validations, yield a full report string: each test with condition, PASSED/FAILED, and reasoning; then a summary line (e.g. "Summary: 3/4 passed (75%)").

3. **Conductor uses stream and full aggregation report**  
   - Conductor calls `generate_and_run_stream` instead of `generate_and_run`, and forwards all non-result events so the UI receives "Created Test N: ..." and the execution report.
   - After aggregation, yield the full report as the message: all tests with condition and pass/fail, reasoning per test, then summary (passed/total, %, reward, confidence). No longer yield only "Test aggregation complete: reward=..., confidence=...".

## Implementation

- **Synapse/core/parallel_test_generator.py**  
  - `generate_tests_stream`: after dedup, yield `Created Test {i}: {condition}` for each test; then existing summary and result.  
  - `generate_and_run_stream`: after building results, yield one message containing the full report (each test + status + reasoning, then summary).

- **Synapse/core/conductor.py**  
  - `_run_auditor_stream`: use `generate_and_run_stream`, forward stream events (skip `type=result`), collect result for aggregation.  
  - Build `feedback` as full report (all tests with condition, PASSED/FAILED, reasoning; then summary) and yield it as `message` instead of the short aggregation line.

## Consequences

- UI receives every created test condition and the full evaluation report in string form.
- Same data is still passed to aggregation and `auditor_result`; only the yielded messages are expanded.
