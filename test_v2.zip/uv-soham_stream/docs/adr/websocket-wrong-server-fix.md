# ADR: WebSocket Endpoint in Wrong Server File

**Status:** Resolved  
**Date:** 2026-02-01  
**Issue:** WebSocket 403 errors due to endpoint in unused server file  

---

## Problem

WebSocket connections to `/ws/browser` were being rejected with 403 Forbidden:

```
INFO: 127.0.0.1:56583 - "WebSocket /ws/browser" 403
INFO: connection rejected (403 Forbidden)
```

---

## Root Cause

The project has **two server files**:

1. **`surface_synapse/server.py`** - Old/standalone server (NOT running)
2. **`uv/src/uv/main.py`** - Actual production server (RUNNING)

The WebSocket endpoint was added to `surface_synapse/server.py`, which is **not the server being used** by `./run_server.sh`.

### Server Startup Chain

```bash
./run_server.sh
  → poetry run uvicorn uv.main:app --host 0.0.0.0 --port 8000
    → uv/src/uv/main.py
      → FastAPI app with routers
        ✅ /api/v1/perform
        ✅ /api/v1/health
        ❌ /ws/browser (MISSING!)
```

---

## Solution

### 1. Created WebSocket Router Module

**File:** `uv/src/uv/api/v1/websocket_agents.py`

```python
"""WebSocket endpoint for agent events."""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    
    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            await connection.send_json(message)

manager = ConnectionManager()

@router.websocket("/ws/browser")
async def websocket_browser(websocket: WebSocket):
    await manager.connect(websocket)
    while True:
        data = await websocket.receive_text()
        if data == "ping":
            await websocket.send_text("pong")
```

### 2. Registered Router in Main App

**File:** `uv/src/uv/main.py`

```python
from uv.api.v1 import websocket_agents

def create_app() -> FastAPI:
    app = FastAPI(...)
    
    # Include WebSocket router
    app.include_router(websocket_agents.router, tags=["WebSocket"])
    
    return app
```

### 3. Initialize AgentSessionManager

**File:** `uv/src/uv/main.py` (lifespan)

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # ... existing initialization ...
    
    # Initialize AgentSessionManager
    try:
        from uv.api.v1.websocket_agents import get_websocket_manager
        from surface_synapse.agent_session_manager import initialize_agent_session_manager
        
        ws_manager = get_websocket_manager()
        agent_session_manager = initialize_agent_session_manager(ws_manager)
        logger.info("✅ AgentSessionManager initialized")
    except Exception as e:
        logger.warning(f"⚠️ Failed to initialize AgentSessionManager: {e}")
    
    yield
```

---

## Files Changed

### Created
- `uv/src/uv/api/v1/websocket_agents.py` - WebSocket router and manager

### Modified
- `uv/src/uv/main.py` - Import router, register router, initialize AgentSessionManager

---

## Decision Rationale

### Why Not Use `surface_synapse/server.py`?

1. **Not the running server** - `./run_server.sh` uses `uv.main:app`
2. **Separate codebase** - `surface_synapse/` is a different module
3. **Duplication** - Would require running two servers

### Why Create New Router?

1. **Modular** - Follows FastAPI best practices
2. **Maintainable** - Clear separation of concerns
3. **Consistent** - Matches existing router structure (`health.py`, `perform.py`)

---

## Testing

### Before Fix
```
❌ INFO: 127.0.0.1:56583 - "WebSocket /ws/browser" 403
❌ INFO: connection rejected (403 Forbidden)
```

### After Fix (Expected)
```
✅ WebSocket connection attempt from: ('127.0.0.1', 56XXX)
✅ WebSocket connected. Total: 1
```

---

## Deployment

### Steps to Apply
1. Stop backend server (Ctrl+C)
2. Restart: `./run_server.sh`
3. Verify logs show: `✅ AgentSessionManager initialized`
4. Restart Electron app
5. Verify WebSocket connection (no 403 errors)

---

## Consequences

### Positive
- ✅ WebSocket endpoint in correct server
- ✅ Follows project structure
- ✅ Modular and maintainable
- ✅ No code duplication

### Negative
- ⚠️ `surface_synapse/server.py` now has unused WebSocket code
- ⚠️ Confusion about which server is running

### Neutral
- Need to restart server to apply changes

---

## Future Improvements

1. **Remove unused code** from `surface_synapse/server.py`
2. **Document server architecture** to prevent confusion
3. **Add integration tests** for WebSocket endpoint
4. **Add origin validation** for production

---

## Related

- [Agent Embedding Implementation](./agent-session-embedding-implementation.md)
- [WebSocket 403 Fix](./websocket-403-fix.md)
- [Testing Guide](../AGENT_EMBEDDING_TESTING_GUIDE.md)

---

## Status

- ✅ Root cause identified
- ✅ Solution implemented
- ✅ Files created/modified
- ⏳ Server restart required
- ⏳ Testing required

**Ready to deploy!** 🚀
