# ADR: WebSearch Event Broadcast Fix

## Status
Implemented

## Context
WebSearch agent events were not being displayed in the Electron UI, while Browser and Terminal agent events were working correctly. The user reported: "not getting events in ui just like how browser/terminal agents are sent"

## Investigation
The investigation revealed two issues:

### Issue 1: Incorrect AgentSessionManager Access (Primary)
In `surface/src/surface/tools/web_search.py`, the code was calling:
```python
manager = AgentSessionManager.get_instance()
```

But `AgentSessionManager` class doesn't have a static `get_instance()` method. The correct approach used by `browser_tools.py` is:
```python
from surface_synapse.agent_session_manager import get_agent_session_manager, AgentType
manager = get_agent_session_manager()
```

This caused all broadcast calls to fail silently (caught by `except Exception` and logged at debug level).

### Issue 2: Event Loop Race Condition (Secondary)
In `surface/src/surface/agents/base_agent.py`, the `aforward` method had a potential race condition. Events enqueued via `loop.call_soon_threadsafe()` from the callback thread might not be processed before the queue was drained when `gen_task.done()` returned True.

### Issue 3: Missing Tool Event Streaming
The `on_tool_start` and `on_tool_end` callbacks only logged but didn't enqueue events for UI streaming.

## Decision
1. **Fix web_search.py**: Use `get_agent_session_manager()` function and match the pattern used by `browser_tools.py`
2. **Fix base_agent.py aforward**: Add `await asyncio.sleep(0)` before draining the queue to allow the event loop to process pending callbacks
3. **Add tool event streaming**: Add `_enqueue()` calls to `on_tool_start`, `on_tool_end`, and `on_module_start` callbacks

## Changes Made

### web_search.py
- Changed import from `AgentSessionManager, AgentType` to `get_agent_session_manager, AgentType`
- Updated `_broadcast_websearch_event_sync` to use `get_agent_session_manager()` instead of `AgentSessionManager.get_instance()`
- Added `AGENT_MANAGER_AVAILABLE` flag pattern matching browser_tools.py
- Updated event loop handling to match browser_tools.py pattern (using `is_running()` check and thread fallback)

### base_agent.py
- Added `await asyncio.sleep(0)` before draining queue when gen_task completes
- Added `_enqueue()` calls to `on_tool_start` for tool start events
- Added `_enqueue()` calls to `on_tool_end` for tool completion events  
- Added `_enqueue()` call to `on_module_start` for module start events

## Consequences
- WebSearch agent events will now be properly broadcast to the Electron UI
- Users will see search queries, results, and scraping activities in real-time
- Tool execution events will be streamed for all agents (Browser, Terminal, WebSearch)
- The UI will show more granular progress updates during agent execution

## Related Files
- `surface/src/surface/tools/web_search.py`
- `surface/src/surface/agents/base_agent.py`
- `surface/src/surface/tools/browser_tools.py` (reference implementation)
- `surface_synapse/agent_session_manager.py`
