# ADR: Configure Screenshots Directory and Auto-Generated Filenames

**Status:** Implemented  
**Date:** 2026-01-30  
**Context:** Screenshots were cluttering root directory with no organized storage

---

## Problem

Screenshots were being saved to the project root directory:
- ❌ Cluttered root directory
- ❌ No organization or naming convention
- ❌ Had to manually specify paths every time
- ❌ Screenshots mixed with code files

**Example:**
```
/Users/anshulchauhan/Tech/term/
  ├── whatsapp_search_results.png
  ├── synapse_after_scroll_top.png
  ├── current_state_final_check.png
  ├── ... (9 screenshot files)
  ├── pyproject.toml
  ├── uv.py
  └── ...
```

---

## Solution

### 1. Centralized Screenshot Directory

Created `runs/screenshots/` as the default location for all screenshots:

```
runs/screenshots/
  ├── README.md
  ├── screenshot_20260130_235959.png
  ├── screenshot_20260131_001234.png
  └── ...
```

### 2. Auto-Generated Filenames

Made `file_path` parameter **optional** in `take_screenshot()`:

```python
def take_screenshot(file_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Take screenshot with automatic filename generation.
    
    If file_path not provided, saves to:
      runs/screenshots/screenshot_YYYYMMDD_HHMMSS.png
    """
    if file_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = str(_DEFAULT_SCREENSHOTS_DIR / f"screenshot_{timestamp}.png")
    
    # Ensure directory exists
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    
    driver.save_screenshot(file_path)
    ...
```

### 3. Updated to Use Shared Browser

Also updated to use `get_browser_driver()` instead of global `_browser_driver`, ensuring it works with the shared browser pattern.

---

## Usage

### Auto-Generated Path (Recommended)

```python
# Agent code
take_screenshot()
# → Saves to: runs/screenshots/screenshot_20260130_235959.png
```

### Custom Path (Optional)

```python
# Specify custom path
take_screenshot("my_folder/my_screenshot.png")
# → Saves to: my_folder/my_screenshot.png
```

### Custom Name in Default Directory

```python
# Custom name but in default directory
take_screenshot("runs/screenshots/login_page.png")
# → Saves to: runs/screenshots/login_page.png
```

---

## Migration

Moved existing screenshots from root to `runs/screenshots/`:

```bash
# Moved 9 PNG files
mv *.png runs/screenshots/
```

**Files moved:**
- whatsapp_search_results.png
- synapse_after_scroll_top.png
- synapse_conversation_after_click.png
- synapse_search_results_2.png
- whatsapp_after_clear_search.png
- whatsapp_initial_view.png
- synapse_after_second_click.png
- synapse_conversation_opened.png
- current_state_final_check.png

---

## Benefits

### ✅ Clean Root Directory

No more screenshot clutter in project root.

### ✅ Organized Storage

All screenshots in one place: `runs/screenshots/`

### ✅ Auto-Generated Names

No need to think of filenames - timestamps are automatic and unique:
- `screenshot_20260130_235959.png`
- `screenshot_20260131_001234.png`

### ✅ Easy Cleanup

Can delete all screenshots at once:
```bash
rm -rf runs/screenshots/*.png
```

Or just old ones:
```bash
find runs/screenshots -name "*.png" -mtime +7 -delete
```

### ✅ Better Git Management

Screenshots directory can be easily gitignored or included as needed.

---

## Configuration

### Default Screenshot Directory

Defined in `browser_tools.py`:

```python
_DEFAULT_SCREENSHOTS_DIR = Path("runs") / "screenshots"
```

**To change default location**, modify this constant.

### Filename Format

Current format: `screenshot_YYYYMMDD_HHMMSS.png`

**To change format**, modify the timestamp format string:

```python
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")  # Current
# OR
timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")  # With dashes
# OR
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")  # With microseconds
```

---

## Implementation Details

### Directory Creation

Screenshot directory is created at module import time:

```python
_DEFAULT_SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
```

Additionally, `take_screenshot()` ensures parent directory exists:

```python
Path(file_path).parent.mkdir(parents=True, exist_ok=True)
```

This handles both default and custom paths gracefully.

### Return Value

Enhanced return value includes both relative and absolute paths:

```python
{
    "status": "success",
    "file_path": "runs/screenshots/screenshot_20260130_235959.png",
    "absolute_path": "/Users/username/Tech/term/runs/screenshots/screenshot_20260130_235959.png",
    "error": None
}
```

---

## Testing

### Test Auto-Generated Path

```python
from surface.tools import take_screenshot

result = take_screenshot()
print(result["file_path"])  
# → runs/screenshots/screenshot_20260130_235959.png
```

### Test Custom Path

```python
result = take_screenshot("my_test.png")
print(result["file_path"])  
# → my_test.png
```

### Verify Directory Exists

```bash
ls -lh runs/screenshots/
```

Should show all screenshots with timestamps.

---

## Files Changed

- `surface/src/surface/tools/browser_tools.py`
  - Added `_DEFAULT_SCREENSHOTS_DIR` constant
  - Added `datetime` import
  - Modified `take_screenshot()` to accept optional file_path
  - Auto-generate filename with timestamp if not provided
  - Use `get_browser_driver()` instead of global
  - Create parent directory if needed

- `runs/screenshots/README.md` - Created documentation for directory

---

## Related

- `docs/adr/property-bag-shared-instances.md` - Shared browser pattern
- `docs/adr/fix-browser-tools-check-shared-first.md` - Browser tool integration

---

## Future Enhancements

- Add screenshot compression/optimization
- Implement automatic cleanup of old screenshots
- Add screenshot metadata (URL, timestamp, page title) as JSON sidecar files
- Support different image formats (JPEG, WebP)
- Add screenshot comparison tools

---

## Summary

Configured browser automation to save screenshots to `runs/screenshots/` directory with auto-generated timestamped filenames. Moved existing screenshots from root to the organized directory. This keeps the project clean and makes screenshot management easier.
