# ADR: Fix TD(λ) Learner end_episode() Parameter Mismatch

**Status**: Implemented  
**Date**: 2026-01-31  
**Context**: Bug fix

## Problem

The `Conductor.run()` method was calling `TDLambdaLearner.end_episode()` with incorrect parameters:

```python
# BEFORE (incorrect)
self.td_learner.end_episode(
    final_reward=final_reward,
    goal_values=self.goal_hierarchy  # Wrong parameter name
    # Missing required 'memories' parameter
)
```

**Error**:
```
TypeError: TDLambdaLearner.end_episode() got an unexpected keyword argument 'goal_values'
```

## Root Cause

The `TDLambdaLearner.end_episode()` signature requires:
- `final_reward`: float
- `memories`: Dict[str, MemoryEntry] (REQUIRED)
- `goal_hierarchy`: Optional[GoalHierarchy] (optional)

The conductor was:
1. Using wrong parameter name: `goal_values` instead of `goal_hierarchy`
2. Missing the required `memories` parameter entirely

## Solution

Fixed the method call in `Synapse/core/conductor.py` (line 4312):

```python
# AFTER (correct)
# Flatten hierarchical memory for TD learner
all_memories = {}
if hasattr(self, 'shared_memory') and self.shared_memory:
    for level in self.shared_memory.memories:
        all_memories.update(self.shared_memory.memories[level])

self.td_learner.end_episode(
    final_reward=final_reward,
    memories=all_memories,
    goal_hierarchy=self.goal_hierarchy if hasattr(self, 'goal_hierarchy') else None
)
```

## Changes

1. **Added memory flattening**: Collect all memories from all levels of HierarchicalMemory into a single dict
2. **Fixed parameter name**: Changed `goal_values` → `goal_hierarchy`
3. **Added required parameter**: Now passing `memories` parameter
4. **Enhanced logging**: Added memory count to success log message

## Verification

Other calls to `end_episode()` in the codebase are correct:
- `synapse_core.py:1458` - passes all parameters correctly
- `offline_learning.py:515` - passes all parameters correctly

## Impact

- **Bug severity**: Critical - prevented TD(λ) learning from completing
- **Side effects**: None - pure bug fix
- **Backwards compatibility**: Maintained - no API changes
