# ADR: VLLM State Identification Tool Not Getting Called - Diagnosis & Solution

**Status**: Fixed  
**Date**: 2026-02-09  
**Context**: VLM tools (especially `inspect_browser_state`) are registered and available but not being called by BrowserExecutor during execution

## Problem

VLM state identification tools (`inspect_browser_state`, `visual_inspect`, etc.) are:
- ✅ Successfully loaded (6 tools from VISUAL_INSPECTOR_TOOLS)
- ✅ Injected into all actors by `swarm_service.py` (8 tools including DataRegistry)
- ✅ Available to architect/auditor agents (visible in logs)
- ✅ Merged during SynapseCore initialization (logs show "🔧 Merged 3 new tools with 8 existing tools → 11 total")
- ❌ **NOT being called by BrowserExecutor during task execution**

### Observed Behavior

**Logs show:**
```
🔍 Injected 8 tools (VLM + DataRegistry) into BrowserExecutor's actor tools  # swarm_service.py ✅
🔧 Merged 3 new tools with 8 existing tools → 11 total                        # SynapseCore ✅
🔧 [browser_executor_architect] Available tools (11): ..., inspect_browser_state, ...  # Architect has tools ✅
🎬 EXECUTE_ACTOR: Starting execution | actor=BrowserExecutor                  # Execution starts ✅
# BUT: No log showing "🔧 Merged X Synapse-injected tools into ReAct" from base_agent.py ❌
# AND: No calls to inspect_browser_state() during BrowserExecutor execution ❌
```

**Expected:**
- BrowserExecutor's `aforward()` should merge `_synapse_additional_tools` into ReAct tool dict
- Log should show: `🔧 Merged X Synapse-injected tools into ReAct`
- BrowserExecutor should be able to call `inspect_browser_state()` when needed

**Actual:**
- No merge log appears during BrowserExecutor execution
- `inspect_browser_state()` is never called
- Tools might not be in BrowserExecutor's ReAct tool dict during execution

## Root Cause Hypothesis

**Location**: `surface/src/surface/agents/base_agent.py::aforward()`

**Possible Issues:**

1. **`_synapse_additional_tools` not preserved**: The attribute might not exist when `aforward()` is called, even though it was set during initialization.

2. **Tool merge happening in wrong place**: Tools might be merged in `_create_bound_tools()` (line 1087-1092) but not logged, and then skipped in `aforward()` because they're already in the dict.

3. **Tool name mismatch**: Tool names might not match between injection and merge, causing tools to be skipped.

4. **LLM not choosing to call tools**: Tools might be available but the LLM isn't recognizing when to use them (prompt/description issue).

## Diagnostic Changes Made

Added comprehensive logging to diagnose the issue:

1. **In `aforward()` (line ~824)**:
   - Log whether `_synapse_additional_tools` attribute exists
   - Log the value, type, and length of `_synapse_additional_tools`
   - Log each tool being processed and whether it's already in the dict
   - Log before/after tool counts

2. **In `_create_bound_tools()` (line ~1087)**:
   - Log when tools are merged there
   - Log before/after tool counts

## Solution Implemented

### 1. Enhanced Tool Descriptions
**File**: `surface/src/surface/tools/visual_inspector_tools.py`

- Enhanced `inspect_browser_state()` docstring with checkpoint verification guidance
- Added checkpoint verification pattern explaining when to use visual inspection
- Clarified that checkpoints are state transitions requiring verification
- Provided generic checkpoint examples (not hardcoded scenarios)
- Enhanced `visual_inspect()` docstring to mention checkpoint verification use case

### 2. Added System Prompt Guidance
**File**: `surface/src/surface/agents/browser_executor.py`

- Added "VISUAL STATE VERIFICATION AT CHECKPOINTS" section to ELECTRON_SYSTEM_PROMPT
- Documented checkpoint verification pattern with generic examples
- Explained when to use checkpoint verification (after navigation, authentication, etc.)
- Provided guidance on formulating checkpoint questions
- Emphasized that visual inspection complements selector-based checks

### 3. Enhanced Architect Prompt
**File**: `Synapse/core/validation_prompts/browser_executor_architect.md`

- Added "Step 3: Visual State Verification Checkpoints" section
- Documented checkpoint planning principles
- Provided generic checkpoint examples (not hardcoded scenarios)
- Updated recovery strategy to recommend visual inspection for diagnosis
- Advised architect to recommend checkpoint verification in planning

### 4. Diagnostic Logging
**File**: `surface/src/surface/agents/base_agent.py`

- Added comprehensive diagnostic logging for tool merging
- Logs show tool merge status, before/after counts, and which tools are added
- Helps verify tools are available during execution

## Verification

After implementation, logs confirmed:
- ✅ Tools ARE being merged: `🔧 Merged 11 Synapse-injected tools into ReAct | before=13 | after=24 | added=11`
- ✅ Tools are available in BrowserExecutor's ReAct tool dict
- ⚠️ Tools are not yet being called (requires LLM to recognize when to use them)

The enhanced descriptions and prompts should guide the LLM to use visual inspection at checkpoints.

## Related Files

- `surface/src/surface/agents/base_agent.py` - Tool merging logic (diagnostic logging added)
- `Synapse/core/synapse_core.py` - Tool injection during initialization
- `uv/src/uv/services/swarm_service.py` - Initial tool injection
- `surface/src/surface/tools/visual_inspector_tools.py` - VLM tool definitions (enhanced descriptions)
- `surface/src/surface/agents/browser_executor.py` - System prompt (checkpoint guidance added)
- `Synapse/core/validation_prompts/browser_executor_architect.md` - Architect prompt (checkpoint planning added)

## Testing

To verify the solution works:
1. Run a BrowserExecutor task that involves state transitions (navigation, authentication, etc.)
2. Check logs for `🔧 Merged X Synapse-injected tools into ReAct` (confirms tools available)
3. Verify `inspect_browser_state()` appears in ReAct tool calls at checkpoints
4. Confirm VLM tools are being used for checkpoint verification
5. Verify that visual inspection helps diagnose issues when selectors fail

## Key Principles Applied

- **Generic guidance, not hardcoded examples**: All guidance uses principles and patterns
- **Checkpoint-based verification**: Focus on verifying state transitions, not specific scenarios
- **Complementary to selectors**: Visual inspection supplements, not replaces, selector-based checks
- **Diagnostic tool**: Visual inspection helps when programmatic checks are insufficient
