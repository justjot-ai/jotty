# ADR: Fix TimeBudgetPlanner AsyncIO Event Loop Error

**Date:** 2026-02-01  
**Status:** Implemented

## Context

The `TimeBudgetPlanner` was causing a runtime error when called from the `Conductor.run()` method:

```
RuntimeWarning: asyncio.run() cannot be called from a running event loop
RuntimeWarning: coroutine 'TimeBudgetPlanner._sync_plan' was never awaited
```

This occurred at line 2827 in `conductor.py` where `self.time_budget_planner.plan()` was being called.

## Problem

The `Conductor.run()` method is an async generator function that already runs within an event loop. The synchronous `plan()` method in `TimeBudgetPlanner` attempts to handle both sync and async contexts by:

1. Checking if an event loop is running
2. If running, raising a RuntimeError and catching it to call `asyncio.run()`
3. However, `asyncio.run()` cannot be called from within an already running event loop

This design pattern was flawed because the exception handling tried to use `asyncio.run()` which is explicitly forbidden when an event loop is already active.

## Decision

Changed the conductor to use the async `plan_stream()` method instead of the synchronous `plan()` method:

**Before:**
```python
plan_result = self.time_budget_planner.plan(
    total_timeout_seconds=actor_timeout,
    actor_metrics=actor_metrics,
    task_context=task_context,
    global_metrics=global_metrics
)
```

**After:**
```python
plan_result = None
async for event in self.time_budget_planner.plan_stream(
    total_timeout_seconds=actor_timeout,
    actor_metrics=actor_metrics,
    task_context=task_context,
    global_metrics=global_metrics
):
    if event.get("type") == "result":
        plan_result = event.get("result")
    else:
        yield event

if plan_result and plan_result.success and plan_result.plan:
    # ... rest of the logic
```

## Consequences

### Positive
- Eliminates the asyncio event loop error
- Properly uses async/await patterns in async context
- Maintains event streaming capability - events from `plan_stream()` are now properly yielded to the caller
- More idiomatic async Python code

### Negative
- None identified

## Implementation Details

**File Modified:** `Synapse/core/conductor.py` (lines 2827-2839)

The fix:
1. Initializes `plan_result = None`
2. Iterates through the async generator `plan_stream()`
3. Captures the result event when `type == "result"`
4. Yields all other events to maintain streaming behavior
5. Checks for `plan_result` existence before accessing its properties

## Related Files
- `Synapse/core/time_budget_planner.py` - Contains the `plan_stream()` async method
- `Synapse/core/conductor.py` - Calls the time budget planner
