# ADR: Fix Compression Negative Max Input Calculation

**Status:** Implemented  
**Date:** 2026-01-31  
**Context:** Bug fix

## Problem

The compression logic was failing with a negative `max_compressor_input` value when the requested `max_tokens` target exceeded the model's context window.

### Error Observed

```
❌ Content too large for compression: 14284 tokens. 
Maximum compressor input: -8000 tokens (model_context=8000, target=14000, safety=2000)
```

### Root Cause

The calculation for maximum compressor input was:

```python
max_compressor_input = model_context - max_tokens - safety_margin
# Example: 8000 - 14000 - 2000 = -8000 (NEGATIVE!)
```

This resulted in a negative value when `max_tokens` (14,000) was larger than `model_context` (8,000), which is logically impossible - you cannot compress content TO 14,000 tokens using a model that only has an 8,000 token context window.

## Decision

Added validation and auto-adjustment logic in two places:

### 1. UnifiedCompressor (`Synapse/core/unified_compression.py`)

- **Validate** `max_tokens` against model context window before calculation
- **Cap** `max_tokens` to a reasonable limit: `model_context - safety_margin - 1000`
- **Log warning** when auto-adjustment occurs
- **Add sanity check** to ensure `max_compressor_input` is always positive

### 2. ContentIngestionPipeline (`Synapse/core/content_ingestion.py`)

- Same validation logic applied at pipeline level
- Use `adjusted_max_tokens` when calling compressor
- Ensures consistency across both entry points

## Implementation

### Before
```python
max_compressor_input = model_context - max_tokens - safety_margin
# Could be negative if max_tokens > model_context
```

### After
```python
# Validate and cap max_tokens
max_output_reasonable = model_context - safety_margin - 1000
if max_tokens > max_output_reasonable:
    logger.warning(f"⚠️  Capping max_tokens from {max_tokens} to {max_output_reasonable}")
    max_tokens = max_output_reasonable

max_compressor_input = model_context - max_tokens - safety_margin

# Sanity check
if max_compressor_input <= 0:
    raise ValueError("Invalid compression parameters...")
```

## Consequences

### Positive
- ✅ Prevents negative max_compressor_input values
- ✅ Provides clear warnings when auto-adjustment occurs
- ✅ Fails fast with helpful error messages for invalid configurations
- ✅ Makes compression behavior more predictable and robust

### Neutral
- Auto-adjustment may compress to smaller output than requested
- Users should use `ContentIngestionPipeline` for large content anyway

### Trade-offs
- Silent auto-adjustment (with warning) vs. hard failure
  - Chose auto-adjustment to be more forgiving
  - Warning still alerts users to the issue

## Alternatives Considered

1. **Hard failure** - Reject any `max_tokens > model_context`
   - Too strict, would break existing workflows
   
2. **Use chunking automatically** - Switch to chunking when detected
   - More complex, harder to debug
   - Already handled by ContentIngestionPipeline

3. **No validation** - Let it fail in LLM call
   - Poor user experience
   - Confusing error messages

## Related

- `ContentIngestionPipeline` - Proper entry point for large content
- `UnifiedChunker` - Handles content that exceeds model context window
- Model limits catalog - Should track context windows per model
