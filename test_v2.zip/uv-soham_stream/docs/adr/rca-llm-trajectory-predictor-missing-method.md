# RCA: LLMTrajectoryPredictor Missing update_agent_model Method

**Date**: 2026-02-05  
**Status**: ✅ Implemented  
**Issue**: `⚠️ Divergence learning failed: 'LLMTrajectoryPredictor' object has no attribute 'update_agent_model'`

## Context

During divergence learning in the conductor, the code attempts to call `update_agent_model()` on `LLMTrajectoryPredictor`, but this method doesn't exist:

```
2026-02-05 16:56:04.290 | WARNING | Synapse.core.conductor:8453 | ⚠️ Divergence learning failed: 'LLMTrajectoryPredictor' object has no attribute 'update_agent_model'
```

**Location**: `Synapse/core/conductor.py` line 8434

```python
self.trajectory_predictor.update_agent_model(
    agent_name=actor_config.name,
    divergence=divergence
)
```

## 5 Whys Root Cause Analysis

### Why 1: Why is update_agent_model() being called?
**Answer**: The conductor code is trying to update agent behavior models based on divergence between predicted and actual trajectories.

### Why 2: Why doesn't the method exist?
**Answer**: The `LLMTrajectoryPredictor` class has a method called `_update_agent_models()` (with underscore, plural) but not `update_agent_model()` (public, singular).

### Why 3: Why is the wrong method name being called?
**Answer**: The conductor code was written expecting a public method `update_agent_model()`, but the actual implementation uses a private method `_update_agent_models()` with different signature.

### Why 4: Why is there a mismatch between expected and actual method names?
**Answer**: Either the conductor code was written before the predictor implementation, or the predictor was refactored without updating all call sites, or there was a miscommunication about the API.

### Why 5: Why wasn't this caught during development/testing?
**Answer**: The divergence learning code path may not be frequently executed, or tests don't cover this specific error scenario, or the method was recently added/renamed without updating callers.

## Root Cause

**The root cause is**: API mismatch between `Conductor` and `LLMTrajectoryPredictor` - the conductor calls a non-existent public method, while the predictor only has a private method with a different signature.

## Current Implementation

**In `Synapse/core/predictive_marl.py`** (line 412):
```python
def _update_agent_models(self, divergence: Divergence):
    """Update models of agent behavior."""
    # Takes Divergence object, not individual parameters
```

**In `Synapse/core/conductor.py`** (line 8434):
```python
self.trajectory_predictor.update_agent_model(
    agent_name=actor_config.name,  # Wrong signature
    divergence=divergence
)
```

## Suggested Fixes

### Fix 1: Add Public Method to LLMTrajectoryPredictor (Recommended)
**Location**: `Synapse/core/predictive_marl.py`

```python
def update_agent_model(self, agent_name: str, divergence: Divergence):
    """
    Public method to update agent behavior model based on divergence.
    
    Args:
        agent_name: Name of the agent whose model to update
        divergence: Divergence object containing predicted vs actual trajectories
    """
    # Delegate to private method
    self._update_agent_models(divergence)
    
    # Optionally filter by agent_name if needed
    if agent_name:
        # Update specific agent model if tracking per-agent
        if agent_name in self.agent_models:
            # Additional per-agent updates can go here
            pass
```

### Fix 2: Update Conductor to Use Existing Private Method
**Location**: `Synapse/core/conductor.py` (line 8434)

```python
# Change from:
self.trajectory_predictor.update_agent_model(
    agent_name=actor_config.name,
    divergence=divergence
)

# To:
self.trajectory_predictor._update_agent_models(divergence)
```

**Note**: This violates encapsulation by accessing private methods.

### Fix 3: Refactor to Match Expected API
**Location**: `Synapse/core/predictive_marl.py`

Rename and refactor `_update_agent_models()` to match the expected API:

```python
def update_agent_model(self, agent_name: str, divergence: Divergence):
    """
    Update agent behavior model based on divergence.
    
    Args:
        agent_name: Name of the agent (for logging/tracking)
        divergence: Divergence object containing predicted vs actual trajectories
    """
    for step_pred, step_actual in zip(
        divergence.predicted.steps,
        divergence.actual.steps
    ):
        agent = step_actual.get('agent', '')
        if not agent:
            continue
        
        # Filter by agent_name if provided
        if agent_name and agent != agent_name:
            continue
        
        if agent not in self.agent_models:
            self.agent_models[agent] = AgentModel(agent_name=agent)
        
        model = self.agent_models[agent]
        model.total_predictions += 1
        
        # Was prediction correct?
        if step_pred.get('action') == step_actual.get('action'):
            model.correct_predictions += 1
        else:
            # Record deviation pattern
            model.deviation_patterns.append({
                'predicted': step_pred.get('action'),
                'actual': step_actual.get('action'),
                'context': step_pred.get('state', {}),
                'timestamp': time.time()
            })
            # Keep bounded
            if len(model.deviation_patterns) > 20:
                model.deviation_patterns = model.deviation_patterns[-20:]
```

## Implementation Priority

1. **High**: Fix 1 (Add Public Method) - Cleanest solution, maintains encapsulation
2. **Medium**: Fix 3 (Refactor API) - Better long-term if we want per-agent updates
3. **Low**: Fix 2 (Use Private Method) - Quick fix but violates encapsulation

## Consequences

### Positive
- ✅ Divergence learning will work correctly
- ✅ Agent behavior models will be updated based on actual vs predicted trajectories
- ✅ Better prediction accuracy over time
- ✅ Maintains proper encapsulation

### Considerations
- ⚠️ Need to verify the method signature matches all call sites
- ⚠️ May want to add logging for model updates
- ⚠️ Consider if per-agent filtering is needed

## Testing

1. **Unit Test**: Call `update_agent_model()` with valid divergence → Should update agent models
2. **Integration Test**: Run conductor with divergence → Should not raise AttributeError
3. **Model Update Test**: Verify agent_models are actually updated after divergence learning

## Files to Modify

- `Synapse/core/predictive_marl.py` - Add `update_agent_model()` method
- `Synapse/core/conductor.py` - Verify call site matches new signature (line 8434)
