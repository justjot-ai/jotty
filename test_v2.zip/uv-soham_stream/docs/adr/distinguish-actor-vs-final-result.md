# ADR: Distinguish Actor Result vs Final Result

**Status:** Fixed  
**Date:** 2026-02-02  
**Context:** Premature Welcome Screen Return

## Problem

The app was returning to the welcome screen prematurely when **any** actor completed, instead of waiting for the **final task completion**:

```javascript
// Event #54: Actor completes
{
  "type": "result",
  "result": true,  // ← Just a boolean!
  "message": "I am returning the actor execution result"
}

// App incorrectly triggered:
🎯 [FINAL RESULT] Received: true
🏠 Returning to welcome screen...
```

This caused:
- ❌ Welcome screen shown while other tasks still running
- ❌ User couldn't see remaining task execution
- ❌ Workspace hidden too early
- ❌ Confusing UX (task not actually done)

## Root Cause

The detection logic was too broad:

```javascript
// OLD CODE - WRONG
if (type === 'result' && event.result) {
  this.handleFinalResult(event.result);  // Triggered for ANY result!
  return;
}
```

This matched both:
1. **Actor results**: `result: true` (intermediate)
2. **Final results**: `result: {metadata, final_output, ...}` (complete)

## Solution

### Distinguish by Result Structure

**Actor Result** (intermediate):
```json
{
  "type": "result",
  "result": true,  // Boolean or simple value
  "module": "Synapse.core.conductor",
  "message": "I am returning the actor execution result"
}
```

**Final Result** (complete):
```json
{
  "type": "result",
  "result": {
    "success": true,
    "final_output": "...",
    "metadata": {
      "iterations": 1,
      "cumulative_reward": 0.67,
      "execution_time": 145.55,
      "agent_contributions": {...}
    },
    "trajectory": [...],
    "error": null
  },
  "module": "Synapse.core.conductor",
  "message": "I am returning the final execution result"
}
```

### Updated Detection Logic

**File**: `electron-app/src/renderer/js/app.js`

```javascript
// 🎯 SPECIAL HANDLING: Final result event
// Only handle if result is an object with metadata (not just true/false for actor results)
if (type === 'result' && event.result && typeof event.result === 'object' && 
    (event.result.metadata || event.result.final_output !== undefined)) {
  this.handleFinalResult(event.result);
  return; // Don't log to system terminal
}
```

### Detection Criteria

The result is considered **final** if ALL of:
1. ✅ `type === 'result'`
2. ✅ `event.result` exists
3. ✅ `typeof event.result === 'object'` (not boolean/string)
4. ✅ Has `metadata` OR `final_output` property

## Event Flow

### Correct Flow (After Fix)

```
Task Start
  ↓
Task 1 Execution
  ↓
Actor Result Event (result: true)
  → Log to system terminal
  → Continue showing workspace
  ↓
Task 2 Execution
  ↓
Actor Result Event (result: true)
  → Log to system terminal
  → Continue showing workspace
  ↓
All Tasks Complete
  ↓
Final Result Event (result: {metadata, ...})
  → Return to welcome screen ✅
  → Show final output
```

### Incorrect Flow (Before Fix)

```
Task Start
  ↓
Task 1 Execution
  ↓
Actor Result Event (result: true)
  → Return to welcome screen ❌ (TOO EARLY!)
  → Task 2 never visible
```

## Debug Output

### Actor Result (Intermediate)
```javascript
🔍 [DEBUG] Event #54 received: {
  type: 'result',
  result: true,  // ← Boolean, not object
  message: 'I am returning the actor execution result'
}
// Does NOT trigger handleFinalResult()
// Logs to system terminal instead
✅ [Synapse.core.conductor] I am returning the actor execution result
```

### Final Result (Complete)
```javascript
🔍 [DEBUG] Event #55 received: {
  type: 'result',
  result: {  // ← Object with metadata
    success: true,
    metadata: {...},
    final_output: '...'
  },
  message: 'I am returning the final execution result'
}
// DOES trigger handleFinalResult()
🎯 [FINAL RESULT] Received: {...}
🏠 Returning to welcome screen...
```

## Benefits

1. **Correct Timing**: Welcome screen only shown when truly done
2. **Full Visibility**: User sees all task execution
3. **Better UX**: No premature transitions
4. **Accurate Status**: Final output reflects complete execution
5. **Multi-Task Support**: Works correctly with multiple tasks

## Testing

To verify the fix:

1. **Start a task** with multiple subtasks
2. **Watch workspace**: Should stay visible during all task execution
3. **Check console**: Actor results logged, not triggering welcome screen
4. **Wait for completion**: Welcome screen appears only at the end
5. **Check output**: Shows complete execution summary

## Message Patterns

### Actor Completion Messages
- "I am returning the actor execution result"
- "I completed executing the actor"
- Result is boolean or simple value

### Final Completion Messages
- "I am returning the final execution result"
- "I completed the task execution"
- Result is object with `metadata` and `final_output`

## Related

- `final-result-welcome-screen.md` - Welcome screen return logic
- `task-list-streaming.md` - Task list display
- `agent-cleanup-on-completion.md` - Cleanup on completion

## Lesson Learned

Always validate the **structure** of data, not just its presence:
- Check type: `typeof result === 'object'`
- Check properties: `result.metadata` or `result.final_output`
- Don't assume: `if (result)` is too broad

Use specific detection criteria to avoid false positives.
