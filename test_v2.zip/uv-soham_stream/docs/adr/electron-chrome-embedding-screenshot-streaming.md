# ADR: Embed Chrome in Electron UI via Screenshot Streaming

**Status:** Accepted  
**Date:** 2026-02-01  
**Deciders:** Architecture Team (A-Team Review)  
**Context:** User wants BrowserExecutor's Chrome window (headless=false) embedded inside Electron UI  

---

## Context

**User Requirements:**
1. BrowserExecutor runs with `headless=False` (Chrome window visible)
2. That Chrome window should be embedded inside the Electron UI (not separate window)
3. User can see browser automation happening inside the Electron app in real-time

**Current State:**
- BrowserExecutor uses Selenium WebDriver
- Chrome runs as separate process/window
- No integration with Electron UI

---

## Decision

**Implement screenshot streaming to embed browser view in Electron UI**

Use continuous screenshot capture from Selenium and stream to Electron via WebSocket, displaying in a dedicated browser panel. This provides the appearance of an embedded browser with minimal complexity.

---

## Rationale

### Options Considered

**Option 1: Native Window Embedding** ❌
- Use OS-level APIs to embed Chrome window into Electron
- Platform-specific code (macOS, Windows, Linux)
- Requires native modules (`ffi-napi`, `native-window-manager`)
- Fragile and hacky
- **Rejected:** Too complex, platform-specific, fragile

**Option 2: CDP + BrowserView** ❌
- Launch Chrome with CDP enabled
- Use Electron's BrowserView to connect
- Technically sound but complex
- Shows DevTools UI, not clean browser view
- **Rejected:** Complex, doesn't provide clean embedding

**Option 3: Screenshot Streaming** ✅ **SELECTED**
- Capture screenshots from Selenium at 10-30 FPS
- Stream via WebSocket to Electron
- Display in dedicated browser panel
- Looks like embedded browser
- **Accepted:** Simple, works on all platforms, safe

**Option 4: Puppeteer + CDP Streaming** 🔮 (Future)
- Migrate from Selenium to Puppeteer
- Native CDP streaming (better performance)
- Requires rewriting BrowserExecutor (~1900 lines)
- **Deferred:** Long-term improvement after Phase 1 validation

---

## Implementation: Three-Phase Approach

### Phase 1: Screenshot Streaming (Immediate - 2-3 hours)

**Architecture:**
```
Electron UI
├── Chat Panel (left)
└── Browser Panel (right)
    └── <img> element (live screenshots)
         ↑
         │ WebSocket (10 FPS)
         │
    Python Backend
    └── BrowserExecutor
        └── Selenium (headless=False)
            └── screenshot capture loop
```

**Backend Changes:**
- Add `start_screenshot_streaming()` function
- Capture screenshots every 100ms (10 FPS)
- Encode as base64 and broadcast via WebSocket
- Add `stream_to_electron` parameter to `initialize_browser()`
- Stop streaming when browser closes

**Frontend Changes:**
- Add browser panel to Electron UI (right side)
- Listen for `browser_frame` WebSocket events
- Update `<img>` element with base64 screenshot
- Add toggle to show/hide browser panel
- Display current URL in panel header

**Files Modified:**
- `surface/src/surface/tools/browser_tools.py` - Screenshot streaming
- `surface_synapse/integration.py` - Pass streaming flag
- `electron-app/src/renderer/index.html` - Browser panel UI
- `electron-app/src/renderer/js/app.js` - WebSocket handling
- `electron-app/src/renderer/css/styles.css` - Panel styling

**Deliverables:**
- ✅ Browser view embedded in Electron UI
- ✅ Real-time updates (10 FPS)
- ✅ Toggle visibility on/off
- ✅ Works on all platforms

---

### Phase 2: Optimization (Future - 4-5 hours)

**Improvements:**
- Increase FPS to 20-30 for smoother experience
- Use JPEG compression (smaller bandwidth)
- Adaptive FPS based on activity
- Activity logs overlay on browser view
- Highlight elements being interacted with

---

### Phase 3: Puppeteer Migration (Future - 2-3 weeks)

**Improvements:**
- Migrate from Selenium to Puppeteer/pyppeteer
- Native CDP streaming (2-3x faster)
- Better quality and lower latency (~50ms)
- True real-time streaming

---

## Consequences

### Positive
- ✅ User sees browser automation in Electron UI
- ✅ Quick implementation (2-3 hours)
- ✅ Works on all platforms (no platform-specific code)
- ✅ No security risks (process isolation maintained)
- ✅ No breaking changes
- ✅ Leverages existing WebSocket infrastructure
- ✅ Looks like true embedding (good UX)

### Negative
- ⚠️ Not "true" embedding (it's a video feed)
- ⚠️ Latency (~100-200ms)
- ⚠️ CPU overhead (~5-10% for screenshot capture)
- ⚠️ Network bandwidth (~1-2 Mbps at 10 FPS)
- ⚠️ Quality limited by screenshot resolution

### Neutral
- Can upgrade to Puppeteer later for better performance
- User likely won't notice it's not "true" embedding
- Good enough for monitoring and visibility

---

## Technical Details

### Screenshot Capture

```python
# In browser_tools.py
async def start_screenshot_streaming(websocket_manager, interval: float = 0.1):
    """Stream screenshots at specified FPS."""
    global _screenshot_streaming_active, _browser_driver
    
    _screenshot_streaming_active = True
    
    while _screenshot_streaming_active and _browser_driver:
        try:
            # Capture screenshot (Selenium)
            screenshot = _browser_driver.get_screenshot_as_base64()
            current_url = _browser_driver.current_url
            
            # Broadcast to Electron
            await websocket_manager.broadcast({
                "type": "browser_frame",
                "data": screenshot,
                "url": current_url,
                "timestamp": datetime.now().isoformat()
            })
            
            await asyncio.sleep(interval)  # 10 FPS
            
        except Exception as e:
            logger.error(f"Screenshot streaming error: {e}")
            await asyncio.sleep(1)
```

### Electron Display

```javascript
// In app.js
socket.on('browser_frame', (data) => {
  const browserFrame = document.getElementById('browser-frame');
  const browserUrl = document.getElementById('browser-url');
  
  // Update image
  browserFrame.src = `data:image/png;base64,${data.data}`;
  
  // Update URL
  browserUrl.textContent = data.url;
});
```

---

## Performance Impact

| Metric | Current | Phase 1 | Phase 2 | Phase 3 |
|--------|---------|---------|---------|---------|
| Latency | N/A | ~200ms | ~100ms | ~50ms |
| FPS | N/A | 10 | 20-30 | 30+ |
| CPU Overhead | 0% | 5-10% | 5-10% | 3-5% |
| Bandwidth | 0 | 1-2 Mbps | 1-2 Mbps | 0.5-1 Mbps |
| Development | 0 | 2-3 hrs | 4-5 hrs | 2-3 weeks |

---

## Security Considerations

### Phase 1 (Low Risk)
- ✅ No CDP port exposure
- ✅ Process isolation maintained
- ✅ No new attack vectors
- ✅ WebSocket already secured
- ✅ Screenshot data is read-only

### Future Phases
- Phase 3 will require CDP security review
- Need authentication for CDP connections
- Bind CDP to 127.0.0.1 only
- Implement rate limiting

---

## Testing Strategy

### Manual Tests
1. Enable browser streaming → Panel appears with live feed
2. Run browser task → Screenshots update in real-time
3. Toggle panel → Panel hides/shows correctly
4. Disable streaming → Placeholder appears
5. Close browser → Streaming stops gracefully
6. Multiple tasks → No memory leaks

### Performance Tests
1. Monitor CPU usage during streaming
2. Monitor WebSocket bandwidth
3. Test with long-running tasks (30+ minutes)
4. Test with multiple browser tabs

### Cross-Platform Tests
1. macOS - Verify rendering and performance
2. Windows - Verify rendering and performance
3. Linux - Verify rendering and performance

---

## Success Criteria

- ✅ Browser view appears in Electron UI
- ✅ Updates in real-time (< 200ms latency)
- ✅ CPU overhead < 15%
- ✅ No security vulnerabilities
- ✅ Works on macOS, Windows, Linux
- ✅ Implementation complete in < 3 hours
- ✅ User can toggle visibility
- ✅ No breaking changes to existing functionality

---

## Alternatives Rejected

### Why not native window embedding?
- Platform-specific code (different for macOS/Windows/Linux)
- Requires native modules with potential security issues
- Fragile (breaks if window title changes)
- Complex window management (resize, focus, etc.)

### Why not CDP + BrowserView?
- Complex to implement correctly
- Shows DevTools UI, not clean browser view
- CDP doesn't directly provide "embed this page" functionality
- More complex than screenshot streaming

### Why not immediate Puppeteer migration?
- Requires rewriting ~1900 lines of browser_tools.py
- High risk of breaking existing functionality
- 2-3 weeks of development time
- Better as gradual migration after Phase 1 validation

---

## Migration Path

**Phase 1 → Phase 2:**
- Optimize screenshot capture (JPEG, higher FPS)
- Add activity logs overlay
- Improve UI/UX

**Phase 2 → Phase 3:**
- Create `PuppeteerBrowserExecutor` agent
- Port browser tools incrementally
- Run both agents in parallel
- Deprecate Selenium after 6 months

---

## Related Decisions

- [A-Team Review: Final Chrome Embedding Plan](../review/A_TEAM_FINAL_CHROME_EMBEDDING_PLAN.md)
- [electron-perform-api-streaming-integration.md](./electron-perform-api-streaming-integration.md)

---

## References

- Selenium WebDriver: https://www.selenium.dev/documentation/webdriver/
- Electron BrowserView: https://www.electronjs.org/docs/latest/api/browser-view
- Chrome DevTools Protocol: https://chromedevtools.github.io/devtools-protocol/
- Puppeteer: https://pptr.dev/

---

## Implementation Checklist

### Backend
- [ ] Add `start_screenshot_streaming()` function
- [ ] Add `stop_screenshot_streaming()` function
- [ ] Update `initialize_browser()` with `stream_to_electron` parameter
- [ ] Update `close_browser()` to stop streaming
- [ ] Add WebSocket broadcast for screenshots
- [ ] Test screenshot capture performance

### Frontend
- [ ] Add browser panel to HTML
- [ ] Add browser panel CSS styling
- [ ] Add WebSocket handler for `browser_frame` events
- [ ] Add toggle for browser panel visibility
- [ ] Add URL display in panel header
- [ ] Add placeholder for inactive state
- [ ] Test on all platforms

### Integration
- [ ] Update `integration.py` to pass streaming flag
- [ ] Update `/api/v1/perform` to accept `stream_browser` context
- [ ] Test end-to-end flow
- [ ] Verify WebSocket connection stability
- [ ] Test with multiple concurrent tasks

### Documentation
- [ ] Update user documentation
- [ ] Add screenshots/demo
- [ ] Document toggle usage
- [ ] Document performance characteristics

---

## Notes

**Team Consensus:**
- Alex (Architect): "Screenshot streaming is the pragmatic choice"
- Jordan (Backend): "Quick win now, Puppeteer later"
- Casey (Frontend): "Can implement this afternoon!"
- Morgan (DevOps): "Safe, secure, and practical"

**Key Insight:** User wants to SEE browser activity, not necessarily true embedding. Screenshot streaming provides 90% of the value with 10% of the complexity.
