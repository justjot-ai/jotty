# ADR: Fix Undefined 'solution' Variable in Retry Logic

**Status:** Fixed  
**Date:** 2026-01-30  
**Context:** Bug fix for NameError in conductor retry logic

---

## Problem

```python
NameError: name 'solution' is not defined
```

At line 6475 in `Synapse/core/conductor.py`:
```python
if not solution.get('should_retry', True):
    logger.info(f"🛑 LLM decided not to retry: {solution.get('reason', 'N/A')}")
    break
```

The variable `solution` was referenced but never defined, causing a crash during error retry logic.

---

## Root Cause

Leftover code from a refactoring where LLM-based retry decision logic was removed. The code was:

1. Creating error context with hardcoded `'should_retry': True` (line 6471)
2. Then trying to check `solution.get('should_retry')` (line 6475) - but `solution` doesn't exist

This is redundant logic since:
- The `should_retry` is hardcoded to `True` anyway
- Actual retry control is handled by the loop's `max_retries` check

---

## Solution

**Removed lines 6475-6477:**
```python
# Decide if we should retry
if not solution.get('should_retry', True):
    logger.info(f"🛑 LLM decided not to retry: {solution.get('reason', 'N/A')}")
    break
```

The retry logic is already properly handled by:
1. The for loop: `for attempt in range(max_retries)`
2. The last-attempt check:
   ```python
   if attempt == max_retries - 1:
       logger.error(f"💥 {actor_config.name} exhausted all {max_retries} retries")
       raise
   ```

---

## Impact

✅ Fixes NameError crash during actor retries  
✅ Simplifies retry logic (removes redundant check)  
✅ No behavior change (retry logic works the same)  

---

## Files Changed

- `Synapse/core/conductor.py` - Line 6475-6477 removed

---

## Testing

Run any task that causes an actor to fail and retry - it should now retry properly without crashing with NameError.

Example:
```bash
./scripts/run_solve_task.sh "Summarize messages of whatsapp group synapse"
```
