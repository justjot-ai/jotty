# RCA: LiteLLM Logging Worker Timeout Error

**Date**: 2026-02-05  
**Status**: Already Addressed (See Existing ADR)  
**Issue**: `ERROR | LiteLLM:103 | LoggingWorker error: TimeoutError`

## Context

This error has already been analyzed and fixed. See existing ADR:
- **File**: `docs/adr/litellm-logging-worker-timeout-fix.md`
- **Status**: Implemented

## Summary

The LiteLLM logging worker timeout error occurs when LiteLLM's async logging worker times out while trying to log API calls. This is a non-critical error that doesn't affect functionality but clutters logs.

## Root Cause

**The timeout is NOT from Synapse's TimeBudgetPlanner or any time budget agent logic.**

The timeout comes from **LiteLLM's own internal logging worker** (`litellm_core_utils/logging_worker.py`):

1. **Source**: LiteLLM's `LoggingWorker._process_log_task()` method (line 98)
2. **Mechanism**: Uses `asyncio.wait_for()` with a timeout value
3. **Purpose**: LiteLLM tries to log API calls asynchronously in a background worker
4. **Problem**: The async logging handler can be cancelled or take too long, causing `TimeoutError`

**Key Point**: This is **completely independent** of Synapse's timeout system:
- Synapse's `TimeBudgetPlanner` assigns timeouts to **actors** (e.g., TerminalExecutor: 120s)
- Synapse's `actor_timeout` config controls **actor execution timeouts** (default: 900s)
- LiteLLM's logging worker timeout is **internal to LiteLLM** and controls how long it waits to log API calls

**The timeout value**: LiteLLM uses its own internal timeout (likely a few seconds) for the logging worker, not Synapse's timeout values.

## Solution Implemented

The fix disables LiteLLM's logging worker by:
1. Setting `LITELLM_LOG` environment variable to `"ERROR"` before importing litellm
2. Setting `litellm.set_verbose = False`
3. Clearing any existing callbacks

**Locations**:
- `uv/src/uv/services/swarm_service.py`
- `surface/src/surface/surface.py`

## Current Status

✅ **Fixed** - See `docs/adr/litellm-logging-worker-timeout-fix.md` for full details.

## Relationship to Synapse Timeout System

**Important**: The LiteLLM logging worker timeout is **NOT related** to:
- ❌ `TimeBudgetPlanner` - This assigns timeouts to actors, not to LiteLLM logging
- ❌ `actor_timeout` config - This controls actor execution timeouts
- ❌ `llm_timeout_seconds` config - This controls LLM API call timeouts
- ❌ `AdaptiveTimeout` - This adapts actor execution timeouts

**The LiteLLM logging worker timeout is**:
- ✅ Internal to LiteLLM's logging infrastructure
- ✅ Used only for background async logging of API calls
- ✅ Separate from actual API call timeouts
- ✅ A non-critical logging feature that can be safely disabled

## Note

If this error is still appearing, verify that:
1. The fix has been applied to all entry points
2. Environment variables are set before litellm import
3. No other code is re-enabling verbose logging
4. The error is NOT from Synapse's timeout system (check stack trace - should show `litellm_core_utils/logging_worker.py`)
