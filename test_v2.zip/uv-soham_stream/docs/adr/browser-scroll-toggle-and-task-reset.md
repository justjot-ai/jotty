# ADR: Browser Card Scroll Toggle and Task Reset

**Date:** 2026-02-02  
**Status:** Implemented  
**Context:** Electron UI browser embedding behavior

---

## Context

When the BrowserExecutor agent is active, a native Electron BrowserView is displayed overlaying the browser module card in the agents grid. Two issues were identified:

1. **Scroll Visibility Issue:** When there are 4+ module cards active, the grid scrolls. If the browser card is pushed below the visible area (positions 4+), the BrowserView still attempts to render at its calculated bounds, potentially appearing outside the visible viewport or in incorrect positions.

2. **Task Lifecycle Issue:** When a user completes a task and starts a new one, the old browser state (page content, local storage) persists, which may cause confusion or interference with the new task.

---

## Decision

### Part 1: Auto-Hide Browser When Card Scrolls

**Behavior:**
- Track the browser card's position index in the grid
- When position >= 4 (not in first 2 rows of 2x2 grid), automatically detach the BrowserView
- Show a toggle button allowing the user to manually display the browser on demand
- When card moves back to visible area (positions 0-3), update toggle text but don't auto-show

**Implementation:**
- `checkBrowserCardPosition()` - Returns card index and visibility status
- `updateBrowserVisibilityForScroll()` - Called after card reordering animations
- `hideBrowserDueToScroll()` - Detaches BrowserView and shows toggle
- `showBrowserToggleButton()` - Renders toggle UI in card placeholder
- `toggleBrowserDisplay()` - Handles user click to show/hide browser

### Part 2: Browser Reset on New Task

**Behavior:**
- When user starts a new task, reset the browser to a clean state
- Navigate to `about:blank`
- Clear localStorage, IndexedDB, service workers, cache
- **Preserve cookies** to maintain login sessions

**Implementation:**
- `browser-reset` IPC handler in main.js
- `browserAPI.reset()` exposed via preload.js
- Called in `sendMessageWorkspace()` before task execution

---

## Consequences

### Positive
- BrowserView no longer renders in wrong position when scrolled
- Users have explicit control over browser visibility
- Resource-efficient: detached BrowserView doesn't consume GPU compositing
- New tasks start with clean browser state
- Login sessions preserved across tasks (cookies remain)

### Negative
- Users must manually click toggle to re-show browser after scrolling
- Slight UX friction when browser card is frequently pushed down

---

## Files Modified

| File | Changes |
|------|---------|
| `electron-app/src/main.js` | Added `browser-reset`, `browser-detach-preserve`, `browser-reattach` IPC handlers |
| `electron-app/src/preload.js` | Added `reset`, `detachPreserve`, `reattach` to browserAPI |
| `electron-app/src/renderer/js/agent-view-manager.js` | Added visibility tracking, toggle button, and scroll detection |
| `electron-app/src/renderer/js/app.js` | Added browser reset call on new task |
| `electron-app/src/renderer/css/agent-views.css` | Added toggle button styles |

---

## API Reference

### New IPC Handlers (main.js)

```javascript
// Reset browser for new task
ipcMain.handle('browser-reset', async () => { ... });

// Detach but preserve state
ipcMain.handle('browser-detach-preserve', async () => { ... });

// Reattach previously detached browser
ipcMain.handle('browser-reattach', async () => { ... });
```

### Browser API (preload.js)

```javascript
browserAPI.reset()          // Reset for new task
browserAPI.detachPreserve() // Detach but keep state
browserAPI.reattach()       // Reattach to window
```

---

## Related

- A-Team Review: `docs/review/A_TEAM_BROWSER_SCROLLED_TOGGLE_REVIEW.md`
- Previous ADR: `docs/adr/electron-native-browser-embedding.md`
