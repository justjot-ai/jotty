# ADR: Task List Streaming to Frontend

**Status:** Implemented  
**Date:** 2026-02-02  
**Context:** Backend Task Visibility

## Decision

Stream the complete list of created tasks from the backend to the Electron frontend for debugging and visibility.

## Problem

The frontend had no visibility into:
- How many tasks were created
- What each task's details are (description, actor, dependencies)
- Task status, priority, and estimated rewards
- Task dependency graph structure

This made debugging and monitoring difficult.

## Solution

### Backend Changes

**File**: `Synapse/core/roadmap.py`

Added `get_all_tasks_list()` method to `MarkovianTODO`:
```python
def get_all_tasks_list(self) -> List[Dict[str, Any]]:
    """Get complete list of all tasks with their details."""
    tasks_list = []
    for task_id, task in self.subtasks.items():
        tasks_list.append({
            'task_id': task_id,
            'description': task.description,
            'actor': task.actor,
            'status': task.status.value,
            'priority': task.priority,
            'estimated_reward': task.estimated_reward,
            'confidence': task.confidence,
            'progress': task.progress,
            'depends_on': task.depends_on,
            'blocks': task.blocks,
            'attempts': task.attempts,
            'max_attempts': task.max_attempts,
            'failure_reasons': task.failure_reasons,
            'created_at': task.created_at.isoformat() if task.created_at else None,
            'started_at': task.started_at.isoformat() if task.started_at else None,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None,
        })
    return tasks_list
```

**File**: `Synapse/core/conductor.py`

Yield task list event at two key points:

1. **After TODO initialization** (when tasks are first created)
2. **After TODO sync with dependency graph** (when tasks are validated)

```python
all_tasks = self.todo.get_all_tasks_list()
yield {
    "module": "Synapse.core.conductor",
    "message": f"I have created {len(all_tasks)} tasks in total",
    "type": "task_list",
    "data": {
        "total_tasks": len(all_tasks),
        "tasks": all_tasks,
        "root_task": self.todo.root_task,
        "completed_count": len(self.todo.completed_tasks),
        "failed_count": len(self.todo.failed_tasks)
    }
}
```

### Frontend Changes

**File**: `electron-app/src/renderer/js/app.js`

Added `handleTaskListEvent()` method to process and display task lists:

```javascript
handleTaskListEvent(data) {
    const { total_tasks, tasks, root_task, completed_count, failed_count } = data;
    
    // Log detailed breakdown to console
    console.log(`📋 [TASK LIST] Root Task: ${root_task}`);
    console.log(`📋 [TASK LIST] Total Tasks: ${total_tasks}`);
    
    tasks.forEach((task, index) => {
        console.log(`  ${index + 1}. [${task.status}] ${task.description}`);
        console.log(`     - Actor: ${task.actor}`);
        console.log(`     - Priority: ${task.priority}`);
        console.log(`     - Dependencies: ${task.depends_on}`);
    });
    
    // Display summary in UI
    this.appendLogToSystem(`📋 Task List: ${total_tasks} tasks created`);
}
```

## Event Format

**Type**: `task_list`

**Structure**:
```json
{
  "module": "Synapse.core.conductor",
  "message": "I have created 5 tasks in total",
  "type": "task_list",
  "data": {
    "total_tasks": 5,
    "root_task": "Search for Python tutorials",
    "completed_count": 0,
    "failed_count": 0,
    "tasks": [
      {
        "task_id": "task_1",
        "description": "Break down search query",
        "actor": "PlannerAgent",
        "status": "pending",
        "priority": 0.9,
        "estimated_reward": 0.8,
        "confidence": 0.7,
        "progress": 0.0,
        "depends_on": [],
        "blocks": ["task_2"],
        "attempts": 0,
        "max_attempts": 5,
        "failure_reasons": [],
        "created_at": "2026-02-02T12:00:00",
        "started_at": null,
        "completed_at": null
      }
    ]
  }
}
```

## Benefits

1. **Full Visibility**: See every task created by the system
2. **Dependency Tracking**: Understand task relationships
3. **Status Monitoring**: Track task progress in real-time
4. **Debug Aid**: Identify issues with task creation or assignment
5. **Performance Insights**: See Q-values, priorities, and confidence scores

## Console Output Example

```
📋 [TASK LIST] Root Task: Check WhatsApp for unread messages
📋 [TASK LIST] Total Tasks: 8
📋 [TASK LIST] Completed: 0
📋 [TASK LIST] Failed: 0
📋 [TASK LIST] Task Breakdown:
  1. [pending] Open WhatsApp Web
     - Task ID: task_1
     - Actor: BrowserExecutor
     - Priority: 0.95
     - Estimated Reward: 0.85
     - Progress: 0.0%
  2. [pending] Navigate to messages
     - Task ID: task_2
     - Actor: BrowserExecutor
     - Priority: 0.90
     - Dependencies: task_1
```

## UI Display

### Left Sidebar - Task List Panel

The task list is displayed in the left sidebar with:

**Header:**
- Root task with goal emoji
- Statistics: total tasks, completed, failed

**Task Groups:**
- Tasks grouped by status (in_progress, pending, blocked, completed, failed, skipped)
- Each group shows count and icon

**Task Items:**
- Description and actor assignment
- Priority indicator (high/medium)
- Progress bar for in-progress tasks
- Dependency count
- Attempt count for failed tasks
- Color-coded left border by status
- Pulse animation for in-progress tasks

**Badge:**
- Top-right badge shows "completed/total" (e.g., "3/8")

### System Terminal

Also logs summary:
```
📋 Task List: 8 tasks created
   Root: Check WhatsApp for unread messages
   Status: 0 completed, 0 failed
   pending: 8
```

## Visual Design

**Status Colors:**
- 🔄 In Progress: Cyan border with pulse animation
- ⏳ Pending: Yellow border
- ✅ Completed: Green border (70% opacity)
- ❌ Failed: Red border
- 🚫 Blocked: Gray border (60% opacity)
- ⏭️ Skipped: Gray border (50% opacity)

**Priority Indicators:**
- ⚡ High (>70%): Yellow badge
- 📊 Medium (>40%): Cyan badge

**Interactive:**
- Hover effect: slight translation and background change
- Click-ready for future task detail expansion

## Files Modified

### Backend
- `Synapse/core/roadmap.py` - Added `get_all_tasks_list()` method
- `Synapse/core/conductor.py` - Yield task_list events

### Frontend
- `electron-app/src/renderer/js/app.js` - Added `displayTaskListInSidebar()` method
- `electron-app/src/renderer/css/styles.css` - Added task list styles

## Related

- Debug mode logging (`electron-debug-mode-logging.md`)
- `/api/v1/perform` SSE streaming
- `MarkovianTODO` state management
