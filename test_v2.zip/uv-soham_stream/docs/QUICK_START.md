# UV FastAPI - Quick Start Guide

Get started with the UV FastAPI application in 5 minutes.

## 1. Install Dependencies

```bash
cd uv
poetry install
```

## 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` and add your API keys:
- `LITELLM_API_KEY` - Your LiteLLM API key
- `SERPER_API_KEY` - Your Serper API key (for web search)

## 3. Start the Server

```bash
./run_server.sh
```

Or manually:

```bash
poetry run uvicorn uv.main:app --reload
```

## 4. Test the API

Visit http://localhost:8000/docs for interactive API documentation.

### Health Check

```bash
curl http://localhost:8000/health
```

### Execute a Task

```bash
curl -N -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "What are the top 3 Python web frameworks?"
  }'
```

Or use the example client:

```bash
python example_perform_client.py "What is FastAPI?"
```

## 5. Run Tests

```bash
poetry run pytest
```

With coverage:

```bash
poetry run pytest --cov=uv --cov-report=html
open htmlcov/index.html
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/health/ready` | Readiness probe |
| GET | `/health/live` | Liveness probe |
| POST | `/api/v1/perform` | Execute task via Synapse (SSE streaming) |

## Project Structure

```
uv/
├── src/uv/              # Source code
│   ├── api/            # API routes
│   ├── schemas/        # Pydantic models
│   ├── services/       # Business logic
│   ├── utils/          # Utilities
│   └── main.py         # Application entry
├── tests/              # Test suite
├── pyproject.toml      # Dependencies
└── .env                # Configuration
```

## Task Execution API

Execute tasks using Synapse orchestration with real-time streaming:

```bash
# Using curl (streaming)
curl -N -X POST "http://localhost:8000/api/v1/perform" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "What are the top 3 Python frameworks?"
  }'

# Using Python client
python example_perform_client.py "What is FastAPI?"

# Run examples
./example_perform.sh
./example_perform_stream.sh
```

The `/perform` endpoint automatically selects appropriate agents:
- **WebSearchAgent** for research tasks
- **BrowserExecutor** for web automation  
- **TerminalExecutor** for command execution
- Multiple agents can work together on complex tasks

**Features**:
- Real-time progress updates via Server-Sent Events (SSE)
- Automatic agent selection based on task requirements
- Context support for providing additional information
- Configurable via environment variables

## Next Steps

1. **Deploy**: Deploy with Docker or directly on a server
2. **Extend**: Add custom agents and capabilities
3. **Monitor**: Set up logging and monitoring
4. **Scale**: Configure load balancing for production

## Troubleshooting

### Port Already in Use

```bash
# Change port in .env
PORT=8001
```

### API Keys Not Working

Make sure you've set the required environment variables in `.env`:
- `LITELLM_API_KEY`
- `LITELLM_BASE_URL`
- `SERPER_API_KEY`

### Poetry Not Found

```bash
# Install poetry
curl -sSL https://install.python-poetry.org | python3 -
```

### Synapse Swarm Fails to Initialize

Check that all required dependencies are installed and API keys are valid.

## Resources

- Full documentation: See `README.md`
- Performance guide: See `PERFORMANCE.md`
- API docs: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc
- FastAPI docs: https://fastapi.tiangolo.com
