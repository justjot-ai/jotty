# UV Assistant - Application Build Guide

This guide explains how to build and package the UV Assistant desktop application for distribution across Windows, macOS, and Linux platforms.

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Project Structure](#project-structure)
4. [Build Process](#build-process)
5. [Platform-Specific Instructions](#platform-specific-instructions)
6. [Troubleshooting](#troubleshooting)
7. [Distribution](#distribution)

## Overview

The UV Assistant application consists of two main components:

1. **Python Backend**: FastAPI server (UV) with Synapse, Surface, and surface_synapse packages
2. **Electron Frontend**: Desktop UI with embedded browser and terminal capabilities

The build process bundles both components into a single distributable application.

## Prerequisites

### Required Software

#### All Platforms

- **Python 3.13+**: [Download](https://www.python.org/downloads/)
- **Node.js 18+**: [Download](https://nodejs.org/)
- **Poetry**: Python dependency manager
  ```bash
  curl -sSL https://install.python-poetry.org | python3 -
  ```
- **PyInstaller**: Python bundling tool
  ```bash
  pip install pyinstaller
  ```

#### macOS Specific

- **Xcode Command Line Tools**:
  ```bash
  xcode-select --install
  ```

#### Windows Specific

- **Visual Studio Build Tools**: [Download](https://visualstudio.microsoft.com/downloads/)
- **NSIS** (optional, for custom installers): [Download](https://nsis.sourceforge.io/)

#### Linux Specific

- **Build essentials**:
  ```bash
  sudo apt-get install build-essential
  ```

### Install Build Dependencies

```bash
# Install Python build dependencies
pip install -r build-requirements.txt

# Install Node.js build dependencies (in electron-app directory)
cd electron-app
npm install
cd ..
```

## Project Structure

```
term/
├── electron-app/          # Electron frontend
│   ├── src/
│   │   ├── main.js       # Electron main process
│   │   ├── preload.js    # Preload script
│   │   └── renderer/     # UI components
│   ├── resources/        # App resources (created during build)
│   └── package.json
├── uv/                   # FastAPI backend
│   ├── src/uv/
│   └── pyproject.toml
├── Synapse/              # Synapse core package
├── surface/              # Surface package
├── surface_synapse/      # Integration package
├── scripts/
│   ├── build_application.py  # Main build script
│   ├── build_app.sh         # Unix build wrapper
│   └── build_app.bat        # Windows build wrapper
├── build/                # Build artifacts (created)
└── dist/                 # Final distributions (created)
```

## Build Process

### Quick Start

#### macOS/Linux

```bash
# Make the script executable
chmod +x scripts/build_app.sh

# Build for current platform
./scripts/build_app.sh

# Build for specific platform
./scripts/build_app.sh --platform mac

# Clean build
./scripts/build_app.sh --clean --platform mac
```

#### Windows

```cmd
REM Build for Windows
scripts\build_app.bat

REM Build for specific platform
scripts\build_app.bat --platform win

REM Clean build
scripts\build_app.bat --clean
```

### Build Steps Explained

The build process performs the following steps:

1. **Clean Build Artifacts**: Removes previous build outputs
2. **Install Dependencies**: Installs Python and Node.js dependencies
3. **Bundle Python Backend**: Uses PyInstaller to create standalone Python executable
4. **Copy Backend to Electron**: Places bundled backend in Electron resources
5. **Update Electron Config**: Modifies package.json to include backend
6. **Create Startup Scripts**: Generates platform-specific startup scripts
7. **Build Electron App**: Uses electron-builder to create distributable
8. **Copy Final Artifacts**: Moves completed builds to dist directory
9. **Generate Documentation**: Creates README for distribution

### Manual Build Process

If you prefer to run the build steps manually:

```bash
# 1. Clean previous builds
rm -rf build dist electron-app/dist electron-app/build

# 2. Install Python dependencies
poetry install --no-dev
cd uv && poetry install --no-dev && cd ..

# 3. Install Node.js dependencies
cd electron-app && npm install && cd ..

# 4. Run the Python build script
python scripts/build_application.py --platform mac

# 5. Check the dist directory for output
ls -la dist/
```

## Platform-Specific Instructions

### macOS

#### Building

```bash
./scripts/build_app.sh --platform mac
```

#### Output

- **DMG Installer**: `dist/UV-1.0.0.dmg`
- **App Bundle**: `dist/mac/UV.app`

#### Code Signing (Optional)

For distribution outside the App Store, you'll need to sign the app:

```bash
# Sign the app
codesign --deep --force --verify --verbose --sign "Developer ID Application: Your Name" dist/mac/UV.app

# Create signed DMG
electron-builder --mac --config.mac.identity="Developer ID Application: Your Name"
```

#### Notarization (Optional)

For Gatekeeper approval:

```bash
# Submit for notarization
xcrun notarytool submit dist/UV-1.0.0.dmg --apple-id your@email.com --team-id TEAMID --wait

# Staple the notarization ticket
xcrun stapler staple dist/UV-1.0.0.dmg
```

### Windows

#### Building

```cmd
scripts\build_app.bat --platform win
```

#### Output

- **NSIS Installer**: `dist\UV Setup 1.0.0.exe`
- **Portable**: `dist\win-unpacked\`

#### Code Signing (Optional)

```cmd
REM Sign the executable
signtool sign /f certificate.pfx /p password /tr http://timestamp.digicert.com /td sha256 /fd sha256 "dist\UV Setup 1.0.0.exe"
```

### Linux

#### Building

```bash
./scripts/build_app.sh --platform linux
```

#### Output

- **AppImage**: `dist/UV-1.0.0.AppImage`
- **Unpacked**: `dist/linux-unpacked/`

#### Making AppImage Executable

```bash
chmod +x dist/UV-1.0.0.AppImage
```

### Cross-Platform Build

To build for all platforms (requires appropriate OS or CI/CD):

```bash
./scripts/build_app.sh --platform all
```

**Note**: Cross-platform builds have limitations:
- Windows builds require Windows or Wine
- macOS builds require macOS (cannot be built on Linux/Windows)
- Linux builds can be created on any platform

## Troubleshooting

### Common Issues

#### PyInstaller Import Errors

**Problem**: Missing modules in bundled application

**Solution**: Add hidden imports to `build_application.py`:

```python
hiddenimports=[
    'your_missing_module',
    # ... other imports
]
```

#### Electron Builder Fails

**Problem**: electron-builder fails with permission errors

**Solution**:
```bash
# Clear electron-builder cache
rm -rf ~/Library/Caches/electron-builder  # macOS
rm -rf ~/.cache/electron-builder          # Linux
del /s /q %LOCALAPPDATA%\electron-builder # Windows
```

#### Backend Not Starting

**Problem**: Bundled backend fails to start

**Solution**: Check startup scripts in `electron-app/resources/`:
- Ensure paths are correct
- Verify environment variables
- Check backend logs

#### Large Bundle Size

**Problem**: Final application is too large

**Solution**:
- Exclude unnecessary dependencies
- Use `upx` compression (enabled by default)
- Remove development dependencies

### Debug Mode

To build with debug output:

```bash
# Enable PyInstaller debug mode
python scripts/build_application.py --platform mac --debug

# Run Electron in dev mode
cd electron-app
npm run dev
```

### Logs

Build logs are stored in:
- **PyInstaller**: `build/uv_backend/warn-uv_backend.txt`
- **Electron**: `electron-app/dist/.build-log`

## Distribution

### File Sizes (Approximate)

- **macOS DMG**: ~200-300 MB
- **Windows Installer**: ~150-250 MB
- **Linux AppImage**: ~200-300 MB

### Distribution Checklist

- [ ] Test on clean system without development tools
- [ ] Verify backend starts correctly
- [ ] Test all UI features
- [ ] Check browser embedding works
- [ ] Verify terminal functionality
- [ ] Test auto-update mechanism (if implemented)
- [ ] Create release notes
- [ ] Upload to distribution platform

### Hosting Options

1. **GitHub Releases**: Free, simple
2. **AWS S3**: Scalable, CDN support
3. **Electron Release Server**: Self-hosted
4. **App Stores**: Official distribution channels

### Auto-Updates

To enable auto-updates, configure `electron-updater` in `package.json`:

```json
{
  "build": {
    "publish": {
      "provider": "github",
      "owner": "yourusername",
      "repo": "term"
    }
  }
}
```

## CI/CD Integration

### GitHub Actions Example

Create `.github/workflows/build.yml`:

```yaml
name: Build Application

on:
  push:
    tags:
      - 'v*'

jobs:
  build-mac:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.13'
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Build
        run: ./scripts/build_app.sh --platform mac
      - uses: actions/upload-artifact@v3
        with:
          name: mac-build
          path: dist/*.dmg

  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.13'
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Build
        run: scripts\build_app.bat --platform win
      - uses: actions/upload-artifact@v3
        with:
          name: windows-build
          path: dist/*.exe

  build-linux:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.13'
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Build
        run: ./scripts/build_app.sh --platform linux
      - uses: actions/upload-artifact@v3
        with:
          name: linux-build
          path: dist/*.AppImage
```

## Advanced Configuration

### Custom Icons

Place platform-specific icons in `electron-app/assets/`:
- **macOS**: `icon.icns` (512x512 or larger)
- **Windows**: `icon.ico` (256x256 with multiple sizes)
- **Linux**: `icon.png` (512x512)

### Environment Variables

Configure build-time environment variables in `build_application.py`:

```python
# Add to PyInstaller spec
os.environ['UV_HOST'] = '127.0.0.1'
os.environ['UV_PORT'] = '8000'
```

### Custom Installers

Modify `electron-app/package.json` build configuration:

```json
{
  "build": {
    "nsis": {
      "oneClick": false,
      "allowToChangeInstallationDirectory": true
    }
  }
}
```

## Support

For build issues:
1. Check this guide's troubleshooting section
2. Review build logs
3. Open an issue on GitHub
4. Contact the development team

## License

MIT License - See LICENSE file for details
