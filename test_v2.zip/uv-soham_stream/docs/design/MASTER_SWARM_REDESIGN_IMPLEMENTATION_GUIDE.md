# MASTER SWARM REDESIGN: Complete Implementation Guide

**Date:** 2026-01-28  
**Version:** 1.0 - FINAL CONSOLIDATED  
**Purpose:** Single source of truth for agent collaboration implementation  
**Use:** Reference this document for ALL changes - nothing else needed

---

## 📋 TABLE OF CONTENTS

1. [Executive Summary](#executive-summary)
2. [Root Cause Analysis](#root-cause-analysis)
3. [Why Latest Log Failed](#why-latest-log-failed)
4. [Architecture: Before vs After](#architecture-before-vs-after)
5. [Components to Build](#components-to-build)
6. [File-by-File Changes](#file-by-file-changes)
7. [Implementation Roadmap (200 Steps)](#implementation-roadmap)
8. [Code Examples](#code-examples)
9. [Testing Strategy](#testing-strategy)
10. [Success Metrics](#success-metrics)

---

## 🎯 EXECUTIVE SUMMARY

### The Problem (In 3 Sentences)
You built a complete multi-agent communication system (`SmartAgentSlack`), but agents don't have access to it. It's like building a Slack workspace where nobody has login credentials. Agents work in isolation despite having all the infrastructure for collaboration.

### The Root Cause
**Agents don't have references to:**
1. `agent_slack` - Can't send/receive messages
2. `agent_directory` - Don't know other agents exist
3. Collaboration methods - No `request_help()` or `share_knowledge()`

**File:** `Synapse/core/conductor.py` line 5100  
**Problem:** `_execute_actor()` doesn't inject collaboration context into agents

### The Fix (3 Phases)
**Phase 1 (Week 1):** Create agent directory + collaboration mixin  
**Phase 2 (Week 2):** Inject into agents + enhance signatures  
**Phase 3 (Week 3):** Process collaboration actions + test

### Expected Impact
- Chess task: ❌ Failed → ✅ Succeeds
- Agent messages: 0 → 10-20 per task
- Success rate: 30% → 80%

---

## 🔍 ROOT CAUSE ANALYSIS

### Evidence Chain

#### 1. SmartAgentSlack EXISTS and Works
**File:** `Synapse/core/axon.py` lines 123-780  
**Methods:**
```python
def send(from_agent, to_agent, data, field_name) → bool
def receive(agent_name) → List[Message]
def register_agent(agent_name, signature, callback, max_context)
```
**Status:** ✅ PERFECT - Communication system is complete

---

#### 2. Agents ARE Registered
**File:** `Synapse/core/conductor.py` lines 1116-1128  
**Code:**
```python
self.agent_slack.register_agent(
    agent_name=actor_config.name,
    signature=signature_obj,
    callback=_make_slack_callback(actor_config.name),
    max_context=16000
)
```
**Status:** ✅ All 6 agents registered with SmartAgentSlack

---

#### 3. Agents DON'T Get Access
**File:** `Synapse/core/conductor.py` lines 4932-5133 `_execute_actor()`  
**Current code:**
```python
resolved_kwargs = self._resolve_parameters(...)
result = await actor(**resolved_kwargs)
```
**Problem:** ❌ `resolved_kwargs` doesn't include:
- `agent_slack`
- `agent_directory`
- `my_name`

---

#### 4. Agents Can't Communicate
**File:** `surface/agents/domain_expert.py` method `forward()`  
**Current signature:**
```python
def forward(self, instruction, terminal_session, conversation_history, ...):
    # Has: self.tools (web_search, scrape_website, terminal)
    # Missing: self.agent_slack (can't send messages)
    # Missing: self.agent_directory (don't know peers)
    return result
```
**Problem:** ❌ No communication capability

---

#### 5. Signatures Don't Include Collaboration
**File:** `surface/signatures/domain_expert_signature.py`  
**Current outputs:**
```python
analysis = dspy.OutputField(...)
plan = dspy.OutputField(...)
commands = dspy.OutputField(...)
task_complete = dspy.OutputField(...)
reasoning = dspy.OutputField(...)
```
**Missing:**
```python
collaboration_actions = dspy.OutputField(...)  # ❌ Not present
```

---

### Why This Breaks Everything

```
┌─────────────────────────────────────────────────────────┐
│                    CONDUCTOR                             │
│                                                          │
│  SmartAgentSlack EXISTS but sits unused                 │
│  ┌─────────────┐                                        │
│  │ agent_slack │ ← Nobody has access!                   │
│  │  .send()    │                                        │
│  │  .receive() │                                        │
│  └─────────────┘                                        │
│                                                          │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐          │
│  │CodeMaster │  │DomainExpert│  │ SysOps   │          │
│  │ Isolated  │  │ Isolated  │  │ Isolated  │          │
│  │ Can't msg │  │ Can't msg │  │ Can't msg │          │
│  └───────────┘  └───────────┘  └───────────┘          │
│        ▲              ▲              ▲                   │
│        │              │              │                   │
│        └──────────────┴──────────────┘                   │
│             Conductor calls each in isolation           │
└─────────────────────────────────────────────────────────┘
```

---

## 🚨 WHY LATEST LOG FAILED

### Analysis of `/Users/sohamacharya/Downloads/d.txt` (2026-01-28__16-09-30)

#### ✅ What DID Work

**1. DynamicTaskPlanner Called web_search (5 times!)**
```
Line 691: web_search("chess board recognition from image python algorithms libraries")
Line 693: web_search("python-chess library best move analysis stockfish integration")
Line 695: web_search("chess board image recognition edge cases common problems opencv python")
Line 697: web_search("python-chess library edge cases common pitfalls FEN notation move generation")
Line 699: web_search("stockfish python get multiple best moves top moves multipv python-chess")
```
**Result:** Found python-chess, opencv, stockfish, edge cases

**2. Tasks Well-Decomposed**
```
Line 708: setup_chess_environment (CodeMaster)
Line 713: recognize_board_and_generate_fen (DomainExpert)
Line 715: analyze_position_find_best_moves (DomainExpert)
Line 717: write_output_file (CodeMaster)
```

**3. SmartAgentSlack Initialized**
```
Line 91: SmartAgentSlack initialized
Line 218: CodeMaster registered
Line 261: DataMind registered
... all 6 agents registered
```

---

#### ❌ What BROKE (3 Critical Breaks)

**Break #1: Research Findings Lost**
```
Line 746: ⚠️ get_context_for_actor returned empty dict | actor=CodeMaster
Line 748: web_search_context | found=False
```
**Problem:** DynamicTaskPlanner researched libraries but CodeMaster got NOTHING!

---

**Break #2: Agents Can't Communicate**
```
Line 786: [FILTER] Filtered out 2 params not in signature: {'rlm_chunk_ids', '_agent_directory'}
```
**Problem:** `_agent_directory` filtered out because signature doesn't expect it!

This is the EXACT issue: Conductor tries to pass collaboration context but agent signatures reject it.

---

**Break #3: Task Failed**
```
Line 1340: RUN_TERMINAL_TASK COMPLETE | success=False | run_duration=1493.000s
Line 1341: ERROR | Error parsing results for task chess-best-move: No short test summary info found
```
**Result:** 25 minutes wasted, task failed

---

#### Why It Failed (Trace)

```
1. DynamicTaskPlanner (16:10:30-16:12:52):
   → Researched 5 times via web_search
   → Found: python-chess, opencv, stockfish, edge cases
   → Stored: NOWHERE (no mechanism to save)

2. CodeMaster called (16:14:12):
   → Received instruction: "Install all required dependencies"
   → Context: EMPTY (line 746)
   → Had to guess which libraries to install
   → Installed python-chess, stockfish, opencv (correct, but by luck)

3. DomainExpert called (16:31:36):
   → Received instruction: "Load chess_board.png, recognize board"
   → No library research from planner
   → No edge case warnings from planner
   → Tried to implement blind
   → Failed

4. System gave up (16:35:07):
   → All tasks complete but validation failed
   → No mechanism to request help
   → No mechanism to share error for research
```

---

### Why No New Swarm?

**User asked:** "why no new swarm?"

**Answer:** The redesign documents exist but CODE HASN'T CHANGED!

**Documents created:**
- ✅ `COMPREHENSIVE_AGENT_SWARM_REDESIGN.md` (1407 lines) - BLUEPRINT ONLY
- ✅ `A_TEAM_ROOT_CAUSE_WHY_AGENTS_DONT_COMMUNICATE.md` (798 lines) - ANALYSIS ONLY
- ✅ `IMPLEMENTATION_ROADMAP_200_STEPS.md` (1117 lines) - PLAN ONLY

**These are DOCUMENTATION, not CODE!**

**What hasn't changed:**
- `Synapse/core/conductor.py` - Still doesn't inject `_agent_directory`
- `surface/signatures/*.py` - Still don't have `collaboration_actions` field
- `Synapse/core/agent_collaboration_mixin.py` - DOESN'T EXIST YET
- `Synapse/core/dynamic_task_planner.py` - Doesn't save research to SharedContext

**THIS DOCUMENT will fix that!**

---

## 🏗️ ARCHITECTURE: BEFORE VS AFTER

### BEFORE (Current - Broken)

```
┌─────────────────────────────────────────────────────────────┐
│                       CONDUCTOR                              │
│                                                              │
│  ┌──────────────┐                                           │
│  │ SmartAgent   │ ← Created but isolated                    │
│  │ Slack        │                                           │
│  │ • send()     │   Nobody calls these!                     │
│  │ • receive()  │                                           │
│  └──────────────┘                                           │
│                                                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │
│  │ Code    │  │ Domain  │  │ SysOps  │  │ Data    │       │
│  │ Master  │  │ Expert  │  │         │  │ Mind    │       │
│  │         │  │         │  │         │  │         │       │
│  │ Isolated│  │ Isolated│  │ Isolated│  │ Isolated│       │
│  │ No ref  │  │ No ref  │  │ No ref  │  │ No ref  │       │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘       │
│       ▲            ▲            ▲            ▲              │
│       │            │            │            │              │
│  Conductor invokes one by one (sequential, isolated)       │
└─────────────────────────────────────────────────────────────┘

FLOW:
1. Conductor → CodeMaster: "solve chess"
2. CodeMaster works alone, fails
3. Conductor → DomainExpert: "next task"
4. DomainExpert works alone, no context from CodeMaster
5. System fails
```

---

### AFTER (New - Collaborative)

```
┌─────────────────────────────────────────────────────────────┐
│                       CONDUCTOR                              │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              AGENT DIRECTORY                          │   │
│  │  {                                                    │   │
│  │    "CodeMaster": {                                    │   │
│  │      capabilities: ["python", "debugging"],           │   │
│  │      provides: ["code_implementation"],               │   │
│  │      status: "available"                              │   │
│  │    },                                                 │   │
│  │    "DomainExpert": {                                  │   │
│  │      capabilities: ["library_research"],              │   │
│  │      provides: ["library_docs", "error_solutions"]    │   │
│  │    }, ...                                             │   │
│  │  }                                                    │   │
│  └──────────────────────────────────────────────────────┘   │
│                          ▲                                   │
│                          │ reads                             │
│  ┌──────────────────────┴────────────────────────────────┐  │
│  │                SmartAgentSlack (HUB)                   │  │
│  │  • MessageBus                                         │  │
│  │  • Agents CAN call .send()                            │  │
│  │  • Agents CAN call .receive()                         │  │
│  └───┬──────────┬──────────┬──────────┬──────────┬───────┘  │
│      │          │          │          │          │           │
│  ┌───▼────┐ ┌──▼─────┐ ┌──▼────┐ ┌──▼────┐ ┌──▼────┐       │
│  │Code    │ │Domain  │ │SysOps │ │Secure │ │Data   │       │
│  │Master  │ │Expert  │ │       │ │Sentry │ │Mind   │       │
│  │        │ │        │ │       │ │       │ │       │       │
│  │Has:    │ │Has:    │ │Has:   │ │Has:   │ │Has:   │       │
│  │•slack  │ │•slack  │ │•slack │ │•slack │ │•slack │       │
│  │•dir    │ │•dir    │ │•dir   │ │•dir   │ │•dir   │       │
│  │•request│ │•request│ │•request│ │•request│ │•request│      │
│  │ _help()│ │ _help()│ │ _help()│ │ _help()│ │ _help()│      │
│  │•share  │ │•share  │ │•share │ │•share │ │•share │       │
│  └────────┘ └────────┘ └───────┘ └───────┘ └───────┘       │
│      ▲          ▲          ▲          ▲          ▲           │
│      └──────────┴──────────┴──────────┴──────────┘           │
│              Peer-to-peer communication                      │
└─────────────────────────────────────────────────────────────┘

FLOW:
1. Conductor → DomainExpert (PRE-RESEARCH): "research chess libraries"
2. DomainExpert → web_search → finds python-chess, opencv
3. DomainExpert → share_knowledge(target="all", data=library_info)
4. Conductor → CodeMaster: "solve chess"
5. CodeMaster → check_incoming_messages() → gets library info
6. CodeMaster → implements with correct libraries
7. If error → CodeMaster → request_help(target="DomainExpert")
8. DomainExpert → researches error → responds
9. Success!
```

---

## 🧩 COMPONENTS TO BUILD

### Component 1: Agent Directory Builder

**Purpose:** Create registry of all agents with capabilities

**File:** `Synapse/core/conductor.py`  
**Method to add:** `_build_agent_directory()` (after line 1130)

**Structure:**
```python
{
    "agent_name": {
        "capabilities": ["python", "debugging", "algorithms"],
        "role": "implementation" | "research" | "validation",
        "provides": ["code_implementation", "bug_fixes"],
        "accepts_requests_for": ["implement_function", "fix_bug"],
        "status": "available" | "busy",
        "confidence_domains": {"python": 0.95, "javascript": 0.70}
    }
}
```

**Building algorithm:**
```python
def _build_agent_directory(self) -> Dict[str, Dict]:
    directory = {}
    
    for name, actor_config in self.actors.items():
        # Extract capabilities from ActorConfig
        capabilities = actor_config.capabilities or []
        
        # Infer from signature
        if hasattr(actor_config.agent, 'signature'):
            sig_caps = self._infer_capabilities_from_signature(
                actor_config.agent.signature
            )
            capabilities.extend(sig_caps)
        
        # Infer from architect prompts
        if actor_config.architect_paths:
            for path in actor_config.architect_paths:
                prompt_caps = self._extract_capabilities_from_prompt(path)
                capabilities.extend(prompt_caps)
        
        directory[name] = {
            "capabilities": list(set(capabilities)),
            "role": self._infer_role(name),
            "provides": self._infer_provides(name),
            "accepts_requests_for": capabilities,
            "status": "available"
        }
    
    return directory
```

---

### Component 2: Agent Collaboration Mixin

**Purpose:** Provide communication methods to all agents

**New file:** `Synapse/core/agent_collaboration_mixin.py`

**Full implementation:**
```python
"""
Agent Collaboration Mixin - Enables agent-to-agent communication.

Provides methods for requesting help, sharing knowledge, broadcasting,
and checking messages from other agents.
"""

import logging
import time
import uuid
import json
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AgentCollaborationMixin:
    """
    Mixin to enable agent-to-agent collaboration.
    
    Agents inherit this to gain:
    - request_help() - Ask another agent for assistance
    - share_knowledge() - Share findings with another agent
    - broadcast_to_swarm() - Announce discovery to all
    - check_incoming_messages() - Check for messages
    - find_agent_for_capability() - Discover who can help
    """
    
    def set_collaboration_context(
        self,
        agent_slack: 'SmartAgentSlack',
        agent_directory: Dict[str, Dict],
        my_name: str
    ):
        """
        Inject collaboration infrastructure.
        
        Called by Conductor before agent execution.
        
        Args:
            agent_slack: Communication system (SmartAgentSlack)
            agent_directory: Registry of all agents
            my_name: This agent's name
        """
        self._agent_slack = agent_slack
        self._agent_directory = agent_directory
        self._my_name = my_name
        logger.info(f"💬 [{my_name}] Collaboration context set")
    
    def request_help(
        self,
        target_agent: str,
        request_type: str,
        problem: str,
        context: Dict[str, Any],
        priority: str = "normal"
    ) -> bool:
        """
        Request help from another agent.
        
        Args:
            target_agent: Name of agent to request help from
            request_type: Type of help ("library_research", "error_solution", etc.)
            problem: Description of the problem
            context: Additional context (code, error, data)
            priority: "critical" | "high" | "normal" | "low"
        
        Returns:
            True if request sent successfully
        
        Example:
            self.request_help(
                target_agent="DomainExpert",
                request_type="library_research",
                problem="Need best library for chess FEN extraction",
                context={"task": "chess_puzzle", "language": "python"},
                priority="high"
            )
        """
        if not self._agent_slack:
            logger.warning(f"[{self._my_name}] No agent_slack - can't request help")
            return False
        
        if target_agent not in self._agent_directory:
            logger.error(f"[{self._my_name}] Unknown agent: {target_agent}")
            return False
        
        message_data = {
            "message_type": "help_request",
            "request_type": request_type,
            "problem": problem,
            "context": context,
            "priority": priority,
            "from_agent": self._my_name,
            "timestamp": time.time(),
            "request_id": str(uuid.uuid4())[:8]
        }
        
        logger.info(f"🆘 [{self._my_name}] → {target_agent}: {request_type}")
        
        success = self._agent_slack.send(
            from_agent=self._my_name,
            to_agent=target_agent,
            data=message_data,
            field_name="help_request"
        )
        
        return success
    
    def share_knowledge(
        self,
        target_agent: str,
        knowledge_type: str,
        data: Any,
        confidence: float = 0.8
    ) -> bool:
        """
        Share knowledge with another agent.
        
        Args:
            target_agent: Agent to share with (or "all" for broadcast)
            knowledge_type: Type ("edge_case_warning", "library_info", etc.)
            data: The knowledge data
            confidence: Confidence in this knowledge (0-1)
        
        Returns:
            True if shared successfully
        
        Example:
            self.share_knowledge(
                target_agent="CodeMaster",
                knowledge_type="edge_case_warning",
                data={
                    "library": "opencv",
                    "function": "cv2.imread",
                    "warning": "Returns None instead of raising exception",
                    "solution": "Check if img is None before using"
                },
                confidence=0.95
            )
        """
        if not self._agent_slack:
            return False
        
        message_data = {
            "message_type": "knowledge_share",
            "knowledge_type": knowledge_type,
            "data": data,
            "confidence": confidence,
            "from_agent": self._my_name,
            "timestamp": time.time()
        }
        
        logger.info(f"📤 [{self._my_name}] → {target_agent}: {knowledge_type}")
        
        if target_agent == "all":
            return self.broadcast_to_swarm("knowledge_share", message_data)
        else:
            return self._agent_slack.send(
                from_agent=self._my_name,
                to_agent=target_agent,
                data=message_data,
                field_name="knowledge_share"
            )
    
    def broadcast_to_swarm(
        self,
        message_type: str,
        data: Any
    ) -> bool:
        """
        Broadcast message to all agents.
        
        Args:
            message_type: Type of message
            data: Message data
        
        Returns:
            True if broadcast successful
        """
        if not self._agent_slack or not self._agent_directory:
            return False
        
        logger.info(f"📢 [{self._my_name}] Broadcasting: {message_type}")
        
        success_count = 0
        for agent_name in self._agent_directory.keys():
            if agent_name == self._my_name:
                continue
            
            if self._agent_slack.send(
                from_agent=self._my_name,
                to_agent=agent_name,
                data=data,
                field_name="broadcast"
            ):
                success_count += 1
        
        logger.info(f"✅ [{self._my_name}] Delivered to {success_count} agents")
        return success_count > 0
    
    def check_incoming_messages(self) -> List[Dict]:
        """
        Check for messages from other agents.
        
        Returns:
            List of message dicts
        """
        if not self._agent_slack:
            return []
        
        messages = self._agent_slack.receive(self._my_name)
        
        if messages:
            logger.info(f"📬 [{self._my_name}] Received {len(messages)} messages")
        
        return [m.data for m in messages]
    
    def find_agent_for_capability(
        self,
        capability: str
    ) -> Optional[str]:
        """
        Find which agent has a specific capability.
        
        Args:
            capability: Capability to search for
        
        Returns:
            Agent name or None
        
        Example:
            expert = self.find_agent_for_capability("library_research")
            # Returns: "DomainExpert"
        """
        if not self._agent_directory:
            return None
        
        for agent_name, info in self._agent_directory.items():
            if capability in info.get("capabilities", []):
                return agent_name
            if capability in info.get("accepts_requests_for", []):
                return agent_name
        
        return None
    
    def get_agent_info(self, agent_name: str) -> Optional[Dict]:
        """Get information about an agent."""
        if not self._agent_directory:
            return None
        return self._agent_directory.get(agent_name)
    
    def list_available_agents(self) -> List[str]:
        """Get list of available agent names."""
        if not self._agent_directory:
            return []
        return [
            name for name, info in self._agent_directory.items()
            if info.get("status") == "available"
        ]
```

---

### Component 3: Enhanced Agent Signatures

**Purpose:** Enable agents to express collaboration intent in outputs

**Files to modify:** All `surface/signatures/*.py`

**Add to each signature:**
```python
collaboration_actions = dspy.OutputField(
    desc="""JSON array of collaboration actions to take with other agents.
    
    CRITICAL: If you need information or help, USE THIS! Don't work in isolation!
    
    Available agents:
    {{agent_directory_will_be_injected}}
    
    Structure:
    [
        {
            "action": "request_help" | "share_knowledge" | "broadcast",
            "target_agent": "agent_name" | "all",
            "type": "library_research" | "error_solution" | "code_review" | ...,
            "data": {
                // Action-specific data
            },
            "priority": "critical" | "high" | "normal" | "low"
        }
    ]
    
    EXAMPLES:
    
    Request help from DomainExpert:
    {
        "action": "request_help",
        "target_agent": "DomainExpert",
        "type": "library_research",
        "data": {
            "problem": "Need best Python library for chess board image processing",
            "context": {"task": "extract_fen_from_image", "format": "PNG"},
            "requirements": ["image_loading", "chess_notation"]
        },
        "priority": "high"
    }
    
    Share edge case warning with CodeMaster:
    {
        "action": "share_knowledge",
        "target_agent": "CodeMaster",
        "type": "edge_case_warning",
        "data": {
            "library": "opencv",
            "function": "cv2.imread",
            "warning": "Returns None instead of raising exception",
            "solution": "Always check: if img is None: raise FileNotFoundError()"
        }
    }
    
    Broadcast discovery to all agents:
    {
        "action": "broadcast",
        "target_agent": "all",
        "type": "task_insight",
        "data": {
            "insight": "This is a chess puzzle task requiring python-chess library",
            "confidence": 0.9
        }
    }
    """
)
```

---

### Component 4: Collaboration-Aware Execution

**Purpose:** Process collaboration actions during execution

**File:** `Synapse/core/conductor.py`  
**Method:** `_execute_actor()` lines 4932-5133

**Enhanced version:**
```python
async def _execute_actor(
    self,
    actor_config: ActorConfig,
    task: TodoItem,
    context: str,
    kwargs: Dict,
    actor_context_dict: Optional[Dict] = None
) -> Any:
    """Execute actor with collaboration support."""
    
    actor = actor_config.agent
    
    # ✅ NEW: Inject collaboration context
    if hasattr(actor, 'set_collaboration_context'):
        actor.set_collaboration_context(
            agent_slack=self.agent_slack,
            agent_directory=self.agent_directory,
            my_name=actor_config.name
        )
        logger.debug(f"💬 [{actor_config.name}] Collaboration context injected")
    
    # Resolve parameters (existing)
    resolved_kwargs = self._resolve_parameters(...)
    
    # ✅ NEW: Add agent directory to kwargs for prompt injection
    resolved_kwargs['_agent_directory_json'] = json.dumps(
        self.agent_directory,
        indent=2
    )
    
    # Execute actor
    result = await actor(**resolved_kwargs)
    
    # ✅ NEW: Process collaboration actions from result
    collaboration_actions = self._extract_collaboration_actions(result)
    
    if collaboration_actions:
        logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} collaboration actions")
        
        for action in collaboration_actions:
            await self._process_collaboration_action(
                action,
                from_actor=actor_config.name,
                context=kwargs
            )
    
    # Check for incoming messages
    if hasattr(actor, 'check_incoming_messages'):
        incoming = actor.check_incoming_messages()
        if incoming:
            logger.info(f"📬 [{actor_config.name}] Has {len(incoming)} pending messages")
    
    return result


def _extract_collaboration_actions(self, result: Any) -> List[Dict]:
    """Extract collaboration_actions from agent output."""
    actions = []
    
    if hasattr(result, 'collaboration_actions'):
        actions_str = str(result.collaboration_actions)
        
        try:
            actions = json.loads(actions_str)
            if not isinstance(actions, list):
                actions = [actions]
        except json.JSONDecodeError:
            logger.warning("Failed to parse collaboration_actions")
    
    return actions


async def _process_collaboration_action(
    self,
    action: Dict,
    from_actor: str,
    context: Dict
) -> None:
    """Process a single collaboration action."""
    action_type = action.get("action")
    target_agent = action.get("target_agent")
    
    if action_type == "request_help":
        await self._handle_help_request(action, from_actor, context)
    
    elif action_type == "share_knowledge":
        await self._handle_knowledge_share(action, from_actor)
    
    elif action_type == "broadcast":
        await self._handle_broadcast(action, from_actor)


async def _handle_help_request(
    self,
    action: Dict,
    from_actor: str,
    context: Dict
) -> None:
    """Handle help request by invoking target agent."""
    target_agent = action.get("target_agent")
    data = action.get("data", {})
    
    logger.info(f"🆘 Help request: {from_actor} → {target_agent}")
    
    if target_agent not in self.actors:
        logger.error(f"Unknown target agent: {target_agent}")
        return
    
    target_config = self.actors[target_agent]
    
    # Build instruction for target agent
    problem = data.get("problem", "")
    request_context = data.get("context", {})
    
    instruction = f"""
HELP REQUEST from {from_actor}:

Type: {data.get('type', 'general')}
Problem: {problem}
Context: {json.dumps(request_context, indent=2)}

Please provide assistance.
"""
    
    # Execute target agent
    try:
        response = await self._execute_actor(
            actor_config=target_config,
            task=TodoItem(id="help_request", description=instruction),
            context=instruction,
            kwargs=context
        )
        
        # Send response back
        self.agent_slack.send(
            from_agent=target_agent,
            to_agent=from_actor,
            data={
                "message_type": "help_response",
                "in_response_to": action.get("request_id"),
                "response": response
            }
        )
        
        logger.info(f"✅ Help provided: {target_agent} → {from_actor}")
        
    except Exception as e:
        logger.error(f"❌ Help request failed: {e}")
```

---

### Component 5: Pre-Execution Research Phase

**Purpose:** Automatically call DomainExpert to research libraries BEFORE coding

**File:** `Synapse/core/conductor.py`  
**New method:** `_run_pre_execution_research()` (before `run()` line 2000)

**Implementation:**
```python
async def _run_pre_execution_research(
    self,
    goal: str,
    plan: Any,
    kwargs: Dict
) -> None:
    """
    Automatically call DomainExpert to research needed libraries.
    
    Called BEFORE task execution to gather knowledge proactively.
    
    Args:
        goal: The main goal
        plan: Plan from DynamicTaskPlanner
        kwargs: Execution context
    """
    if "DomainExpert" not in self.actors:
        logger.info("⏭️  No DomainExpert - skipping pre-execution research")
        return
    
    logger.info("🔬 Phase: Pre-Execution Research")
    
    # Analyze goal and plan to identify research needs
    research_needs = self._identify_research_needs(goal, plan)
    
    if not research_needs:
        logger.info("  ℹ️  No research needs identified")
        return
    
    logger.info(f"  📚 Research needs: {research_needs}")
    
    # Call DomainExpert for each need
    domain_expert = self.actors["DomainExpert"]
    
    for need in research_needs:
        instruction = f"""
RESEARCH REQUEST (Pre-Execution):

Goal: {goal}
Research Needed: {need["type"]}
Context: {json.dumps(need["context"], indent=2)}

Please research and provide:
1. Recommended libraries
2. API documentation
3. Edge cases and gotchas
4. Best practices

Store findings for other agents to use.
"""
        
        try:
            await self._execute_actor(
                actor_config=domain_expert,
                task=TodoItem(id="pre_research", description=instruction),
                context=instruction,
                kwargs=kwargs
            )
            
            logger.info(f"  ✅ Research complete: {need['type']}")
            
        except Exception as e:
            logger.error(f"  ❌ Research failed: {e}")
    
    logger.info("✅ Pre-execution research phase complete")


def _identify_research_needs(
    self,
    goal: str,
    plan: Any
) -> List[Dict]:
    """
    Identify what needs to be researched based on goal and plan.
    """
    needs = []
    
    goal_lower = goal.lower()
    
    # Domain detection (keyword-based for now, could be LLM-based)
    if any(word in goal_lower for word in ["chess", "puzzle", "move", "board"]):
        needs.append({
            "type": "game_logic_libraries",
            "context": {
                "domain": "chess",
                "requirements": ["board_representation", "move_validation"]
            }
        })
    
    if any(word in goal_lower for word in ["image", "picture", "photo", "png", "jpg"]):
        needs.append({
            "type": "image_processing_libraries",
            "context": {
                "domain": "image_processing",
                "requirements": ["image_loading", "image_analysis"]
            }
        })
    
    return needs
```

---

## 📂 FILE-BY-FILE CHANGES

### 1. `Synapse/core/conductor.py`

**Location:** After line 1130 (after agent registration)

**ADD: Agent directory builder**
```python
def _build_agent_directory(self) -> Dict[str, Dict]:
    """
    Build directory of all agents with their capabilities.
    
    Returns registry with agent names → {capabilities, role, provides, etc.}
    """
    directory = {}
    
    for name, actor_config in self.actors.items():
        # Extract capabilities
        capabilities = []
        
        # From ActorConfig
        if actor_config.capabilities:
            capabilities.extend(actor_config.capabilities)
        
        # Infer from name
        if "CodeMaster" in name:
            capabilities.extend(["python_coding", "debugging", "algorithms"])
        elif "DomainExpert" in name:
            capabilities.extend(["library_research", "documentation_analysis"])
        elif "SysOps" in name:
            capabilities.extend(["system_administration", "file_management"])
        elif "DataMind" in name:
            capabilities.extend(["data_processing", "analysis"])
        
        directory[name] = {
            "capabilities": list(set(capabilities)),
            "role": self._infer_role(name),
            "provides": self._infer_provides(name),
            "accepts_requests_for": capabilities,
            "status": "available"
        }
    
    return directory


def _infer_role(self, agent_name: str) -> str:
    """Infer agent role from name."""
    if "CodeMaster" in agent_name:
        return "implementation"
    elif "DomainExpert" in agent_name:
        return "research"
    elif "SysOps" in agent_name:
        return "operations"
    elif "DataMind" in agent_name:
        return "analysis"
    elif "SecureSentry" in agent_name:
        return "security"
    elif "ScienceCore" in agent_name:
        return "scientific"
    return "general"


def _infer_provides(self, agent_name: str) -> List[str]:
    """Infer what agent provides."""
    if "CodeMaster" in agent_name:
        return ["code_implementation", "bug_fixes", "code_review"]
    elif "DomainExpert" in agent_name:
        return ["library_research", "documentation", "error_solutions"]
    elif "SysOps" in agent_name:
        return ["file_operations", "system_commands"]
    elif "DataMind" in agent_name:
        return ["data_analysis", "visualization"]
    return []
```

**Location:** In `__init__()` after line 1128

**ADD: Call agent directory builder**
```python
# After agent registration
logger.info("🏗️  Building agent directory")
self.agent_directory = self._build_agent_directory()
logger.info(f"📋 Agent directory built: {len(self.agent_directory)} agents")
```

**Location:** Modify `_execute_actor()` at line 5100

**MODIFY: Inject collaboration context**
```python
# BEFORE:
result = await actor(**resolved_kwargs)

# AFTER:
# Inject collaboration context if agent supports it
if hasattr(actor, 'set_collaboration_context'):
    actor.set_collaboration_context(
        agent_slack=self.agent_slack,
        agent_directory=self.agent_directory,
        my_name=actor_config.name
    )
    logger.debug(f"💬 [{actor_config.name}] Collaboration context injected")

# Add agent directory to kwargs for prompt injection
resolved_kwargs['_agent_directory_json'] = json.dumps(
    self.agent_directory, indent=2
)

result = await actor(**resolved_kwargs)

# Process collaboration actions
collaboration_actions = self._extract_collaboration_actions(result)
if collaboration_actions:
    logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} actions")
    for action in collaboration_actions:
        await self._process_collaboration_action(action, actor_config.name, kwargs)
```

**Estimated changes:** +400 lines

---

### 2. `Synapse/core/agent_collaboration_mixin.py`

**Status:** NEW FILE

**Location:** Create in `Synapse/core/`

**Full content:** See Component 2 above

**Estimated:** +200 lines

---

### 3. `surface/agents/base_swarm_agent.py`

**Location:** Modify class definition at line ~20

**MODIFY: Inherit from mixin**
```python
# BEFORE:
from surface.agents.base_agent import BaseAgent

class BaseSwarmAgent(BaseAgent):
    """Base class for swarm agents."""
    pass

# AFTER:
from surface.agents.base_agent import BaseAgent
from Synapse.core.agent_collaboration_mixin import AgentCollaborationMixin

class BaseSwarmAgent(BaseAgent, AgentCollaborationMixin):
    """
    Base class for swarm agents with collaboration capability.
    
    Inherits:
    - BaseAgent: Core agent functionality
    - AgentCollaborationMixin: Collaboration methods
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Collaboration context will be set by Conductor
        self._agent_slack = None
        self._agent_directory = None
        self._my_name = None
```

**Estimated:** +15 lines

---

### 4. All Agent Signature Files

**Files to modify:**
- `surface/signatures/code_master_signature.py`
- `surface/signatures/domain_expert_signature.py`
- `surface/signatures/data_mind_signature.py`
- `surface/signatures/sys_ops_signature.py`
- `surface/signatures/secure_sentry_signature.py`
- `surface/signatures/science_core_signature.py`

**ADD to each:** See Component 3 above (`collaboration_actions` field)

**Estimated:** +30 lines per file = 180 total

---

### 5. All Architect Prompt Files

**Files to modify:**
- `surface_synapse/architect/codemaster_agent.md`
- `surface_synapse/architect/domainexpert_agent.md`
- `surface_synapse/architect/datamind_agent.md`
- `surface_synapse/architect/sysops_agent.md`
- `surface_synapse/architect/secure_sentry_agent.md`
- `surface_synapse/architect/science_core_agent.md`

**ADD to each:**
```markdown
## 🤝 Available Agents for Collaboration

You are part of a multi-agent swarm. Other agents can help you!

{{agent_directory_json}}

## How to Request Help

If you need information or assistance, use the `collaboration_actions` output field:

```json
{
    "action": "request_help",
    "target_agent": "DomainExpert",
    "type": "library_research",
    "data": {
        "problem": "Need to know best library for [task]",
        "context": {"requirement": "..."},
        "priority": "high"
    }
}
```

## How to Share Knowledge

If you discovered something useful, share it:

```json
{
    "action": "share_knowledge",
    "target_agent": "CodeMaster",
    "type": "edge_case_warning",
    "data": {
        "library": "opencv",
        "warning": "cv2.imread returns None instead of exception",
        "solution": "Check if img is None before using"
    }
}
```

## When to Collaborate

**Request help when:**
- You don't know which library to use
- You encounter an unfamiliar error
- You need domain-specific knowledge
- You're stuck on implementation

**Share knowledge when:**
- You find an edge case
- You discover a library limitation
- You solve an error
- You find a better approach

**IMPORTANT:** Don't work in isolation! Use collaboration!
```

**Estimated:** +100 lines per file = 600 total

---

## 📅 IMPLEMENTATION ROADMAP (200 Steps)

### Phase 1: Core Infrastructure (Steps 1-40)

#### Week 1, Days 1-2: Agent Directory

**Steps 1-10: Create directory builder**
1. Open `Synapse/core/conductor.py`
2. Find line 1130 (after agent registration)
3. Add `_build_agent_directory()` method
4. Add `_infer_role()` helper method
5. Add `_infer_provides()` helper method
6. Test directory building with print statements
7. Verify all 6 agents appear in directory
8. Verify capabilities are populated
9. Add logging for directory creation
10. Commit: "feat: Add agent directory builder"

**Steps 11-20: Integrate directory into Conductor**
11. Find `__init__()` in Conductor (line ~1000)
12. After agent registration, add `self.agent_directory = self._build_agent_directory()`
13. Add logging: "Agent directory built: X agents"
14. Verify directory is built on Conductor initialization
15. Add test to print directory contents
16. Verify directory updates when agents are added
17. Add error handling for missing agents
18. Add validation for directory structure
19. Test with missing agents (should handle gracefully)
20. Commit: "feat: Build agent directory on initialization"

**Steps 21-30: Test directory building**
21. Create test script `test_agent_directory.py`
22. Initialize Conductor
23. Print agent_directory
24. Verify CodeMaster has "python_coding" capability
25. Verify DomainExpert has "library_research" capability
26. Verify all agents have "status": "available"
27. Test directory is accessible from Conductor
28. Test directory is JSON-serializable
29. Test edge case: empty actors dict
30. Commit: "test: Agent directory validation"

**Steps 31-40: Create collaboration mixin**
31. Create file `Synapse/core/agent_collaboration_mixin.py`
32. Add imports (logging, time, uuid, json, typing)
33. Create `AgentCollaborationMixin` class
34. Add `set_collaboration_context()` method
35. Add `request_help()` method
36. Add `share_knowledge()` method
37. Add `broadcast_to_swarm()` method
38. Add `check_incoming_messages()` method
39. Add `find_agent_for_capability()` helper method
40. Commit: "feat: Add AgentCollaborationMixin"

---

### Phase 2: Agent Enhancement (Steps 41-100)

#### Week 1, Days 3-4: Update base agent

**Steps 41-50: Modify base_swarm_agent.py**
41. Open `surface/agents/base_swarm_agent.py`
42. Import `AgentCollaborationMixin`
43. Modify class to inherit from mixin
44. Add `__init__()` if not present
45. Initialize collaboration attributes to None
46. Test import doesn't break existing agents
47. Verify all agents still initialize
48. Add docstring explaining mixin
49. Test agent creation with mixin
50. Commit: "feat: Add collaboration capability to base agent"

**Steps 51-60: Update agent signatures**
51. Open `surface/signatures/code_master_signature.py`
52. Add `collaboration_actions` output field (full desc)
53. Test signature still loads
54. Open `surface/signatures/domain_expert_signature.py`
55. Add `collaboration_actions` output field
56. Open `surface/signatures/data_mind_signature.py`
57. Add `collaboration_actions` output field
58. Open remaining 3 signature files
59. Add `collaboration_actions` to each
60. Commit: "feat: Add collaboration_actions to all signatures"

**Steps 61-70: Test signatures**
61. Create test script `test_signatures.py`
62. Import each signature
63. Create sample output with collaboration_actions
64. Verify DSPy accepts the field
65. Test with empty collaboration_actions (should work)
66. Test with invalid JSON (should handle gracefully)
67. Test with valid help request action
68. Test with valid share knowledge action
69. Verify all 6 signatures load correctly
70. Commit: "test: Validate enhanced signatures"

**Steps 71-80: Update architect prompts**
71. Open `surface_synapse/architect/codemaster_agent.md`
72. Add "Available Agents for Collaboration" section
73. Add "How to Request Help" section with example
74. Add "How to Share Knowledge" section with example
75. Add "When to Collaborate" guidelines
76. Open `surface_synapse/architect/domainexpert_agent.md`
77. Add same collaboration sections
78. Open remaining 4 architect prompts
79. Add collaboration sections to each
80. Commit: "feat: Add collaboration guidance to architect prompts"

**Steps 81-90: Inject collaboration context**
81. Open `Synapse/core/conductor.py`
82. Find `_execute_actor()` method (line ~5100)
83. After resolving parameters, add collaboration injection
84. Add `if hasattr(actor, 'set_collaboration_context'):`
85. Call `actor.set_collaboration_context()`
86. Pass `self.agent_slack`, `self.agent_directory`, `actor_config.name`
87. Add logging for injection
88. Test injection doesn't break existing agents
89. Verify collaboration context is set
90. Commit: "feat: Inject collaboration context into agents"

**Steps 91-100: Add agent directory to prompts**
91. In `_execute_actor()`, add `resolved_kwargs['_agent_directory_json']`
92. Serialize `self.agent_directory` to JSON
93. Test JSON serialization works
94. Verify agent directory appears in agent context
95. Test with large directory (100+ agents - future-proof)
96. Handle case where directory is None
97. Handle JSON serialization errors
98. Add logging for directory injection
99. Test end-to-end: agent receives directory
100. Commit: "feat: Inject agent directory into prompt context"

---

### Phase 3: Collaboration Processing (Steps 101-160)

#### Week 2, Days 1-2: Extract collaboration actions

**Steps 101-110: Add extraction method**
101. In `Synapse/core/conductor.py`, after `_execute_actor()` call
102. Add `_extract_collaboration_actions()` method
103. Check if result has `collaboration_actions` attribute
104. Parse JSON string to list
105. Handle empty actions
106. Handle invalid JSON gracefully
107. Handle non-list JSON (convert to list)
108. Add logging for extracted actions
109. Test with sample result
110. Commit: "feat: Extract collaboration_actions from agent output"

**Steps 111-120: Process actions**
111. Add `_process_collaboration_action()` method
112. Route based on action type
113. Add `_handle_help_request()` method stub
114. Add `_handle_knowledge_share()` method stub
115. Add `_handle_broadcast()` method stub
116. Call process method after extraction
117. Log each action being processed
118. Test routing works correctly
119. Handle unknown action types
120. Commit: "feat: Process collaboration actions routing"

**Steps 121-130: Implement help request handling**
121. Implement `_handle_help_request()` fully
122. Extract target_agent from action
123. Verify target agent exists
124. Build instruction for target agent
125. Call `_execute_actor()` with target agent
126. Get response from target agent
127. Send response back via `agent_slack.send()`
128. Add logging for help request flow
129. Handle errors in target agent execution
130. Commit: "feat: Handle help requests between agents"

**Steps 131-140: Test help request flow**
131. Create test script `test_help_request.py`
132. Mock Conductor with 2 agents
133. Agent A requests help from Agent B
134. Verify Agent B is invoked
135. Verify response is sent back
136. Verify Agent A can receive response
137. Test with invalid target agent
138. Test with error in target execution
139. Test with multiple sequential help requests
140. Commit: "test: Validate help request flow"

**Steps 141-150: Implement knowledge share**
141. Implement `_handle_knowledge_share()` fully
142. Extract knowledge data from action
143. Store in `HierarchicalMemory` as SEMANTIC
144. Send confirmation to originating agent
145. Log knowledge share
146. Handle "all" target (broadcast)
147. Test knowledge storage
148. Test knowledge retrieval
149. Test broadcast to all agents
150. Commit: "feat: Handle knowledge sharing"

**Steps 151-160: Pre-execution research**
151. Add `_run_pre_execution_research()` method
152. Add `_identify_research_needs()` helper
153. Detect domains from goal (chess, image, web, etc.)
154. Call DomainExpert with research request
155. Store research in HierarchicalMemory
156. Call research before task execution in `run()`
157. Add config flag `enable_pre_execution_research`
158. Test research phase with chess task
159. Verify research is accessible to agents
160. Commit: "feat: Add pre-execution research phase"

---

### Phase 4: Testing & Validation (Steps 161-200)

#### Week 2-3: Comprehensive testing

**Steps 161-170: Unit tests**
161. Create `tests/test_agent_directory.py`
162. Test directory building with various agents
163. Test capability inference
164. Test role inference
165. Create `tests/test_collaboration_mixin.py`
166. Test `request_help()` method
167. Test `share_knowledge()` method
168. Test `broadcast_to_swarm()` method
169. Test `check_incoming_messages()` method
170. Commit: "test: Unit tests for collaboration"

**Steps 171-180: Integration tests**
171. Create `tests/test_agent_collaboration_integration.py`
172. Test Agent A → request_help → Agent B flow
173. Test knowledge share → storage → retrieval
174. Test broadcast → all agents receive
175. Test collaboration context injection
176. Test directory injection into prompts
177. Test action extraction from results
178. Test action processing
179. Test error handling in collaboration
180. Commit: "test: Integration tests for collaboration"

**Steps 181-190: Chess task test**
181. Run chess task with collaboration enabled
182. Verify DomainExpert researches libraries pre-execution
183. Verify CodeMaster receives research
184. Verify agents can request help during execution
185. Verify collaboration_actions appear in outputs
186. Check logs for collaboration messages
187. Verify task succeeds
188. Measure collaboration metrics (messages, requests)
189. Compare with previous run (without collaboration)
190. Commit: "test: Chess task with collaboration"

**Steps 191-200: Final validation**
191. Test with image processing task
192. Test with web scraping task
193. Test with file manipulation task
194. Verify system works for ANY task (generic)
195. Measure success rate improvement
196. Verify no breaking changes to existing functionality
197. Run all existing tests (should pass)
198. Create performance benchmarks
199. Document all changes in CHANGELOG.md
200. Commit: "release: Agent collaboration v1.0"

---

## 💻 CODE EXAMPLES

### Example 1: Agent Requesting Help

**Scenario:** CodeMaster needs library research from DomainExpert

**CodeMaster output:**
```python
{
    "analysis": "Task requires chess board image processing",
    "plan": "Need to research best libraries before implementation",
    "commands": [],
    "task_complete": False,
    "reasoning": "Don't know which library is best - requesting expert help",
    "collaboration_actions": [
        {
            "action": "request_help",
            "target_agent": "DomainExpert",
            "type": "library_research",
            "data": {
                "problem": "Need best Python library for chess board image recognition and FEN extraction",
                "context": {
                    "task": "extract_chess_position_from_image",
                    "input_format": "PNG image",
                    "output_format": "FEN notation",
                    "requirements": [
                        "image_loading",
                        "chess_piece_recognition",
                        "FEN_conversion"
                    ]
                },
                "priority": "high"
            }
        }
    ]
}
```

**What happens:**
1. Conductor extracts `collaboration_actions`
2. Calls `_process_collaboration_action()`
3. Routes to `_handle_help_request()`
4. Invokes DomainExpert with research request
5. DomainExpert researches, finds `python-chess` + `opencv`
6. Response sent back to CodeMaster
7. CodeMaster continues with library info

---

### Example 2: Agent Sharing Knowledge

**Scenario:** DomainExpert discovers edge case, shares with CodeMaster

**DomainExpert output:**
```python
{
    "analysis": "Researched opencv library for chess task",
    "plan": "Found critical edge case that CodeMaster should know",
    "commands": [],
    "task_complete": True,
    "reasoning": "cv2.imread has dangerous edge case - sharing with CodeMaster",
    "collaboration_actions": [
        {
            "action": "share_knowledge",
            "target_agent": "CodeMaster",
            "type": "edge_case_warning",
            "data": {
                "library": "opencv",
                "function": "cv2.imread",
                "edge_case": "Returns None instead of raising exception when file not found",
                "severity": "critical",
                "solution": "Always check: if img is None: raise FileNotFoundError(path)",
                "example_code": "img = cv2.imread('chess.png')\nif img is None:\n    raise FileNotFoundError('Image not found')"
            }
        }
    ]
}
```

**What happens:**
1. Conductor processes `share_knowledge` action
2. Stores knowledge in `HierarchicalMemory` as SEMANTIC
3. Sends to CodeMaster via `agent_slack.send()`
4. CodeMaster receives and can now avoid the bug

---

### Example 3: Pre-Execution Research

**Scenario:** Chess task starts, DomainExpert researches BEFORE CodeMaster

**Flow:**
```python
# In Conductor.run()
async def run(goal: str, **kwargs) -> SwarmResult:
    # 1. Plan
    plan = await self.task_planner.decompose_goal(goal, ...)
    
    # 2. ✅ NEW: Pre-execution research
    await self._run_pre_execution_research(goal, plan, kwargs)
    
    # 3. Execute with knowledge already available
    result = await self._execute_tasks(plan.tasks, **kwargs)
    
    return result


async def _run_pre_execution_research(goal, plan, kwargs):
    if "DomainExpert" not in self.actors:
        return
    
    logger.info("🔬 Phase: Pre-Execution Research")
    
    # Identify research needs
    research_needs = self._identify_research_needs(goal, plan)
    # Example: [{"type": "chess_libraries", "context": {...}}]
    
    # Call DomainExpert for each
    for need in research_needs:
        instruction = f"Research {need['type']} for goal: {goal}"
        await self._execute_actor(
            actor_config=self.actors["DomainExpert"],
            task=TodoItem(id="pre_research", description=instruction),
            context=instruction,
            kwargs=kwargs
        )
    
    logger.info("✅ Pre-execution research complete")
```

**Result:**
- DomainExpert researches python-chess, opencv, stockfish
- Stores in HierarchicalMemory
- CodeMaster queries memory when executing
- CodeMaster has library info WITHOUT requesting

---

## 🧪 TESTING STRATEGY

### Unit Tests

**File:** `tests/test_agent_directory.py`
```python
def test_agent_directory_building():
    """Test agent directory is built correctly."""
    conductor = create_test_conductor()
    directory = conductor._build_agent_directory()
    
    assert "CodeMaster" in directory
    assert "DomainExpert" in directory
    assert len(directory["CodeMaster"]["capabilities"]) > 0
    assert directory["CodeMaster"]["status"] == "available"


def test_capability_inference():
    """Test capabilities are inferred correctly."""
    conductor = create_test_conductor()
    directory = conductor.agent_directory
    
    assert "python_coding" in directory["CodeMaster"]["capabilities"]
    assert "library_research" in directory["DomainExpert"]["capabilities"]
```

---

**File:** `tests/test_collaboration_mixin.py`
```python
def test_request_help():
    """Test request_help sends message correctly."""
    agent = MockAgent()
    mock_slack = MockSmartAgentSlack()
    mock_directory = {"DomainExpert": {"capabilities": ["research"]}}
    
    agent.set_collaboration_context(mock_slack, mock_directory, "CodeMaster")
    
    success = agent.request_help(
        target_agent="DomainExpert",
        request_type="library_research",
        problem="Need chess library",
        context={}
    )
    
    assert success
    assert mock_slack.last_send_to == "DomainExpert"
    assert mock_slack.last_send_from == "CodeMaster"
```

---

### Integration Tests

**File:** `tests/test_collaboration_flow.py`
```python
async def test_help_request_flow():
    """Test complete help request flow."""
    conductor = create_test_conductor()
    
    # Setup: CodeMaster needs help
    code_master = conductor.actors["CodeMaster"]
    domain_expert = conductor.actors["DomainExpert"]
    
    # Execute CodeMaster (will request help)
    result = await conductor._execute_actor(
        actor_config=code_master,
        task=TodoItem(id="test", description="Solve chess"),
        context="",
        kwargs={}
    )
    
    # Verify help request was sent
    messages = domain_expert.check_incoming_messages()
    assert len(messages) > 0
    assert messages[0]["message_type"] == "help_request"
    
    # Verify DomainExpert was invoked
    # (check logs or mock)
```

---

### End-to-End Test

**File:** `tests/test_chess_with_collaboration.py`
```python
async def test_chess_task_with_collaboration():
    """Test chess task succeeds with collaboration."""
    conductor = create_production_conductor()
    
    # Run chess task
    result = await conductor.run(
        goal="Solve chess puzzle in chess_board.png, write move to move.txt"
    )
    
    # Verify success
    assert result.success == True
    
    # Verify collaboration happened
    stats = conductor.agent_slack.get_cooperation_stats()
    assert stats["total_events"] > 0
    assert "DomainExpert" in stats.get("help_given", {})
    
    # Verify correct output
    with open("move.txt") as f:
        move = f.read().strip()
    assert len(move) >= 4  # e.g., "e2e4"
    
    # Verify pre-execution research happened
    memories = conductor.shared_memory.query("chess library", level=MemoryLevel.SEMANTIC)
    assert len(memories) > 0
```

---

## 📊 SUCCESS METRICS

### Before Implementation

| Metric | Value |
|--------|-------|
| Chess task success | ❌ 0% |
| Agent-to-agent messages | 0 per task |
| Help requests per task | 0 |
| Knowledge shares per task | 0 |
| Pre-execution research | Never |
| Error recovery via collaboration | 0% |
| DynamicTaskPlanner uses web_search | ✅ Yes (but findings lost) |
| Agents receive research findings | ❌ No |
| Complex task success rate | ~30% |

---

### After Implementation (Expected)

| Metric | Target |
|--------|--------|
| Chess task success | ✅ 100% |
| Agent-to-agent messages | 10-20 per task |
| Help requests per task | 3-5 |
| Knowledge shares per task | 5-10 |
| Pre-execution research | ✅ Always |
| Error recovery via collaboration | >80% |
| DynamicTaskPlanner uses web_search | ✅ Yes |
| Agents receive research findings | ✅ Yes (via HierarchicalMemory) |
| Complex task success rate | ~80% |

---

### Key Performance Indicators

**1. Collaboration Rate**
```python
collaboration_rate = (tasks_with_messages / total_tasks) * 100
# Target: >90%
```

**2. Help Request Success Rate**
```python
help_success_rate = (successful_help_requests / total_help_requests) * 100
# Target: >85%
```

**3. Research Impact**
```python
research_impact = (success_with_research - success_without_research) * 100
# Target: >40% improvement
```

**4. Knowledge Reuse**
```python
reuse_rate = (knowledge_items_retrieved / knowledge_items_stored) * 100
# Target: >70%
```

**5. Error Recovery via Collaboration**
```python
collab_recovery = (errors_solved_via_collab / total_errors) * 100
# Target: >80%
```

---

## ✅ FINAL CHECKLIST

### Phase 1: Infrastructure
- [ ] Agent directory builder implemented
- [ ] AgentCollaborationMixin created
- [ ] Collaboration context injection works
- [ ] Unit tests passing
- [ ] No breaking changes

### Phase 2: Agent Enhancement
- [ ] All agents inherit mixin
- [ ] All signatures have `collaboration_actions`
- [ ] All prompts have collaboration guidance
- [ ] Agents receive agent directory
- [ ] Integration tests passing

### Phase 3: Execution Enhancement
- [ ] Collaboration actions extracted from outputs
- [ ] Help requests invoke target agents
- [ ] Knowledge sharing stores in memory
- [ ] Pre-execution research works
- [ ] End-to-end tests passing

### Phase 4: Validation
- [ ] Chess task succeeds with collaboration
- [ ] Agent-to-agent messages logged
- [ ] Collaboration metrics tracked
- [ ] Success rate improved to >75%
- [ ] System is GENERIC (works for any task)
- [ ] No hardcoded chess logic
- [ ] Documentation complete

---

## 🚀 GETTING STARTED

### Day 1 Morning: Setup
1. Read this entire document (2 hours)
2. Understand root cause (agents can't access SmartAgentSlack)
3. Review architecture diagrams
4. Plan your implementation schedule

### Day 1 Afternoon: First Code
1. Create `Synapse/core/agent_collaboration_mixin.py`
2. Implement basic methods (request_help, share_knowledge)
3. Test mixin imports correctly
4. Commit: "feat: Add AgentCollaborationMixin skeleton"

### Day 2: Agent Directory
1. Add `_build_agent_directory()` to Conductor
2. Call it in `__init__()`
3. Print directory and verify structure
4. Commit: "feat: Build agent directory"

### Day 3: Injection
1. Modify `_execute_actor()` to inject collaboration context
2. Test agents receive context
3. Verify no breaking changes
4. Commit: "feat: Inject collaboration context"

### Week 1 End: Foundation Complete
- Agent directory works
- Collaboration mixin exists
- Context injection works
- Ready for Phase 2

---

## 📞 SUPPORT & QUESTIONS

### Q: What if I get stuck?
**A:** Check the specific file/line references in this document. Every change is documented with exact locations.

### Q: How do I know if it's working?
**A:** Add logging at each step. You should see:
- "Agent directory built: 6 agents"
- "Collaboration context injected"
- "Processing N collaboration actions"

### Q: What if tests fail?
**A:** Check logs for errors. Most common issues:
- Import errors (check paths)
- Signature mismatches (check DSPy fields)
- None values (check context injection)

### Q: How long will this take?
**A:** 
- Experienced: 2 weeks
- Learning: 3 weeks
- Part-time: 4-5 weeks

---

## 🎯 EXPECTED OUTCOME

After implementing this guide:

1. **Agents communicate:** 10-20 messages per task
2. **DomainExpert researches:** Before CodeMaster executes
3. **CodeMaster succeeds:** Has library info from research
4. **Errors get researched:** Automatic recovery
5. **Chess task passes:** 100% success rate
6. **System is generic:** Works for ANY task type

**Most importantly:** Agents are no longer isolated. They work as a TEAM.

---

**Status:** Ready for implementation  
**Version:** 1.0 FINAL  
**Last Updated:** 2026-01-28  
**Next Action:** Begin Phase 1, Step 1

---

*This is the ONLY document you need. Everything is here.*
