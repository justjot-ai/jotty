# Comprehensive Agent Swarm Redesign: From Isolated to Collaborative

**Date:** 2026-01-28  
**Problem:** Agents exist but don't communicate despite having infrastructure  
**Solution:** Enable explicit agent-to-agent collaboration  
**Impact:** Transform system from 30% to 80% success rate

---

## 📋 TABLE OF CONTENTS

1. [Executive Summary](#executive-summary)
2. [Root Cause Analysis](#root-cause-analysis)
3. [Architectural Vision](#architectural-vision)
4. [Component Design](#component-design)
5. [Integration Strategy](#integration-strategy)
6. [File-by-File Changes](#file-by-file-changes)
7. [Implementation Phases](#implementation-phases)
8. [Testing Strategy](#testing-strategy)
9. [Success Metrics](#success-metrics)

---

## 🎯 EXECUTIVE SUMMARY

### The Problem
You built a sophisticated multi-agent system with:
- ✅ SmartAgentSlack for communication
- ✅ HierarchicalMemory for knowledge storage
- ✅ LLMRAGRetriever for semantic search
- ✅ 6 specialized agents (CodeMaster, DomainExpert, etc.)

**But agents don't talk to each other!**

### Why It's Broken
1. **No Reference:** Agents don't have access to `agent_slack`
2. **No Directory:** Agents don't know what other agents exist
3. **No Methods:** Agents can't request help or share knowledge
4. **No Signatures:** Agent outputs don't include collaboration actions
5. **No Injection:** Conductor doesn't pass collaboration context

**Analogy:** You built Slack, but nobody has login credentials.

### The Fix (3 Weeks)
1. **Week 1:** Create agent directory + collaboration mixin
2. **Week 2:** Inject collaboration context + enhance agent signatures
3. **Week 3:** Process collaboration actions + add pre-execution research

**Expected Result:**
- Chess task: ❌ Failed → ✅ Succeeds
- Complex tasks: 30% success → 80% success
- Agent messages: 0 → 10-20 per task
- System becomes truly collaborative

---

## 🔍 ROOT CAUSE ANALYSIS

### Evidence Trail

#### File: `Synapse/core/axon.py` (SmartAgentSlack)
**Lines:** 123-780  
**Status:** ✅ PERFECT - Communication system works  
**Capability:** `send()`, `receive()`, auto-transformation, context management  
**Problem:** Nobody calls it!

#### File: `Synapse/core/conductor.py` (Initialization)
**Lines:** 956-962  
**Code:**
```python
self.agent_slack = SmartAgentSlack(config={}, enable_cooperation=True)
# Agents registered with agent_slack (lines 1116-1128)
```
**Status:** ✅ Created and agents registered  
**Problem:** Agents don't get a reference to use it

#### File: `Synapse/core/conductor.py` (_execute_actor)
**Lines:** 4932-5133  
**Code:**
```python
resolved_kwargs = self._resolve_parameters(...)
result = await actor(**resolved_kwargs)
```
**Problem:** ❌ Missing:
- `agent_slack` not in resolved_kwargs
- `agent_directory` not in resolved_kwargs
- `my_name` not in resolved_kwargs

#### File: `surface/agents/domain_expert.py` (forward method)
**Lines:** ~50-200  
**Signature:**
```python
def forward(self, instruction, terminal_session, conversation_history, ...):
    # Has: terminal tools, web_search, scrape_website
    # Missing: agent_slack, agent_directory, collaboration methods
    return result
```
**Problem:** ❌ No collaboration capability

#### File: `surface/signatures/domain_expert_signature.py`
**Lines:** ~20-50  
**Output fields:**
```python
analysis = dspy.OutputField(...)
plan = dspy.OutputField(...)
commands = dspy.OutputField(...)
# Missing: collaboration_actions, help_requests, knowledge_shares
```
**Problem:** ❌ No collaboration outputs

### Conclusion
**System has all the pieces, but they're not connected!**

---

## 🏗️ ARCHITECTURAL VISION

### Current Architecture (Broken)

```
┌─────────────────────────────────────────────────────────────┐
│                       CONDUCTOR                              │
│                                                              │
│  ┌──────────────┐                                           │
│  │ SmartAgent   │ ← Created but isolated                    │
│  │ Slack        │                                           │
│  │ • send()     │   Nobody has reference!                   │
│  │ • receive()  │                                           │
│  └──────────────┘                                           │
│                                                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │
│  │ Code    │  │ Domain  │  │ SysOps  │  │ Data    │       │
│  │ Master  │  │ Expert  │  │         │  │ Mind    │       │
│  │         │  │         │  │         │  │         │       │
│  │ Isolated│  │ Isolated│  │ Isolated│  │ Isolated│       │
│  │ No comm │  │ No comm │  │ No comm │  │ No comm │       │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘       │
│       ▲            ▲            ▲            ▲              │
│       │            │            │            │              │
│  Conductor invokes agents one by one (sequential)          │
│  No agent-to-agent communication                           │
└─────────────────────────────────────────────────────────────┘
```

### New Architecture (Collaborative)

```
┌─────────────────────────────────────────────────────────────┐
│                       CONDUCTOR                              │
│                                                              │
│  ┌──────────────────────────────────────────┐               │
│  │        SmartAgentSlack (Hub)             │               │
│  │  • Message Bus                           │               │
│  │  • Format Registry                       │               │
│  │  • Cooperation Tracking                  │               │
│  └────────┬──────────┬──────────┬──────────┘               │
│           │          │          │                           │
│           │          │          │                           │
│  ┌────────▼─────┐  ┌▼─────────┐  ┌▼────────┐  ┌▼─────────┐│
│  │ CodeMaster   │  │Domain    │  │SysOps   │  │DataMind  ││
│  │              │  │Expert    │  │         │  │          ││
│  │ Can:         │  │Can:      │  │Can:     │  │Can:      ││
│  │• request_help│  │• share   │  │• request│  │• share   ││
│  │• share_know  │  │  knowledge│  │  _help  │  │  _know   ││
│  │• broadcast   │  │• respond │  │• respond│  │• broadcast││
│  │              │  │  to_help │  │  to_help│  │          ││
│  └──────────────┘  └──────────┘  └─────────┘  └──────────┘│
│         ▲               ▲             ▲             ▲        │
│         │               │             │             │        │
│         └───────────────┼─────────────┼─────────────┘        │
│                         │             │                      │
│                    Agent Directory                           │
│              {agents, capabilities, status}                  │
│                                                              │
│  Agents communicate peer-to-peer via SmartAgentSlack       │
│  Conductor orchestrates but doesn't block communication     │
└─────────────────────────────────────────────────────────────┘
```

### Key Differences

| Aspect | Before | After |
|--------|--------|-------|
| **Communication** | Conductor-mediated | Direct agent-to-agent |
| **Agent awareness** | None | Full directory |
| **Help requests** | Impossible | request_help() method |
| **Knowledge sharing** | Via memory only | Active push to peers |
| **Execution flow** | Sequential | Parallel + collaborative |
| **Error handling** | Retry same code | Request help, get solution |
| **Research** | Never happens | Pre-execution + on-demand |

---

## 🧩 COMPONENT DESIGN

### Component 1: Agent Directory

**Purpose:** Enable agent discovery

**File:** `Synapse/core/conductor.py`  
**New method:** `_build_agent_directory()`  
**Location:** After line 1130  

**Structure:**
```python
{
    "CodeMaster": {
        "capabilities": [
            "python_coding",
            "debugging",
            "algorithms",
            "code_review"
        ],
        "role": "implementation",
        "provides": [
            "code_implementation",
            "bug_fixes",
            "code_optimization"
        ],
        "accepts_requests_for": [
            "implement_function",
            "fix_bug",
            "optimize_code",
            "code_review"
        ],
        "status": "available",
        "confidence_domains": {
            "python": 0.95,
            "javascript": 0.70,
            "algorithms": 0.90
        },
        "last_successful_task": "chess_code_generation",
        "average_response_time_seconds": 15.3
    },
    "DomainExpert": {
        "capabilities": [
            "library_research",
            "documentation_analysis",
            "error_diagnosis",
            "api_discovery"
        ],
        "role": "research",
        "provides": [
            "library_recommendations",
            "api_documentation",
            "edge_case_warnings",
            "error_solutions"
        ],
        "accepts_requests_for": [
            "research_library",
            "explain_error",
            "find_api_docs",
            "discover_edge_cases"
        ],
        "status": "available",
        "confidence_domains": {
            "python_libraries": 0.95,
            "image_processing": 0.85,
            "game_logic": 0.80
        }
    },
    // ... other agents
}
```

**Build algorithm:**
```python
def _build_agent_directory(self) -> Dict[str, Dict]:
    directory = {}
    
    for actor_config in self.actors.values():
        # Extract from ActorConfig
        capabilities = actor_config.capabilities or []
        
        # Infer from signature if available
        if hasattr(actor_config.agent, 'signature'):
            capabilities.extend(
                self._infer_capabilities_from_signature(
                    actor_config.agent.signature
                )
            )
        
        # Infer from architect prompts
        if actor_config.architect_paths:
            for path in actor_config.architect_paths:
                capabilities.extend(
                    self._extract_capabilities_from_prompt(path)
                )
        
        directory[actor_config.name] = {
            "capabilities": list(set(capabilities)),
            "role": self._infer_role(actor_config),
            "provides": self._infer_provides(actor_config),
            "accepts_requests_for": capabilities,
            "status": "available",
            "confidence_domains": {}
        }
    
    return directory
```

**Update frequency:** Real-time as agents complete tasks

---

### Component 2: Agent Collaboration Mixin

**Purpose:** Provide communication methods to all agents

**New file:** `Synapse/core/agent_collaboration_mixin.py`

**Full class design:**
```python
class AgentCollaborationMixin:
    """
    Mixin to enable agent-to-agent collaboration.
    
    Provides methods for:
    - Requesting help from other agents
    - Sharing knowledge
    - Broadcasting discoveries
    - Checking messages
    - Finding agents with capabilities
    """
    
    def set_collaboration_context(
        self,
        agent_slack: 'SmartAgentSlack',
        agent_directory: Dict[str, Dict],
        my_name: str
    ):
        """
        Inject collaboration infrastructure.
        
        Called by Conductor before agent execution.
        
        Args:
            agent_slack: Communication system
            agent_directory: Registry of all agents
            my_name: This agent's name
        """
        self._agent_slack = agent_slack
        self._agent_directory = agent_directory
        self._my_name = my_name
        self._pending_messages = []
    
    def request_help(
        self,
        target_agent: str,
        request_type: str,
        problem: str,
        context: Dict[str, Any],
        priority: str = "normal",
        wait_for_response: bool = False
    ) -> Optional[Any]:
        """
        Request help from another agent.
        
        Args:
            target_agent: Name of agent to request help from
            request_type: Type of help needed
            problem: Description of the problem
            context: Additional context (code, error, data)
            priority: "critical" | "high" | "normal" | "low"
            wait_for_response: If True, blocks until response received
        
        Returns:
            Response data if wait_for_response=True, else None
        
        Example:
            response = self.request_help(
                target_agent="DomainExpert",
                request_type="library_research",
                problem="Need to parse chess board from image",
                context={
                    "task": "chess_fen_extraction",
                    "requirements": ["image_processing", "chess_notation"]
                },
                priority="high",
                wait_for_response=True
            )
        """
        if not self._agent_slack:
            logger.warning(f"[{self._my_name}] Cannot request help - no agent_slack")
            return None
        
        # Verify target agent exists
        if target_agent not in self._agent_directory:
            logger.error(f"[{self._my_name}] Unknown agent: {target_agent}")
            return None
        
        # Build help request message
        message_data = {
            "message_type": "help_request",
            "request_type": request_type,
            "problem": problem,
            "context": context,
            "priority": priority,
            "from_agent": self._my_name,
            "timestamp": time.time(),
            "request_id": str(uuid.uuid4())[:8]
        }
        
        logger.info(f"🆘 [{self._my_name}] Requesting help from {target_agent}: {request_type}")
        
        # Send via SmartAgentSlack
        success = self._agent_slack.send(
            from_agent=self._my_name,
            to_agent=target_agent,
            data=message_data,
            field_name="help_request"
        )
        
        if not success:
            logger.error(f"❌ [{self._my_name}] Help request failed")
            return None
        
        # Wait for response if requested
        if wait_for_response:
            return self._wait_for_response(message_data["request_id"], timeout=30)
        
        return None
    
    def share_knowledge(
        self,
        target_agent: str,
        knowledge_type: str,
        data: Any,
        confidence: float = 0.8
    ) -> bool:
        """
        Share knowledge with another agent.
        
        Args:
            target_agent: Agent to share with (or "all" for broadcast)
            knowledge_type: Type of knowledge
            data: The knowledge data
            confidence: Confidence in this knowledge (0-1)
        
        Returns:
            True if shared successfully
        
        Example:
            self.share_knowledge(
                target_agent="CodeMaster",
                knowledge_type="edge_case_warning",
                data={
                    "library": "opencv",
                    "function": "cv2.imread",
                    "edge_case": "Returns None instead of raising exception",
                    "solution": "Always check: if img is None: raise FileNotFoundError()",
                    "severity": "critical"
                },
                confidence=0.95
            )
        """
        if not self._agent_slack:
            return False
        
        message_data = {
            "message_type": "knowledge_share",
            "knowledge_type": knowledge_type,
            "data": data,
            "confidence": confidence,
            "from_agent": self._my_name,
            "timestamp": time.time()
        }
        
        logger.info(f"📤 [{self._my_name}] Sharing knowledge with {target_agent}: {knowledge_type}")
        
        if target_agent == "all":
            # Broadcast to all agents
            return self.broadcast_to_swarm("knowledge_share", message_data)
        else:
            return self._agent_slack.send(
                from_agent=self._my_name,
                to_agent=target_agent,
                data=message_data,
                field_name="knowledge_share"
            )
    
    def broadcast_to_swarm(
        self,
        message_type: str,
        data: Any
    ) -> bool:
        """
        Broadcast message to all agents.
        
        Args:
            message_type: Type of message
            data: Message data
        
        Returns:
            True if broadcast successful
        """
        if not self._agent_slack or not self._agent_directory:
            return False
        
        logger.info(f"📢 [{self._my_name}] Broadcasting: {message_type}")
        
        success_count = 0
        for agent_name in self._agent_directory.keys():
            if agent_name == self._my_name:
                continue  # Don't send to self
            
            if self._agent_slack.send(
                from_agent=self._my_name,
                to_agent=agent_name,
                data=data,
                field_name="broadcast"
            ):
                success_count += 1
        
        logger.info(f"✅ [{self._my_name}] Broadcast delivered to {success_count} agents")
        return success_count > 0
    
    def check_incoming_messages(self) -> List[Dict]:
        """
        Check for messages from other agents.
        
        Returns:
            List of message dicts
        """
        if not self._agent_slack:
            return []
        
        messages = self._agent_slack.receive(self._my_name)
        
        if messages:
            logger.info(f"📬 [{self._my_name}] Received {len(messages)} messages")
        
        return [m.data for m in messages]
    
    def find_agent_for_capability(
        self,
        capability: str
    ) -> Optional[str]:
        """
        Find which agent has a specific capability.
        
        Args:
            capability: Capability to search for
        
        Returns:
            Agent name or None
        
        Example:
            expert = self.find_agent_for_capability("library_research")
            # Returns: "DomainExpert"
        """
        if not self._agent_directory:
            return None
        
        for agent_name, info in self._agent_directory.items():
            if capability in info.get("capabilities", []):
                return agent_name
            if capability in info.get("accepts_requests_for", []):
                return agent_name
        
        return None
    
    def get_agent_info(self, agent_name: str) -> Optional[Dict]:
        """Get information about an agent."""
        if not self._agent_directory:
            return None
        return self._agent_directory.get(agent_name)
    
    def list_available_agents(self) -> List[str]:
        """Get list of available agent names."""
        if not self._agent_directory:
            return []
        return [
            name for name, info in self._agent_directory.items()
            if info.get("status") == "available"
        ]
    
    def _wait_for_response(
        self,
        request_id: str,
        timeout: float = 30
    ) -> Optional[Any]:
        """Wait for response to a help request."""
        start_time = time.time()
        
        while (time.time() - start_time) < timeout:
            messages = self.check_incoming_messages()
            
            for msg in messages:
                if msg.get("in_response_to") == request_id:
                    logger.info(f"✅ [{self._my_name}] Received response to {request_id}")
                    return msg.get("data")
            
            time.sleep(0.5)  # Poll every 500ms
        
        logger.warning(f"⏱️  [{self._my_name}] Response timeout for {request_id}")
        return None
```

**Integration:** All agents in `surface/agents/` inherit from this

---

### Component 3: Enhanced Agent Signatures

**Purpose:** Enable agents to express collaboration intent

**Files to modify:** All `surface/signatures/*.py` files

**Add to each signature:**
```python
collaboration_actions = dspy.OutputField(
    desc="""JSON array of collaboration actions to take with other agents.
    
    Use this to REQUEST HELP or SHARE KNOWLEDGE with other agents!
    
    Available agents and their capabilities:
    {{agent_directory_will_be_injected}}
    
    Structure:
    [
        {
            "action": "request_help" | "share_knowledge" | "broadcast",
            "target_agent": "agent_name" | "all",
            "type": "library_research" | "error_solution" | "code_review" | etc.,
            "data": {
                // Action-specific data
                "problem": "description",
                "context": {...},
                "priority": "critical" | "high" | "normal"
            }
        }
    ]
    
    Examples:
    
    REQUEST HELP from DomainExpert:
    {
        "action": "request_help",
        "target_agent": "DomainExpert",
        "type": "library_research",
        "data": {
            "problem": "Need best library for chess board image processing",
            "context": {"task": "extract_fen_from_image", "format": "PNG"},
            "priority": "high"
        }
    }
    
    SHARE KNOWLEDGE with CodeMaster:
    {
        "action": "share_knowledge",
        "target_agent": "CodeMaster",
        "type": "edge_case_warning",
        "data": {
            "library": "opencv",
            "warning": "cv2.imread returns None instead of exception",
            "solution": "Check if img is None before using",
            "confidence": 0.95
        }
    }
    
    BROADCAST discovery to all:
    {
        "action": "broadcast",
        "target_agent": "all",
        "type": "task_insight",
        "data": {
            "insight": "This is a chess puzzle task, need python-chess library",
            "confidence": 0.9
        }
    }
    
    CRITICAL: If you need information or help, USE THIS! Don't work in isolation!
    """
)
```

**Inject agent directory:** In Conductor before agent execution

---

### Component 4: Collaboration-Aware Execution

**Purpose:** Process collaboration actions from agents

**File:** `Synapse/core/conductor.py`  
**Method:** `_execute_actor()` lines 4932-5133

**Enhanced flow:**

```python
async def _execute_actor(
    self,
    actor_config: ActorConfig,
    task: TodoItem,
    context: str,
    kwargs: Dict,
    actor_context_dict: Optional[Dict] = None
) -> Any:
    """Execute actor with collaboration support."""
    
    # Get actor
    actor = actor_config.agent
    
    # ✅ NEW: Inject collaboration context
    if hasattr(actor, 'set_collaboration_context'):
        actor.set_collaboration_context(
            agent_slack=self.agent_slack,
            agent_directory=self.agent_directory,
            my_name=actor_config.name
        )
        logger.debug(f"💬 [{actor_config.name}] Collaboration context injected")
    
    # Resolve parameters
    resolved_kwargs = self._resolve_parameters(...)
    
    # ✅ NEW: Add agent directory to context for prompt injection
    resolved_kwargs['_agent_directory'] = json.dumps(
        self.agent_directory,
        indent=2
    )
    
    # Execute actor
    result = await actor(**resolved_kwargs)
    
    # ✅ NEW: Process collaboration actions
    collaboration_actions = self._extract_collaboration_actions(result)
    
    if collaboration_actions:
        logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} collaboration actions")
        
        for action in collaboration_actions:
            await self._process_collaboration_action(
                action,
                from_actor=actor_config.name,
                context=kwargs
            )
    
    # Check for incoming messages
    if hasattr(actor, 'check_incoming_messages'):
        incoming = actor.check_incoming_messages()
        if incoming:
            logger.info(f"📬 [{actor_config.name}] Has {len(incoming)} pending messages")
            # Could process messages here or in next iteration
    
    return result


def _extract_collaboration_actions(self, result: Any) -> List[Dict]:
    """Extract collaboration_actions from agent output."""
    actions = []
    
    # Check if result has collaboration_actions field
    if hasattr(result, 'collaboration_actions'):
        actions_str = str(result.collaboration_actions)
        
        # Parse JSON
        try:
            actions = json.loads(actions_str)
            if not isinstance(actions, list):
                actions = [actions]
        except json.JSONDecodeError:
            logger.warning("Failed to parse collaboration_actions")
    
    return actions


async def _process_collaboration_action(
    self,
    action: Dict,
    from_actor: str,
    context: Dict
) -> None:
    """Process a single collaboration action."""
    action_type = action.get("action")
    target_agent = action.get("target_agent")
    
    if action_type == "request_help":
        await self._handle_help_request(action, from_actor, context)
    
    elif action_type == "share_knowledge":
        await self._handle_knowledge_share(action, from_actor)
    
    elif action_type == "broadcast":
        await self._handle_broadcast(action, from_actor)


async def _handle_help_request(
    self,
    action: Dict,
    from_actor: str,
    context: Dict
) -> None:
    """Handle help request by invoking target agent."""
    target_agent = action.get("target_agent")
    request_type = action["data"].get("type")
    problem = action["data"].get("problem")
    request_context = action["data"].get("context", {})
    
    logger.info(f"🆘 Help request: {from_actor} → {target_agent} ({request_type})")
    
    # Get target actor config
    if target_agent not in self.actors:
        logger.error(f"Unknown target agent: {target_agent}")
        return
    
    target_config = self.actors[target_agent]
    
    # Build instruction for target agent
    instruction = f"""
HELP REQUEST from {from_actor}:

Type: {request_type}
Problem: {problem}
Context: {json.dumps(request_context, indent=2)}

Please provide assistance.
"""
    
    # Execute target agent
    try:
        response = await self._execute_actor(
            actor_config=target_config,
            task=TodoItem(id="help_request", description=instruction),
            context=instruction,
            kwargs=context
        )
        
        # Send response back via agent_slack
        self.agent_slack.send(
            from_agent=target_agent,
            to_agent=from_actor,
            data={
                "message_type": "help_response",
                "in_response_to": action.get("request_id"),
                "response": response
            }
        )
        
        logger.info(f"✅ Help provided: {target_agent} → {from_actor}")
        
    except Exception as e:
        logger.error(f"❌ Help request failed: {e}")
```

---

### Component 5: Pre-Execution Research Phase

**Purpose:** Automatically research libraries before coding

**File:** `Synapse/core/conductor.py`  
**New method:** `_run_pre_execution_research()` (before `run()`)

**Design:**
```python
async def _run_pre_execution_research(
    self,
    goal: str,
    plan: Any,
    kwargs: Dict
) -> None:
    """
    Automatically call DomainExpert to research needed libraries.
    
    Called BEFORE task execution to gather knowledge proactively.
    
    Args:
        goal: The main goal
        plan: Plan from DynamicTaskPlanner
        kwargs: Execution context
    """
    # Check if DomainExpert exists
    if "DomainExpert" not in self.actors:
        logger.info("⏭️  No DomainExpert - skipping pre-execution research")
        return
    
    logger.info("🔬 Phase: Pre-Execution Research")
    
    # Analyze goal and plan to identify research needs
    research_needs = self._identify_research_needs(goal, plan)
    
    if not research_needs:
        logger.info("  ℹ️  No research needs identified")
        return
    
    logger.info(f"  📚 Research needs: {research_needs}")
    
    # Call DomainExpert for each need
    domain_expert = self.actors["DomainExpert"]
    
    for need in research_needs:
        instruction = f"""
RESEARCH REQUEST (Pre-Execution):

Goal: {goal}
Research Needed: {need["type"]}
Context: {json.dumps(need["context"], indent=2)}

Please research and provide:
1. Recommended libraries
2. API documentation
3. Edge cases and gotchas
4. Best practices

Store findings in shared memory for other agents to use.
"""
        
        try:
            await self._execute_actor(
                actor_config=domain_expert,
                task=TodoItem(id="pre_research", description=instruction),
                context=instruction,
                kwargs=kwargs
            )
            
            logger.info(f"  ✅ Research complete: {need['type']}")
            
        except Exception as e:
            logger.error(f"  ❌ Research failed: {e}")
    
    logger.info("✅ Pre-execution research phase complete")


def _identify_research_needs(
    self,
    goal: str,
    plan: Any
) -> List[Dict]:
    """
    Identify what needs to be researched based on goal and plan.
    
    Uses LLM to analyze goal and extract research requirements.
    """
    # Simple keyword-based for now, could be LLM-based
    needs = []
    
    goal_lower = goal.lower()
    
    # Domain detection
    if any(word in goal_lower for word in ["chess", "puzzle", "move", "board"]):
        needs.append({
            "type": "game_logic_libraries",
            "context": {
                "domain": "chess",
                "requirements": ["board_representation", "move_validation"]
            }
        })
    
    if any(word in goal_lower for word in ["image", "picture", "photo", "png", "jpg"]):
        needs.append({
            "type": "image_processing_libraries",
            "context": {
                "domain": "image_processing",
                "requirements": ["image_loading", "image_analysis"]
            }
        })
    
    # Could be enhanced with LLM analysis
    return needs
```

---

## 📂 FILE-BY-FILE CHANGES

### 1. `Synapse/core/conductor.py`

**Lines:** Multiple sections  
**Changes:**
- Add `_build_agent_directory()` method (after line 1130)
- Add `agent_directory` attribute (line ~950)
- Modify `_execute_actor()` to inject collaboration context (line ~5100)
- Add `_extract_collaboration_actions()` method
- Add `_process_collaboration_action()` method
- Add `_handle_help_request()` method
- Add `_handle_knowledge_share()` method
- Add `_run_pre_execution_research()` method
- Add `_identify_research_needs()` method

**Estimated:** +300 lines

---

### 2. `Synapse/core/agent_collaboration_mixin.py`

**Status:** NEW FILE  
**Purpose:** Provide collaboration methods  
**Methods:**
- `set_collaboration_context()`
- `request_help()`
- `share_knowledge()`
- `broadcast_to_swarm()`
- `check_incoming_messages()`
- `find_agent_for_capability()`
- `get_agent_info()`
- `list_available_agents()`

**Estimated:** +200 lines

---

### 3. `surface/agents/base_swarm_agent.py`

**Lines:** ~50-100  
**Changes:**
- Inherit from `AgentCollaborationMixin`
- Accept `_agent_slack`, `_agent_directory`, `_my_name` in forward()
- Call `set_collaboration_context()` when collaboration params provided

**Estimated:** +30 lines

---

### 4. All signature files in `surface/signatures/`

**Files:**
- `code_master_signature.py`
- `domain_expert_signature.py`
- `data_mind_signature.py`
- `sys_ops_signature.py`
- `secure_sentry_signature.py`
- `science_core_signature.py`

**Changes:** Add `collaboration_actions` output field to each

**Estimated:** +20 lines each (120 total)

---

### 5. All architect prompts in `surface_synapse/architect/`

**Files:**
- `codemaster_agent.md`
- `domainexpert_agent.md`
- `datamind_agent.md`
- `sysops_agent.md`
- `secure_sentry_agent.md`
- `science_core_agent.md`

**Changes:**
- Add "Available Agents" section with {{agent_directory}}
- Add "Collaboration Guide" section with examples
- Add "When to Request Help" guidelines

**Estimated:** +100 lines each (600 total)

---

### 6. `Synapse/core/data_structures.py`

**Lines:** After existing structures  
**Changes:**
- Add `AgentDirectoryEntry` dataclass (optional, for type safety)
- Add `CollaborationAction` dataclass (optional)

**Estimated:** +50 lines (optional)

---

## 📅 IMPLEMENTATION PHASES

### Phase 1: Infrastructure (Week 1, Days 1-5)

#### Day 1-2: Agent Directory
- Create `_build_agent_directory()` in Conductor
- Test directory building
- Verify all agents registered

#### Day 3-4: Collaboration Mixin
- Create `agent_collaboration_mixin.py`
- Implement all methods
- Unit test each method

#### Day 5: Integration Testing
- Test directory + mixin together
- Verify no breaking changes

---

### Phase 2: Agent Enhancement (Week 2, Days 6-10)

#### Day 6-7: Update Agents
- Modify `base_swarm_agent.py` to inherit mixin
- Update all 6 agent files
- Test agent initialization

#### Day 8-9: Update Signatures
- Add `collaboration_actions` to all signatures
- Test signature changes don't break existing

#### Day 10: Update Prompts
- Add collaboration sections to all prompts
- Test prompt loading

---

### Phase 3: Execution Enhancement (Week 2-3, Days 11-15)

#### Day 11-12: Collaboration Processing
- Implement `_process_collaboration_action()`
- Implement help request handling
- Test help request flow

#### Day 13-14: Pre-Execution Research
- Implement `_run_pre_execution_research()`
- Implement research need identification
- Test research phase

#### Day 15: Integration
- Connect all phases
- End-to-end test

---

### Phase 4: Testing & Validation (Week 3, Days 16-20)

#### Day 16-17: Chess Task Testing
- Run chess task with collaboration
- Verify DomainExpert researches libraries
- Verify CodeMaster receives research
- Verify edge cases handled

#### Day 18: Other Task Testing
- Test with image processing task
- Test with web scraping task
- Verify generalization

#### Day 19: Metrics & Monitoring
- Implement collaboration metrics
- Track message counts
- Measure success rate improvement

#### Day 20: Documentation & Review
- Document all changes
- Create usage guide
- A-Team review

---

## 🧪 TESTING STRATEGY

### Unit Tests

**Test 1: Agent Directory Building**
```python
def test_agent_directory_building():
    conductor = Conductor(...)
    directory = conductor._build_agent_directory()
    
    assert "CodeMaster" in directory
    assert "DomainExpert" in directory
    assert "capabilities" in directory["CodeMaster"]
    assert len(directory["CodeMaster"]["capabilities"]) > 0
```

**Test 2: Collaboration Mixin**
```python
def test_request_help():
    agent = MockAgent()
    agent.set_collaboration_context(mock_slack, mock_directory, "TestAgent")
    
    response = agent.request_help(
        target_agent="DomainExpert",
        request_type="library_research",
        problem="Need chess library",
        context={}
    )
    
    # Verify message sent
    assert mock_slack.send_called
    assert mock_slack.last_to_agent == "DomainExpert"
```

**Test 3: Collaboration Action Extraction**
```python
def test_extract_collaboration_actions():
    result = MockResult()
    result.collaboration_actions = '[{"action": "request_help", ...}]'
    
    actions = conductor._extract_collaboration_actions(result)
    
    assert len(actions) == 1
    assert actions[0]["action"] == "request_help"
```

---

### Integration Tests

**Test 4: Help Request Flow**
```python
async def test_help_request_flow():
    # Setup
    conductor = create_test_conductor()
    
    # Agent A requests help from Agent B
    result_a = await conductor._execute_actor(
        actor_config=agent_a_config,
        task=TodoItem(...),
        ...
    )
    
    # Verify Agent B was invoked
    assert agent_b_invoked
    
    # Verify response sent back
    messages = agent_a.check_incoming_messages()
    assert len(messages) > 0
    assert messages[0]["message_type"] == "help_response"
```

**Test 5: Pre-Execution Research**
```python
async def test_pre_execution_research():
    conductor = create_test_conductor()
    
    await conductor._run_pre_execution_research(
        goal="Solve chess puzzle from image",
        plan=mock_plan,
        kwargs={}
    )
    
    # Verify DomainExpert was called
    assert domain_expert_called
    
    # Verify research stored in memory
    memories = conductor.shared_memory.query("chess library")
    assert len(memories) > 0
```

---

### End-to-End Tests

**Test 6: Chess Task with Collaboration**
```python
async def test_chess_task_with_collaboration():
    conductor = create_production_conductor()
    
    result = await conductor.run(
        goal="Solve the chess puzzle in chess_board.png and write best move to move.txt"
    )
    
    # Verify success
    assert result.success == True
    
    # Verify collaboration happened
    stats = conductor.agent_slack.get_cooperation_stats()
    assert stats["total_events"] > 0
    assert "DomainExpert" in stats["help_given"]
    
    # Verify correct output
    with open("move.txt") as f:
        move = f.read().strip()
    assert len(move) >= 4  # e.g., "e2e4"
```

---

## 📊 SUCCESS METRICS

### Before Implementation

| Metric | Value |
|--------|-------|
| Chess task success | ❌ 0% |
| Agent-to-agent messages | 0 per task |
| Help requests | 0 |
| Knowledge shares | 0 |
| Pre-execution research | Never |
| Error recovery via research | Never |
| Complex task success rate | ~30% |

### After Implementation (Expected)

| Metric | Target |
|--------|--------|
| Chess task success | ✅ 100% |
| Agent-to-agent messages | 10-20 per task |
| Help requests | 3-5 per complex task |
| Knowledge shares | 5-10 per task |
| Pre-execution research | Always |
| Error recovery via research | >80% |
| Complex task success rate | ~80% |

### Key Performance Indicators

1. **Collaboration Rate:** % of tasks with agent-to-agent messages
2. **Help Request Success:** % of help requests that led to task success
3. **Research Impact:** % improvement when pre-execution research used
4. **Knowledge Reuse:** % of shared knowledge used by other agents
5. **Error Recovery:** % of errors solved via agent collaboration

---

## 🎯 FINAL ARCHITECTURE DIAGRAM

```
┌──────────────────────────────────────────────────────────────────────────┐
│                           CONDUCTOR                                       │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐ │
│  │                    AGENT DIRECTORY                                   │ │
│  │  {CodeMaster: {capabilities:[...], provides:[...], status:...},     │ │
│  │   DomainExpert: {...}, SysOps: {...}, ...}                          │ │
│  └─────────────────────────────────────────────────────────────────────┘ │
│                                 ▲                                         │
│                                 │ updates                                │
│                                 │                                         │
│  ┌─────────────────────────────┴─────────────────────────────────────┐  │
│  │                    SmartAgentSlack (HUB)                            │  │
│  │  • MessageBus                                                       │  │
│  │  • FormatRegistry                                                   │  │
│  │  • Cooperation Tracking                                             │  │
│  │  • send(from, to, data)                                            │  │
│  │  • receive(agent)                                                   │  │
│  └────┬──────────┬──────────┬──────────┬──────────┬──────────┬───────┘  │
│       │          │          │          │          │          │           │
│  ┌────▼─────┐┌──▼─────┐┌───▼────┐┌───▼────┐┌───▼────┐┌───▼────┐       │
│  │CodeMaster││Domain  ││SysOps  ││Secure  ││Science ││Data    │       │
│  │          ││Expert  ││        ││Sentry  ││Core    ││Mind    │       │
│  │          ││        ││        ││        ││        ││        │       │
│  │Mixin:    ││Mixin:  ││Mixin:  ││Mixin:  ││Mixin:  ││Mixin:  │       │
│  │•request_ ││•request││•request││•request││•request││•request│       │
│  │ help()   ││ _help()││ _help()││ _help()││ _help()││ _help()│       │
│  │•share_   ││•share_ ││•share_ ││•share_ ││•share_ ││•share_ │       │
│  │ know()   ││ know() ││ know() ││ know() ││ know() ││ know() │       │
│  │•check_   ││•check_ ││•check_ ││•check_ ││•check_ ││•check_ │       │
│  │ msgs()   ││ msgs() ││ msgs() ││ msgs() ││ msgs() ││ msgs() │       │
│  └──────────┘└────────┘└────────┘└────────┘└────────┘└────────┘       │
│       ▲          ▲          ▲          ▲          ▲          ▲           │
│       │          │          │          │          │          │           │
│       └──────────┴──────────┴──────────┴──────────┴──────────┘           │
│                  All agents know about each other                        │
│                  All agents can request help                            │
│                  All agents can share knowledge                         │
└──────────────────────────────────────────────────────────────────────────┘
                                 ▲
                                 │
                                 │
                         EXECUTION FLOW
                                 │
                                 ▼
┌──────────────────────────────────────────────────────────────────────────┐
│ 1. Conductor.run(goal="Solve chess puzzle")                              │
│                                                                           │
│ 2. Pre-Execution Research Phase                                          │
│    → Conductor calls DomainExpert: "Research chess + image libraries"    │
│    → DomainExpert researches, stores in HierarchicalMemory               │
│    → Agent directory updated                                             │
│                                                                           │
│ 3. Task Execution Phase                                                  │
│    → Conductor calls CodeMaster with goal                                │
│    → CodeMaster sees research in shared memory                           │
│    → CodeMaster implements using researched libraries                    │
│    → If stuck: CodeMaster.request_help(DomainExpert, "error_solution")   │
│    → DomainExpert responds with fix                                      │
│    → CodeMaster applies fix and continues                                │
│                                                                           │
│ 4. Validation Phase                                                      │
│    → Auditor validates output                                            │
│    → If failed: Auditor can trigger DomainExpert research                │
│                                                                           │
│ 5. Success! Task complete with collaboration                             │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## ✅ COMPLETION CHECKLIST

### Week 1: Infrastructure
- [ ] Agent directory building implemented
- [ ] Agent collaboration mixin created
- [ ] Unit tests passing
- [ ] No breaking changes

### Week 2: Agent Enhancement
- [ ] All agents inherit mixin
- [ ] All signatures include collaboration_actions
- [ ] All prompts include collaboration guide
- [ ] Agents receive collaboration context

### Week 3: Execution & Testing
- [ ] Collaboration actions processed
- [ ] Help requests invoke target agents
- [ ] Pre-execution research works
- [ ] Chess task succeeds
- [ ] Success rate >75%

### Final Validation
- [ ] System is generic (not chess-specific)
- [ ] Agents autonomously collaborate
- [ ] Knowledge flows between agents
- [ ] Error recovery through collaboration works
- [ ] Metrics show improvement
- [ ] Documentation complete

---

**Status:** Ready for implementation  
**Estimated Effort:** 3 weeks  
**Expected Impact:** Transform from 30% to 80% success rate  
**Risk Level:** Low (additive changes, no architectural rewrites)

