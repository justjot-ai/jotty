# UV Assistant - Packaging Quick Start

Get your UV Assistant application packaged and ready for distribution in minutes.

## Prerequisites Check

Before starting, ensure you have:

```bash
# Check Python
python3 --version  # Should be 3.13+

# Check Node.js
node --version     # Should be 18+

# Check Poetry
poetry --version

# Install PyInstaller if needed
pip install pyinstaller
```

## Quick Build Commands

### macOS

```bash
# Navigate to project root
cd /path/to/term

# Make script executable (first time only)
chmod +x scripts/build_app.sh

# Build for macOS
./scripts/build_app.sh --platform mac

# Output: dist/UV-1.0.0.dmg
```

### Windows

```cmd
REM Navigate to project root
cd C:\path\to\term

REM Build for Windows
scripts\build_app.bat --platform win

REM Output: dist\UV Setup 1.0.0.exe
```

### Linux

```bash
# Navigate to project root
cd /path/to/term

# Build for Linux
./scripts/build_app.sh --platform linux

# Output: dist/UV-1.0.0.AppImage
```

## Build Options

### Clean Build

Remove all previous build artifacts before building:

```bash
# macOS/Linux
./scripts/build_app.sh --clean --platform mac

# Windows
scripts\build_app.bat --clean --platform win
```

### Build All Platforms

```bash
./scripts/build_app.sh --platform all
```

**Note**: Cross-platform limitations apply:
- macOS builds require macOS
- Windows builds work best on Windows
- Linux builds work on any platform

## What Gets Built?

The packaging process creates:

1. **Standalone Python Backend**
   - UV FastAPI server
   - Synapse core engine
   - Surface agent framework
   - surface_synapse integration
   - All dependencies bundled

2. **Electron Application**
   - Desktop UI
   - Embedded browser (CDP)
   - Terminal interface
   - WebSocket communication

3. **Platform Installer**
   - macOS: DMG with drag-to-install
   - Windows: NSIS installer
   - Linux: AppImage (portable)

## Build Time

Typical build times:
- **First build**: 5-10 minutes (downloads dependencies)
- **Subsequent builds**: 2-5 minutes (cached dependencies)

## Output Location

All build artifacts are in the `dist/` directory:

```
dist/
├── UV-1.0.0.dmg              # macOS
├── UV Setup 1.0.0.exe        # Windows
├── UV-1.0.0.AppImage         # Linux
└── README.txt                # Installation instructions
```

## Testing Your Build

### macOS

```bash
# Mount and install
open dist/UV-1.0.0.dmg
# Drag UV.app to Applications
# Launch from Applications folder
```

### Windows

```cmd
REM Run installer
dist\UV Setup 1.0.0.exe
REM Follow installation wizard
REM Launch from Start Menu
```

### Linux

```bash
# Make executable
chmod +x dist/UV-1.0.0.AppImage

# Run directly
./dist/UV-1.0.0.AppImage
```

## Troubleshooting

### Build Fails: "PyInstaller not found"

```bash
pip install pyinstaller
```

### Build Fails: "Poetry not found"

```bash
curl -sSL https://install.python-poetry.org | python3 -
```

### Build Fails: "electron-builder error"

```bash
cd electron-app
rm -rf node_modules
npm install
cd ..
```

### Backend Doesn't Start

Check the startup script:
- macOS/Linux: `electron-app/resources/start_backend.sh`
- Windows: `electron-app/resources/start_backend.bat`

### Large Bundle Size

This is normal. The bundle includes:
- Python runtime
- All Python packages
- Node.js/Electron runtime
- Chromium browser

Typical sizes: 150-300 MB

## Next Steps

1. **Test on Clean System**: Install on a machine without dev tools
2. **Create Release**: Upload to GitHub Releases or distribution platform
3. **Code Sign** (Optional): Sign for macOS/Windows
4. **Distribute**: Share with users

## Advanced Usage

For advanced options and customization, see:
- [Full Build Guide](BUILD_GUIDE.md)
- [ADR: Application Packaging](adr/application-packaging-system.md)

## CI/CD Integration

To automate builds, see the GitHub Actions example in [BUILD_GUIDE.md](BUILD_GUIDE.md#cicd-integration).

## Support

- **Build Issues**: Check [BUILD_GUIDE.md](BUILD_GUIDE.md#troubleshooting)
- **Runtime Issues**: Check application logs
- **Questions**: Open an issue on GitHub

## Quick Reference

| Task | Command |
|------|---------|
| Build for current platform | `./scripts/build_app.sh` |
| Build for macOS | `./scripts/build_app.sh --platform mac` |
| Build for Windows | `scripts\build_app.bat --platform win` |
| Build for Linux | `./scripts/build_app.sh --platform linux` |
| Clean build | `./scripts/build_app.sh --clean` |
| Build all platforms | `./scripts/build_app.sh --platform all` |

---

**Ready to build?** Run `./scripts/build_app.sh` and you're done! 🚀
