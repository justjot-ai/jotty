# Quick Start: Electron App with UV Backend

## 🚀 One-Command Startup

```bash
./scripts/run_electron_app.sh
```

This starts the UV FastAPI backend and launches the Electron app.

## 🧪 Test the Backend

```bash
./scripts/test_electron_backend.sh
```

## 📋 What Changed?

- **Backend:** Now uses `uv/` FastAPI server on port 8000 (was port 8765)
- **Core API:** Uses `/api/v1/perform` endpoint
- **Example:**
  ```bash
  curl -X POST "http://localhost:8000/api/v1/perform" \
    -H "Content-Type: application/json" \
    -d '{"task": "Check if I have any unread WhatsApp messages"}'
  ```

## 📖 Documentation

- **Full Migration Details:** `ELECTRON_UV_MIGRATION.md`
- **Architecture Decision:** `docs/adr/0001-electron-app-uv-fastapi-integration.md`
- **Electron App README:** `electron-app/README.md`
- **UV Backend README:** `uv/README.md`

## ✅ Verification

All files passed syntax checks:
- ✅ Python files (electron_support.py, main.py, config.py)
- ✅ Shell scripts (run_electron_app.sh, test_electron_backend.sh)
- ✅ Electron app files (main.js, app.js)

## 🎯 Key Points

1. **Single Backend:** UV FastAPI handles all requests
2. **Main Endpoint:** `/api/v1/perform` for task execution
3. **Stub Endpoints:** UI support endpoints return placeholder data
4. **Port Change:** 8765 → 8000
5. **No User Impact:** Startup script handles everything

---

**Ready to use! Run `./scripts/run_electron_app.sh` to start.**
