# Unified Agent Session Embedding - Executive Summary

**Date:** 2026-02-01  
**Status:** Ready for Implementation  
**Timeline:** 12-15 hours  

---

## What You're Getting

**A unified system where the ACTIVE agent is visible in your Electron UI - automatically switches based on which agent is working.**

```
┌─────────────────────────────────────────────────────┐
│ Left: Tasks  │  Center: ACTIVE AGENT │ Right: Memory │
│              │  ┌──────────────────┐ │               │
│ ✓ Search web │  │ [BrowserExecutor]│ │ 🧠 Memory     │
│ → Run tests  │  │ [Chrome browser] │ │               │
│   Deploy app │  │  live view!      │ │ 🌍 Env        │
│              │  │                  │ │               │
│              │  │ ONLY active agent│ │ ⚡ Agents:     │
│              │  │ visible at once  │ │ • Browser ●   │
│              │  │                  │ │ • Terminal    │
│              │  │                  │ │ • Search      │
│              │  └──────────────────┘ │ • Planner     │
└─────────────────────────────────────────────────────┘

When TerminalExecutor becomes active:
┌─────────────────────────────────────────────────────┐
│ Left: Tasks  │  Center: ACTIVE AGENT │ Right: Memory │
│              │  ┌──────────────────┐ │               │
│ ✓ Search web │  │[TerminalExecutor]│ │ 🧠 Memory     │
│ ✓ Run tests  │  │ $ npm test       │ │               │
│ → Deploy app │  │ ✓ Tests passed   │ │ ⚡ Agents:     │
│              │  │                  │ │ • Browser     │
│              │  │ AUTOMATICALLY    │ │ • Terminal ●  │
│              │  │ SWITCHED!        │ │ • Search      │
│              │  └──────────────────┘ │ • Planner     │
└─────────────────────────────────────────────────────┘
```

---

## The Solution

### **Single Active Agent View with Auto-Switching**

**Backend:** `AgentSessionManager`
- Tracks which agent is currently active
- Auto-activates agent when it sends events
- Only ONE agent active at a time

**Frontend:** `AgentViewManager`
- Shows only the active agent
- Automatically switches when agent changes
- Smooth transitions between agents

**Protocol:** Unified WebSocket Events
```json
{
  "type": "agent_activated",
  "agent": "BrowserExecutor"
}

{
  "type": "agent_event",
  "agent": "BrowserExecutor",
  "event_type": "navigate",
  "data": { "url": "https://..." }
}
```

**Key Feature:** When any agent sends an event, it automatically becomes visible!

---

## Agent Support

| Agent | What You See | Technology |
|-------|-------------|-----------|
| **BrowserExecutor** | Real Chrome browser | Electron BrowserView |
| **TerminalExecutor** | Real terminal | xterm.js |
| **WebSearchAgent** | Search results | HTML panel |
| **PlannerAgent** | Planning steps | Text panel |

**All with identical, seamless integration!**

---

## Key Features

### **For Users**
- ✅ See ONLY the active agent (no clutter)
- ✅ Automatic switching when agent changes
- ✅ Clear focus on what's happening NOW
- ✅ Professional, clean interface

### **For Developers**
- ✅ Simpler than multi-view approach
- ✅ Auto-activation (no manual switching)
- ✅ Easy to add new agents
- ✅ Less state management

### **Technical**
- ✅ Real browser embedding (not screenshots)
- ✅ Real terminal emulator (not plain text)
- ✅ Automatic view switching
- ✅ Secure (read-only views)
- ✅ Lower resource usage (one view at a time)

---

## Implementation Plan

### **Phase 1: Core Infrastructure** (3-4 hours)
- Create `AgentSessionManager` with activation system (backend)
- Create `AgentViewManager` with auto-switching (frontend)
- Implement unified WebSocket protocol

### **Phase 2: Agent Views** (5-6 hours)
- **BrowserExecutor:** Electron BrowserView integration
- **TerminalExecutor:** xterm.js integration
- **WebSearchAgent:** Results panel
- **PlannerAgent:** Plan visualizer

### **Phase 3: Integration & Polish** (1-2 hours)
- Testing
- Smooth transitions
- Error handling
- Documentation

**Total: 9-12 hours** (3 hours faster than multi-view!)

---

## What Gets Built

### **Backend Files**
```
surface_synapse/
├── agent_session_manager.py  (NEW - unified manager)
└── server.py                  (UPDATED - initialize manager)

surface/src/surface/tools/
├── browser_tools.py           (UPDATED - use manager)
├── terminal_tools.py          (UPDATED - use manager)
└── web_search_tools.py        (UPDATED - use manager)
```

### **Frontend Files**
```
electron-app/src/
├── main.js                    (UPDATED - BrowserView setup)
└── renderer/
    ├── js/
    │   ├── agent-view-manager.js  (NEW - unified frontend)
    │   ├── terminal.js            (NEW - xterm.js wrapper)
    │   └── app.js                 (UPDATED - integrate manager)
    ├── css/
    │   └── agent-views.css        (NEW - agent styles)
    └── index.html                 (UPDATED - agent containers)
```

---

## Technical Architecture

```
┌─────────────────────────────────────────────────────┐
│              Electron Frontend                       │
│  ┌──────────────────────────────────────────────┐  │
│  │         AgentViewManager                      │  │
│  │  • BrowserViewHandler                         │  │
│  │  • TerminalViewHandler                        │  │
│  │  • SearchViewHandler                          │  │
│  │  • PlannerViewHandler                         │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
                         ▲
                         │ WebSocket
                         │ (unified protocol)
                         │
┌─────────────────────────────────────────────────────┐
│              Python Backend                          │
│  ┌──────────────────────────────────────────────┐  │
│  │      AgentSessionManager                      │  │
│  │  • register_agent()                           │  │
│  │  • broadcast_agent_event()                    │  │
│  │  • track active agents                        │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

## Benefits

### **Unified Approach**
- Single API for all agents
- Consistent event handling
- Easy to extend

### **User Experience**
- Complete visibility
- Real-time updates
- Professional UI

### **Maintainability**
- Centralized code
- Easy debugging
- Scalable architecture

---

## Security

- ✅ All views are read-only (users can't inject commands)
- ✅ WebSocket already secured
- ✅ Process isolation maintained
- ✅ No new attack vectors

---

## Performance

| Metric | Impact |
|--------|--------|
| Memory | +500MB (for all agent views) |
| CPU | +5-7% (for real-time updates) |
| Network | Minimal (WebSocket events) |
| Latency | <100ms (for all agents) |

**Acceptable on modern systems!**

---

## Success Criteria

- ✅ All agents visible in Electron UI
- ✅ Seamless switching between agents
- ✅ Real-time updates
- ✅ Consistent UI/UX
- ✅ No performance degradation
- ✅ Easy to add new agents
- ✅ Complete in 12-15 hours

---

## Next Steps

1. **Review this plan** - Confirm approach
2. **Phase 1** - Build core infrastructure (4-5 hours)
3. **Phase 2** - Implement agent views (6-8 hours)
4. **Phase 3** - Integration and polish (2-3 hours)
5. **Ship!** 🚀

---

## Documentation

**Detailed Plans:**
- [A-Team Review: Unified Agent Embedding](./review/A_TEAM_UNIFIED_AGENT_EMBEDDING_PLAN.md) - Complete technical discussion
- [ADR: Unified Agent Session Embedding](./adr/unified-agent-session-embedding.md) - Architecture decision

**Agent-Specific:**
- [A-Team Review: TRUE Chrome Embedding](./review/A_TEAM_TRUE_CHROME_EMBEDDING_FINAL.md) - BrowserExecutor details
- [A-Team Review: Terminal Embedding](./review/A_TEAM_TERMINAL_EMBEDDING_ANALYSIS.md) - TerminalExecutor details

---

## The Bottom Line

**You get a professional, unified system where you can see EVERYTHING your agents are doing, in real-time, with a beautiful interface.**

- **BrowserExecutor?** See the actual Chrome browser
- **TerminalExecutor?** See the actual terminal
- **WebSearchAgent?** See the search results
- **Any agent?** Just add a handler!

**Timeline:** 9-12 hours (even faster!)  
**Complexity:** Low-Medium (simpler than multi-view)  
**Value:** Extremely High  
**Recommendation:** Ship it! 🚀

---

## Questions?

All technical details are in the linked documents. The architecture is solid, the plan is clear, and the implementation is straightforward.

**Ready to build!** 🔥
