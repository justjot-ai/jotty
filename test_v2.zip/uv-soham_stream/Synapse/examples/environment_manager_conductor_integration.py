"""
Environment Manager + Conductor Integration Example

Demonstrates how to integrate the Environment Manager with Synapse Conductor
for automatic context tracking during swarm execution.

Usage:
    python environment_manager_conductor_integration.py
"""
import asyncio
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def example_with_conductor():
    """
    Example showing environment manager integrated with Conductor.
    
    This is a conceptual example showing the integration pattern.
    """
    print("\n" + "="*80)
    print("Environment Manager + Conductor Integration")
    print("="*80 + "\n")
    
    try:
        # Import Synapse components
        from Synapse import (
            Conductor,
            AgentConfig,
            SynapseConfig,
            create_environment_manager
        )
        
        # Create Synapse config
        config = SynapseConfig()
        config.synapse_dir = Path("outputs/synapse_state")
        
        # Create environment manager
        env_manager = create_environment_manager(
            config,
            goal_context="Multi-agent task execution with context tracking"
        )
        
        print("✅ Environment Manager created")
        print(f"📁 Environment file: {env_manager.env_file}")
        
        # Track initialization
        env_manager.add_to_current_env("🚀 Conductor initialization started")
        env_manager.add_to_current_env(f"Configuration loaded from: {config.synapse_dir}")
        
        # Note: Actual Conductor usage would require proper agent setup
        # This is a conceptual example showing the pattern
        
        print("\n📝 Added initialization context")
        
        # Simulate task execution phases
        phases = [
            "Phase 1: Agent initialization",
            "Phase 2: Task breakdown", 
            "Phase 3: Parallel execution",
            "Phase 4: Result aggregation"
        ]
        
        for phase in phases:
            env_manager.add_to_current_env(f"\n### {phase}")
            print(f"✅ Tracked: {phase}")
            await asyncio.sleep(0.2)
        
        # Show current environment
        print("\n📄 Current Environment Context:")
        print("-" * 80)
        content = env_manager.get_current_env()
        print(content)
        print("-" * 80)
        
        # Show statistics
        stats = env_manager.get_statistics()
        print(f"\n📊 Statistics:")
        print(f"  Size: {stats['file_size_bytes']} bytes")
        print(f"  Lines: {stats['line_count']}")
        print(f"  Auto-summarization: {'Active' if stats['auto_summarization_active'] else 'Inactive'}")
        
        # Cleanup
        env_manager.stop_auto_summarization()
        print("\n✅ Integration example completed")
        
    except ImportError as e:
        print(f"⚠️ Import error: {e}")
        print("This example requires full Synapse setup with DSpy configuration.")


async def example_custom_agent_tracking():
    """
    Example showing environment tracking with custom agents.
    """
    print("\n" + "="*80)
    print("Custom Agent Context Tracking")
    print("="*80 + "\n")
    
    from Synapse import create_environment_manager, SynapseConfig
    
    # Create config
    config = SynapseConfig()
    config.synapse_dir = Path("outputs/synapse_state")
    
    # Create environment manager
    env_manager = create_environment_manager(
        config,
        goal_context="Custom multi-agent system"
    )
    
    # Simulate custom agents
    class CustomAgent:
        def __init__(self, name: str, env_manager):
            self.name = name
            self.env_manager = env_manager
        
        async def execute(self, task: str):
            """Execute a task with context tracking."""
            self.env_manager.add_to_current_env(
                f"🤖 Agent '{self.name}' started task: {task}"
            )
            
            # Simulate work
            await asyncio.sleep(0.3)
            
            # Random success/failure
            import random
            success = random.choice([True, True, True, False])  # 75% success
            
            if success:
                self.env_manager.add_to_current_env(
                    f"✅ Agent '{self.name}' completed task: {task}"
                )
                return {"success": True, "result": f"Result from {task}"}
            else:
                self.env_manager.add_to_current_env(
                    f"❌ Agent '{self.name}' failed task: {task} (Retrying...)"
                )
                
                # Retry
                await asyncio.sleep(0.2)
                self.env_manager.add_to_current_env(
                    f"✅ Agent '{self.name}' completed task on retry: {task}"
                )
                return {"success": True, "result": f"Result from {task} (retry)"}
    
    # Create agents
    agents = [
        CustomAgent("DataProcessor", env_manager),
        CustomAgent("CodeGenerator", env_manager),
        CustomAgent("TestRunner", env_manager)
    ]
    
    # Execute tasks
    tasks = [
        "Load data from database",
        "Process data transformations",
        "Generate code from template",
        "Run unit tests",
        "Generate report"
    ]
    
    print("🚀 Starting task execution with context tracking\n")
    
    for i, task in enumerate(tasks):
        agent = agents[i % len(agents)]
        result = await agent.execute(task)
        print(f"  [{i+1}/{len(tasks)}] {task}: {'✅' if result['success'] else '❌'}")
    
    # Show final context
    print("\n📄 Final Environment Context:")
    print("-" * 80)
    content = env_manager.get_current_env()
    # Show last 500 chars
    if len(content) > 500:
        print(content[-500:])
    else:
        print(content)
    print("-" * 80)
    
    # Statistics
    stats = env_manager.get_statistics()
    print(f"\n📊 Context Size: {stats['file_size_bytes']} bytes, {stats['line_count']} lines")
    
    # Cleanup
    env_manager.stop_auto_summarization()
    print("\n✅ Custom agent tracking example completed")


async def example_error_debugging():
    """
    Example showing how environment context helps with debugging.
    """
    print("\n" + "="*80)
    print("Error Debugging with Environment Context")
    print("="*80 + "\n")
    
    from Synapse import create_environment_manager, SynapseConfig
    
    config = SynapseConfig()
    config.synapse_dir = Path("outputs/synapse_state")
    
    env_manager = create_environment_manager(
        config,
        goal_context="Debugging failed task execution"
    )
    
    # Simulate a failing workflow
    env_manager.add_to_current_env("🚀 Starting data pipeline")
    env_manager.add_to_current_env("✅ Step 1: Data loaded (10,000 records)")
    env_manager.add_to_current_env("✅ Step 2: Validation passed")
    env_manager.add_to_current_env("▶️ Step 3: Starting transformation")
    
    await asyncio.sleep(0.2)
    
    # Simulate error
    env_manager.add_to_current_env(
        "❌ ERROR in Step 3: ValueError: Invalid data type in column 'age'\n"
        "   Expected: int, Got: str\n"
        "   Row: 5432\n"
        "   Value: 'unknown'"
    )
    
    env_manager.add_to_current_env(
        "🔍 Analyzing error context:\n"
        "   - Data source: users_2024.csv\n"
        "   - Validation passed but transformation failed\n"
        "   - Suggests data inconsistency"
    )
    
    env_manager.add_to_current_env(
        "🔧 Applied fix: Added type coercion in transformation step"
    )
    
    await asyncio.sleep(0.2)
    
    env_manager.add_to_current_env("🔄 Retrying Step 3 with fix")
    env_manager.add_to_current_env("✅ Step 3: Transformation completed successfully")
    env_manager.add_to_current_env("✅ Pipeline completed")
    
    # Show debugging context
    print("📄 Debugging Context (environment.md):")
    print("-" * 80)
    content = env_manager.get_current_env()
    print(content)
    print("-" * 80)
    
    print("\n💡 The environment context shows:")
    print("  1. What steps executed successfully")
    print("  2. Exact error details with context")
    print("  3. Analysis of the error")
    print("  4. Fix that was applied")
    print("  5. Retry and resolution")
    
    # Cleanup
    env_manager.stop_auto_summarization()
    print("\n✅ Error debugging example completed")


async def main():
    """Run all integration examples."""
    await example_with_conductor()
    await example_custom_agent_tracking()
    await example_error_debugging()
    
    print("\n" + "="*80)
    print("✅ All integration examples completed!")
    print("="*80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
