"""
Environment Manager Example - CoT-based Context Tracking

Demonstrates how to use the Environment Manager for tracking
execution context with automatic CoT-based summarization.

Usage:
    python environment_manager_example.py
"""
import asyncio
import logging
import time
from pathlib import Path
from Synapse import EnvironmentManager, create_environment_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SimpleConfig:
    """Simple configuration for environment manager."""
    def __init__(self):
        self.synapse_dir = Path("outputs") / "example_synapse_state"
        self.env_dir = self.synapse_dir / "env"
        self.env_summarization_interval = 60  # 1 minute
        self.env_max_size_bytes = 10000  # 10KB
        self.env_min_lines = 20
        self.env_max_snapshots = 5


async def simulate_task_execution(env_manager: EnvironmentManager):
    """
    Simulate a task execution with environment tracking.
    
    Args:
        env_manager: Environment manager instance
    """
    logger.info("Starting simulated task execution")
    
    # Track initialization
    env_manager.add_to_current_env("🚀 Starting task execution pipeline")
    env_manager.add_to_current_env("Loaded configuration from config.yaml")
    await asyncio.sleep(0.5)
    
    # Track agent initialization
    env_manager.add_to_current_env("Initializing agents...")
    agents = ["DataMind", "CodeMaster", "SysOps"]
    for agent in agents:
        env_manager.add_to_current_env(f"✅ Agent '{agent}' initialized successfully")
        await asyncio.sleep(0.3)
    
    # Track task processing
    env_manager.add_to_current_env("\n📋 Beginning task processing phase")
    tasks = [
        ("data_preprocessing", "DataMind", True),
        ("model_training", "DataMind", True),
        ("code_generation", "CodeMaster", True),
        ("deployment_setup", "SysOps", False),  # This will fail
        ("monitoring_setup", "SysOps", True),
    ]
    
    for task_name, agent, success in tasks:
        env_manager.add_to_current_env(f"▶️ Executing task: {task_name} (assigned to {agent})")
        await asyncio.sleep(0.4)
        
        if success:
            env_manager.add_to_current_env(f"✅ Task '{task_name}' completed successfully")
        else:
            env_manager.add_to_current_env(f"❌ Task '{task_name}' failed: Connection timeout")
            env_manager.add_to_current_env(f"🔄 Retrying task '{task_name}' with exponential backoff")
            await asyncio.sleep(0.5)
            env_manager.add_to_current_env(f"✅ Task '{task_name}' succeeded on retry")
    
    # Track completion
    env_manager.add_to_current_env("\n🎉 All tasks completed successfully")
    env_manager.add_to_current_env("Generated outputs saved to: /outputs/results/")
    env_manager.add_to_current_env("Execution time: 12.34 seconds")


async def example_basic_usage():
    """Example 1: Basic usage of environment manager."""
    print("\n" + "="*80)
    print("EXAMPLE 1: Basic Usage")
    print("="*80 + "\n")
    
    # Create config
    config = SimpleConfig()
    
    # Create environment manager
    env_manager = create_environment_manager(
        config, 
        goal_context="Example: Basic multi-agent task execution"
    )
    
    # Add some context
    env_manager.add_to_current_env("Starting example task")
    env_manager.add_to_current_env("Loaded user preferences")
    env_manager.add_to_current_env("Connected to database")
    
    # Retrieve current environment
    print("Current Environment:")
    print("-" * 80)
    print(env_manager.get_current_env())
    print("-" * 80)
    
    # Show statistics
    stats = env_manager.get_statistics()
    print("\nEnvironment Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Cleanup
    env_manager.stop_auto_summarization()


async def example_task_execution():
    """Example 2: Tracking a complete task execution."""
    print("\n" + "="*80)
    print("EXAMPLE 2: Task Execution Tracking")
    print("="*80 + "\n")
    
    config = SimpleConfig()
    env_manager = create_environment_manager(
        config,
        goal_context="Multi-agent data pipeline execution"
    )
    
    # Simulate task execution
    await simulate_task_execution(env_manager)
    
    # Show final environment
    print("\n📄 Final Environment Context:")
    print("-" * 80)
    content = env_manager.get_current_env()
    print(content)
    print("-" * 80)
    
    # Show statistics
    stats = env_manager.get_statistics()
    print(f"\n📊 Final size: {stats['file_size_bytes']} bytes, {stats['line_count']} lines")
    
    # Cleanup
    env_manager.stop_auto_summarization()


async def example_manual_summarization():
    """Example 3: Manual summarization trigger."""
    print("\n" + "="*80)
    print("EXAMPLE 3: Manual Summarization")
    print("="*80 + "\n")
    
    config = SimpleConfig()
    config.env_max_size_bytes = 50000  # Large threshold to prevent auto-summarization
    
    env_manager = create_environment_manager(
        config,
        goal_context="Testing manual summarization"
    )
    
    # Add lots of content
    print("Adding content...")
    for i in range(30):
        env_manager.add_to_current_env(
            f"Task {i}: Processing batch {i} with multiple steps and detailed information"
        )
    
    # Check size before summarization
    stats_before = env_manager.get_statistics()
    print(f"\n📊 Before summarization: {stats_before['file_size_bytes']} bytes, {stats_before['line_count']} lines")
    
    # Force summarization
    print("\n🧠 Triggering manual summarization...")
    # Note: This will fail without proper DSpy setup, but demonstrates the API
    try:
        env_manager.force_summarize()
        
        # Check size after summarization
        stats_after = env_manager.get_statistics()
        print(f"📊 After summarization: {stats_after['file_size_bytes']} bytes, {stats_after['line_count']} lines")
        
        reduction = ((stats_before['file_size_bytes'] - stats_after['file_size_bytes']) / 
                    stats_before['file_size_bytes'] * 100)
        print(f"📉 Size reduction: {reduction:.1f}%")
    except Exception as e:
        print(f"⚠️ Summarization requires DSpy to be configured: {e}")
    
    # Cleanup
    env_manager.stop_auto_summarization()


async def example_snapshots():
    """Example 4: Working with snapshots."""
    print("\n" + "="*80)
    print("EXAMPLE 4: Environment Snapshots")
    print("="*80 + "\n")
    
    config = SimpleConfig()
    env_manager = create_environment_manager(
        config,
        goal_context="Snapshot demonstration"
    )
    
    # Add content in phases
    phases = [
        ("Initialization", ["Config loaded", "Agents started", "Database connected"]),
        ("Processing", ["Task 1 complete", "Task 2 complete", "Task 3 complete"]),
        ("Finalization", ["Results saved", "Cleanup done", "Pipeline finished"])
    ]
    
    for phase_name, entries in phases:
        env_manager.add_to_current_env(f"\n### Phase: {phase_name}")
        for entry in entries:
            env_manager.add_to_current_env(f"  - {entry}")
    
    # Show snapshots
    print(f"📸 Total snapshots: {len(env_manager.snapshots)}")
    
    # Get latest snapshot (if any)
    snapshot = env_manager.get_snapshot(-1)
    if snapshot:
        print(f"\n📸 Latest snapshot:")
        print(f"  Timestamp: {snapshot.timestamp}")
        print(f"  Size: {snapshot.size_bytes} bytes")
        print(f"  Lines: {snapshot.line_count}")
    else:
        print("\nℹ️ No snapshots yet (snapshots created during summarization)")
    
    # Cleanup
    env_manager.stop_auto_summarization()


async def example_persistence():
    """Example 5: Environment persistence across sessions."""
    print("\n" + "="*80)
    print("EXAMPLE 5: Persistence Across Sessions")
    print("="*80 + "\n")
    
    config = SimpleConfig()
    
    # Session 1: Create and populate
    print("📝 Session 1: Creating environment...")
    env_manager1 = create_environment_manager(config, "Persistent session")
    env_manager1.add_to_current_env("Session 1: First entry")
    env_manager1.add_to_current_env("Session 1: Second entry")
    env_file = env_manager1.env_file
    print(f"Environment saved to: {env_file}")
    env_manager1.stop_auto_summarization()
    
    # Simulate session end
    await asyncio.sleep(0.5)
    
    # Session 2: Load existing
    print("\n📖 Session 2: Loading existing environment...")
    env_manager2 = create_environment_manager(config, "Persistent session")
    content = env_manager2.get_current_env()
    
    # Verify content persisted
    if "Session 1: First entry" in content:
        print("✅ Content persisted successfully!")
        print("\nRestored content includes:")
        print("  - Session 1: First entry")
        print("  - Session 1: Second entry")
    
    # Add new content
    env_manager2.add_to_current_env("Session 2: New entry")
    print("\n📝 Added new entry in Session 2")
    
    # Show combined content
    stats = env_manager2.get_statistics()
    print(f"\n📊 Combined environment: {stats['line_count']} lines")
    
    # Cleanup
    env_manager2.stop_auto_summarization()


async def main():
    """Run all examples."""
    print("\n" + "="*80)
    print("ENVIRONMENT MANAGER EXAMPLES")
    print("="*80)
    
    try:
        # Run examples
        await example_basic_usage()
        await example_task_execution()
        await example_manual_summarization()
        await example_snapshots()
        await example_persistence()
        
        print("\n" + "="*80)
        print("✅ All examples completed!")
        print("="*80 + "\n")
        
    except Exception as e:
        logger.error(f"Error running examples: {e}", exc_info=True)


if __name__ == "__main__":
    # Run examples
    asyncio.run(main())
