# Environment Manager Examples

This directory contains examples demonstrating the Environment Manager with CoT-based summarization.

## Overview

The Environment Manager provides automatic context tracking with intelligent summarization for long-running multi-agent tasks.

## Files

### `environment_manager_example.py`
Comprehensive examples demonstrating all features of the Environment Manager.

## Running the Examples

### All Examples
```bash
python Synapse/examples/environment_manager_example.py
```

### Individual Examples

The script includes 5 examples:

1. **Basic Usage** - Simple add/get operations
2. **Task Execution Tracking** - Simulated multi-agent pipeline
3. **Manual Summarization** - Force summarization trigger
4. **Environment Snapshots** - Working with historical snapshots
5. **Persistence** - Context preservation across sessions

## Quick Start

```python
from Synapse import create_environment_manager

# Create simple config
class Config:
    synapse_dir = Path("outputs/synapse_state")

# Create manager
env_manager = create_environment_manager(
    Config(), 
    goal_context="My task description"
)

# Add context
env_manager.add_to_current_env("Started execution")
env_manager.add_to_current_env("Completed step 1")

# Get current environment
content = env_manager.get_current_env()
print(content)

# Cleanup
env_manager.stop_auto_summarization()
```

## Features Demonstrated

### 1. Basic Context Tracking
- Adding entries with timestamps
- Retrieving current environment
- Getting statistics

### 2. Task Execution Tracking
- Multi-agent coordination
- Task success/failure tracking
- Error handling and retries
- Phase transitions

### 3. Automatic Summarization
- Background thread operation
- Size threshold triggers
- Manual force trigger
- Compression statistics

### 4. Snapshot Management
- Historical snapshots
- Snapshot retrieval
- Content comparison

### 5. Persistence
- Cross-session persistence
- Environment file location
- Loading existing context

## Configuration

All parameters are configurable:

```python
class SynapseConfig:
    # Directory settings
    synapse_dir: Path = Path("outputs/synapse_state")
    env_dir: Optional[Path] = None  # Override default
    
    # Summarization settings
    env_summarization_interval: int = 60  # Seconds
    env_max_size_bytes: int = 50000  # 50KB
    env_min_lines: int = 100
    
    # Snapshot settings
    env_max_snapshots: int = 10
```

## API Reference

### Core Methods

#### `add_to_current_env(content: str)`
Add new content to environment with timestamp.

```python
env_manager.add_to_current_env("Agent1 completed task A")
```

#### `get_current_env() -> str`
Retrieve current environment content.

```python
content = env_manager.get_current_env()
```

#### `force_summarize()`
Manually trigger CoT summarization.

```python
env_manager.force_summarize()
```

#### `get_statistics() -> Dict[str, Any]`
Get environment statistics.

```python
stats = env_manager.get_statistics()
print(f"Size: {stats['file_size_bytes']} bytes")
print(f"Lines: {stats['line_count']}")
```

#### `get_snapshot(index: int = -1) -> Optional[EnvironmentSnapshot]`
Get historical snapshot.

```python
snapshot = env_manager.get_snapshot(-1)  # Latest
if snapshot:
    print(f"Size: {snapshot.size_bytes} bytes")
```

### Control Methods

#### `start_auto_summarization()`
Start background summarization thread.

#### `stop_auto_summarization()`
Stop background summarization thread.

#### `clear_environment()`
Clear environment and start fresh.

## Output Files

Environment data is stored in:

```
outputs/synapse_state/env/
├── env.md              # Current environment content
└── env_history.json    # Snapshot history
```

### env.md Structure

```markdown
# Environment Context
**Goal:** Multi-agent task execution
**Created:** 2026-01-31 10:30:45
**Last Updated:** 2026-01-31 10:35:22

---

## Environment Updates

### [2026-01-31 10:30:50]
Started task execution

### [2026-01-31 10:31:15]
Agent1 completed subtask A

...
```

### After Summarization

```markdown
# Environment Context
**Goal:** Multi-agent task execution
**Created:** 2026-01-31 10:30:45
**Last Updated:** 2026-01-31 10:35:22
**Last Summarized:** 2026-01-31 10:35:22

---

## Summarization Reasoning
The environment had 50 entries. Key information: task execution,
agent coordination, error recovery. Pruned: redundant status updates.

---

## Key Insights
- Agent1 and Agent2 successfully coordinated on 3 tasks
- Error recovery pattern: retry with exponential backoff
- Overall success rate: 95%

---

## Pruned Information
Removed 30 low-value status updates and redundant progress reports.

---

## Summarized Environment Updates
[Condensed content with key events preserved]
```

## Testing

Run the test suite:

```bash
pytest tests/test_environment_manager.py -v
```

## Best Practices

### 1. Descriptive Context
Use clear, descriptive messages:

✅ Good:
```python
env_manager.add_to_current_env("Agent DataMind completed batch 1 of 10 (1000 records)")
```

❌ Bad:
```python
env_manager.add_to_current_env("done")
```

### 2. Structured Information
Use markdown formatting for clarity:

```python
env_manager.add_to_current_env("""
### Data Processing Phase
- Loaded 10,000 records
- Applied 3 transformations
- Output: processed_data.csv
""")
```

### 3. Error Context
Include relevant error information:

```python
env_manager.add_to_current_env(
    f"❌ Error in Agent {agent_name}: {error_type}\n"
    f"   Details: {error_message}\n"
    f"   Retry attempt: {retry_count}"
)
```

### 4. Goal Context
Provide meaningful goal context on initialization:

```python
env_manager = create_environment_manager(
    config,
    goal_context="Multi-agent data pipeline: ETL process for customer analytics"
)
```

### 5. Cleanup
Always stop auto-summarization when done:

```python
try:
    # Use environment manager
    env_manager.add_to_current_env("...")
finally:
    env_manager.stop_auto_summarization()
```

## Integration with Synapse

### With Conductor

```python
from Synapse import Conductor, create_environment_manager

# Create environment manager
env_manager = create_environment_manager(
    conductor.config,
    goal_context=conductor.root_goal
)

# Track execution
env_manager.add_to_current_env("Swarm execution started")

# Run conductor
result = await conductor.run(task)

# Track completion
env_manager.add_to_current_env(f"Swarm execution completed: {result.success}")
```

### With Custom Agents

```python
class MyAgent:
    def __init__(self, env_manager):
        self.env_manager = env_manager
    
    async def execute(self, task):
        self.env_manager.add_to_current_env(f"Agent {self.name} started task: {task}")
        
        try:
            result = await self._do_work(task)
            self.env_manager.add_to_current_env(f"Agent {self.name} completed task")
            return result
        except Exception as e:
            self.env_manager.add_to_current_env(f"Agent {self.name} failed: {e}")
            raise
```

## Troubleshooting

### Issue: Summarization not triggering

**Check:**
1. File size exceeds threshold: `stats['file_size_bytes'] > config.env_max_size_bytes`
2. Line count is sufficient: `stats['line_count'] >= config.env_min_lines`
3. Auto-summarization is running: `stats['auto_summarization_active'] == True`

**Solution:**
```python
# Manually trigger
env_manager.force_summarize()
```

### Issue: DSpy summarization fails

**Check:**
1. DSpy is configured: `dspy.settings.lm` is set
2. LLM API credentials are valid
3. Check logs for error details

**Solution:**
```python
import dspy
dspy.settings.configure(lm=your_lm)
```

### Issue: Thread safety errors

**Check:**
- Not manually modifying env.md file
- Using provided API methods only

**Solution:**
Always use the API methods (they handle locking internally).

## See Also

- ADR: `docs/adr/environment-manager-cot-summarization.md`
- Tests: `tests/test_environment_manager.py`
- Q-Learning: `Synapse/core/q_learning.py` (similar structure)
- Persistence: `Synapse/core/persistence.py`

## License

See project LICENSE file.
