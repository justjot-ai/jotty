"""
A-TEAM: Auditor Strategy Signatures

LLM-based strategy generation using compound logical reasoning.
No hardcoded thresholds - all decisions made through reasoning.
"""

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False
    dspy = None


if DSPY_AVAILABLE:
    class AuditorStrategySignature(dspy.Signature):
        """
        Generate comprehensive strategy after task validation.

        A-TEAM PRINCIPLE: Use compound logical reasoning to decide WHAT to do, WHY, and HOW.
        """

        test_results = dspy.InputField(
            desc="JSON summary of test results: {passed: X, failed: Y, results: [...], patterns: [...]}"
        )
        task_description = dspy.InputField(desc="Original task description")
        actor_assigned = dspy.InputField(
            desc="Actor that executed the task with capabilities (JSON: {name, capabilities: [...]})"
        )
        failure_analysis = dspy.InputField(
            desc="Detailed analysis of why task failed: root causes, error patterns, recoverability"
        )
        available_actors = dspy.InputField(
            desc="List of all available actors with capabilities (JSON array)"
        )
        attempt_count = dspy.InputField(
            desc="How many times this task has been attempted (integer)"
        )
        task_context = dspy.InputField(
            desc="Additional context: dependencies, previous outputs, swarm state (JSON)"
        )
        time_advisory_context = dspy.InputField(
            desc="Advisory timing context (elapsed/attempt durations) for strategic reasoning only; never enforce hard timeouts"
        )
        reward = dspy.InputField(desc="Auditor reward score (0.0-1.0)")
        confidence = dspy.InputField(desc="Auditor confidence score (0.0-1.0)")

        action = dspy.OutputField(
            desc="One of: pass, pass_partial, retry, stop, re_evaluate"
        )
        reasoning = dspy.OutputField(
            desc="Strategic reasoning using compound logical reasoning: evidence, causal, capability, retry potential, alternative, decision analysis"
        )
        action_confidence = dspy.OutputField(
            desc="Confidence in action choice (0.0-1.0)"
        )
        execution_guidance = dspy.OutputField(
            desc="JSON object with action-specific execution guidance. IMPORTANT: Return valid JSON only."
        )
        decision_metrics = dspy.OutputField(
            desc="JSON object with probabilistic decision metrics: blocker_probability, retry_success_probability, cost_retry, expected_information_gain etc. IMPORTANT: Return valid JSON only."
        )

    class TaskAbandonmentConsensusSignature(dspy.Signature):
        """
        Multi-actor consensus negotiation for task abandonment.

        Instead of external hard-stops or loop limits, the involved actors
        (actor + auditor) negotiate whether a task genuinely cannot be completed.
        Both parties must agree that further retries have no expected value.

        A-TEAM PRINCIPLE: Tasks end through consensus, not arbitrary limits.
        The system streams the negotiation to the UI so users see WHY.
        """

        task_description = dspy.InputField(desc="Original task description")
        attempt_history_json = dspy.InputField(
            desc="JSON array of attempt summaries: [{attempt, error, approach, outcome}]"
        )
        actor_assessment = dspy.InputField(
            desc="Current actor assessment of why the task cannot be completed"
        )
        auditor_assessment = dspy.InputField(
            desc="Auditor assessment of why the task cannot be completed"
        )
        available_resources = dspy.InputField(
            desc="Available actors, tools, and skills that could be tried (JSON)"
        )
        user_goal_context = dspy.InputField(
            desc="Broader user goal and how critical this task is to the overall objective"
        )

        consensus_reached = dspy.OutputField(
            desc="true if both assessments agree the task is genuinely impossible; false if there are untried options"
        )
        reasoning = dspy.OutputField(
            desc="Detailed reasoning about why consensus was or was not reached, referencing specific attempts and capabilities"
        )
        untried_options = dspy.OutputField(
            desc="JSON array of options that have NOT been exhausted (empty array if truly impossible)"
        )
        user_facing_explanation = dspy.OutputField(
            desc="Clear, non-technical explanation for the user about why this task failed and what was tried"
        )
        recommended_action = dspy.OutputField(
            desc="One of: abandon, retry_with_new_approach, escalate_to_user, reroute_to_different_actor"
        )
