"""
DSPy signatures for the TodoCreator agent.
"""

import dspy


class ActorAssignmentSignature(dspy.Signature):
    """
    Assign the best actor to a task based on task type and actor capabilities.
    
    CRITICAL: Only assign actors that have the REQUIRED capabilities for this task.
    REJECT any actor that lacks required capabilities, even if they have other capabilities.
    
    Consider:
    - Task type and requirements
    - Actor capabilities and expertise match (REQUIRED)
    - Actor workload balance (if multiple actors have required capabilities)
    - Whether a task can be parallelized across actors for speed
    - Whether complementary actors could collaborate (e.g., one fetches data, another processes it)
    
    Assignment Priority:
    1. Match capabilities (REQUIRED - reject actors without required capabilities)
    2. If multiple actors have required capabilities, prefer the one with the most relevant specialization
    3. Balance workload across actors to maximize parallelism
    4. If no actor has required capabilities, report error
    """
    
    task_id: str = dspy.InputField(desc="Task ID")
    task_name: str = dspy.InputField(desc="Task name")
    task_type: str = dspy.InputField(desc="Task type (setup, implementation, testing, etc.)")
    task_description: str = dspy.InputField(desc="Detailed task description")
    available_actors: str = dspy.InputField(desc="JSON list of available actors with capabilities")
    
    reasoning: str = dspy.OutputField(desc="Why this actor is best for this task (must explain capability matching)")
    assigned_actor_name: str = dspy.OutputField(desc="Name of the assigned actor")


class DAGValidationSignature(dspy.Signature):
    """
    Validate DAG structure for correctness and executability.
    
    Check:
    - Circular dependencies
    - Missing dependencies
    - Task feasibility
    - Actor assignments completeness
    - Execution order validity
    
    CRITICAL: Only suggest actors that exist in available_actors list.
    Do NOT suggest actors like FileReader, DocumentReader, CollaborativeReasoner
    unless they are explicitly listed in available_actors.
    """
    
    dag_summary: str = dspy.InputField(desc="DAG statistics and structure summary")
    tasks_info: str = dspy.InputField(desc="JSON list of tasks with dependencies")
    assignments_info: str = dspy.InputField(desc="JSON of actor assignments")
    available_actors: str = dspy.InputField(desc="JSON list of ACTUAL available actors with their names and capabilities. ONLY suggest actors from this list.")
    cycle_check: str = dspy.InputField(desc="Result of cycle detection")
    
    is_valid: str = dspy.OutputField(desc="YES or NO - is the DAG valid?")
    issues_found: str = dspy.OutputField(desc="List of issues (one per line, or 'None' if valid). IMPORTANT: Only suggest actors from available_actors list.")
    recommendations: str = dspy.OutputField(desc="Recommendations to fix issues. IMPORTANT: Only suggest actors from available_actors list.")


class DAGFixSignature(dspy.Signature):
    """
    Fix identified issues in the DAG.
    
    Fix:
    - Remove circular dependencies
    - Add missing dependencies
    - Reassign actors for better load balancing
    - Adjust task order
    - Mark infeasible tasks
    """
    
    issue_description: str = dspy.InputField(desc="Description of the issue to fix")
    dag_state: str = dspy.InputField(desc="Current DAG state (JSON)")
    available_actors: str = dspy.InputField(desc="Available actors (JSON)")
    
    fix_type: str = dspy.OutputField(desc="Type of fix (remove_edge, add_edge, reassign_actor, mark_skipped)")
    fix_details: str = dspy.OutputField(desc="Specific fix details (JSON)")
    reasoning: str = dspy.OutputField(desc="Why this fix solves the issue")
