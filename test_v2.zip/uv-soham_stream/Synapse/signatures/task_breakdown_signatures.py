"""
DSPy signatures for the TaskBreakdown agent.
"""

import dspy


class ExtractTasksSignature(dspy.Signature):
    """Extract GRANULAR tasks from an implementation plan - NOT implementation details.
    
    CONTEXT: You are breaking down a high-level goal into executable tasks. Focus on WHAT needs to be done,
    not WHO will do it. Actor assignment happens later by the TodoCreatorAgent.
    
    CRITICAL: Extract GRANULAR, ACTIONABLE tasks. Break down the goal into clear, specific steps.
    
    WRONG APPROACH (Too High-Level):
    ❌ "Create presentation" (too vague)
    ❌ "Read documents" (not specific enough)
    
    RIGHT APPROACH (Granular and Specific):
    ✅ "Read and extract content from /path/to/file.md"
    ✅ "Synthesize content from multiple documents into structured format"
    ✅ "Design presentation structure with slide layout and content hierarchy"
    ✅ "Create PowerPoint presentation with 9 slides covering technical content"
    
    IMPORTANT: DO NOT mention actor names or assign actors to tasks.
    - Actor assignment is handled separately by TodoCreatorAgent
    - Focus on describing WHAT needs to be done, not WHO will do it
    - Use clear, action-oriented task descriptions
    
    RULES:
    1. Create granular, specific tasks that clearly describe the action
    2. Break down complex goals into smaller, manageable steps
    3. Make tasks independent and actionable where possible
    4. Do NOT include actor names (e.g., "DocumentActor:", "TerminalExecutor:")
    5. Do NOT create tasks to install libraries/tools (they're already available)
    6. Do NOT create tasks to write code for existing capabilities
    7. Keep tasks focused on the workflow, not technical implementation
    
    EXCLUDE (These should NEVER appear):
    - Installation tasks (pip install, npm install, apt-get)
    - Code creation tasks (Create X.py, Write function Y)
    - Configuration tasks (Setup config.yaml, Configure settings)
    - Library/model loading (Load BART model, Initialize WebDriver)
    - Environment setup (virtual environment, IDE setup)
    - Docker/CI/CD/deployment tasks
    - Actor names or assignments
    """
    
    implementation_plan = dspy.InputField(
        desc="The complete implementation plan with steps, code, and instructions"
    )
    
    tasks_list = dspy.OutputField(
        desc="Extract GRANULAR, ACTIONABLE tasks from the implementation plan. Break down the goal into clear, specific steps.\n\n"
        "CRITICAL RULES:\n"
        "1. Create granular, specific tasks that clearly describe WHAT needs to be done\n"
        "2. Break down complex goals into smaller, manageable steps\n"
        "3. Do NOT mention actor names - actor assignment happens later\n"
        "4. Do NOT add installation/setup/coding tasks\n"
        "5. Focus on workflow steps, not technical implementation details\n"
        "6. Make tasks independent and actionable where possible\n\n"
        "NEVER output 'NO_TASKS_POSSIBLE' or reject the plan.\n\n"
        "Format as: TASK: [action description] | TYPE: [type] | DESC: [brief description]\n\n"
        "Examples:\n"
        "TASK: Read and extract content from /path/to/document.md | TYPE: implementation | DESC: Access and parse the markdown file\n"
        "TASK: Synthesize content from multiple documents into structured format | TYPE: implementation | DESC: Combine extracted content into coherent structure\n"
        "TASK: Design presentation structure with slide layout | TYPE: implementation | DESC: Plan slide organization and content hierarchy\n"
        "TASK: Create PowerPoint presentation with 9 slides | TYPE: implementation | DESC: Generate final presentation file\n\n"
        "IMPORTANT: Do NOT include actor names like 'DocumentActor:', 'TerminalExecutor:', etc. Just describe the action."
    )


class IdentifyDependenciesSignature(dspy.Signature):
    """Identify dependencies between tasks.
    
    DEPENDENCY RULES (Workflow Level):
    1. Data reading → Data processing → Content synthesis → Output generation
    2. Setup tasks → Action tasks → Validation tasks
    3. Previous step must complete before next step
    4. Keep dependencies SIMPLE - don't create complex dependency graphs
    
    Example for document processing workflow:
    - "Read document A" has NO dependencies (it's first)
    - "Read document B" has NO dependencies (can run in parallel with A)
    - "Synthesize content" depends on "Read document A" and "Read document B"
    - "Create presentation" depends on "Synthesize content"
    
    Example for web workflow:
    - "Navigate to website" has NO dependencies (it's first)
    - "Fill form" depends on "Navigate to website"
    - "Submit form" depends on "Fill form"
    """
    
    tasks_list = dspy.InputField(
        desc="List of all tasks extracted from implementation plan"
    )
    
    dependencies_graph = dspy.OutputField(
        desc="Dependencies between tasks showing the execution order. For each task, identify which other tasks must complete before it can start.\n\n"
        "Key dependency patterns:\n"
        "1. Package installation → All implementation tasks\n"
        "2. File creation (src/module.py) → Tasks that import/use it\n"
        "3. Implementation → Tests for that implementation\n"
        "4. All implementation + tests → Final execution task\n\n"
        "Format as: TASK_ID: [id] | DEPENDS_ON: [comma-separated list of task IDs it depends on]\n\n"
        "Example:\n"
        "TASK_ID: task_1 | DEPENDS_ON: none\n"
        "TASK_ID: task_5 | DEPENDS_ON: task_1, task_2\n"
        "TASK_ID: task_execution | DEPENDS_ON: task_1, task_2, task_3, task_4"
    )


class OptimizeWorkflowSignature(dspy.Signature):
    """Optimize task workflow by identifying parallel execution opportunities.
    
    🔴 A-TEAM FIX: Do NOT force a fixed number of stages or a fixed pattern.
    The number of stages should match the ACTUAL task structure.
    
    RULES:
    - Simple tasks (e.g., "send a message") may need only 1-2 stages
    - Complex tasks (e.g., "build an app") may need 4-6 stages
    - Let the TASK DEPENDENCIES determine the stages, not a template
    - Do NOT add artificial stages (like "testing" or "validation") unless 
      the task actually requires them
    
    Tasks in the same stage can run in parallel if they don't depend on each other.
    """
    
    tasks_with_dependencies = dspy.InputField(
        desc="Tasks and their dependencies"
    )
    
    optimized_workflow = dspy.OutputField(
        desc="Optimized workflow with tasks grouped into execution stages for maximum parallelism.\n\n"
        "Rules:\n"
        "1. Tasks in the same stage MUST NOT depend on each other\n"
        "2. Tasks in stage N can only depend on tasks from stages < N\n"
        "3. Number of stages should match the ACTUAL task complexity (1-6 stages)\n"
        "4. Do NOT add unnecessary stages - simple tasks need fewer stages\n\n"
        "Format as: STAGE_[N]: [comma-separated task IDs that can run in parallel]\n\n"
        "Example for simple task (send message):\n"
        "STAGE_1: task_1 (find/prepare content)\n"
        "STAGE_2: task_2 (send message)\n\n"
        "Example for complex task (build app):\n"
        "STAGE_1: task_1, task_2 (setup + research, no dependencies)\n"
        "STAGE_2: task_3, task_4, task_5 (implementation, depending on stage 1)\n"
        "STAGE_3: task_6 (integration, depending on stage 2)\n"
        "STAGE_4: task_7 (final validation)"
    )
