"""
DSPy signatures for the AgentResolver agent.
"""

import dspy


class ResolveAgentSignature(dspy.Signature):
    """Resolve a requested agent name to the correct agent based on capabilities and context.
    
    CONTEXT: An agent has requested help from another agent, but the requested agent name
    doesn't match any existing agent. You need to find the best matching agent from the
    available agents based on:
    1. The requested agent name (may be incorrect/deprecated)
    2. The type of help needed (knowledge_type)
    3. The context/data being shared
    4. The capabilities of available agents
    
    Your goal is to match the INTENT behind the request, not just the name.
    
    Examples:
    - "FileSystemNavigator" requesting file reading → "TerminalExecutor" (can read files via cat/head/tail)
    - "WhatsAppManager" requesting browser automation → "BrowserExecutor" (handles WhatsApp Web)
    - "CodeMaster" requesting code execution → "TerminalExecutor" (can execute scripts)
    - "DataAnalyst" requesting data processing → Check if any agent has data processing capabilities
    
    CRITICAL: Return the EXACT agent name as it appears in agent_directory, or "all" if no match.
    """
    
    requested_agent_name = dspy.InputField(
        desc="The agent name that was requested (may be incorrect/deprecated)"
    )
    
    knowledge_type = dspy.InputField(
        desc="Type of knowledge/help being requested (e.g., 'read_files', 'execute_script', 'browser_automation')"
    )
    
    request_context = dspy.InputField(
        desc="Context about what the requesting agent needs help with (JSON string)"
    )
    
    available_agents = dspy.InputField(
        desc="JSON string containing available agents with their capabilities: {\"agent_name\": {\"capabilities\": [...], \"description\": \"...\"}}"
    )
    
    resolved_agent_name = dspy.OutputField(
        desc="The correct agent name that matches the request, or 'all' if no specific match. Must be EXACT name from available_agents."
    )
    
    reasoning = dspy.OutputField(
        desc="Brief explanation of why this agent was chosen, including which capabilities match"
    )
    
    confidence = dspy.OutputField(
        desc="Confidence score 0.0-1.0 indicating how well the resolved agent matches the request"
    )
