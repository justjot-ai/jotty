"""
DSPy signatures for DAG optimization (removing unnecessary tasks).
"""

import dspy


class OptimizeDAGSignature(dspy.Signature):
    """Optimize DAG by removing unnecessary tasks and combining redundant ones.
    
    CONTEXT: Available capabilities are EXISTING actors in the system.
    Tasks that install libraries or write code to build these capabilities should be REMOVED.
    """
    
    tasks_summary = dspy.InputField(
        desc="Summary of all tasks in the DAG with their descriptions and types"
    )
    available_capabilities = dspy.InputField(
        desc="List of EXISTING capabilities/actors (e.g., ['browser_interaction', 'summarization']). "
        "These are ALREADY IMPLEMENTED - any tasks trying to build/install these should be removed."
    )
    
    optimization_plan = dspy.OutputField(
        desc="List of task IDs to REMOVE or COMBINE with reasoning. "
        "REMOVE tasks that:\n"
        "1. Install libraries/tools for capabilities that already exist\n"
        "2. Write code to implement capabilities that already exist\n"
        "3. Load ML models for capabilities that already exist\n"
        "4. Are redundant or duplicate work\n"
        "5. Setup development environment (IDE, linters) when not needed\n\n"
        "COMBINE tasks that:\n"
        "1. Can be done in a single step by the same actor\n"
        "2. Are consecutive and non-blocking\n\n"
        "KEEP tasks that:\n"
        "1. Use existing actors/capabilities to complete workflow steps\n"
        "2. Are necessary workflow steps (authentication, navigation, data extraction)\n"
        "3. Validate or test the results\n\n"
        "Format:\n"
        "REMOVE: task_id_1, task_id_2 | REASON: Installing libraries for capabilities that already exist\n"
        "COMBINE: task_id_3 + task_id_4 → new_task | REASON: Can be done in one step by same actor\n"
        "KEEP: task_id_5 | REASON: Uses existing actor capability for workflow step"
    )
