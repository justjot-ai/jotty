"""
DSPy signatures for Synapse agents.
"""

from .task_breakdown_signatures import (
    ExtractTasksSignature,
    IdentifyDependenciesSignature,
    OptimizeWorkflowSignature
)
from .todo_creator_signatures import (
    ActorAssignmentSignature,
    DAGValidationSignature,
    DAGFixSignature
)
from .dag_optimization_signatures import OptimizeDAGSignature
from .user_communication_signatures import (
    UserCommunicationSignature,
    CommunicationPrioritySignature
)
from .auditor_strategy_signatures import AuditorStrategySignature
from .agent_resolver_signatures import ResolveAgentSignature

__all__ = [
    'ExtractTasksSignature',
    'IdentifyDependenciesSignature',
    'OptimizeWorkflowSignature',
    'ActorAssignmentSignature',
    'DAGValidationSignature',
    'DAGFixSignature',
    'OptimizeDAGSignature',
    'UserCommunicationSignature',
    'CommunicationPrioritySignature',
    'AuditorStrategySignature',
    'ResolveAgentSignature',
]
