"""
Session Manager - Complete Output & Persistence Management

A-Team Design Principles:
- Single source of truth for all output paths
- Auto-creates session folders
- Auto-loads previous state if present
- Persists memories, Q-tables, brain state, TODOs
- Generates beautified logs automatically
- No hardcoded paths anywhere

Author: A-Team
Date: Dec 29, 2025
"""

import json
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, AsyncGenerator
from dataclasses import asdict

logger = logging.getLogger(__name__)


class SessionManager:
    """
    Manages all output and persistence for a ReVal session.
    
    Features:
    - Per-session timestamped folders
    - Auto-load from outputs/latest/
    - Persistent memories, Q-tables, brain state
    - Session TODO tracking
    - Beautified log generation
    - Auto-cleanup old runs
    
    Directory Structure:
        outputs/
        ├── latest/ → symlink to most recent run
        ├── run_20251229_220000/
        │   ├── synapse_state/
        │   │   ├── memories/
        │   │   │   ├── shared_memory.json
        │   │   │   └── agent_memories/
        │   │   │       ├── SQLGenerator.json
        │   │   │       └── BusinessTermResolver.json
        │   │   ├── q_tables/
        │   │   │   └── q_predictor.json
        │   │   ├── brain_state/
        │   │   │   └── consolidated.json
        │   │   └── markovian_todos/
        │   │       └── session_todo.md
        │   ├── logs/
        │   │   ├── raw/
        │   │   │   └── test_run_TIMESTAMP.log
        │   │   └── beautified/
        │   │       └── BEAUTIFUL_TIMESTAMP.log
        │   ├── results/
        │   │   └── query_results.json
        │   └── config_snapshot.json
    """
    
    def __init__(self, config: 'SynapseConfig'):
        """
        Initialize session manager.
        
        Args:
            config: SynapseConfig with persistence settings
        """
        self.config = config
        self.base_dir = Path(config.output_base_dir).expanduser().resolve()
        
        # Create or load session
        if config.create_run_folder:
            self.session_dir = self._create_session_folder()
        else:
            self.session_dir = self.base_dir
        
        # Setup directory structure
        self._setup_directories()
        
        # Save config snapshot
        self._save_config_snapshot()
        
        logger.info(f"📁 Session initialized: {self.session_dir}")
        # Note: __init__ cannot be async generator, but initialization is logged
    
    def _create_session_folder(self) -> Path:
        """Create timestamped session folder and update 'latest' symlink."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_dir = self.base_dir / f"run_{timestamp}"
        session_dir.mkdir(parents=True, exist_ok=True)
        
        # Update 'latest' symlink
        latest_link = self.base_dir / "latest"
        if latest_link.exists() or latest_link.is_symlink():
            latest_link.unlink()
        latest_link.symlink_to(session_dir.name)
        
        logger.info(f"✅ Created session folder: {session_dir.name}")
        return session_dir
    
    async def _create_session_folder_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Create session folder with event streaming."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_dir = self.base_dir / f"run_{timestamp}"
        session_dir.mkdir(parents=True, exist_ok=True)
        yield {"module": "Synapse.core.session_manager", "message": f"I am creating a new session folder: {session_dir.name}"}
        
        # Update 'latest' symlink
        latest_link = self.base_dir / "latest"
        if latest_link.exists() or latest_link.is_symlink():
            latest_link.unlink()
        latest_link.symlink_to(session_dir.name)
        
        logger.info(f"✅ Created session folder: {session_dir.name}")
        yield {"module": "Synapse.core.session_manager", "message": f"I have successfully created session folder {session_dir.name}"}
        yield {"type": "result", "result": session_dir, "module": "Synapse.core.session_manager", "message": "I am returning the session directory path"}
        return
    
    def _setup_directories(self):
        """Create all necessary subdirectories."""
        # Determine global base directory (shared across runs)
        if self.base_dir.parent.name == "outputs" or "run_" in self.session_dir.name:
            # We're in a run folder, go to outputs/global
            self.global_base_dir = self.base_dir / "global"
        else:
            # Fallback: create global sibling to base_dir
            self.global_base_dir = self.base_dir.parent / "global"
        
        self.global_synapse_dir = self.global_base_dir / "synapse_state"
        
        # Global directories (shared across runs)
        global_dirs = [
            self.global_synapse_dir / "memories" / "agent_memories",
            self.global_synapse_dir / "q_tables",
            self.global_synapse_dir / "brain_state",
        ]
        
        # Run-specific directories
        run_dirs = [
            self.session_dir / "synapse_state" / "markovian_todos",
            self.session_dir / "logs" / "raw",
            self.session_dir / "logs" / "beautified",
            self.session_dir / "logs" / "debug",
            self.session_dir / "results",
        ]
        
        for d in global_dirs + run_dirs:
            d.mkdir(parents=True, exist_ok=True)
    
    def _save_config_snapshot(self):
        """Save config used for this session."""
        config_file = self.session_dir / "config_snapshot.json"
        with open(config_file, 'w') as f:
            json.dump(asdict(self.config), f, indent=2, default=str)
    
    # =========================================================================
    # AUTO-LOADING
    # =========================================================================
    
    def load_previous_state(self) -> Optional[Dict[str, Any]]:
        """
        Auto-load state from outputs/latest/ if it exists.
        
        Returns:
            Dict with loaded state
            
        Raises:
            FileNotFoundError: If auto_load_on_start is True but no previous state exists
            RuntimeError: If loading fails
        """
        if not self.config.auto_load_on_start:
            logger.info("⏭️  Auto-load disabled")
            return None
        
        latest_dir = self.base_dir / "latest"
        if not latest_dir.exists():
            raise FileNotFoundError(
                f"❌ Auto-load enabled but no previous state found at {latest_dir}.\n"
                f"This is a configuration error. Either:\n"
                f"  1. Set config.auto_load_on_start = False, or\n"
                f"  2. Ensure a previous session exists in outputs/latest/"
            )
        
        try:
            state = {}
            
            # 🔧 FIX: Use the same global_synapse_dir that was set during _setup_directories()
            # This ensures consistency between directory creation and loading
            # self.global_synapse_dir is already set in __init__ via _setup_directories()
            global_synapse_dir = self.global_synapse_dir
            
            # Load memories from GLOBAL location
            if self.config.persist_memories:
                state['memories'] = self._load_memories(global_synapse_dir)
            
            # Load Q-tables from GLOBAL location
            if self.config.persist_q_tables:
                state['q_tables'] = self._load_q_tables(global_synapse_dir)
            
            # Load brain state from GLOBAL location
            if self.config.persist_brain_state:
                state['brain_state'] = self._load_brain_state(global_synapse_dir)
            
            # Load TODOs (run-specific)
            if self.config.persist_todos:
                state['todos'] = self._load_todos(latest_dir)
            
            logger.info(f"✅ Loaded previous state from {latest_dir}")
            return state
        
        except FileNotFoundError:
            raise  # Re-raise FileNotFoundError as-is
        except Exception as e:
            raise RuntimeError(
                f"❌ Failed to load previous state from {latest_dir}: {e}\n"
                f"State loading is critical for session continuity. Cannot proceed."
            ) from e
    
    async def load_previous_state_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Load previous state with event streaming."""
        if not self.config.auto_load_on_start:
            logger.info("⏭️  Auto-load disabled")
            yield {"module": "Synapse.core.session_manager", "message": "I noticed auto-load is disabled"}
            yield {"type": "result", "result": None, "module": "Synapse.core.session_manager", "message": "I am returning None because auto-load is disabled"}
            return
        
        latest_dir = self.base_dir / "latest"
        if not latest_dir.exists():
            raise FileNotFoundError(
                f"❌ Auto-load enabled but no previous state found at {latest_dir}.\n"
                f"This is a configuration error. Either:\n"
                f"  1. Set config.auto_load_on_start = False, or\n"
                f"  2. Ensure a previous session exists in outputs/latest/"
            )
        
        try:
            state = {}
            
            # 🔧 FIX: Use the same global_synapse_dir that was set during _setup_directories()
            # This ensures consistency between directory creation and loading
            # self.global_synapse_dir is already set in __init__ via _setup_directories()
            global_synapse_dir = self.global_synapse_dir
            
            # Load memories from GLOBAL location
            if self.config.persist_memories:
                state['memories'] = self._load_memories(global_synapse_dir)
            
            # Load Q-tables from GLOBAL location
            if self.config.persist_q_tables:
                state['q_tables'] = self._load_q_tables(global_synapse_dir)
            
            # Load brain state from GLOBAL location
            if self.config.persist_brain_state:
                state['brain_state'] = self._load_brain_state(global_synapse_dir)
            
            # Load TODOs (run-specific)
            if self.config.persist_todos:
                state['todos'] = self._load_todos(latest_dir)
            
            logger.info(f"✅ Loaded previous state from {latest_dir}")
            yield {"module": "Synapse.core.session_manager", "message": f"I have successfully loaded previous state from {latest_dir}"}
            yield {"type": "result", "result": state, "module": "Synapse.core.session_manager", "message": "I am returning the loaded state"}
            return
        
        except FileNotFoundError:
            raise  # Re-raise FileNotFoundError as-is
        except Exception as e:
            raise RuntimeError(
                f"❌ Failed to load previous state from {latest_dir}: {e}\n"
                f"State loading is critical for session continuity. Cannot proceed."
            ) from e
    
    def _load_memories(self, source_dir: Path) -> Dict[str, Any]:
        """
        Load all memory files from GLOBAL location.
        
        Args:
            source_dir: Global synapse_state directory (not run-specific)
        
        Returns:
            Dict with loaded memories (empty dict if directory doesn't exist - first run)
        """
        memories = {}
        mem_dir = source_dir / "memories"
        
        # 🔧 FIX: Defensive directory creation - handle first-run scenario gracefully
        if not mem_dir.exists():
            logger.warning(
                f"⚠️ Memory directory not found: {mem_dir}\n"
                f"Creating directory structure (this may be a first run)."
            )
            mem_dir.mkdir(parents=True, exist_ok=True)
            # Return empty memories dict for first run
            logger.info("📁 Created memory directory structure - returning empty memories")
            return memories
        
        # Load shared memory
        shared_file = mem_dir / "shared_memory.json"
        if shared_file.exists():
            with open(shared_file) as f:
                memories['shared'] = json.load(f)
        
        # Load agent memories
        agent_dir = mem_dir / "agent_memories"
        if agent_dir.exists():
            memories['agents'] = {}
            for mem_file in agent_dir.glob("*.json"):
                agent_name = mem_file.stem
                with open(mem_file) as f:
                    memories['agents'][agent_name] = json.load(f)
        
        logger.info(f"  📚 Loaded {len(memories.get('agents', {}))} agent memories")
        return memories
    
    async def _load_memories_stream(self, source_dir: Path) -> AsyncGenerator[Dict[str, Any], None]:
        """Load memories with event streaming."""
        memories = {}
        # 🔧 FIX: source_dir is already synapse_state directory, don't add it again
        mem_dir = source_dir / "memories"
        
        # 🔧 FIX: Defensive directory creation - handle first-run scenario gracefully
        if not mem_dir.exists():
            logger.warning(
                f"⚠️ Memory directory not found: {mem_dir}\n"
                f"Creating directory structure (this may be a first run)."
            )
            mem_dir.mkdir(parents=True, exist_ok=True)
            yield {"module": "Synapse.core.session_manager", "message": f"I created the memory directory structure at {mem_dir}"}
            yield {"type": "result", "result": memories, "module": "Synapse.core.session_manager", "message": "I am returning empty memories for first run"}
            return
        
        yield {"module": "Synapse.core.session_manager", "message": "I am loading memories from the previous session"}
        
        # Load shared memory
        shared_file = mem_dir / "shared_memory.json"
        if shared_file.exists():
            with open(shared_file) as f:
                memories['shared'] = json.load(f)
            yield {"module": "Synapse.core.session_manager", "message": "I have loaded the shared memory"}
        
        # Load agent memories
        agent_dir = mem_dir / "agent_memories"
        if agent_dir.exists():
            memories['agents'] = {}
            for mem_file in agent_dir.glob("*.json"):
                agent_name = mem_file.stem
                with open(mem_file) as f:
                    memories['agents'][agent_name] = json.load(f)
        
        logger.info(f"  📚 Loaded {len(memories.get('agents', {}))} agent memories")
        yield {"module": "Synapse.core.session_manager", "message": f"I have loaded {len(memories.get('agents', {}))} agent memories"}
        yield {"type": "result", "result": memories, "module": "Synapse.core.session_manager", "message": "I am returning the loaded memories"}
        return
    
    def _load_q_tables(self, source_dir: Path) -> Dict[str, Any]:
        """
        Load Q-table files from GLOBAL location.
        
        Args:
            source_dir: Global synapse_state directory (not run-specific)
        
        Returns:
            Dict with loaded Q-tables (empty dict if directory doesn't exist - first run)
        """
        q_tables = {}
        q_dir = source_dir / "q_tables"
        
        # 🔧 FIX: Defensive directory creation - handle first-run scenario gracefully
        if not q_dir.exists():
            logger.warning(
                f"⚠️ Q-tables directory not found: {q_dir}\n"
                f"Creating directory structure (this may be a first run)."
            )
            q_dir.mkdir(parents=True, exist_ok=True)
            # Return empty Q-tables dict for first run
            logger.info("📁 Created Q-tables directory structure - returning empty Q-tables")
            return q_tables
        
        for q_file in q_dir.glob("*.json"):
            with open(q_file) as f:
                q_tables[q_file.stem] = json.load(f)
        
        logger.info(f"  🎯 Loaded {len(q_tables)} Q-tables")
        return q_tables
    
    async def _load_q_tables_stream(self, source_dir: Path) -> AsyncGenerator[Dict[str, Any], None]:
        """Load Q-tables with event streaming."""
        q_tables = {}
        # 🔧 FIX: source_dir is already synapse_state directory, don't add it again
        q_dir = source_dir / "q_tables"
        
        # 🔧 FIX: Defensive directory creation - handle first-run scenario gracefully
        if not q_dir.exists():
            logger.warning(
                f"⚠️ Q-tables directory not found: {q_dir}\n"
                f"Creating directory structure (this may be a first run)."
            )
            q_dir.mkdir(parents=True, exist_ok=True)
            yield {"module": "Synapse.core.session_manager", "message": f"I created the Q-tables directory structure at {q_dir}"}
            yield {"type": "result", "result": q_tables, "module": "Synapse.core.session_manager", "message": "I am returning empty Q-tables for first run"}
            return
        
        yield {"module": "Synapse.core.session_manager", "message": "I am loading Q-tables from the previous session"}
        
        for q_file in q_dir.glob("*.json"):
            with open(q_file) as f:
                q_tables[q_file.stem] = json.load(f)
        
        logger.info(f"  🎯 Loaded {len(q_tables)} Q-tables")
        yield {"module": "Synapse.core.session_manager", "message": f"I have loaded {len(q_tables)} Q-tables"}
        yield {"type": "result", "result": q_tables, "module": "Synapse.core.session_manager", "message": "I am returning the loaded Q-tables"}
        return
    
    def _load_brain_state(self, source_dir: Path) -> Optional[Dict[str, Any]]:
        """
        Load brain consolidation state from GLOBAL location.
        
        Args:
            source_dir: Global synapse_state directory (not run-specific)
        
        Returns:
            Dict with brain state if exists, None if not found (first run or not persisted)
        """
        brain_file = source_dir / "brain_state" / "consolidated.json"
        # 🔧 FIX: Brain state is optional - return None instead of raising error
        if not brain_file.exists():
            logger.info(f"📁 Brain state file not found: {brain_file} (this is normal for first run)")
            return None
        
        with open(brain_file) as f:
            state = json.load(f)
        logger.info(f"  🧠 Loaded brain state")
        return state
    
    async def _load_brain_state_stream(self, source_dir: Path) -> AsyncGenerator[Dict[str, Any], None]:
        """Load brain state with event streaming."""
        # 🔧 FIX: source_dir is already synapse_state directory, don't add it again
        brain_file = source_dir / "brain_state" / "consolidated.json"
        
        # 🔧 FIX: Brain state is optional - return None instead of raising error
        if not brain_file.exists():
            logger.info(f"📁 Brain state file not found: {brain_file} (this is normal for first run)")
            yield {"module": "Synapse.core.session_manager", "message": f"I noticed brain state file doesn't exist (this is normal for first run)"}
            yield {"type": "result", "result": None, "module": "Synapse.core.session_manager", "message": "I am returning None because brain state doesn't exist"}
            return
        
        yield {"module": "Synapse.core.session_manager", "message": "I am loading brain state from the previous session"}
        
        with open(brain_file) as f:
            state = json.load(f)
        logger.info(f"  🧠 Loaded brain state")
        yield {"module": "Synapse.core.session_manager", "message": "I have successfully loaded the brain state"}
        yield {"type": "result", "result": state, "module": "Synapse.core.session_manager", "message": "I am returning the loaded brain state"}
        return
    
    def _load_todos(self, source_dir: Path) -> Optional[str]:
        """
        Load session TODO markdown.
        
        Raises:
            FileNotFoundError: If TODO file doesn't exist
        """
        todo_file = source_dir / "synapse_state" / "markovian_todos" / "session_todo.md"
        if not todo_file.exists():
            raise FileNotFoundError(
                f"❌ TODO file not found: {todo_file}\n"
                f"Expected TODO state from previous session is missing."
            )
        
        with open(todo_file) as f:
            content = f.read()
        logger.info(f"  ✅ Loaded session TODO")
        return content
    
    async def _load_todos_stream(self, source_dir: Path) -> AsyncGenerator[Dict[str, Any], None]:
        """Load TODOs with event streaming."""
        todo_file = source_dir / "synapse_state" / "markovian_todos" / "session_todo.md"
        if not todo_file.exists():
            raise FileNotFoundError(
                f"❌ TODO file not found: {todo_file}\n"
                f"Expected TODO state from previous session is missing."
            )
        
        yield {"module": "Synapse.core.session_manager", "message": "I am loading session TODO from the previous session"}
        
        with open(todo_file) as f:
            content = f.read()
        logger.info(f"  ✅ Loaded session TODO")
        yield {"module": "Synapse.core.session_manager", "message": "I have successfully loaded the session TODO"}
        yield {"type": "result", "result": content, "module": "Synapse.core.session_manager", "message": "I am returning the loaded TODO content"}
        return
    
    # =========================================================================
    # SAVING
    # =========================================================================
    
    def save_state(self, state: Dict[str, Any]):
        """
        Save complete ReVal state.
        
        Args:
            state: Dict containing memories, q_tables, brain_state, etc.
        """
        try:
            if self.config.persist_memories and 'memories' in state:
                self._save_memories(state['memories'])
            
            if self.config.persist_q_tables and 'q_tables' in state:
                self._save_q_tables(state['q_tables'])
            
            if self.config.persist_brain_state and 'brain_state' in state:
                self._save_brain_state(state['brain_state'])
            
            if self.config.persist_todos and 'todos' in state:
                self._save_todos(state['todos'])
            
            logger.info(f"💾 Saved state to {self.session_dir}")
        
        except Exception as e:
            logger.error(f"❌ Failed to save state: {e}", exc_info=True)
    
    async def save_state_stream(self, state: Dict[str, Any]) -> AsyncGenerator[Dict[str, Any], None]:
        """Save state with event streaming."""
        try:
            yield {"module": "Synapse.core.session_manager", "message": "I am starting to save the session state"}
            
            if self.config.persist_memories and 'memories' in state:
                self._save_memories(state['memories'])
                yield {"module": "Synapse.core.session_manager", "message": "I have saved memories"}
            
            if self.config.persist_q_tables and 'q_tables' in state:
                self._save_q_tables(state['q_tables'])
                yield {"module": "Synapse.core.session_manager", "message": "I have saved Q-tables"}
            
            if self.config.persist_brain_state and 'brain_state' in state:
                self._save_brain_state(state['brain_state'])
                yield {"module": "Synapse.core.session_manager", "message": "I have saved brain state"}
            
            if self.config.persist_todos and 'todos' in state:
                self._save_todos(state['todos'])
                yield {"module": "Synapse.core.session_manager", "message": "I have saved TODOs"}
            
            logger.info(f"💾 Saved state to {self.session_dir}")
            yield {"module": "Synapse.core.session_manager", "message": f"I have successfully saved state to {self.session_dir}"}
        
        except Exception as e:
            logger.error(f"❌ Failed to save state: {e}", exc_info=True)
            yield {"module": "Synapse.core.session_manager", "message": f"I encountered an error while saving state: {str(e)}"}
    
    def _save_memories(self, memories: Dict[str, Any]):
        """Save all memory files to GLOBAL location (shared across runs)."""
        mem_dir = self.global_synapse_dir / "memories"
        
        # Save shared memory
        if 'shared' in memories:
            shared_file = mem_dir / "shared_memory.json"
            with open(shared_file, 'w') as f:
                json.dump(memories['shared'], f, indent=2, default=str)
        
        # Save agent memories
        if 'agents' in memories:
            agent_dir = mem_dir / "agent_memories"
            for agent_name, mem_data in memories['agents'].items():
                mem_file = agent_dir / f"{agent_name}.json"
                with open(mem_file, 'w') as f:
                    json.dump(mem_data, f, indent=2, default=str)
    
    def _save_q_tables(self, q_tables: Dict[str, Any]):
        """Save Q-table files to GLOBAL location (shared across runs)."""
        q_dir = self.global_synapse_dir / "q_tables"
        for name, data in q_tables.items():
            q_file = q_dir / f"{name}.json"
            with open(q_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
    
    def _save_brain_state(self, brain_state: Dict[str, Any]):
        """Save brain consolidation state to GLOBAL location (shared across runs)."""
        brain_file = self.global_synapse_dir / "brain_state" / "consolidated.json"
        with open(brain_file, 'w') as f:
            json.dump(brain_state, f, indent=2, default=str)
    
    def _save_todos(self, todos: str):
        """Save session TODO markdown."""
        todo_file = self.session_dir / "synapse_state" / "markovian_todos" / "session_todo.md"
        with open(todo_file, 'w') as f:
            f.write(todos)
    
    # =========================================================================
    # RESULTS & LOGS
    # =========================================================================
    
    def save_results(self, results: Dict[str, Any]):
        """Save query execution results."""
        result_file = self.session_dir / "results" / "query_results.json"
        with open(result_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"💾 Saved results to {result_file}")
    
    async def save_results_stream(self, results: Dict[str, Any]) -> AsyncGenerator[Dict[str, Any], None]:
        """Save results with event streaming."""
        result_file = self.session_dir / "results" / "query_results.json"
        yield {"module": "Synapse.core.session_manager", "message": "I am saving query execution results"}
        with open(result_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"💾 Saved results to {result_file}")
        yield {"module": "Synapse.core.session_manager", "message": f"I have successfully saved results to {result_file}"}
    
    def get_log_path(self, log_type: str = "raw") -> Path:
        """Get path for log file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return self.session_dir / "logs" / log_type / f"{log_type}_{timestamp}.log"
    
    def get_beautified_log_dir(self) -> Path:
        """Get directory for beautified logs."""
        return self.session_dir / "logs" / "beautified"
    
    def get_debug_log_dir(self) -> Path:
        """Get directory for debug logs."""
        return self.session_dir / "logs" / "debug"
    
    # =========================================================================
    # CLEANUP
    # =========================================================================
    
    def cleanup_old_runs(self):
        """Remove old run folders beyond max_runs_to_keep."""
        if not self.config.max_runs_to_keep:
            return
        
        # Get all run folders
        run_folders = sorted(
            [d for d in self.base_dir.glob("run_*") if d.is_dir()],
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )
        
        # Keep only the newest N
        to_remove = run_folders[self.config.max_runs_to_keep:]
        for folder in to_remove:
            shutil.rmtree(folder)
            logger.info(f"🗑️  Removed old run: {folder.name}")
    
    async def cleanup_old_runs_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Cleanup old runs with event streaming."""
        if not self.config.max_runs_to_keep:
            yield {"module": "Synapse.core.session_manager", "message": "I noticed cleanup is disabled (max_runs_to_keep not set)"}
            return
        
        yield {"module": "Synapse.core.session_manager", "message": "I am starting to clean up old run folders"}
        
        # Get all run folders
        run_folders = sorted(
            [d for d in self.base_dir.glob("run_*") if d.is_dir()],
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )
        
        # Keep only the newest N
        to_remove = run_folders[self.config.max_runs_to_keep:]
        for folder in to_remove:
            shutil.rmtree(folder)
            logger.info(f"🗑️  Removed old run: {folder.name}")
            yield {"module": "Synapse.core.session_manager", "message": f"I have removed old run folder: {folder.name}"}
        
        if to_remove:
            yield {"module": "Synapse.core.session_manager", "message": f"I have completed cleanup, removed {len(to_remove)} old run folders"}
    
    # =========================================================================
    # UTILITIES
    # =========================================================================
    
    def get_session_info(self) -> Dict[str, Any]:
        """Get information about current session."""
        return {
            'session_dir': str(self.session_dir),
            'session_name': self.session_dir.name,
            'created': datetime.fromtimestamp(self.session_dir.stat().st_mtime).isoformat(),
            'has_memories': (self.session_dir / "synapse_state" / "memories").exists(),
            'has_q_tables': (self.session_dir / "synapse_state" / "q_tables").exists(),
            'has_brain_state': (self.session_dir / "synapse_state" / "brain_state" / "consolidated.json").exists(),
            'has_todos': (self.session_dir / "synapse_state" / "markovian_todos" / "session_todo.md").exists(),
        }

