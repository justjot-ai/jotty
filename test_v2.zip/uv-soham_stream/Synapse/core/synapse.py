"""
SYNAPSE: SYnergistic Neural Agent Processing & Self-organizing Execution
=========================================================================

Brain-Inspired Orchestration for LLM Agent Swarms

This is the main entry point for the SYNAPSE framework (evolved from Synapse).

SYNAPSE Terminology:
- Conductor = Main orchestrator (was Conductor)
- SynapseCore = Core execution engine (was ReVal)
- Architect = Pre-execution planner (was PreVal)
- Auditor = Post-execution validator (was PostVal)
- Cortex = Hierarchical memory (was HierarchicalMemory)
- Axon = Agent communication channel (was AgentSlack)
- Roadmap = Task planning with state tracking (was MarkovianTODO)

Scientific Foundations:
- Reinforcement Learning: TD(λ), Q-Learning, Policy Exploration
- Game Theory: Shapley Values, Nash Equilibrium, Coalition Formation
- Neuroscience: Hippocampal Memory, Sharp Wave Ripple, Cortical Hierarchy
- Information Theory: Shannon Entropy, Surprise, Compression
- Multi-Agent Systems: MARL, Swarm Coordination, Predictive Cooperation

# ✅ GENERIC: No domain-specific logic (no SQL, no Prism, no tool-specific code)
"""

import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# =============================================================================
# SYNAPSE CORE IMPORTS (mapping new names to existing implementations)
# =============================================================================

# Conductor = Main Orchestrator
from .conductor import Conductor

# SynapseCore = Core Execution Engine
from .synapse_core import SynapseCore

# Configuration
from .data_structures import SynapseConfig as SynapseConfig
from .agent_config import AgentConfig  # SYNAPSE v1.0 agent configuration

# Architect = Pre-execution Planner (was PreVal)
# Auditor = Post-execution Validator (was PostVal)
from .inspector import InspectorAgent as InspectorAgent
from .inspector import MultiRoundValidator as IterativeAuditor

# Cortex = Hierarchical Memory
from .cortex import HierarchicalMemory as Cortex

# Axon = Agent Communication
from .axon import SmartAgentSlack as Axon

# Roadmap = Markovian TODO
from .roadmap import MarkovianTODO as Roadmap
from .roadmap import SubtaskState as Checkpoint

# Learning Components
from .learning import TDLambdaLearner as TemporalLearner
from .q_learning import LLMQPredictor as RewardLearner

# Credit Assignment (Game Theory)
from .algorithmic_credit import ShapleyValueEstimator as ContributionEstimator
from .algorithmic_credit import DifferenceRewardEstimator as ImpactEstimator

# Context Management
from .global_context_guard import GlobalContextGuard as ContextSentinel
from .smart_context_manager import SmartContextManager as Focus
from .agentic_chunker import AgenticChunker as Segmenter
from .agentic_compressor import AgenticCompressor as Distiller

# Data Flow
from .io_manager import IOManager as Datastream
from .shared_context import SharedContext as Blackboard
from .data_registry import DataRegistry as Catalog

# Persistence
from .persistence import Vault as Vault
from .session_manager import SessionManager as Chronicle

# Predictive Cooperation
from .predictive_cooperation import (
    CooperationPrinciples,
    NashBargainingSolver,
    CooperationReasoner,
    PredictiveCooperativeAgent
)

# Context Gradient - DELETED (orphaned module, 567 lines dead code)
# A-Team Vote: 8/8 unanimous DELETE (2026-01-29)

# =============================================================================
# SYNAPSE CONVENIENCE FUNCTIONS
# =============================================================================

def create_conductor(
    agents: List[AgentConfig],
    config: Optional[SynapseConfig] = None,
    metadata_provider: Any = None,
    **kwargs
) -> Conductor:
    """
    Create a new SYNAPSE Conductor (orchestrator) for agent swarms.
    
    Args:
        agents: List of AgentConfig defining the agents in the swarm
        config: SynapseConfig with framework settings
        metadata_provider: Optional metadata provider instance
        **kwargs: Additional arguments passed to Conductor
    
    Returns:
        Conductor instance ready to orchestrate the swarm
    
    Example:
        ```python
        from synapse import create_conductor, AgentConfig
        
        agents = [
            AgentConfig(
                name="MyAgent",
                agent=my_dspy_module,
                architect_prompts=["Plan the execution"],
                auditor_prompts=["Validate the output"]
            )
        ]
        
        conductor = create_conductor(agents)
        result = conductor.run(goal="Do something")
        ```
    """
    if config is None:
        config = SynapseConfig()
    
    return Conductor(
        actors=agents,  # Still uses 'actors' internally for now
        config=config,
        metadata_provider=metadata_provider,
        **kwargs
    )


def create_cortex(config: Optional[SynapseConfig] = None) -> Cortex:
    """
    Create a new Cortex (hierarchical memory) instance.
    
    The Cortex manages multi-level memory similar to the brain's cortex:
    - Episodic: Recent experiences
    - Semantic: General knowledge
    - Procedural: How to do things
    - Causal: Why things work
    """
    if config is None:
        config = SynapseConfig()
    return Cortex(config)


def create_axon() -> Axon:
    """
    Create a new Axon (agent communication channel).
    
    The Axon enables neural-inspired messaging between agents,
    with automatic format transformation and context compression.
    """
    return Axon()


def create_roadmap(goal: str) -> Roadmap:
    """
    Create a new Roadmap (Markovian TODO) for task planning.
    
    The Roadmap tracks tasks with state, enables checkpointing,
    and supports dynamic updates during execution.
    """
    roadmap = Roadmap(main_goal=goal)
    return roadmap


# =============================================================================
# SYNAPSE VERSION INFO
# =============================================================================

__version__ = "1.0.0"
__codename__ = "SYNAPSE"
__description__ = "Brain-Inspired Orchestration for LLM Agent Swarms"

# =============================================================================
# ALL EXPORTS
# =============================================================================

__all__ = [
    # SYNAPSE Core
    "Conductor",
    "SynapseCore",
    "SynapseConfig",
    "AgentConfig",
    "InspectorAgent",
    "IterativeAuditor",
    
    # Memory & State
    "Cortex",
    "Axon",
    "Roadmap",
    "Checkpoint",
    
    # Learning
    "TemporalLearner",
    "RewardLearner",
    "ContributionEstimator",
    "ImpactEstimator",
    
    # Context Management
    "ContextSentinel",
    "Focus",
    "Segmenter",
    "Distiller",
    
    # Data Flow
    "Datastream",
    "Blackboard",
    "Catalog",
    "Vault",
    "Chronicle",
    
    # Cooperation
    "CooperationPrinciples",
    "NashBargainingSolver",
    "CooperationReasoner",
    "PredictiveCooperativeAgent",
    "ContextGradient",
    "ContextApplier",
    "ContextUpdate",
    
    # Convenience functions
    "create_conductor",
    "create_cortex",
    "create_axon",
    "create_roadmap",
    
    # Version info
    "__version__",
    "__codename__",
    "__description__",
]

