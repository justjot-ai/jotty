# MENTAL MODELS: Frameworks for Thinkey entities

**A-TEAM CONSENSUS (2026-01-29):** Mental models are COGNITIVE SHORTCUTS that enable efficient reasoning about complex problems. They're REUSABLE PATTERNS for thinkey entities, not domain-specific rules.

---

## 🧠 A-TEAM DEBATE: What Are Mental Models?

### Herbert Simon (Cognitive Science):
> "Mental models are simplified representations of complex systems that allow bounded rational agents to make decisions efficiently. Without mental models, every problem would require exhaustive reasoning from first principles."

### Charlie Munger (Multidisciplinary Thinkey entities):
> "You need a latticework of mental models from multiple disciplines. If you have only one model, you'll torture reality to fit your model. With multiple models, you can triangulate truth."

### Shane Parrish (Farnam Street):
> "Mental models are how we understand the world. They're the thinkey entities tools that help you make better decisions and solve problems effectively. The best models are simple, general, and widely applicable."

### Judea Pearl (Causal Reasoning):
> "Mental models are causal diagrams - they show HOW things relate and WHY things happen. A good mental model captures the causal structure of a domain."

**CONSENSUS:**
✅ Mental models are REUSABLE thinkey entities patterns
✅ Mental models SIMPLIFY complex reasoning
✅ Multiple models provide TRIANGULATION
✅ Good models are SIMPLE, GENERAL, and CAUSAL

---

## 1️⃣ FIRST PRINCIPLES THINkey entities

### Model Description
Break problems down to fundamental truths and reason up from there

**Elon Musk's approach:** "Boil things down to the most fundamental truths and reason up from there, as opposed to reasoning by analogy."

### When to Use
- Novel problems (no analogies available)
- Questioning assumptions
- Innovation and creativity needed
- Existing approaches seem suboptimal

### Framework

```
STEP 1: IDENTIFY the problem clearly
  - What am I trying to achieve?

STEP 2: DECONSTRUCT into fundamental truths
  - What are the basic facts?
  - What MUST be true?
  - What can I NOT change?

STEP 3: QUESTION every assumption
  - What am I assuming?
  - Is this assumption necessary?
  - What if assumption is false?

STEP 4: RECONSTRUCT from first principles
  - Given only fundamental truths, how would I solve this?
  - Build up solution without inherited assumptions

STEP 5: VALIDATE against reality
  - Does this solution work?
  - Is it better than conventional approach?
```

### Example

**Problem:** Need to find best library for X

**Conventional reasoning:** "Others use library L, so I'll use L too"

**First principles:**
```
FUNDAMENTAL TRUTHS:
  - I need functionality F
  - Library must be maintained
  - Library must work in my environment (Python, 2026)

ASSUMPTIONS TO QUESTION:
  - "Popular = best" → Maybe popular but outdated?
  - "Used by others = works for me" → Maybe different requirements?

RECONSTRUCT:
  - What is F exactly? (Define precisely)
  - What are ALL libraries that provide F?
  - Evaluate each on: functionality, maintenance, compatibility
  - Choose based on MY requirements, not popularity

RESULT: Maybe L is best, maybe not - but decision is REASONED
```

---

## 2️⃣ INVERSION (Think Backwards)

### Model Description
Instead of thinkey entities "how do I succeed?", think "how do I fail?" and avoid that

**Charlie Munger:** "Invert, always invert. Many problems are best solved backwards."

### When to Use
- Risk assessment
- Debugging (what would cause this error?)
- Planning (what could go wrong?)
- Avoiding failure

### Framework

```
FORWARD: "How do I achieve X?"
INVERTED: "What would prevent X? How do I avoid that?"

STEPS:
  1. Define success clearly
  2. Invert: What does failure look like?
  3. Identify all ways to fail
  4. Design to avoid each failure mode
  5. Result: Robust solution
```

### Example

**Problem:** Implement problem X successfully

**Forward thinkey entities:** "I'll write code, it'll work"

**Inverted thinkey entities:**
```
FAILURE MODES:
  1. Wrong algorithm → Research algorithms FIRST
  2. Wrong library → Research libraries FIRST
  3. Edge cases not handled → Research edge cases FIRST
  4. Environment issues → Test environment FIRST
  5. Time runs out → Plan timeline, prioritize

PREVENTION:
  - Do research BEFORE coding (prevents 1, 2, 3)
  - Validate environment early (prevents 4)
  - Time-box each step (prevents 5)

RESULT: Much lower failure probability
```

---

## 3️⃣ SECOND-ORDER THINkey entities

### Model Description
Think beyond immediate consequences - what happens NEXT?

**Howard Marks:** "First-level thinkey entities says 'It's a good company, let's buy.' Second-level thinkey entities says 'It's a good company, but everyone thinks so and the stock is overpriced.'"

### When to Use
- Strategic decisions
- Long-term planning
- Game theory situations
- Unintended consequences

### Framework

```
LEVEL 0: What's the immediate effect?
LEVEL 1: What happens next?
LEVEL 2: What happens after that?
LEVEL 3: What's the equilibrium?

Consider:
  - Direct effects
  - Indirect effects
  - Feedback loops
  - System dynamics
```

### Example

**Decision:** Share discovered edge case

**First-order:** "Sharing takes time → Don't share"

**Second-order:**
```
LEVEL 1: If I don't share:
  - I save 2 minutes
  - Others might hit same issue
  - Swarm efficiency decreases

LEVEL 2: If swarm efficiency decreases:
  - Overall task takes longer
  - Other agents waste time
  - My future tasks blocked by their failures

LEVEL 3: Equilibrium:
  - If everyone withholds → Everyone fails (bad equilibrium)
  - If everyone shares → Everyone succeeds (good equilibrium)
  - My choice affects equilibrium

DECISION: Share (second-order thinkey entities reveals it's optimal)
```

---

## 4️⃣ PROBABILISTIC THINkey entities

### Model Description
Think in probabilities, not certainties

**Nate Silver:** "We must think probabilistically, because the future is uncertain and the present is ambiguous."

### When to Use
- Uncertainty (always!)
- Decision makey entities
- Risk assessment
- Predictions

### Framework

```
Instead of: "X will happen" or "X won't happen"
Think: "P(X) = 0.7" with confidence interval [0.6, 0.8]

STEPS:
  1. Identify possible outcomes
  2. Assign probabilities
  3. Update with evidence (Bayes)
  4. Make decisions based on expected value
  5. Calibrate over time
```

### Example

**Question:** Will this library work?

**Bad:** "Yes" or "No"

**Good:**
```
PROBABILITIES:
  - Library is maintained: P = 0.9
  - Library works in Python 3.9: P = 0.85
  - Library has the feature I need: P = 0.8
  - No major bugs: P = 0.7

JOINT PROBABILITY (independent):
  P(all work) = 0.9 × 0.85 × 0.8 × 0.7 = 0.43

CONFIDENCE: Moderate (need more info)

DECISION:
  - Try library, but have backup plan
  - Research edge cases
  - Test early
```

---

## 5️⃣ FEEDBACK LOOPS

### Model Description
Understand how systems reinforce or balance themselves

**Positive loop:** Output amplifies input (exponential growth/decline)
**Negative loop:** Output dampens input (stabilization)

### When to Use
- System dynamics
- Escalation/de-escalation
- Learning and improvement
- Debugging spirals

### Framework

```
IDENTIFY LOOPS:
  A → B → C → A

CLASSIFY:
  - Positive (reinforcing): More A → More B → More A
  - Negative (balancing): More A → Less B → Less A

PREDICT DYNAMICS:
  - Positive loops: Exponential change (good or bad)
  - Negative loops: Stabilization

INTERVENE:
  - Amplify good positive loops
  - Break bad positive loops
  - Maintain good negative loops
  - Break bad negative loops
```

### Example

**Positive loop (good):**
```
Success → Confidence → Better decisions → More success
  
Action: Amplify this loop (celebrate wins, reflect on successes)
```

**Positive loop (bad):**
```
Error → Debug without understanding → More errors → More confusion → Worse errors

Action: Break this loop (pause, get help, do root cause analysis)
```

**Negative loop (good):**
```
High context → Compression → Manageable context → Better decisions

Action: Maintain this loop (keep compressing when context grows)
```

---

## 6️⃣ OPTIONALITY

### Model Description
Value having OPTIONS over committing early

**Nassim Taleb:** "Optionality is the property of asymmetric upside (gains) with corresponding limited downside (losses)."

### When to Use
- Uncertainty is high
- Decisions are reversible
- Multiple paths possible
- Learning while doing

### Framework

```
CREATE OPTIONS:
  - Don't commit early
  - Keep multiple paths open
  - Do cheap experiments
  - Learn before deciding

VALUE OF OPTION:
  - Upside: Can choose best path after learning
  - Downside: Small cost to maintain option
  - Asymmetry: Unlimited upside, limited downside

EXERCISE OPTION:
  - When information reduces uncertainty
  - When one path clearly dominates
  - When cost of waiting exceeds value
```

### Example

**Problem:** Need to implement solution

**No optionality:**
```
Commit to Library A immediately → If wrong, high cost to switch
```

**With optionality:**
```
MAINTAIN OPTIONS:
  - Research multiple libraries (low cost)
  - Learn which is best (reduces uncertainty)
  - Then commit (informed decision)

VALUE:
  - Upside: Choose optimal library
  - Downside: 10 minutes research time
  - Asymmetry: Avoid hours of wrong-path debugging
```

---

## 7️⃣ PARETO PRINCIPLE (80/20 Rule)

### Model Description
80% of effects come from 20% of causes

**Vilfredo Pareto:** Observed 80% of land owned by 20% of population

### When to Use
- Prioritization
- Optimization
- Resource allocation
- Identifying high-impact actions

### Framework

```
ANALYZE:
  - What causes produce most effect?
  - What tasks produce most value?
  - What effort produces most results?

FOCUS:
  - Prioritize high-impact 20%
  - Minimize low-impact 80%
  - Don't perfectionism on 80%

APPLY:
  - 80% of bugs from 20% of code
  - 80% of value from 20% of features
  - 80% of success from 20% of effort
```

### Example

**Task:** Debug code

**Without Pareto:**
```
Check every line systematically → Takes hours
```

**With Pareto:**
```
IDENTIFY 20%:
  - Which 20% of code handles critical logic?
  - Where do 80% of bugs typically occur?
    * Edge case handling
    * Input validation
    * API calls

FOCUS:
  - Check those areas first
  - Find bug in 20% of time

RESULT: 80% efficiency improvement
```

---

## 8️⃣ CIRCLE OF COMPETENCE

### Model Description
Know what you know, know what you don't know

**Warren Buffett:** "Know your circle of competence, and stick within it. The size of that circle is not very important; knowing its boundaries, however, is vital."

### When to Use
- Confidence calibration
- Deciding when to request help
- Risk assessment
- Learning priorities

### Framework

```
THREE ZONES:
  1. COMPETENCE: I know this well
     → High confidence, proceed independently
  
  2. EDGE: I partially know this
     → Medium confidence, proceed with caution
     → Research or ask questions
  
  3. OUTSIDE: I don't know this
     → Low confidence, request help
     → Don't guess

EXPAND CIRCLE:
  - Learn systematically
  - Get feedback
  - Build experience
```

### Example

**Task:** Implement solution

**Self-assess:**
```
COMPETENCE:
  - Python syntax: INSIDE (confidence = 0.95)
  - Algorithms: INSIDE (confidence = 0.85)
  - This specific library: OUTSIDE (confidence = 0.3)

DECISION:
  - Python/algorithms: Proceed independently
  - Library: Request research from DomainExpert

REASONING:
  - Know my boundaries
  - Don't pretend competence I lack
  - Efficient division of labor
```

---

## 9️⃣ MAP IS NOT THE TERRITORY

### Model Description
The model is not reality - all models are simplified approximations

**Alfred Korzybski:** "The map is not the territory"

### When to Use
- Model validation
- Reality checkey entities
- Avoiding over-confidence in plans
- Debugging when plan fails

### Framework

```
REMEMBER:
  - Plans are MODELS of future
  - Models are SIMPLIFICATIONS
  - Reality is RICHER than model
  - Expect SURPRISES

WHEN MODEL FAILS:
  - Don't blame reality
  - Update model
  - Learn from divergence

VALIDATE:
  - Test assumptions
  - Check against reality
  - Iterate model
```

### Example

**Plan:** 5-step solution

**Reality:** Step 3 fails unexpectedly

**Bad response:** "But the plan said it would work!"

**Good response:**
```
RECOGNIZE:
  - My plan was a MODEL
  - Reality diverged
  - Model needs update

LEARN:
  - What did I miss?
  - What assumption was wrong?
  - How to improve model?

UPDATE:
  - Replan from current state
  - Incorporate new knowledge
  - Better model for next time
```

---

## 🎯 APPLYING MULTIPLE MODELS: Triangulation

### Philosophy
Use MULTIPLE mental models to triangulate better answers

**Charlie Munger:** "If you have multiple models, you can look at a problem from different angles and find a solution that works."

### Framework

```
PROBLEM: Complex decision

APPLY MODELS:
  Model 1: First principles
    → What are fundamental truths?
  
  Model 2: Inversion
    → What would cause failure?
  
  Model 3: Probabilistic thinkey entities
    → What are the odds?
  
  Model 4: Second-order thinkey entities
    → What happens next?
  
  Model 5: Circle of competence
    → Do I know enough?

TRIANGULATE:
  - Where do models agree? → High confidence
  - Where do models disagree? → Investigate
  - What do models collectively suggest? → Robust answer
```

### Example: Deciding on Implementation Approach

```
PROBLEM: Should I implement immediately or research first?

MODEL 1 (First Principles):
  - Need correct algorithm
  - Need correct library
  - Need to understand edge cases
  → Research first is fundamental

MODEL 2 (Inversion):
  - Failure mode: Wrong approach → Wasted time
  - Prevention: Research first
  → Research first avoids failure

MODEL 3 (Probabilistic):
  - P(success | no research) = 0.4
  - P(success | research) = 0.85
  → Research first increases odds

MODEL 4 (Second-order):
  - If I start immediately → Likely errors → Debug time → Delays
  - If I research first → Informed start → Faster completion
  → Research first is faster overall

MODEL 5 (Circle of Competence):
  - This library is OUTSIDE my circle
  - → Need to learn or get help first

TRIANGULATION:
  ✅ All 5 models agree: Research first!
  → Very high confidence decision
```

---

## ✅ SUCCESS CRITERIA

You're using mental models when you:
1. ✅ Apply MULTIPLE models to problems
2. ✅ Recognize which models are RELEVANT
3. ✅ TRIANGULATE answers across models
4. ✅ UPDATE models when reality diverges
5. ✅ Choose SIMPLE, GENERAL models
6. ✅ TRANSFER models across domains

You're NOT using mental models when you:
1. ❌ Use only one perspective
2. ❌ Apply models mechanically (wrong context)
3. ❌ Ignore contradictions between models
4. ❌ Stick to model despite evidence
5. ❌ Use overly complex, domain-specific rules
6. ❌ Fail to generalize from one domain to another

---

## 📚 MENTAL MODEL LIBRARY

### Quick Reference

| Problem Type | Relevant Models |
|--------------|----------------|
| Novel problem | First Principles, Probabilistic |
| Risk assessment | Inversion, Second-Order, Probabilistic |
| Optimization | Pareto, Optionality |
| Uncertainty | Probabilistic, Circle of Competence, Optionality |
| System behavior | Feedback Loops, Second-Order |
| Decision makey entities | Multiple models + Triangulation |
| Planning | Map ≠ Territory, Optionality, Second-Order |
| Debugging | Inversion, First Principles, Feedback Loops |
| Collaboration | Second-Order, Circle of Competence |

---

**Remember:** Mental models are THINkey entities TOOLS, not rigid rules. Master multiple models and apply them contextually!

