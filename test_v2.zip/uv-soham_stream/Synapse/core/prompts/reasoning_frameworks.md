# REASONING FRAMEWORKS: How to Think, Not What to Do

**A-TEAM CONSENSUS (2026-01-29):** Agents must learn REASONING PATTERNS, not follow checklists. Intelligence emerges from LOGICAL INFERENCE, not rule-following.

---

## 🧠 A-TEAM DEBATE: Instructions vs. Reasoning

### Alan Turing (Logic & Computation):
> "Instructions tell agents WHAT to do - they're deterministic programs. Reasoning frameworks teach agents HOW TO THINK - they're inference engines. We need inference, not programs."

### Judea Pearl (Causality):
> "Current prompts say 'do X'. Better prompts say 'if you observe Y, reason about the cause, then infer whether X is appropriate'. Causal reasoning, not blind execution."

### David Silver (Reinforcement Learning):
> "Instructions = supervised learning (given labeled data). Reasoning = reinforcement learning (learn through experience and inference). Agents should develop policies, not memorize actions."

### John von Neumann (Game Theory):
> "Instructions assume a single-player game. Reasoning frameworks enable multi-agent strategic thinkey entities: 'What will others do? What should I do given their strategies?' Game theory, not scripts."

**CONSENSUS:**
✅ Replace instructions with REASONING PATTERNS
✅ Teach LOGICAL INFERENCE, not rule-following
✅ Enable CAUSAL REASONING, not correlation
✅ Support STRATEGIC THINkey entities, not script execution

---

## 1️⃣ COMPOUND LOGICAL REASONING

### Philosophy
Multiple pieces of evidence → Logical inference → Conclusion

**NOT:** "If X, do Y"  
**YES:** "If X AND Y AND Z, then logically W must be true, therefore action A is optimal"

### Framework

```
GIVEN:
  - Observations: O₁, O₂, ..., Oₙ
  - Background knowledge: K
  - Goal: G

REASON:
  1. What do observations tell me? (Pattern recognition)
  2. How does this relate to my knowledge? (Semantic linkey entities)
  3. What can I INFER? (Logical deduction)
  4. What's the best action given inferences? (Decision theory)

CONCLUDE:
  - Belief state updated
  - Action chosen with reasoning
```

### Example: Deciding Whether to Request Help

**BAD (Instruction-based):**
```
IF uncertain:
    request_help()
```

**GOOD (Reasoning-based):**
```
OBSERVE:
  - My confidence: P(success | my knowledge) = 0.6
  - Task novelty: No similar task in episodic memory
  - Available agent: DomainExpert (success_rate = 0.92)
  - Q-value: Q(request_help | similar_state) = 0.88
  - Time pressure: Moderate

REASON:
  1. My confidence is low (0.6 < 0.7 threshold)
  2. AND task is novel (no prior experience)
  3. AND DomainExpert has high success rate (0.92)
  4. AND Q-learning suggests requesting help is valuable (0.88)
  5. THEREFORE, expected value of requesting help > proceeding alone

INFER:
  - P(success | request_help) ≈ 0.88
  - P(success | proceed_alone) ≈ 0.6
  - Expected improvement = 0.28

DECIDE:
  - Action: request_help(target=DomainExpert)
  - Reasoning: Compound evidence suggests 28% improvement in success probability
```

**This is COMPOUND LOGICAL REASONING!**

---

## 2️⃣ BAYESIAN REASONING (Uncertainty Quantification)

### Philosophy
Beliefs are PROBABILITIES, updated with evidence

**NOT:** "I know X"  
**YES:** "P(X | evidence) = 0.85, with confidence interval [0.75, 0.95]"

### Framework: Bayesian Belief Update

```
PRIOR: P(hypothesis)
  - What did I believe before observing evidence?

LIKELIHOOD: P(evidence | hypothesis)
  - How likely is this evidence if hypothesis is true?

POSTERIOR: P(hypothesis | evidence)
  - What should I believe after observing evidence?
  - P(H|E) = P(E|H) × P(H) / P(E)  [Bayes' Theorem]

DECISION: Choose action with highest expected utility
  - EU(action) = Σ P(outcome|action) × U(outcome)
```

### Example: Estimating Library Quality

**BAD (Binary thinkey entities):**
```
IF library is popular:
    library is good
```

**GOOD (Bayesian reasoning):**
```
PRIOR:
  - P(library is good) = 0.5 (uninformed prior)

EVIDENCE:
  1. GitHub stars: 10,000 → P(stars|good) = 0.8, P(stars|bad) = 0.2
  2. Last commit: 2 months ago → P(recent|good) = 0.7, P(recent|bad) = 0.4
  3. Issue response time: < 1 day → P(responsive|good) = 0.9, P(responsive|bad) = 0.3

UPDATE (simplified Bayesian):
  P(good | evidence) ≈ 0.5 × (0.8 × 0.7 × 0.9) / Z
                    ≈ 0.87 (after normalization)

CONFIDENCE INTERVAL:
  - With 3 pieces of evidence, confidence ≈ 0.85
  - [0.75, 0.95] range

DECISION:
  - Use this library with 87% confidence
  - Plan for 13% chance it's not optimal
  - Monitor for issues
```

**This is BAYESIAN REASONING!**

---

## 3️⃣ CAUSAL REASONING (Root Cause Analysis)

### Philosophy
Understand CAUSES, not just correlations

**NOT:** "X happened, then Y happened, so X caused Y"  
**YES:** "Does X → Y have a causal mechanism? Or is this spurious correlation?"

### Framework: Judea Pearl's Causal Hierarchy

**Level 1: ASSOCIATION (Seeing)**
  - What is? P(Y|X)
  - Observation: "ImportError occurs after pip install"

**Level 2: INTERVENTION (Doing)**
  - What if I do X? P(Y|do(X))
  - Counterfactual: "If I don't run pip install, does error still occur?"

**Level 3: COUNTERFACTUALS (Imagining)**
  - What if I had done X instead? P(Y_X|X', Y')
  - Retrospection: "If I had used --trusted-host, would it have worked?"

### Causal Reasoning Process

```
OBSERVE: Event E occurred

QUESTION: Why did E occur?

REASON:
  1. IDENTIFY possible causes: C₁, C₂, ..., Cₙ
  2. EVALUATE causal mechanisms:
     - Does C₁ → E have a plausible mechanism?
     - Is there a confounding variable?
  3. TEST counterfactuals:
     - If ¬C₁, would ¬E follow?
  4. RANK causes by strength of evidence

CONCLUDE: Root cause is Cᵢ with confidence P
```

### Example: Debugging ImportError

**BAD (Correlation-based):**
```
ERROR: ImportError occurred
OBSERVE: pip install was run before error
CONCLUDE: pip install caused the error
```

**GOOD (Causal reasoning):**
```
OBSERVE:
  - ImportError: No module named 'chess'
  - pip install library L was executed
  - Command appeared to succeed (exit code 0)
  - But import still fails

CAUSAL HYPOTHESES:
  H₁: pip installed to wrong environment
  H₂: pip install failed silently (SSL error)
  H₃: Module name mismatch (installed 'library L' but importing 'chess')
  H₄: Path issue (module installed but not in sys.path)

EVALUATE MECHANISMS:
  H₁: Mechanism = virtual env mismatch
      - Check: which python? which pip?
      - If different paths → H₁ likely
  
  H₂: Mechanism = SSL certificate failure
      - Check: logs for SSL errors
      - Docker environments often lack certs → H₂ plausible
  
  H₃: Mechanism = naming confusion
      - Check: pip show library L
      - If "import name: chess" → H₃ ruled out
  
  H₄: Mechanism = sys.path missing install dir
      - Check: python -c "import sys; print(sys.path)"
      - If install dir not in path → H₄ plausible

TEST COUNTERFACTUALS:
  - If I use `python -m pip install` (same Python), would it work?
  - If I use `pip install --trusted-host`, would it work?

CONCLUDE:
  - Most likely: H₂ (SSL failure in Docker)
  - Evidence: Exit code 0 but silent failure is common with SSL
  - Action: Retry with --trusted-host flags

This is CAUSAL REASONING!
```

---

## 4️⃣ COUNTERFACTUAL REASONING (What-If Analysis)

### Philosophy
Learn from HYPOTHETICAL scenarios, not just observed ones

**NOT:** "This happened, so I'll remember it"  
**YES:** "This happened, but what if I had done X instead? Would outcome be better?"

### Framework

```
ACTUAL: What happened
  - Action: A₁
  - Outcome: O₁
  - Reward: R₁

COUNTERFACTUAL: What if...?
  - Alternative action: A₂
  - Hypothetical outcome: Ô₂
  - Hypothetical reward: R̂₂

COMPARE:
  - R̂₂ > R₁? → Should have done A₂
  - R̂₂ < R₁? → A₁ was correct
  - R̂₂ ≈ R₁? → Both acceptable

LEARN:
  - Update policy to prefer better action
  - Store counterfactual for future reference
```

### Example: Learning from Failure

**BAD (No counterfactual):**
```
OUTCOME: Task failed
ACTION: Mark failure and move on
```

**GOOD (Counterfactual reasoning):**
```
ACTUAL:
  - I tried to implement solution without askey entities for library research
  - Result: Used wrong library, task failed
  - Reward: -0.5

COUNTERFACTUAL SCENARIO 1:
  - What if I had requested library research first?
  - Estimated outcome: Would have used correct library
  - Estimated reward: +0.8
  - Improvement: +1.3

COUNTERFACTUAL SCENARIO 2:
  - What if I had done web_search myself?
  - Estimated outcome: Would have found correct library (maybe)
  - Estimated reward: +0.6
  - Improvement: +1.1
  - But time cost: +5 minutes

ANALYSIS:
  - Scenario 1 is optimal: High reward, low time cost
  - Lesson: When uncertain about libraries, request research FIRST
  - Update Q-value: Q(request_research_first) ← 0.8
  - Update policy: IF library_uncertainty > 0.5, THEN request_research

STORE COUNTERFACTUAL:
  - Situation: "Need library, uncertain which one"
  - Action taken: "Guessed"
  - Better action: "Request research first"
  - Improvement: +1.3 reward

This is COUNTERFACTUAL LEARNING!
```

---

## 5️⃣ STRATEGIC REASONING (Game Theory)

### Philosophy
Optimal action depends on OTHERS' actions (multi-agent reasoning)

**NOT:** "I'll do X because it's good for me"  
**YES:** "Given others will do Y, my best response is X (Nash Equilibrium)"

### Framework: Game-Theoretic Analysis

```
PLAYERS: Set of agents

STRATEGIES: What each agent can do

PAYOFFS: Utility for each agent given strategy profile

REASON:
  1. What strategies are available to others?
  2. What will others likely choose?
  3. Given their choices, what's my best response?
  4. Is there a Nash Equilibrium?
  5. Can we coordinate for Pareto improvement?

DECIDE: Choose strategy that maximizes expected utility
```

### Example: Knowledge Sharing Decision

**BAD (Single-agent reasoning):**
```
I discovered something useful
Should I share it?
→ Sharing takes time, so NO
```

**GOOD (Game-theoretic reasoning):**
```
SITUATION:
  - I (DomainExpert) discovered library edge case
  - Other agents (CodeMaster, SysOps) might encounter this

PAYOFF MATRIX (simplified):
                 Others Share    Others Don't Share
I Share          (5, 5)          (3, 6)
I Don't Share    (6, 3)          (2, 2)

ANALYSIS:
  1. If others share, my best response: SHARE (5 > 3)
  2. If others don't share, my best response: DON'T SHARE (6 > 2)
  3. Nash Equilibria: (Share, Share) and (Don't Share, Don't Share)
  4. Pareto optimal: (Share, Share) → Total utility = 10
  5. Risk: If I share but others don't, I get 3 (exploited)

COORDINATION:
  - Establish norm: "Everyone shares discoveries"
  - Use reputation: Track who shares vs. withholds
  - Nash Bargaining: Reward sharing with credit assignment

DECIDE:
  - Action: SHARE
  - Reasoning: 
    * (Share, Share) equilibrium is Pareto optimal
    * My sharing encourages others to share (tit-for-tat)
    * Nash Bargaining rewards me for helping others
    * Long-term benefit > short-term cost

This is STRATEGIC REASONING!
```

---

## 6️⃣ TEMPORAL REASONING (Sequence & Trajectory)

### Philosophy
Reason about TIME, not just static states

**NOT:** "What should I do now?"  
**YES:** "What sequence of actions leads to goal? How does action now affect options later?"

### Framework: Multi-Step Planning

```
CURRENT STATE: s₀
GOAL STATE: s_goal
HORIZON: T steps

REASON:
  1. What states are reachable from s₀?
  2. For each action aᵢ, what's the next state P(s₁|s₀, aᵢ)?
  3. What's the optimal path s₀ → s₁ → ... → s_goal?
  4. How do early actions constrain later actions?

PLANNING:
  - Forward search: Explore from s₀ toward s_goal
  - Backward search: Work back from s_goal to s₀
  - Value iteration: Estimate V(s) for all states
  - Policy iteration: Find π(s) that maximizes expected return

DECIDE: Choose a₀ that starts optimal trajectory
```

### Example: Multi-Step Task Planning

**BAD (Greedy, myopic):**
```
GOAL: Implement problem X
ACTION: Start coding immediately
```

**GOOD (Temporal reasoning):**
```
TRAJECTORY ANALYSIS:

Path 1 (Greedy):
  t=0: Start coding
  t=1: Realize I need library
  t=2: Search for library
  t=3: Restart coding with correct library
  Expected reward: -0.2 (wasted time)

Path 2 (Research-first):
  t=0: Research libraries
  t=1: Get library recommendation
  t=2: Start coding with correct library
  t=3: Complete implementation
  Expected reward: +0.8 (efficient)

Path 3 (Parallel):
  t=0: Request library research (async) + start environment setup
  t=1: Receive research results
  t=2: Install library + start coding
  t=3: Complete implementation
  Expected reward: +0.9 (most efficient)

TEMPORAL CONSTRAINTS:
  - Action at t=0 affects options at t=2
  - Parallel path requires coordination with DomainExpert
  - Sequential dependency: Can't code without knowing library

VALUE ESTIMATES:
  V(Path 1) = -0.2
  V(Path 2) = +0.8
  V(Path 3) = +0.9 (but requires coordination)

DECIDE:
  - Choose Path 3 if DomainExpert is available
  - Fallback to Path 2 if not
  - Reasoning: Path 3 maximizes expected value over full trajectory

This is TEMPORAL REASONING!
```

---

## 7️⃣ ABDUCTIVE REASONING (Inference to Best Explanation)

### Philosophy
Given observations, infer the most likely EXPLANATION

**NOT:** "I see X, so X is the cause"  
**YES:** "I see X. What are all possible causes? Which is most likely given evidence?"

### Framework

```
OBSERVATIONS: O₁, O₂, ..., Oₙ

GENERATE HYPOTHESES:
  - H₁: Explanation 1
  - H₂: Explanation 2
  - ...
  - Hₘ: Explanation m

EVALUATE HYPOTHESES:
  For each Hᵢ:
    - Prior: P(Hᵢ)
    - Likelihood: P(O|Hᵢ)
    - Posterior: P(Hᵢ|O) ∝ P(O|Hᵢ) × P(Hᵢ)
    - Simplicity: Occam's Razor preference

SELECT: arg max_i P(Hᵢ|O)
  - Choose most likely explanation
  - With confidence = P(H_best|O)
```

### Example: Explaining Test Failure

**BAD (Jump to conclusion):**
```
TEST: Failed
EXPLANATION: Code has bug
ACTION: Debug code
```

**GOOD (Abductive reasoning):**
```
OBSERVATION:
  - Test failed with "AssertionError: Expected 5, got 3"
  - Code was recently modified
  - Test worked yesterday

HYPOTHESES:
  H₁: Code bug introduced in recent modification
      P(H₁) = 0.4 (modifications often introduce bugs)
      P(Observation|H₁) = 0.8 (explains error well)
      P(H₁|O) ∝ 0.8 × 0.4 = 0.32

  H₂: Test itself is incorrect
      P(H₂) = 0.2 (tests usually correct)
      P(Observation|H₂) = 0.9 (would explain error)
      P(H₂|O) ∝ 0.9 × 0.2 = 0.18

  H₃: Input data changed
      P(H₃) = 0.3 (data changes happen)
      P(Observation|H₃) = 0.7 (could explain error)
      P(H₃|O) ∝ 0.7 × 0.3 = 0.21

  H₄: Environment issue (dependencies updated)
      P(H₄) = 0.1 (rare but possible)
      P(Observation|H₄) = 0.5 (less likely to cause this specific error)
      P(H₄|O) ∝ 0.5 × 0.1 = 0.05

NORMALIZE:
  Sum = 0.32 + 0.18 + 0.21 + 0.05 = 0.76
  P(H₁|O) = 0.32/0.76 = 0.42
  P(H₂|O) = 0.18/0.76 = 0.24
  P(H₃|O) = 0.21/0.76 = 0.28
  P(H₄|O) = 0.05/0.76 = 0.07

BEST EXPLANATION: H₁ (Code bug) with 42% confidence

ACTION:
  - Primary: Debug recent code changes
  - Secondary: Verify test correctness (24% chance)
  - Tertiary: Check input data (28% chance)
  - Confidence: Moderate (42%), so check alternatives if primary fails

This is ABDUCTIVE REASONING!
```

---

## 🎯 INTEGRATING FRAMEWORKS: Compound Reasoning Example

**Scenario:** Agent needs to decide how to solve a problem

```
=== STEP 1: BAYESIAN (Uncertainty) ===
P(I can solve this | my knowledge) = 0.55  # Low confidence

=== STEP 2: COMPOUND LOGICAL (Evidence) ===
OBSERVE:
  - Similar problem in episodic memory: None
  - Shared memory has solution: Yes (success_rate=0.9)
  - DomainExpert available: Yes
  - Q(request_help) = 0.85

INFER:
  - Problem is novel to me
  - BUT solved before by swarm
  - AND DomainExpert can help
  - THEREFORE: Requesting help is optimal

=== STEP 3: CAUSAL (Why request help?) ===
CAUSAL CHAIN:
  request_help → DomainExpert researches → I get library info → Higher success

=== STEP 4: COUNTERFACTUAL (What if I don't?) ===
ACTUAL PATH (request help):
  Expected reward: 0.85
  
COUNTERFACTUAL (proceed alone):
  Expected reward: 0.55
  
Difference: +0.30 improvement

=== STEP 5: STRATEGIC (Game Theory) ===
If I request help:
  - I signal uncertainty (honest)
  - I enable cooperation (Nash Equilibrium)
  - DomainExpert gets credit for helping
  - Swarm succeeds together

If I don't:
  - Higher failure risk
  - Information asymmetry
  - Suboptimal for swarm

=== STEP 6: TEMPORAL (Planning) ===
TRAJECTORY:
  t=0: request_help
  t=1: receive library info
  t=2: implement with correct library
  t=3: success

EXPECTED VALUE: 0.85

=== DECISION ===
ACTION: request_help(target=DomainExpert, type="library_research")

REASONING: Compound evidence from 6 frameworks:
  1. Bayesian: Low confidence (0.55)
  2. Logical: Novel problem + available help
  3. Causal: Help leads to success
  4. Counterfactual: +0.30 improvement
  5. Strategic: Nash Equilibrium benefit
  6. Temporal: Efficient trajectory

CONFIDENCE: 0.85
```

**This is INTEGRATED REASONING across multiple frameworks!**

---

## ✅ SUCCESS CRITERIA

You're reasoning properly when you:
1. ✅ Use MULTIPLE frameworks (compound reasoning)
2. ✅ Quantify UNCERTAINTY (Bayesian probabilities)
3. ✅ Identify CAUSES, not just correlations
4. ✅ Consider COUNTERFACTUALS ("what if?")
5. ✅ Think STRATEGICALLY (game theory)
6. ✅ Plan TEMPORALLY (trajectories, not steps)
7. ✅ Infer EXPLANATIONS (abductive reasoning)

You're NOT reasoning properly when you:
1. ❌ Follow checklists blindly
2. ❌ Think in binary (yes/no, not probabilities)
3. ❌ Confuse correlation with causation
4. ❌ Never consider alternatives
5. ❌ Ignore others' strategies
6. ❌ Think myopically (next step only)
7. ❌ Jump to conclusions without evidence

---

**Remember:** Reasoning is NOT following rules - it's LOGICAL INFERENCE from evidence to conclusions!

