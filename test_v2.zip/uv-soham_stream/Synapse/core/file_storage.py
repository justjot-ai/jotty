"""
🗄️ Tiered File Storage for Inter-Agent Communication
=====================================================

A-Team Approved: Enables large binary file transfer between agents.

Problem Solved:
- SmartAgentSlack loads all data into memory → fails for large files
- UnifiedChunker is TEXT-only → cannot process binary (WAV, images)
- No clean path mechanism for file references
- No lifecycle management for transferred files

Solution:
- FileReference: Path-independent reference using file_id
- TieredFileStorage: Manages storage lifecycle with 4 tiers
- Auto file mode for bytes data or files >1MB
- Background tier transitions with compression

Storage Tiers:
- HOT (0-1 day): Raw files, instant access
- WARM (1-7 days): Raw files, fast access
- COLD (7-30 days): Gzip compressed, medium access
- ARCHIVE (30+ days): Monthly tar.gz bundles, slow access

Usage:
    ```python
    storage = TieredFileStorage('/tmp/synapse_shared')
    
    # Save binary data
    ref = storage.save(
        data=audio_bytes,
        filename='speech.wav',
        content_type='audio/wav'
    )
    
    # Pass ref.file_id to other agents (not raw bytes!)
    
    # Receiver reads when needed
    data = storage.read_file(ref.file_id)
    ```

Author: A-Team
Date: February 2, 2026
ADR: docs/adr/tiered-file-storage-inter-agent-transfer.md
"""

import hashlib
import uuid
import time
import gzip
import tarfile
import os
import shutil
import json
import threading
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, Optional, Any, List
from enum import Enum
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


# =============================================================================
# ENUMS AND DATA STRUCTURES
# =============================================================================

class StorageTier(Enum):
    """Storage tiers with increasing latency and compression."""
    HOT = 'hot'        # 0-1 day, raw files, instant access
    WARM = 'warm'      # 1-7 days, raw files, fast access
    COLD = 'cold'      # 7-30 days, compressed (.gz), medium access
    ARCHIVE = 'archive'  # 30+ days, tar.gz bundles, slow access


@dataclass
class FileReference:
    """
    Reference to a file in shared storage.
    
    Uses file_id for path-independent referencing.
    Agents pass FileReference (or just file_id) instead of raw bytes.
    
    Attributes:
        file_id: UUID - primary identifier (path-independent)
        original_filename: Original filename for display
        content_type: MIME type (audio/wav, image/png, etc.)
        size_bytes: Original file size
        checksum: SHA256 for integrity verification
        created_at: Unix timestamp of creation
        tier: Current storage tier
        metadata: Additional metadata dict
        last_accessed: Unix timestamp of last access
        access_count: Number of times file was read
    """
    file_id: str
    original_filename: str
    content_type: str
    size_bytes: int
    checksum: str
    created_at: float
    tier: StorageTier = StorageTier.HOT
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Access tracking for smart tier management
    last_accessed: float = field(default_factory=time.time)
    access_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict for serialization."""
        return {
            'file_id': self.file_id,
            'original_filename': self.original_filename,
            'content_type': self.content_type,
            'size_bytes': self.size_bytes,
            'checksum': self.checksum,
            'created_at': self.created_at,
            'tier': self.tier.value,
            'metadata': self.metadata,
            'last_accessed': self.last_accessed,
            'access_count': self.access_count
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FileReference':
        """Create from dict."""
        return cls(
            file_id=data['file_id'],
            original_filename=data['original_filename'],
            content_type=data['content_type'],
            size_bytes=data['size_bytes'],
            checksum=data['checksum'],
            created_at=data['created_at'],
            tier=StorageTier(data.get('tier', 'hot')),
            metadata=data.get('metadata', {}),
            last_accessed=data.get('last_accessed', data['created_at']),
            access_count=data.get('access_count', 0)
        )
    
    def to_message_payload(self) -> Dict[str, Any]:
        """
        Convert to payload for inter-agent messaging.
        This is what gets sent via SmartAgentSlack instead of raw bytes.
        """
        return {
            'type': 'file_reference',
            'file_id': self.file_id,
            'filename': self.original_filename,
            'content_type': self.content_type,
            'size_bytes': self.size_bytes,
            'checksum': self.checksum
        }


# =============================================================================
# CONTENT TYPE DETECTION
# =============================================================================

class ContentTypeDetector:
    """
    Detect content type from binary data using magic numbers.
    
    Note: For more robust detection, consider python-magic library.
    This implementation covers common formats for agent communication.
    """
    
    # Magic number signatures: (bytes_prefix, content_type)
    SIGNATURES = [
        # Audio
        (b'RIFF', 'audio/wav'),
        (b'ID3', 'audio/mpeg'),
        (b'\xff\xfb', 'audio/mpeg'),  # MP3 frame sync
        (b'\xff\xfa', 'audio/mpeg'),
        (b'OggS', 'audio/ogg'),
        (b'fLaC', 'audio/flac'),
        
        # Images
        (b'\x89PNG\r\n\x1a\n', 'image/png'),
        (b'\xff\xd8\xff', 'image/jpeg'),
        (b'GIF87a', 'image/gif'),
        (b'GIF89a', 'image/gif'),
        (b'WEBP', 'image/webp'),
        (b'BM', 'image/bmp'),
        
        # Video
        (b'\x00\x00\x00\x1cftyp', 'video/mp4'),
        (b'\x00\x00\x00\x20ftyp', 'video/mp4'),
        (b'\x1aE\xdf\xa3', 'video/webm'),
        
        # Documents
        (b'%PDF', 'application/pdf'),
        (b'PK\x03\x04', 'application/zip'),
        (b'\x1f\x8b', 'application/gzip'),
        
        # Data
        (b'SQLite format', 'application/x-sqlite3'),
    ]
    
    @classmethod
    def detect(cls, data: bytes, filename: str = None) -> str:
        """
        Detect content type from binary data.
        
        Args:
            data: Binary data (at least first 32 bytes)
            filename: Optional filename for extension-based fallback
            
        Returns:
            MIME type string
        """
        # Try magic number detection first
        for signature, content_type in cls.SIGNATURES:
            if data.startswith(signature):
                return content_type
        
        # Check for RIFF-based formats (WAV, AVI, etc.)
        if len(data) >= 12 and data[:4] == b'RIFF':
            riff_type = data[8:12]
            if riff_type == b'WAVE':
                return 'audio/wav'
            elif riff_type == b'AVI ':
                return 'video/avi'
        
        # Check for WebP (RIFF with WEBP)
        if len(data) >= 12 and data[:4] == b'RIFF' and data[8:12] == b'WEBP':
            return 'image/webp'
        
        # Fallback to extension if provided
        if filename:
            ext_map = {
                '.wav': 'audio/wav',
                '.mp3': 'audio/mpeg',
                '.ogg': 'audio/ogg',
                '.flac': 'audio/flac',
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.bmp': 'image/bmp',
                '.mp4': 'video/mp4',
                '.webm': 'video/webm',
                '.pdf': 'application/pdf',
                '.json': 'application/json',
                '.txt': 'text/plain',
                '.csv': 'text/csv',
                '.html': 'text/html',
                '.xml': 'application/xml',
            }
            ext = Path(filename).suffix.lower()
            if ext in ext_map:
                return ext_map[ext]
        
        # Default for unknown binary
        return 'application/octet-stream'


# =============================================================================
# TIERED FILE STORAGE
# =============================================================================

class TieredFileStorage:
    """
    Tiered storage system for inter-agent file transfer.
    
    Features:
    - 4 storage tiers with automatic lifecycle management
    - File ID-based referencing (path-independent)
    - Transparent compression for cold/archive tiers
    - Access tracking for smart tier policies
    - Automatic cleanup of expired archives
    
    Tiers:
    - HOT: 0-1 day, raw files, instant access
    - WARM: 1-7 days, raw files, fast access
    - COLD: 7-30 days, gzip compressed, medium access
    - ARCHIVE: 30+ days, monthly tar.gz bundles, slow access
    """
    
    # Tier age thresholds in seconds
    TIER_THRESHOLDS = {
        StorageTier.HOT: 0,              # Immediate
        StorageTier.WARM: 86400,         # 1 day
        StorageTier.COLD: 604800,        # 7 days
        StorageTier.ARCHIVE: 2592000,    # 30 days
    }
    
    # Archive retention (1 year default)
    DEFAULT_ARCHIVE_RETENTION_DAYS = 365
    
    def __init__(self, base_path: str = '/tmp/synapse_shared'):
        """
        Initialize tiered storage.
        
        Args:
            base_path: Base directory for all storage tiers
        """
        self.base_path = Path(base_path)
        self._init_tier_directories()
        
        # File registry: file_id -> FileReference
        self.registry: Dict[str, FileReference] = {}
        
        # Path index: file_id -> current physical path
        self.path_index: Dict[str, Path] = {}
        
        # Thread lock for concurrent access
        self._lock = threading.RLock()
        
        # Load existing registry if present
        self._load_registry()
        
        logger.info(f'📁 [TIERED STORAGE] Initialized at {self.base_path}')
    
    def _init_tier_directories(self):
        """Create tier directories."""
        for tier in StorageTier:
            tier_path = self.base_path / tier.value
            tier_path.mkdir(parents=True, exist_ok=True)
        
        # Also create registry directory
        registry_path = self.base_path / '.registry'
        registry_path.mkdir(parents=True, exist_ok=True)
    
    def _get_registry_path(self) -> Path:
        """Get path to registry JSON file."""
        return self.base_path / '.registry' / 'files.json'
    
    def _load_registry(self):
        """Load registry from disk."""
        registry_path = self._get_registry_path()
        if registry_path.exists():
            try:
                with open(registry_path, 'r') as f:
                    data = json.load(f)
                
                for file_id, ref_data in data.get('files', {}).items():
                    self.registry[file_id] = FileReference.from_dict(ref_data)
                
                for file_id, path_str in data.get('paths', {}).items():
                    self.path_index[file_id] = Path(path_str)
                
                logger.info(f'📁 [STORAGE] Loaded {len(self.registry)} files from registry')
            except Exception as e:
                logger.warning(f'📁 [STORAGE] Failed to load registry: {e}')
    
    def _save_registry(self):
        """Persist registry to disk."""
        registry_path = self._get_registry_path()
        try:
            data = {
                'files': {fid: ref.to_dict() for fid, ref in self.registry.items()},
                'paths': {fid: str(path) for fid, path in self.path_index.items()}
            }
            with open(registry_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f'📁 [STORAGE] Failed to save registry: {e}')
    
    def save(
        self,
        data: bytes,
        filename: str,
        content_type: str = None,
        metadata: Dict = None
    ) -> FileReference:
        """
        Save file to hot tier and return reference.
        
        Args:
            data: Binary data to save
            filename: Original filename
            content_type: MIME type (auto-detected if not provided)
            metadata: Optional metadata dict
            
        Returns:
            FileReference for the saved file
        """
        with self._lock:
            file_id = str(uuid.uuid4())
            checksum = hashlib.sha256(data).hexdigest()
            
            # Auto-detect content type if not provided
            if content_type is None:
                content_type = ContentTypeDetector.detect(data, filename)
            
            # Save to hot tier
            safe_filename = self._sanitize_filename(filename)
            physical_path = self.base_path / 'hot' / f'{file_id}_{safe_filename}'
            
            with open(physical_path, 'wb') as f:
                f.write(data)
            
            # Create reference
            ref = FileReference(
                file_id=file_id,
                original_filename=filename,
                content_type=content_type,
                size_bytes=len(data),
                checksum=checksum,
                created_at=time.time(),
                tier=StorageTier.HOT,
                metadata=metadata or {}
            )
            
            # Register
            self.registry[file_id] = ref
            self.path_index[file_id] = physical_path
            
            # Persist registry
            self._save_registry()
            
            logger.info(f'📁 [STORAGE] Saved {filename} ({len(data):,} bytes) -> {file_id[:8]}...')
            return ref
    
    def save_from_path(
        self,
        source_path: str,
        content_type: str = None,
        metadata: Dict = None
    ) -> FileReference:
        """
        Save file from disk path (avoids loading into memory for very large files).
        
        Args:
            source_path: Path to source file
            content_type: MIME type (auto-detected if not provided)
            metadata: Optional metadata dict
            
        Returns:
            FileReference for the saved file
        """
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f'Source file not found: {source_path}')
        
        with self._lock:
            file_id = str(uuid.uuid4())
            
            # Calculate checksum by streaming
            sha256 = hashlib.sha256()
            size = 0
            with open(source, 'rb') as f:
                for chunk in iter(lambda: f.read(65536), b''):
                    sha256.update(chunk)
                    size += len(chunk)
            checksum = sha256.hexdigest()
            
            # Auto-detect content type
            if content_type is None:
                with open(source, 'rb') as f:
                    header = f.read(32)
                content_type = ContentTypeDetector.detect(header, source.name)
            
            # Copy to hot tier
            safe_filename = self._sanitize_filename(source.name)
            physical_path = self.base_path / 'hot' / f'{file_id}_{safe_filename}'
            shutil.copy2(source, physical_path)
            
            # Create reference
            ref = FileReference(
                file_id=file_id,
                original_filename=source.name,
                content_type=content_type,
                size_bytes=size,
                checksum=checksum,
                created_at=time.time(),
                tier=StorageTier.HOT,
                metadata=metadata or {}
            )
            
            # Register
            self.registry[file_id] = ref
            self.path_index[file_id] = physical_path
            self._save_registry()
            
            logger.info(f'📁 [STORAGE] Saved {source.name} ({size:,} bytes) -> {file_id[:8]}...')
            return ref
    
    def get_reference(self, file_id: str) -> Optional[FileReference]:
        """Get file reference by ID."""
        return self.registry.get(file_id)
    
    def resolve_path(self, file_id: str) -> Optional[Path]:
        """Resolve file_id to current physical path."""
        return self.path_index.get(file_id)
    
    def read_file(self, file_id: str, verify_checksum: bool = False) -> Optional[bytes]:
        """
        Read file by ID, handling compression transparently.
        
        Args:
            file_id: File identifier
            verify_checksum: If True, verify SHA256 after reading
            
        Returns:
            File contents as bytes, or None if not found
        """
        with self._lock:
            ref = self.registry.get(file_id)
            if not ref:
                logger.warning(f'📁 [STORAGE] File not found: {file_id}')
                return None
            
            path = self.path_index.get(file_id)
            if not path or not path.exists():
                logger.error(f'📁 [STORAGE] Physical path missing: {file_id}')
                return None
            
            # Update access tracking
            ref.last_accessed = time.time()
            ref.access_count += 1
            
            # Read based on tier (handle compression)
            try:
                if ref.tier == StorageTier.COLD:
                    # Gzip compressed
                    with gzip.open(path, 'rb') as f:
                        data = f.read()
                elif ref.tier == StorageTier.ARCHIVE:
                    # Tar.gz archive
                    data = self._read_from_archive(ref, path)
                else:
                    # Raw file (HOT or WARM)
                    with open(path, 'rb') as f:
                        data = f.read()
                
                # Verify checksum if requested
                if verify_checksum and data:
                    actual_checksum = hashlib.sha256(data).hexdigest()
                    if actual_checksum != ref.checksum:
                        logger.error(f'📁 [STORAGE] Checksum mismatch for {file_id}!')
                        return None
                
                logger.debug(f'📁 [STORAGE] Read {file_id[:8]}... ({len(data):,} bytes)')
                return data
                
            except Exception as e:
                logger.error(f'📁 [STORAGE] Failed to read {file_id}: {e}')
                return None
    
    def exists(self, file_id: str) -> bool:
        """Check if file exists in storage."""
        if file_id not in self.registry:
            return False
        path = self.path_index.get(file_id)
        return path is not None and path.exists()
    
    def delete(self, file_id: str) -> bool:
        """
        Delete file from storage.
        
        Args:
            file_id: File identifier
            
        Returns:
            True if deleted, False if not found
        """
        with self._lock:
            if file_id not in self.registry:
                return False
            
            path = self.path_index.get(file_id)
            if path and path.exists():
                try:
                    path.unlink()
                except Exception as e:
                    logger.warning(f'📁 [STORAGE] Failed to delete file: {e}')
            
            del self.registry[file_id]
            if file_id in self.path_index:
                del self.path_index[file_id]
            
            self._save_registry()
            logger.info(f'📁 [STORAGE] Deleted {file_id[:8]}...')
            return True
    
    def run_tier_transition(self):
        """
        Move files between tiers based on age.
        
        Call this periodically (e.g., every hour via background task or after task completion).
        """
        with self._lock:
            now = time.time()
            transitions = []
            
            for file_id, ref in list(self.registry.items()):
                age = now - ref.created_at
                
                # Determine target tier based on age
                target_tier = self._get_tier_for_age(age)
                
                if target_tier != ref.tier:
                    transitions.append((file_id, ref.tier, target_tier))
            
            # Execute transitions
            for file_id, from_tier, to_tier in transitions:
                try:
                    self._transition_file(file_id, from_tier, to_tier)
                except Exception as e:
                    logger.error(f'📁 [STORAGE] Transition failed for {file_id}: {e}')
            
            if transitions:
                logger.info(f'📁 [STORAGE] Transitioned {len(transitions)} files')
                self._save_registry()
    
    def _get_tier_for_age(self, age_seconds: float) -> StorageTier:
        """Determine tier based on file age."""
        if age_seconds >= self.TIER_THRESHOLDS[StorageTier.ARCHIVE]:
            return StorageTier.ARCHIVE
        elif age_seconds >= self.TIER_THRESHOLDS[StorageTier.COLD]:
            return StorageTier.COLD
        elif age_seconds >= self.TIER_THRESHOLDS[StorageTier.WARM]:
            return StorageTier.WARM
        else:
            return StorageTier.HOT
    
    def _transition_file(self, file_id: str, from_tier: StorageTier, to_tier: StorageTier):
        """Move file between tiers."""
        ref = self.registry.get(file_id)
        if not ref:
            return
        
        old_path = self.path_index.get(file_id)
        if not old_path or not old_path.exists():
            return
        
        logger.info(f'📁 [STORAGE] Transitioning {file_id[:8]}...: {from_tier.value} -> {to_tier.value}')
        
        if to_tier == StorageTier.COLD:
            # Compress with gzip
            new_path = self.base_path / 'cold' / f'{file_id}.gz'
            
            # Handle case where source might already be compressed
            if from_tier == StorageTier.COLD:
                # Already compressed, just move
                shutil.move(str(old_path), str(new_path))
            else:
                # Compress raw file
                with open(old_path, 'rb') as f_in:
                    with gzip.open(new_path, 'wb', compresslevel=6) as f_out:
                        shutil.copyfileobj(f_in, f_out)
                old_path.unlink()
            
        elif to_tier == StorageTier.ARCHIVE:
            # Add to monthly tar.gz archive
            new_path = self._add_to_archive(ref, old_path)
            if old_path.exists():
                old_path.unlink()
            
        elif to_tier == StorageTier.WARM:
            # Simple move (HOT -> WARM)
            new_path = self.base_path / 'warm' / old_path.name
            shutil.move(str(old_path), str(new_path))
            
        else:
            # HOT (shouldn't happen in normal flow)
            new_path = self.base_path / 'hot' / old_path.name
            shutil.move(str(old_path), str(new_path))
        
        # Update registry
        ref.tier = to_tier
        self.path_index[file_id] = new_path
    
    def _add_to_archive(self, ref: FileReference, source_path: Path) -> Path:
        """Add file to monthly archive bundle."""
        dt = datetime.fromtimestamp(ref.created_at)
        archive_dir = self.base_path / 'archive' / str(dt.year) / f'{dt.month:02d}'
        archive_dir.mkdir(parents=True, exist_ok=True)
        
        archive_path = archive_dir / f'{dt.year}_{dt.month:02d}_files.tar.gz'
        
        # Archive member name
        member_name = f'{ref.file_id}_{ref.original_filename}'
        
        # If source is gzipped, decompress first
        if source_path.suffix == '.gz':
            with gzip.open(source_path, 'rb') as f:
                temp_data = f.read()
            # Write to temp file for tarfile
            temp_path = source_path.with_suffix('')
            with open(temp_path, 'wb') as f:
                f.write(temp_data)
            source_to_add = temp_path
            cleanup_temp = True
        else:
            source_to_add = source_path
            cleanup_temp = False
        
        # Append to existing archive or create new
        mode = 'a:gz' if archive_path.exists() else 'w:gz'
        try:
            with tarfile.open(archive_path, mode) as tar:
                tar.add(source_to_add, arcname=member_name)
        finally:
            if cleanup_temp and source_to_add.exists():
                source_to_add.unlink()
        
        return archive_path
    
    def _read_from_archive(self, ref: FileReference, archive_path: Path) -> Optional[bytes]:
        """Read file from tar.gz archive."""
        if not archive_path.exists():
            return None
        
        target_name = f'{ref.file_id}_{ref.original_filename}'
        
        try:
            with tarfile.open(archive_path, 'r:gz') as tar:
                for member in tar.getmembers():
                    if target_name in member.name:
                        f = tar.extractfile(member)
                        if f:
                            return f.read()
        except Exception as e:
            logger.error(f'📁 [STORAGE] Failed to read from archive: {e}')
        
        return None
    
    def cleanup_expired(self, max_archive_age_days: int = None):
        """
        Remove archives older than max age.
        
        Args:
            max_archive_age_days: Max age in days (default: 365)
        """
        if max_archive_age_days is None:
            max_archive_age_days = self.DEFAULT_ARCHIVE_RETENTION_DAYS
        
        cutoff = datetime.now() - timedelta(days=max_archive_age_days)
        
        archive_base = self.base_path / 'archive'
        if not archive_base.exists():
            return
        
        removed_count = 0
        for year_dir in archive_base.iterdir():
            if not year_dir.is_dir():
                continue
            try:
                year = int(year_dir.name)
                if year < cutoff.year:
                    # Remove entire year
                    shutil.rmtree(year_dir)
                    logger.info(f'📁 [STORAGE] Removed archive year: {year}')
                    removed_count += 1
                elif year == cutoff.year:
                    # Check month directories
                    for month_dir in year_dir.iterdir():
                        if not month_dir.is_dir():
                            continue
                        try:
                            month = int(month_dir.name)
                            if month < cutoff.month:
                                shutil.rmtree(month_dir)
                                logger.info(f'📁 [STORAGE] Removed archive: {year}/{month:02d}')
                                removed_count += 1
                        except ValueError:
                            pass
            except ValueError:
                pass
        
        if removed_count > 0:
            # Clean up registry entries for deleted files
            self._cleanup_orphaned_registry_entries()
    
    def _cleanup_orphaned_registry_entries(self):
        """Remove registry entries for files that no longer exist."""
        orphaned = []
        for file_id, path in list(self.path_index.items()):
            if not path.exists():
                orphaned.append(file_id)
        
        for file_id in orphaned:
            if file_id in self.registry:
                del self.registry[file_id]
            if file_id in self.path_index:
                del self.path_index[file_id]
        
        if orphaned:
            logger.info(f'📁 [STORAGE] Cleaned up {len(orphaned)} orphaned entries')
            self._save_registry()
    
    def _sanitize_filename(self, filename: str) -> str:
        """Remove dangerous characters from filename."""
        # Remove path traversal attempts
        safe = filename.replace('..', '').replace('/', '_').replace('\\', '_')
        # Remove null bytes
        safe = safe.replace('\x00', '')
        # Limit length
        return safe[:100]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        stats = {tier.value: {'count': 0, 'size_bytes': 0} for tier in StorageTier}
        
        for ref in self.registry.values():
            stats[ref.tier.value]['count'] += 1
            stats[ref.tier.value]['size_bytes'] += ref.size_bytes
        
        # Calculate disk usage
        total_disk_usage = 0
        for tier in StorageTier:
            tier_path = self.base_path / tier.value
            if tier_path.exists():
                for f in tier_path.rglob('*'):
                    if f.is_file():
                        total_disk_usage += f.stat().st_size
        
        return {
            'total_files': len(self.registry),
            'tiers': stats,
            'disk_usage_bytes': total_disk_usage,
            'base_path': str(self.base_path)
        }
    
    def __repr__(self) -> str:
        stats = self.get_stats()
        return f"TieredFileStorage(path={stats['base_path']}, files={stats['total_files']})"


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def is_binary_content_type(content_type: str) -> bool:
    """
    Check if content type is binary (not text-based).
    
    Used to determine if UnifiedChunker should be skipped.
    """
    # Text-based types that CAN be chunked
    text_types = {
        'text/',
        'application/json',
        'application/xml',
        'application/javascript',
        'application/x-yaml',
        'application/x-www-form-urlencoded',
    }
    
    if content_type is None:
        return True  # Assume binary if unknown
    
    ct_lower = content_type.lower()
    
    for text_type in text_types:
        if ct_lower.startswith(text_type):
            return False
    
    # Everything else is binary
    return True


def should_use_file_mode(data: Any, size_bytes: int, threshold: int = 1_000_000) -> bool:
    """
    Determine if file mode should be used for data transfer.
    
    File mode means:
    - Save to TieredFileStorage
    - Send FileReference instead of raw data
    - Skip UnifiedChunker (which is TEXT ONLY)
    
    Args:
        data: The data being sent
        size_bytes: Estimated size in bytes
        threshold: Size threshold (default 1MB)
        
    Returns:
        True if file mode should be used
    """
    # Binary data always uses file mode
    if isinstance(data, bytes):
        return True
    
    # Large data uses file mode
    if size_bytes > threshold:
        return True
    
    return False
