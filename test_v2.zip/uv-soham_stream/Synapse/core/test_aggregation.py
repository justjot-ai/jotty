"""
Test Result Aggregation - A-Team Consensus Implementation
==========================================================

Aggregates parallel test results into a single reward score.

A-Team Consensus: Hybrid Approach
- Primary: LLM-based semantic aggregation
- Fallback: Bayesian aggregation with learned priors
- Bootstrap: Priority-weighted average

Mathematical Guarantees:
1. Monotonicity: More tests passed → higher reward
2. Criticality: Critical test failure → reward < 0.5
3. Convergence: Bayesian posterior converges to true quality

A-Team Approval:
- Dr. Manning: ✅ (semantic aggregation)
- Dr. Sutton: ✅ (Bayesian framework)
- Dr. Abbeel: ✅ (learning from data)
- Dr. Finn: ✅ (task-conditioned)
- Shannon: ✅ (information weighting)
- Von Neumann: ✅ (failure-mode aware)
- Dr. Silver: ✅ (uncertainty quantification)
"""

import logging
import numpy as np
from typing import List, Dict, Any, Optional, AsyncGenerator
from dataclasses import dataclass
from collections import defaultdict

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class AggregatedResult:
    """Result of test aggregation."""
    reward: float  # [0, 1]
    confidence: float  # [0, 1]
    reasoning: str
    method: str  # Which aggregation method was used
    test_breakdown: Optional[List[Dict]] = None  # Individual test results


# =============================================================================
# LLM-BASED SEMANTIC AGGREGATION (Dr. Manning's Proposal)
# =============================================================================

class SemanticAggregationSignature(dspy.Signature):
    """Aggregate test results semantically, considering relationships between tests."""
    
    test_results = dspy.InputField(
        desc="""Test results with outcomes and descriptions. Format:
        [
            {"name": "test1", "passed": true/false, "priority": "critical/high/medium/low", "description": "..."},
            ...
        ]
        """
    )
    task_description = dspy.InputField(desc="What task was being validated")
    
    quality_score = dspy.OutputField(
        desc="Overall quality score [0.0 to 1.0]. Consider semantic relationships between tests. "
             "If Test A depends on Test B, weight accordingly."
    )
    confidence = dspy.OutputField(
        desc="Confidence in quality estimate [0.0 to 1.0]. Higher if test results are consistent."
    )
    reasoning = dspy.OutputField(
        desc="Explain how you aggregated the test results. Mention any test correlations or dependencies."
    )


class SemanticTestAggregator:
    """
    LLM-based semantic test aggregation.
    
    Dr. Manning: "Tests are not numbers. They have meaning."
    """
    
    def __init__(self, lm=None):
        if not DSPY_AVAILABLE:
            logger.warning("DSPy not available, SemanticTestAggregator will not work")
            self.aggregator = None
        else:
            self.aggregator = dspy.ChainOfThought(SemanticAggregationSignature)
    
    async def aggregate_stream(
        self,
        test_results: List[Dict],
        task_description: str
    ) -> AsyncGenerator[Dict[str, Any], AggregatedResult]:
        """
        Aggregate tests semantically using LLM.
        
        Args:
            test_results: List of test dicts
            task_description: What was being tested
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            AggregatedResult with quality score, confidence, reasoning
        
        Raises:
            RuntimeError: If LLM is not available
        """
        yield {"module": "Synapse.core.test_aggregation", "message": f"I am aggregating {len(test_results)} test results using LLM semantic analysis"}
        if not self.aggregator:
            yield {"module": "Synapse.core.test_aggregation", "message": "I noticed DSPy is not available, cannot perform semantic aggregation"}
            raise RuntimeError("SemanticTestAggregator requires DSPy")
        
        # Format test results for LLM
        test_summary = self._format_tests(test_results)
        yield {"module": "Synapse.core.test_aggregation", "message": "I formatted the test results for LLM analysis"}
        
        try:
            yield {"module": "Synapse.core.test_aggregation", "message": "I am calling the LLM to perform semantic aggregation"}
            result = self.aggregator(
                test_results=test_summary,
                task_description=task_description
            )
            
            # Parse outputs
            quality = self._parse_score(result.quality_score)
            confidence = self._parse_score(result.confidence)
            
            yield {"module": "Synapse.core.test_aggregation", "message": f"I parsed the LLM results: quality={quality:.3f}, confidence={confidence:.3f}"}
            aggregated_result = AggregatedResult(
                reward=quality,
                confidence=confidence,
                reasoning=result.reasoning,
                method='llm_semantic',
                test_breakdown=test_results
            )
            yield {"type": "result", "result": aggregated_result}
            return
        
        except Exception as e:
            logger.error(f"Semantic aggregation failed: {e}")
            yield {"module": "Synapse.core.test_aggregation", "message": f"I encountered an error during semantic aggregation: {e}"}
            raise RuntimeError(f"LLM aggregation failed: {e}")
    
    def aggregate(
        self,
        test_results: List[Dict],
        task_description: str
    ) -> AggregatedResult:
        """Synchronous wrapper for aggregate_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use aggregate_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.aggregate_stream(test_results, task_description):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_aggregate(test_results, task_description))
    
    async def _sync_aggregate(self, test_results: List[Dict], task_description: str) -> AggregatedResult:
        """Helper for sync wrapper."""
        result = None
        async for event in self.aggregate_stream(test_results, task_description):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else AggregatedResult(reward=0.5, confidence=0.0, reasoning="No result", method="error")
    
    def _format_tests(self, test_results: List[Dict]) -> str:
        """Format test results for LLM."""
        lines = []
        for i, test in enumerate(test_results, 1):
            status = "PASS" if test.get('passed', False) else "FAIL"
            priority = test.get('priority', 'medium').upper()
            name = test.get('name', f'test_{i}')
            desc = test.get('description', test.get('expected_output', ''))
            
            lines.append(f"{i}. [{priority}] {name}: {status}")
            if desc:
                lines.append(f"   Description: {desc[:100]}")
        
        return "\n".join(lines)
    
    def _parse_score(self, score_str: str) -> float:
        """Parse score from LLM output."""
        try:
            # Try direct float conversion
            score = float(score_str)
            return max(0.0, min(1.0, score))
        except ValueError:
            # Try extracting first number
            import re
            match = re.search(r'(\d+\.?\d*)', score_str)
            if match:
                score = float(match.group(1))
                # If score > 1, assume it's out of 10
                if score > 1.0:
                    score = score / 10.0
                return max(0.0, min(1.0, score))
            else:
                logger.warning(f"Could not parse score: {score_str}, defaulting to 0.5")
                return 0.5


# =============================================================================
# BAYESIAN AGGREGATION (Dr. Sutton's Proposal)
# =============================================================================

class BayesianTestAggregator:
    """
    Bayesian aggregation with learned test-quality relationships.
    
    Dr. Sutton: "Model test correlations explicitly."
    """
    
    def __init__(self):
        # Test-specific statistics
        self.test_pass_counts = defaultdict(int)  # test_name -> pass_count
        self.test_total_counts = defaultdict(int)  # test_name -> total_count
        self.test_quality_correlation = defaultdict(list)  # test_name -> [qualities when test passed]
        
        # Episode count for deciding when to use Bayesian
        self.episode_count = 0
    
    def record_episode(self, test_results: List[Dict], final_quality: float):
        """
        Record an episode for learning.
        
        Args:
            test_results: Test outcomes
            final_quality: Ground truth quality (from user feedback or downstream success)
        """
        self.episode_count += 1
        
        for test in test_results:
            name = test.get('name', 'unknown')
            passed = test.get('passed', False)
            
            self.test_total_counts[name] += 1
            if passed:
                self.test_pass_counts[name] += 1
                self.test_quality_correlation[name].append(final_quality)
    
    async def aggregate_stream(self, test_results: List[Dict]) -> AsyncGenerator[Dict[str, Any], AggregatedResult]:
        """
        Bayesian aggregation using learned priors.
        
        Args:
            test_results: Test outcomes
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            AggregatedResult with Bayesian quality estimate
        
        Raises:
            RuntimeError: If not enough data to use Bayesian method
        """
        yield {"module": "Synapse.core.test_aggregation", "message": f"I am performing Bayesian aggregation on {len(test_results)} test results"}
        if self.episode_count < 10:
            yield {"module": "Synapse.core.test_aggregation", "message": f"I need at least 10 episodes for Bayesian aggregation, but only have {self.episode_count}"}
            raise RuntimeError(
                f"Not enough data for Bayesian aggregation (need 10 episodes, have {self.episode_count})"
            )
        
        yield {"module": "Synapse.core.test_aggregation", "message": f"I have sufficient data ({self.episode_count} episodes) for Bayesian aggregation"}
        
        # Bayesian posterior: P(quality | test_results)
        # We approximate this as a weighted average where weights are test reliabilities
        
        total_weight = 0.0
        weighted_sum = 0.0
        
        yield {"module": "Synapse.core.test_aggregation", "message": "I am computing test reliabilities and weighted quality estimates"}
        for test in test_results:
            name = test.get('name', 'unknown')
            passed = test.get('passed', False)
            
            # Test reliability: how well does this test predict quality?
            if name in self.test_quality_correlation and self.test_quality_correlation[name]:
                # Average quality when this test passed
                avg_quality_when_passed = np.mean(self.test_quality_correlation[name])
                # Test pass rate (entropy proxy)
                pass_rate = self.test_pass_counts[name] / max(1, self.test_total_counts[name])
                # Reliability: high if test is discriminative (pass_rate not 0 or 1)
                entropy = -pass_rate * np.log2(pass_rate + 1e-10) - (1 - pass_rate) * np.log2(1 - pass_rate + 1e-10)
                reliability = entropy  # Max at 0.5, min at 0 or 1
            else:
                # No history for this test, use neutral values
                avg_quality_when_passed = 0.5
                reliability = 0.5
            
            # Weight by reliability
            weight = reliability
            total_weight += weight
            
            # If test passed, expect avg_quality_when_passed, else expect lower
            if passed:
                weighted_sum += weight * avg_quality_when_passed
            else:
                weighted_sum += weight * (1.0 - avg_quality_when_passed)
        
        if total_weight == 0:
            quality = 0.5
            confidence = 0.0
        else:
            quality = weighted_sum / total_weight
            # Confidence: how consistent are test reliabilities?
            weights = [entropy for name, entropy in [(t.get('name', ''), 0.5) for t in test_results]]
            confidence = 1.0 - np.std(weights) if len(weights) > 1 else 0.5
        
        yield {"module": "Synapse.core.test_aggregation", "message": f"I computed Bayesian aggregation: quality={quality:.3f}, confidence={confidence:.3f}"}
        result = AggregatedResult(
            reward=max(0.0, min(1.0, quality)),
            confidence=max(0.0, min(1.0, confidence)),
            reasoning=f"Bayesian aggregation from {self.episode_count} episodes of learning",
            method='bayesian_learned',
            test_breakdown=test_results
        )
        yield {"type": "result", "result": result}
        return
    
    def aggregate(self, test_results: List[Dict]) -> AggregatedResult:
        """Synchronous wrapper for aggregate_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use aggregate_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.aggregate_stream(test_results):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_bayesian_aggregate(test_results))
    
    async def _sync_bayesian_aggregate(self, test_results: List[Dict]) -> AggregatedResult:
        """Helper for sync wrapper."""
        result = None
        async for event in self.aggregate_stream(test_results):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else AggregatedResult(reward=0.5, confidence=0.0, reasoning="No result", method="error")


# =============================================================================
# BOOTSTRAP WEIGHTED AVERAGE (Fallback)
# =============================================================================

def bootstrap_aggregate(test_results: List[Dict]) -> AggregatedResult:
    """
    Priority-weighted average (better than naive 60/40).
    
    This is the fallback when LLM and Bayesian are not available.
    """
    if not test_results:
        return AggregatedResult(
            reward=0.5,
            confidence=0.0,
            reasoning='No tests provided',
            method='bootstrap_empty',
            test_breakdown=[]
        )
    
    # Priority weights (more principled than hardcoded 60/40)
    priority_weights = {
        'critical': 1.0,
        'high': 0.7,
        'medium': 0.4,
        'low': 0.2
    }
    
    total_weight = 0.0
    weighted_sum = 0.0
    
    for test in test_results:
        priority = test.get('priority', 'medium')
        weight = priority_weights.get(priority, 0.5)
        outcome = 1.0 if test.get('passed', False) else 0.0
        
        weighted_sum += weight * outcome
        total_weight += weight
    
    reward = weighted_sum / total_weight if total_weight > 0 else 0.5
    
    # 🎯 VON NEUMANN FIX: Critical test failure must dominate
    # For large n, weighted average might not enforce reward < 0.5
    # Explicit check ensures critical failures are never ignored
    critical_tests = [t for t in test_results if t.get('priority') == 'critical']
    critical_failed = [t for t in critical_tests if not t.get('passed', False)]
    
    if critical_failed:
        # Cap reward at 0.4 for any critical failure (below neutral 0.5)
        reward = min(reward, 0.4)
        logger.info(f"⚠️  Critical test failure detected, capping reward at 0.4 (was {reward:.3f})")
    
    # Confidence: how consistent are test outcomes?
    outcomes = [1.0 if t.get('passed', False) else 0.0 for t in test_results]
    confidence = 1.0 - np.std(outcomes) if len(outcomes) > 1 else 0.5
    
    return AggregatedResult(
        reward=reward,
        confidence=confidence,
        reasoning=f'Priority-weighted average of {len(test_results)} tests'
                  + (f' (critical failure cap applied)' if critical_failed else ''),
        method='bootstrap_weighted',
        test_breakdown=test_results
    )


# =============================================================================
# HYBRID AGGREGATOR (A-Team Consensus)
# =============================================================================

class HybridTestAggregator:
    """
    A-Team Consensus Implementation.
    
    Tries methods in order:
    1. LLM-based semantic aggregation (most powerful)
    2. Bayesian aggregation with learned priors (if enough data)
    3. Bootstrap weighted average (fallback)
    """
    
    def __init__(self, config: 'SynapseConfig'):
        self.config = config
        self.semantic_aggregator = SemanticTestAggregator()
        self.bayesian_aggregator = BayesianTestAggregator()
        
        # Config flags
        self.enable_llm = getattr(config, 'enable_llm_test_aggregation', True)
        self.enable_bayesian = getattr(config, 'enable_bayesian_test_aggregation', True)
        
        logger.info(
            f"✅ HybridTestAggregator initialized | "
            f"llm={self.enable_llm} | bayesian={self.enable_bayesian}"
        )
    
    async def aggregate_stream(
        self,
        test_results: List[Dict],
        task_description: str,
        task_type: Optional[str] = None
    ) -> AsyncGenerator[Dict[str, Any], AggregatedResult]:
        """
        Aggregate parallel test results into a single reward.
        
        Args:
            test_results: List of test dicts with 'passed', 'priority', 'name', etc.
            task_description: Semantic description of task
            task_type: Type of task (for task-conditioned aggregation, future work)
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            AggregatedResult with reward, confidence, reasoning, method
        """
        yield {"module": "Synapse.core.test_aggregation", "message": f"I am starting hybrid test aggregation for {len(test_results)} test results"}
        # STAGE 1: Try LLM-based semantic aggregation (most powerful)
        if self.enable_llm and DSPY_AVAILABLE:
            try:
                yield {"module": "Synapse.core.test_aggregation", "message": "I am trying LLM-based semantic aggregation first"}
                result = None
                async for event in self.semantic_aggregator.aggregate_stream(test_results, task_description):
                    yield event
                    if event.get("type") == "result":
                        result = event.get("result")
                if result:
                    logger.info(
                        f"✅ Test aggregation (LLM): reward={result.reward:.3f}, "
                        f"confidence={result.confidence:.3f}"
                    )
                    yield {"type": "result", "result": result}
                    return
            except Exception as e:
                logger.warning(f"⚠️  LLM aggregation failed: {e}, falling back to Bayesian")
                yield {"module": "Synapse.core.test_aggregation", "message": f"I encountered an error with LLM aggregation: {e}, falling back to Bayesian"}
        
        # STAGE 2: Bayesian aggregation (if enough history)
        if self.enable_bayesian:
            try:
                yield {"module": "Synapse.core.test_aggregation", "message": "I am trying Bayesian aggregation"}
                result = None
                async for event in self.bayesian_aggregator.aggregate_stream(test_results):
                    yield event
                    if event.get("type") == "result":
                        result = event.get("result")
                if result:
                    logger.info(
                        f"✅ Test aggregation (Bayesian): reward={result.reward:.3f}, "
                        f"confidence={result.confidence:.3f}"
                    )
                    yield {"type": "result", "result": result}
                    return
            except Exception as e:
                logger.debug(f"Bayesian aggregation not available: {e}, using bootstrap")
                yield {"module": "Synapse.core.test_aggregation", "message": f"I cannot use Bayesian aggregation: {e}, using bootstrap"}
        
        # STAGE 3: Bootstrap with priority-weighted average
        yield {"module": "Synapse.core.test_aggregation", "message": "I am using bootstrap priority-weighted average aggregation"}
        result = bootstrap_aggregate(test_results)
        logger.info(
            f"✅ Test aggregation (Bootstrap): reward={result.reward:.3f}, "
            f"confidence={result.confidence:.3f}"
        )
        yield {"module": "Synapse.core.test_aggregation", "message": f"I completed bootstrap aggregation: reward={result.reward:.3f}, confidence={result.confidence:.3f}"}
        yield {"type": "result", "result": result}
        return
    
    def aggregate(
        self,
        test_results: List[Dict],
        task_description: str,
        task_type: Optional[str] = None
    ) -> AggregatedResult:
        """Synchronous wrapper for aggregate_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use aggregate_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.aggregate_stream(test_results, task_description, task_type):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_hybrid_aggregate(test_results, task_description, task_type))
    
    async def _sync_hybrid_aggregate(
        self,
        test_results: List[Dict],
        task_description: str,
        task_type: Optional[str] = None
    ) -> AggregatedResult:
        """Helper for sync wrapper."""
        result = None
        async for event in self.aggregate_stream(test_results, task_description, task_type):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else bootstrap_aggregate(test_results)
    
    def record_episode(self, test_results: List[Dict], final_quality: float):
        """
        Record episode for Bayesian learning.
        
        Args:
            test_results: Test outcomes from episode
            final_quality: Ground truth quality (user feedback or downstream success)
        """
        if self.enable_bayesian:
            self.bayesian_aggregator.record_episode(test_results, final_quality)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get aggregator statistics."""
        return {
            'episode_count': self.bayesian_aggregator.episode_count,
            'learned_tests': len(self.bayesian_aggregator.test_quality_correlation),
            'methods_available': {
                'llm_semantic': self.enable_llm and DSPY_AVAILABLE,
                'bayesian': self.enable_bayesian and self.bayesian_aggregator.episode_count >= 10,
                'bootstrap': True
            }
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'HybridTestAggregator',
    'AggregatedResult',
    'SemanticTestAggregator',
    'BayesianTestAggregator',
    'bootstrap_aggregate'
]
