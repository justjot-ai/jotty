"""
Agent Collaboration Mixin - Inter-Agent Communication During ReAct Execution
=============================================================================

Provides agents with the ability to store and access collaboration context
injected by the Conductor during _execute_actor. This enables agents to:
1. Know about other available agents (via agent_directory)
2. Access the communication channel (via agent_slack / SmartAgentSlack)
3. Track pending messages from other agents

🔴 A-TEAM PRINCIPLE: No hardcoding of agent names or capabilities.
All collaboration decisions are LLM-driven via the Conductor.

This mixin is mixed into BaseSwarmAgent alongside dspy.Module.
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AgentCollaborationMixin:
    """
    Mixin that provides collaboration context storage for swarm agents.
    
    The Conductor calls set_collaboration_context() on each actor before
    execution (in _execute_actor), providing:
    - agent_slack: SmartAgentSlack instance for inter-agent messaging
    - agent_directory: Dict of available agents with capabilities
    - my_name: This agent's registered name in the swarm
    
    Agents can then use this context to:
    - Check what other agents are available
    - Request help or share knowledge (via collaboration actions in output)
    - Access pending messages from other agents
    
    NOTE: Direct agent-to-agent communication during ReAct execution is
    orchestrated by the Conductor (which parses collaboration actions from
    agent output). This mixin stores the context needed for agents to
    make informed collaboration decisions in their reasoning.
    """
    
    # NOTE: __init__ is NOT defined here because BaseSwarmAgent.__init__
    # already initializes _agent_slack, _agent_directory, _my_name, _pending_messages
    # when COLLABORATION_AVAILABLE is True. This avoids MRO conflicts with dspy.Module.
    
    def set_collaboration_context(
        self,
        agent_slack: Any = None,
        agent_directory: Optional[Dict[str, Any]] = None,
        my_name: Optional[str] = None
    ) -> None:
        """
        Set collaboration context for this agent.
        
        Called by Conductor._execute_actor() before each execution.
        
        Args:
            agent_slack: SmartAgentSlack instance for inter-agent messaging
            agent_directory: Dict mapping agent names to their capabilities,
                           roles, status, and performance metrics
            my_name: This agent's registered name in the swarm
        """
        self._agent_slack = agent_slack
        self._agent_directory = agent_directory
        self._my_name = my_name
        
        if agent_directory:
            agent_names = list(agent_directory.keys())
            logger.info(
                f"💬 [{my_name}] Collaboration context set | "
                f"agents={len(agent_names)} ({', '.join(agent_names[:5])}{'...' if len(agent_names) > 5 else ''}) | "
                f"slack={'yes' if agent_slack else 'no'}"
            )
        else:
            logger.debug(f"💬 [{my_name}] Collaboration context set (no directory)")
    
    def get_available_agents(self) -> Dict[str, Any]:
        """
        Get the directory of available agents.
        
        Returns:
            Dict mapping agent names to their info (capabilities, role, status, etc.)
            Empty dict if no directory is available.
        """
        return self._agent_directory or {}
    
    def get_agent_capabilities(self, agent_name: str) -> List[str]:
        """
        Get capabilities of a specific agent.
        
        Args:
            agent_name: Name of the agent to look up
            
        Returns:
            List of capability strings, empty if agent not found
        """
        if not self._agent_directory:
            return []
        agent_info = self._agent_directory.get(agent_name, {})
        return agent_info.get("capabilities", [])
    
    def add_pending_message(self, message: Dict[str, Any]) -> None:
        """
        Add a pending message from another agent.
        
        Args:
            message: Message dict with 'from', 'type', 'content' keys
        """
        self._pending_messages.append(message)
        logger.debug(
            f"📬 [{self._my_name}] Received message from "
            f"{message.get('from', 'unknown')}: {message.get('type', 'unknown')}"
        )
    
    def get_pending_messages(self, clear: bool = True) -> List[Dict[str, Any]]:
        """
        Get pending messages from other agents.
        
        Args:
            clear: If True, clear messages after retrieval
            
        Returns:
            List of message dicts
        """
        messages = list(self._pending_messages)
        if clear:
            self._pending_messages = []
        return messages
    
    def record_collaboration(self, action: str, target: str, result: Any = None) -> None:
        """
        Record a collaboration action for history/learning.
        
        Args:
            action: Type of collaboration (e.g., 'help_request', 'knowledge_share')
            target: Target agent name
            result: Result of the collaboration
        """
        import time
        if not hasattr(self, '_collaboration_history'):
            self._collaboration_history = []
        self._collaboration_history.append({
            "timestamp": time.time(),
            "action": action,
            "from": self._my_name,
            "target": target,
            "result_summary": str(result)[:500] if result else None  # Log-only summary, not data-path
        })
    
    @property
    def has_collaboration_context(self) -> bool:
        """Check if collaboration context has been set."""
        return self._agent_slack is not None or self._agent_directory is not None
    
    @property
    def collaboration_agent_count(self) -> int:
        """Number of agents available for collaboration."""
        if not self._agent_directory:
            return 0
        return len(self._agent_directory)
