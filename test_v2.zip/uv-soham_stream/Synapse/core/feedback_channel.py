"""
FeedbackChannel: Inter-Agent Communication System

Enables agents to:
1. Ask questions to other agents
2. Request re-execution with hints
3. Provide error feedback
4. Suggest alternatives
5. Seek clarification

This is critical for intelligent multi-agent systems where agents
can consult each other rather than working in isolation.

Example:
    SQLGenerator has 15 tables but only needs 3-5:
    → Consults BusinessTermResolver: "Which tables are most relevant?"
    → Gets response: ["table1", "table2", "table3"]
    → Uses only those tables in SQL
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional, AsyncGenerator
from collections import defaultdict
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class FeedbackType(Enum):
    """Types of feedback messages between agents."""
    QUESTION = "question"           # Ask another agent for information
    ERROR = "error"                 # Report an error to another agent
    SUGGESTION = "suggestion"       # Suggest an alternative approach
    REQUEST = "request"             # Request re-execution
    CLARIFICATION = "clarification" # Ask for clarification
    RESPONSE = "response"           # Response to a question
    ERROR_CORRECTION = "error_correction"  # Correct an error in another agent's output
    REFINEMENT = "refinement"       # Refine/improve another agent's output
    CONSULTATION = "consultation"   # Consult with other agents for guidance


@dataclass
class FeedbackMessage:
    """
    Message from one agent to another.
    
    Attributes:
        source_actor: Agent sending the message
        target_actor: Agent receiving the message
        feedback_type: Type of feedback
        content: The actual message content
        context: Additional context (data, parameters, etc.)
        timestamp: When message was created
        requires_response: Whether this needs a response
        priority: Message priority (1=high, 2=medium, 3=low)
        original_message_id: If this is a response, ID of original message
    """
    source_actor: str
    target_actor: str
    feedback_type: FeedbackType
    content: str
    context: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    requires_response: bool = True
    priority: int = 1  # 1=high, 2=medium, 3=low
    message_id: str = field(default_factory=lambda: f"msg_{datetime.now().timestamp()}")
    original_message_id: Optional[str] = None


class FeedbackChannel:
    """
    Communication channel between agents.
    
    Manages message passing, history, and ensures agents can
    communicate effectively without tight coupling.
    
    Usage:
        channel = FeedbackChannel()
        
        # Agent A asks Agent B a question
        channel.send(FeedbackMessage(
            source_actor="SQLGenerator",
            target_actor="BusinessTermResolver",
            feedback_type=FeedbackType.QUESTION,
            content="Which data sources are most relevant for {target_concept}?",
            context={"current_tables": ["table1", "table2", ...]}
        ))
        
        # Agent B checks for messages
        messages = channel.get_for_actor("BusinessTermResolver")
        
        # Agent B responds
        channel.send(FeedbackMessage(
            source_actor="BusinessTermResolver",
            target_actor="SQLGenerator",
            feedback_type=FeedbackType.RESPONSE,
            content="Most relevant tables: table1, table2, table3",
            original_message_id=messages[0].message_id
        ))
    """
    
    def __init__(self):
        """Initialize the feedback channel."""
        self.messages: Dict[str, List[FeedbackMessage]] = defaultdict(list)
        self.message_history: List[FeedbackMessage] = []
        self.message_count = 0
        logger.info("📧 FeedbackChannel initialized - agents can now communicate!")
        # Note: __init__ cannot yield, but initialization is logged
    
    def send(self, message: FeedbackMessage) -> str:
        """
        Send a feedback message to an actor.
        
        Args:
            message: The feedback message to send
            
        Returns:
            Message ID for tracking
        """
        self.messages[message.target_actor].append(message)
        self.message_history.append(message)
        self.message_count += 1
        
        logger.info(
            f"📧 {message.source_actor} → {message.target_actor}: "
            f"{message.feedback_type.value} "
            f"(priority={message.priority}, id={message.message_id})"
        )
        logger.debug(f"   Content: {message.content}...")
        # Note: Sync method, async version would yield events
        return message.message_id
    
    def get_for_actor(
        self, 
        actor_name: str, 
        clear: bool = True,
        priority_threshold: int = 3
    ) -> List[FeedbackMessage]:
        """
        Get messages for a specific actor.
        
        Args:
            actor_name: Name of the actor
            clear: Whether to clear messages after retrieval
            priority_threshold: Only get messages with priority <= this (1=high, 3=low)
            
        Returns:
            List of feedback messages for the actor
        """
        if actor_name not in self.messages:
            return []
        
        # Filter by priority
        messages = [
            msg for msg in self.messages[actor_name]
            if msg.priority <= priority_threshold
        ]
        
        # Sort by priority (high first), then timestamp
        messages.sort(key=lambda m: (m.priority, m.timestamp))
        
        if clear:
            self.messages[actor_name] = [
                msg for msg in self.messages[actor_name]
                if msg.priority > priority_threshold
            ]
        
        if messages:
            logger.info(
                f"📬 {actor_name} has {len(messages)} message(s) "
                f"(priority <={priority_threshold})"
            )
        
        return messages
    
    def has_feedback(
        self, 
        actor_name: str, 
        priority_threshold: int = 3
    ) -> bool:
        """
        Check if an actor has pending messages.
        
        Args:
            actor_name: Name of the actor
            priority_threshold: Only check messages with priority <= this
            
        Returns:
            True if actor has pending messages
        """
        if actor_name not in self.messages:
            return False
        
        return any(
            msg.priority <= priority_threshold
            for msg in self.messages[actor_name]
        )
    
    def get_conversation(
        self, 
        actor1: str, 
        actor2: str
    ) -> List[FeedbackMessage]:
        """
        Get all messages between two actors.
        
        Args:
            actor1: First actor name
            actor2: Second actor name
            
        Returns:
            List of all messages between the two actors, sorted by time
        """
        conversation = [
            msg for msg in self.message_history
            if (msg.source_actor == actor1 and msg.target_actor == actor2) or
               (msg.source_actor == actor2 and msg.target_actor == actor1)
        ]
        conversation.sort(key=lambda m: m.timestamp)
        return conversation
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about message passing.
        
        Returns:
            Dictionary with stats
        """
        return {
            "total_messages": self.message_count,
            "pending_messages": sum(len(msgs) for msgs in self.messages.values()),
            "actors_with_pending": list(self.messages.keys()),
            "message_types": {
                ft.value: sum(
                    1 for msg in self.message_history
                    if msg.feedback_type == ft
                )
                for ft in FeedbackType
            }
        }
    
    def clear_all(self):
        """Clear all pending messages (but keep history)."""
        self.messages.clear()
        logger.info("📧 FeedbackChannel: All pending messages cleared")
    
    def format_messages_for_agent(
        self, 
        actor_name: str,
        messages: List[FeedbackMessage]
    ) -> str:
        """
        Format messages as a string for injection into agent context.
        
        Args:
            actor_name: Name of the actor receiving the messages
            messages: List of messages to format
            
        Returns:
            Formatted string for injection
        """
        if not messages:
            return ""
        
        formatted = f"\n📧 MESSAGES FOR {actor_name}:\n\n"
        
        for i, msg in enumerate(messages, 1):
            formatted += f"{i}. FROM {msg.source_actor} ({msg.feedback_type.value}):\n"
            formatted += f"   {msg.content}\n"
            
            if msg.context:
                formatted += f"   Context: {str(msg.context)}\n"
            
            if msg.requires_response:
                formatted += f"   ⚠️ Requires Response\n"
            
            formatted += "\n"
        
        formatted += "END MESSAGES\n"
        return formatted

