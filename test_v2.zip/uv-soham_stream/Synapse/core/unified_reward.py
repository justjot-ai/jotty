"""
Unified Reward System - A-Team Consensus Implementation
========================================================

Single source of truth for ALL reward calculations in Synapse.

Principles:
1. All rewards in [0, 1] range (NO negative rewards)
2. Hierarchical: subtask → phase → episode
3. Decomposed: quality + cooperation + learning + user
4. User-augmented: LLM + human feedback
5. Anti-hacking: validation and consistency checks
6. Transparent: RewardBreakdown explains every component

A-Team Approval:
- Dr. Manning: ✅ (reward decomposition)
- Dr. Sutton: ✅ (hierarchical rewards)
- Dr. Chen: ✅ (normalized scale)
- Shannon: ✅ (consistent information)
- Von Neumann: ✅ (proportional cooperation)
- Dr. Silver: ✅ (user input API!)
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class UserReward:
    """User-provided reward for a task."""
    task_id: str
    reward: float  # [0, 1]
    reason: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    def __post_init__(self):
        if not 0.0 <= self.reward <= 1.0:
            raise ValueError(f"User reward must be in [0, 1], got {self.reward}")


@dataclass
class RewardBreakdown:
    """Transparent breakdown of reward components."""
    total: float  # Final reward [0, 1]
    quality: float  # From auditor confidence [0, 1]
    cooperation: float  # From downstream impact [0, 1]
    learning: float  # From predictability [0, 1]
    user: Optional[float]  # From human feedback [0, 1]
    weights: Dict[str, float]  # Component weights
    
    def explain(self) -> str:
        """Human-readable explanation of reward."""
        parts = [
            f"Total Reward: {self.total:.3f}",
            f"  Quality (LLM tests): {self.quality:.3f} (weight: {self.weights['quality']:.1%})",
            f"  Cooperation (helps others): {self.cooperation:.3f} (weight: {self.weights['cooperation']:.1%})",
            f"  Learning (predicted correctly): {self.learning:.3f} (weight: {self.weights['learning']:.1%})",
        ]
        
        if self.user is not None:
            parts.append(f"  User Feedback: {self.user:.3f} (weight: {self.weights.get('user', 0.1):.1%})")
        else:
            parts.append(f"  User Feedback: Not provided")
        
        return "\n".join(parts)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            'total': self.total,
            'components': {
                'quality': self.quality,
                'cooperation': self.cooperation,
                'learning': self.learning,
                'user': self.user
            },
            'weights': self.weights
        }


# =============================================================================
# REWARD NORMALIZER
# =============================================================================

class RewardNormalizer:
    """
    Normalize rewards from different sources to [0, 1] range.
    
    A-Team: Shannon's solution to inconsistent scales.
    
    🔴 A-TEAM FIX: Ranges are now adaptive — they start with default values but
    update based on observed data to handle drift in reward distributions.
    """
    
    # Default source ranges (initial estimates, updated from observed data)
    DEFAULT_RANGES = {
        'auditor': (0.0, 1.0),  # Already normalized
        'q_learning': (0.0, 1.0),  # Binary but in [0, 1]
        'episode': (-0.8, 1.2),  # Needs normalization!
        'intermediate': (-0.025, 0.3),  # Needs normalization!
        'cooperative': (0.0, 2.0),  # Unbounded sum, needs cap
        'user': (0.0, 1.0)  # User input is always [0, 1]
    }
    
    def __init__(self):
        # Start with defaults, adapt from observed data
        self.RANGES = dict(self.DEFAULT_RANGES)
        self._observed_min: Dict[str, float] = {}
        self._observed_max: Dict[str, float] = {}
    
    def normalize(self, reward: float, source: str) -> float:
        """
        Normalize reward to [0, 1] based on source.
        
        🔴 A-TEAM FIX: Now adaptively updates ranges from observed data.
        
        Args:
            reward: Raw reward value
            source: One of: auditor, q_learning, episode, intermediate, cooperative, user
        
        Returns:
            Normalized reward in [0, 1]
        """
        if source not in self.RANGES:
            logger.warning(f"Unknown reward source: {source}, assuming [0, 1]")
            return max(0.0, min(1.0, reward))
        
        # Adaptive range update: track actual observed min/max
        if source not in self._observed_min:
            self._observed_min[source] = reward
            self._observed_max[source] = reward
        else:
            # Exponential moving average to adapt ranges smoothly
            alpha = 0.1
            self._observed_min[source] = min(self._observed_min[source], 
                                              self._observed_min[source] * (1 - alpha) + reward * alpha)
            self._observed_max[source] = max(self._observed_max[source],
                                              self._observed_max[source] * (1 - alpha) + reward * alpha)
            
            # Update RANGES with observed data (weighted blend of default + observed)
            default_min, default_max = self.DEFAULT_RANGES.get(source, (0.0, 1.0))
            obs_min = self._observed_min[source]
            obs_max = self._observed_max[source]
            # Use wider of default or observed range to avoid clipping
            self.RANGES[source] = (min(default_min, obs_min), max(default_max, obs_max))
        
        min_val, max_val = self.RANGES[source]
        
        # Already normalized
        if min_val == 0.0 and max_val == 1.0:
            return max(0.0, min(1.0, reward))
        
        # Avoid division by zero
        range_span = max_val - min_val
        if range_span < 1e-10:
            return max(0.0, min(1.0, reward))
        
        # Linear normalization: (x - min) / (max - min)
        normalized = (reward - min_val) / range_span
        
        # Clamp to [0, 1]
        return max(0.0, min(1.0, normalized))


# =============================================================================
# REWARD VALIDATOR (Anti-Hacking)
# =============================================================================

class RewardValidator:
    """
    Validate rewards to prevent reward hacking.
    
    A-Team: Turing's solution to specification gaming.
    """
    
    def __init__(self):
        self.task_reward_history: Dict[str, List[float]] = {}
    
    def validate_reward(
        self,
        task_id: str,
        task_type: str,
        reward: float,
        result: Any,
        context: Dict
    ) -> float:
        """
        Validate reward is not hacked.
        
        Checks:
        1. Reward matches output quality (length, structure)
        2. Consistency with previous similar tasks
        3. Suspicious patterns (e.g., always 1.0)
        
        Args:
            task_id: Task identifier
            task_type: Type of task (e.g., "generate_sql", "format_data")
            reward: Proposed reward
            result: Task output
            context: Execution context
        
        Returns:
            Validated (possibly adjusted) reward in [0, 1]
        """
        # Check 1: Output quality heuristics
        # 🔴 A-TEAM FIX: Made thresholds configurable (were hardcoded 0.8/10/0.3/1000)
        high_reward_suspect = getattr(context.get('config'), 'reward_high_suspect_threshold', 0.8) if isinstance(context, dict) else 0.8
        min_output_chars = getattr(context.get('config'), 'reward_min_output_chars', 10) if isinstance(context, dict) else 10
        low_reward_suspect = getattr(context.get('config'), 'reward_low_suspect_threshold', 0.3) if isinstance(context, dict) else 0.3
        substantial_output_chars = getattr(context.get('config'), 'reward_substantial_output_chars', 1000) if isinstance(context, dict) else 1000
        
        result_str = str(result) if result is not None else ""
        result_len = len(result_str)
        
        # Suspiciously high reward for empty/short output
        if reward > high_reward_suspect and result_len < min_output_chars:
            logger.warning(
                f"⚠️  REWARD VALIDATION: High reward ({reward:.2f}) for short output ({result_len} chars). "
                f"Adjusting to 0.5."
            )
            reward = 0.5
        
        # Suspiciously low reward for long, structured output
        if reward < low_reward_suspect and result_len > substantial_output_chars and isinstance(result, (dict, list)):
            logger.warning(
                f"⚠️  REWARD VALIDATION: Low reward ({reward:.2f}) for substantial output ({result_len} chars). "
                f"Adjusting to 0.5."
            )
            reward = 0.5
        
        # Check 2: Consistency with task type history
        if task_type in self.task_reward_history:
            history = self.task_reward_history[task_type]
            if len(history) >= 3:
                mean_reward = sum(history) / len(history)
                
                # If reward deviates >0.5 from mean, clip it
                if abs(reward - mean_reward) > 0.5:
                    adjusted = max(mean_reward - 0.3, min(mean_reward + 0.3, reward))
                    logger.warning(
                        f"⚠️  REWARD VALIDATION: {task_type} reward {reward:.2f} deviates from "
                        f"mean {mean_reward:.2f}. Adjusting to {adjusted:.2f}."
                    )
                    reward = adjusted
        
        # Record for history
        if task_type not in self.task_reward_history:
            self.task_reward_history[task_type] = []
        self.task_reward_history[task_type].append(reward)
        
        # Keep history bounded
        if len(self.task_reward_history[task_type]) > 20:
            self.task_reward_history[task_type] = self.task_reward_history[task_type][-20:]
        
        # Check 3: Suspicious patterns
        if task_type in self.task_reward_history:
            recent = self.task_reward_history[task_type][-5:]
            
            # All rewards identical (suspicious)
            if len(set(recent)) == 1 and len(recent) >= 3:
                logger.warning(
                    f"⚠️  REWARD VALIDATION: {task_type} has identical rewards for last {len(recent)} tasks. "
                    f"Possible reward hacking."
                )
        
        return max(0.0, min(1.0, reward))


# =============================================================================
# UNIFIED REWARD CALCULATOR
# =============================================================================

class UnifiedRewardCalculator:
    """
    Single source of truth for ALL reward calculations.
    
    A-Team Consensus Implementation.
    """
    
    def __init__(self, config: 'SynapseConfig'):
        self.config = config
        self.normalizer = RewardNormalizer()
        self.validator = RewardValidator()
        self.user_feedback: List[UserReward] = []
        
        # A-TEAM FIX: Reward component weights - QUALITY (task completion) is PRIMARY
        # Previous weights gave cooperation 30% which incentivized sharing over completing tasks
        # New weights: quality 60%, cooperation 10%, learning 20%, user 10%
        self.weights = {
            'quality': getattr(config, 'reward_weight_quality', 0.6),
            'cooperation': getattr(config, 'reward_weight_cooperation', 0.1),
            'learning': getattr(config, 'reward_weight_learning', 0.2),
            'user': getattr(config, 'reward_weight_user', 0.1)
        }
        
        # Normalize weights to sum to 1.0
        total_weight = sum(self.weights.values())
        self.weights = {k: v / total_weight for k, v in self.weights.items()}
        
        logger.info(f"✅ UnifiedRewardCalculator initialized with weights: {self.weights}")
    
    def compute_subtask_reward(
        self,
        task: 'SubtaskState',
        auditor_results: Dict,
        context: Dict
    ) -> RewardBreakdown:
        """
        Compute reward for a single subtask.
        
        Args:
            task: Subtask that was executed
            auditor_results: Full auditor results from HybridTestAggregator
                {
                    'reward': float [0, 1],
                    'confidence': float [0, 1],
                    'reasoning': str,
                    'method': str,
                    'test_breakdown': List[Dict]
                }
            context: Execution context (todo, predictor, etc.)
        
        Returns:
            RewardBreakdown with transparent component breakdown
        """
        # 1. QUALITY COMPONENT (from aggregated test results)
        quality_raw = auditor_results.get('reward', auditor_results) if isinstance(auditor_results, dict) else auditor_results
        quality_confidence = auditor_results.get('confidence', 1.0) if isinstance(auditor_results, dict) else 1.0
        
        # Weight quality by confidence (high confidence → trust quality, low confidence → regress to mean)
        quality = quality_raw * quality_confidence + 0.5 * (1 - quality_confidence)
        
        # 2. COOPERATION COMPONENT
        cooperation = self._compute_downstream_impact(task, context)
        
        # 3. LEARNING COMPONENT
        learning = self._compute_predictability(task, context)
        
        # 4. USER COMPONENT (if provided)
        user_reward = self._get_user_reward(task.task_id)
        
        # WEIGHTED COMBINATION (excluding user initially)
        base_weights = {
            'quality': self.weights['quality'] / (1 - self.weights['user']),
            'cooperation': self.weights['cooperation'] / (1 - self.weights['user']),
            'learning': self.weights['learning'] / (1 - self.weights['user'])
        }
        
        total = (
            quality * base_weights['quality'] +
            cooperation * base_weights['cooperation'] +
            learning * base_weights['learning']
        )
        
        # ADD USER FEEDBACK (if provided)
        if user_reward is not None:
            # Blend: (1 - user_weight) * LLM + user_weight * user
            total = total * (1 - self.weights['user']) + user_reward * self.weights['user']
        
        # VALIDATE (anti-hacking)
        task_type = task.actor if hasattr(task, 'actor') else 'unknown'
        validated = self.validator.validate_reward(
            task_id=task.task_id,
            task_type=task_type,
            reward=total,
            result=task.result if hasattr(task, 'result') else None,
            context=context
        )
        
        breakdown = RewardBreakdown(
            total=validated,
            quality=quality,
            cooperation=cooperation,
            learning=learning,
            user=user_reward,
            weights=self.weights
        )
        
        logger.debug(f"📊 Reward for {task.task_id}:\n{breakdown.explain()}")
        
        return breakdown
    
    def compute_phase_reward(
        self,
        phase: str,  # PhaseType removed - using string instead
        subtask_rewards: List[float]
    ) -> float:
        """
        Aggregate subtask rewards into phase reward.
        
        Later tasks in phase get higher weight (more critical).
        """
        if not subtask_rewards:
            return 0.0
        
        # Weighted average (exponentially increasing weights)
        weights = [(i + 1) / len(subtask_rewards) for i in range(len(subtask_rewards))]
        total_weight = sum(weights)
        
        phase_reward = sum(r * w for r, w in zip(subtask_rewards, weights)) / total_weight
        
        return max(0.0, min(1.0, phase_reward))
    
    def compute_episode_reward(
        self,
        phase_rewards: Dict[str, float]  # PhaseType removed - using string keys instead
    ) -> float:
        """
        Aggregate phase rewards into episode reward.
        
        Uses weighted average of all phase rewards.
        Later phases (closer to final output) get exponentially higher weight.
        
        Math:
            w_i = (i + 1) / N  (linearly increasing weights)
            episode_reward = Σ(w_i * r_i) / Σ(w_i)
        
        This incentivizes strong performance on final delivery phases
        while still rewarding good intermediate work.
        """
        if not phase_rewards:
            return 0.0
        
        # Ordered phases get linearly increasing weights
        rewards_list = list(phase_rewards.values())
        n = len(rewards_list)
        weights = [(i + 1) / n for i in range(n)]
        total_weight = sum(weights)
        
        weighted_sum = sum(r * w for r, w in zip(rewards_list, weights))
        total = weighted_sum / total_weight if total_weight > 0 else 0.0
        
        return max(0.0, min(1.0, total))
    
    def accept_user_feedback(
        self,
        task_id: str,
        reward: float,
        reason: str,
        timestamp: datetime = None
    ):
        """
        Accept user feedback on a task.
        
        THIS IS THE CRITICAL MISSING FEATURE!
        
        Args:
            task_id: Task identifier
            reward: User reward in [0, 1] or [0, 10] (will be normalized)
            reason: User explanation
            timestamp: When feedback was given
        
        Example:
            calculator.accept_user_feedback(
                task_id="generate_sql",
                reward=9.0,  # Out of 10
                reason="SQL was correct but could be optimized"
            )
        """
        # Normalize if user provided 0-10 scale
        if reward > 1.0:
            if reward <= 10.0:
                reward = reward / 10.0
            else:
                raise ValueError(f"User reward must be [0, 1] or [0, 10], got {reward}")
        
        if not 0.0 <= reward <= 1.0:
            raise ValueError(f"User reward must be in [0, 1], got {reward}")
        
        feedback = UserReward(
            task_id=task_id,
            reward=reward,
            reason=reason,
            timestamp=timestamp or datetime.now()
        )
        
        self.user_feedback.append(feedback)
        
        logger.info(
            f"👤 USER FEEDBACK: task={task_id}, reward={reward:.2f} ({reward*10:.1f}/10), "
            f"reason={reason}"
        )
    
    def _compute_downstream_impact(self, task: 'SubtaskState', context: Dict) -> float:
        """
        How much does this task help future tasks?
        
        A-Team: Von Neumann's proportional cooperation bonus.
        """
        todo = context.get('todo')
        if not todo:
            return 0.5  # Neutral if no todo available
        
        # Find tasks that depend on this one
        try:
            from .roadmap import TaskStatus
        except ImportError:
            return 0.5
        
        dependent_tasks = [
            t for t in todo.subtasks.values()
            if task.task_id in t.depends_on
        ]
        
        if not dependent_tasks:
            return 0.5  # Neutral if no dependents
        
        # Impact = weighted sum of dependent task priorities
        total_priority = 0.0
        for dep_task in dependent_tasks:
            # Weight by: priority * (1 if pending else 0.5)
            task_weight = 1.0 if dep_task.status == TaskStatus.PENDING else 0.5
            total_priority += dep_task.priority * task_weight
        
        # Normalize by number of dependents (max priority assumed to be 1.0)
        max_possible = len(dependent_tasks) * 1.0
        
        impact = total_priority / max_possible if max_possible > 0 else 0.5
        
        return max(0.0, min(1.0, impact))
    
    def _compute_predictability(self, task: 'SubtaskState', context: Dict) -> float:
        """
        How well was this task predicted?
        
        A-Team: Dr. Agarwal's learning component.
        """
        predictor = context.get('trajectory_predictor')
        if not predictor:
            return 0.5  # Neutral if no predictor
        
        if not hasattr(predictor, 'prediction_history') or not predictor.prediction_history:
            return 0.5  # Neutral if no predictions
        
        # Find prediction for this task
        try:
            from .roadmap import TaskStatus
        except ImportError:
            return 0.5
        
        for pred in reversed(predictor.prediction_history):  # Most recent first
            prediction = pred.get('prediction', {})
            predicted_action = prediction.get('predicted_action', '')
            
            # Check if this task was predicted
            if task.actor in predicted_action or task.task_id in predicted_action:
                # Check if prediction matched reality
                predicted_outcome = prediction.get('predicted_outcome', '').lower()
                actual_success = task.status == TaskStatus.COMPLETED
                
                # Match if both success or both failure
                prediction_correct = (
                    ('success' in predicted_outcome and actual_success) or
                    ('fail' in predicted_outcome and not actual_success)
                )
                
                if prediction_correct:
                    confidence = prediction.get('confidence', 0.5)
                    return max(0.0, min(1.0, confidence))
                else:
                    # Prediction was wrong
                    return 0.3  # Below neutral for wrong prediction
        
        return 0.5  # Neutral if no matching prediction
    
    def _get_user_reward(self, task_id: str) -> Optional[float]:
        """Get user reward for this task (if any)."""
        # Search from most recent to oldest
        for feedback in reversed(self.user_feedback):
            if feedback.task_id == task_id:
                return feedback.reward
        return None
    
    def get_user_feedback_summary(self) -> str:
        """Get summary of all user feedback."""
        if not self.user_feedback:
            return "No user feedback provided yet."
        
        lines = ["User Feedback Summary:"]
        for feedback in self.user_feedback:
            lines.append(
                f"  - {feedback.task_id}: {feedback.reward:.2f} "
                f"('{feedback.reason}') at {feedback.timestamp.strftime('%H:%M:%S')}"
            )
        
        return "\n".join(lines)
    
    def save_user_feedback(self, path: str):
        """Save user feedback to JSON file."""
        import json
        from pathlib import Path
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        data = [
            {
                'task_id': f.task_id,
                'reward': f.reward,
                'reason': f.reason,
                'timestamp': f.timestamp.isoformat()
            }
            for f in self.user_feedback
        ]
        
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        
        logger.info(f"💾 Saved {len(data)} user feedback entries to {path}")
    
    def load_user_feedback(self, path: str):
        """Load user feedback from JSON file."""
        import json
        from pathlib import Path
        
        if not Path(path).exists():
            logger.info(f"ℹ️  No user feedback file at {path}")
            return
        
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            
            for item in data:
                self.user_feedback.append(UserReward(
                    task_id=item['task_id'],
                    reward=item['reward'],
                    reason=item['reason'],
                    timestamp=datetime.fromisoformat(item['timestamp'])
                ))
            
            logger.info(f"✅ Loaded {len(data)} user feedback entries from {path}")
        
        except Exception as e:
            logger.error(f"❌ Failed to load user feedback: {e}")


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'UnifiedRewardCalculator',
    'RewardBreakdown',
    'UserReward',
    'RewardNormalizer',
    'RewardValidator'
]
