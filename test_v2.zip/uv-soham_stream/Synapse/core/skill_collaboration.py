"""
Structured collaboration payload builders for dynamic skills.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SkillRequest:
    capability: str
    context: Dict[str, Any] = field(default_factory=dict)
    preferred_owner: str = ""
    required_io: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SkillProposal:
    name: str
    description: str
    module_path: str
    owner_actor: str
    dependencies: List[str] = field(default_factory=list)
    entrypoint: str = "run"
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    safety_profile: Dict[str, Any] = field(default_factory=dict)
    quality_signals: Dict[str, Any] = field(default_factory=dict)


def make_request_skill_action(
    request: SkillRequest,
    *,
    target_agent: str = "all",
) -> Dict[str, Any]:
    return {
        "action": "request_skill",
        "target_agent": target_agent,
        "data": {
            "capability": request.capability,
            "context": request.context,
            "preferred_owner": request.preferred_owner,
            "required_io": request.required_io,
        },
    }


def make_propose_skill_action(
    proposal: SkillProposal,
    *,
    target_agent: str = "Conductor",
) -> Dict[str, Any]:
    return {
        "action": "propose_skill",
        "target_agent": target_agent,
        "data": {
            "name": proposal.name,
            "description": proposal.description,
            "module_path": proposal.module_path,
            "owner_actor": proposal.owner_actor,
            "dependencies": proposal.dependencies,
            "entrypoint": proposal.entrypoint,
            "input_schema": proposal.input_schema,
            "output_schema": proposal.output_schema,
            "safety_profile": proposal.safety_profile,
            "quality_signals": proposal.quality_signals,
        },
    }


def make_publish_skill_action(
    *,
    skill_id: str,
    target_agent: str = "Conductor",
    quality_signals: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "action": "publish_skill",
        "target_agent": target_agent,
        "data": {
            "skill_id": skill_id,
            "quality_signals": quality_signals or {},
        },
    }


def make_deprecate_skill_action(
    *,
    skill_id: str,
    reason: str,
    target_agent: str = "Conductor",
) -> Dict[str, Any]:
    return {
        "action": "deprecate_skill",
        "target_agent": target_agent,
        "data": {
            "skill_id": skill_id,
            "reason": reason,
        },
    }

