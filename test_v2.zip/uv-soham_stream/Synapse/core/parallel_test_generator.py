"""Parallel test case generation for Auditor."""
import dspy
import asyncio
import json
import logging
from typing import List, Dict, Any, Optional, AsyncGenerator

logger = logging.getLogger(__name__)


class LLMTestValidationSignature(dspy.Signature):
    """Validate if actual output matches expected criteria using semantic understanding.
    
    This is much better than string matching - it understands intent and meaning.
    
    IMPORTANT: Be LENIENT in validation:
    - Focus on whether the TASK WAS COMPLETED, not exact format
    - If task completed successfully (even with "zero results" or "nothing found"), consider it PASSED
    - Pass tests if the agent attempted the task and reported results, even if results are empty
    - Only fail if the task clearly failed, errored, or was not attempted
    - If the actual_output shows the agent navigated to the right place and performed the action, PASS
    - Raw trajectory output (tool calls, observations) IS valid evidence of task completion
    """
    
    test_name = dspy.InputField(desc="Name of the test being validated")
    expected_criteria = dspy.InputField(desc="What the output should contain or demonstrate")
    actual_output = dspy.InputField(desc="The actual output/result from task execution (may be raw trajectory)")
    
    passed = dspy.OutputField(desc="true if output meets criteria, false otherwise. Be LENIENT - pass if task completed successfully even with empty/zero results. Raw trajectory showing correct actions = PASS")
    reasoning = dspy.OutputField(desc="Brief explanation of why test passed or failed")


class TestCaseGenerationSignature(dspy.Signature):
    """Generate test cases for a given task/problem.
    
    Tests will be validated using LLM semantic matching (not string matching).
    
    🔴 CRITICAL GROUNDING RULE:
    Every test case MUST be directly derived from the task_description.
    Do NOT invent tests about things not mentioned in the task.
    Do NOT hallucinate test names that reference unrelated topics.
    
    If task is "Send cricket highlights to John on WhatsApp", then:
    ✅ "test_whatsapp_message_sent" - directly related
    ✅ "test_cricket_content_found" - directly related  
    ❌ "test_release_notes_access" - UNRELATED, DO NOT GENERATE
    ❌ "test_python_installation" - UNRELATED, DO NOT GENERATE
    
    FOCUS on: Did the agent complete the specific task described?
    """
    
    task_description = dspy.InputField(desc="The EXACT task that was completed - ALL tests must relate to THIS task")
    expected_output = dspy.InputField(desc="Expected output format/requirements")
    domain = dspy.InputField(desc="Domain (inferred from task, e.g., image processing, web scraping)")
    
    test_cases = dspy.OutputField(
        desc="""JSON array of test cases (2-4 tests max).
        
        Each test case:
        {
            "name": "test_name",
            "input": "test input description",
            "expected_output": "expected result description",
            "validation_method": "MUST be one of: content_match, regex_match, file_exists, format_check",
            "priority": "critical|high|medium|low"
        }
        
        MANDATORY RULES:
        1. Every test MUST directly relate to the task_description
        2. Test names MUST reflect the actual task (not generic or unrelated names)
        3. Simple tasks: 2 tests (task completion + basic validation)
        4. Complex tasks: 3-4 tests
        5. NEVER exceed 4 test cases
        6. NEVER generate tests about topics not in task_description
        7. validation_method MUST be exactly one of: content_match, regex_match, file_exists, format_check
        
        Example for task "Search for weather in NYC":
        [
            {
                "name": "test_weather_search_executed",
                "input": "NYC weather query",
                "expected_output": "Weather information for NYC was retrieved",
                "validation_method": "content_match",
                "priority": "critical"
            },
            {
                "name": "test_weather_data_present",
                "input": "weather results",
                "expected_output": "Temperature or forecast data is present in output",
                "validation_method": "content_match",
                "priority": "high"
            }
        ]
        """
    )
    reasoning = dspy.OutputField(desc="Why these test cases cover the requirements - must reference the actual task")


class ParallelTestGenerator:
    """Generate multiple test cases in parallel for comprehensive validation."""
    
    def __init__(self, max_parallel: int = 5, validator_lm: Optional[Any] = None, config=None):
        try:
            self.generator = dspy.ChainOfThought(TestCaseGenerationSignature)
            self.max_parallel = max_parallel
            
            # 🔴 A-TEAM FIX: Use config-driven lightweight model (no hardcoded model names!)
            # Priority: YAML internal_agents override > config.default_lightweight_model > default dspy LM
            if validator_lm is None:
                try:
                    import os
                    model_name = None
                    # Priority 0: Per-internal-agent override from agent_models.yaml
                    try:
                        import yaml
                        from pathlib import Path
                        _cfg_path = Path(__file__).parent.parent / "config" / "agent_models.yaml"
                        if _cfg_path.exists():
                            with open(_cfg_path, "r") as _f:
                                _yaml = yaml.safe_load(_f) or {}
                            _int_cfg = _yaml.get("internal_agents", {})
                            _entry = _int_cfg.get("ParallelTestGenerator", {})
                            if isinstance(_entry, dict):
                                _mv = _entry.get("model", "lightweight")
                                if _mv == "default":
                                    model_name = _yaml.get("default_model")
                                elif _mv == "lightweight":
                                    model_name = _yaml.get("default_lightweight_model")
                                elif _mv:
                                    model_name = _mv
                    except Exception:
                        pass
                    # Priority 1: config.default_lightweight_model
                    if not model_name and config and hasattr(config, 'default_lightweight_model'):
                        model_name = config.default_lightweight_model
                    
                    if model_name:
                        api_key = (
                            (getattr(config, 'model_api_key', None) if config else None)
                            or os.getenv("LITELLM_API_KEY")
                        )
                        api_base = (
                            (getattr(config, 'model_api_base', None) if config else None)
                            or os.getenv("LITELLM_BASE_URL")
                        )
                        kwargs = {"model": model_name}
                        if api_key:
                            kwargs["api_key"] = api_key
                        if api_base:
                            kwargs["api_base"] = api_base
                        validator_lm = dspy.LM(**kwargs)
                        logger.info(f"✅ Test validator using lightweight model: {model_name}")
                    else:
                        logger.info("✅ Test validator using default dspy LM (no lightweight model configured)")
                except Exception as e:
                    logger.warning(f"Failed to create validator LM: {e}, will use default")
                    validator_lm = None
            
            self.validator_lm = validator_lm
            self.validator = None
            if validator_lm:
                # Create validator with custom LM
                with dspy.context(lm=validator_lm):
                    self.validator = dspy.ChainOfThought(LLMTestValidationSignature)
            else:
                self.validator = dspy.ChainOfThought(LLMTestValidationSignature)
                logger.info("✅ Test validator initialized with default LM")
            
        except Exception as e:
            logger.warning(f"Failed to initialize ParallelTestGenerator: {e}")
            self.generator = None
            self.validator = None
    
    async def generate_tests_stream(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        num_tests: int = 2
    ) -> AsyncGenerator[Dict[str, Any], List[Dict[str, Any]]]:
        """
        Generate multiple test cases in parallel.
        
        Args:
            task_description: Description of the task
            expected_output: Expected output format
            domain: Domain of the task
            num_tests: Number of test batches to generate
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            List of test case dicts
        """
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am starting to generate {num_tests} test batches in parallel"}
        if not self.generator:
            logger.warning("Generator not initialized")
            yield {"module": "Synapse.core.parallel_test_generator", "message": "I noticed the generator is not initialized"}
            yield {"type": "result", "result": []}
            return
        
        # Create multiple generation tasks
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am creating {min(num_tests, self.max_parallel)} parallel generation tasks"}
        tasks = []
        for i in range(min(num_tests, self.max_parallel)):
            task = self._generate_single_batch(
                task_description=task_description,
                expected_output=expected_output,
                domain=domain,
                batch_id=i
            )
            tasks.append(task)
        
        # Run in parallel
        yield {"module": "Synapse.core.parallel_test_generator", "message": "I am running test generation tasks in parallel"}
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Flatten and deduplicate
        all_tests = []
        seen_names = set()
        
        for result in results:
            if isinstance(result, Exception):
                logger.warning(f"Test generation failed: {result}")
                yield {"module": "Synapse.core.parallel_test_generator", "message": f"I encountered an error during test generation: {result}"}
                continue
            
            for test in result:
                if test['name'] not in seen_names:
                    all_tests.append(test)
                    seen_names.add(test['name'])
        
        logger.info(f"✅ Generated {len(all_tests)} unique test cases in parallel")
        # Yield each test case condition for UI (e.g. "Created Test 1: Check if agent started whatsapp web")
        for i, test in enumerate(all_tests, 1):
            condition = test.get('expected_output') or test.get('name', f'Test {i}')
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"Created Test {i}: {condition}"}
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I successfully generated {len(all_tests)} unique test cases in parallel"}
        yield {"type": "result", "result": all_tests}
        return
    
    async def generate_tests(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        num_tests: int = 2
    ) -> List[Dict[str, Any]]:
        """Synchronous wrapper for generate_tests_stream."""
        result = None
        async for event in self.generate_tests_stream(task_description, expected_output, domain, num_tests):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else []
    
    async def _generate_single_batch(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        batch_id: int
    ) -> List[Dict]:
        """Generate a single batch of test cases."""
        try:
            result = self.generator(
                task_description=task_description[:500],  # Limit length
                expected_output=expected_output[:500],
                domain=domain
            )
            
            # Validate test_cases exists and is not empty
            if not hasattr(result, 'test_cases') or not result.test_cases:
                logger.warning(f"Batch {batch_id} returned empty test_cases, skipping")
                return []
            
            # Try to parse JSON
            test_cases_str = result.test_cases.strip()
            if not test_cases_str:
                logger.warning(f"Batch {batch_id} test_cases is empty string, skipping")
                return []
            
            tests = json.loads(test_cases_str)
            
            if not isinstance(tests, list):
                tests = [tests]
            
            return tests
        except json.JSONDecodeError as e:
            logger.error(f"Batch {batch_id} JSON parsing failed: {e}")
            logger.debug(f"Raw test_cases value: {getattr(result, 'test_cases', 'N/A')[:200] if hasattr(result, 'test_cases') else 'N/A'}")
            return []
        except Exception as e:
            logger.error(f"Batch {batch_id} generation failed: {e}")
            return []
    
    def generate_tests_sync(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        num_tests: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Synchronous version of generate_tests.
        
        Useful when async is not available.
        """
        if not self.generator:
            return []
        
        all_tests = []
        seen_names = set()
        
        for i in range(num_tests):
            try:
                result = self.generator(
                    task_description=task_description[:500],
                    expected_output=expected_output[:500],
                    domain=domain
                )
                
                tests = json.loads(result.test_cases)
                
                if not isinstance(tests, list):
                    tests = [tests]
                
                for test in tests:
                    if test['name'] not in seen_names:
                        all_tests.append(test)
                        seen_names.add(test['name'])
            except Exception as e:
                logger.warning(f"Batch {i} generation failed: {e}")
                continue
        
        logger.info(f"✅ Generated {len(all_tests)} unique test cases")
        return all_tests
    
    async def generate_and_run_stream(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        actual_result: Any,
        num_tests: int = 2
    ) -> AsyncGenerator[Dict[str, Any], Dict[str, Any]]:
        """
        Generate test cases and run them against the actual result.
        
        Args:
            task_description: Description of the task
            expected_output: Expected output format
            domain: Domain of the task
            actual_result: The actual result to validate against
            num_tests: Number of test batches to generate
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            Dict containing test results:
            {
                "results": List[Dict] with test cases and pass/fail status,
                "total_tests": int,
                "passed": int,
                "failed": int
            }
        """
        yield {"module": "Synapse.core.parallel_test_generator", "message": "I am starting to generate test cases and run them"}
        # Generate test cases
        test_cases = None
        async for event in self.generate_tests_stream(
            task_description=task_description,
            expected_output=expected_output,
            domain=domain,
            num_tests=num_tests
        ):
            yield event
            if event.get("type") == "result":
                test_cases = event.get("result")
        
        if not test_cases:
            logger.warning("No test cases generated")
            yield {"module": "Synapse.core.parallel_test_generator", "message": "I did not generate any test cases"}
            result = {
                "results": [],
                "total_tests": 0,
                "passed": 0,
                "failed": 0
            }
            yield {"type": "result", "result": result}
            return
        
        # 🎯 NEW: Run tests in parallel using LLM semantic validation
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am extracting meaningful output from the actual result for validation"}
        meaningful_output = self._extract_meaningful_output(actual_result)
        
        # Create validation tasks for parallel execution
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am creating validation tasks for {len(test_cases)} test cases"}
        validation_tasks = []
        for test_case in test_cases:
            task = self._validate_test_llm(
                test_case=test_case,
                actual_output=meaningful_output
            )
            validation_tasks.append(task)
        
        # Execute all validations in parallel
        yield {"module": "Synapse.core.parallel_test_generator", "message": "I am running test validations in parallel"}
        validation_results = await asyncio.gather(*validation_tasks, return_exceptions=True)
        
        # Process results
        results = []
        passed_count = 0
        failed_count = 0
        
        for test_case, validation_result in zip(test_cases, validation_results):
            if isinstance(validation_result, Exception):
                logger.error(f"Test validation failed for {test_case.get('name', 'unknown')}: {validation_result}")
                test_result = {
                    **test_case,
                    "passed": False,
                    "error": str(validation_result),
                    "actual_result": meaningful_output[:200],
                    "reasoning": f"Validation error: {validation_result}"
                }
                failed_count += 1
            else:
                passed, reasoning = validation_result
                test_result = {
                    **test_case,
                    "passed": passed,
                    "actual_result": meaningful_output[:200],
                    "reasoning": reasoning
                }
                if passed:
                    passed_count += 1
                else:
                    failed_count += 1
            
            results.append(test_result)
        
        logger.info(f"✅ Test execution complete: {passed_count}/{len(test_cases)} passed, {failed_count} failed")
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I completed test execution: {passed_count}/{len(test_cases)} passed, {failed_count} failed"}
        
        # Full report string: each test with condition, pass/fail, reasoning; then summary
        pct = (100 * passed_count / len(test_cases)) if test_cases else 0
        report_lines = [f"Test execution report: {passed_count}/{len(test_cases)} passed ({pct:.0f}%)"]
        for i, r in enumerate(results, 1):
            status = "PASSED" if r.get('passed', False) else "FAILED"
            cond = r.get('expected_output') or r.get('name', f'Test {i}')
            reason = (r.get('reasoning') or r.get('error') or 'N/A')[:200]
            report_lines.append(f"  Test {i} ({status}): {cond}")
            report_lines.append(f"    Reasoning: {reason}")
        report_lines.append(f"Summary: {passed_count}/{len(test_cases)} passed ({pct:.0f}%)")
        yield {"module": "Synapse.core.parallel_test_generator", "message": "\n".join(report_lines)}
        
        # Log individual failed tests for debugging
        if failed_count > 0:
            logger.debug(f"📋 Failed test details:")
            for result in results:
                if not result.get('passed', False):
                    logger.debug(f"   ❌ {result.get('name', 'Unknown')}: validation={result.get('validation_method', 'N/A')}")
        
        result = {
            "results": results,
            "total_tests": len(test_cases),
            "passed": passed_count,
            "failed": failed_count
        }
        yield {"type": "result", "result": result}
        return
    
    async def generate_and_run(
        self,
        task_description: str,
        expected_output: str,
        domain: str,
        actual_result: Any,
        num_tests: int = 2
    ) -> Dict[str, Any]:
        """Synchronous wrapper for generate_and_run_stream."""
        result = None
        async for event in self.generate_and_run_stream(task_description, expected_output, domain, actual_result, num_tests):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else {
            "results": [],
            "total_tests": 0,
            "passed": 0,
            "failed": 0
        }
    
    async def _validate_test_llm_stream(
        self,
        test_case: Dict[str, Any],
        actual_output: str
    ) -> AsyncGenerator[Dict[str, Any], tuple[bool, str]]:
        """
        Validate a single test using LLM semantic matching.
        
        This is MUCH better than string matching because:
        - Understands semantic equivalence
        - Handles different phrasings
        - More robust to formatting differences
        
        Args:
            test_case: Test case dict with name, expected_output, etc.
            actual_output: The extracted meaningful output
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            (passed: bool, reasoning: str)
        """
        test_name = test_case.get('name', 'Unknown test')
        yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am validating test '{test_name}' using LLM semantic matching"}
        if not self.validator:
            # Fallback to old validation if validator not available
            logger.warning("LLM validator not available, using fallback")
            yield {"module": "Synapse.core.parallel_test_generator", "message": "I noticed LLM validator is not available, using fallback validation"}
            passed = self._run_validation_fallback(test_case, actual_output)
            yield {"type": "result", "result": (passed, "Fallback validation (no LLM)")}
            return
        
        try:
            # Run LLM validation
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"I am running LLM validation for test '{test_name}'"}
            if self.validator_lm:
                with dspy.context(lm=self.validator_lm):
                    result = self.validator(
                        test_name=test_name,
                        expected_criteria=test_case.get('expected_output', ''),
                        actual_output=actual_output[:1000]  # Limit for token efficiency
                    )
            else:
                result = self.validator(
                    test_name=test_name,
                    expected_criteria=test_case.get('expected_output', ''),
                    actual_output=actual_output[:1000]
                )
            
            # Parse result
            passed_str = str(result.passed).lower()
            passed = passed_str in ['true', 'yes', 'pass', 'passed']
            reasoning = str(result.reasoning)
            
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"I completed LLM validation for test '{test_name}': {'PASSED' if passed else 'FAILED'}"}
            yield {"type": "result", "result": (passed, reasoning)}
            return
            
        except Exception as e:
            logger.error(f"LLM validation failed: {e}")
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"I encountered an error during LLM validation: {e}, using fallback"}
            # Fallback to simple validation
            passed = self._run_validation_fallback(test_case, actual_output)
            yield {"type": "result", "result": (passed, f"LLM validation error, used fallback: {e}")}
            return
    
    async def _validate_test_llm(
        self,
        test_case: Dict[str, Any],
        actual_output: str
    ) -> tuple[bool, str]:
        """Synchronous wrapper for _validate_test_llm_stream."""
        result = None
        async for event in self._validate_test_llm_stream(test_case, actual_output):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else (False, "No validation result")
    
    def _run_validation_fallback(
        self,
        test_case: Dict[str, Any],
        actual_output: str
    ) -> bool:
        """
        Fallback validation using simple string matching.
        Only used if LLM validation fails.
        """
        try:
            actual_str = actual_output.lower()
            expected = str(test_case.get('expected_output', '')).lower()
            
            # Simple content matching
            return expected[:50] in actual_str or actual_str[:50] in expected
            
        except Exception as e:
            logger.error(f"Fallback validation failed: {e}")
            return False
    
    def _run_validation(
        self,
        validation_method: str,
        test_case: Dict[str, Any],
        actual_result: Any
    ) -> bool:
        """
        Run a single test validation based on the validation method.
        
        Args:
            validation_method: Type of validation to perform
            test_case: Test case details
            actual_result: Actual result to validate
        
        Returns:
            True if test passed, False otherwise
        """
        try:
            # 🎯 FIX: Extract meaningful output from EpisodeResult if present
            actual_output = self._extract_meaningful_output(actual_result)
            actual_str = str(actual_output).lower()
            expected = str(test_case.get('expected_output', '')).lower()
            
            # 🎯 FIX: Normalize validation method names (handle LLM creativity)
            # Map custom methods to standard ones
            normalized_method = validation_method.lower()
            if 'page_load' in normalized_method or 'url' in normalized_method:
                normalized_method = 'content_match'
            elif 'element_count' in normalized_method or 'count' in normalized_method:
                normalized_method = 'content_match'
            elif 'zero_state' in normalized_method or 'empty' in normalized_method:
                normalized_method = 'content_match'
            
            if normalized_method == 'file_exists':
                # Check if result mentions file creation/existence
                return 'file' in actual_str or 'created' in actual_str or 'saved' in actual_str
            
            elif normalized_method == 'content_match':
                # Simple string matching
                return expected in actual_str or actual_str in expected
            
            elif normalized_method == 'regex_match':
                # Basic pattern matching (simplified)
                import re
                pattern = test_case.get('pattern', expected)
                return bool(re.search(pattern, actual_str, re.IGNORECASE))
            
            elif normalized_method == 'format_check':
                # Check if result has expected format indicators
                format_indicators = ['json', 'csv', 'xml', 'html', 'text']
                return any(fmt in actual_str for fmt in format_indicators)
            
            else:
                # Default: simple content matching
                return expected in actual_str
                
        except Exception as e:
            logger.error(f"Validation failed: {e}")
            return False
    
    def _extract_meaningful_output(self, result: Any) -> str:
        """
        Extract meaningful output from complex result objects.
        
        Handles:
        - EpisodeResult objects (extract from trajectory, tagged_outputs, or output.rationale)
        - dict with 'output', 'result', or 'success' keys
        - Direct string/primitive values
        
        Args:
            result: The result object to extract from
        
        Returns:
            Meaningful string representation
        """
        try:
            # Handle EpisodeResult objects (most common in Synapse)
            if hasattr(result, 'trajectory') and isinstance(result.trajectory, list):
                # 🎯 PRIORITY 1: Extract from trajectory observations (most detailed)
                # Trajectory contains all tool calls and observations
                observations = []
                for step in result.trajectory:
                    if isinstance(step, dict):
                        # Look for observation or output keys
                        if 'observation' in step:
                            observations.append(str(step['observation']))
                        elif 'output' in step:
                            observations.append(str(step['output']))
                        elif 'result' in step:
                            observations.append(str(step['result']))
                
                if observations:
                    # Return the last few observations (most recent are most relevant)
                    return " | ".join(observations[-3:])  # Last 3 observations
                
                # 🎯 PRIORITY 2: Check tagged_outputs
                if hasattr(result, 'tagged_outputs') and result.tagged_outputs:
                    tagged = []
                    for tagged_output in result.tagged_outputs[-3:]:  # Last 3
                        if hasattr(tagged_output, 'output'):
                            tagged.append(str(tagged_output.output))
                    if tagged:
                        return " | ".join(tagged)
            
            # 🎯 PRIORITY 3: Extract from output (Prediction object from DSPy)
            if hasattr(result, 'output'):
                output = result.output
                
                # 🎯 NEW: If output is a Prediction, extract its string representation better
                if hasattr(output, '__class__') and 'Prediction' in output.__class__.__name__:
                    # Try to get the actual fields from Prediction
                    if hasattr(output, 'rationale'):
                        return str(output.rationale)
                    elif hasattr(output, 'answer'):
                        return str(output.answer)
                    elif hasattr(output, 'response'):
                        return str(output.response)
                    elif hasattr(output, 'result'):
                        return str(output.result)
                    
                    # If Prediction has trajectory, get last meaningful step
                    if hasattr(output, 'trajectory') and isinstance(output.trajectory, dict):
                        trajectory = output.trajectory
                        # Get the last observation or thought
                        observations = [v for k, v in trajectory.items() if k.startswith('observation_')]
                        if observations:
                            return str(observations[-1])
                        thoughts = [v for k, v in trajectory.items() if k.startswith('thought_')]
                        if thoughts:
                            return str(thoughts[-1])
                
                # Check output.trajectory (dict format) for non-Prediction outputs
                if hasattr(output, 'trajectory') and isinstance(output.trajectory, dict):
                    trajectory = output.trajectory
                    # Get the last observation or thought
                    observations = [v for k, v in trajectory.items() if k.startswith('observation_')]
                    if observations:
                        return str(observations[-1])
                    thoughts = [v for k, v in trajectory.items() if k.startswith('thought_')]
                    if thoughts:
                        return str(thoughts[-1])
                
                # Try to get rationale or final answer
                if hasattr(output, 'rationale') and output.rationale:
                    rationale = str(output.rationale)
                    # If rationale is too generic, try to get more context
                    if len(rationale) < 20 and hasattr(result, 'trajectory'):
                        # Rationale is too short, use trajectory instead
                        pass  # Will fall through to dict handling
                    else:
                        return rationale
                elif hasattr(output, 'answer'):
                    return str(output.answer)
                
                # Fallback: stringify output (but avoid full Prediction dump)
                output_str = str(output)
                # If it's a long Prediction dump, just take first meaningful part
                if 'Prediction(' in output_str and len(output_str) > 500:
                    # Try to extract just the first thought or observation
                    if "'thought_0':" in output_str:
                        start = output_str.find("'thought_0':") + 14
                        end = output_str.find("'", start + 1)
                        if end > start:
                            return output_str[start:end]
                return output_str[:500]  # Truncate long dumps
            
            # Handle dict results
            elif isinstance(result, dict):
                # Look for common output keys
                for key in ['output', 'result', 'answer', 'response', 'message']:
                    if key in result:
                        return str(result[key])
                
                # If has 'success' key, include it
                if 'success' in result:
                    return f"Success: {result['success']}, {result.get('message', '')}"
                
                # Fallback: stringify dict
                return str(result)
            
            # Direct value
            return str(result)
            
        except Exception as e:
            logger.warning(f"Failed to extract meaningful output: {e}")
            return str(result)
