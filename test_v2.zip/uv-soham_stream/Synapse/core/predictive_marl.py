"""
Predictive Multi-Agent RL for ReVal
====================================

THE VISION:
- Each agent predicts what OTHER agents will do
- Compare predictions with actual outcomes  
- Learn from divergence (like weight updates)
- Emergent cooperation through predictive modeling

THE KEY INSIGHT:
LLM IS the DQN. Prompts ARE weights. Divergence learning updates prompts.

Traditional RL: θ ← θ - α * ∇L(predicted, actual)
Agentic RL:     prompt ← prompt + "When predicted X but got Y, learn..."

This is IN-CONTEXT LEARNING as WEIGHT UPDATE.
"""

import json
import time
import math
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import logging

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

logger = logging.getLogger(__name__)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class PredictedAction:
    """Predicted action by an agent."""
    agent_name: str
    action_type: str  # What action they'll take
    action_params: Dict[str, Any]
    confidence: float
    reasoning: str


@dataclass
class PredictedTrajectory:
    """Predicted sequence of agent actions."""
    horizon: int
    steps: List[Dict[str, Any]]  # Each step: {agent, action, predicted_state}
    predicted_reward: float
    confidence: float
    timestamp: float = field(default_factory=time.time)


@dataclass
class ActualTrajectory:
    """What actually happened."""
    steps: List[Dict[str, Any]]
    actual_reward: float
    timestamp: float = field(default_factory=time.time)


@dataclass
class Divergence:
    """Divergence between predicted and actual."""
    predicted: PredictedTrajectory
    actual: ActualTrajectory
    
    # Divergence metrics
    action_divergence: float      # How different were actions?
    state_divergence: float       # How different were states?
    reward_divergence: float      # How different was reward?
    
    # Information content (higher = more surprising = more valuable)
    information_content: float
    
    # Extracted learning
    learning: str
    
    # Divergence weights — configurable via class-level overrides or config
    ACTION_WEIGHT: float = 0.4
    STATE_WEIGHT: float = 0.3
    REWARD_WEIGHT: float = 0.3
    
    def total_divergence(self) -> float:
        """Weighted total divergence (weights configurable via class attrs)."""
        return (self.ACTION_WEIGHT * self.action_divergence + 
                self.STATE_WEIGHT * self.state_divergence + 
                self.REWARD_WEIGHT * self.reward_divergence)


@dataclass 
class AgentModel:
    """Model of another agent's behavior (Theory of Mind)."""
    agent_name: str
    
    # Behavioral patterns learned
    action_patterns: List[Dict[str, Any]] = field(default_factory=list)
    
    # When this agent tends to deviate from predictions
    deviation_patterns: List[Dict[str, Any]] = field(default_factory=list)
    
    # Cooperation style
    cooperation_score: float = 0.5  # 0 = competitive, 1 = cooperative
    predictability_score: float = 0.5  # 0 = chaotic, 1 = predictable
    
    # Statistics
    total_predictions: int = 0
    correct_predictions: int = 0
    
    @property
    def accuracy(self) -> float:
        if self.total_predictions == 0:
            return 0.5
        return self.correct_predictions / self.total_predictions


# =============================================================================
# LLM TRAJECTORY PREDICTOR
# =============================================================================

class TrajectoryPredictionSignature(dspy.Signature):
    """
    Predict what will happen over the next H steps in a multi-agent system.
    
    You are predicting the FUTURE trajectory of a multi-agent swarm.
    Think about:
    1. What will the current agent do?
    2. How will this affect the state?
    3. What will OTHER agents do in response?
    4. What will be the final outcome?
    """
    
    current_state = dspy.InputField(
        desc="Current state: TODO progress, agent states, recent history"
    )
    acting_agent = dspy.InputField(
        desc="Which agent is about to act"
    )
    proposed_action = dspy.InputField(
        desc="The action the agent is considering"
    )
    other_agents = dspy.InputField(
        desc="List of other agents and their recent behaviors"
    )
    agent_models = dspy.InputField(
        desc="Models of other agents' typical behaviors and cooperation styles"
    )
    horizon = dspy.InputField(
        desc="How many steps ahead to predict"
    )
    goal = dspy.InputField(
        desc="The final goal we're trying to achieve"
    )
    
    step_by_step_prediction = dspy.OutputField(
        desc="Step-by-step prediction: For each step, predict {agent, action, resulting_state}"
    )
    predicted_trajectory = dspy.OutputField(
        desc="JSON list of predicted steps: [{agent, action, state}, ...]"
    )
    predicted_final_reward = dspy.OutputField(
        desc="Predicted reward at the end (0.0 to 1.0)"
    )
    prediction_confidence = dspy.OutputField(
        desc="How confident are you in this prediction? (0.0 to 1.0)"
    )
    cooperation_assessment = dspy.OutputField(
        desc="Will agents cooperate well? What might go wrong?"
    )


class LLMTrajectoryPredictor:
    """
    LLM-based trajectory prediction for multi-agent systems.
    
    This is the DQN equivalent for agentic systems:
    - DQN: Neural network predicts Q(s,a)
    - This: LLM predicts trajectory and reward given (state, action, other_agents)
    
    The key innovation: LLM can REASON about other agents' intentions,
    not just pattern-match like a traditional DQN.
    """
    
    def __init__(self, config, horizon: int = 5):
        self.config = config
        self.horizon = horizon
        self.predictor = dspy.ChainOfThought(TrajectoryPredictionSignature) if DSPY_AVAILABLE else None
        
        # Experience buffer for learning
        self.experience_buffer: List[Tuple[PredictedTrajectory, ActualTrajectory]] = []
        self.max_buffer_size = 100
        
        # Learned patterns (this IS the "weights")
        self.learned_patterns: List[str] = []
        self.agent_models: Dict[str, AgentModel] = {}
        
        logger.info(f"🔮 LLMTrajectoryPredictor initialized (horizon={horizon})")
    
    def predict(
        self,
        current_state: Dict[str, Any],
        acting_agent: str,
        proposed_action: Dict[str, Any],
        other_agents: List[str],
        goal: str
    ) -> PredictedTrajectory:
        """
        Predict trajectory over horizon H.
        
        This is the forward pass of our "DQN".
        """
        if not self.predictor:
            return self._fallback_prediction()
        
        # Get agent models
        models_str = self._format_agent_models(other_agents)
        
        # Add learned patterns to prompt (this is the "weight injection")
        patterns_context = self._format_learned_patterns()
        
        try:
            result = self.predictor(
                current_state=json.dumps(current_state, default=str),
                acting_agent=acting_agent,
                proposed_action=json.dumps(proposed_action, default=str),
                other_agents=json.dumps(other_agents),
                agent_models=models_str,
                horizon=str(self.horizon),
                goal=goal + f"\n\nLEARNED PATTERNS:\n{patterns_context}"
            )
            
            # Parse prediction
            try:
                steps = json.loads(result.predicted_trajectory or "[]")
            except (json.JSONDecodeError, TypeError):
                steps = []
            
            reward = self._parse_float(result.predicted_final_reward, 0.5)
            confidence = self._parse_float(result.prediction_confidence, 0.5)
            
            return PredictedTrajectory(
                horizon=self.horizon,
                steps=steps,
                predicted_reward=reward,
                confidence=confidence
            )
            
        except Exception as e:
            logger.warning(f"Trajectory prediction failed: {e}")
            return self._fallback_prediction()
    
    def compute_divergence(
        self,
        predicted: PredictedTrajectory,
        actual: ActualTrajectory
    ) -> Divergence:
        """
        Compute divergence between predicted and actual trajectories.
        
        This is analogous to computing loss in traditional RL.
        """
        # Action divergence: How different were the actions?
        action_div = self._compute_action_divergence(
            predicted.steps, actual.steps
        )
        
        # State divergence: How different were the states?
        state_div = self._compute_state_divergence(
            predicted.steps, actual.steps
        )
        
        # Reward divergence
        reward_div = abs(predicted.predicted_reward - actual.actual_reward)
        
        # Information content: -log P(actual | predicted)
        # Higher divergence = higher information = more surprising
        total_div = 0.4 * action_div + 0.3 * state_div + 0.3 * reward_div
        info_content = -math.log(max(0.01, 1 - total_div))
        
        # Extract learning from divergence
        learning = self._extract_learning(predicted, actual, total_div)
        
        return Divergence(
            predicted=predicted,
            actual=actual,
            action_divergence=action_div,
            state_divergence=state_div,
            reward_divergence=reward_div,
            information_content=info_content,
            learning=learning
        )
    
    def update_from_divergence(self, divergence: Divergence):
        """
        Update predictor based on divergence.
        
        THIS IS THE KEY INNOVATION:
        Traditional RL: θ ← θ - α * ∇L
        Agentic RL: self.learned_patterns.append(learning)
        
        The "weight update" happens by modifying the context/prompt.
        """
        # A-TEAM FIX: Learn from moderate-to-high information divergences
        # Previous threshold of 0.5 was too high, missing important learnings
        # -log(1-0.3) ≈ 0.36, so this catches divergences >= 30%
        if divergence.information_content < 0.2:
            return
        
        # Add to learned patterns
        self.learned_patterns.append(divergence.learning)
        
        # Keep patterns bounded (forget old ones) - A-TEAM FIX: was NO-OP before!
        if len(self.learned_patterns) > 50:
            self.learned_patterns = self.learned_patterns[-50:]
        
        # Update agent models
        self._update_agent_models(divergence)
        
        # A-TEAM FIX: Meta-prompt update - generate consolidated learning insight
        if len(self.learned_patterns) % 10 == 0 and len(self.learned_patterns) > 0:
            self._consolidate_learnings()
        
        logger.info(f"📚 Learned: {divergence.learning}...")
    
    def _compute_action_divergence(
        self, 
        predicted_steps: List[Dict], 
        actual_steps: List[Dict]
    ) -> float:
        """Compute how different the actions were."""
        if not predicted_steps or not actual_steps:
            return 0.5
        
        matches = 0
        total = min(len(predicted_steps), len(actual_steps))
        
        for i in range(total):
            pred_agent = predicted_steps[i].get('agent', '')
            actual_agent = actual_steps[i].get('agent', '')
            
            pred_action = predicted_steps[i].get('action', '')
            actual_action = actual_steps[i].get('action', '')
            
            if pred_agent == actual_agent:
                matches += 0.5
            if str(pred_action) == str(actual_action):
                matches += 0.5
        
        return 1 - (matches / total) if total > 0 else 0.5
    
    def _compute_state_divergence(
        self,
        predicted_steps: List[Dict],
        actual_steps: List[Dict]
    ) -> float:
        """Compute how different the states were."""
        # Simplified: compare final states
        if not predicted_steps or not actual_steps:
            return 0.5
        
        pred_final = predicted_steps[-1].get('state', {})
        actual_final = actual_steps[-1].get('state', {})
        
        # Simple key overlap comparison
        pred_keys = set(str(pred_final).split())
        actual_keys = set(str(actual_final).split())
        
        if not pred_keys or not actual_keys:
            return 0.5
        
        overlap = len(pred_keys & actual_keys)
        total = len(pred_keys | actual_keys)
        
        return 1 - (overlap / total) if total > 0 else 0.5
    
    def _extract_learning(
        self,
        predicted: PredictedTrajectory,
        actual: ActualTrajectory,
        divergence: float
    ) -> str:
        """Extract human-readable learning from divergence."""
        if divergence < 0.2:
            return "Prediction was accurate - patterns confirmed"
        
        # What was different?
        differences = []
        
        for i, (pred, act) in enumerate(zip(predicted.steps, actual.steps)):
            pred_agent = pred.get('agent', '')
            act_agent = act.get('agent', '')
            
            # ✅ FIX: Only log if we have actual agent data
            if pred_agent and act_agent and pred_agent != act_agent:
                differences.append(
                    f"Step {i}: Expected {pred_agent} but {act_agent} acted"
                )
            elif pred_agent and act_agent and pred.get('action') != act.get('action'):
                differences.append(
                    f"Step {i}: {pred_agent} did {act.get('action')} not {pred.get('action')}"
                )
        
        if predicted.predicted_reward > actual.actual_reward + 0.2:
            differences.append(
                f"Outcome worse than expected ({actual.actual_reward:.2f} vs {predicted.predicted_reward:.2f})"
            )
        elif predicted.predicted_reward < actual.actual_reward - 0.2:
            differences.append(
                f"Outcome better than expected ({actual.actual_reward:.2f} vs {predicted.predicted_reward:.2f})"
            )
        
        if differences:
            return "; ".join(differences)
        return "Minor divergence in execution details"
    
    def update_agent_model(self, agent_name: str, divergence: Divergence):
        """
        Public method to update agent behavior model based on divergence.
        
        This is the public API called by Conductor to update agent models
        when divergence is detected between predicted and actual trajectories.
        
        Args:
            agent_name: Name of the agent whose model to update (for logging/tracking)
            divergence: Divergence object containing predicted vs actual trajectories
        
        Note:
            The agent_name parameter is used for logging, but the method updates
            all agent models found in the divergence. This allows learning from
            multi-agent interactions.
        """
        # Delegate to private method to update all agent models
        self._update_agent_models(divergence)
        
        # Log the update for the specific agent if requested
        if agent_name and agent_name in self.agent_models:
            model = self.agent_models[agent_name]
            logger.debug(
                f"📊 Updated model for {agent_name}: "
                f"{model.correct_predictions}/{model.total_predictions} correct predictions"
            )
    
    def _update_agent_models(self, divergence: Divergence):
        """Update models of agent behavior."""
        for step_pred, step_actual in zip(
            divergence.predicted.steps,
            divergence.actual.steps
        ):
            agent = step_actual.get('agent', '')
            if not agent:
                continue
            
            if agent not in self.agent_models:
                self.agent_models[agent] = AgentModel(agent_name=agent)
            
            model = self.agent_models[agent]
            model.total_predictions += 1
            
            # Was prediction correct?
            if step_pred.get('action') == step_actual.get('action'):
                model.correct_predictions += 1
            else:
                # Record deviation pattern
                model.deviation_patterns.append({
                    'predicted': step_pred.get('action'),
                    'actual': step_actual.get('action'),
                    'context': step_pred.get('state', {}),
                    'timestamp': time.time()
                })
                # Keep bounded
                if len(model.deviation_patterns) > 20:
                    model.deviation_patterns = model.deviation_patterns[-20:]
    
    def _format_agent_models(self, agents: List[str]) -> str:
        """Format agent models for prompt injection."""
        models_str = []
        for agent in agents:
            if agent in self.agent_models:
                model = self.agent_models[agent]
                models_str.append(
                    f"- {agent}: accuracy={model.accuracy:.2f}, "
                    f"predictability={model.predictability_score:.2f}"
                )
                if model.deviation_patterns:
                    recent = model.deviation_patterns[-5:]  # A-TEAM FIX: Only show recent deviations, not all
                    for dev in recent:
                        models_str.append(
                            f"  └ Recently: predicted {dev['predicted']} but did {dev['actual']}"
                        )
        return "\n".join(models_str) if models_str else "No agent models yet"
    
    def _format_learned_patterns(self) -> str:
        """Format learned patterns for prompt injection."""
        if not self.learned_patterns:
            return "No patterns learned yet"
        
        # A-TEAM FIX: Only use recent patterns (was returning ALL before)
        recent = self.learned_patterns[-15:]
        
        # Include consolidated insights if available
        parts = []
        if hasattr(self, '_consolidated_insights') and self._consolidated_insights:
            parts.append("CONSOLIDATED INSIGHTS:")
            for insight in self._consolidated_insights[-3:]:
                parts.append(f"  ★ {insight}")
            parts.append("")
        
        parts.append("RECENT OBSERVATIONS:")
        for p in recent:
            parts.append(f"  - {p}")
        
        return "\n".join(parts)
    
    def _consolidate_learnings(self):
        """
        A-TEAM META-PROMPT UPDATE:
        Periodically consolidate learned patterns into higher-level insights.
        
        This is the "reflection tuning" the user requested - the system learns
        from its own divergences and updates its meta-understanding.
        
        Traditional RL: Periodic target network update
        Agentic RL: LLM consolidates observations into principles
        """
        if not DSPY_AVAILABLE or not self.learned_patterns:
            return
        
        if not hasattr(self, '_consolidated_insights'):
            self._consolidated_insights: List[str] = []
        
        try:
            # Use LLM to consolidate recent patterns into insights
            consolidator = dspy.ChainOfThought("patterns: str -> consolidated_insight: str, prediction_improvement: str")
            
            recent_patterns = self.learned_patterns[-20:]
            patterns_text = "\n".join(f"- {p}" for p in recent_patterns)
            
            result = consolidator(
                patterns=f"These are observations from comparing predicted vs actual agent behaviors:\n{patterns_text}\n\nConsolidate into a single actionable insight for improving future predictions."
            )
            
            insight = result.consolidated_insight
            if insight and len(insight) > 10:
                self._consolidated_insights.append(insight)
                # Keep bounded
                if len(self._consolidated_insights) > 10:
                    self._consolidated_insights = self._consolidated_insights[-10:]
                
                logger.info(f"🧠 META-PROMPT UPDATE: Consolidated learning → {insight[:100]}...")
                logger.info(f"   Prediction improvement hint: {result.prediction_improvement[:100]}...")
            
        except Exception as e:
            logger.debug(f"Consolidation failed (non-critical): {e}")
    
    def _fallback_prediction(self) -> PredictedTrajectory:
        """Fallback when LLM not available."""
        return PredictedTrajectory(
            horizon=self.horizon,
            steps=[],
            predicted_reward=0.5,
            confidence=0.3
        )
    
    def _parse_float(self, s: str, default: float) -> float:
        """Parse float from string - A-Team approved, no regex."""
        from .robust_parsing import parse_float_robust
        result = parse_float_robust(s, default=default)
        if result is not None:
            return max(0.0, min(1.0, result))
        return default
    
    # 🔴 A-TEAM FIX: Add persistence support for MARL state
    def to_dict(self) -> Dict[str, Any]:
        """Serialize learnable MARL state for persistence."""
        agent_models_data = {}
        for name, model in self.agent_models.items():
            agent_models_data[name] = {
                'agent_name': model.agent_name,
                'action_patterns': model.action_patterns[-20:],  # Keep recent
                'deviation_patterns': model.deviation_patterns[-20:],
                'cooperation_score': model.cooperation_score,
                'predictability_score': model.predictability_score,
                'total_predictions': model.total_predictions,
                'correct_predictions': model.correct_predictions
            }
        
        return {
            'learned_patterns': self.learned_patterns[-50:],  # Bounded
            'agent_models': agent_models_data,
            'consolidated_insights': getattr(self, '_consolidated_insights', []),
            'horizon': self.horizon,
            'timestamp': time.time()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], config) -> 'LLMTrajectoryPredictor':
        """Restore MARL state from persisted data."""
        predictor = cls(config, horizon=data.get('horizon', 5))
        predictor.learned_patterns = data.get('learned_patterns', [])
        predictor._consolidated_insights = data.get('consolidated_insights', [])
        
        for name, model_data in data.get('agent_models', {}).items():
            predictor.agent_models[name] = AgentModel(
                agent_name=model_data.get('agent_name', name),
                action_patterns=model_data.get('action_patterns', []),
                deviation_patterns=model_data.get('deviation_patterns', []),
                cooperation_score=model_data.get('cooperation_score', 0.5),
                predictability_score=model_data.get('predictability_score', 0.5),
                total_predictions=model_data.get('total_predictions', 0),
                correct_predictions=model_data.get('correct_predictions', 0)
            )
        
        logger.info(f"🔮 MARL state restored: {len(predictor.learned_patterns)} patterns, "
                    f"{len(predictor.agent_models)} agent models")
        return predictor


# =============================================================================
# DIVERGENCE MEMORY
# =============================================================================

class DivergenceMemory:
    """
    Memory that stores prediction-vs-reality divergences.
    
    Key insight from Shannon: Store by INFORMATION CONTENT, not recency.
    High-surprise events are more valuable for learning.
    """
    
    def __init__(self, config, max_size: int = 500):
        self.config = config
        self.max_size = max_size
        self.memories: List[Divergence] = []
    
    def store(self, divergence: Divergence):
        """Store divergence, prioritizing high-information ones."""
        self.memories.append(divergence)
        
        # Evict by information content (keep surprising ones)
        if len(self.memories) > self.max_size:
            # Sort by information content (ascending)
            self.memories.sort(key=lambda d: d.information_content)
            # Remove lowest information ones
            self.memories = self.memories[len(self.memories) - self.max_size:]
    
    def get_relevant(self, state: Dict[str, Any], k: int = 5) -> List[Divergence]:
        """Get most relevant divergences for current state."""
        # Simple: return highest information ones
        sorted_by_info = sorted(
            self.memories,
            key=lambda d: d.information_content,
            reverse=True
        )
        return sorted_by_info[:k]
    
    def get_patterns_for_agent(self, agent_name: str) -> List[str]:
        """Get learned patterns related to specific agent."""
        patterns = []
        for div in self.memories:
            if any(s.get('agent') == agent_name for s in div.predicted.steps):
                patterns.append(div.learning)
        return patterns  # Recent ones


# =============================================================================
# COOPERATIVE CREDIT ASSIGNER
# =============================================================================

class CooperativeCreditAssigner:
    """
    Assign credit based on COOPERATION, not just individual success.
    
    Key insight: An agent that helps others succeed deserves credit,
    even if their own task seemed unimportant.
    
    A-Team v8.0: No hardcoded weights! Uses adaptive learned weights.
    A-Team v9.0: Enhanced with Shapley concepts (variance tracking, auto-tuning, caching)
    """
    
    def __init__(self, config):
        self.config = config
        
        # A-Team v8.0: Adaptive weights instead of hardcoded 0.3, 0.2
        from .robust_parsing import AdaptiveThreshold
        self.coop_weight_tracker = AdaptiveThreshold(initial_mean=0.3, initial_std=0.1)
        self.pred_weight_tracker = AdaptiveThreshold(initial_mean=0.2, initial_std=0.1)
        
        # 🔬 A-TEAM v9.0: Shapley-inspired enhancements
        self.credit_history = []  # Track credit assignments for variance analysis
        self.agent_contribution_cache = {}  # Cache agent contributions
        self.min_samples = 3  # Min episodes before computing variance
        self.max_samples = 20  # Max episodes to keep in history
    
    def assign_credit(
        self,
        trajectory: ActualTrajectory,
        predictions: Dict[str, PredictedTrajectory],
        final_reward: float
    ) -> Dict[str, float]:
        """
        Assign credit to each agent.
        
        Credit = (task_success) * (cooperation_factor) * (prediction_factor)
        
        A-Team v8.0: Weights are adaptive, not hardcoded.
        """
        credits = {}
        
        # Get current adaptive weights
        coop_weight = self.coop_weight_tracker.mean
        pred_weight = self.pred_weight_tracker.mean
        
        for step in trajectory.steps:
            agent = step.get('agent', '')
            if not agent:
                continue
            
            # Base credit from task success
            task_success = step.get('success', 0.5)
            
            # Cooperation bonus: Did this agent's action help others?
            coop_bonus = self._compute_cooperation_bonus(
                agent, step, trajectory.steps
            )
            
            # Prediction accuracy bonus: Was this agent predictable?
            pred_bonus = self._compute_prediction_bonus(
                agent, step, predictions.get(agent)
            )
            
            # A-Team v8.0: Use adaptive weights
            credits[agent] = task_success * (1 + coop_weight * coop_bonus) * (1 + pred_weight * pred_bonus)
        
        # Normalize
        total = sum(credits.values())
        if total > 0:
            credits = {k: v / total * final_reward for k, v in credits.items()}
        
        # Update adaptive weights based on this episode's outcome
        if final_reward > 0.5:
            # Success - current weights worked, strengthen them
            avg_coop = sum(self._compute_cooperation_bonus(a, s, trajectory.steps) 
                          for a, s in [(step.get('agent', ''), step) for step in trajectory.steps]
                          if a) / max(1, len(trajectory.steps))
            self.coop_weight_tracker.update(avg_coop)
            
            # 🔴 A-TEAM FIX: Also update pred_weight_tracker based on prediction accuracy
            # Previously only coop_weight was updated — prediction weight never adapted!
            avg_pred = sum(
                self._compute_prediction_bonus(
                    step.get('agent', ''), step, predictions.get(step.get('agent', ''))
                )
                for step in trajectory.steps if step.get('agent')
            ) / max(1, len(trajectory.steps))
            self.pred_weight_tracker.update(avg_pred)
        
        return credits
    
    def _compute_cooperation_bonus(
        self,
        agent: str,
        step: Dict,
        all_steps: List[Dict]
    ) -> float:
        """
        Bonus for helping other agents succeed.
        
        Uses ACTUAL cooperation signals (help_given/help_received) from AgentSlack
        rather than arbitrary ordering in the steps list.
        """
        help_given = step.get('help_given', 0)
        help_received = step.get('help_received', 0)
        
        # If this agent gave help, it contributed to others' success
        if help_given > 0:
            # Count how many agents this one helped that succeeded
            other_successes = sum(
                1 for s in all_steps 
                if s.get('agent') != agent and s.get('success', False)
            )
            other_count = sum(1 for s in all_steps if s.get('agent') != agent)
            
            if other_count > 0:
                # Cooperation bonus = help_given normalized * success rate of others
                success_rate = other_successes / other_count
                # Scale by how much help was given (diminishing returns)
                help_factor = min(1.0, help_given / max(1, other_count))
                return help_factor * success_rate
        
        # Even without explicit help_given, check if this agent's success
        # correlated with subsequent agents succeeding (indirect cooperation)
        if step.get('success', False):
            other_successes = sum(
                1 for s in all_steps
                if s.get('agent') != agent and s.get('success', False)
            )
            other_count = sum(1 for s in all_steps if s.get('agent') != agent)
            if other_count > 0:
                # Small indirect cooperation bonus (agent succeeded, others also succeeded)
                indirect_bonus = getattr(self.config, 'indirect_cooperation_bonus', 0.2)
                return indirect_bonus * (other_successes / other_count)
        
        return 0.0
    
    def _compute_prediction_bonus(
        self,
        agent: str,
        actual_step: Dict,
        prediction: Optional[PredictedTrajectory]
    ) -> float:
        """Bonus for being predictable (helps others plan)."""
        if not prediction or not prediction.steps:
            return 0.0
        
        # Find predicted step for this agent
        for pred_step in prediction.steps:
            if pred_step.get('agent') == agent:
                if pred_step.get('action') == actual_step.get('action'):
                    return 1.0
                else:
                    return 0.0
        return 0.0
    
    # =========================================================================
    # 🔬 A-TEAM v9.0: SHAPLEY-INSPIRED ENHANCEMENTS
    # Salvaged from algorithmic_credit.py before deletion
    # =========================================================================
    
    def _compute_credit_variance(self, agent: str) -> tuple:
        """
        Compute variance and confidence interval for agent's credit.
        
        Returns: (mean, variance, ci_half_width, confidence)
        """
        agent_credits = [
            episode.get(agent, 0.0)
            for episode in self.credit_history
            if agent in episode
        ]
        
        if len(agent_credits) < self.min_samples:
            return (0.0, 1.0, 1.0, 0.0)
        
        mean = sum(agent_credits) / len(agent_credits)
        variance = sum((x - mean) ** 2 for x in agent_credits) / (len(agent_credits) - 1)
        
        import math
        std_error = math.sqrt(variance / len(agent_credits))
        ci_half_width = 1.96 * std_error
        confidence = max(0.0, min(1.0, 1.0 - ci_half_width))
        
        return (mean, variance, ci_half_width, confidence)
    
    def record_episode(self, credits: Dict[str, float]):
        """Record episode credits for variance tracking."""
        self.credit_history.append(credits.copy())
        if len(self.credit_history) > self.max_samples:
            self.credit_history = self.credit_history[-self.max_samples:]
        
        for agent, credit in credits.items():
            if agent not in self.agent_contribution_cache:
                self.agent_contribution_cache[agent] = []
            self.agent_contribution_cache[agent].append(credit)
            if len(self.agent_contribution_cache[agent]) > self.max_samples:
                self.agent_contribution_cache[agent] = \
                    self.agent_contribution_cache[agent][-self.max_samples:]


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PredictedAction',
    'PredictedTrajectory',
    'ActualTrajectory',
    'Divergence',
    'AgentModel',
    'LLMTrajectoryPredictor',
    'DivergenceMemory',
    'CooperativeCreditAssigner'
]

