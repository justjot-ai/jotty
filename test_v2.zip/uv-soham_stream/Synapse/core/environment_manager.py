"""
Environment Manager for Synapse - Context Tracking with CoT Summarization

Provides environment state tracking with automatic summarization using DSpy CoT agent.
Maintains env.md file that gets periodically summarized to keep context fresh.

A-Team Design Principles:
- NO HARDCODING: All paths configurable
- Automatic summarization every 1 minute
- Thread-safe operations
- Natural language context tracking
"""
import dspy
import json
import time
import logging
import threading
import queue
from pathlib import Path
from typing import Optional, Dict, Any, AsyncGenerator
from datetime import datetime
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class EnvironmentSummarizationSignature(dspy.Signature):
    """Chain-of-Thought signature for summarizing environment context."""
    
    current_content = dspy.InputField(desc="Current content of environment.md file")
    goal_context = dspy.InputField(desc="The root goal/task being worked on")
    timestamp = dspy.InputField(desc="Current timestamp for reference")
    
    reasoning = dspy.OutputField(desc="Step-by-step reasoning about what's important to keep")
    summarized_content = dspy.OutputField(desc="Summarized and condensed environment context")
    key_insights = dspy.OutputField(desc="Key insights or patterns detected in the environment")
    pruned_items = dspy.OutputField(desc="What was removed and why")


@dataclass
class EnvironmentSnapshot:
    """Snapshot of environment state at a point in time."""
    content: str
    timestamp: float
    size_bytes: int
    line_count: int


class EnvironmentManager:
    """
    Manages environment context with automatic CoT-based summarization.
    
    KEY FEATURES:
    - Persistent env.md file stored alongside Q-tables
    - Automatic summarization when file exceeds 10KB to keep context fresh
    - Thread-safe read/write operations
    - Chain-of-Thought reasoning for intelligent summarization
    - Maintains history of environment snapshots
    
    ✅ GENERIC: No domain-specific logic, works for any use case.
    """
    
    def __init__(self, config, goal_context: str = "General task execution"):
        """
        Initialize Environment Manager.
        
        Args:
            config: Synapse configuration object with paths
            goal_context: Description of the current goal/task
        """
        self.config = config
        self.goal_context = goal_context
        
        # Thread safety - MUST be created first before any file operations
        self._lock = threading.Lock()
        
        # Lazy-load CoT summarizer (defer until first use to ensure DSPy is configured)
        self._summarizer = None
        
        # Determine storage path (same location as q_tables)
        self.env_dir = self._get_env_directory()
        self.env_file = self.env_dir / "env.md"
        self.history_file = self.env_dir / "env_history.json"
        
        # Ensure directory exists
        self.env_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize env.md if it doesn't exist
        if not self.env_file.exists():
            self._initialize_env_file()
        
        # Summarization settings
        self.summarization_interval = getattr(config, 'env_summarization_interval', 60)  # 1 minute default
        self.max_size_before_summarize = getattr(config, 'env_max_size_bytes', 10_240)  # 10KB default (triggers more frequently)
        self.min_lines_before_summarize = getattr(config, 'env_min_lines', 50)  # Minimum lines before summarizing
        
        # History tracking
        self.snapshots = []
        self.max_snapshots = getattr(config, 'env_max_snapshots', 10)
        
        # Load history if exists
        self._load_history()
        
        # Non-blocking summarization queue
        self._summarization_queue = queue.Queue()
        self._summarization_in_progress = False
        self._last_summarized_at: float = 0.0  # Cooldown tracker: epoch time of last summarization
        # Minimum seconds between summarization attempts (prevents infinite loop
        # when output template + LLM summary still exceeds size threshold)
        self._summarization_cooldown = getattr(config, 'env_summarization_cooldown', 300)  # 5 min default
        
        # Initialize thread references (must be set before start_auto_summarization)
        self._running = True
        self._summarization_thread = None
        self._worker_thread = None
        
        # Start background summarization threads
        self.start_auto_summarization()
        
        logger.info(f"✅ Environment Manager initialized at: {self.env_file}")
        # Note: __init__ cannot yield, but initialization is logged
    
    def _get_env_directory(self) -> Path:
        """
        Determine the environment storage directory (RUN-SPECIFIC).
        
        Priority:
        1. config.env_dir if specified
        2. Run-specific location (config.synapse_dir / "env") - synapse_dir should point to run folder
        3. Fallback to outputs/run_XXX/synapse_state/env
        """
        if hasattr(self.config, 'env_dir') and self.config.env_dir:
            return Path(self.config.env_dir)
        
        if hasattr(self.config, 'synapse_dir') and self.config.synapse_dir:
            synapse_dir = Path(self.config.synapse_dir)
            return synapse_dir / "env"
        
        # Fallback - assume we're in a run folder
        return Path("outputs") / "run_latest" / "synapse_state" / "env"
    
    def _initialize_env_file(self):
        """Initialize env.md with header."""
        header = f"""# Environment Context
**Goal:** {self.goal_context}
**Created:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Last Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Environment Updates

"""
        with self._lock:
            with open(self.env_file, 'w') as f:
                f.write(header)
        logger.info(f"📝 Initialized env.md at {self.env_file}")
    
    def get_current_env(self) -> str:
        """
        Read and return the current environment context.
        
        Returns:
            str: Current content of env.md file
        """
        with self._lock:
            if not self.env_file.exists():
                self._initialize_env_file()
                return ""
            
            try:
                with open(self.env_file, 'r') as f:
                    content = f.read()
                logger.debug(f"📖 Read environment: {len(content)} bytes")
                return content
            except Exception as e:
                logger.error(f"❌ Failed to read env.md: {e}")
                return ""
    
    async def add_to_current_env_stream(self, content: str) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Append new content to the environment file with event streaming.
        
        Args:
            content: String to append to env.md
        """
        if not content or not content.strip():
            logger.warning("⚠️ Attempted to add empty content to environment")
            yield {"module": "Synapse.core.environment_manager", "message": "I noticed an attempt to add empty content to the environment"}
            return
        
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        entry = f"\n### [{timestamp}]\n{content}\n"
        
        with self._lock:
            try:
                # Update "Last Updated" in header
                current_content = ""
                if self.env_file.exists():
                    with open(self.env_file, 'r') as f:
                        current_content = f.read()
                
                # Update timestamp in header
                if "**Last Updated:**" in current_content:
                    lines = current_content.split('\n')
                    for i, line in enumerate(lines):
                        if line.startswith("**Last Updated:**"):
                            lines[i] = f"**Last Updated:** {timestamp}"
                            break
                    current_content = '\n'.join(lines)
                
                # Append new entry
                yield {"module": "Synapse.core.environment_manager", "message": f"I am adding {len(content)} bytes to the environment file"}
                with open(self.env_file, 'a') as f:
                    f.write(entry)
                
                logger.info(f"✅ Added to environment: {len(content)} bytes")
                yield {"module": "Synapse.core.environment_manager", "message": f"I have successfully added {len(content)} bytes to the environment"}
                
                # Check if we need to summarize based on size (non-blocking)
                file_size = self.env_file.stat().st_size
                if file_size > self.max_size_before_summarize:
                    logger.info(f"📊 Environment file exceeds {self.max_size_before_summarize} bytes, queueing summarization")
                    yield {"module": "Synapse.core.environment_manager", "message": f"I noticed the environment file exceeds {self.max_size_before_summarize} bytes, queueing summarization"}
                    self._queue_summarization("size_threshold")
                    
            except Exception as e:
                logger.error(f"❌ Failed to add to env.md: {e}")
                yield {"module": "Synapse.core.environment_manager", "message": f"I encountered an error while adding to environment: {str(e)}"}
    
    def add_to_current_env(self, content: str):
        """
        Synchronous wrapper for add_to_current_env_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use sync version directly
                return self._add_to_current_env_sync(content)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            async for _ in self.add_to_current_env_stream(content):
                pass
        
        asyncio.run(_run())
    
    def _add_to_current_env_sync(self, content: str):
        """
        Synchronous implementation (for backward compatibility).
        """
        if not content or not content.strip():
            logger.warning("⚠️ Attempted to add empty content to environment")
            return
        
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        entry = f"\n### [{timestamp}]\n{content}\n"
        
        with self._lock:
            try:
                # Update "Last Updated" in header
                current_content = ""
                if self.env_file.exists():
                    with open(self.env_file, 'r') as f:
                        current_content = f.read()
                
                # Update timestamp in header
                if "**Last Updated:**" in current_content:
                    lines = current_content.split('\n')
                    for i, line in enumerate(lines):
                        if line.startswith("**Last Updated:**"):
                            lines[i] = f"**Last Updated:** {timestamp}"
                            break
                    current_content = '\n'.join(lines)
                
                # Append new entry
                with open(self.env_file, 'a') as f:
                    f.write(entry)
                
                logger.info(f"✅ Added to environment: {len(content)} bytes")
                
                # Check if we need to summarize based on size (non-blocking)
                file_size = self.env_file.stat().st_size
                if file_size > self.max_size_before_summarize:
                    logger.info(f"📊 Environment file exceeds {self.max_size_before_summarize} bytes, queueing summarization")
                    self._queue_summarization("size_threshold")
                    
            except Exception as e:
                logger.error(f"❌ Failed to add to env.md: {e}")
    
    def _queue_summarization(self, reason: str = "manual"):
        """
        Queue a summarization request (non-blocking).
        
        Args:
            reason: Reason for summarization request
        """
        # Cooldown guard: don't re-summarize if we recently summarized
        elapsed = time.time() - self._last_summarized_at
        if elapsed < self._summarization_cooldown:
            logger.debug(
                f"⏳ Skipping summarization request ({reason}): "
                f"cooldown active ({elapsed:.0f}s / {self._summarization_cooldown}s)"
            )
            return
        
        # Only queue if not already in progress
        if not self._summarization_in_progress:
            try:
                self._summarization_queue.put_nowait(reason)
                logger.debug(f"📥 Queued summarization request: {reason}")
            except queue.Full:
                logger.warning("⚠️ Summarization queue is full, skipping request")
        else:
            logger.debug(f"⏳ Summarization already in progress, skipping queue for: {reason}")
    
    def _summarize_environment(self):
        """
        Summarize the environment file using CoT DSpy agent.
        Creates a condensed version while preserving key information.
        """
        # Mark summarization as in progress
        self._summarization_in_progress = True
        
        try:
            self._do_summarize()
        finally:
            self._summarization_in_progress = False
    
    def _do_summarize(self):
        """Internal method that performs the actual summarization."""
        with self._lock:
            try:
                # Read current content
                if not self.env_file.exists():
                    logger.warning("⚠️ No env.md file to summarize")
                    return
                
                with open(self.env_file, 'r') as f:
                    current_content = f.read()
                
                # Skip if content is too small
                line_count = len(current_content.split('\n'))
                if line_count < self.min_lines_before_summarize:
                    logger.debug(f"📊 Environment too small to summarize ({line_count} lines < {self.min_lines_before_summarize})")
                    return
                
                # Create snapshot before summarization
                snapshot = EnvironmentSnapshot(
                    content=current_content,
                    timestamp=time.time(),
                    size_bytes=len(current_content.encode('utf-8')),
                    line_count=line_count
                )
                self.snapshots.append(snapshot)
                
                # Keep only recent snapshots
                if len(self.snapshots) > self.max_snapshots:
                    self.snapshots = self.snapshots[-self.max_snapshots:]
                
                # Save snapshot to history
                self._save_history()
                
                logger.info(f"🧠 Summarizing environment: {line_count} lines, {len(current_content)} bytes")
                
                # Lazy-load summarizer (ensure DSPy is configured before first use)
                if self._summarizer is None:
                    try:
                        self._summarizer = dspy.ChainOfThought(EnvironmentSummarizationSignature)
                        logger.debug("✅ Initialized ChainOfThought summarizer")
                    except Exception as e:
                        logger.error(f"❌ Failed to initialize summarizer: {e}")
                        logger.warning("⚠️  Skipping summarization - ensure DSPy is configured with API key")
                        return
                
                # Check if DSPy is actually configured with an LM
                if not hasattr(dspy.settings, 'lm') or dspy.settings.lm is None:
                    logger.warning("⚠️  Skipping summarization - DSPy not configured with language model")
                    logger.warning("   Call dspy.configure(lm=...) before using Environment Manager")
                    return
                
                # Use CoT to summarize
                result = self._summarizer(
                    current_content=current_content,
                    goal_context=self.goal_context,
                    timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                )
                
                # Extract results
                summarized = result.summarized_content
                reasoning = result.reasoning
                key_insights = result.key_insights
                pruned = result.pruned_items
                
                # Create new condensed env.md
                timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                new_content = f"""# Environment Context
**Goal:** {self.goal_context}
**Created:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Last Updated:** {timestamp}
**Last Summarized:** {timestamp}

---

## Summarization Reasoning
{reasoning}

---

## Key Insights
{key_insights}

---

## Pruned Information
{pruned}

---

## Summarized Environment Updates

{summarized}

"""
                
                # Write summarized content
                with open(self.env_file, 'w') as f:
                    f.write(new_content)
                
                new_size = len(new_content)
                old_size = len(current_content)
                reduction = ((old_size - new_size) / old_size * 100) if old_size > 0 else 0
                
                logger.info(f"✅ Environment summarized: {old_size}→{new_size} bytes ({reduction:.1f}% reduction)")
                logger.info(f"🔍 Key insights: {key_insights[:100]}...")
                
                # Update cooldown timestamp to prevent infinite re-summarization
                self._last_summarized_at = time.time()
                
            except Exception as e:
                logger.error(f"❌ Failed to summarize environment: {e}", exc_info=True)
    
    def _summarization_worker(self):
        """Background worker thread that processes summarization queue."""
        logger.info("🔧 Starting summarization worker thread")
        
        while self._running:
            try:
                # Wait for summarization request (with timeout to check _running)
                try:
                    reason = self._summarization_queue.get(timeout=1.0)
                except queue.Empty:
                    continue
                
                logger.info(f"🚀 Processing queued summarization: {reason}")
                self._summarize_environment()
                
                # Mark task as done
                self._summarization_queue.task_done()
                
            except Exception as e:
                logger.error(f"❌ Error in summarization worker: {e}")
        
        logger.info("🛑 Summarization worker thread stopped")
    
    def _auto_summarize_loop(self):
        """Background thread that periodically summarizes the environment."""
        logger.info(f"🔄 Starting auto-summarization loop (interval: {self.summarization_interval}s)")
        
        while self._running:
            try:
                time.sleep(self.summarization_interval)
                
                if not self._running:
                    break
                
                # Check if summarization is needed
                if self.env_file.exists():
                    file_size = self.env_file.stat().st_size
                    
                    # Only summarize if file is large enough
                    if file_size > self.max_size_before_summarize:
                        logger.info(f"⏰ Periodic summarization triggered (size: {file_size} bytes)")
                        self._queue_summarization("periodic_check")
                    else:
                        logger.debug(f"📊 Environment size OK: {file_size} bytes (threshold: {self.max_size_before_summarize})")
                        
            except Exception as e:
                logger.error(f"❌ Error in auto-summarization loop: {e}")
    
    def start_auto_summarization(self):
        """Start the background summarization threads."""
        if self._summarization_thread and self._summarization_thread.is_alive():
            logger.warning("⚠️ Auto-summarization thread already running")
            return
        
        self._running = True
        
        # Start periodic checker thread
        self._summarization_thread = threading.Thread(
            target=self._auto_summarize_loop,
            daemon=True,
            name="EnvSummarizer"
        )
        self._summarization_thread.start()
        
        # Start worker thread to process queue
        self._worker_thread = threading.Thread(
            target=self._summarization_worker,
            daemon=True,
            name="EnvWorker"
        )
        self._worker_thread.start()
        
        logger.info("✅ Auto-summarization threads started (periodic + worker)")
    
    def stop_auto_summarization(self):
        """Stop the background summarization threads."""
        logger.info("🛑 Stopping auto-summarization threads")
        self._running = False
        
        # Wait for worker thread to finish pending tasks
        if self._worker_thread and self._worker_thread.is_alive():
            logger.info("⏳ Waiting for pending summarizations to complete...")
            self._worker_thread.join(timeout=10)
        
        # Stop periodic thread
        if self._summarization_thread and self._summarization_thread.is_alive():
            self._summarization_thread.join(timeout=5)
        
        logger.info("✅ Auto-summarization threads stopped")
    
    def force_summarize(self, blocking: bool = True):
        """
        Manually trigger environment summarization.
        
        Args:
            blocking: If True, wait for summarization to complete. If False, queue it.
        """
        logger.info("🔨 Forcing environment summarization")
        
        if blocking:
            # Bypass queue and run synchronously
            self._summarize_environment()
        else:
            # Queue for background processing
            self._queue_summarization("force_manual")
    
    def clear_environment(self):
        """Clear the environment file and start fresh."""
        with self._lock:
            logger.warning("🗑️ Clearing environment file")
            self._initialize_env_file()
    
    def get_snapshot(self, index: int = -1) -> Optional[EnvironmentSnapshot]:
        """
        Get a historical snapshot of the environment.
        
        Args:
            index: Index of snapshot (default: -1 for most recent)
        
        Returns:
            EnvironmentSnapshot or None if not found
        """
        if not self.snapshots:
            return None
        
        try:
            return self.snapshots[index]
        except IndexError:
            return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about the environment manager.
        
        Returns:
            Dict with statistics
        """
        file_size = 0
        line_count = 0
        
        if self.env_file.exists():
            file_size = self.env_file.stat().st_size
            with open(self.env_file, 'r') as f:
                line_count = len(f.readlines())
        
        return {
            'env_file': str(self.env_file),
            'file_size_bytes': file_size,
            'line_count': line_count,
            'snapshots_count': len(self.snapshots),
            'auto_summarization_active': self._running,
            'summarization_in_progress': self._summarization_in_progress,
            'queued_summarizations': self._summarization_queue.qsize(),
            'summarization_interval': self.summarization_interval,
            'max_size_threshold': self.max_size_before_summarize,
            'goal_context': self.goal_context
        }
    
    def _save_history(self):
        """Save snapshot history to JSON file."""
        try:
            history_data = {
                'snapshots': [
                    {
                        'timestamp': s.timestamp,
                        'size_bytes': s.size_bytes,
                        'line_count': s.line_count,
                        'content_preview': s.content[:500] + "..." if len(s.content) > 500 else s.content
                    }
                    for s in self.snapshots
                ],
                'last_saved': time.time()
            }
            
            with open(self.history_file, 'w') as f:
                json.dump(history_data, f, indent=2)
                
        except Exception as e:
            logger.warning(f"⚠️ Failed to save environment history: {e}")
    
    def _load_history(self):
        """Load snapshot history from JSON file."""
        if not self.history_file.exists():
            return
        
        try:
            with open(self.history_file, 'r') as f:
                history_data = json.load(f)
            
            logger.info(f"📚 Loaded {len(history_data.get('snapshots', []))} environment snapshots")
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to load environment history: {e}")
    
    def __del__(self):
        """Cleanup: stop the summarization thread."""
        self.stop_auto_summarization()
    
    def __repr__(self) -> str:
        stats = self.get_statistics()
        return f"EnvironmentManager(file={stats['env_file']}, size={stats['file_size_bytes']} bytes, lines={stats['line_count']})"


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_environment_manager(config, goal_context: str = "General task execution") -> EnvironmentManager:
    """
    Factory function to create an EnvironmentManager instance.
    
    Args:
        config: Synapse configuration object
        goal_context: Description of the current goal
    
    Returns:
        Configured EnvironmentManager instance
    """
    return EnvironmentManager(config, goal_context)


if __name__ == "__main__":
    # Example usage / testing
    import sys
    from pathlib import Path
    
    # Simple config for testing
    class TestConfig:
        synapse_dir = Path("test_outputs") / "synapse_state"
        env_summarization_interval = 10  # 10 seconds for testing
        env_max_size_bytes = 1000  # 1KB for testing (override default 20MB)
        env_min_lines = 5
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    
    # Create manager
    config = TestConfig()
    manager = EnvironmentManager(config, goal_context="Testing Environment Manager")
    
    print(f"\n{manager}\n")
    
    # Add some content
    manager.add_to_current_env("Started task execution")
    manager.add_to_current_env("Loaded configuration from config.yaml")
    manager.add_to_current_env("Initialized agents: Agent1, Agent2, Agent3")
    manager.add_to_current_env("Processing first batch of tasks")
    manager.add_to_current_env("Agent1 completed task: data_processing")
    manager.add_to_current_env("Agent2 encountered error: connection timeout")
    manager.add_to_current_env("Retrying Agent2 task with backoff")
    manager.add_to_current_env("All tasks completed successfully")
    
    # Read environment
    print("Current Environment:")
    print("=" * 80)
    print(manager.get_current_env())
    print("=" * 80)
    
    # Force summarize
    print("\nForcing summarization...")
    manager.force_summarize()
    
    # Read again
    print("\nSummarized Environment:")
    print("=" * 80)
    print(manager.get_current_env())
    print("=" * 80)
    
    # Show stats
    print("\nStatistics:")
    stats = manager.get_statistics()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Cleanup
    manager.stop_auto_summarization()
    print("\n✅ Test completed!")
