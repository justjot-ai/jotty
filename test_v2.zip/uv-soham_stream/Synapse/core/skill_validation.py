"""
Skill validation pipeline for dynamic skills.
"""

from __future__ import annotations

import ast
import asyncio
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class SkillValidationResult:
    valid: bool
    static_ok: bool
    tests_ok: bool
    contract_ok: bool
    issues: List[str] = field(default_factory=list)
    test_output: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


class SkillValidator:
    """
    Deterministic validator for synthesized skill modules.

    Safety checks are config-driven to avoid hidden hardcoded paths.
    """

    DEFAULT_FORBIDDEN_IMPORTS = {
        "pty",
        "resource",
    }

    def __init__(
        self,
        *,
        forbidden_imports: Optional[List[str]] = None,
        max_file_size_bytes: int = 256_000,
        test_timeout_seconds: int = 90,
    ):
        self.forbidden_imports = set(forbidden_imports or self.DEFAULT_FORBIDDEN_IMPORTS)
        self.max_file_size_bytes = int(max_file_size_bytes)
        self.test_timeout_seconds = int(test_timeout_seconds)

    async def validate(
        self,
        module_path: str,
        *,
        expected_entrypoint: str = "run",
        test_command: Optional[List[str]] = None,
    ) -> SkillValidationResult:
        static = await self._static_validate(module_path, expected_entrypoint=expected_entrypoint)
        tests_ok = True
        test_output = ""
        contract_ok = static.get("entrypoint_present", False)
        issues = list(static.get("issues", []))

        if test_command:
            tests_ok, test_output, test_issue = await self._run_tests(test_command)
            if test_issue:
                issues.append(test_issue)

        valid = static.get("ok", False) and tests_ok and contract_ok
        return SkillValidationResult(
            valid=valid,
            static_ok=static.get("ok", False),
            tests_ok=tests_ok,
            contract_ok=contract_ok,
            issues=issues,
            test_output=test_output,
            metadata={
                "module_path": module_path,
                "entrypoint": expected_entrypoint,
            },
        )

    async def _static_validate(self, module_path: str, *, expected_entrypoint: str) -> Dict[str, Any]:
        path = Path(module_path).expanduser().resolve()
        issues: List[str] = []

        if not path.exists():
            return {"ok": False, "issues": [f"Module not found: {path}"], "entrypoint_present": False}
        if path.stat().st_size > self.max_file_size_bytes:
            issues.append(f"Module too large: {path.stat().st_size} bytes > {self.max_file_size_bytes}")

        try:
            src = await asyncio.to_thread(path.read_text, encoding="utf-8")
        except Exception as exc:
            return {"ok": False, "issues": [f"Read failed: {exc}"], "entrypoint_present": False}

        try:
            tree = ast.parse(src)
        except SyntaxError as exc:
            return {"ok": False, "issues": [f"Syntax error: {exc}"], "entrypoint_present": False}

        entrypoint_present = False
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == expected_entrypoint:
                entrypoint_present = True
            if isinstance(node, ast.AsyncFunctionDef) and node.name == expected_entrypoint:
                entrypoint_present = True
            if isinstance(node, ast.Import):
                for n in node.names:
                    root = (n.name or "").split(".")[0]
                    if root in self.forbidden_imports:
                        issues.append(f"Forbidden import: {n.name}")
            if isinstance(node, ast.ImportFrom):
                root = (node.module or "").split(".")[0]
                if root in self.forbidden_imports:
                    issues.append(f"Forbidden import-from: {node.module}")

        if not entrypoint_present:
            issues.append(f"Entrypoint '{expected_entrypoint}' not found")

        return {
            "ok": len(issues) == 0,
            "issues": issues,
            "entrypoint_present": entrypoint_present,
        }

    async def _run_tests(self, cmd: List[str]) -> tuple[bool, str, Optional[str]]:
        def _run() -> tuple[int, str, str]:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.test_timeout_seconds,
            )
            return proc.returncode, proc.stdout or "", proc.stderr or ""

        try:
            code, out, err = await asyncio.to_thread(_run)
            full = (out + "\n" + err).strip()
            if code != 0:
                return False, full, f"Tests failed with exit code {code}"
            return True, full, None
        except subprocess.TimeoutExpired:
            return False, "", f"Tests timed out after {self.test_timeout_seconds}s"
        except Exception as exc:
            logger.warning(f"Skill test command failed: {exc}")
            return False, "", f"Test execution failed: {exc}"

