"""
TrajectoryParser - Generic Trajectory Parsing & Tagging for ReVal

Parses DSPy ReAct trajectories and tags attempts as:
- 'answer': Successful attempt with valid result
- 'error': Failed attempt or invalid result  
- 'exploratory': Uncertain outcome, learning phase

✅ GENERIC: Works for ANY domain (SQL, code, marketing, finance, etc.)
✅ NO HARDCODING: Zero domain-specific assumptions
✅ LLM-READY: Supports semantic tagging via LLM
✅ PARALLEL: Concurrent tagging for faster processing

A-Team Design: Turing (architecture) + Sutton (RL tagging) + Chomsky (semantic understanding)
"""
from dataclasses import dataclass, field
from typing import List, Any, Optional, Dict
from datetime import datetime
import logging
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import asyncio
from functools import partial

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except Exception:
    DSPY_AVAILABLE = False


class TagAttemptSignature(dspy.Signature):
    """
    LLM-based tagging of trajectory attempts.
    """
    observation = dspy.InputField(desc="Tool observation/output")
    expected_outcome = dspy.InputField(desc="Expected outcome (if any)")
    
    reasoning = dspy.OutputField(desc="Why this attempt is answer/error/exploratory")
    tag = dspy.OutputField(desc="One of: answer, error, exploratory")


class TagTrajectoryBatchSignature(dspy.Signature):
    """
    Batch tag all attempts in a single LLM call to reduce latency/noise.
    """
    attempts_json = dspy.InputField(
        desc="JSON list of attempts with attempt_number, tool_name, thought, and observation"
    )
    expected_outcome = dspy.InputField(desc="Expected outcome (if any)")

    reasoning = dspy.OutputField(
        desc="High-level reasoning for why attempts were tagged the way they were"
    )
    tags_json = dspy.OutputField(
        desc=(
            "JSON list with one entry per attempt: "
            "[{\"attempt_number\": 1, \"tag\": \"answer|error|exploratory\", \"reason\": \"...\"}]"
        )
    )

@dataclass
class TaggedAttempt:
    """
    Single attempt from ReAct exploration with standardized tag.
    
    Tags (standardized across ALL domains):
    - 'answer': Successful attempt with valid result
    - 'error': Failed attempt or invalid result
    - 'exploratory': Uncertain outcome, learning phase
    
    ✅ GENERIC: No domain-specific fields
    ✅ STANDARD: Same structure for SQL, code, marketing, etc.
    """
    output: Any                    # The actual output (query, code, config, etc.)
    tag: str                       # 'answer', 'error', or 'exploratory'
    execution_status: str          # 'success', 'failed', 'uncertain'
    execution_result: str          # Full observation from tool
    reasoning: str                 # Thought/reasoning for this attempt
    attempt_number: int = 0
    tool_name: str = ""           # Which tool was called
    timestamp: float = field(default_factory=lambda: datetime.now().timestamp())
    
    def is_answer(self) -> bool:
        """Check if this is a successful answer."""
        return self.tag == 'answer'
    
    def is_error(self) -> bool:
        """Check if this is a failed attempt."""
        return self.tag == 'error'
    
    def is_exploratory(self) -> bool:
        """Check if this is exploratory (uncertain)."""
        return self.tag == 'exploratory'


class TrajectoryParser:
    """
    Generic trajectory parser for ANY DSPy ReAct agent.
    
    Extracts tool calls from trajectory and tags them as:
    - 'answer': Successful execution with valid result
    - 'error': Failed execution or invalid result
    - 'exploratory': Uncertain outcome, learning attempt
    
    ✅ GENERIC: Works for SQL, code, marketing, finance, etc.
    ✅ NO HARDCODING: No domain-specific assumptions
    ✅ LLM-BASED: Semantic understanding of success/failure
    
    A-Team Consensus: This is the ONLY place where trajectory parsing happens.
    Agents should NOT parse their own trajectories.
    """
    
    def __init__(self, lm: Optional[Any] = None):
        """
        Initialize parser.
        
        Args:
            lm: Optional LLM for semantic tagging (can override default model)
        """
        self.lm = lm
        self._tagger = dspy.ChainOfThought(TagAttemptSignature) if DSPY_AVAILABLE else None
        self._batch_tagger = dspy.ChainOfThought(TagTrajectoryBatchSignature) if DSPY_AVAILABLE else None
        if self.lm:
            logger.info(f"🏷️  TrajectoryParser initialized with custom LM: {self.lm}")
        else:
            logger.info("🏷️  TrajectoryParser initialized (generic, domain-agnostic)")
        
    def parse_trajectory(
        self,
        result: Any,
        tool_name_filter: Optional[str] = None,
        expected_outcome: Optional[str] = None,
        parallel: bool = True,
        max_workers: int = 10
    ) -> List[TaggedAttempt]:
        """
        Parse DSPy ReAct trajectory and tag attempts.
        
        Args:
            result: DSPy Prediction with _store containing trajectory
            tool_name_filter: Only parse calls to this tool (e.g. 'execute_query')
            expected_outcome: What we expected (for semantic tagging)
            parallel: Enable parallel tagging (default: True)
            max_workers: Max parallel workers for tagging (default: 10)
            
        Returns:
            List of TaggedAttempt with generic tags
        """
        attempts = []
        
        # Check if result has trajectory data
        if not hasattr(result, '_store'):
            logger.debug("🏷️  No trajectory (_store) in result")
            return attempts
            
        store = result._store
        
        # 🔥 CRITICAL FIX: DSPy ReAct stores trajectory as a DICT in _store['trajectory']!
        # NOT as top-level keys in _store!
        # See: https://dspy.ai/api/modules/ReAct/
        if 'trajectory' in store and isinstance(store['trajectory'], dict):
            trajectory = store['trajectory']
            logger.info(f"🏷️  Parsing trajectory dict with {len(trajectory)} keys")
        else:
            # Fallback: check if trajectory keys are at top level
            trajectory = store
            logger.info(f"🏷️  Parsing trajectory (top-level) with {len(store)} keys")
        
        # PHASE 1: Collect all attempt data (fast, no LLM calls)
        attempt_data = []
        i = 0
        
        while True:
            # DSPy ReAct trajectory format:
            # thought_0, tool_name_0, tool_args_0, observation_0
            # thought_1, tool_name_1, tool_args_1, observation_1
            tool_name_key = f'tool_name_{i}'
            
            if tool_name_key not in trajectory:
                break  # No more tool calls
                
            tool_name = trajectory.get(tool_name_key, '')
            tool_args = trajectory.get(f'tool_args_{i}', {})
            observation = trajectory.get(f'observation_{i}', '')
            thought = trajectory.get(f'thought_{i}', '')
            
            # Filter by tool if specified
            if tool_name_filter and tool_name != tool_name_filter:
                i += 1
                continue
                
            # Extract output from tool args (GENERIC)
            output = self._extract_output(tool_args)
            
            # Store raw data for parallel tagging
            attempt_data.append({
                'index': i,
                'output': output,
                'observation': observation,
                'thought': thought,
                'tool_name': tool_name,
                'attempt_number': len(attempt_data) + 1
            })
            
            i += 1
        
        if not attempt_data:
            logger.info("🏷️  No attempts found in trajectory")
            return attempts
        
        logger.info(f"🏷️  Collected {len(attempt_data)} attempts, starting tagging...")
        
        # PHASE 2: Tag attempts
        # Prefer a SINGLE batch LLM call to avoid N per-attempt calls that can be slow/noisy.
        if self._batch_tagger and len(attempt_data) > 1:
            attempts = self._tag_attempts_batch(attempt_data, expected_outcome)
        elif parallel and len(attempt_data) > 1:
            attempts = self._tag_attempts_parallel(attempt_data, expected_outcome, max_workers)
        else:
            attempts = self._tag_attempts_sequential(attempt_data, expected_outcome)
        
        logger.info(f"🏷️  Parsed {len(attempts)} attempts from trajectory")
        return attempts

    def _tag_attempts_batch(
        self,
        attempt_data: List[Dict[str, Any]],
        expected_outcome: Optional[str]
    ) -> List[TaggedAttempt]:
        """
        Tag all attempts in one LLM call.
        This keeps the system fully LLM-driven while reducing overhead and call explosion.
        """
        if not self._batch_tagger:
            return self._tag_attempts_sequential(attempt_data, expected_outcome)

        payload = []
        for data in attempt_data:
            payload.append({
                "attempt_number": data["attempt_number"],
                "tool_name": data["tool_name"],
                "thought": str(data.get("thought", ""))[:1000],
                "observation": str(data.get("observation", ""))[:1500],
            })

        try:
            if self.lm:
                with dspy.context(lm=self.lm):
                    result = self._batch_tagger(
                        attempts_json=json.dumps(payload, default=str),
                        expected_outcome=str(expected_outcome)[:500] if expected_outcome else ""
                    )
            else:
                result = self._batch_tagger(
                    attempts_json=json.dumps(payload, default=str),
                    expected_outcome=str(expected_outcome)[:500] if expected_outcome else ""
                )

            tags_raw = getattr(result, "tags_json", "[]")
            parsed = json.loads(tags_raw) if isinstance(tags_raw, str) else tags_raw
            if not isinstance(parsed, list):
                raise ValueError("tags_json is not a list")

            tag_by_attempt = {}
            for item in parsed:
                if not isinstance(item, dict):
                    continue
                n = item.get("attempt_number")
                tag = str(item.get("tag", "exploratory")).strip().lower()
                if tag not in ["answer", "error", "exploratory"]:
                    tag = "exploratory"
                if isinstance(n, int):
                    tag_by_attempt[n] = tag

            attempts: List[TaggedAttempt] = []
            for data in attempt_data:
                tag = tag_by_attempt.get(data["attempt_number"], "exploratory")
                attempts.append(
                    TaggedAttempt(
                        output=data["output"],
                        tag=tag,
                        execution_status=self._get_status(tag),
                        execution_result=str(data["observation"]),
                        reasoning=str(data["thought"]) if data["thought"] else f"Trajectory step {data['index']}",
                        attempt_number=data["attempt_number"],
                        tool_name=data["tool_name"],
                    )
                )

            logger.info(f"🏷️  Batch-tagged {len(attempts)} attempts in a single LLM call")
            return attempts

        except Exception as e:
            logger.warning(f"🏷️  Batch tagging failed, falling back to sequential tagging: {e}")
            return self._tag_attempts_sequential(attempt_data, expected_outcome)
    
    def _tag_attempts_parallel(
        self,
        attempt_data: List[Dict[str, Any]],
        expected_outcome: Optional[str],
        max_workers: int
    ) -> List[TaggedAttempt]:
        """
        Tag attempts in parallel using ThreadPoolExecutor.
        
        Each attempt is independent, so we can tag them concurrently.
        This reduces total tagging time from O(n) to O(1) for n attempts.
        """
        attempts = []
        
        # Create partial function with expected_outcome
        tag_fn = partial(self._tag_single_attempt, expected_outcome=expected_outcome)
        
        # Submit all tagging tasks in parallel
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_data = {
                executor.submit(tag_fn, data): data 
                for data in attempt_data
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_data):
                data = future_to_data[future]
                try:
                    tag = future.result()
                    attempt = TaggedAttempt(
                        output=data['output'],
                        tag=tag,
                        execution_status=self._get_status(tag),
                        execution_result=str(data['observation']),
                        reasoning=str(data['thought']) if data['thought'] else f"Trajectory step {data['index']}",
                        attempt_number=data['attempt_number'],
                        tool_name=data['tool_name']
                    )
                    attempts.append(attempt)
                    logger.info(f"🏷️  Attempt {attempt.attempt_number}: tag='{tag}', tool='{data['tool_name']}'")
                except Exception as e:
                    logger.error(f"🏷️  Failed to tag attempt {data['attempt_number']}: {e}")
                    # Create exploratory fallback
                    attempt = TaggedAttempt(
                        output=data['output'],
                        tag='exploratory',
                        execution_status='uncertain',
                        execution_result=str(data['observation']),
                        reasoning=f"Tagging failed: {e}",
                        attempt_number=data['attempt_number'],
                        tool_name=data['tool_name']
                    )
                    attempts.append(attempt)
        
        # Sort by attempt number to maintain order
        attempts.sort(key=lambda a: a.attempt_number)
        return attempts
    
    def _tag_attempts_sequential(
        self,
        attempt_data: List[Dict[str, Any]],
        expected_outcome: Optional[str]
    ) -> List[TaggedAttempt]:
        """
        Tag attempts sequentially (fallback for single attempt or disabled parallel).
        """
        attempts = []
        
        for data in attempt_data:
            tag = self._tag_attempt(data['observation'], expected_outcome)
            
            attempt = TaggedAttempt(
                output=data['output'],
                tag=tag,
                execution_status=self._get_status(tag),
                execution_result=str(data['observation']),
                reasoning=str(data['thought']) if data['thought'] else f"Trajectory step {data['index']}",
                attempt_number=data['attempt_number'],
                tool_name=data['tool_name']
            )
            
            attempts.append(attempt)
            logger.info(f"🏷️  Attempt {attempt.attempt_number}: tag='{tag}', tool='{data['tool_name']}'")
        
        return attempts
    
    def _tag_single_attempt(
        self,
        data: Dict[str, Any],
        expected_outcome: Optional[str] = None
    ) -> str:
        """
        Tag a single attempt (used by parallel executor).
        """
        return self._tag_attempt(data['observation'], expected_outcome)
    
    def _tag_attempt(
        self,
        observation: str,
        expected_outcome: Optional[str] = None
    ) -> str:
        """
        Tag attempt as 'answer', 'error', or 'exploratory'.
        
        LLM-based semantic tagging (no heuristics).
        Uses custom LM if provided (e.g., azure-paytm-east-us2/paytm-gpt-4o-mini).
        """
        if self._tagger:
            try:
                # Use custom LM if provided, otherwise use default
                if self.lm:
                    with dspy.context(lm=self.lm):
                        result = self._tagger(
                            observation=str(observation)[:1500],
                            expected_outcome=str(expected_outcome)[:500] if expected_outcome else ""
                        )
                else:
                    result = self._tagger(
                        observation=str(observation)[:1500],
                        expected_outcome=str(expected_outcome)[:500] if expected_outcome else ""
                    )
                
                tag = str(getattr(result, "tag", "exploratory")).strip().lower()
                if tag in ["answer", "error", "exploratory"]:
                    return tag
            except Exception as e:
                logger.debug(f"LLM tagging failed: {e}")
        
        # Explicit uncertainty fallback (no heuristics)
        return "exploratory"
    
    def _extract_output(self, tool_args: Any) -> Any:
        """
        Extract output from tool arguments (GENERIC).
        
        Tries common patterns across different domains.
        """
        if isinstance(tool_args, dict):
            # Try common field names across domains
            return (
                tool_args.get('query') or      # SQL / database queries
                tool_args.get('code') or       # Code generation
                tool_args.get('prompt') or     # Marketing / content
                tool_args.get('input') or      # Generic input
                tool_args.get('data') or       # Data processing
                tool_args.get('text') or       # Text generation
                tool_args.get('command') or    # Shell commands
                str(tool_args)                  # Fallback: full dict
            )
        return str(tool_args)
    
    def _get_status(self, tag: str) -> str:
        """Map tag to execution status (standardized)."""
        return {
            'answer': 'success',
            'error': 'failed',
            'exploratory': 'uncertain'
        }.get(tag, 'unknown')


def create_parser(lm: Optional[Any] = None) -> TrajectoryParser:
    """Factory function to create parser."""
    return TrajectoryParser(lm=lm)

