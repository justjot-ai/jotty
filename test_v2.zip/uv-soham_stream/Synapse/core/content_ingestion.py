"""
🔬 Content Ingestion Pipeline - Generic Entry Point for ALL Content Processing
===============================================================================

A-Team Approved: The SINGLE coordinator for chunking and compression decisions.

This module implements the critical architecture insight:
> "Compressor needs entire context to fit in prompt, else it will fail"
> "Chunker is deployed when input is too large, reads in chunks given goal"

The Problem We Solve:
1. Compressor can ONLY handle inputs that fit in model's context window
2. Chunker is needed when input exceeds that limit
3. Sometimes we need BOTH (chunk → compress combined result)
4. Decision must be GENERIC (no hardcoded thresholds)

The Solution:
┌─────────────────────────────────────────┐
│ ContentIngestionPipeline                │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│ Decides: Pass-through, Compress, Chunk  │
│ - Context-window aware                  │
│ - Query-aware (not blind)               │
│ - Two-stage processing                  │
│ - NO hardcoding                         │
└───────────┬─────────────────────────────┘
            │
     ┌──────┴──────┐
     │             │
     ▼             ▼
┌─────────┐   ┌────────────┐
│Compressor│   │Chunker     │
│(LLM)    │   │(Token-acc) │
│         │   │+ LLM scorer│
└─────────┘   └────────────┘

Usage:
    ```python
    pipeline = ContentIngestionPipeline()
    
    # Process any content
    result = await pipeline.process(
        content=large_terminal_output,
        max_tokens=10000,
        query="What errors occurred?",
        goal="Debug the system"
    )
    ```

A-Team Consensus: This is the ONLY entry point for content ingestion.
All manual chunking/compression logic is deprecated.
"""

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

import logging
from typing import Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class IngestionResult:
    """
    Result from content ingestion pipeline.
    
    Attributes:
        content: Processed content (within budget)
        original_tokens: Token count of input
        final_tokens: Token count of output
        processing_path: What was done ("passthrough", "compress", "chunk", "chunk+compress")
        chunks_used: Number of chunks used (if chunked)
        chunks_total: Total chunks created (if chunked)
        compression_ratio: Final/original token ratio
        metadata: Additional processing metadata
    """
    content: str
    original_tokens: int
    final_tokens: int
    processing_path: str
    chunks_used: int = 0
    chunks_total: int = 0
    compression_ratio: float = 1.0
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


# =============================================================================
# CONTENT INGESTION PIPELINE
# =============================================================================

class ContentIngestionPipeline:
    """
    Generic content ingestion coordinator.
    
    A-Team Approved: Context-window aware, query-aware, NO hardcoding.
    
    Decision Logic:
    1. If content <= max_tokens → pass through (no processing)
    2. If content <= model_context_window → compress (LLM can handle it)
    3. If content > model_context_window → chunk (too large for LLM)
    4. If chunked result still > max_tokens → compress (two-stage)
    
    Key Principles (A-Team Consensus):
    - Token checks BEFORE calling LLM (never send 200k tokens to compressor!)
    - Context-window aware (adapts to model, no magic numbers)
    - Query-aware (for relevant chunk selection)
    - Two-stage when needed (chunk → compress)
    - Fail fast with helpful errors
    """
    
    def __init__(self, config=None):
        """
        Initialize content ingestion pipeline.
        
        Args:
            config: Optional SynapseConfig. Passed to UnifiedCompressor so it uses
                    the lightweight model for compression instead of the main expensive model.
        
        Lazy-loads components to avoid import cycles and reduce startup time.
        """
        self._chunker = None
        self._compressor = None
        self.config = config
        
        # Get model's context window (with fallback)
        self.model_context_window = self._get_model_context_window()
        self.safety_margin = 2000  # Reserve for prompt, response, etc.
        
        logger.info(
            f"🔧 ContentIngestionPipeline initialized "
            f"(model_context={self.model_context_window}, safety={self.safety_margin})"
        )
    
    @property
    def chunker(self):
        """Lazy-load UnifiedChunker."""
        if self._chunker is None:
            from .unified_chunker import UnifiedChunker
            self._chunker = UnifiedChunker()
            logger.debug("  ✅ UnifiedChunker lazy-loaded")
        return self._chunker
    
    @property
    def compressor(self):
        """Lazy-load UnifiedCompressor."""
        if self._compressor is None:
            from .unified_compression import UnifiedCompressor
            self._compressor = UnifiedCompressor(config=self.config)
            logger.debug(f"  ✅ UnifiedCompressor lazy-loaded (config={'yes' if self.config else 'none'})")
        return self._compressor
    
    def _get_model_context_window(self) -> int:
        """
        Get model's context window size dynamically.
        
        A-Team Requirement: NO hardcoded thresholds!
        Uses token_counter.py catalog for accurate limits.
        
        Priority:
        1. DSPy LM's context_window attribute
        2. Model limits catalog (token_counter.py)
        3. Fallback: 128000 (modern model minimum)
        """
        # Strategy 1: Get from DSPy LM settings
        if DSPY_AVAILABLE:
            try:
                if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                    lm = dspy.settings.lm
                    # Try context_window attribute
                    context_window = getattr(lm, 'context_window', None)
                    if context_window and context_window > 0:
                        logger.debug(f"  Model context window from DSPy LM: {context_window}")
                        return context_window
                    
                    # Strategy 2: Try model name + catalog lookup
                    model_name = getattr(lm, 'model', None) or getattr(lm, 'model_name', None)
                    if model_name:
                        try:
                            from .token_counter import get_model_limits
                            limits = get_model_limits(model_name)
                            ctx = limits.get('max_prompt', 128000)
                            logger.info(f"  📊 Model context window from catalog for '{model_name}': {ctx}")
                            return ctx
                        except (ImportError, ValueError) as e:
                            logger.debug(f"  Could not get limits from catalog: {e}")
            except Exception as e:
                logger.debug(f"Could not get model context window from DSPy: {e}")
        
        # Strategy 3: Reasonable modern default (NOT 8000!)
        # A-TEAM FIX: Modern models have at least 128k context
        logger.warning("⚠️ Could not determine model context window, using 128000 (modern default)")
        return 128000
    
    def _estimate_tokens(self, content: str) -> int:
        """Estimate token count for content."""
        try:
            from .token_utils import count_tokens_accurate
            return count_tokens_accurate(content)
        except ImportError:
            # Fallback: rough estimation
            return len(content) // 4
    
    async def process(
        self,
        content: str,
        max_tokens: int,
        query: Optional[str] = None,
        goal: Optional[str] = None,
        context_type: str = "general",
        _recursion_depth: int = 0,
        **kwargs
    ) -> IngestionResult:
        """
        Process content to fit within max_tokens budget.
        
        This is the MAIN entry point for all content ingestion.
        
        Args:
            content: The content to process
            max_tokens: Maximum tokens in output
            query: Query for relevance scoring (required for chunking)
            goal: Overall goal (optional, for context)
            context_type: Type of content ("terminal", "web", "file", "general")
            _recursion_depth: Internal parameter to track recursion depth (max 5)
            **kwargs: Additional args passed to compressor/chunker
        
        Returns:
            IngestionResult with processed content and metadata
        
        Raises:
            ValueError: If content is too large and no query provided for chunking
            RecursionError: If recursion depth exceeds maximum (5)
        """
        if not content:
            return IngestionResult(
                content="",
                original_tokens=0,
                final_tokens=0,
                processing_path="empty"
            )
        
        # Prevent infinite recursion
        MAX_RECURSION_DEPTH = 5
        if _recursion_depth >= MAX_RECURSION_DEPTH:
            logger.error(
                f"❌ Maximum recursion depth ({MAX_RECURSION_DEPTH}) exceeded. "
                f"Content may be too large or chunking ineffective."
            )
            # Fallback: truncate
            from .token_utils import truncate_to_token_limit
            truncated = truncate_to_token_limit(content, max_tokens)
            return IngestionResult(
                content=truncated,
                original_tokens=self._estimate_tokens(content),
                final_tokens=self._estimate_tokens(truncated),
                processing_path="truncate_max_recursion",
                metadata={"recursion_depth": _recursion_depth}
            )
        
        # Estimate current token count
        current_tokens = self._estimate_tokens(content)
        
        if _recursion_depth > 0:
            logger.info(f"🔄 Recursive processing (depth {_recursion_depth}): {current_tokens} tokens")
        
        logger.info(f"📥 Ingesting content: {current_tokens} tokens → target {max_tokens} tokens")
        logger.info(f"   Type: {context_type}")
        if query:
            logger.info(f"   Query: {query[:100]}...")
        if goal:
            logger.info(f"   Goal: {goal[:100]}...")
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DECISION 1: Pass-through (already within budget)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if current_tokens <= max_tokens:
            logger.info(f"✅ Pass-through: content already within budget ({current_tokens}/{max_tokens})")
            return IngestionResult(
                content=content,
                original_tokens=current_tokens,
                final_tokens=current_tokens,
                processing_path="passthrough",
                compression_ratio=1.0
            )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DECISION 2: Compress (content fits in model's context window)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        # Validate that max_tokens is reasonable for the model context
        max_output_reasonable = self.model_context_window - self.safety_margin - 64000  # Leave room for input
        adjusted_max_tokens = max_tokens
        
        if max_tokens > max_output_reasonable:
            logger.warning(
                f"⚠️  Requested max_tokens ({max_tokens}) exceeds reasonable limit "
                f"for model context ({self.model_context_window}). Capping to {max_output_reasonable}."
            )
            # Auto-adjust to prevent negative max_compressor_input
            adjusted_max_tokens = max_output_reasonable
        
        max_compressor_input = self.model_context_window - adjusted_max_tokens - self.safety_margin
        
        if current_tokens <= max_compressor_input:
            logger.info(f"🗜️  Compressing: content fits in model window ({current_tokens}/{max_compressor_input})")
            
            try:
                # Compressor can handle entire content (use adjusted max_tokens)
                compressed = await self.compressor.compress(
                    content=content,
                    max_tokens=adjusted_max_tokens,
                    task_description=query or "Process content",
                    goal=goal,
                    purpose=f"ingestion_{context_type}",
                    **kwargs
                )
                
                final_tokens = self._estimate_tokens(compressed)
                
                logger.info(f"✅ Compressed: {current_tokens} → {final_tokens} tokens")
                
                return IngestionResult(
                    content=compressed,
                    original_tokens=current_tokens,
                    final_tokens=final_tokens,
                    processing_path="compress",
                    compression_ratio=final_tokens / current_tokens if current_tokens > 0 else 1.0
                )
            
            except Exception as e:
                logger.error(f"❌ Compression failed: {e}")
                logger.warning(f"   Falling back to chunking...")
                # Fall through to chunking
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # DECISION 3: Chunk (too large for compressor)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        logger.info(f"📄 Chunking: content too large for compressor ({current_tokens} > {max_compressor_input})")
        
        # Require query for chunk selection
        if not query:
            logger.warning("⚠️ No query provided, using generic query")
            query = "Extract the most important and relevant information"
        
        try:
            # Chunk and select relevant
            chunked = await self.chunker.chunk_and_select(
                content=content,
                query=query,
                goal=goal,
                max_tokens=max_tokens,
                context_hints=f"Content type: {context_type}",
                **kwargs
            )
            
            chunked_tokens = self._estimate_tokens(chunked)
            
            logger.info(f"✅ Chunked: {current_tokens} → {chunked_tokens} tokens")
            
            # Get chunk stats
            chunks = self.chunker.chunk_content(content)
            chunks_total = len(chunks)
            # Estimate chunks used (rough)
            chunks_used = int((chunked_tokens / current_tokens) * chunks_total) if current_tokens > 0 else 0
            
            # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            # DECISION 4: Two-stage (chunked result still too large?)
            # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if chunked_tokens > max_tokens:
                logger.info(f"🗜️  Two-stage: chunked result still too large ({chunked_tokens}/{max_tokens})")
                
                # 🔧 FIX: Check if chunked content fits within compressor's input limit
                # Recalculate max_compressor_input for two-stage compression
                max_output_reasonable = self.model_context_window - self.safety_margin - 64000
                adjusted_max_tokens = min(max_tokens, max_output_reasonable)
                max_compressor_input_two_stage = self.model_context_window - adjusted_max_tokens - self.safety_margin
                
                if chunked_tokens > max_compressor_input_two_stage:
                    logger.warning(
                        f"⚠️  Chunked content ({chunked_tokens} tokens) still exceeds compressor input limit "
                        f"({max_compressor_input_two_stage} tokens). "
                        f"Chunking again recursively..."
                    )
                    
                    # 🔧 FIX: Recursively process the chunked content through the pipeline
                    # This will chunk it AGAIN if still too large, then compress
                    try:
                        recursive_result = await self.process(
                            content=chunked,
                            max_tokens=max_tokens,
                            query=query,
                            goal=goal,
                            context_type=context_type,
                            _recursion_depth=_recursion_depth + 1,
                            **kwargs
                        )
                        
                        logger.info(
                            f"✅ Recursive two-stage complete: "
                            f"{current_tokens} → {chunked_tokens} → {recursive_result.final_tokens} tokens"
                        )
                        
                        return IngestionResult(
                            content=recursive_result.content,
                            original_tokens=current_tokens,
                            final_tokens=recursive_result.final_tokens,
                            processing_path=f"chunk+recursive_{recursive_result.processing_path}",
                            chunks_used=chunks_used,
                            chunks_total=chunks_total,
                            compression_ratio=recursive_result.final_tokens / current_tokens if current_tokens > 0 else 1.0,
                            metadata={
                                "stage1_tokens": chunked_tokens,
                                "stage2_tokens": recursive_result.final_tokens,
                                "recursive_path": recursive_result.processing_path
                            }
                        )
                    except Exception as e:
                        logger.error(f"❌ Recursive two-stage compression failed: {e}")
                        logger.warning(f"   Returning chunked result despite exceeding budget")
                        # Return chunked result even if recursive compression failed
                else:
                    # Chunked content fits within compressor input limit - proceed with compression
                    logger.info(f"   Applying compression to combined chunks ({chunked_tokens}/{max_compressor_input_two_stage} tokens)...")
                    
                    try:
                        # Compress the combined chunks
                        compressed = await self.compressor.compress(
                            content=chunked,
                            max_tokens=adjusted_max_tokens,
                            task_description=query,
                            goal=goal,
                            purpose=f"ingestion_{context_type}_two_stage",
                            **kwargs
                        )
                        
                        final_tokens = self._estimate_tokens(compressed)
                        
                        logger.info(f"✅ Two-stage complete: {current_tokens} → {chunked_tokens} → {final_tokens} tokens")
                        
                        return IngestionResult(
                            content=compressed,
                            original_tokens=current_tokens,
                            final_tokens=final_tokens,
                            processing_path="chunk+compress",
                            chunks_used=chunks_used,
                            chunks_total=chunks_total,
                            compression_ratio=final_tokens / current_tokens if current_tokens > 0 else 1.0,
                            metadata={
                                "stage1_tokens": chunked_tokens,
                                "stage2_tokens": final_tokens
                            }
                        )
                    
                    except Exception as e:
                        logger.error(f"❌ Two-stage compression failed: {e}")
                        logger.warning(f"   Returning chunked result despite exceeding budget")
                        # Return chunked result even if compression failed
            
            # Chunking alone was sufficient
            return IngestionResult(
                content=chunked,
                original_tokens=current_tokens,
                final_tokens=chunked_tokens,
                processing_path="chunk",
                chunks_used=chunks_used,
                chunks_total=chunks_total,
                compression_ratio=chunked_tokens / current_tokens if current_tokens > 0 else 1.0
            )
        
        except Exception as e:
            logger.error(f"❌ Chunking failed: {e}")
            logger.warning(f"   Falling back to simple truncation")
            
            # Last resort: truncate
            from .token_utils import truncate_to_token_limit
            truncated = truncate_to_token_limit(content, max_tokens)
            final_tokens = self._estimate_tokens(truncated)
            
            return IngestionResult(
                content=truncated,
                original_tokens=current_tokens,
                final_tokens=final_tokens,
                processing_path="truncate_fallback",
                compression_ratio=final_tokens / current_tokens if current_tokens > 0 else 1.0,
                metadata={"error": str(e)}
            )
    
    def process_sync(
        self,
        content: str,
        max_tokens: int,
        query: Optional[str] = None,
        goal: Optional[str] = None,
        context_type: str = "general",
        **kwargs
    ) -> IngestionResult:
        """
        Sync version of process() for sync workflows.
        
        Handles three scenarios:
        1. No running event loop → use asyncio.run() (cleanest)
        2. Running event loop (e.g. inside asyncio.to_thread) → spawn a
           fresh event loop in a separate thread to avoid
           "this event loop is already running" error
        3. Fallback → ThreadPoolExecutor
        """
        import asyncio
        import concurrent.futures
        
        coro = self.process(content, max_tokens, query, goal, context_type, **kwargs)
        
        try:
            asyncio.get_running_loop()
            # We're inside a running event loop — cannot use run_until_complete.
            # Spawn the coroutine in a brand-new thread with its own event loop.
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        except RuntimeError:
            # No running loop — safe to use asyncio.run()
            return asyncio.run(coro)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'IngestionResult',
    'ContentIngestionPipeline',
]
