"""
SYNAPSE Conductor v2.3 - Brain-Inspired Multi-Actor Orchestration with Agentic Data Discovery
================================================================================================

SOTA Agentic Architecture with:
- Multi-actor orchestration with shared learning
- LLM-based Q-Predictor and Value Estimator (no static tables!)
- SmartContextGuard (NEVER out of context)
- PolicyExplorer with dynamic Roadmap
- Prompt updates as weight updates (online learning)
- Exploration until full reward (all Auditors pass)

BRAIN-INSPIRED ENHANCEMENTS (v2.1):
- Sharp Wave Ripple: Memory consolidation during "sleep"
- Hippocampal Extraction: What to remember (salience, novelty, relevance)
- Online/Offline Modes: Awake (learning) vs Sleep (consolidation)
- Agent Abstraction: Scalable swarm management
- Predictive MARL: Predict other agents, learn from divergence

A-TEAM AUTO-RESOLUTION (v2.2):
- Signature introspection: Auto-detects what each actor needs
- Parameter resolution: Auto-resolves from context providers and previous outputs
- Dependency graph: Auto-infers actor dependencies
- Zero hardcoding: Works with ANY agents, ANY domains

A-TEAM DATA REGISTRY (v2.3):
- Agentic data discovery: Agents can discover available data
- Semantic search: Find data by type, tags, fields
- Auto-registration: All outputs automatically indexed
- Type detection: HTML, DataFrames, files, predictions
- Non-breaking: Optional feature, backwards compatible

A-Team Design:
- Dr. Manning: Multi-agent TD(λ) with adaptive learning
- Dr. Chen: Inter-actor communication and coordination
- Dr. Agarwal: LLM-based everything (no embeddings)
- Aristotle: Causal learning across actors
- Shannon: Information-theoretic context management
- Alex: Robust persistence and health monitoring
"""

import asyncio
import inspect  # 🔑 NEW: For signature introspection
import json
import time
import traceback
import uuid  # 🔑 NEW: For unique run IDs
import warnings
from typing import List, Dict, Any, Optional, Tuple, Callable, Union, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from enum import Enum
import logging

# 🔇 Suppress DSPy's "use module(...) instead of module.forward(...)" warnings
# These are informational and don't affect functionality
warnings.filterwarnings("ignore", message=".*module.forward.*discouraged.*", category=UserWarning)

# 🔑 NEW: Import Data Registry
from .data_registry import DataRegistry, DataRegistryTool, DataArtifact, set_active_registry
from .io_manager import IOManager, ActorOutput, SwarmResult  # 🆕 A-TEAM: Typed output management
from .smart_data_transformer import SmartDataTransformer  # 🆕 A-TEAM: Intelligent data transformation
from .token_utils import smart_truncate  # 🔴 A-TEAM FIX: Token-aware truncation (replaces [:N] slicing)
from .axon import SmartAgentSlack, AgentCapabilities, Message  # 🆕 A-TEAM: Intelligent agent communication
from .skill_registry import SkillRegistry
from .skill_validation import SkillValidator
from .skill_runtime import SkillRuntime

# 🤝 NEW: Import FeedbackChannel for agent coordination
from .feedback_channel import FeedbackChannel, FeedbackMessage, FeedbackType

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

from .data_structures import SynapseConfig, EpisodeResult, OutputTag, MemoryLevel
from .cortex import HierarchicalMemory
from .swarm_learner import SwarmLearner, SwarmLearnerSignature  # 🔴 A-TEAM FIX: Import canonical version
from .persistence import Vault
from .roadmap import MarkovianTODO, SubtaskState, TaskStatus  # Enhanced TODO with all methods
from .agent_config import AgentConfig  # SYNAPSE v1.0: Unified agent config

# Brain-inspired memory modules were removed in favour of HierarchicalMemory.
# Constants kept as False for any residual guard clauses; no live code depends on them.

# ──────────────────────────────────────────────────────────────────────
# 🔴 A-TEAM FIX: Lightweight result builder to prevent SSE serialization hangs
# EpisodeResult objects can be 200KB+, with circular references.
# This extracts only what the frontend / downstream needs.
# ──────────────────────────────────────────────────────────────────────
def _to_lightweight_result(result, actor_name: str = "", task_id: str = "", max_output_chars: int = 2000):
    """Convert a potentially massive result object into a small, JSON-safe dict."""
    if result is None or isinstance(result, bool):
        return result
    if isinstance(result, (str, int, float)):
        return result
    if isinstance(result, dict):
        # Already a dict – keep it but cap large string values
        safe = {}
        for k, v in result.items():
            if isinstance(v, str) and len(v) > max_output_chars:
                safe[k] = v[:max_output_chars] + "…(truncated)"
            elif isinstance(v, (str, int, float, bool, type(None))):
                safe[k] = v
            elif isinstance(v, (list, tuple)):
                safe[k] = str(v)[:max_output_chars]
            else:
                safe[k] = str(v)[:max_output_chars]
        return safe
    # Handle EpisodeResult / dataclass-like / DSPy Prediction
    lightweight = {
        "_lightweight": True,
        "actor_name": actor_name,
        "task_id": task_id,
    }
    for attr in ("success", "valid", "final_output", "output", "reasoning", "error"):
        val = getattr(result, attr, None)
        if val is not None:
            val_str = str(val)
            lightweight[attr] = val_str[:max_output_chars] + ("…" if len(val_str) > max_output_chars else "")
    # Pull tagged outputs / output_fields summaries if available
    if hasattr(result, "output_fields") and isinstance(result.output_fields, dict):
        lightweight["output_fields_keys"] = list(result.output_fields.keys())[:20]
    if hasattr(result, "tagged_outputs") and isinstance(result.tagged_outputs, dict):
        lightweight["tagged_output_keys"] = list(result.tagged_outputs.keys())[:20]
    return lightweight


# SimpleBrain / Experience — fully removed (dead code, never referenced)

# Import predictive MARL
try:
    from .predictive_marl import (
        LLMTrajectoryPredictor, DivergenceMemory,
        CooperativeCreditAssigner, PredictedTrajectory, ActualTrajectory,
        Divergence
    )
    PREDICTIVE_MARL_AVAILABLE = True
except ImportError:
    PREDICTIVE_MARL_AVAILABLE = False

# Import robust parsing utilities (A-Team Approved)
try:
    from .robust_parsing import (
        parse_float_robust
    )
    ROBUST_PARSING_AVAILABLE = True
except ImportError:
    ROBUST_PARSING_AVAILABLE = False

# Import Q-Learning with NeuroChunk Memory Management
try:
    from .q_learning import LLMQPredictor as NaturalLanguageQTable  # Use full Q-table implementation
    from .q_learning import AsyncQLearningUpdater  # 🔥 A-TEAM: Non-blocking async updates
    Q_LEARNING_AVAILABLE = True
    ASYNC_Q_LEARNING_AVAILABLE = True
except ImportError:
    Q_LEARNING_AVAILABLE = False
    ASYNC_Q_LEARNING_AVAILABLE = False

# Import TD(λ) Learning
try:
    from .learning import TDLambdaLearner
    TD_LAMBDA_AVAILABLE = True
except ImportError:
    TD_LAMBDA_AVAILABLE = False

# Time-Aware Execution Framework
# 🔴 A-TEAM FIX: Re-enabled StuckDetector — agents must not loop forever
try:
    from .time_aware_execution import StuckDetector, TimeAwareExecutor, PhaseType
    TIME_AWARE_AVAILABLE = True
except ImportError:
    TIME_AWARE_AVAILABLE = False
    # Stub classes for backward compatibility ONLY if module genuinely missing
    class StuckDetector:
        def record_action(self, *args): return None
        def record_error(self, *args): return None
        def record_progress(self, *args): return None
    class TimeAwareExecutor:
        pass
    class PhaseType:
        EXPLORATION = "exploration"
    def create_time_aware_context_injection(*args, **kwargs): return {}

# Import AgenticAgentSelector for intelligent agent selection
try:
    from .tool_shed import AgenticAgentSelector
    AGENTIC_AGENT_SELECTOR_AVAILABLE = True
except ImportError:
    AGENTIC_AGENT_SELECTOR_AVAILABLE = False

# Import DynamicTaskPlanner for LLM-based goal decomposition
# 🎯 A-TEAM FIX: This enables true recursive language model task decomposition
try:
    from .dynamic_task_planner import DynamicTaskPlanner
    DYNAMIC_TASK_PLANNER_AVAILABLE = True
except ImportError:
    DYNAMIC_TASK_PLANNER_AVAILABLE = False

# Import logging config (prefer get_logger if available)
try:
    from .logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

# Import GenericAgentRegistry for capability inference
try:
    from .generic_agent_registry import GenericAgentRegistry
    AGENT_REGISTRY_AVAILABLE = True
except ImportError:
    AGENT_REGISTRY_AVAILABLE = False

# 🔴 A-TEAM: OptimalTaskPlanner and TimeBudgetPlanner archived to _archived_dead_code/
# They were never used in any active flow. Flags kept for backward compatibility.
    OPTIMAL_TASK_PLANNER_AVAILABLE = False
TIME_BUDGET_PLANNER_AVAILABLE = False


# =============================================================================
# MARKOVIAN TODO - Long-Horizon Task Management
# =============================================================================

@dataclass
class TodoItem:
    """A single TODO item with RL metadata."""
    id: str
    description: str
    actor: str  # Which actor handles this
    status: str  # pending, in_progress, completed, failed, blocked
    priority: float  # 0-1, learned priority
    estimated_reward: float  # Q-value estimate
    dependencies: List[str] = field(default_factory=list)
    attempts: int = 0
    max_attempts: int = 5
    failure_reasons: List[str] = field(default_factory=list)
    completion_time: Optional[float] = None


# =============================================================================
# NOTE: MarkovianTODO is now imported from enhanced_state.py
# =============================================================================
# The enhanced MarkovianTODO has all the methods we need:
# - record_intermediary_values()
# - update_q_value()
# - predict_next()
# - get_state_summary()
# - Compatibility properties: .items, .completed
#
# Keeping TodoItem for backward compatibility with other components
# =============================================================================

# @dataclass
# class MarkovianTODO:  ← DEPRECATED: Use enhanced_state.MarkovianTODO
#     """DEPRECATED - Use MarkovianTODO from enhanced_state.py"""
#     root_task: str = ""
#     items: Dict[str, TodoItem] = field(default_factory=dict)
#     current_path: List[str] = field(default_factory=list)
#     completed: List[str] = field(default_factory=list)
#     failed: List[str] = field(default_factory=list)
#     estimated_remaining_steps: int = 0
#     
#     # RL state
#     state_history: List[Dict] = field(default_factory=list)
#     total_reward: float = 0.0
# 
# ALL METHODS REMOVED - Using enhanced_state.MarkovianTODO instead
# (which has all these methods plus more: record_intermediary_values, update_q_value, etc.)


# =============================================================================
# DSPy SIGNATURES FOR CONDUCTOR COMPONENTS
# =============================================================================


class ContextAllocationSignature(dspy.Signature):
    """
    Allocate context budget across items (LLM-based, no heuristics).
    """
    items = dspy.InputField(desc="JSON list of items with key, priority, size_tokens")
    required_keys = dspy.InputField(desc="JSON list of keys that must be included")
    max_tokens = dspy.InputField(desc="Maximum total tokens allowed")
    
    reasoning = dspy.OutputField(desc="How allocation was decided")
    allocation = dspy.OutputField(desc="JSON list of {key, max_tokens, compress} items to include")


class TaskCoverageSignature(dspy.Signature):
    """
    Decide if completed work covers another pending task (LLM-based).
    """
    completed_work = dspy.InputField(desc="Summary of completed work/output")
    pending_task = dspy.InputField(desc="Pending task description")
    goal_context = dspy.InputField(desc="Root goal for context")
    
    reasoning = dspy.OutputField(desc="Why the pending task is or is not covered")
    is_covered = dspy.OutputField(desc="True if completed work covers the pending task")


class ErrorPatternSignature(dspy.Signature):
    """Extract structured error patterns and resolutions from trajectory (LLM-based)."""
    trajectory_json = dspy.InputField(desc="JSON list of trajectory steps with errors/tool calls")
    goal_context = dspy.InputField(desc="Root goal context")
    
    reasoning = dspy.OutputField(desc="How error patterns were inferred")
    error_patterns = dspy.OutputField(desc="JSON list of error patterns and suggested resolutions")


class OverflowDetectionSignature(dspy.Signature):
    """
    Determine if an error indicates context overflow.
    """
    error_message = dspy.InputField(desc="Error message or summary")
    context_tokens = dspy.InputField(desc="Current context size in tokens")
    max_tokens = dspy.InputField(desc="Maximum allowed tokens")
    
    is_overflow = dspy.OutputField(desc="True if error indicates context overflow")
    reasoning = dspy.OutputField(desc="Why this is or is not an overflow")


class MissingParameterSignature(dspy.Signature):
    """
    Extract missing parameter names from an error message.
    """
    error_message = dspy.InputField(desc="Error message from actor execution")
    signature_json = dspy.InputField(desc="JSON of expected input parameters")
    provided_params = dspy.InputField(desc="JSON of provided parameters")
    
    reasoning = dspy.OutputField(desc="Why these parameters are missing")
    missing_params = dspy.OutputField(desc="JSON list of missing parameter names")


# =============================================================================
# SMART CONTEXT GUARD - NEVER Out of Context
# =============================================================================

class SmartContextGuard:
    """
    Ensures we NEVER exceed context length by:
    - Priority-based compression
    - Task-critical preservation (TODO always kept)
    - Intelligent summarization
    - Graceful degradation
    """
    
    # Priority levels
    CRITICAL = 0   # NEVER remove (root goal, current task)
    HIGH = 1       # Remove only if desperate (recent trajectory)
    MEDIUM = 2     # Can compress (memories, examples)
    LOW = 3        # Remove first (verbose logs)
    
    def __init__(self, max_tokens: int = 28000, safety_margin: int = None, config=None):
        self.max_tokens = max_tokens
        self.config = config
        # A-Team: Make safety_margin configurable (was hardcoded 2000)
        self.safety_margin = safety_margin if safety_margin is not None else 2000
        self.usable_tokens = max_tokens - self.safety_margin  # Use self.safety_margin, not safety_margin
        self._token_model = None
        
        # Priority buffers
        self.buffers: Dict[int, List[Tuple[str, str, int]]] = {
            self.CRITICAL: [],
            self.HIGH: [],
            self.MEDIUM: [],
            self.LOW: []
        }
        
        # LLM-based components (no heuristics)
        self._allocator = dspy.ChainOfThought(ContextAllocationSignature) if DSPY_AVAILABLE else None
        self._overflow_detector = dspy.ChainOfThought(OverflowDetectionSignature) if DSPY_AVAILABLE else None
    
    def estimate_tokens(self, text: str) -> int:
        """Estimate token count using tokencost (accurate, no heuristics)."""
        from .token_utils import count_tokens_accurate
        model = self._token_model or getattr(dspy.settings, "lm", None)
        model_name = getattr(model, "model", None) if model else None
        return count_tokens_accurate(text, model_name)
    
    def register(self, key: str, content: str, priority: int):
        """Register content with priority."""
        tokens = self.estimate_tokens(content)
        self.buffers[priority].append((key, content, tokens))
    
    def register_critical(self, key: str, content: str):
        """Register CRITICAL content (goal, current task)."""
        self.register(key, content, self.CRITICAL)
    
    def build_context(self) -> Tuple[str, Dict[str, Any]]:
        """
        Build context that fits within limit.
        
        Returns:
            (context_string, metadata)
        """
        items = []
        required_keys = []
        for priority, entries in self.buffers.items():
            for key, content, tokens in entries:
                items.append({
                    "key": key,
                    "priority": priority,
                    "size_tokens": tokens
                })
                if priority == self.CRITICAL:
                    required_keys.append(key)
        
        # If no LLM allocator, include only CRITICAL items (explicit uncertainty)
        if not self._allocator:
            context_parts = []
            total_tokens = 0
            included = {}
            for key, content, tokens in self.buffers[self.CRITICAL]:
                context_parts.append(f"## {key}\n{content}\n")
                total_tokens += tokens
                included[key] = tokens
            return "\n".join(context_parts), {
                'total_tokens': total_tokens,
                'max_tokens': self.usable_tokens,
                'included': included,
                'truncated': {},
                'utilization': total_tokens / max(1, self.usable_tokens),
                'note': 'LLM allocator unavailable; included CRITICAL only'
            }
        
        try:
            result = self._allocator(
                items=json.dumps(items),
                required_keys=json.dumps(required_keys),
                max_tokens=str(self.usable_tokens)
            )
            allocation = json.loads(result.allocation) if hasattr(result, "allocation") else []
        except Exception as e:
            logger.debug(f"LLM context allocation failed: {e}")
            allocation = [{"key": k, "max_tokens": self.usable_tokens, "compress": False} for k in required_keys]
        
        context_parts = []
        included = {}
        truncated = {}
        total_tokens = 0
        
        content_map = {key: content for priority, entries in self.buffers.items() for key, content, _ in entries}
        token_map = {key: tokens for priority, entries in self.buffers.items() for key, _, tokens in entries}
        
        for item in allocation:
            key = item.get("key")
            if key not in content_map:
                continue
            max_tokens = int(item.get("max_tokens", token_map.get(key, 0)))
            compress = bool(item.get("compress", False))
            content = content_map[key]
            
            if compress:
                content = self._smart_compress(content, max_tokens)
                truncated[key] = (token_map.get(key, 0), max_tokens)
            
            context_parts.append(f"## {key}\n{content}\n")
            total_tokens += min(token_map.get(key, 0), max_tokens)
            included[key] = min(token_map.get(key, 0), max_tokens)
        
        return "\n".join(context_parts), {
            'total_tokens': total_tokens,
            'max_tokens': self.usable_tokens,
            'included': included,
            'truncated': truncated,
            'utilization': total_tokens / max(1, self.usable_tokens)
        }
    
    def clear(self):
        """Clear all buffers."""
        for priority in self.buffers:
            self.buffers[priority] = []
    
    def process_large_document(self, document: str, query: str) -> str:
        """
        A-Team Enhancement: LLM-based compression for oversized documents.
        """
        doc_tokens = self.estimate_tokens(document)
        
        # If document fits, return as-is
        if doc_tokens <= self.usable_tokens:
            return document
        
        logger.info(f"📄 Large document detected ({doc_tokens} tokens), compressing with LLM")
        return self._smart_compress(document, self.usable_tokens)
    
    def catch_and_recover(self, error: Exception, current_context: str) -> Optional[str]:
        """
        A-Team Fix: LLM-based error interception (no regex, no heuristics).
        """
        if not self._overflow_detector:
            return None
        
        try:
            result = self._overflow_detector(
                error_message=smart_truncate(str(error), max_tokens=125),
                context_tokens=str(self.estimate_tokens(current_context)),
                max_tokens=str(self.usable_tokens)
            )
            is_overflow = bool(getattr(result, "is_overflow", False))
            if is_overflow:
                logger.warning("🔄 LLM detected token overflow; compressing context")
                return self._smart_compress(current_context, self.usable_tokens)
        except Exception as e:
            logger.debug(f"LLM overflow detection failed: {e}")
        
        return None
    
    def _smart_compress(self, content: str, max_tokens: int) -> str:
        """
        A-Team Enhancement: Use ContentIngestionPipeline for automatic chunking.
        
        🔧 FIX: Uses ContentIngestionPipeline.process_sync() which automatically
        chunks large content before compression, preventing "content too large" errors.
        """
        try:
            # Lazy-load ContentIngestionPipeline
            if not hasattr(self, '_content_ingestion_pipeline'):
                from .content_ingestion import ContentIngestionPipeline
                self._content_ingestion_pipeline = ContentIngestionPipeline(config=self.config)
            
            # Use pipeline which handles chunking automatically for large content
            result = self._content_ingestion_pipeline.process_sync(
                content=content,
                max_tokens=max_tokens,
                query="Compress context while preserving critical information",
                goal="Context compression",
                context_type="context"
            )
            # process_sync returns IngestionResult with .content attribute
            return result.content
        except Exception as e:
            logger.debug(f"ContentIngestionPipeline failed: {e}")
            return content
    
    def emergency_compress(self, context: str, target_limit: int) -> str:
        """
        🚨 EMERGENCY: Multi-layer compression when API rejects context.
        
        Compression chain (each layer attempts if previous not enough):
        1. SmartContextGuard compression (LLM-based)
        2. UnifiedCompressor (LLM-based, more aggressive)
        3. UnifiedChunker (keep only most relevant chunks)
        4. Simple truncation (LAST RESORT - logs ERROR)
        
        Args:
            context: Oversized context that was rejected
            target_limit: Target token limit (from API error or learned limit)
        
        Returns:
            Compressed context that fits within target_limit
        """
        logger.warning(f"🚨 EMERGENCY COMPRESSION: {self.estimate_tokens(context):,} tokens → target {target_limit:,} tokens")
        
        # Layer 1: SmartContextGuard compression (already in use)
        compressed = self._smart_compress(context, target_limit)
        compressed_tokens = self.estimate_tokens(compressed)
        
        if compressed_tokens <= target_limit:
            logger.info(f"✅ Layer 1 (SmartContextGuard) SUCCESS: {compressed_tokens:,} tokens")
            return compressed
        
        logger.warning(f"⚠️  Layer 1 insufficient: {compressed_tokens:,} > {target_limit:,} | trying Layer 2...")
        
        # Layer 2: ContentIngestionPipeline (more aggressive LLM compression with chunking)
        try:
            # 🔧 FIX: Use ContentIngestionPipeline instead of UnifiedCompressor directly
            # Pipeline handles chunking automatically if content is still too large
            if not hasattr(self, '_content_ingestion_pipeline'):
                from .content_ingestion import ContentIngestionPipeline
                self._content_ingestion_pipeline = ContentIngestionPipeline(config=self.config)
            
            result = self._content_ingestion_pipeline.process_sync(
                content=compressed,
                max_tokens=target_limit,
                query="Emergency compression: preserve most critical information",
                goal="Emergency context management",
                context_type="emergency"
            )
            compressed = result.content
            compressed_tokens = self.estimate_tokens(compressed)
            
            if compressed_tokens <= target_limit:
                logger.info(f"✅ Layer 2 (ContentIngestionPipeline) SUCCESS: {compressed_tokens:,} tokens")
                return compressed
            
            logger.warning(f"⚠️  Layer 2 insufficient: {compressed_tokens:,} > {target_limit:,} | trying Layer 3...")
        except Exception as e:
            logger.error(f"Layer 2 (ContentIngestionPipeline) FAILED: {e} | trying Layer 3...")
        
        # Layer 3: UnifiedChunker (keep only most relevant chunks)
        try:
            from .unified_chunker import UnifiedChunker
            chunker = UnifiedChunker()
            chunks = chunker.chunk(
                content=compressed,
                query="most important information",  # Generic query
                max_tokens=target_limit // 2  # Aim for half to leave room
            )
            
            if chunks:
                # Take first chunk (most relevant)
                compressed = chunks[0]
                compressed_tokens = self.estimate_tokens(compressed)
                
                if compressed_tokens <= target_limit:
                    logger.info(f"✅ Layer 3 (UnifiedChunker) SUCCESS: {compressed_tokens:,} tokens")
                    return compressed
                
                logger.warning(f"⚠️  Layer 3 insufficient: {compressed_tokens:,} > {target_limit:,} | LAST RESORT...")
        except Exception as e:
            logger.error(f"Layer 3 (UnifiedChunker) FAILED: {e} | LAST RESORT...")
        
        # Layer 4: LAST RESORT - Simple truncation
        logger.error(f"🚨 LAST RESORT: Simple truncation to {target_limit:,} tokens!")
        logger.error("⚠️  THIS IS NON-AGENTIC FALLBACK - SHOULD NOT HAPPEN IN PRODUCTION!")
        
        # Approximate: 4 chars per token on average
        target_chars = target_limit * 4
        truncated = compressed[:target_chars]
        
        logger.error(f"🚨 Truncated to {len(truncated)} chars (≈{target_limit:,} tokens)")
        return truncated


# =============================================================================
# POLICY EXPLORER - Dynamic TODO with Exploration
# =============================================================================

class PolicyExplorerSignature(dspy.Signature):
    """LLM-based policy exploration for finding better action sequences."""
    
    current_state = dspy.InputField(desc="Current TODO state and failures")
    failed_actions = dspy.InputField(desc="Actions that have failed and why")
    available_actions = dspy.InputField(desc="Available alternative actions")
    goal = dspy.InputField(desc="Root goal to achieve")
    # 🔴 A-TEAM FIX: Add MARL predictions context for informed exploration
    predictions_context = dspy.InputField(desc="MARL predictions about agent behavior and expected outcomes (empty if unavailable)")
    
    analysis = dspy.OutputField(desc="Analysis of why current approach is failing")
    recommended_exploration = dspy.OutputField(desc="Specific alternative approach to try")
    new_todo_items = dspy.OutputField(desc="JSON list of new TODO items to try")
    confidence = dspy.OutputField(desc="Confidence this will work 0.0-1.0")


class PolicyExplorer:
    """
    Explores alternative policies when stuck.
    
    Instead of giving up when tasks fail:
    1. Analyzes failure patterns
    2. Generates alternative approaches
    3. Updates TODO with new exploration paths
    4. Tracks exploration history to avoid loops
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.explorer = dspy.ChainOfThought(PolicyExplorerSignature) if DSPY_AVAILABLE else None
        
        # Exploration state
        self.explored_paths: List[List[str]] = []
        self.exploration_count = 0
        self.max_explorations = self.config.max_exploration_iterations  # 🔧 STANFORD FIX
    
    def should_explore(self, todo: MarkovianTODO) -> bool:
        """Check if we should try a new exploration."""
        # Explore if: failed tasks exist, haven't explored too much
        has_failures = len(todo.failed_tasks) > 0
        can_explore = self.exploration_count < self.max_explorations
        not_repeated = todo.current_path not in self.explored_paths
        
        return has_failures and can_explore and not_repeated
    
    def explore(
        self, 
        todo: MarkovianTODO, 
        available_actions: List[Dict[str, Any]],
        goal: str,
        marl_predictions: Optional[Dict] = None  # 🔴 A-TEAM FIX: Accept MARL context
    ) -> List[TodoItem]:
        """
        Generate new TODO items through exploration.
        
        🔴 A-TEAM FIX: Now accepts MARL predictions for informed exploration.
        
        Returns:
            List of new TodoItems to try
        """
        if not self.explorer:
            return []
        
        self.exploration_count += 1
        self.explored_paths.append(todo.current_path.copy())
        
        # Gather failure info
        failed_info = []
        for task_id in todo.failed_tasks:
            task = todo.subtasks.get(task_id)
            if task:
                failed_info.append({
                    'task': task.description,
                    'actor': task.actor,
                    'reasons': task.failure_reasons
                })
        
        # 🔴 A-TEAM FIX: Format MARL predictions for exploration context
        predictions_str = "No MARL predictions available."
        if marl_predictions:
            predictions_str = smart_truncate(json.dumps(marl_predictions, default=str), max_tokens=200)
        
        try:
            result = self.explorer(
                current_state=smart_truncate(todo.get_state_summary(), max_tokens=375),
                failed_actions=smart_truncate(json.dumps(failed_info, default=str), max_tokens=250),
                available_actions=smart_truncate(json.dumps(available_actions[:10], default=str), max_tokens=250),
                goal=smart_truncate(goal, max_tokens=125),
                predictions_context=predictions_str
            )
            
            # Parse new TODO items
            new_items = []
            try:
                items_json = json.loads(result.new_todo_items or "[]")
                for item in items_json:
                    new_items.append(TodoItem(
                        id=f"explore_{self.exploration_count}_{len(new_items)}",
                        description=item.get('description', 'Exploration task'),
                        actor=item.get('actor', 'unknown'),
                        status="pending",
                        priority=0.8,  # High priority for explorations
                        estimated_reward=self.config.default_estimated_reward  # ✅ FROM CONFIG! (was 0.6)
                    ))
            except json.JSONDecodeError:
                pass
            
            logger.info(f"🔍 Policy exploration generated {len(new_items)} new tasks")
            return new_items
            
        except Exception as e:
            logger.warning(f"Exploration failed: {e}")
            return []


# =============================================================================
# SWARM LEARNER - Imported from canonical source (swarm_learner.py)
# 🔴 A-TEAM FIX: Removed duplicate definition — now imports from swarm_learner.py
# =============================================================================


# =============================================================================
# MAIN SYNAPSE CONDUCTOR CLASS
# =============================================================================

# Use AgentConfig from agent_config.py (SYNAPSE v1.0)
# Alias for backward compatibility in existing code
ActorConfig = AgentConfig


class Conductor:
    """
    Multi-Actor Reinforced Validation Framework.
    
    Orchestrates multiple actors with:
    - Shared hierarchical memory
    - LLM-based Q-prediction
    - Markovian TODO management
    - Policy exploration when stuck
    - Smart context management
    - Online prompt learning
    
    Usage:
        # Generic example - works with ANY agents
        swarm = Conductor(
            actors=[
                ActorConfig("agent1", MyAgent1, ["agent1_architect.md"], ["agent1_auditor.md"]),
                ActorConfig("agent2", MyAgent2, ["agent2_architect.md"], ["agent2_auditor.md"]),
            ],
            config=swarm_config,
            global_architect="plan_validation.md",
            global_auditor="output_validation.md"
        )
        
        # swarm.run() is now an async generator
        result = None
        async for event in swarm.run(goal="Complete the task", **kwargs):
            if isinstance(event, dict) and event.get("type") == "result":
                result = event.get("result")
    """
    
    def __init__(
        self,
        actors: List[ActorConfig],
        metadata_provider,  # ✅ A-TEAM: Generic protocol
        config: SynapseConfig = None,
        global_architect: Optional[str] = None,
        global_auditor: Optional[str] = None,
        annotations_path: Optional[str] = None,
        context_providers: Optional[Dict[str, Any]] = None,
        enable_data_registry: bool = True,  # 🔑 NEW: Enable agentic data discovery
        custom_mappings: Optional[Dict[str, List[str]]] = None,  # 🆕 A-TEAM: User-defined parameter mappings!
        enable_dynamic_planning: bool = True  # 🎯 A-TEAM FIX: Enable LLM-based task decomposition
    ):
        import time
        init_start_time = time.time()
        
        logger.info(f"🔧 INIT: Conductor | actors={len(actors)} | "
                   f"enable_data_registry={enable_data_registry} | "
                   f"enable_dynamic_planning={enable_dynamic_planning}")
        logger.debug(f"  Global architect: {global_architect}")
        logger.debug(f"  Global auditor: {global_auditor}")
        logger.debug(f"  Annotations path: {annotations_path}")
        logger.debug(f"  Context providers: {list(context_providers.keys()) if context_providers else 'None'}")
        
        self.config = config or SynapseConfig()
        logger.debug(f"  Config initialized: {type(self.config).__name__}")
        
        # ⏱️  C1: Wire global circuit breakers / adaptive timeouts from config
        # (replaces hardcoded defaults in timeouts.py with user-configurable values)
        try:
            from .timeouts import init_global_from_config
            init_global_from_config(self.config)
        except Exception as _timeout_init_err:
            logger.warning(f"⏱️  Failed to init global timeouts from config: {_timeout_init_err}")
        
        self.metadata_provider = self._build_metadata_provider(metadata_provider)
        self.context_providers = context_providers or {}
        
        # Set LM from dspy settings (configured via dspy.configure)
        import dspy as dspy_module
        self.lm = getattr(dspy_module.settings, 'lm', None) if hasattr(dspy_module, 'settings') else None
        if self.lm:
            logger.debug(f"  ✅ LM from dspy.settings: {self.lm}")
        else:
            logger.warning("  ⚠️  No LM found in dspy.settings")
        
        # 🔧 A-TEAM: Initialize MetadataToolRegistry (LLM-driven tool discovery!)
        from .metadata_tool_registry import MetadataToolRegistry
        self.metadata_tool_registry = MetadataToolRegistry(self.metadata_provider)
        logger.info(f"🔧 MetadataToolRegistry initialized - {len(self.metadata_tool_registry.tools)} tools discovered!")

        # 🔧 A-TEAM: Initialize ToolShed with discovered tools (no hardcoding)
        self.tool_shed = self._init_tool_shed()
        
        # 🆕 A-TEAM: Build parameter mappings (user + config + defaults)
        self.param_mappings = self._build_param_mappings(custom_mappings)
        
        # 🆕 A-TEAM: IOManager for typed output management
        self.io_manager = IOManager()
        logger.info("📦 IOManager enabled - typed output management!")
        
        # 🔑 NEW: Smart Data Transformer with FORMAT TOOLS (ReAct + json.loads, csv, etc.)
        self.data_transformer = SmartDataTransformer()
        logger.info("🔄 SmartDataTransformer enabled - ReAct agent with format tools!")
        
        # 🔥 CRITICAL: SmartAgentSlack - Intelligent agent communication with embedded helpers
        # User insight: "Agent Slack should HAVE transformer, chunker, compressor. It's a SMART slack"
        # 🆕 A-TEAM: Now with cooperation tracking!
        self.agent_slack = SmartAgentSlack(config={'synapse_config': self.config}, enable_cooperation=True)
        logger.info("💬 SmartAgentSlack initialized - intelligent agent communication!")
        logger.info("   ✅ Embedded: Transformer, Chunker, Compressor")
        logger.info("   ✅ Auto-detects format needs from signatures")
        logger.info("   ✅ Manages context length automatically")
        logger.info("   🤝 Cooperation tracking enabled (for credit assignment)")

        # 🧠 Dynamic skill lifecycle (persistent across sessions)
        self.skill_registry = None
        self.skill_validator = None
        self.skill_runtime = None
        if getattr(self.config, "enable_dynamic_skills", True):
            try:
                self.skill_registry = SkillRegistry(
                    root_dir=getattr(self.config, "dynamic_skill_root_dir", "./uv_skills")
                )
                self.skill_validator = SkillValidator(
                    max_file_size_bytes=getattr(self.config, "dynamic_skill_max_file_size_bytes", 256_000),
                    test_timeout_seconds=getattr(self.config, "dynamic_skill_validation_timeout_seconds", 90),
                )
                self.skill_runtime = SkillRuntime(
                    default_timeout_seconds=getattr(self.config, "dynamic_skill_runtime_timeout_seconds", 60.0),
                    allowed_roots=[getattr(self.config, "dynamic_skill_root_dir", "./uv_skills")],
                )
                logger.info("🧠 Dynamic skill lifecycle enabled (registry + validator + runtime)")
            except Exception as _skill_init_err:
                logger.error(f"❌ Dynamic skill lifecycle init failed: {_skill_init_err}")
        
        # 🔢 Monotonic event sequence counter for frontend ordering guarantees
        self._event_seq = 0
        # 📊 Fan-out counter for telemetry (tracks how many parallel batches were launched)
        self._fan_out_count = 0
        
        # 🔑 NEW: Agentic Parameter Resolver for semantic matching
        from .agentic_parameter_resolver import AgenticParameterResolver
        self.param_resolver = AgenticParameterResolver(llm=None)  # Uses dspy.settings.lm
        logger.info("🧠 AgenticParameterResolver enabled - LLM-based semantic parameter matching!")
        
        # 🔑 NEW: Data Registry for agentic data discovery
        if enable_data_registry:
            self.data_registry = DataRegistry()
            self.data_registry_tool = DataRegistryTool(self.data_registry)
            # 🔴 A-TEAM AUDIT FIX: Set module-level registry for tool functions
            set_active_registry(self.data_registry)
            logger.info("📚 Data Registry enabled - agents can discover and retrieve data")
            
            # 🎯 NEW: Agentic Discovery Orchestrator (LLM-based registration)
            from .agentic_discovery import RegistrationOrchestrator
            
            # A-Team: Pass model and config for token counting
            model_for_tokens = getattr(config, 'token_model_name', None) or getattr(config, 'model', None)
            
            self.registration_orchestrator = RegistrationOrchestrator(
                data_registry=self.data_registry,
                lm=None,  # Will use dspy.settings.lm
                model=model_for_tokens,
                config=config,
                enable_validation=True
            )
            logger.info("🎯 RegistrationOrchestrator initialized - LLM-based tagging & discovery!")
        else:
            self.data_registry = None
            self.data_registry_tool = None
            self.registration_orchestrator = None
        
        # 🤝 NEW: FeedbackChannel for agent coordination
        self.feedback_channel = FeedbackChannel()
        logger.info("📧 FeedbackChannel enabled - agents can consult each other!")
        
        # =====================================================================
        # 🎯 A-TEAM FIX: Dynamic Task Planner for semantic goal decomposition
        # =====================================================================
        self.enable_dynamic_planning = enable_dynamic_planning
        # Get task planner tools and prompt from config (if provided)
        task_planner_tools = getattr(config, 'task_planner_tools', None)
        task_planner_prompt_path = getattr(config, 'task_planner_prompt_path', None)
        logger.info(f"🔧 Conductor.__init__ | task_planner_tools from config: {task_planner_tools} | type={type(task_planner_tools)} | is_none={task_planner_tools is None}")
        if task_planner_tools:
            logger.info(f"🔧 Conductor.__init__ | task_planner_tools length: {len(task_planner_tools)}")
            for i, tool in enumerate(task_planner_tools):
                logger.info(f"🔧 Conductor.__init__ | task_planner_tool[{i}]: {tool} | type={type(tool)} | name={getattr(tool, '__name__', 'NO_NAME')}")
        if enable_dynamic_planning and DYNAMIC_TASK_PLANNER_AVAILABLE:
            logger.info(f"🔧 Conductor.__init__ | Creating DynamicTaskPlanner with tools={task_planner_tools}")
            self._task_planner = DynamicTaskPlanner(
                max_tasks_per_agent=30,
                tools=task_planner_tools,
                system_prompt_path=task_planner_prompt_path
            )
            logger.info(f"🔧 Conductor.__init__ | DynamicTaskPlanner created | _task_planner.tools={self._task_planner.tools if hasattr(self._task_planner, 'tools') else 'NO_TOOLS_ATTR'}")
            logger.info("🎯 DynamicTaskPlanner enabled - LLM-based goal decomposition!")
            logger.info("   ✅ Semantic task descriptions (not 'Execute X pipeline')")
            logger.info("   ✅ Explicit input/output dependencies")
            logger.info("   ✅ Topological task ordering")
            if task_planner_tools:
                logger.info(f"   🔧 Task planner tools: {len(task_planner_tools)} tools enabled")
            if task_planner_prompt_path:
                logger.info(f"   📄 Task planner prompt: {task_planner_prompt_path}")
        else:
            self._task_planner = None
            if enable_dynamic_planning:
                logger.warning("⚠️ DynamicTaskPlanner requested but not available")
            else:
                logger.info("ℹ️ DynamicTaskPlanner disabled - using sequential agent tasks")

        # =====================================================================
        # 🗑️  OptimalTaskPlanner REMOVED (Dead Code - Never Used)
        # =====================================================================
        # Was initialized but never called in main execution loop
        # Removed as part of code cleanup (2026-01-29)
        self._optimal_task_planner = None

        # =====================================================================
        # 🔥 A-TEAM: Wire Axon (SmartAgentSlack) into the running swarm
        # =====================================================================
        # Before: agent_slack existed but was not used by orchestration.
        # Now: we register each actor so messages can be delivered, logged, and
        # bridged into FeedbackChannel for injection on the next execution.
        def _make_slack_callback(target_actor_name: str):
            def _callback(message):
                try:
                    # Bridge Slack message → FeedbackChannel message for context injection
                    fb = FeedbackMessage(
                        source_actor=message.from_agent,
                        target_actor=target_actor_name,
                        feedback_type=FeedbackType.RESPONSE,
                        content=str(message.data),
                        context={
                            "format": getattr(message, "format", "unknown"),
                            "size_bytes": getattr(message, "size_bytes", None),
                            "metadata": getattr(message, "metadata", {}) or {},
                            "timestamp": getattr(message, "timestamp", None),
                        },
                        requires_response=False,
                        priority=2,
                    )
                    self.feedback_channel.send(fb)
                except Exception as e:
                    logger.warning(f"⚠️ Slack callback failed for {target_actor_name}: {e}")
            return _callback
        
        # 🎯 NEW: MetaDataFetcher + SharedContext (NO MCP SERVER NEEDED!)
        # Auto-discovers @synapse_method methods and creates dspy.Tool objects directly
        from .metadata_fetcher import MetaDataFetcher
        from .shared_context import SharedContext
        
        self.shared_context = SharedContext()
        logger.info("🗂️  SharedContext initialized - agents share data here!")
        
        # MetaDataFetcher with direct dspy.Tool (no MCP server)
        self.metadata_fetcher = MetaDataFetcher(metadata_provider=self.metadata_provider)
        logger.info("🔍 MetaDataFetcher initialized - auto-discovered @synapse_method tools!")
        
        # 🔥 A-TEAM FIX: SessionManager for output & persistence management
        from .session_manager import SessionManager
        self.session_manager = SessionManager(config=self.config)
        logger.info(f"📁 SessionManager initialized: {self.session_manager.session_dir}")
        
        # Auto-load previous state if configured
        if getattr(self.config, "auto_load_on_start", False):
            try:
                previous_state = self.session_manager.load_previous_state()
                if previous_state:
                    logger.info("✅ Previous session state loaded successfully")
                    # State is automatically applied by session_manager.load_previous_state()
            except (FileNotFoundError, RuntimeError) as e:
                logger.error(f"❌ Failed to load previous state: {e}")
                if getattr(self.config, "require_previous_state", False):
                    raise
        
        # 🆕 SYNAPSE_NEW: Initialize TaskBreakdownAgent and TodoCreatorAgent
        try:
            from Synapse.agents import TaskBreakdownAgent, TodoCreatorAgent
            self.task_breakdown_agent = TaskBreakdownAgent()
            self.todo_creator_agent = TodoCreatorAgent()
            logger.info("✅ Synapse_new agents initialized (TaskBreakdownAgent, TodoCreatorAgent)")
        except ImportError as e:
            logger.warning(f"⚠️  Synapse_new agents not available: {e}")
            self.task_breakdown_agent = None
            self.todo_creator_agent = None
        
        # 🆕 A-TEAM: Initialize UserCommunicationAgent for user-friendly final output
        try:
            from Synapse.agents import UserCommunicationAgent
            self.user_communication_agent = UserCommunicationAgent(lm=self.lm)
            logger.info("✅ UserCommunicationAgent initialized - user-friendly final messages!")
        except ImportError as e:
            logger.warning(f"⚠️  UserCommunicationAgent not available: {e}")
            self.user_communication_agent = None
        
        # 🆕 A-TEAM: Initialize AgentResolverAgent for intelligent agent name resolution
        try:
            from Synapse.agents import AgentResolverAgent
            self.agent_resolver_agent = AgentResolverAgent()
            logger.info("✅ AgentResolverAgent initialized - intelligent agent name resolution!")
        except ImportError as e:
            logger.warning(f"⚠️  AgentResolverAgent not available: {e}")
            self.agent_resolver_agent = None
        
        # 🌍 Environment Manager: Track execution context with CoT summarization
        try:
            from Synapse import create_environment_manager
            self.env_manager = create_environment_manager(
                self.config,
                goal_context="Synapse multi-agent task execution"
            )
            # Add to config so Inspector agents can access it
            self.config.env_manager = self.env_manager
            logger.info(f"✅ Environment Manager initialized: {self.env_manager.env_file}")
            
            # 🔧 Register cleanup handler to ensure graceful shutdown.
            # NOTE: atexit handlers run during Python interpreter teardown, when
            # internal thread pools (litellm, dspy, etc.) may already be shut down.
            # LLM-based summarization is therefore SKIPPED here — it is performed
            # inside Conductor.run() before the run completes (line ~6974).
            # The atexit handler only stops background threads to prevent orphans.
            import atexit
            env_mgr = self.env_manager  # Capture reference for closure
            def _finalize_environment():
                try:
                    env_mgr.stop_auto_summarization()
                except Exception:
                    pass  # Teardown — best-effort only
            
            atexit.register(_finalize_environment)
            logger.info("✅ Environment Manager cleanup handler registered")
            
        except ImportError as e:
            logger.warning(f"⚠️  Environment Manager not available: {e}")
            self.env_manager = None
            self.config.env_manager = None
        
        # 🔴 CRITICAL FIX: Enhanced Agent Selector (Q-learning based, dynamic selection)
        # 🔴 A-TEAM FIX: Use lightweight model for EnhancedAgentSelector (as per agent_models.yaml)
        # The YAML config says "lightweight" but previously we passed self.lm (the default/expensive model).
        # Agent selection is a low-value routing task — it should use the lightweight model.
        from .enhanced_agent_selector import EnhancedAgenticAgentSelector
        _selector_lm = self.lm  # fallback to default
        if hasattr(self.config, 'default_lightweight_model') and self.config.default_lightweight_model:
            try:
                import dspy
                _selector_lm = dspy.LM(
                    model=self.config.default_lightweight_model,
                    api_key=getattr(self.config, 'model_api_key', None),
                    api_base=getattr(self.config, 'model_api_base', None),
                    temperature=0.3,
                    max_tokens=1024,
                )
                logger.info(f"🏷️  EnhancedAgentSelector: Lightweight LM created with model={self.config.default_lightweight_model}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to create lightweight LM for EnhancedAgentSelector, using default: {e}")
                _selector_lm = self.lm
        self.enhanced_agent_selector = EnhancedAgenticAgentSelector(
            lm=_selector_lm,
            config=self.config
        )
        logger.info("🎯 EnhancedAgenticAgentSelector initialized (Q-learning for agent selection)")
        logger.info("   - Dynamic agent selection at execution time")
        logger.info("   - ε-greedy exploration for discovering best agents")
        logger.info("   - Learning from every task outcome")
        
        # 🔴 CRITICAL FIX: Predictive Cooperation (Nash bargaining, reward distribution)
        from .predictive_cooperation import CooperationReasoner, CooperationPrinciples
        self.cooperation_reasoner = CooperationReasoner()  # Uses dspy.settings.lm internally
        logger.info("🤝 CooperationReasoner initialized (Nash bargaining for cooperation)")
        logger.info("   - Game theory for reward distribution")
        logger.info("   - Constitutional AI cooperation principles")
        logger.info("   - System-level reward optimization")
        
        # 🟠 HIGH PRIORITY: Unified Chunker (token-accurate, LLM-scored, query-aware)
        from .unified_chunker import UnifiedChunker
        self.unified_chunker = UnifiedChunker(
            chunk_size=getattr(self.config, 'chunk_size', 500),
            overlap=getattr(self.config, 'chunk_overlap', 50)
        )
        logger.info("✂️  UnifiedChunker initialized (token-accurate, query-aware)")
        logger.info("   - Binary search for token accuracy (NO heuristics)")
        logger.info("   - LLM-based relevance scoring")
        logger.info("   - Sliding window with configurable overlap")
        
        # 🟠 HIGH PRIORITY: Swarm Validation (internal LLM-based validation)
        try:
            from .swarm_validation import SwarmValidator
            self.swarm_validator = SwarmValidator(config=self.config)
            logger.info("🔍 SwarmValidator initialized (internal swarm orchestration checks)")
            logger.info("   - TODO completeness validation")
            logger.info("   - Actor coordination checks")
            logger.info("   - Goal alignment verification")
        except (ImportError, TypeError) as e:
            logger.warning(f"⚠️  SwarmValidator not available: {e}")
            self.swarm_validator = None
        
        # 🔑 Auto-introspect actor signatures
        self.actor_signatures = {}
        self.dependency_graph = {}
        logger.info("🔍 Introspecting actor signatures...")
        
        # Wrap actors with Synapse wrapper if they have tools or validation prompts
        self.actors = {}
        for actor_config in actors:
            if self._should_wrap_actor(actor_config):
                wrapped_actor = self._wrap_actor_with_synapse(actor_config)
                # Create new config with wrapped actor
                # 🚨 CRITICAL FIX: Copy ALL fields from original config!
                new_config = ActorConfig(
                    name=actor_config.name,
                    agent=wrapped_actor,
                    architect_prompts=[],  # Already wrapped
                    auditor_prompts=[], # Already wrapped
                    architect_tools=[],
                    auditor_tools=[],
                    enabled=actor_config.enabled,
                    capabilities=actor_config.capabilities,
                    dependencies=actor_config.dependencies,
                    metadata=actor_config.metadata,
                    enable_architect=actor_config.enable_architect,
                    enable_auditor=actor_config.enable_auditor,
                    validation_mode=actor_config.validation_mode,
                    is_critical=actor_config.is_critical,
                    max_retries=actor_config.max_retries,
                    retry_strategy=actor_config.retry_strategy,
                    is_executor=getattr(actor_config, "is_executor", False),
                )
                # Add parameter_mappings and outputs as dynamic attributes if they exist
                if hasattr(actor_config, 'parameter_mappings'):
                    new_config.parameter_mappings = actor_config.parameter_mappings
                if hasattr(actor_config, 'outputs'):
                    new_config.outputs = actor_config.outputs
                self.actors[actor_config.name] = new_config
                # 🔑 Introspect the ORIGINAL actor (before wrapping)
                self._introspect_actor_signature(actor_config)
            else:
                self.actors[actor_config.name] = actor_config
                # 🔑 Introspect this actor too
                self._introspect_actor_signature(actor_config)

            # ✅ Register agent with Axon (SmartAgentSlack) so it can receive messages.
            # We pass signature when available; otherwise Axon uses safe defaults.
            try:
                actor_obj = (new_config.agent if self._should_wrap_actor(actor_config) else actor_config.agent)
                signature_obj = getattr(actor_obj, "signature", None)
                self.agent_slack.register_agent(
                    agent_name=actor_config.name,
                    signature=signature_obj if hasattr(signature_obj, "input_fields") else None,
                    callback=_make_slack_callback(actor_config.name),
                    max_context=getattr(self.config, "max_context_tokens", 16000),
                )
            except Exception as e:
                logger.warning(f"⚠️ Could not register {actor_config.name} with SmartAgentSlack: {e}")

        # =====================================================================
        # 🧭 A-TEAM: Generic Agent Registry (Capability Inference)
        # =====================================================================
        self.agent_registry = None
        if getattr(self.config, "enable_agent_registry", True) and AGENT_REGISTRY_AVAILABLE:
            try:
                self.agent_registry = GenericAgentRegistry(lm=None)  # Uses dspy.settings.lm
                for actor_config in actors:
                    description = self._get_agent_description(actor_config.name, actor_config)
                    explicit_caps = None
                    if actor_config.capabilities:
                        explicit_caps = actor_config.capabilities
                    elif actor_config.metadata and actor_config.metadata.get("capabilities"):
                        explicit_caps = actor_config.metadata.get("capabilities")

                    allow_infer = getattr(self.config, "auto_infer_capabilities", True)
                    inferred_caps = explicit_caps
                    if not allow_infer and explicit_caps is None:
                        inferred_caps = []

                    self.agent_registry.register(
                        name=actor_config.name,
                        actor=actor_config.agent,
                        capabilities=inferred_caps,
                        description=description,
                        metadata=actor_config.metadata or {}
                    )
                    # Persist inferred capabilities back into config for downstream use
                    reg = self.agent_registry.get_actor(actor_config.name)
                    if reg and reg.capabilities:
                        actor_config.capabilities = reg.capabilities
                    else:
                        logger.warning(
                            f"⚠️ No capabilities inferred for {actor_config.name}; "
                            "Dynamic planning may have reduced context."
                        )
                # Report missing capabilities summary
                missing = [
                    a.name for a in actors
                    if not (a.capabilities or (a.metadata and a.metadata.get("capabilities")))
                ]
                if missing:
                    logger.warning(
                        f"⚠️ Capability coverage incomplete for {len(missing)} actors: {', '.join(missing)}"
                    )
                    if hasattr(self, 'shared_context') and self.shared_context:
                        self.shared_context.set("capability_missing_actors", missing)
                logger.info("🧭 GenericAgentRegistry initialized - capabilities ready for all actors")
            except Exception as e:
                logger.warning(f"⚠️ GenericAgentRegistry init failed: {e}")
        
        # =====================================================================
        # 🤝 A-TEAM: Agent Directory for Collaboration
        # =====================================================================
        # Build agent directory from GenericAgentRegistry for agent collaboration
        self.agent_directory = self._build_agent_directory()
        if self.agent_directory:
            logger.info(f"📋 Agent directory built: {len(self.agent_directory)} agents available for collaboration")
            # 🔴 A-TEAM FIX: Inject agent directory into shared_context so architect/auditor can access it
            # Without this, architects cannot make handover decisions because they don't know what actors exist
            self.shared_context.set('agent_directory', self.agent_directory)
            logger.info(f"📋 Agent directory injected into shared_context for architect/auditor access")
        else:
            logger.warning("⚠️ Agent directory is empty - agents won't be able to collaborate")
        
        # Global validation prompts
        self.global_architect_path = global_architect
        self.global_auditor_path = global_auditor
        
        # Load annotations for Auditor enrichment
        self.annotations = self._load_annotations(annotations_path)
        
        # Initialize core components
        self.todo = MarkovianTODO()
        
        # 🔥 A-TEAM FIX #1: Initialize goal_hierarchy for TD(λ) learning
        # David Silver: "TD(λ) was getting goal_values=None because goal_hierarchy wasn't initialized"
        from .data_structures import GoalHierarchy
        self.goal_hierarchy = GoalHierarchy()
        logger.info("✅ GoalHierarchy initialized for TD(λ) goal-conditioned learning")
        
        # 🧠 A-TEAM FIX: Use FULL Q-learning implementation from q_learning.py, not the simplified local one!
        self.q_predictor = NaturalLanguageQTable(self.config)
        
        # 🔥 A-TEAM: Async Q-Learning Updater for non-blocking background updates
        self.async_q_updater = None
        if ASYNC_Q_LEARNING_AVAILABLE:
            self.async_q_updater = AsyncQLearningUpdater(self.q_predictor)
            logger.info("✅ AsyncQLearningUpdater initialized for non-blocking Q-learning updates")
        # 🎯 USER CRITICAL FIX: ZERO HARDCODING for token limits!
        # System learns actual limits from API errors, persists them, reuses forever.
        from .model_limits_catalog import get_model_limits
        from .adaptive_limit_learner import AdaptiveLimitLearner
        
        # Initialize adaptive limit learner (learns from API errors!)
        persistence_dir = getattr(self.persistence_manager, 'session_dir', None) if hasattr(self, 'persistence_manager') else None
        self.limit_learner = AdaptiveLimitLearner(persistence_dir=persistence_dir)
        logger.info(f"✅ AdaptiveLimitLearner initialized | learned {len(self.limit_learner.learned_limits)} model limits from disk")
        
        # Determine model name for limit lookup
        model_name = None
        if hasattr(self.config, 'token_model_name') and self.config.token_model_name:
            model_name = self.config.token_model_name
        elif hasattr(dspy.settings, 'lm') and dspy.settings.lm:
            model_name = getattr(dspy.settings.lm, 'model', None)
        
        self.current_model_name = model_name  # Store for later use
        
        # 🔴 USER FIX: PRIORITY ORDER (no hardcoded fallbacks!):
        # 1. LEARNED limit (from previous API errors) ← HIGHEST PRIORITY
        # 2. CATALOG limit (from model_limits_catalog.py)
        # 3. MINIMAL SAFE ESTIMATE (4K) - will learn actual on first API call
        if model_name:
            # Priority 1: Check learned limits FIRST
            learned_limit = self.limit_learner.get_limit(model_name)
            if learned_limit:
                max_tokens = learned_limit
                logger.info(f"🎯 LEARNED LIMIT (Priority 1): {model_name} → {max_tokens:,} tokens (from previous API error)")
            else:
                # Priority 2: Try catalog
                try:
                    limits = get_model_limits(model_name, conservative=False)  # USER FIX: No conservative mode!
                    max_tokens = limits['max_prompt']
                    logger.info(f"📊 CATALOG LIMIT (Priority 2): {model_name} → {max_tokens:,} tokens")
                except ValueError as e:
                    # Priority 3: Model unknown - use minimal safe estimate
                    # System will learn actual limit from first API error
                    max_tokens = 16384  # 🔴 USER FIX: 16K - modern LLM minimum (GPT-4o-mini, Claude, Llama 3.3)
                    logger.warning(
                        f"⚠️  UNKNOWN MODEL (Priority 3): '{model_name}' not in catalog. "
                        f"Starting with modern LLM minimum: {max_tokens:,} tokens (16K). "
                        f"System will learn actual limit from first API call/error. "
                        f"Error: {e}"
                    )
        else:
            # No model name - use modern LLM minimum
            max_tokens = 16384  # 🔴 USER FIX: 16K - modern LLM minimum
            logger.warning(
                f"⚠️  NO MODEL NAME: Using modern LLM minimum: {max_tokens:,} tokens (16K). "
                f"System will learn actual limit from first API error."
            )
        
        self.context_guard = SmartContextGuard(max_tokens=max_tokens, config=self.config)
        logger.info(f"✅ SmartContextGuard initialized | max_tokens={max_tokens:,}")
        
        # 🎯 A-TEAM GAP #1: Add AgenticTODOAdapter (LLM-based, no hardcoding)
        from Synapse.core.roadmap import AgenticTODOAdapter
        self.todo_adapter = AgenticTODOAdapter(lm=self.lm)
        logger.info("✅ AgenticTODOAdapter initialized (LLM-based TODO mutation)")
        
        # 🎯 A-TEAM GAP #2: Add DynamicDependencyGraph for parallel execution
        from Synapse.core.dynamic_dependency_graph import DynamicDependencyGraph
        self.dependency_graph = DynamicDependencyGraph()
        logger.info("✅ DynamicDependencyGraph initialized (parallel task execution)")
        
        # 🎯 A-TEAM GAP #3: Add AgenticFeedbackRouter for auditor-to-actor routing
        from Synapse.core.agentic_feedback_router import AgenticFeedbackRouter
        self.feedback_router = AgenticFeedbackRouter(lm=self.lm)
        logger.info("✅ AgenticFeedbackRouter initialized (intelligent failure routing)")
        
        # 🎯 CRITICAL USER FIX: Add ParallelTestGenerator for LLM-based test generation
        from Synapse.core.parallel_test_generator import ParallelTestGenerator
        self.test_generator = ParallelTestGenerator(config=self.config)  # 🔴 A-TEAM: Pass config for model selection
        logger.info("✅ ParallelTestGenerator initialized (LLM as judge, parallel execution)")
        
        # 🔧 FIX: Add ErrorSolutionExtractor for auto error research
        from Synapse.core.error_solution_extractor import ErrorSolutionExtractor
        self.error_solution_extractor = ErrorSolutionExtractor()
        logger.info("✅ ErrorSolutionExtractor initialized (auto error research & retry)")
        
        # 🔧 FIX: Add LLMRAGRetriever for advanced memory retrieval
        from Synapse.core.llm_rag import LLMRAGRetriever
        self.rag_retriever = LLMRAGRetriever(config=self.config)
        logger.info("✅ LLMRAGRetriever initialized (pure LLM semantic RAG)")
        
        # 🎯 A-TEAM CONSENSUS: Unified Reward System (THE MISSING FEATURE!)
        from Synapse.core.unified_reward import UnifiedRewardCalculator
        from Synapse.core.user_feedback_api import UserFeedback
        from Synapse.core.test_aggregation import HybridTestAggregator
        
        self.reward_calculator = UnifiedRewardCalculator(config=self.config)
        self.test_aggregator = HybridTestAggregator(config=self.config)
        
        # NOTE: Persisted state (Bayesian, user feedback, MARL) is loaded in run()
        # AFTER persistence_manager (Vault) is created. Not here in __init__.
        
        UserFeedback._set_calculator(self.reward_calculator)  # Enable global API
        logger.info("✅ UnifiedRewardCalculator initialized (hierarchical, decomposed rewards)")
        logger.info("✅ HybridTestAggregator initialized (LLM→Bayesian→Bootstrap)")
        logger.info("   🎯 CRITICAL: User feedback API now available!")
        logger.info("   📊 Reward breakdown: quality + cooperation + learning + user")
        logger.info("   ⚖️  All rewards normalized to [0, 1]")
        logger.info("   🛡️  Anti-hacking validation enabled")
        logger.info("   🧪 Test aggregation: semantic → learned → weighted")
        logger.info("   💾 Bayesian learning persists across sessions!")
        
        self.policy_explorer = PolicyExplorer(self.config)
        self.task_coverage_checker = dspy.ChainOfThought(TaskCoverageSignature) if DSPY_AVAILABLE else None
        self.error_pattern_extractor = dspy.ChainOfThought(ErrorPatternSignature) if DSPY_AVAILABLE else None
        
        # =====================================================================
        # MEMORY SUBSYSTEM (HierarchicalMemory via cortex.py)
        # =====================================================================
        if self.config.enable_memory:
            logger.info("🧠 Memory active via HierarchicalMemory (shared_memory + local_memories)")
        else:
            logger.warning("⚠️  Memory disabled (enable_memory=False)")
        
        # Episode counter for tracking
        self.episode_counter = 0
        
        # Predictive MARL: Predict other agents, learn from divergence
        # NOTE: MARL state restoration from persistence happens in run() after Vault init
        if PREDICTIVE_MARL_AVAILABLE:
            self.trajectory_predictor = LLMTrajectoryPredictor(
                self.config,
                horizon=5  # Predict 5 steps ahead
            )
            self.divergence_memory = DivergenceMemory(self.config)
            self.cooperative_credit = CooperativeCreditAssigner(self.config)
            logger.info("🔮 Predictive MARL components initialized")
        else:
            self.trajectory_predictor = None
            self.divergence_memory = None
            self.cooperative_credit = None
        
        # =====================================================================
        # 🧠 Q-LEARNING WITH NEUROCHUNK TIERED MEMORY (v2.4 - A-Team Approved)
        # =====================================================================
        # 🔴 A-TEAM FIX: q_learner and q_predictor MUST be the SAME instance.
        # Previously they were separate NaturalLanguageQTable objects, so Q-updates
        # went to q_predictor while stats/tiering/Nash used q_learner (always empty).
        # Now q_learner is an alias for q_predictor — single source of truth.
        if Q_LEARNING_AVAILABLE:
            self.q_learner = self.q_predictor  # Alias — same object
            logger.info("🧠 Q-Learning with NeuroChunk Memory initialized (unified q_predictor+q_learner)")
            logger.info("   - Tier 1: Working Memory (always in context)")
            logger.info("   - Tier 2: Semantic Clusters (retrieval-based)")
            logger.info("   - Tier 3: Long-term Archive (causal impact pruning)")
        else:
            self.q_learner = None
            logger.warning("⚠️  Q-Learning not available")
        
        # TD(λ) Learning (Temporal Difference with Eligibility Traces)
        if TD_LAMBDA_AVAILABLE:
            from .learning import AdaptiveLearningRate
            adaptive_lr = AdaptiveLearningRate(self.config)
            self.td_learner = TDLambdaLearner(self.config, adaptive_lr)
            logger.info("📊 TD(λ) Learning initialized (eligibility traces)")
        else:
            self.td_learner = None
            logger.warning("⚠️  TD(λ) Learning not available")
        
        # =====================================================================
        # 🔥 TIMEOUT & CIRCUIT BREAKER (v2.5 - A-Team Production Resilience)
        # =====================================================================
        from .timeouts import (
            CircuitBreaker, CircuitBreakerConfig,
            DeadLetterQueue, AdaptiveTimeout
        )
        
        if self.config.enable_circuit_breakers:
            # LLM Circuit Breaker
            self.llm_circuit_breaker = CircuitBreaker(
                CircuitBreakerConfig(
                    name="llm_calls",
                    failure_threshold=self.config.llm_circuit_failure_threshold,
                    timeout=self.config.llm_circuit_timeout,
                    success_threshold=self.config.llm_circuit_success_threshold
                )
            )
            # Tool Circuit Breaker
            self.tool_circuit_breaker = CircuitBreaker(
                CircuitBreakerConfig(
                    name="tool_calls",
                    failure_threshold=self.config.tool_circuit_failure_threshold,
                    timeout=self.config.tool_circuit_timeout,
                    success_threshold=self.config.tool_circuit_success_threshold
                )
            )
            logger.info("🔌 Circuit Breakers initialized")
            logger.info(f"   - LLM: {self.config.llm_circuit_failure_threshold} failures → open")
            logger.info(f"   - Tool: {self.config.tool_circuit_failure_threshold} failures → open")
        else:
            self.llm_circuit_breaker = None
            self.tool_circuit_breaker = None
            logger.info("⚠️  Circuit Breakers disabled")
        
        # Adaptive Timeout
        if self.config.enable_adaptive_timeouts:
            self.adaptive_timeout = AdaptiveTimeout(
                initial=self.config.initial_timeout,
                percentile=self.config.timeout_percentile,
                min_timeout=self.config.min_timeout,
                max_timeout=self.config.max_timeout
            )
            logger.info(f"⏱️  Adaptive Timeout initialized ({self.config.timeout_percentile}th percentile)")
        else:
            self.adaptive_timeout = None
            logger.info("⚠️  Adaptive Timeout disabled")
        
        # Dead Letter Queue
        if self.config.enable_dead_letter_queue:
            self.dead_letter_queue = DeadLetterQueue(
                max_size=self.config.dlq_max_size
            )
            logger.info(f"📮 Dead Letter Queue initialized (max_size={self.config.dlq_max_size})")
        else:
            self.dead_letter_queue = None
            logger.info("⚠️  Dead Letter Queue disabled")
        
        # ⏰ Timeout Warning Manager - REMOVED
        # Timeout warnings and hard timeout enforcement have been removed to allow LLM freedom
        
        # =====================================================================
        # 🕐 TIME-AWARE EXECUTOR (v2.6 - A-Team Timeout Prevention)
        # =====================================================================
        # 🔴 A-TEAM FIX: Re-enabled StuckDetector to prevent infinite agent loops
        if TIME_AWARE_AVAILABLE:
            self.stuck_detector = StuckDetector(
                max_repetitions=getattr(self.config, 'stuck_max_repetitions', 3),
                pattern_window=getattr(self.config, 'stuck_pattern_window', 10),
            )
            logger.info(f"🔍 StuckDetector initialized (pattern-based, max_reps={self.stuck_detector.max_repetitions})")
        else:
            self.stuck_detector = StuckDetector()  # Stub fallback
            logger.info("⚠️ Using stub StuckDetector (time_aware_execution not available)")
        
        self.swarm_learner = SwarmLearner(self.config)
        
        # Shared memory (across all actors) - conditional based on enable_memory flag
        if self.config.enable_memory:
            self.shared_memory = HierarchicalMemory(
                config=self.config,
                agent_name="SwarmShared"
            )
            
            # Per-actor local memories
            self.local_memories: Dict[str, HierarchicalMemory] = {}
            for name in self.actors:
                self.local_memories[name] = HierarchicalMemory(
                    config=self.config,
                    agent_name=name
                )
        else:
            from .cortex import NullMemory
            self.shared_memory = NullMemory(agent_name="SwarmShared", config=self.config)
            self.local_memories: Dict[str, NullMemory] = {}
            for name in self.actors:
                self.local_memories[name] = NullMemory(agent_name=name, config=self.config)
            logger.info("⚠️  Memory system disabled (enable_memory=False)")
            self._memory_disabled_diagnostic = True
        
        # State
        self.episode_count = 0
        self.total_episodes = 0
        self.trajectory: List[Dict] = []
        
        # =====================================================================
        # CONFIG LEARNER: Dynamic parameter optimization (TODO 9)
        # =====================================================================
        self.config_learner = None
        if getattr(self.config, 'enable_config_learning', False):
            try:
                from .config_learner import ConfigLearner
                config_path = getattr(self.config, 'config_path', 'synapse_config.json')
                auto_apply_threshold = getattr(self.config, 'config_auto_apply_threshold', 0.9)
                self.config_learner = ConfigLearner(
                    config_path=config_path,
                    auto_apply_threshold=auto_apply_threshold  # 🆕 A-TEAM: Conditional auto-apply
                )
                logger.info(f"📊 ConfigLearner enabled (auto-apply threshold: {auto_apply_threshold})")
            except Exception as e:
                logger.warning(f"⚠️ ConfigLearner initialization failed: {e}")
        # =====================================================================
        
        # =====================================================================
        # PERSISTENCE MANAGER (v9.1 - Complete Integration)
        # =====================================================================
        self.persistence_manager: Optional['Vault'] = None
        # Will be initialized in run() when output directory is known
        
        logger.info(f"🚀 Conductor initialized with {len(actors)} actors")
    
    def _should_wrap_actor(self, actor_config: ActorConfig) -> bool:
        """
        Determine if an actor needs to be wrapped with SYNAPSE.
        
        Wrapping is needed if:
        - Actor has validation prompts (architect_prompts or auditor_prompts)
        - Actor has tools (architect_tools or auditor_tools)
        """
        has_validation = (
            actor_config.architect_prompts or 
            actor_config.auditor_prompts
        )
        has_tools = (
            actor_config.architect_tools or 
            actor_config.auditor_tools
        )
        return has_validation or has_tools

    def _build_metadata_provider(self, metadata_provider: Any):
        """
        Build a composite metadata provider with optional system tools.

        NO HARDCODING: Uses config flags to enable built-in providers.
        """
        providers: List[Any] = []

        if metadata_provider is not None:
            providers.append(metadata_provider)

        if getattr(self.config, "enable_web_search_tools", False):
            try:
                from .web_search_tools import OpenSourceWebSearchProvider
                provider = OpenSourceWebSearchProvider(config=self.config)
                # Validate dependencies are available
                if provider.__synapse_validate__():
                    providers.append(provider)
                    logger.info("🔍 Web search tools enabled (OpenSourceWebSearchProvider)")
                else:
                    logger.warning("⚠️ Web search tools disabled: missing dependencies. Install with: pip install duckduckgo-search requests beautifulsoup4")
            except ImportError as e:
                logger.warning(f"⚠️ Failed to enable web search tools: missing dependencies. Install with: pip install duckduckgo-search requests beautifulsoup4. Error: {e}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to enable web search tools: {e}")

        if not providers:
            # ✅ A-TEAM FIX: Return empty provider instead of None (prevents crashes)
            logger.info("📋 No metadata providers - creating empty default")
            return self._create_empty_metadata_provider()

        if len(providers) == 1:
            return providers[0]

        from .composite_metadata_provider import CompositeMetadataProvider
        logger.info(f"🧩 CompositeMetadataProvider enabled ({len(providers)} providers)")
        return CompositeMetadataProvider(providers)
    
    def _create_empty_metadata_provider(self):
        """
        Create an empty metadata provider when no metadata is available.
        
        ✅ A-TEAM FIX: Prevents crashes when user doesn't provide metadata_provider.
        
        This ensures the system always has a provider, even if it returns empty context.
        Graceful degradation is better than crashing!
        
        Returns:
            EmptyMetadataProvider instance with no metadata
        """
        from .base_metadata_provider import BaseMetadataProvider
        
        class EmptyMetadataProvider(BaseMetadataProvider):
            """Empty provider when no metadata is available."""
            def __init__(self):
                # No token budget needed (no tools to call)
                super().__init__(token_budget=0, enable_caching=False)
                logger.debug("  Created EmptyMetadataProvider (no metadata available)")
            
            def get_context_for_actor(self, **kwargs):
                """Return empty context (no metadata to provide)."""
                return {}
        
        return EmptyMetadataProvider()

    def _init_tool_shed(self):
        """
        Initialize ToolShed and register all discovered metadata tools.

        No hardcoding: tool discovery comes from metadata_tool_registry.
        """
        try:
            from .tool_shed import ToolShed
        except Exception as e:
            logger.warning(f"⚠️ ToolShed unavailable: {e}")
            return None

        max_tools = getattr(self.config, "tool_selection_max_tools", None)
        tool_shed = ToolShed(
            max_tools=max_tools,
            cache_ttl_seconds=getattr(self.config, "tool_cache_ttl_seconds", 300.0),
            cache_max_entries=getattr(self.config, "tool_cache_max_entries", 1000),
        )
        if not hasattr(self, "metadata_tool_registry"):
            logger.warning("⚠️ No metadata_tool_registry found; ToolShed will be empty")
            return tool_shed

        for tool_name, tool_info in self.metadata_tool_registry.tools.items():
            try:
                tool_func = tool_info.get("callable")
                if not callable(tool_func):
                    continue
                tool_shed.register(
                    tool=tool_func,
                    name=tool_name,
                    description=tool_info.get("desc"),
                    produces=[tool_info.get("returns")] if tool_info.get("returns") else None,
                    consumes=list(
                        tool_info.get("signature", {})
                        .get("parameters", {})
                        .keys()
                    ) if tool_info.get("signature") else None,
                )
            except Exception as e:
                logger.warning(f"⚠️ Failed to register tool '{tool_name}' in ToolShed: {e}")

        logger.info(f"🧰 ToolShed initialized with {len(tool_shed.tools)} tools")
        return tool_shed

    def _checkpoint_state(self, reason: str, task: Optional[TodoItem] = None) -> None:
        """
        Save a lightweight checkpoint using Vault (no hardcoding).
        """
        if not self.persistence_manager:
            return

        try:
            self.persistence_manager.save_markovian_todo(self.todo)
        except Exception as e:
            logger.debug(f"Checkpoint todo save failed: {e}")

        try:
            if hasattr(self, 'shared_memory') and self.shared_memory and self.config.enable_memory:
                self.persistence_manager.save_memory(self.shared_memory, name="shared")
            if hasattr(self, 'local_memories') and self.local_memories:
                for name, memory in self.local_memories.items():
                    self.persistence_manager.save_memory(memory, name=name)
        except Exception as e:
            logger.debug(f"Checkpoint memory save failed: {e}")

        try:
            if hasattr(self, 'q_predictor') and self.q_predictor:
                self.persistence_manager.save_q_predictor(self.q_predictor)
        except Exception as e:
            logger.debug(f"Checkpoint Q-predictor save failed: {e}")

        # 🔴 A-TEAM FIX: Also persist MARL state (learned patterns, agent models, insights)
        try:
            if hasattr(self, 'trajectory_predictor') and self.trajectory_predictor:
                marl_data = self.trajectory_predictor.to_dict()
                marl_file = self.persistence_manager.global_synapse_dir / "marl_state.json"
                marl_file.parent.mkdir(parents=True, exist_ok=True)
                import json as _json
                with open(marl_file, 'w') as f:
                    _json.dump(marl_data, f, indent=2, default=str)
        except Exception as e:
            logger.debug(f"Checkpoint MARL save failed: {e}")
        
        # 🔴 A-TEAM FIX: Persist reward calculator user feedback
        try:
            if hasattr(self, 'reward_calculator') and self.reward_calculator and self.persistence_manager:
                self.persistence_manager.save_user_feedback(self.reward_calculator)
        except Exception as e:
            logger.debug(f"Checkpoint reward feedback save failed: {e}")

        task_info = f" task={task.task_id}" if task else ""
        logger.info(f"💾 Checkpoint saved ({reason}){task_info}")

    def _store_memory(self, content: str, level, context: Dict[str, Any],
                      goal: str, actor_name: Optional[str] = None,
                      initial_value: float = 0.5, outcome: Optional[str] = None) -> None:
        """
        Store memory in BOTH shared and local (per-actor) memory systems.
        
        This ensures:
        - shared_memory has the global knowledge graph
        - local_memories[actor] has actor-specific experiences
        - Retrieval during _build_actor_context finds relevant memories from both
        
        Args:
            content: Memory content
            level: MemoryLevel (e.g. SEMANTIC, CAUSAL, PROCEDURAL)
            context: Dict with actor, task, etc.
            goal: Current goal string
            actor_name: Actor name for local memory storage
            initial_value: Initial memory value weight
            outcome: Optional outcome string for store_with_outcome
        """
        if not hasattr(self, 'shared_memory') or not self.shared_memory:
            return
        if not self.config.enable_memory:
            return
        
        try:
            if outcome:
                self.shared_memory.store_with_outcome(
                    content=content, context=context, goal=goal, outcome=outcome
                )
            else:
                self.shared_memory.store(
                    content=content, level=level, context=context,
                    goal=goal, initial_value=initial_value
                )
            logger.debug(f"✅ Stored in shared_memory (outcome={outcome})")
        except Exception as e:
            logger.warning(f"⚠️ Failed to store in shared_memory: {e}")
        
        # Also store in actor-specific local memory
        if actor_name and hasattr(self, 'local_memories') and actor_name in self.local_memories:
            try:
                local_mem = self.local_memories[actor_name]
                if outcome:
                    local_mem.store_with_outcome(
                        content=content, context=context, goal=goal, outcome=outcome
                    )
                else:
                    local_mem.store(
                        content=content, level=level, context=context,
                        goal=goal, initial_value=initial_value
                    )
                logger.debug(f"✅ Stored in local_memory[{actor_name}] (outcome={outcome})")
            except Exception as e:
                logger.warning(f"⚠️ Failed to store in local_memory[{actor_name}]: {e}")
        elif actor_name:
            logger.debug(f"⚠️ local_memory[{actor_name}] not found in local_memories keys={list(self.local_memories.keys()) if hasattr(self, 'local_memories') else 'N/A'}")

    def _collect_runtime_metrics(self) -> Dict[str, Any]:
        """Collect tool and search usage metrics for diagnostics."""
        metrics: Dict[str, Any] = {}
        if hasattr(self, 'tool_shed') and self.tool_shed:
            metrics['tool_usage_stats'] = self.tool_shed.call_stats.copy()

        # Try to get web search stats if provider supports it
        provider = getattr(self, 'metadata_provider', None)
        if provider and hasattr(provider, 'get_stats'):
            try:
                metrics['web_search_stats'] = provider.get_stats()
            except Exception:
                pass
        return metrics
    
    def _get_auto_discovered_dspy_tools(self) -> List[Any]:
        """
        Get ALL auto-discovered metadata tools as dspy.Tool objects.
        
        🔥 A-TEAM CONSENSUS SOLUTION (Post-Debate):
        - Individual DSPy tools (one per metadata method) ✅
        - Smart parameter resolution (4-level fallback) ✅
        - Caching via SharedScratchpad ✅
        - Enhanced descriptions for LLM reasoning ✅
        - FULLY GENERIC - works for ANY tool! ✅
        
        Returns:
            List of dspy.Tool objects for all @synapse_method decorated methods
        """
        import dspy
        import json
        
        if not hasattr(self, 'metadata_tool_registry'):
            logger.warning("⚠️  No metadata_tool_registry found, returning empty tool list")
            return []
        
        tools = []
        tool_names = self.metadata_tool_registry.list_tools()
        
        logger.info(f"🔧 Creating {len(tool_names)} individual DSPy tools with smart param resolution...")
        
        for tool_name in tool_names:
            tool_info = self.metadata_tool_registry.get_tool_info(tool_name)
            
            # Get original function to extract signature
            original_func = tool_info.get('callable')
            if not original_func:
                logger.warning(f"⚠️  No callable found for {tool_name}, skipping")
                continue
            
            # Extract signature from original function
            try:
                original_sig = inspect.signature(original_func)
            except Exception as e:
                logger.warning(f"⚠️  Failed to get signature for {tool_name}: {e}")
                original_sig = None
            
            # Create closure to capture tool_name, tool_info, and original_sig
            def make_smart_tool_func(tname, tinfo, orig_sig):
                # Create function with same signature as original, but all params optional
                if orig_sig:
                    # Build new parameters - same names/types, but all optional
                    new_params = []
                    param_names = []
                    for param_name, param in orig_sig.parameters.items():
                        if param_name == 'self':
                            # Skip self - wrapper doesn't need it
                            continue
                        param_names.append(param_name)
                        # Make all params optional (use existing default or None)
                        new_default = param.default if param.default != inspect.Parameter.empty else None
                        new_param = inspect.Parameter(
                            name=param.name,
                            kind=inspect.Parameter.KEYWORD_ONLY,  # Force keyword-only for clarity
                            default=new_default,
                            annotation=param.annotation
                        )
                        new_params.append(new_param)
                    
                    # Create new signature with all optional params
                    new_sig = orig_sig.replace(parameters=new_params)
                else:
                    new_sig = None
                    param_names = []
                
                # Create function that accepts all parameters as keyword arguments
                # This matches the original function signature (all params optional)
                def smart_tool_func(**kwargs):
                    """
                    🔥 A-TEAM SMART WRAPPER with 4-level parameter resolution:
                    1. Explicit override (user provides param)
                    2. IOManager auto-resolution (exact name match from actor outputs)
                    3. SharedContext auto-resolution (exact name match from global data)
                    4. Type-based resolution (generic! works for ANY type)
                    """
                    try:
                        raw_kwargs = dict(kwargs)
                        # Get parameter specs
                        signature = tinfo.get('signature', {})
                        params_spec = signature.get('parameters', {})
                        
                        # Build final kwargs with smart resolution
                        # 🔥 A-TEAM FIX: Filter out internal DSPy parameters (tool_name, args, kwargs, etc.)
                        # DSPy ReAct sometimes passes internal metadata as parameters, which causes errors
                        # Only keep parameters that are actually in the tool's signature
                        filtered_kwargs = {}
                        filtered_out = []
                        for param_name in params_spec.keys():
                            if param_name in kwargs:
                                filtered_kwargs[param_name] = kwargs[param_name]
                        
                        # Track what was filtered out for debugging
                        for key in kwargs.keys():
                            if key not in params_spec:
                                filtered_out.append(key)
                        
                        if filtered_out:
                            logger.debug(f"🔍 Filtered out internal DSPy parameters: {filtered_out} (not in tool signature)")
                        
                        final_kwargs = dict(filtered_kwargs)
                        
                        for param_name, param_info in params_spec.items():
                            if param_name in final_kwargs:
                                # Level 1: Explicit override (highest priority)
                                logger.debug(f"✅ {tname}({param_name}): Using explicit value")
                                continue
                            
                            # Level 2: Exact match in IOManager (actor outputs)
                            resolved_val = self._resolve_param_from_iomanager(param_name)
                            if resolved_val is not None:
                                final_kwargs[param_name] = resolved_val
                                logger.info(f"✅ {tname}({param_name}): Auto-resolved from IOManager")
                                continue
                            
                            # Level 3: Exact match in SharedContext (global data)
                            if hasattr(self, 'shared_context') and self.shared_context.has(param_name):
                                resolved_val = self.shared_context.get(param_name)
                                final_kwargs[param_name] = resolved_val
                                logger.info(f"✅ {tname}({param_name}): Auto-resolved from SharedContext")
                                continue
                            
                            # Level 3.5: Special handling for search_query - only use as last resort fallback
                            # The ReAct agent should extract and provide search_query itself based on tool description
                            # This fallback is only for cases where the agent truly fails to provide it
                            if param_name == 'search_query':
                                # Don't auto-resolve - let ReAct agent extract it from task context
                                # Only log that it's missing so the agent can learn
                                logger.debug(f"🔍 {tname}({param_name}): ReAct agent should extract this from task context")
                            
                            # Level 4: Type-based resolution (GENERIC!)
                            param_type = param_info.get('annotation', '')
                            if param_type:
                                resolved_val = self._resolve_param_by_type(param_name, param_type)
                                if resolved_val is not None:
                                    final_kwargs[param_name] = resolved_val
                                    logger.info(f"✅ {tname}({param_name}): Auto-resolved by type ({param_type})")
                                    continue
                            
                            # Last-chance generic derivation for required string-like params.
                            if param_info.get('required', False) and param_name not in final_kwargs:
                                if param_name == 'search_query':
                                    # Prefer common semantic fields if present.
                                    for candidate in ('search_query', 'query', 'instruction', 'task_description', 'goal', 'text', 'message'):
                                        candidate_val = raw_kwargs.get(candidate, final_kwargs.get(candidate))
                                        if isinstance(candidate_val, str) and candidate_val.strip():
                                            final_kwargs[param_name] = candidate_val.strip()
                                            logger.info(f"✅ {tname}({param_name}): Derived from '{candidate}'")
                                            break
                                    if param_name not in final_kwargs and hasattr(self, "shared_context"):
                                        for skey in ("query", "instruction", "current_goal", "goal", "root_goal", "task_description"):
                                            sval = self.shared_context.get(skey) if self.shared_context.has(skey) else None
                                            if isinstance(sval, str) and sval.strip():
                                                final_kwargs[param_name] = sval.strip()
                                                logger.info(f"✅ {tname}({param_name}): Derived from SharedContext '{skey}'")
                                                break
                                    if param_name not in final_kwargs and hasattr(self, "todo"):
                                        root_goal = getattr(self.todo, "root_task", None)
                                        if isinstance(root_goal, str) and root_goal.strip():
                                            final_kwargs[param_name] = root_goal.strip()
                                            logger.info(f"✅ {tname}({param_name}): Derived from TODO root task")
                                    if param_name not in final_kwargs and hasattr(self, "todo"):
                                        try:
                                            task_items = self.todo.get_all_tasks_list() if hasattr(self.todo, "get_all_tasks_list") else []
                                            for item in task_items:
                                                desc = item.get("description") if isinstance(item, dict) else None
                                                if isinstance(desc, str) and desc.strip():
                                                    final_kwargs[param_name] = desc.strip()
                                                    logger.info(f"✅ {tname}({param_name}): Derived from TODO task description")
                                                    break
                                        except Exception:
                                            pass
                                    if param_name not in final_kwargs:
                                        # Generic salvage: scan raw kwargs for a usable query-like string.
                                        for _, value in raw_kwargs.items():
                                            candidate_str = None
                                            if isinstance(value, str):
                                                candidate_str = value.strip()
                                            elif isinstance(value, (list, tuple)):
                                                candidate_str = " ".join(str(v) for v in value if isinstance(v, str)).strip()
                                            elif isinstance(value, dict):
                                                joined = []
                                                for vk in ("query", "instruction", "task_description", "goal", "text", "message"):
                                                    vv = value.get(vk)
                                                    if isinstance(vv, str) and vv.strip():
                                                        joined.append(vv.strip())
                                                candidate_str = " ".join(joined).strip()
                                            if candidate_str:
                                                final_kwargs[param_name] = candidate_str[:2000]
                                                logger.info(f"✅ {tname}({param_name}): Derived from generic kwargs scan")
                                                break
                                    if param_name not in final_kwargs:
                                        # Never hard-fail the tool invocation on missing query; provide minimal fallback
                                        # so the actor can keep progressing and correct itself in subsequent turns.
                                        final_kwargs[param_name] = "latest task context and required evidence"
                                        logger.warning(
                                            f"⚠️  {tname}({param_name}): No semantic source found; using safe fallback query"
                                        )

                            # Not resolved - only warn if parameter is actually required
                            # 🔥 A-TEAM FIX: Optional parameters (with defaults) should not cause errors
                            if param_info.get('required', False) and param_name not in final_kwargs:  # Only True if no default value
                                # For search_query, provide helpful error message
                                if param_name == 'search_query':
                                    error_msg = f"ERROR: {tname}() requires search_query parameter. You must provide this parameter when calling the tool."
                                    logger.error(f"❌ {tname}({param_name}): {error_msg}")
                                    return json.dumps({"error": error_msg})
                                else:
                                    logger.warning(f"⚠️  {tname}({param_name}): Required parameter not resolved")
                            else:
                                logger.debug(f"ℹ️  {tname}({param_name}): Optional parameter not provided, will use default")
                        
                        # Check cache first (via SharedScratchpad)
                        result = self._call_tool_with_cache(tname, **final_kwargs)
                        
                        # Ensure result is string (DSPy tools return strings)
                        if not isinstance(result, str):
                            return json.dumps(result, indent=2)
                        return result
                        
                    except Exception as e:
                        error_msg = self._build_helpful_error_message(tname, tinfo, e)
                        logger.error(f"❌ Tool {tname} error: {e}")
                        return json.dumps({"error": error_msg})
                
                # Preserve signature so DSPy can infer it correctly
                if new_sig:
                    smart_tool_func.__signature__ = new_sig
                    # Also set __annotations__ for better type hints
                    annotations = {}
                    for param_name, param in new_sig.parameters.items():
                        if param_name != 'self' and param.annotation != inspect.Parameter.empty:
                            annotations[param_name] = param.annotation
                    if annotations:
                        smart_tool_func.__annotations__ = annotations
                
                return smart_tool_func
            
            # Create smart wrapper with preserved signature
            smart_wrapper = make_smart_tool_func(tool_name, tool_info, original_sig)
            
            # DSPy ReAct automatically infers function signature from func parameter
            # Now smart_wrapper has the same signature as original function (all params optional)
            tool_desc = f"{tool_info['desc']}\n\nWhen to use: {tool_info['when']}"
            
            # Create dspy.Tool - DSPy will auto-infer signature from the function
            tool = dspy.Tool(
                func=smart_wrapper,
                name=tool_name,
                desc=tool_desc
            )
            
            # 🔥 A-TEAM CRITICAL FIX: Attach Val agent flags to dspy.Tool!
            tool._synapse_for_architect = tool_info.get('for_architect', False)
            tool._synapse_for_auditor = tool_info.get('for_auditor', False)
            
            tools.append(tool)
            logger.debug(f"  ✅ {tool_name} (architect={tool._synapse_for_architect}, auditor={tool._synapse_for_auditor})")
        
        logger.info(f"✅ Auto-discovered {len(tools)} tools for Val agents")
        for tool in tools:
            logger.info(f"   - {tool.name}: {tool.desc[:80]}...")
        
        return tools
    
    def _resolve_param_from_iomanager(self, param_name: str) -> Any:
        """
        Resolve parameter from IOManager (previous actor outputs).
        
        🔥 A-TEAM: Level 2 resolution - searches actor outputs for param
        
        Args:
            param_name: Name of parameter to resolve (e.g., 'tables')
        
        Returns:
            Resolved value or None if not found
        """
        if not hasattr(self, 'io_manager') or not self.io_manager:
            return None
        
        # Try exact name match in all actor outputs
        all_outputs = self.io_manager.get_all_outputs()
        for actor_name, output in all_outputs.items():
            if hasattr(output, 'output_fields') and isinstance(output.output_fields, dict):
                if param_name in output.output_fields:
                    value = output.output_fields[param_name]
                    logger.debug(f"   📦 Found '{param_name}' in {actor_name} output")
                    return value
        
        return None
    
    def _resolve_param_by_type(self, param_name: str, param_type: Any) -> Any:
        """
        Resolve parameter by type matching in IOManager.
        
        🔥 A-TEAM: Level 4 resolution - GENERIC type-based matching!
        Works for ANY type, not just hardcoded names.
        
        Args:
            param_name: Name of parameter (for logging)
            param_type: Type annotation (can be type object or string)
        
        Returns:
            Resolved value or None if not found
        """
        if not hasattr(self, 'io_manager') or not self.io_manager:
            return None
        
        # 🔥 A-TEAM FIX: Convert type annotation to string for comparison
        # Handle both type objects and string annotations
        type_str = str(param_type) if not isinstance(param_type, str) else param_type
        
        # Parse type (simplified - handles common cases)
        target_type = None
        if 'List' in type_str or 'list' in type_str:
            target_type = list
        elif 'Dict' in type_str or 'dict' in type_str:
            target_type = dict
        elif type_str in ['str', 'string'] or 'str' in type_str:
            target_type = str
        elif type_str in ['int', 'integer'] or 'int' in type_str:
            target_type = int
        elif type_str in ['float'] or 'float' in type_str:
            target_type = float
        elif type_str in ['bool', 'boolean'] or 'bool' in type_str:
            target_type = bool
        
        if not target_type:
            return None
        
        # Search all actor outputs for matching type
        all_outputs = self.io_manager.get_all_outputs()
        for actor_name, output in all_outputs.items():
            if hasattr(output, 'output_fields') and isinstance(output.output_fields, dict):
                for field_name, field_value in output.output_fields.items():
                    if isinstance(field_value, target_type):
                        logger.debug(f"   🎯 Type match for '{param_name}': found {field_name} ({type(field_value).__name__}) in {actor_name}")
                        return field_value
        
        return None
    
    def _call_tool_with_cache(self, tool_name: str, **kwargs) -> Any:
        """
        Call tool with caching via SharedScratchpad.
        
        🔥 A-TEAM: Prevents duplicate tool calls across Val agents!
        
        Args:
            tool_name: Name of tool to call
            **kwargs: Parameters for tool
        
        Returns:
            Tool result (cached if available)
        """
        import json
        
        # Create cache key
        cache_key = f"tool_call:{tool_name}:{json.dumps(kwargs, sort_keys=True)}"
        
        # Check cache
        if hasattr(self, 'shared_scratchpad') and self.shared_scratchpad:
            if cache_key in self.shared_scratchpad:
                logger.debug(f"💾 Cache HIT: {tool_name}({list(kwargs.keys())})")
                return self.shared_scratchpad[cache_key]
        
        # Call actual tool
        logger.debug(f"📞 Calling {tool_name}({list(kwargs.keys())})")
        result = self.metadata_tool_registry.call_tool(tool_name, **kwargs)
        
        # Store in cache
        if hasattr(self, 'shared_scratchpad') and self.shared_scratchpad:
            self.shared_scratchpad[cache_key] = result
        
        return result
    
    def _build_helpful_error_message(self, tool_name: str, tool_info: Dict, error: Exception) -> str:
        """
        Build helpful error message for Val agents when tool call fails.
        
        🔥 A-TEAM: Shows available data and how to fix the issue!
        
        Args:
            tool_name: Name of tool that failed
            tool_info: Tool metadata
            error: Exception that occurred
        
        Returns:
            Helpful error message string
        """
        import json
        
        # Extract missing parameters if it's a TypeError
        error_str = str(error)
        
        # Build helpful message
        msg_parts = [f"❌ {tool_name}() failed: {error_str}"]
        
        # If missing parameters, show available data
        if 'missing' in error_str.lower() or 'required' in error_str.lower():
            msg_parts.append("\n📦 AVAILABLE DATA (IOManager):")
            
            if hasattr(self, 'io_manager') and self.io_manager:
                all_outputs = self.io_manager.get_all_outputs()
                for actor_name, output in all_outputs.items():
                    if hasattr(output, 'output_fields'):
                        fields = list(output.output_fields.keys()) if isinstance(output.output_fields, dict) else []
                        msg_parts.append(f"  • {actor_name}: {fields}")
            else:
                msg_parts.append("  (No IOManager available)")
            
            msg_parts.append("\n💡 TIP: You can provide parameters explicitly in your tool call.")
            msg_parts.append(f"   Example: {tool_name}(param_name=value)")
        
        return "\n".join(msg_parts)
    
    async def _web_search_on_error(self, error: Exception, context: Dict[str, Any]) -> Optional[str]:
        """
        A-Team Enhancement: Web search fallback on errors.
        
        When an error occurs, use web search to find:
        - Documentation for the failing component
        - Common solutions to similar errors
        - Library usage examples
        
        This ensures agents can recover from unknown errors by learning.
        """
        if not hasattr(self, 'metadata_provider'):
            return None
        
        # Build search query from error
        error_type = type(error).__name__
        error_msg = smart_truncate(str(error), max_tokens=100)
        
        # Extract key terms from context
        task = context.get('task', '')
        actor = context.get('actor', '')
        
        search_query = f"{error_type} {error_msg} solution"
        if actor:
            search_query = f"{actor} {search_query}"
        
        try:
            # Try to use web search tool
            if hasattr(self.metadata_provider, 'web_search'):
                result = self.metadata_provider.web_search(
                    query=search_query,
                    max_results=3,
                    max_chars=2000
                )
                if result and "error" not in result.lower():
                    logger.info(f"🔍 Web search found info for error: {error_type}")
                    return f"""
🌐 WEB SEARCH RESULTS FOR ERROR:
Query: {search_query}

{result}

Use this information to understand and fix the error.
"""
        except Exception as e:
            logger.debug(f"Web search fallback failed: {e}")
        
        return None
    
    def _build_enhanced_tool_description(self, tool_name: str, tool_info: Dict) -> str:
        """
        Build simple tool description - DSPy ReAct auto-infers function signature!
        
        🔥 A-TEAM SIMPLIFICATION: DSPy automatically extracts signature from func parameter.
        We only need to provide a clear description and "when to use" guidance.
        
        Args:
            tool_name: Name of tool
            tool_info: Tool metadata
        
        Returns:
            Simple description string (DSPy handles signature inference)
        """
        # DSPy ReAct automatically infers function signature from the func parameter
        # We just need a clear description - no need to manually list parameters!
        desc = tool_info['desc']
        when = tool_info['when']
        
        return f"{desc}\n\nWhen to use: {when}"

    async def _extract_missing_params_llm(
        self,
        error_message: str,
        signature: Dict[str, Any],
        provided_params: Dict[str, Any]
    ) -> List[str]:
        """
        LLM-based extraction of missing parameter names (no regex).
        """
        if not DSPY_AVAILABLE:
            return []
        
        try:
            extractor = dspy.ChainOfThought(MissingParameterSignature)
            result = extractor(
                error_message=smart_truncate(str(error_message), max_tokens=125),
                signature_json=smart_truncate(json.dumps(signature, default=str), max_tokens=500),
                provided_params=smart_truncate(json.dumps(list(provided_params.keys())), max_tokens=250)
            )
            if hasattr(result, "missing_params"):
                try:
                    missing = json.loads(result.missing_params)
                    return [p for p in missing if isinstance(p, str)]
                except Exception:
                    pass
        except Exception as e:
            logger.debug(f"LLM missing-param extraction failed: {e}")
        
        return []
    
    def _get_architect_tools(self, all_tools: List[Any]) -> List[Any]:
        """
        Filter tools marked for Architect by metadata manager.
        
        🔥 A-TEAM CRITICAL FIX: NO HARDCODING!
        
        This method checks the `for_architect` flag set by @synapse_method decorator.
        The METADATA MANAGER (user-provided, domain-specific) decides which tools
        are for Architect, NOT SYNAPSE core (which is generic).
        
        This keeps SYNAPSE domain-agnostic and reusable for ANY use case!
        """
        filtered = []
        for tool in all_tools:
            # 🔥 A-TEAM FIX: Tools are dictionaries from MetadataToolRegistry
            if isinstance(tool, dict) and tool.get('for_architect', False):
                filtered.append(tool)
            # Legacy support for function objects
            elif hasattr(tool, 'func') and hasattr(tool.func, '_synapse_for_architect'):
                if tool.func._synapse_for_architect:
                    filtered.append(tool)
            elif hasattr(tool, '_synapse_for_architect'):
                if tool._synapse_for_architect:
                    filtered.append(tool)
        
        logger.info(f"🔍 Architect tools: {len(filtered)}/{len(all_tools)} tools (marked by metadata manager)")
        for tool in filtered:
            tool_name = tool.get('name') if isinstance(tool, dict) else (tool.name if hasattr(tool, 'name') else tool.__name__)
            logger.debug(f"   ✅ {tool_name}")
        
        return filtered
    
    def _get_auditor_tools(self, all_tools: List[Any]) -> List[Any]:
        """
        Filter tools marked for Auditor by metadata manager.
        
        🔥 A-TEAM CRITICAL FIX: NO HARDCODING!
        
        This method checks the `for_auditor` flag set by @synapse_method decorator.
        The METADATA MANAGER (user-provided, domain-specific) decides which tools
        are for Auditor, NOT SYNAPSE core (which is generic).
        
        This keeps SYNAPSE domain-agnostic and reusable for ANY use case!
        """
        filtered = []
        for tool in all_tools:
            # 🔥 A-TEAM FIX: Tools are dictionaries from MetadataToolRegistry
            if isinstance(tool, dict) and tool.get('for_auditor', False):
                filtered.append(tool)
            # Legacy support for function objects
            elif hasattr(tool, 'func') and hasattr(tool.func, '_synapse_for_auditor'):
                if tool.func._synapse_for_auditor:
                    filtered.append(tool)
            elif hasattr(tool, '_synapse_for_auditor'):
                if tool._synapse_for_auditor:
                    filtered.append(tool)
        
        logger.info(f"✅ Auditor tools: {len(filtered)}/{len(all_tools)} tools (marked by metadata manager)")
        for tool in filtered:
            tool_name = tool.get('name') if isinstance(tool, dict) else (tool.name if hasattr(tool, 'name') else tool.__name__)
            logger.debug(f"   ✅ {tool_name}")
        
        return filtered
    
    def _wrap_actor_with_synapse(self, actor_config: ActorConfig):
        """
        Wrap an actor with Synapse wrapper for validation and tool support.
        
        This enables per-actor validation and tools in Conductor.
        
        🔥 A-TEAM PHASE 2 FIX: Separate tool sets for Architect vs Auditor!
        - Architect gets exploration tools (4-5 tools)
        - Auditor gets verification tools (6-7 tools)
        - NO overlap of inappropriate tools!
        """
        from .synapse_core import SynapseCore
        
        # Get all available tools
        all_tools = self._get_auto_discovered_dspy_tools()
        
        # 🔥 A-TEAM: Separate tool sets for Architect vs Auditor
        # IMPORTANT: Always merge explicitly provided tools with auto-discovered tools!
        architect_tools = actor_config.architect_tools or []
        auto_architect_tools = self._get_architect_tools(all_tools)
        
        # Helper function to extract tool name consistently
        def get_tool_name(tool):
            """Extract tool name from function or dspy.Tool object."""
            if hasattr(tool, 'name'):
                return tool.name
            if hasattr(tool, '__name__'):
                return tool.__name__
            return str(tool)
        
        # Merge: combine explicitly provided tools with auto-discovered architect tools
        # Avoid duplicates by checking tool names/identity
        merged_architect_tools = list(architect_tools)  # Start with explicitly provided
        explicit_tool_names = {get_tool_name(t) for t in architect_tools}
        
        added_tools = []
        for auto_tool in auto_architect_tools:
            auto_tool_name = get_tool_name(auto_tool)
            if auto_tool_name not in explicit_tool_names:
                merged_architect_tools.append(auto_tool)
                added_tools.append(auto_tool_name)
        
        architect_tools = merged_architect_tools
        if len(auto_architect_tools) > 0:
            logger.info(f"✅ Merged architect tools: {len(explicit_tool_names)} explicit + {len(added_tools)} auto-discovered = {len(architect_tools)} total")
            if added_tools:
                logger.info(f"   📦 Added auto-discovered tools: {', '.join(added_tools)}")
        
        auditor_tools = actor_config.auditor_tools or []
        auto_auditor_tools = self._get_auditor_tools(all_tools)
        
        # Merge auditor tools similarly
        merged_auditor_tools = list(auditor_tools)
        explicit_auditor_names = {get_tool_name(t) for t in auditor_tools}
        
        added_auditor_tools = []
        for auto_tool in auto_auditor_tools:
            auto_tool_name = get_tool_name(auto_tool)
            if auto_tool_name not in explicit_auditor_names:
                merged_auditor_tools.append(auto_tool)
                added_auditor_tools.append(auto_tool_name)
        
        auditor_tools = merged_auditor_tools
        if len(auto_auditor_tools) > 0:
            logger.info(f"✅ Merged auditor tools: {len(explicit_auditor_names)} explicit + {len(added_auditor_tools)} auto-discovered = {len(auditor_tools)} total")
            if added_auditor_tools:
                logger.info(f"   📦 Added auto-discovered tools: {', '.join(added_auditor_tools)}")
        
        # 🔴 A-TEAM: Per-agent model override from AgentConfig.model (set via agent_models.yaml)
        agent_model = getattr(actor_config, 'model', None)
        agent_lm = None
        if agent_model:
            try:
                from Synapse.core.llm_gateway import resolve_lm_kwargs, resolve_gateway_name
                _agent_gateway = getattr(actor_config, "gateway", None) or getattr(self.config, "model_gateway", None)
                _api_key_env = getattr(actor_config, "api_key_env", None)
                _api_base_env = getattr(actor_config, "api_base_env", None)
                _lm_kwargs = resolve_lm_kwargs(
                    model=agent_model,
                    gateway=_agent_gateway,
                    api_key_env=_api_key_env,
                    api_base_env=_api_base_env,
                )
                # Backward compatibility fallback for configs that still rely on model_api_*.
                if "api_key" not in _lm_kwargs and getattr(self.config, "model_api_key", None):
                    _lm_kwargs["api_key"] = getattr(self.config, "model_api_key")
                if "api_base" not in _lm_kwargs and getattr(self.config, "model_api_base", None):
                    _lm_kwargs["api_base"] = getattr(self.config, "model_api_base")
                agent_lm = dspy.LM(**_lm_kwargs)
                logger.info(
                    f"  🏷️ Per-agent LM override: {agent_model} "
                    f"(gateway={resolve_gateway_name(_agent_gateway)})"
                )
            except Exception as e:
                logger.warning(f"  ⚠️ Failed to create per-agent LM for {actor_config.name}: {e}")
                agent_lm = None
        
        logger.info(f"🔧 Wrapping actor '{actor_config.name}' with SYNAPSE")
        logger.info(f"  📝 Architect prompts: {len(actor_config.architect_prompts)}")
        logger.info(f"  📝 Auditor prompts: {len(actor_config.auditor_prompts)}")
        logger.info(f"  🔍 Architect tools: {len(architect_tools)} (exploration)")
        logger.info(f"  ✅ Auditor tools: {len(auditor_tools)} (verification)")
        logger.info(f"  🏷️ Model: {agent_model or 'default (global dspy LM)'}")
        
        synapse_core = SynapseCore(
            actor=actor_config.agent,
            architect_prompts=actor_config.architect_prompts or [],
            auditor_prompts=actor_config.auditor_prompts or [],
            architect_tools=architect_tools or [],
            auditor_tools=auditor_tools or [],
            actor_tools=all_tools or [],
            config=self.config,
            actor_config=actor_config,  # 🔑 A-TEAM: Pass actor_config for validation control
            shared_context=self.shared_context  # 🔥 A-TEAM: Pass SharedContext for metadata access
        )
        
        # 🔴 A-TEAM: Store per-agent LM on the SynapseCore wrapper for use during execution
        synapse_core._agent_lm_override = agent_lm
        
        return synapse_core
    
    def _load_annotations(self, path: Optional[str]) -> Dict[str, Any]:
        """Load annotations for validation enrichment."""
        if not path:
            return {}
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load annotations: {e}")
            return {}
    
    # ─── Event Schema Validation (Item 163) ──────────────────────────
    _TASK_LIST_REQUIRED_KEYS = {"total_tasks", "tasks", "root_task", "completed_count", "failed_count"}
    _MEMORY_UPDATE_REQUIRED_KEYS = {"content", "level", "actor", "operation", "timestamp"}
    _FAN_OUT_REQUIRED_KEYS = {"child_count", "child_ids", "child_actors"}
    _FAN_IN_REQUIRED_KEYS = {"passed", "failed", "duration_s"}
    _ANOMALY_ALERT_REQUIRED_KEYS = {"anomaly", "severity"}
    
    # Type constraints for critical fields (field_name -> expected type)
    _TASK_LIST_TYPE_SCHEMA = {
        "total_tasks": int, "tasks": list, "completed_count": int, "failed_count": int
    }
    _MEMORY_UPDATE_TYPE_SCHEMA = {
        "content": str, "level": str, "actor": str, "operation": str, "timestamp": str
    }

    @staticmethod
    def _validate_event_payload(payload: Dict[str, Any], required_keys: set, event_type: str,
                                 type_schema: Optional[Dict[str, type]] = None) -> List[str]:
        """Validate event payload: required keys, no None for critical fields, and optional type checks."""
        errors = []
        if not isinstance(payload, dict):
            return [f"{event_type}: payload is not a dict ({type(payload).__name__})"]
        missing = required_keys - set(payload.keys())
        if missing:
            errors.append(f"{event_type}: missing keys {missing}")
        for key in required_keys:
            if key in payload and payload[key] is None:
                errors.append(f"{event_type}: key '{key}' is None")
        # Type validation
        if type_schema:
            for key, expected_type in type_schema.items():
                if key in payload and payload[key] is not None and not isinstance(payload[key], expected_type):
                    errors.append(f"{event_type}: key '{key}' expected {expected_type.__name__}, got {type(payload[key]).__name__}")
        return errors

    def _build_task_list_event(self) -> Optional[Dict[str, Any]]:
        """
        Build a task_list event for the frontend.
        
        Called after each task completion/failure to push real-time updates
        to the UI so the task list stays in sync.
        
        Returns:
            Event dict with type='task_list' and full task data, or None on error.
        """
        try:
            all_tasks = self.todo.get_all_tasks_list()
            completed_count = len(self.todo.completed_tasks)
            total_count = len(self.todo.subtasks)
            failed_count = len(self.todo.failed_tasks) if hasattr(self.todo, 'failed_tasks') else 0
            self._event_seq += 1
            data = {
                "total_tasks": len(all_tasks),
                "tasks": all_tasks,
                "root_task": self.todo.root_task,
                "completed_count": completed_count,
                "failed_count": failed_count
            }
            # Schema validation
            validation_errors = self._validate_event_payload(data, self._TASK_LIST_REQUIRED_KEYS, "task_list", self._TASK_LIST_TYPE_SCHEMA)
            if validation_errors:
                logger.warning(f"⚠️ task_list schema violation: {validation_errors}")
            logger.info(f"📋 [TASK_LIST_EVENT] Emitting task_list | completed={completed_count}/{total_count} | failed={failed_count} | seq={self._event_seq}")
            return {
                "module": "Synapse.core.conductor",
                "message": f"Task progress: {completed_count}/{total_count} completed, {failed_count} failed",
                "type": "task_list",
                "event_version": "1.0",
                "seq": self._event_seq,
                "data": data
            }
        except Exception as e:
            logger.warning(f"Failed to build task list event: {e}")
            return None

    def _build_memory_update_event(
        self,
        content: str,
        level: str = "episodic",
        actor: str = "",
        context: dict = None,
        operation: str = "created",
    ) -> Dict[str, Any]:
        """
        Build a memory_update event for the frontend Memory panel.
        
        Called after each memory store to push the entry to the UI in real-time.
        """
        self._event_seq += 1
        context = context or {}
        enriched_content = str(content or "")
        retrieval_type = context.get("retrieval_type")
        confidence = context.get("confidence")
        if retrieval_type:
            enriched_content = f"[{retrieval_type}] {enriched_content}"
        if confidence is not None:
            try:
                enriched_content = f"{enriched_content}\nconfidence={float(confidence):.2f}"
            except Exception:
                enriched_content = f"{enriched_content}\nconfidence={confidence}"
        data = {
            "content": enriched_content[:4000],
            "level": level,
            "actor": actor or context.get('actor', ''),
            "operation": operation,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "task_id": context.get('task', ''),
        }
        # Schema validation
        validation_errors = self._validate_event_payload(data, self._MEMORY_UPDATE_REQUIRED_KEYS, "memory_update", self._MEMORY_UPDATE_TYPE_SCHEMA)
        if validation_errors:
            logger.warning(f"⚠️ memory_update schema violation: {validation_errors}")
        return {
            "module": "Synapse.core.conductor",
            "message": f"Memory stored: {enriched_content[:120]}...",
            "type": "memory_update",
            "event_version": "1.0",
            "seq": self._event_seq,
            "data": data
        }

    def _generate_correlation_id(self, prefix: str = "evt") -> str:
        """Generate a short, unique correlation ID for linking related events (screenshots + logs)."""
        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    # ================================================================
    # Item 189: Anomaly Detection
    # ================================================================
    def _detect_anomalies(self, iteration: int, loop_start_time: float) -> List[Dict[str, Any]]:
        """
        Detect runtime anomalies: stuck progress, repeated retries, blank screenshots.
        
        Returns a list of anomaly alert dicts to be yielded as events.
        Called periodically (every N iterations) from the main loop.
        """
        alerts: List[Dict[str, Any]] = []
        
        # ── 1. Stuck progress: no completed tasks in last N iterations ──
        completed_count = len(self.todo.completed_tasks)
        prev_completed = getattr(self, '_anomaly_prev_completed', 0)
        prev_check_iter = getattr(self, '_anomaly_prev_iter', 0)
        iter_delta = iteration - prev_check_iter
        
        if iter_delta >= 3 and completed_count == prev_completed and completed_count < len(self.todo.subtasks):
            alerts.append({
                "module": "Synapse.core.conductor",
                "type": "agent_event",
                "event_type": "anomaly_alert",
                "data": {
                    "anomaly": "stuck_progress",
                    "severity": "high",
                    "detail": f"No task completions in {iter_delta} iterations (still {completed_count}/{len(self.todo.subtasks)})",
                    "iteration": iteration,
                },
                "message": f"⚠️ ANOMALY: Progress stuck at {completed_count}/{len(self.todo.subtasks)} for {iter_delta} iterations"
            })
            logger.warning(f"🚨 [ANOMALY] Stuck progress: {completed_count}/{len(self.todo.subtasks)} for {iter_delta} iterations")
        
        self._anomaly_prev_completed = completed_count
        self._anomaly_prev_iter = iteration
        
        # ── 2. Repeated retries on same task ──
        for tid, subtask in self.todo.subtasks.items():
            if hasattr(subtask, 'attempts') and subtask.attempts >= 3 and subtask.status.value not in ('completed', 'skipped', 'archived'):
                alerts.append({
                    "module": "Synapse.core.conductor",
                    "type": "agent_event",
                    "event_type": "anomaly_alert",
                    "data": {
                        "anomaly": "repeated_retries",
                        "severity": "medium",
                        "task_id": tid,
                        "attempts": subtask.attempts,
                        "last_failure": subtask.failure_reasons[-1] if subtask.failure_reasons else "unknown",
                    },
                    "message": f"⚠️ ANOMALY: Task {tid} retried {subtask.attempts} times without success"
                })
        
        # ── 3. Long elapsed time with low completion ratio ──
        elapsed = time.time() - loop_start_time
        total = len(self.todo.subtasks)
        if elapsed > 300 and total > 0:  # After 5 minutes
            ratio = completed_count / total
            expected_ratio = min(1.0, elapsed / 1200)  # Expect ~1 task per minute baseline
            if ratio < expected_ratio * 0.3:  # Less than 30% of expected pace
                alerts.append({
                    "module": "Synapse.core.conductor",
                    "type": "agent_event",
                    "event_type": "anomaly_alert",
                    "data": {
                        "anomaly": "slow_progress",
                        "severity": "medium",
                        "elapsed_seconds": round(elapsed, 1),
                        "completion_ratio": round(ratio, 3),
                        "expected_ratio": round(expected_ratio, 3),
                    },
                    "message": f"⚠️ ANOMALY: Slow progress — {ratio:.1%} complete after {elapsed:.0f}s (expected ~{expected_ratio:.1%})"
                })
        
        return alerts

    def _drain_and_build_screenshot_events(self, actor_name: str, correlation_id: str = None) -> List[Dict[str, Any]]:
        """Drain pending screenshot events and build agent_event dicts for the frontend.
        
        After an actor finishes execution (or at any yield point), screenshots
        captured by electron_screenshot are queued in browser_tools. This method
        drains that queue and builds properly-attributed events so the UI can
        render them in the actor's screen card.
        
        Args:
            actor_name: Name of the actor that took the screenshots.
            correlation_id: Optional correlation ID to link screenshots with log events.
        """
        events = []
        try:
            from surface.tools.browser_tools import drain_screenshot_events
            raw = drain_screenshot_events()
            for sc in raw:
                cid = correlation_id or self._generate_correlation_id("ss")
                events.append({
                    "type": "agent_event",
                    "agent": sc.get("agent") or actor_name,
                    "event_type": "screenshot",
                    "_actor_name": sc.get("agent") or actor_name,
                    "correlation_id": cid,
                    "data": {
                        "screenshot": sc.get("screenshot", ""),
                        "instance_id": sc.get("instance_id", "default"),
                        "caption": f"Browser @ {sc.get('url', '')}" if sc.get("url") else "",
                        "correlation_id": cid,
                    },
                })
            if events:
                logger.info(f"📸 Drained {len(events)} screenshot event(s) for {actor_name} (corr={correlation_id or 'auto'})")
        except ImportError:
            pass
        return events

    def _build_actor_output_event(self, actor_name: str, result, task) -> Dict[str, Any]:
        """
        Build an actor_output event so the frontend can display the result
        in the actor's dedicated screen card.
        
        Extracts the most useful renderable content from the result:
        - Plain text output
        - Structured data (slides, tests, files)
        - Screenshots / images
        """
        output_data: Dict[str, Any] = {}
        
        # Extract output text
        if hasattr(result, 'output') and result.output:
            output_data['output'] = str(result.output)[:2000]
        elif hasattr(result, 'final_output') and result.final_output:
            output_data['output'] = str(result.final_output)[:2000]
        elif isinstance(result, str):
            output_data['output'] = result[:2000]
        elif isinstance(result, dict):
            if 'output' in result:
                output_data['output'] = str(result['output'])[:2000]
            elif 'final_output' in result:
                output_data['output'] = str(result['final_output'])[:2000]
        
        # Extract structured data
        if hasattr(result, 'tagged_outputs') and result.tagged_outputs:
            output_data['tagged_outputs'] = [
                {'tag': getattr(t, 'tag', ''), 'content': str(getattr(t, 'content', ''))[:500]}
                for t in result.tagged_outputs[:10]
            ]
        
        # File paths
        if hasattr(result, 'file_path'):
            output_data['file_path'] = str(result.file_path)
        elif hasattr(result, 'output_file'):
            output_data['file_path'] = str(result.output_file)
        
        # Screenshots
        if hasattr(result, 'screenshot'):
            output_data['screenshot'] = result.screenshot
        elif hasattr(result, 'image_base64'):
            output_data['image_base64'] = result.image_base64
        
        # Test results
        if hasattr(result, 'test_results'):
            output_data['test_results'] = result.test_results
        
        # Slides / structured items
        if hasattr(result, 'slides'):
            output_data['slides'] = result.slides
        elif hasattr(result, 'items'):
            output_data['items'] = result.items
        
        # Task info
        task_desc = task.description[:100] if hasattr(task, 'description') else ''
        
        # If no useful output was extracted, create a summary
        if not output_data.get('output') and not any(k in output_data for k in ['file_path', 'screenshot', 'test_results', 'slides', 'items']):
            output_data['output'] = f"✅ {actor_name} completed task: {task_desc}"
        
        correlation_id = self._generate_correlation_id("act")
        return {
            "module": actor_name,
            "_actor_name": actor_name,
            "message": output_data.get('output', f"✅ {actor_name} completed"),
            "type": "actor_output",
            "correlation_id": correlation_id,
            "data": {**output_data, "correlation_id": correlation_id}
        }

    def _build_dag_event(self, task_dag) -> Optional[Dict[str, Any]]:
        """
        Build a DAG visualization event for the frontend.
        
        Serializes the TaskDAG structure into nodes and edges
        that can be rendered as a visual dependency graph.
        
        Args:
            task_dag: TaskDAG object with tasks and dependencies
            
        Returns:
            Event dict with type='dag' and visualization data.
        """
        try:
            nodes = []
            edges = []
            
            for task_id, task in task_dag.tasks.items():
                status_val = task.status.value if hasattr(task.status, 'value') else str(task.status)
                type_val = getattr(task, 'task_type', None)
                type_val = type_val.value if hasattr(type_val, 'value') else str(type_val) if type_val else 'action'
                # Use 'name' if available (TaskDAG tasks), else 'description' (SubtaskState)
                display_name = getattr(task, 'name', None) or getattr(task, 'description', task_id)
                nodes.append({
                    "id": task_id,
                    "name": str(display_name)[:60],
                    "status": status_val,
                    "type": type_val,
                    "depends_on": list(task.depends_on) if task.depends_on else [],
                    # 🔴 A-TEAM: Enriched node data
                    "actor": getattr(task, 'actor', None),
                    "attempts": getattr(task, 'attempts', 0),
                    "max_attempts": getattr(task, 'max_attempts', 5),
                    "priority": getattr(task, 'priority', 0.5),
                    "failure_count": len(getattr(task, 'failure_reasons', [])),
                    "last_failure": str(task.failure_reasons[-1])[:80] if getattr(task, 'failure_reasons', None) else None,
                    "test_status": (task.test_status.value if hasattr(task.test_status, 'value') else str(task.test_status)) if getattr(task, 'test_status', None) else None,
                })
                
                for dep_id in (task.depends_on or []):
                    edges.append({"from": dep_id, "to": task_id})
            
            # Get execution stages for parallel grouping
            stages = []
            try:
                stage_list = task_dag.get_execution_stages()
                for stage in stage_list:
                    stages.append([t.id for t in stage])
            except Exception:
                pass
            
            return {
                "module": "Synapse.core.conductor",
                "message": f"DAG visualization: {len(nodes)} tasks, {len(edges)} dependencies, {len(stages)} stages",
                "type": "dag",
                "data": {
                    "nodes": nodes,
                    "edges": edges,
                    "stages": stages,
                }
            }
        except Exception as e:
            logger.warning(f"Failed to build DAG event: {e}")
            return None
    
    def _build_dag_event_from_todo(self) -> Optional[Dict[str, Any]]:
        """
        Build a DAG visualization event from the current MarkovianTODO state.
        
        🔴 A-TEAM AUDIT FIX: Re-emit DAG after dynamic TODO updates
        (adaptation, replan, task completion) so the frontend stays in sync.
        
        Falls back to stored _task_dag if available.
        """
        # First try building from the stored TaskDAG (preserves original structure)
        if hasattr(self, '_task_dag') and self._task_dag:
            # 🔴 A-TEAM: Sync ALL mutable fields from TODO → TaskDAG for accurate rendering
            for task_id, dag_task in self._task_dag.tasks.items():
                if task_id in self.todo.subtasks:
                    todo_task = self.todo.subtasks[task_id]
                    dag_task.status = todo_task.status
                    if hasattr(todo_task, 'actor'):
                        dag_task.actor = todo_task.actor
                    if hasattr(todo_task, 'attempts'):
                        dag_task.attempts = todo_task.attempts
                    if hasattr(todo_task, 'test_status'):
                        dag_task.test_status = todo_task.test_status
            # Also add any NEW tasks in TODO that don't exist in the original DAG
            for task_id, todo_task in self.todo.subtasks.items():
                if task_id not in self._task_dag.tasks:
                    # Create a lightweight task object for the DAG
                    self._task_dag.tasks[task_id] = todo_task
            return self._build_dag_event(self._task_dag)
        
        # Fallback: build DAG-like structure from TODO state
        try:
            nodes = []
            edges = []
            for task_id, task in self.todo.subtasks.items():
                status_val = task.status.value if hasattr(task.status, 'value') else str(task.status)
                nodes.append({
                    "id": task_id,
                    "name": str(task.description)[:60],
                    "status": status_val,
                    "type": "action",
                    "depends_on": list(task.depends_on) if hasattr(task, 'depends_on') and task.depends_on else [],
                    # 🔴 A-TEAM: Enriched node data for beautiful DAG
                    "actor": getattr(task, 'actor', None),
                    "attempts": getattr(task, 'attempts', 0),
                    "max_attempts": getattr(task, 'max_attempts', 5),
                    "priority": getattr(task, 'priority', 0.5),
                    "failure_count": len(getattr(task, 'failure_reasons', [])),
                    "last_failure": str(task.failure_reasons[-1])[:80] if getattr(task, 'failure_reasons', None) else None,
                })
                for dep_id in (getattr(task, 'depends_on', None) or []):
                    edges.append({"from": dep_id, "to": task_id})
            
            # Compute execution stages via topological sort
            stages = self._compute_dag_stages(nodes, edges)
            
            return {
                "module": "Synapse.core.conductor",
                "message": f"DAG updated: {len(nodes)} tasks, {len(edges)} dependencies, {len(stages)} stages",
                "type": "dag",
                "data": {
                    "nodes": nodes,
                    "edges": edges,
                    "stages": stages,
                }
            }
        except Exception as e:
            logger.warning(f"Failed to build DAG event from TODO: {e}")
            return None
    
    def _compute_dag_stages(self, nodes: List[Dict], edges: List[Dict]) -> List[List[str]]:
        """
        Compute execution stages (layers) via topological sort for DAG visualization.
        Tasks with no unresolved dependencies go in the earliest stage.
        """
        try:
            node_ids = {n['id'] for n in nodes}
            # Build adjacency + in-degree
            in_degree = {nid: 0 for nid in node_ids}
            children = {nid: [] for nid in node_ids}
            for edge in edges:
                if edge['from'] in node_ids and edge['to'] in node_ids:
                    in_degree[edge['to']] = in_degree.get(edge['to'], 0) + 1
                    children[edge['from']].append(edge['to'])
            
            # BFS layers
            stages = []
            ready = [nid for nid, deg in in_degree.items() if deg == 0]
            while ready:
                stages.append(sorted(ready))
                next_ready = []
                for nid in ready:
                    for child in children.get(nid, []):
                        in_degree[child] -= 1
                        if in_degree[child] == 0:
                            next_ready.append(child)
                ready = next_ready
            
            # Add orphans (no edges at all) to first stage if missing
            all_staged = {nid for stage in stages for nid in stage}
            orphans = [nid for nid in node_ids if nid not in all_staged]
            if orphans:
                if stages:
                    stages[0].extend(orphans)
                else:
                    stages.append(orphans)
            
            return stages
        except Exception:
            # Fallback: all in one stage
            return [[n['id'] for n in nodes]]
    
    def run_sync(
        self,
        goal: str,
        max_iterations: int = 100,
        target_reward: float = 1.0,
        output_dir: Optional[str] = None,
        **kwargs
    ) -> SwarmResult:
        """
        Synchronous wrapper for run().
        
        Handles asyncio automatically - works in both sync and async contexts.
        
        Returns:
            SwarmResult with typed outputs
        """
        try:
            loop = asyncio.get_running_loop()
            # Already in async context - can't use asyncio.run()
            logger.warning("⚠️  run_sync() called from async context! Use await run() instead.")
            # Create a task and return it (caller must await)
            return asyncio.create_task(self.run(goal, max_iterations, target_reward, output_dir, **kwargs))
        except RuntimeError:
            # No running loop - create one
            return asyncio.run(self.run(goal, max_iterations, target_reward, output_dir, **kwargs))
    
    async def run(
        self, 
        goal: str, 
        max_iterations: int = 100,
        target_reward: float = 1.0,
        output_dir: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[Dict[str, Any], SwarmResult]:
        """
        Run the swarm until goal achieved or max iterations.
        
        Explores and retries until all Auditors pass (full reward).
        
        Args:
            goal: High-level goal to achieve
            max_iterations: Max iterations
            target_reward: Target reward to achieve
            output_dir: Directory for persistence
            **kwargs: Additional context
        
        Returns:
            SwarmResult with typed outputs and metadata
        """
        self.episode_count += 1
        start_time = time.time()
        self._run_start_time = start_time  # Track start time for logging/diagnostics (not used for termination)
        
        # 🔴 A-TEAM: Reset episode trajectory for n-step backward Q-propagation
        if hasattr(self, 'q_predictor') and self.q_predictor and hasattr(self.q_predictor, 'start_new_episode'):
            self.q_predictor.start_new_episode()
        
        logger.info(f"{'='*80}")
        yield {"module": "Synapse.core.conductor", "message": "I am starting a new execution episode"}
        logger.info(f"🚀 RUN: Conductor | episode={self.episode_count} | "
                   f"goal_length={len(goal)} | max_iterations={max_iterations} | "
                   f"target_reward={target_reward}")
        yield {"module": "Synapse.core.conductor", "message": f"I am running the conductor with goal length {len(goal)} and max iterations {max_iterations}"}
        logger.info(f"{'='*80}")
        logger.info(f"⏱️ [CONDUCTOR RUN START] Conductor.run | episode={self.episode_count} | goal_length={len(goal)}")
        yield {"module": "Synapse.core.conductor", "message": f"I am starting conductor run for episode {self.episode_count}"}
        logger.debug(f"  Goal: {goal[:200]}{'...' if len(goal) > 200 else ''}")
        logger.debug(f"  Additional kwargs: {list(kwargs.keys())}")
        
        # ⏰ Timeout warning manager - REMOVED
        # No timeout warnings or enforcement - LLM has freedom to execute
        
        # 🔥 A-TEAM: Start async Q-Learning updater for non-blocking background updates
        if self.async_q_updater:
            await self.async_q_updater.start()
            logger.info("🔥 ASYNC_Q_LEARNING: Started background updater for non-blocking Q-table updates")
            yield {"module": "Synapse.core.conductor", "message": "Started async Q-learning updater"}

        # Load dynamic skills index once per run so actors can discover reusable skills.
        if self.skill_registry:
            try:
                await self.skill_registry.load()
                approved = await self.skill_registry.list_skills(status="approved")
                logger.info(f"🧠 Dynamic skills loaded | approved={len(approved)}")
                yield {"module": "Synapse.core.conductor", "message": f"I loaded {len(approved)} approved dynamic skills for this run."}
                # 🔴 A-TEAM FIX: Check for stale skills that need revalidation.
                # Without this, approved skills with expired revalidation windows
                # remain in use without any quality assurance check.
                stale = await self.skill_registry.get_skills_needing_revalidation()
                if stale:
                    stale_names = [s.name for s in stale[:10]]
                    logger.warning(f"⚠️ {len(stale)} skills need revalidation: {stale_names}")
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"I detected {len(stale)} skills needing revalidation: {', '.join(stale_names[:5])}.",
                    }
            except Exception as _skills_load_err:
                logger.warning(f"⚠️ Failed to load dynamic skills: {_skills_load_err}")
                yield {"module": "Synapse.core.conductor", "message": f"I could not load dynamic skills: {_skills_load_err}"}
        
        # 🤖 EMIT agents_list event — all registered actors + internal agents for frontend panel
        agents_for_frontend = []
        for name, cfg in self.actors.items():
            agents_for_frontend.append({"name": name, "type": "actor", "enabled": cfg.enabled})
        # Add internal agents (architect, auditor, task planner, etc.)
        internal_agents = [
            {"name": "Conductor", "type": "orchestrator"},
            {"name": "Architect", "type": "internal"},
            {"name": "Auditor", "type": "internal"},
            {"name": "TaskBreakdownAgent", "type": "internal"},
            {"name": "TodoCreatorAgent", "type": "internal"},
        ]
        if hasattr(self, 'task_coverage_checker') and self.task_coverage_checker:
            internal_agents.append({"name": "TaskCoverageChecker", "type": "internal"})
        if hasattr(self, 'q_predictor') and self.q_predictor:
            internal_agents.append({"name": "QPredictor", "type": "internal"})
        agents_for_frontend.extend(internal_agents)
        yield {
            "module": "Synapse.core.conductor",
            "message": f"Registered {len(agents_for_frontend)} agents ({len(self.actors)} actors + {len(internal_agents)} internal)",
            "type": "agents_list",
            "data": {"agents": agents_for_frontend}
        }
        
        # ─── Adaptive Actor Timeout (Item C1) ────────────────────────────
        # 0.0 means "adaptive": the system learns from observed latencies.
        # Actors are LLM systems whose runtime depends on input size, output
        # length, gateway latency, retries, and task complexity.  Hard deadlines
        # kill legitimate long-running tasks.  We rely on:
        #   1. AdaptiveTimeout (percentile-based, learns per-operation)
        #   2. StuckDetector   (pattern-based, catches loops)
        # Instead of a single hard number, we keep a generous ceiling and let
        # the adaptive layer provide real guidance.
        raw_actor_timeout = getattr(self.config, 'actor_timeout', 0.0)
        actor_timeout = raw_actor_timeout if raw_actor_timeout > 0 else 900.0  # fallback ceiling
        self.actor_timeout_overrides = {}  # Populated by adaptive timeout later
        if raw_actor_timeout <= 0:
            logger.info("⏱️  Actor timeout is ADAPTIVE (no hard deadline; StuckDetector + AdaptiveTimeout govern)")
        else:
            logger.info(f"⏱️  Actor timeout set to {actor_timeout}s (user-configured)")

        # ✅ Ensure we always have an output directory when persistence/logging is enabled.
        # This keeps RUN_DIR non-null and standardizes artifacts under ./outputs/run_YYYYMMDD_HHMMSS/
        if output_dir is None:
            try:
                base = getattr(self.config, "output_base_dir", "./outputs")
                create_run = getattr(self.config, "create_run_folder", True)
                if create_run:
                    ts = datetime.now().strftime("run_%Y%m%d_%H%M%S")
                    output_dir = str(Path(base) / ts)
                else:
                    output_dir = str(Path(base))
            except Exception:
                output_dir = "./outputs"
        
        # 🔥 A-TEAM FIX: Add goal to kwargs so it's available for parameter resolution
        # This allows parameter_mappings like "input.goal" to work
        kwargs['goal'] = goal
        kwargs['query'] = goal  # Alias
        
        # 🔥 A-TEAM CRITICAL FIX: Store goal + current date/time in SharedContext for ALL actors
        if hasattr(self, 'shared_context') and self.shared_context:
            # Store goal/query
            shared_ctx_start = time.time()
            self.shared_context.set('goal', goal)
            self.shared_context.set('query', goal)  # Also map to 'query' for first actor
            shared_ctx_duration = time.time() - shared_ctx_start
            logger.info(f"📝 SHARED_CONTEXT: Stored 'goal' and 'query' | "
                       f"goal_preview='{goal[:100]}...' | duration={shared_ctx_duration:.3f}s")
            yield {"module": "Synapse.core.conductor", "message": "I have stored the goal and query in shared context"}
            
            # 🔥 A-TEAM: Store current date/time for ALL agents (prevents date hallucinations!)
            try:
                from zoneinfo import ZoneInfo
                current_dt = datetime.now(ZoneInfo("Asia/Kolkata"))
                current_date = current_dt.strftime("%Y-%m-%d")
                current_datetime = current_dt.strftime("%Y-%m-%d %H:%M:%S")
                
                self.shared_context.set('current_date', current_date)
                self.shared_context.set('current_datetime', current_datetime)
                logger.info(f"✅ Stored current_date={current_date}, current_datetime={current_datetime}")
                yield {"module": "Synapse.core.conductor", "message": f"I have stored the current date and time: {current_date}, {current_datetime}"}
            except Exception:
                # Fallback to basic datetime if zoneinfo not available
                current_dt = datetime.now()
                current_date = current_dt.strftime("%Y-%m-%d")
                current_datetime = current_dt.strftime("%Y-%m-%d %H:%M:%S")
                
                self.shared_context.set('current_date', current_date)
                self.shared_context.set('current_datetime', current_datetime)
                logger.info(f"✅ Stored current_date={current_date}, current_datetime={current_datetime} (UTC)")
                yield {"module": "Synapse.core.conductor", "message": f"I have stored the current date and time in UTC: {current_date}, {current_datetime}"}
                logger.warning("⚠️  Could not import zoneinfo, using UTC")
        
        # 🎯 PHASE 1: Proactive Metadata Fetch (if fetcher available)
        if self.metadata_fetcher and hasattr(self.metadata_fetcher, 'fetch'):
            logger.info("=" * 80)
            logger.info("🎯 PHASE 1: Direct Metadata Fetch (NO ReAct guessing!)")
            logger.info("=" * 80)
            
            try:
                # 🔥 A-TEAM CRITICAL FIX (User Insight): Just call ALL metadata methods directly!
                # NO ReAct agent, NO guessing, NO missing data!
                # User question: "Why is react agent fetching when it's already in metadata manager?"
                # Answer: YOU'RE RIGHT! We should just call them directly!
                fetched_data = self._fetch_all_metadata_directly()
                
                # 🔥 A-TEAM FIX: Store metadata in SEPARATE namespace to avoid confusion with actor outputs!
                # Metadata = Reference data (for context/prompts)
                # Actor outputs = Execution data (for parameter flow)
                self.shared_context.set('metadata', fetched_data)
                
                logger.info(f"✅ Fetched and stored {len(fetched_data)} metadata items in SharedContext['metadata']")
                yield {"module": "Synapse.core.conductor", "message": f"I have fetched and stored {len(fetched_data)} metadata items"}
                logger.info(f"   Keys: {list(fetched_data.keys())}")
                yield {"module": "Synapse.core.conductor", "message": f"I found metadata keys: {', '.join(list(fetched_data.keys())[:5])}"}
                
                # 🔥 A-TEAM CRITICAL FIX: ENRICH BUSINESS TERMS WITH PARSED FILTERS!
                # This bridges metadata (context) with parameter flow (actor inputs)
                self._enrich_business_terms_with_filters(fetched_data)
            except Exception as e:
                logger.warning(f"⚠️  Metadata fetch failed: {e}")
                logger.warning("   Continuing without proactive metadata fetch")
                import traceback
                traceback.print_exc()
            
            logger.info("=" * 80)
        
        # Initialize persistence manager (NO HARDCODING - takes output_dir dynamically)
        if output_dir and not self.persistence_manager:
            # Use config.synapse_data_root as the stable global base directory.
            # This ensures Q-values, memories, and skills persist across sessions
            # in a predictable location (<uv>/synapse_data/) rather than a
            # run-specific output path that changes every session.
            global_base_dir = getattr(self.config, 'synapse_data_root', '') or None
            if not global_base_dir:
                # Fallback: derive from output_dir (legacy behavior)
                run_path = Path(output_dir)
                global_base_dir = str(run_path.parent / "global")
                logger.warning(
                    f"⚠️ config.synapse_data_root was empty — Vault falling back to "
                    f"run-derived global path: {global_base_dir}. "
                    f"This means data will NOT persist across sessions to synapse_data/."
                )
            else:
                logger.info(f"✅ Vault will use stable synapse_data_root: {global_base_dir}")
            
            self.persistence_manager = Vault(
                base_output_dir=output_dir,
                auto_save_interval=getattr(self.config, 'save_interval', 1),
                global_base_dir=global_base_dir
            )
            # 🔧 Set config.synapse_dir so EnvironmentManager uses the correct path (run-specific)
            self.config.synapse_dir = self.persistence_manager.run_synapse_dir
            
            # 🔧 Update EnvironmentManager's path if it was already initialized (run-specific)
            if self.env_manager:
                old_env_file = self.env_manager.env_file
                new_env_dir = self.persistence_manager.run_synapse_dir / "env"
                self.env_manager.env_dir = new_env_dir
                self.env_manager.env_file = new_env_dir / "env.md"
                
                # Migrate existing env.md if it exists at the old location
                if old_env_file.exists() and old_env_file != self.env_manager.env_file:
                    new_env_dir.mkdir(parents=True, exist_ok=True)
                    import shutil
                    shutil.copy2(old_env_file, self.env_manager.env_file)
                    logger.info(f"♻️ Migrated environment file from {old_env_file} to {self.env_manager.env_file}")
                else:
                    new_env_dir.mkdir(parents=True, exist_ok=True)
                
                logger.info(f"🔧 Updated EnvironmentManager path: {self.env_manager.env_file}")
            
            logger.info(f"💾 Persistence enabled: {output_dir}/synapse_state/")
            yield {"module": "Synapse.core.conductor", "message": f"I have enabled persistence at {output_dir}/synapse_state/"}
        
        # 🔴 A-TEAM FIX: Load persisted state NOW (after Vault creation, not in __init__)
        # Previously this was in __init__ where persistence_manager didn't exist yet
        try:
            if hasattr(self, 'test_aggregator') and self.test_aggregator:
                self.persistence_manager.load_test_aggregator(self.test_aggregator)
            if hasattr(self, 'reward_calculator') and self.reward_calculator:
                self.persistence_manager.load_user_feedback(self.reward_calculator)
            logger.info("✅ Loaded persisted Bayesian & user feedback state")
        except Exception as e:
            logger.debug(f"Persisted state load skipped: {e}")
        
        # 🔴 A-TEAM FIX: Load Q-learning state from persistence
        # Without this, Q-table values, experience buffer, agentic tag index,
        # and all meta-learning state are LOST on restart — the system never
        # benefits from previous sessions' learned strategies and pitfalls.
        try:
            if hasattr(self, 'q_predictor') and self.q_predictor:
                loaded = self.persistence_manager.load_q_predictor(self.q_predictor)
                if loaded:
                    q_size = len(self.q_predictor.Q) if hasattr(self.q_predictor, 'Q') else 0
                    buf_size = len(self.q_predictor.experience_buffer) if hasattr(self.q_predictor, 'experience_buffer') else 0
                    logger.info(f"✅ Q-Predictor state restored: {q_size} Q-entries, {buf_size} experiences")
                    yield {"module": "Synapse.core.conductor", "message": f"I restored Q-learning state: {q_size} Q-table entries, {buf_size} experience buffer entries"}
                else:
                    logger.info("ℹ️ No previous Q-learning state found — starting fresh")
        except Exception as e:
            logger.debug(f"Q-predictor state load skipped: {e}")
        
        # 🔴 A-TEAM FIX: Restore MARL state from persistence via Vault method
        # Uses persistence_manager.load_marl_state which reads from the correct
        # path (global_synapse_dir / "marl" / "trajectory_predictor.json")
        # and also restores divergence memory if available.
        try:
            if hasattr(self, 'trajectory_predictor') and self.trajectory_predictor:
                marl_state = self.persistence_manager.load_marl_state(self.config)
                
                # Restore trajectory predictor learned patterns & agent models
                if marl_state.get('trajectory_predictor_data'):
                    restored = LLMTrajectoryPredictor.from_dict(
                        marl_state['trajectory_predictor_data'], self.config
                    )
                    # Transfer learned state to existing instance (preserves references)
                    self.trajectory_predictor.learned_patterns = restored.learned_patterns
                    self.trajectory_predictor.agent_models = restored.agent_models
                    self.trajectory_predictor._consolidated_insights = getattr(
                        restored, '_consolidated_insights', []
                    )
                    self.trajectory_predictor.horizon = restored.horizon
                    logger.info(
                        f"🔮 MARL trajectory predictor restored: "
                        f"{len(self.trajectory_predictor.learned_patterns)} patterns, "
                        f"{len(self.trajectory_predictor.agent_models)} agent models"
                    )
                
                # Restore divergence memory entries
                if (marl_state.get('divergence_data') and 
                        hasattr(self, 'divergence_memory') and self.divergence_memory):
                    div_entries = marl_state['divergence_data'].get('memories', [])
                    for entry in div_entries:
                        # Reconstruct lightweight Divergence objects from persisted data
                        # PredictedTrajectory fields: horizon, steps, predicted_reward, confidence
                        # ActualTrajectory fields: steps, actual_reward
                        div = Divergence(
                            predicted=PredictedTrajectory(
                                horizon=0,
                                steps=[],
                                predicted_reward=entry.get('predicted_reward', 0.0),
                                confidence=0.0
                            ),
                            actual=ActualTrajectory(
                                steps=[],
                                actual_reward=entry.get('actual_reward', 0.0)
                            ),
                            action_divergence=entry.get('action_divergence', 0.0),
                            state_divergence=entry.get('state_divergence', 0.0),
                            reward_divergence=entry.get('reward_divergence', 0.0),
                            information_content=entry.get('information_content', 0.0),
                            learning=entry.get('learning', '')
                        )
                        self.divergence_memory.store(div)
                    logger.info(
                        f"🔮 Divergence memory restored: {len(div_entries)} entries"
                    )
        except Exception as e:
            logger.debug(f"MARL state restore skipped: {e}")
        
        # 🔴 A-TEAM FIX: Load persisted memories (shared + per-actor)
        # Without this, all episodic, semantic, procedural, meta, and causal memories
        # from previous sessions are LOST — the system cannot recall past experiences,
        # learned patterns, or accumulated wisdom.
        try:
            if self.config.enable_memory and hasattr(self, 'persistence_manager') and self.persistence_manager:
                # Load shared memory
                loaded_shared = self.persistence_manager.load_memory("shared", self.config)
                if loaded_shared:
                    self.shared_memory = loaded_shared
                    logger.info("✅ Shared memory restored from persistence")
                    yield {"module": "Synapse.core.conductor", "message": "I restored shared memory from persistence"}
                
                # Load per-actor local memories
                for actor_name in list(self.local_memories.keys()):
                    loaded_local = self.persistence_manager.load_memory(actor_name, self.config)
                    if loaded_local:
                        self.local_memories[actor_name] = loaded_local
                        logger.info(f"✅ Local memory for '{actor_name}' restored from persistence")
        except Exception as e:
            logger.debug(f"Memory state restore skipped: {e}")
        
        # Restore TODO if available and configured
        restored = False
        if self.persistence_manager and getattr(self.config, 'auto_load_on_start', False):
            try:
                todo_data = self.persistence_manager.load_markovian_todo()
                if todo_data and todo_data.get('root_task') == goal:
                    self.todo = MarkovianTODO.from_dict(todo_data)
                    restored = True
                    logger.info("♻️ Restored MarkovianTODO from persistence")
                    yield {"module": "Synapse.core.conductor", "message": "I have restored the MarkovianTODO from persistence"}
            except Exception as e:
                logger.debug(f"TODO restore skipped: {e}")

        if not restored:
            # Set root goal
            self.todo.root_task = goal
            # Initialize TODO from goal (it's an async generator, so iterate over it)
            async for event in self._initialize_todo_from_goal_stream(goal, kwargs):
                yield event

        # 🔴 A-TEAM FIX: Sync DAG immediately after TODO initialization
        # Previously DAG was only populated on the first iteration of the main loop.
        # This ensures the dependency graph is ready before any pre-execution steps
        # (e.g., research phase) that might need to query task dependencies.
        if self.todo.subtasks:
            logger.info(f"🔗 Syncing DependencyGraph with {len(self.todo.subtasks)} TODO tasks (post-init)")
            yield {"module": "Synapse.core.conductor", "message": f"I am syncing the dependency graph with {len(self.todo.subtasks)} tasks after initialization"}
            async for event in self._sync_todo_with_dep_graph_stream():
                yield event

        # 📋 CRITICAL: Emit initial task_list event for the frontend
        # Without this, the UI never gets the initial task list and shows "0/0" forever.
        _initial_tl = self._build_task_list_event()
        if _initial_tl:
            logger.info(f"📋 [INITIAL TASK_LIST] Emitting initial task list to frontend: {len(self.todo.subtasks)} tasks")
            yield _initial_tl
        
        # Store TODO summary in SharedContext for global access
        if hasattr(self, 'shared_context') and self.shared_context:
            try:
                self.shared_context.set('todo_state', self.todo.get_state_summary())
            except Exception as e:
                logger.debug(f"TODO summary unavailable for SharedContext: {e}")
        
        # 🌍 Track execution start in environment
        if self.env_manager:
            try:
                async for event in self.env_manager.add_to_current_env_stream(f"🚀 Starting new execution | Goal: {goal[:200]}{'...' if len(goal) > 200 else ''}"):
                    yield event
                async for event in self.env_manager.add_to_current_env_stream(f"📊 Configuration: {len(self.actors)} actors available"):
                    yield event
            except Exception as e:
                logger.warning(f"Failed to track start in environment: {e}")
                yield {"module": "Synapse.core.conductor", "message": f"I encountered a warning while tracking start in environment: {str(e)}"}
        
        # 🤝 NEW: Pre-execution research phase (generic, domain-agnostic)
        async for event in self._run_pre_execution_research_stream(goal, kwargs):
            yield event
        
        # Build initial context
        self.context_guard.clear()
        self.context_guard.register_critical("ROOT_GOAL", goal)
        self.context_guard.register_critical("TODO_STATE", self.todo.get_state_summary())
        
        # Reset collaboration round-trip counters for this run
        self._collaboration_roundtrips = {}
        
        # 🔴 A-TEAM FIX: Accumulate per-agent predictions for Nash bargaining credit assignment.
        # Previously, only _last_prediction (single) was stored & _last_predictions (typo) was read,
        # meaning assign_credit always received an empty dict, making prediction bonus always 0.0.
        self._agent_predictions: Dict[str, Any] = {}
        
        # Main loop - iterate until all tasks complete or consensus-based abandonment.
        # max_iterations is a generous safety ceiling, NOT a hard stop.
        # When the limit approaches, we invoke TaskAbandonmentConsensus so actors
        # can negotiate whether to continue or gracefully end.
        iteration = 0
        cumulative_reward = 0.0
        all_auditors_passed = False
        _consensus_abandonment_checked = False  # Only check once near the limit
        
        while iteration < max_iterations and not all_auditors_passed:
            iteration += 1
            iteration_start_time = time.time()
            task_start_time = time.time()  # Track task timing (NO HARDCODING)
            
            logger.info(f"{'='*80}")
            yield {"module": "Synapse.core.conductor", "message": f"I am starting iteration {iteration} of {max_iterations}"}
            logger.info(f"🔄 ITERATION {iteration}/{max_iterations} START | "
                       f"cumulative_reward={cumulative_reward:.3f} | "
                       f"all_auditors_passed={all_auditors_passed}")
            yield {"module": "Synapse.core.conductor", "message": f"I have cumulative reward {cumulative_reward:.3f} and all auditors passed: {all_auditors_passed}"}
            logger.info(f"{'='*80}")

            logger.debug(f"  Updating shared_context with TODO state")
            if hasattr(self, 'shared_context') and self.shared_context:
                try:
                    todo_summary = self.todo.get_state_summary()
                    logger.debug(f"    TODO summary length: {len(str(todo_summary))} chars")
                    self.shared_context.set('todo_state', todo_summary)
                    logger.debug(f"    ✅ TODO state updated in shared_context")
                except Exception as e:
                    logger.debug(f"    ⚠️  TODO summary update failed: {e}")
            else:
                logger.debug(f"    No shared_context available")

            # 🧩 Dependency-await support: unblock tasks whose deps are now satisfied
            logger.debug(f"  Checking for unblockable tasks")
            try:
                unblock_start = time.time()
                unblocked = self.todo.unblock_ready_tasks()
                unblock_duration = time.time() - unblock_start
                if unblocked:
                    logger.info(f"  🟢 Unblocked {unblocked} task(s) (dependencies satisfied) | duration={unblock_duration:.3f}s")
                else:
                    logger.debug(f"  No tasks to unblock | duration={unblock_duration:.3f}s")
            except Exception as e:
                logger.debug(f"  ⚠️  Unblock check failed: {e}")
            
            # 🔴 A-TEAM FIX: Check should_replan() EVERY iteration for reactive replanning
            # This handles high failure rates and stuck tasks (NO time-based triggers)
            try:
                needs_replan, replan_reason = self.todo.should_replan()
                if needs_replan:
                    logger.warning(f"🔄 REPLAN TRIGGERED: {replan_reason}")
                    replan_actions = self.todo.replan(observation=replan_reason)
                    if replan_actions:
                        logger.info(f"  📋 Replan actions taken: {replan_actions}")
                        yield {"module": "Synapse.core.conductor", "message": f"Replanning triggered ({replan_reason}): {', '.join(replan_actions[:3])}"}
            except Exception as e:
                logger.debug(f"  ⚠️  Replan check failed: {e}")
            
            # 🎯 A-TEAM GAP #1: Periodic TODO adaptation using AgenticTODOAdapter
            # Every 5 iterations, adapt TODO based on learning
            if iteration % 5 == 0 and iteration > 0:
                logger.info(f"🔄 Periodic TODO adaptation (iteration {iteration})")
                
                # Collect learning insights
                recent_failures = [
                    {
                        'task_id': tid,
                        'description': self.todo.subtasks[tid].description,
                        'failure_reasons': self.todo.subtasks[tid].failure_reasons
                    }
                    for tid in list(self.todo.failed_tasks)[:5]  # Last 5 failures
                    if tid in self.todo.subtasks
                ]
                
                q_learning_insights = {
                    'low_q_tasks': [
                        {'task_id': tid, 'q_value': task.estimated_reward}
                        for tid, task in self.todo.subtasks.items()
                        if task.estimated_reward < 0.3 and task.status == TaskStatus.PENDING
                    ][:3]
                }
                
                # 🔴 A-TEAM FIX: Structure MARL predictions properly for TODO adapter
                marl_predictions = {}
                if self.trajectory_predictor and hasattr(self, '_last_prediction') and self._last_prediction:
                    pred = self._last_prediction
                    marl_predictions = {
                        'predicted_reward': getattr(pred, 'predicted_reward', 0.0),
                        'confidence': getattr(pred, 'confidence', 0.0),
                        'horizon': getattr(pred, 'horizon', 0),
                        'predicted_steps': [
                            {
                                'agent': step.get('agent', 'unknown'),
                                'action': step.get('action', 'unknown'),
                            }
                            for step in getattr(pred, 'steps', [])[:5]  # Limit to 5 steps
                        ]
                    }
                
                # 🔴 A-TEAM FIX: Retrieve brain memory patterns from shared_memory
                # BrainInspiredMemoryManager was removed; use HierarchicalMemory instead
                brain_memory_patterns = []
                try:
                    if hasattr(self, 'shared_memory') and self.shared_memory:
                        # Retrieve semantic-level patterns (learned from past episodes)
                        semantic_patterns = self.shared_memory.retrieve(
                            query=goal,
                            goal=goal,
                            budget_tokens=500,
                            levels=[MemoryLevel.SEMANTIC, MemoryLevel.META],
                            context_hints="TODO adaptation: failure patterns and learned strategies"
                        )
                        brain_memory_patterns = [
                            {'content': str(m), 'level': getattr(m, 'level', 'unknown')}
                            for m in semantic_patterns
                        ] if semantic_patterns else []
                        if brain_memory_patterns:
                            logger.debug(f"  📧 Retrieved {len(brain_memory_patterns)} brain memory patterns for TODO adaptation")
                except Exception as e:
                    logger.debug(f"  ⚠️  Brain memory pattern retrieval failed: {e}")
                
                async for event in self._adapt_todo_with_learning_stream(
                    recent_failures=recent_failures,
                    q_learning_insights=q_learning_insights,
                    marl_predictions=marl_predictions,
                    brain_memory_patterns=brain_memory_patterns
                ):
                    yield event
            
            # Get next task
            logger.info(f"📋 ITERATION {iteration}: Getting next task")
            yield {"module": "Synapse.core.conductor", "message": f"I am getting the next task for iteration {iteration}"}
            logger.debug(f"  Current TODO state: {len(self.todo.subtasks)} total tasks")
            get_task_start = time.time()
            
            # 🎯 A-TEAM GAP #2: Use DynamicDependencyGraph for parallel execution
            # Sync TODO state with dependency graph
            async for event in self._sync_todo_with_dep_graph_stream():
                yield event
            
            # Get ALL ready tasks (not just first one)
            # 🔧 PARALLEL EXECUTION: Use DAG execution stages for parallel task execution
            # 🔴 A-TEAM FIX 31: Pass RL task_scores for priority-based batch selection
            task_scores = {
                tid: t.priority * t.estimated_reward * t.confidence
                for tid, t in self.todo.subtasks.items()
            }
            # 🧠 A-TEAM ENHANCEMENT E4: Dynamic parallel batch sizing
            # Adapt batch size based on recent failure rate and system performance
            base_max_batch = getattr(self.config, 'max_parallel_batch', 10)
            if len(self.trajectory) >= 3:
                recent = self.trajectory[-min(10, len(self.trajectory)):]
                recent_failure_rate = sum(1 for t in recent if not t.get('passed', False)) / len(recent)
                # Reduce parallelism when failure rate is high (conserve resources)
                # Increase when everything is passing (maximize throughput)
                if recent_failure_rate > 0.5:
                    dynamic_batch = max(2, base_max_batch // 3)  # High failures → reduce batch
                elif recent_failure_rate > 0.2:
                    dynamic_batch = max(3, base_max_batch // 2)  # Some failures → moderate batch
                else:
                    dynamic_batch = base_max_batch  # Low failures → full parallelism
                logger.debug(f"📊 Dynamic batch: {dynamic_batch} (failure_rate={recent_failure_rate:.2f}, base={base_max_batch})")
            else:
                dynamic_batch = max(3, base_max_batch // 2)  # Start conservative
            ready_tasks = self.dependency_graph.get_independent_tasks(max_batch=dynamic_batch, task_scores=task_scores)
            
            if ready_tasks and len(ready_tasks) > 1:
                # ✅ PARALLEL EXECUTION ENABLED: Execute multiple independent tasks in parallel
                logger.info(f"  🚀 PARALLEL EXECUTION: {len(ready_tasks)} task(s) ready: {ready_tasks}")
                yield {"module": "Synapse.core.conductor", "message": f"I have identified {len(ready_tasks)} tasks ready for parallel execution"}
                
                tasks_to_execute = [self.todo.subtasks.get(tid) for tid in ready_tasks if tid in self.todo.subtasks]
                tasks_to_execute = [t for t in tasks_to_execute if t]  # Filter None
                
                if len(tasks_to_execute) > 1:
                    # Execute ALL tasks in parallel
                    task = None  # Signal to use parallel execution path
                    parallel_tasks = tasks_to_execute
                else:
                    # Only one valid task, execute normally
                    task = tasks_to_execute[0] if tasks_to_execute else None
                    parallel_tasks = None
            elif ready_tasks:
                # Single task ready, execute normally
                logger.info(f"  ✅ 1 task ready for execution: {ready_tasks[0]}")
                yield {"module": "Synapse.core.conductor", "message": f"I have found 1 task ready for execution: {ready_tasks[0]}"}
                task = self.todo.subtasks.get(ready_tasks[0])
                parallel_tasks = None
            else:
                # Fallback to sequential selection
                task = self.todo.get_next_task()
                parallel_tasks = None
            
            get_task_duration = time.time() - get_task_start
            logger.debug(f"  get_next_task duration: {get_task_duration:.3f}s")
            
            # ============================================================================
            # 🚀 PARALLEL EXECUTION PATH
            # ============================================================================
            if parallel_tasks and len(parallel_tasks) > 1:
                logger.info(f"{'='*80}")
                yield {"module": "Synapse.core.conductor", "message": f"I am starting parallel execution of {len(parallel_tasks)} tasks"}
                # 📡 Dedicated fan-out begin event for UI
                self._event_seq += 1
                yield {
                    "module": "Synapse.core.conductor",
                    "type": "agent_event",
                    "event_type": "fan_out_begin",
                    "event_version": "1.0",
                    "seq": self._event_seq,
                    "data": {
                        "child_count": len(parallel_tasks),
                        "child_ids": [pt.task_id for pt in parallel_tasks],
                        "child_actors": [pt.actor for pt in parallel_tasks],
                    },
                    "message": f"🚀 Fan-out: spawning {len(parallel_tasks)} parallel tasks"
                }
                self._fan_out_count += 1
                logger.info(f"🚀 PARALLEL EXECUTION: Executing {len(parallel_tasks)} tasks simultaneously (fan-out #{self._fan_out_count})")
                logger.info(f"{'='*80}")
                
                # ================================================================
                # 🧬 A-TEAM: PARALLEL SAME-ACTOR DETECTION & SPAWNING
                # When multiple parallel tasks target the same actor, we spawn
                # cloned actor instances to avoid state corruption.
                # Strategy:
                #   - Group tasks by actor name
                #   - First task per actor uses the original instance
                #   - Subsequent tasks get a CLONED actor config with fresh instance
                #   - Each clone has its own execution context (no shared state)
                #   - Results merge back into shared_context by task_id
                # ================================================================
                actor_task_count = {}
                cloned_configs = {}  # task_id -> cloned ActorConfig
                
                for ptask in parallel_tasks:
                    actor_name = ptask.actor
                    actor_task_count[actor_name] = actor_task_count.get(actor_name, 0) + 1
                
                # Log collisions
                collisions = {k: v for k, v in actor_task_count.items() if v > 1}
                if collisions:
                    logger.info(f"🧬 SAME-ACTOR COLLISION DETECTED: {collisions}")
                    yield {"module": "Synapse.core.conductor", "message": f"Detected same-actor parallel tasks: {collisions}. Spawning cloned actor instances for independent execution."}
                    
                    # For each collision, spawn N-1 clones
                    actor_clone_idx = {}  # actor_name -> current clone index
                    for ptask in parallel_tasks:
                        actor_name = ptask.actor
                        if actor_name in collisions:
                            idx = actor_clone_idx.get(actor_name, 0)
                            actor_clone_idx[actor_name] = idx + 1
                            
                            if idx > 0:
                                # Need to clone this actor for parallel execution
                                original_config = self.actors.get(actor_name)
                                if original_config:
                                    cloned = self._clone_actor_config(original_config, clone_id=idx)
                                    if cloned:
                                        cloned_configs[ptask.task_id] = cloned
                                        logger.info(f"  🧬 Spawned clone #{idx} of {actor_name} for task {ptask.task_id}")
                
                # ================================================================
                # 🔒 Item 123: RESOURCE CONFLICT DETECTION
                # Before launching parallel tasks, detect if any pair targets the
                # same external resource (URL domain, file path, service endpoint).
                # If conflicts exist, serialize the conflicting subset while
                # keeping non-conflicting tasks parallel.
                # ================================================================
                def _extract_resource_hints(subtask) -> set:
                    """Extract resource keys from task description for conflict detection.
                    
                    Uses structural parsing (URLs, file paths) plus actor-type grouping
                    to identify resources that cannot safely be accessed concurrently.
                    No hardcoded service name lists — actor type is the semantic proxy
                    for the service being accessed.
                    """
                    hints = set()
                    desc = (subtask.description or "").lower()
                    actor_name = str(getattr(subtask, 'actor', '')).lower()
                    # URL domain extraction (structural parsing, not rule-based)
                    import re as _re
                    for url_match in _re.finditer(r'https?://([^\s/]+)', desc):
                        hints.add(f"url:{url_match.group(1)}")
                    # File path hints (structural parsing)
                    for fpath_match in _re.finditer(r'(?:/[\w.-]+){2,}', desc):
                        hints.add(f"file:{fpath_match.group()}")
                    # Actor-type as resource proxy: tasks using the same actor that
                    # interact with external services share that actor's resource scope.
                    # This replaces the hardcoded service name list.
                    if actor_name:
                        hints.add(f"actor:{actor_name}")
                    return hints
                
                resource_map: Dict[str, list] = {}  # resource_key -> [task_ids]
                for ptask in parallel_tasks:
                    for rkey in _extract_resource_hints(ptask):
                        resource_map.setdefault(rkey, []).append(ptask.task_id)

                # Optional safety mode: serialize browser work to one active browser task.
                if getattr(self.config, "single_browser_mode", False):
                    browser_tasks = [
                        t for t in parallel_tasks
                        if "browser" in str(getattr(t, "actor", "")).lower()
                    ]
                    if len(browser_tasks) > 1:
                        keep_task_id = browser_tasks[0].task_id
                        dropped = [t.task_id for t in browser_tasks[1:]]
                        parallel_tasks = [
                            t for t in parallel_tasks
                            if ("browser" not in str(getattr(t, "actor", "")).lower()) or t.task_id == keep_task_id
                        ]
                        logger.warning(
                            f"🧭 single_browser_mode active: executing browser task {keep_task_id} now, "
                            f"deferring browser tasks {dropped} to next iterations."
                        )
                        yield {
                            "module": "Synapse.core.conductor",
                            "type": "anomaly_alert",
                            "data": {
                                "anomaly_type": "browser_parallel_serialized",
                                "active_browser_task": keep_task_id,
                                "deferred_browser_tasks": dropped,
                                "reason": "single_browser_mode enabled for rendering and VLM reliability",
                            },
                            "message": f"single_browser_mode serialized browser tasks; deferred={dropped}",
                        }
                
                # Recompute resource map after any optional task filtering.
                resource_map = {}
                for ptask in parallel_tasks:
                    for rkey in _extract_resource_hints(ptask):
                        resource_map.setdefault(rkey, []).append(ptask.task_id)
                
                # 🔒 ENFORCED CONFLICT SERIALIZATION
                # For each conflict group (multiple tasks sharing a resource key),
                # keep only the first task and defer the rest to future iterations.
                # Deferred tasks remain PENDING in the TODO and will be picked up
                # by the main loop once their conflict group clears.
                conflicting_resources = {k: v for k, v in resource_map.items() if len(v) > 1}
                if conflicting_resources:
                    logger.warning(f"🔒 RESOURCE CONFLICT detected: {conflicting_resources}")
                    # Determine which tasks to defer: for each conflict group, keep
                    # the first task_id and defer all others.
                    tasks_to_keep = set()
                    tasks_to_defer = set()
                    for rkey, conflicting_ids in conflicting_resources.items():
                        # Keep the first task in the conflict group
                        tasks_to_keep.add(conflicting_ids[0])
                        # Defer the rest
                        for tid in conflicting_ids[1:]:
                            if tid not in tasks_to_keep:
                                tasks_to_defer.add(tid)
                    
                    # Remove deferred tasks from the parallel batch
                    if tasks_to_defer:
                        deferred_list = list(tasks_to_defer)
                        parallel_tasks = [t for t in parallel_tasks if t.task_id not in tasks_to_defer]
                        logger.warning(
                            f"🔒 Serializing {len(deferred_list)} conflicting tasks: {deferred_list}. "
                            f"They remain pending and will execute in future iterations."
                        )
                        yield {
                            "module": "Synapse.core.conductor",
                            "type": "anomaly_alert",
                            "data": {
                                "anomaly_type": "resource_conflict_serialized",
                                "executing_now": [t.task_id for t in parallel_tasks],
                                "deferred_tasks": deferred_list,
                                "conflict_groups": {k: v for k, v in conflicting_resources.items()},
                            },
                            "message": f"🔒 Resource conflict: serialized {len(deferred_list)} tasks to prevent concurrent access. Deferred={deferred_list}",
                        }
                else:
                    logger.info(f"✅ No resource conflicts among {len(parallel_tasks)} parallel tasks")

                # Execute all tasks in parallel with event streaming
                parallel_results = []
                for ptask in parallel_tasks:
                    try:
                        logger.info(f"  📋 Task {ptask.task_id}: {ptask.description[:80]}... | actor={ptask.actor}")
                        
                        # Use cloned config if available, otherwise use original
                        actor_config = cloned_configs.get(ptask.task_id) or self.actors.get(ptask.actor)
                        if not actor_config:
                            logger.error(f"  ❌ Unknown actor for task {ptask.task_id}: {ptask.actor}")
                            self.todo.fail_task(ptask.task_id, f"Unknown actor: {ptask.actor}")
                            _tl = self._build_task_list_event()
                            if _tl:
                                yield _tl
                            continue
                        
                        # Build context (each parallel task gets its OWN context snapshot)
                        context, actor_context_dict, _mem_events = self._build_actor_context(ptask, actor_config)
                        
                        # 🧠 Emit memory retrieval events for frontend Memory panel
                        for _mev in _mem_events:
                            yield _mev
                        
                        # 🔴 A-TEAM FIX: Mark task as started (increments attempts, sets IN_PROGRESS)
                        # This was MISSING for parallel tasks — only sequential path called start().
                        # Without this, attempts stays 0, fail() never triggers max_attempts guard,
                        # and parallel tasks could retry infinitely.
                        ptask.start()
                        logger.info(f"  ✅ Parallel task started | task_id={ptask.task_id} | attempts={ptask.attempts}/{ptask.max_attempts}")
                        task_list_evt = self._build_task_list_event()
                        if task_list_evt:
                            yield task_list_evt
                        
                        task_kwargs = dict(kwargs or {})
                        task_kwargs.setdefault("instance_id", ptask.task_id)
                        task_kwargs.setdefault("_parallel_task_id", ptask.task_id)

                        parallel_results.append((
                            ptask,
                            actor_config,
                            context,
                            task_kwargs,
                            actor_context_dict
                        ))
                    except Exception as e:
                        logger.error(f"  ❌ Failed to prepare task {ptask.task_id}: {e}")
                        self.todo.fail_task(ptask.task_id, str(e))
                        _tl = self._build_task_list_event()
                        if _tl:
                            yield _tl
                
                # Execute all tasks in parallel with real-time event streaming
                if parallel_results:
                    logger.info(f"  ⏳ Executing {len(parallel_results)} tasks in parallel...")
                    yield {"module": "Synapse.core.conductor", "message": f"I am executing {len(parallel_results)} tasks in parallel"}
                    parallel_start = time.time()
                    
                    try:
                        # Create event queues for each task
                        task_queues = {}
                        task_results = {}
                        
                        # Start all tasks as background tasks
                        async def run_task_with_queue(ptask, actor_cfg, ctx, kw, actor_ctx):
                            """Run task and put events in queue."""
                            queue = asyncio.Queue()
                            task_queues[ptask.task_id] = queue
                            result = None
                            
                            # 🔴 A-TEAM FIX: Skip execution if task was already completed
                            # This prevents redundant work when a parallel sibling or 
                            # feedback-routed task has already completed the same goal.
                            if ptask.task_id in self.todo.completed_tasks:
                                logger.info(f"⏭️ [PARALLEL WORKER] Task {ptask.task_id} already completed — skipping execution")
                                await queue.put({
                                    "module": "Synapse.core.conductor",
                                    "message": f"Task {ptask.task_id} already completed — skipping redundant execution",
                                    "_parallel_task_id": ptask.task_id,
                                    "_parallel_actor": ptask.actor
                                })
                                await queue.put(None)
                                return
                            
                            logger.info(f"🔄 [PARALLEL WORKER] Task {ptask.task_id} ({ptask.actor}) starting")
                            try:
                                async for event in self._execute_actor_with_retry(
                                    actor_cfg, ptask, ctx, kw, actor_ctx
                                ):
                                    # Tag events with task_id for multi-agent UI display
                                    if isinstance(event, dict):
                                        event['_parallel_task_id'] = ptask.task_id
                                        event['_parallel_actor'] = ptask.actor
                                    # Put event in queue for streaming
                                    await queue.put(event)
                                    # Extract result from final event
                                    if isinstance(event, dict) and event.get("type") == "result":
                                        result = event.get("result")
                                task_results[ptask.task_id] = result
                                logger.info(f"✅ [PARALLEL WORKER] Task {ptask.task_id} ({ptask.actor}) execution finished")
                            except Exception as e:
                                task_results[ptask.task_id] = e
                                logger.error(f"❌ [PARALLEL WORKER] Task {ptask.task_id} ({ptask.actor}) failed: {e}")
                            finally:
                                # Signal completion
                                logger.info(f"🏁 [PARALLEL WORKER] Task {ptask.task_id} sending completion sentinel (None)")
                                await queue.put(None)
                        
                        # Start all tasks
                        tasks = []
                        for ptask, actor_config, context, kw, actor_ctx in parallel_results:
                            task = asyncio.create_task(
                                run_task_with_queue(ptask, actor_config, context, kw, actor_ctx)
                            )
                            tasks.append((ptask, task))
                        
                        # Stream events from all tasks in real-time
                        active_tasks = set(ptask.task_id for ptask, _ in tasks)
                        _poll_start = time.time()
                        _poll_stall_check = 60  # Log warning every 60s of no events
                        _last_event_time = time.time()
                        _per_child_last_event: Dict[str, float] = {tid: time.time() for tid in active_tasks}
                        _child_dead_threshold = getattr(self.config, 'actor_timeout', 0.0)
                        if _child_dead_threshold <= 0:
                            _child_dead_threshold = 600.0  # 10-min ceiling per child (adaptive system may shorten)
                        logger.info(f"🔄 [PARALLEL POLL] Starting event streaming | active_tasks={active_tasks} | dead_threshold={_child_dead_threshold}s")
                        while active_tasks:
                            _elapsed = time.time() - _poll_start
                            # Stall detection
                            if time.time() - _last_event_time > _poll_stall_check:
                                logger.warning(f"⚠️ [PARALLEL POLL] No events for {time.time() - _last_event_time:.0f}s | active={active_tasks} | elapsed={_elapsed:.0f}s")
                                _last_event_time = time.time()  # Reset to avoid log spam
                            
                            # ─── Item 127: Dead-child detection ─────────────────
                            # If a child hasn't emitted any event for _child_dead_threshold
                            # seconds, mark it dead and remove from active set.
                            for _tid in list(active_tasks):
                                _child_silence = time.time() - _per_child_last_event.get(_tid, time.time())
                                if _child_silence > _child_dead_threshold:
                                    logger.warning(f"💀 [DEAD CHILD] Task {_tid} silent for {_child_silence:.0f}s (>{_child_dead_threshold}s) — marking dead")
                                    active_tasks.discard(_tid)
                                    if _tid not in task_results:
                                        task_results[_tid] = TimeoutError(f"Child task {_tid} unresponsive for {_child_silence:.0f}s")
                                    yield {"module": "Synapse.core.conductor",
                                           "message": f"💀 Parallel child task {_tid} detected as dead (no events for {_child_silence:.0f}s)"}
                            # ────────────────────────────────────────────────────
                            
                            # Check all queues for events
                            for task_id in list(active_tasks):
                                if task_id in task_queues:
                                    queue = task_queues[task_id]
                                    try:
                                        # Non-blocking get with timeout
                                        event = await asyncio.wait_for(queue.get(), timeout=0.1)
                                        if event is None:
                                            # Task completed
                                            active_tasks.discard(task_id)
                                            logger.info(f"✅ [PARALLEL POLL] Task {task_id} signalled completion | remaining={active_tasks}")
                                        else:
                                            _last_event_time = time.time()
                                            _per_child_last_event[task_id] = time.time()
                                            # Yield event to stream
                                            yield event
                                    except asyncio.TimeoutError:
                                        # No event available, continue to next queue
                                        pass
                            
                            # Small delay to prevent busy loop
                            if active_tasks:
                                await asyncio.sleep(0.05)
                        
                        logger.info(f"✅ [PARALLEL POLL] All tasks completed | duration={time.time() - _poll_start:.1f}s")
                        
                        # Wait for all tasks to complete (with grace period for late arrivals)
                        results = []
                        for ptask, task in tasks:
                            try:
                                # Give late-arriving tasks a grace period to finish
                                await asyncio.wait_for(task, timeout=30.0)
                            except asyncio.TimeoutError:
                                logger.warning(f"⏰ [FAN-IN] Task {ptask.task_id} did not finish within grace period")
                                if ptask.task_id not in task_results:
                                    task_results[ptask.task_id] = TimeoutError(f"Task {ptask.task_id} timed out during fan-in grace")
                            except Exception as _task_err:
                                logger.warning(f"⚠️ [FAN-IN] Error awaiting task {ptask.task_id}: {_task_err}")
                                if ptask.task_id not in task_results:
                                    task_results[ptask.task_id] = _task_err
                            
                            result = task_results.get(ptask.task_id)
                            # Item 128: If a dead child later produced a valid (non-error) result,
                            # use it instead of the timeout error. Late-arriving valid outputs
                            # should NOT be discarded.
                            if isinstance(result, TimeoutError) and ptask.task_id in task_results:
                                # Check if the asyncio task actually completed with a real result
                                if task.done() and not task.cancelled():
                                    try:
                                        task.result()  # Trigger any stored exception
                                        # Task completed without error — check if queue has result
                                        actual = task_results.get(ptask.task_id)
                                        if actual is not None and not isinstance(actual, Exception):
                                            logger.info(f"🔄 [FAN-IN LATE] Task {ptask.task_id} late-arrived with valid result — accepting")
                                            result = actual
                                    except Exception:
                                        pass  # Task truly failed
                            results.append(result)
                        
                        parallel_duration = time.time() - parallel_start
                        
                        # ============================================================================
                        # 🎯 A-TEAM FIX: Process results with INDEPENDENT AUDITOR VALIDATION
                        # Each parallel task gets its own auditor check before being marked complete
                        # ============================================================================
                        parallel_passed_count = 0
                        parallel_failed_count = 0
                        
                        for (ptask, actor_config, _, _, _), result in zip(parallel_results, results):
                            if isinstance(result, Exception):
                                logger.error(f"  ❌ Task {ptask.task_id} failed with exception: {result}")
                                self.todo.fail_task(ptask.task_id, str(result))
                                parallel_failed_count += 1
                                
                                # 📋 REAL-TIME UI: Emit task_list after parallel exception failure
                                _tl_exc = self._build_task_list_event()
                                if _tl_exc:
                                    yield _tl_exc
                                
                                # 🌍 Track task failure in environment
                                if self.env_manager:
                                    try:
                                        async for event in self.env_manager.add_to_current_env_stream(
                                            f"❌ Task failed | ID: {ptask.task_id} | Actor: {ptask.actor}\n"
                                            f"   Error: {str(result)[:200]}"
                                        ):
                                            yield event
                                    except Exception as e:
                                        logger.warning(f"Failed to track task failure in environment: {e}")
                                        yield {"module": "Synapse.core.conductor", "message": f"I encountered a warning while tracking task failure: {str(e)}"}
                            else:
                                # ============================================================
                                # 🎯 CRITICAL FIX: Run auditor INDEPENDENTLY for each task
                                # Task is only marked complete if auditor validation passes
                                # ============================================================
                                logger.info(f"🔍 [PARALLEL] Running auditor for task {ptask.task_id}...")
                                yield {"module": "Synapse.core.conductor", "message": f"I am validating parallel task {ptask.task_id} with auditor"}
                                
                                auditor_passed = False
                                auditor_reward = 0.0
                                auditor_feedback = ""
                                
                                try:
                                    async for auditor_event in self._run_auditor_stream(
                                        actor_config,
                                        result,
                                        ptask
                                    ):
                                        # Yield auditor events to UI
                                        if isinstance(auditor_event, dict):
                                            if auditor_event.get("type") == "auditor_result":
                                                auditor_passed = auditor_event.get("passed", False)
                                                auditor_reward = auditor_event.get("reward", 0.0)
                                                auditor_feedback = auditor_event.get("feedback", "")
                                                auditor_strategy = auditor_event.get("strategy", {})  # 🎯 A-TEAM: Strategy
                                            else:
                                                # Yield intermediate validation events
                                                yield auditor_event
                                    
                                    logger.info(f"🔍 [PARALLEL] Auditor result for {ptask.task_id}: passed={auditor_passed}, reward={auditor_reward:.3f}")
                                    yield {"module": "Synapse.core.conductor", "message": f"Auditor validation for {ptask.task_id}: {'PASSED' if auditor_passed else 'FAILED'}"}
                                    
                                except Exception as e:
                                    logger.error(f"❌ [PARALLEL] Auditor failed for {ptask.task_id}: {e}")
                                    yield {"module": "Synapse.core.conductor", "message": f"Auditor error for {ptask.task_id}: {str(e)[:100]}"}
                                    auditor_passed = False
                                    auditor_feedback = f"Auditor error: {e}"
                                
                                # ============================================================
                                # 🎯 DECISION: Mark complete ONLY if auditor passes
                                # ============================================================
                                if auditor_passed:
                                    logger.info(f"  ✅ Task {ptask.task_id} VALIDATED and completed")
                                    
                                    # 🔴 A-TEAM FIX (BUG W): Compute unified reward for parallel
                                    # tasks, matching sequential path quality. Previously used raw
                                    # auditor_reward, missing decomposed reward components.
                                    try:
                                        _p_reward_breakdown = self.reward_calculator.compute_subtask_reward(
                                            task=ptask,
                                            auditor_results={'passed': True, 'reward': auditor_reward, 'feedback': auditor_feedback},
                                            context={
                                                'todo': self.todo,
                                                'trajectory_predictor': self.trajectory_predictor if hasattr(self, 'trajectory_predictor') else None,
                                                'iteration': iteration,
                                            }
                                        )
                                        _p_cooperative_reward = _p_reward_breakdown.total
                                        logger.info(f"📊 Parallel Reward for {ptask.task_id}: {_p_cooperative_reward:.3f} (raw auditor: {auditor_reward:.3f})")
                                    except Exception as _rw_err:
                                        logger.warning(f"⚠️ UnifiedRewardCalculator failed for parallel task {ptask.task_id}: {_rw_err}, using raw auditor_reward")
                                        _p_cooperative_reward = auditor_reward
                                    
                                    self.todo.complete_task(ptask.task_id, result)
                                    parallel_passed_count += 1
                                    cumulative_reward += _p_cooperative_reward
                                    
                                    # 📋 REAL-TIME UI: Emit task_list after parallel complete
                                    _tl_pcomplete = self._build_task_list_event()
                                    if _tl_pcomplete:
                                        yield _tl_pcomplete
                                    
                                    # Store result in shared context (UNIFIED STORAGE)
                                    # 🧬 A-TEAM FIX: Store by TASK_ID (primary) and actor name (secondary)
                                    # For parallel same-actor tasks, task_id is the unique key.
                                    # Actor-name key stores LATEST result (last-writer-wins).
                                    if hasattr(self, 'shared_context') and self.shared_context:
                                        # 1. Store by task_id for direct dependency lookup (always unique)
                                        self.shared_context.set(f'output_{ptask.task_id}', result)
                                        # 2. Store in actor_outputs dict (last-writer-wins for same actor)
                                        actor_outputs = self.shared_context.get('actor_outputs') or {}
                                        actor_outputs[ptask.actor] = result
                                        # 3. Also store under actor_name + task_id for divergent parallel context
                                        actor_outputs[f'{ptask.actor}_{ptask.task_id}'] = result
                                        self.shared_context.set('actor_outputs', actor_outputs)
                                    
                                    # 🔴 A-TEAM FIX: Sync parallel completion to DynamicDependencyGraph
                                    if hasattr(self, 'dependency_graph') and self.dependency_graph:
                                        try:
                                            await self.dependency_graph.mark_completed(ptask.task_id)
                                        except Exception as e:
                                            logger.debug(f"  ⚠️ Failed to mark {ptask.task_id} in dep graph: {e}")
                                    
                                    # 🔴 A-TEAM FIX 33: Propagate Q-value to SubtaskState (parallel path)
                                    alpha = getattr(self.config, 'task_q_learning_rate', 0.3)
                                    old_est = ptask.estimated_reward
                                    ptask.estimated_reward = old_est + alpha * (_p_cooperative_reward - old_est)
                                    ptask.confidence = min(1.0, ptask.confidence + 0.1)
                                    
                                    # 🔴 A-TEAM FIX (BUG W): Update agent selector Q-function
                                    # for parallel tasks — was missing, so parallel outcomes
                                    # never influenced future actor selection.
                                    if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                                        self.enhanced_agent_selector.update(
                                            agent=ptask.actor,
                                            task=ptask,
                                            reward=_p_cooperative_reward
                                        )
                                        logger.debug(f"  📊 Updated agent Q-function (parallel): {ptask.actor} | reward={_p_cooperative_reward:.3f}")
                                    
                                    # 🌍 Track validated success in environment
                                    if self.env_manager:
                                        try:
                                            completion_info = []
                                            completion_info.append(f"✅ **Task VALIDATED and Completed** (Parallel Execution)")
                                            completion_info.append(f"  - Task ID: {ptask.task_id}")
                                            completion_info.append(f"  - Description: {ptask.description}")
                                            completion_info.append(f"  - Actor: {ptask.actor}")
                                            completion_info.append(f"  - Auditor: PASSED (reward={auditor_reward:.3f})")
                                            
                                            result_str = str(result) if result else "No output"
                                            completion_info.append(f"  - Result: {result_str[:500]}")
                                            
                                            total_tasks = len(self.todo.subtasks)
                                            completed_count = len(self.todo.completed_tasks)
                                            completion_info.append(f"  - Progress: {completed_count}/{total_tasks} tasks completed ({completed_count/total_tasks*100:.1f}%)")
                                            
                                            async for event in self.env_manager.add_to_current_env_stream("\n".join(completion_info)):
                                                yield event
                                        except Exception as e:
                                            logger.warning(f"Failed to track validated success: {e}")
                                    
                                    # 📋 REAL-TIME UI UPDATE: Emit updated task list + DAG after parallel completion
                                    task_list_event = self._build_task_list_event()
                                    if task_list_event:
                                        yield task_list_event
                                    dag_update = self._build_dag_event_from_todo()
                                    if dag_update:
                                        yield dag_update
                                else:
                                    # 🎯 A-TEAM: Handle strategy actions for parallel execution
                                    # 🔴 A-TEAM FIX: Use `strategy_action` to avoid shadowing Q-learning `action`
                                    strategy = auditor_strategy if 'auditor_strategy' in locals() else {}
                                    strategy_action = strategy.get("action", "retry" if ptask.attempts < ptask.max_attempts else "stop")
                                    execution_guidance = strategy.get("execution_guidance", {})
                                    
                                    # 🔴 A-TEAM FIX: Record auditor feedback as failure_reason
                                    # (parallel path). synapse_core handles internal retries
                                    # but never populates failure_reasons on the task object.
                                    if not hasattr(ptask, 'failure_reasons'):
                                        ptask.failure_reasons = []
                                    ptask.failure_reasons.append({
                                        "reason": auditor_feedback,
                                        "timestamp": datetime.now().isoformat(),
                                        "actor": ptask.actor,
                                        "confidence": auditor_reward,
                                    })
                                    
                                    if strategy_action == "stop":
                                        self.todo.fail_task(ptask.task_id, f"Auditor validation failed: {smart_truncate(auditor_feedback, max_tokens=125)}")
                                        self.todo.mark_task_permanent_failure(ptask.task_id, execution_guidance.get("why_impossible", "Permanent failure"))
                                        # 📋 REAL-TIME UI: Emit task_list after parallel stop
                                        _tl_pstop = self._build_task_list_event()
                                        if _tl_pstop:
                                            yield _tl_pstop
                                    elif strategy_action in ("pass", "pass_partial"):
                                        # LLM decided this task has sufficient material progress with explicit gaps.
                                        partial_credit = execution_guidance.get("partial_credit", auditor_reward)
                                        try:
                                            partial_credit = float(partial_credit)
                                        except Exception:
                                            partial_credit = auditor_reward
                                        partial_credit = max(0.0, min(1.0, partial_credit))
                                        self.todo.complete_task(ptask.task_id, result, partial_credit)
                                        parallel_passed_count += 1
                                        cumulative_reward += partial_credit
                                        
                                        # 📋 REAL-TIME UI: Emit task_list after parallel pass_partial
                                        _tl_ppartial = self._build_task_list_event()
                                        if _tl_ppartial:
                                            yield _tl_ppartial

                                        # Keep dependency graph and shared outputs aligned for partial/pass decisions too.
                                        if hasattr(self, 'shared_context') and self.shared_context:
                                            self.shared_context.set(f'output_{ptask.task_id}', result)
                                            actor_outputs = self.shared_context.get('actor_outputs') or {}
                                            actor_outputs[ptask.actor] = result
                                            actor_outputs[f'{ptask.actor}_{ptask.task_id}'] = result
                                            self.shared_context.set('actor_outputs', actor_outputs)
                                        if hasattr(self, 'dependency_graph') and self.dependency_graph:
                                            try:
                                                await self.dependency_graph.mark_completed(ptask.task_id)
                                            except Exception as e:
                                                logger.debug(f"  ⚠️ Failed to mark {ptask.task_id} in dep graph: {e}")

                                        unresolved = execution_guidance.get("unresolved_items", [])
                                        yield {
                                            "module": "Synapse.core.conductor",
                                            "message": f"Task {ptask.task_id} accepted by auditor strategy ({strategy_action}). Unresolved: {smart_truncate(str(unresolved), max_tokens=125)}"
                                        }
                                        task_list_event = self._build_task_list_event()
                                        if task_list_event:
                                            yield task_list_event
                                        dag_update = self._build_dag_event_from_todo()
                                        if dag_update:
                                            yield dag_update
                                    elif strategy_action == "retry":
                                        # 🧠 A-TEAM ENHANCEMENT E1: Proactive Q-value-based re-delegation
                                        # Before retrying with same actor, check if a BETTER actor exists
                                        reassigned = False
                                        if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                                            try:
                                                current_q = self.enhanced_agent_selector._get_q_value(
                                                    ptask.actor, 
                                                    self.enhanced_agent_selector._extract_task_features(ptask)
                                                )
                                                # Check all other agents
                                                best_alt_agent = None
                                                best_alt_q = current_q
                                                redelegate_margin = getattr(self.config, 'redelegate_q_margin', 0.15)
                                                for aname in self.actors:
                                                    if aname != ptask.actor:
                                                        alt_q = self.enhanced_agent_selector._get_q_value(
                                                            aname,
                                                            self.enhanced_agent_selector._extract_task_features(ptask)
                                                        )
                                                        if alt_q > best_alt_q + redelegate_margin:
                                                            best_alt_q = alt_q
                                                            best_alt_agent = aname
                                                if best_alt_agent:
                                                    logger.info(f"🔀 Q-VALUE RE-DELEGATION: {ptask.actor} (Q={current_q:.3f}) → {best_alt_agent} (Q={best_alt_q:.3f}) for {ptask.task_id}")
                                                    ptask.actor = best_alt_agent
                                                    reassigned = True
                                            except Exception as e:
                                                logger.debug(f"Q-value re-delegation check failed: {e}")
                                        self.todo.mark_for_retry(ptask.task_id, auditor_feedback, execution_guidance)
                                        if reassigned:
                                            logger.info(f"🔄 Task {ptask.task_id} re-assigned to {ptask.actor} and marked for retry")
                                        # 🔴 A-TEAM FIX: Store retry memory in parallel path
                                        try:
                                            self._store_memory(
                                                content=f"Parallel retry for '{smart_truncate(ptask.description, max_tokens=80)}': {smart_truncate(str(auditor_feedback), max_tokens=150)}",
                                                level=MemoryLevel.EPISODIC,
                                                context={'task_id': ptask.task_id, 'actor': ptask.actor, 'event_type': 'parallel_retry'},
                                                goal=goal, actor_name=ptask.actor, initial_value=0.3, outcome='retry'
                                            )
                                        except Exception:
                                            pass
                                    elif strategy_action == "re_evaluate":
                                        # Note: Re-evaluation in parallel context is deferred to next iteration
                                        logger.info(f"🔄 Task {ptask.task_id} marked for re-evaluation (parallel context)")
                                        self.todo.mark_for_retry(ptask.task_id, auditor_feedback, execution_guidance)
                                    else:
                                        self.todo.fail_task(ptask.task_id, f"Auditor validation failed: {smart_truncate(auditor_feedback, max_tokens=125)}")
                                    
                                    # 📋 REAL-TIME UI: Emit task_list after parallel retry/fail
                                    _tl_pretry = self._build_task_list_event()
                                    if _tl_pretry:
                                        yield _tl_pretry
                                    
                                    parallel_failed_count += 1
                                    
                                    # 🔴 A-TEAM FIX 38: Propagate failure Q-value (parallel path)
                                    alpha = getattr(self.config, 'task_q_learning_rate', 0.3)
                                    old_est = ptask.estimated_reward
                                    ptask.estimated_reward = old_est + alpha * (0.0 - old_est)
                                    ptask.confidence = min(1.0, ptask.confidence + 0.05)
                                    
                                    # 🌍 Track auditor failure in environment
                                    if self.env_manager:
                                        try:
                                            failure_info = []
                                            failure_info.append(f"❌ **Task FAILED Auditor Validation** (Parallel Execution)")
                                            failure_info.append(f"  - Task ID: {ptask.task_id}")
                                            failure_info.append(f"  - Actor: {ptask.actor}")
                                            failure_info.append(f"  - Auditor Feedback: {auditor_feedback[:300]}")
                                            
                                            async for event in self.env_manager.add_to_current_env_stream("\n".join(failure_info)):
                                                yield event
                                        except Exception as e:
                                            logger.warning(f"Failed to track auditor failure: {e}")
                                    
                                    # 🔴 A-TEAM: Re-emit DAG after parallel failure/retry/re-delegation
                                    dag_update = self._build_dag_event_from_todo()
                                    if dag_update:
                                        yield dag_update
                                    task_list_event = self._build_task_list_event()
                                    if task_list_event:
                                        yield task_list_event
                        
                        logger.info(f"{'='*80}")
                        yield {"module": "Synapse.core.conductor", "message": f"Parallel execution complete: {parallel_passed_count} passed, {parallel_failed_count} failed (took {parallel_duration:.2f}s)"}
                        logger.info(f"✅ PARALLEL EXECUTION COMPLETE | {len(parallel_results)} tasks | "
                                  f"passed={parallel_passed_count} | failed={parallel_failed_count} | "
                                  f"duration={parallel_duration:.2f}s")
                        logger.info(f"{'='*80}")
                        
                        # ─── Item 130: Convergence Check for Fan-In Aggregator ────
                        # Validate that the aggregate outcome of parallel batch is acceptable.
                        # If pass ratio is below threshold and tasks remain, emit a warning.
                        _total_parallel = parallel_passed_count + parallel_failed_count
                        _pass_ratio = parallel_passed_count / max(_total_parallel, 1)
                        _convergence_ok = _pass_ratio >= 0.5  # At least 50% should pass
                        if not _convergence_ok and _total_parallel > 1:
                            logger.warning(f"🔻 [FAN-IN CONVERGENCE] Low pass ratio: {_pass_ratio:.2f} ({parallel_passed_count}/{_total_parallel})")
                            yield {
                                "module": "Synapse.core.conductor",
                                "type": "agent_event",
                                "event_type": "fan_in_convergence_warning",
                                "data": {
                                    "pass_ratio": round(_pass_ratio, 3),
                                    "passed": parallel_passed_count,
                                    "failed": parallel_failed_count,
                                    "total": _total_parallel,
                                },
                                "message": f"⚠️ Fan-in convergence warning: only {_pass_ratio:.0%} of parallel tasks passed"
                            }
                        # ──────────────────────────────────────────────────────────

                        # 📡 Dedicated fan-in merge event for UI
                        self._event_seq += 1
                        yield {
                            "module": "Synapse.core.conductor",
                            "type": "agent_event",
                            "event_type": "fan_in_merge",
                            "event_version": "1.0",
                            "seq": self._event_seq,
                            "data": {
                                "passed": parallel_passed_count,
                                "failed": parallel_failed_count,
                                "duration_s": round(parallel_duration, 2),
                                "convergence_ok": _convergence_ok,
                                "pass_ratio": round(_pass_ratio, 3),
                            },
                            "message": f"🔗 Fan-in: merged {parallel_passed_count} passed, {parallel_failed_count} failed in {parallel_duration:.1f}s"
                        }
                        
                        # 🧬 CLEANUP: Delete cloned actor configs to free memory
                        if cloned_configs:
                            logger.info(f"🧬 Cleaning up {len(cloned_configs)} cloned actor instances")
                            cloned_configs.clear()
                        
                        # 🧬 FAN-IN CLEANUP: Destroy spawned browser instances
                        # Each parallel task may have created a BrowserView in Electron.
                        # Emit destroy events so the frontend can release those resources.
                        for ptask_entry in parallel_results:
                            ptask = ptask_entry[0]
                            instance_id = ptask.task_id
                            if instance_id and instance_id != "default":
                                yield {
                                    "type": "browser_command",
                                    "command": "destroy_instance",
                                    "params": {"instance_id": instance_id},
                                    "module": "Synapse.core.conductor",
                                    "message": f"Cleaning up browser instance {instance_id}",
                                }
                                logger.info(f"🧹 Emitted destroy for browser instance: {instance_id}")
                        
                        # 🔴 A-TEAM FIX (E7c): Final consolidated task_list emission after fan-in
                        # Individual task completions emit their own events, but this ensures
                        # the UI has the final accurate state after all parallel tasks resolved.
                        _tl_fanin = self._build_task_list_event()
                        if _tl_fanin:
                            yield _tl_fanin
                        
                        # Continue to next iteration (reward already accumulated per-task)
                        continue
                        
                    except Exception as e:
                        logger.error(f"❌ Parallel execution failed: {e}")
                        # 🔴 A-TEAM FIX: parallel_results contains 5-tuples, not 3-tuples
                        for entry in parallel_results:
                            ptask = entry[0]
                            self.todo.fail_task(ptask.task_id, f"Parallel execution error: {e}")
                        # 🔴 A-TEAM: Re-emit DAG after parallel batch failure
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        task_list_event = self._build_task_list_event()
                        if task_list_event:
                            yield task_list_event
                        # 🧬 CLEANUP: Clear cloned configs on error too
                        if cloned_configs:
                            cloned_configs.clear()
                        continue
            
            # ============================================================================
            # 📍 SEQUENTIAL EXECUTION PATH (original logic)
            # ============================================================================
            if task:
                logger.info(f"  ✅ Task retrieved: {task.task_id} | actor={task.actor} | "
                          f"status={task.status.value} | desc='{task.description[:100]}...'")
            else:
                logger.info(f"  ⚠️  No immediate task available")
            
            if not task and not parallel_tasks:
                # 🎯 A-TEAM FIX: Check if there are still tasks that could become available
                pending_count = sum(1 for t in self.todo.subtasks.values() 
                                   if t.status == TaskStatus.PENDING)
                blocked_count = sum(1 for t in self.todo.subtasks.values() 
                                   if t.status == TaskStatus.BLOCKED)
                in_progress_count = sum(1 for t in self.todo.subtasks.values() 
                                       if t.status == TaskStatus.IN_PROGRESS)
                
                logger.info(f"📋 No immediate tasks. State: pending={pending_count}, blocked={blocked_count}, in_progress={in_progress_count}")
                
                # If there are pending tasks but none can start, their dependencies might not be in completed_tasks
                # Try to unblock them again
                if pending_count > 0:
                    unblocked = self.todo.unblock_ready_tasks()
                    if unblocked > 0:
                        logger.info(f"🔓 Unblocked {unblocked} tasks on retry")
                        continue
                    
                    # Check if pending tasks have dependencies that are completed
                    # This handles the case where completion wasn't properly registered
                    for task_id, t in self.todo.subtasks.items():
                        if t.status == TaskStatus.PENDING:
                            missing_deps = [dep for dep in t.depends_on if dep not in self.todo.completed_tasks]
                            if not missing_deps:
                                logger.info(f"🔄 Found runnable task {task_id} - dependencies satisfied")
                                task = t
                                break
                            else:
                                logger.debug(f"Task {task_id} waiting on: {missing_deps}")
                
                # If still no task, try exploration
                if not task:
                    if self.policy_explorer.should_explore(self.todo):
                        new_tasks = self.policy_explorer.explore(
                            self.todo,
                            self._get_available_actions(),
                            goal
                        )
                        for new_task in new_tasks:
                            # Convert TodoItem to SubtaskState for storage in MarkovianTODO
                            subtask = SubtaskState(
                                task_id=new_task.id,  # TodoItem uses 'id', SubtaskState uses 'task_id'
                                description=new_task.description,
                                actor=new_task.actor,
                                status=TaskStatus.PENDING,
                                priority=new_task.priority,
                                estimated_reward=new_task.estimated_reward,
                                attempts=new_task.attempts,
                                max_attempts=new_task.max_attempts,
                                failure_reasons=new_task.failure_reasons.copy()
                            )
                            self.todo.subtasks[subtask.task_id] = subtask
                        continue
                    else:
                        # 🎯 A-TEAM FIX: Only break if truly no work remaining
                        remaining_work = pending_count + blocked_count + in_progress_count
                        if remaining_work == 0:
                            logger.info("✅ All tasks completed or exhausted - ending loop")
                            break
                        else:
                            logger.warning(f"⚠️ {remaining_work} tasks remain but cannot proceed (pending={pending_count}, blocked={blocked_count})")
                            # Log which tasks are stuck and why
                            for task_id, t in self.todo.subtasks.items():
                                if t.status in [TaskStatus.PENDING, TaskStatus.BLOCKED]:
                                    missing = [d for d in t.depends_on if d not in self.todo.completed_tasks]
                                    logger.warning(f"   Stuck: {task_id} ({t.status.value}) - missing deps: {missing}")
                            break
            
            # 🔥 A-TEAM FIX: Ensure task exists before accessing task.actor
            if not task:
                logger.debug("  ⚠️  No task available for Q-value prediction, continuing to next iteration")
                continue
            
            # 🔴 A-TEAM FIX: Double-check task hasn't been completed since selection
            # (e.g. by a parallel worker or feedback-routed collaborator)
            if task.task_id in self.todo.completed_tasks:
                logger.info(f"⏭️ Skipping task {task.task_id} — already completed (race condition guard)")
                continue
            
            # Predict Q-value for this task
            logger.debug(f"  Step 1: Getting current state for Q-value prediction")
            state_start = time.time()
            state = self._get_current_state(current_subtask=task)
            state_duration = time.time() - state_start
            logger.debug(f"  ✅ State retrieved | state_keys={list(state.keys())} | duration={state_duration:.3f}s")
            
            # 🔴 A-TEAM FIX a4: Enrich action dict with full task context for Q-learning
            action = {
                'actor': task.actor,
                'task': task.description,
                'task_id': task.task_id,
                'priority': task.priority,
                'attempts': task.attempts,
                'max_attempts': task.max_attempts,
            }
            # Add failure history if present (critical for learning)
            if task.failure_reasons:
                action['previous_failures'] = task.failure_reasons[-3:]  # Last 3 failures
            if task.retry_feedback:
                action['retry_feedback'] = [fb.get('feedback', '') for fb in task.retry_feedback[-2:]]
            if task.depends_on:
                action['dependencies'] = task.depends_on
            # ============================================================================
            # 🚀 A-TEAM SPEED FIX: Parallelize Q-prediction + Agent selection
            # These are independent LLM calls that were running sequentially.
            # Q-prediction uses state+action, agent selection uses state+task.
            # Neither depends on the other's output.
            # ============================================================================
            logger.debug(f"  Step 2+3: Parallel Q-prediction & agent selection")
            parallel_start = time.time()
            
            # --- Coroutine 1: Q-value prediction ---
            async def _q_predict():
                return await asyncio.to_thread(
                    self.q_predictor.predict_q_value, state, action, goal
                )
            
            # --- Coroutine 2: Agent selection/verification ---
            async def _agent_select():
                _task_actor = task.actor  # Capture current value
                if _task_actor is None:
                    logger.info("  🔍 Actor unassigned - using EnhancedAgenticAgentSelector...")
                    sel = await asyncio.to_thread(
                        self.enhanced_agent_selector.select_agent,
                        task=task,
                        available_agents=list(self.actors.values()),
                        context=state,
                        exploration=True
                    )
                    return ('assign', sel.agent_name)
                else:
                    logger.debug(f"  🔍 Verifying pre-assigned actor: {_task_actor}")
                    try:
                        sel = await asyncio.to_thread(
                            self.enhanced_agent_selector.select_agent,
                            task=task,
                            available_agents=list(self.actors.values()),
                            context=state,
                            exploration=False
                        )
                        return ('verify', sel, _task_actor)
                    except Exception as e:
                        logger.debug(f"  Q-learning verification failed: {e}, keeping: {_task_actor}")
                        return ('keep', _task_actor)
            
            # Run both in parallel
            q_result, agent_result = await asyncio.gather(_q_predict(), _agent_select())
            
            # Unpack Q-prediction result
            q_value, confidence, alternative = q_result
            parallel_duration = time.time() - parallel_start
            logger.info(f"  ✅ Parallel Q+agent complete | q_value={q_value:.3f} | confidence={confidence:.3f} | "
                       f"duration={parallel_duration:.3f}s")
            
            # 🔥 Record prediction for meta-learning
            predicted_q_value = q_value
            
            # 🔥 Get proactive warnings (cheap, no LLM call)
            if hasattr(self.q_predictor, 'get_proactive_warnings'):
                warnings = self.q_predictor.get_proactive_warnings(state, action)
                if warnings:
                    logger.warning("⚠️ Q-LEARNING PROACTIVE WARNINGS:")
                    for warning in warnings[:5]:
                        logger.warning(f"   ⚡ {warning}")
                    yield {"module": "Synapse.core.conductor", "message": f"Q-learning warns: {warnings[0]}"}
            
            if alternative:
                logger.info(f"  🔄 LLM suggested alternative action: {alternative}")
            
            # Apply agent selection result
            if agent_result[0] == 'assign':
                task.actor = agent_result[1]
                logger.info(f"  ✅ Agent selected: → {task.actor}")
            elif agent_result[0] == 'verify':
                sel_result = agent_result[1]
                original_actor = agent_result[2]
                q_recommended = sel_result.agent_name
                q_sel_confidence = sel_result.confidence if hasattr(sel_result, 'confidence') else 0.5
                try:
                    task_features = self.enhanced_agent_selector._extract_task_features(task)
                    q_assigned = self.enhanced_agent_selector._get_q_value(original_actor, task_features)
                    q_best = self.enhanced_agent_selector._get_q_value(q_recommended, task_features)
                    if q_recommended != original_actor and (q_best - q_assigned) > 0.3 and q_sel_confidence > 0.7:
                        logger.warning(
                            f"  🔄 A-TEAM Q-OVERRIDE: Reassigning {original_actor} → {q_recommended} "
                            f"(Q: {q_assigned:.3f} → {q_best:.3f}, confidence={q_sel_confidence:.3f})"
                        )
                        task.actor = q_recommended
                    else:
                        logger.debug(f"  ✅ Pre-assigned actor confirmed: {task.actor} (Q={q_assigned:.3f})")
                except Exception as e:
                    logger.debug(f"  Q-value comparison failed: {e}, keeping: {task.actor}")
            # else: 'keep' — no change needed
            
            # Validate actor exists
            logger.debug(f"  Step 3b: Getting actor config | actor={task.actor}")
            actor_config = self.actors.get(task.actor)
            if not actor_config:
                logger.error(f"  ❌ Unknown actor: {task.actor} | available_actors={list(self.actors.keys())}")
                self.todo.fail_task(task.task_id, f"Unknown actor: {task.actor}")
                _tl = self._build_task_list_event()
                if _tl:
                    yield _tl
                continue
            logger.debug(f"  ✅ Actor config retrieved: {actor_config.name}")
            
            # ============================================================================
            # 🚀 A-TEAM SPEED FIX: Parallelize trajectory prediction + context building
            # After agent selection resolves (task.actor is final), these two operations
            # are independent: trajectory prediction uses state+actor, context building
            # uses task+actor_config for memory retrieval. Run them concurrently.
            # ============================================================================
            logger.info(f"🔨 Step 4+5: Parallel trajectory prediction + context build for actor={task.actor}")
            phase2_start = time.time()
            
            # --- Coroutine A: Trajectory prediction (MARL) ---
            async def _trajectory_predict():
                if not self.trajectory_predictor:
                    return None
                try:
                    _actor = task.actor
                    _other = [a for a in self.actors.keys() if a != _actor]
                    return await asyncio.to_thread(
                        self.trajectory_predictor.predict,
                        current_state=state,
                        acting_agent=_actor,
                        proposed_action={'task': task.description},
                        other_agents=_other,
                        goal=goal
                    )
                except Exception as e:
                    logger.debug(f"Prediction failed: {e}")
                    return None
            
            # --- Coroutine B: Context building ---
            async def _build_context():
                return await asyncio.to_thread(
                    self._build_actor_context, task, actor_config
                )
            
            self._last_prediction, (context, actor_context_dict, _mem_events) = await asyncio.gather(
                _trajectory_predict(), _build_context()
            )
            
            phase2_duration = time.time() - phase2_start
            
            if self._last_prediction:
                logger.debug(f"🔮 Predicted trajectory: reward={self._last_prediction.predicted_reward:.2f}")
                if task.actor:
                    self._agent_predictions[task.actor] = self._last_prediction
            
            logger.info(f"✅ Parallel trajectory+context complete | "
                       f"context_length={len(context) if isinstance(context, str) else 'N/A'} | "
                       f"actor_context_keys={list(actor_context_dict.keys()) if actor_context_dict else 'None'} | "
                       f"duration={phase2_duration:.3f}s")
            
            # 🧠 Emit memory retrieval events for frontend Memory panel
            for _mev in _mem_events:
                yield _mev
            
            # 🔥 A-TEAM: Inject Q-learning learned context into actor context
            if hasattr(self.q_predictor, 'get_learned_context'):
                try:
                    learned_context = self.q_predictor.get_learned_context(state, action)
                    if learned_context:
                        # Inject into actor_context_dict for parameter resolution
                        if actor_context_dict is None:
                            actor_context_dict = {}
                        actor_context_dict['q_learning_context'] = learned_context
                        
                        # Also prepend to context string
                        context_prefix = f"""## 📚 Q-LEARNING ADVISORY CONTEXT
The following insights were learned from past similar tasks. Consider them but trust your own judgment:

{learned_context}

---
"""
                        if isinstance(context, tuple):
                            context = (context_prefix + context[0], context[1])
                        else:
                            context = context_prefix + str(context)
                        
                        logger.info(f"🧠 Q-LEARNING: Injected {len(learned_context)} chars of learned context")
                except Exception as e:
                    logger.debug(f"Failed to get learned context: {e}")
            
            # 🔥 A-TEAM: Inject trajectory correction if available from previous failure
            if self.shared_context and self.shared_context.get('trajectory_correction'):
                correction = self.shared_context.get('trajectory_correction')
                if actor_context_dict is None:
                    actor_context_dict = {}
                actor_context_dict['trajectory_correction'] = correction
                logger.info(f"🔄 Injected trajectory correction: {correction.get('correction_strategy', 'N/A')}")
            
            # ⏰ Timeout warning injection - REMOVED
            # No timeout warnings or enforcement - LLM has freedom to execute
            
            # Execute actor
            logger.info(f"🎬 EXECUTE_ACTOR: Starting execution | actor={task.actor} | task_id={task.task_id}")
            
            # 🔴 A-TEAM FIX: Emit explicit actor_executing event with _actor_name tag.
            # This allows the frontend to ONLY activate agent UI (including browser layout)
            # when the actor is genuinely executing — NOT on mere text mentions in
            # task lists, agent selection, or Q-learning events.
            yield {
                "type": "actor_executing",
                "module": task.actor,
                "_actor_name": task.actor,
                "message": f"🎬 Starting execution | actor={task.actor} | task_id={task.task_id}",
                "task_id": task.task_id,
            }
            
            # 🔴 A-TEAM FIX: Mark task as started (increments attempts, sets IN_PROGRESS)
            # This was MISSING — conductor never called task.start(), so attempts stayed 0
            # and fail() would never trigger max_attempts guard, creating infinite loops.
            task.start()
            logger.info(f"  ✅ Task started | attempts={task.attempts}/{task.max_attempts}")
            task_list_evt = self._build_task_list_event()
            if task_list_evt:
                yield task_list_evt
            
            try:
                # ✅ Checkpoint before execution (A-Team) — non-blocking I/O
                logger.debug(f"  Creating checkpoint before execution")
                await asyncio.to_thread(self._checkpoint_state, "pre_execute", task)
                logger.debug(f"  ✅ Checkpoint created")
                
                execute_start = time.time()
                logger.info(f"  Calling _execute_actor_with_retry | context_length={len(context[0]) if isinstance(context, tuple) else len(str(context))}")
                result = None
                exec_kwargs = dict(kwargs or {})
                exec_kwargs.setdefault("instance_id", task.task_id)
                async for event in self._execute_actor_with_retry(
                    actor_config,
                    task,
                    context,
                    exec_kwargs,
                    actor_context_dict  # 🔥 Pass actor_context for parameter resolution
                ):
                    # 🔴 A-TEAM FIX: Tag every execution event with _actor_name
                    # so the frontend can accurately identify which agent is running.
                    # Previously, events lacked _actor_name, causing the frontend to
                    # fall back to text scanning which produced false positives.
                    if isinstance(event, dict) and '_actor_name' not in event:
                        event['_actor_name'] = task.actor
                    # Yield all events from actor execution
                    yield event
                    # Extract result from final event
                    if isinstance(event, dict) and event.get("type") == "result":
                        result = event.get("result")
                execute_duration = time.time() - execute_start
                logger.info(f"  ✅ _execute_actor completed | duration={execute_duration:.3f}s | "
                           f"result_type={type(result).__name__ if result is not None else 'None'}")
                
                # Auditor check
                logger.info(f"🔍 RUN_AUDITOR: Starting validation | actor={task.actor}")
                yield {"module": "Synapse.core.conductor", "message": f"I am starting validation for {task.actor}"}
                auditor_start = time.time()
                
                # 🔴 A-TEAM FIX: Initialize auditor_strategy BEFORE the auditor loop
                # Previously, auditor_strategy was only set inside the loop on line 4107,
                # meaning it could be undefined if auditor threw an exception or yielded
                # no "auditor_result" event. This caused the fallback on line 4303 to
                # always default to {"action": "retry"}, creating infinite loops.
                auditor_strategy = {}
                
                # Run auditor and yield events
                auditor_passed, auditor_reward, auditor_feedback = None, 0.0, ""
                async for auditor_event in self._run_auditor_stream(
                    actor_config,
                    result,
                    task
                ):
                    # Yield intermediate events to UI
                    if isinstance(auditor_event, dict):
                        if auditor_event.get("type") == "auditor_result":
                            auditor_passed = auditor_event.get("passed")
                            auditor_reward = auditor_event.get("reward", 0.0)
                            auditor_feedback = auditor_event.get("feedback", "")
                            auditor_strategy = auditor_event.get("strategy", {})  # 🎯 A-TEAM: Strategy
                        else:
                            # Yield test/validation events
                            yield auditor_event
                
                auditor_duration = time.time() - auditor_start
                logger.info(f"✅ RUN_AUDITOR COMPLETE: actor={task.actor} | "
                           f"passed={auditor_passed} | reward={auditor_reward:.3f} | "
                           f"feedback_length={len(auditor_feedback) if auditor_feedback else 0} | "
                           f"duration={auditor_duration:.3f}s")
                yield {"module": "Synapse.core.conductor", "message": f"Validation complete for {task.actor}: passed={auditor_passed}, reward={auditor_reward:.3f}"}
                
                if auditor_passed:
                    # ================================================================
                    # 🎯 A-TEAM UNIFIED REWARD SYSTEM
                    # Quality + Cooperation + Learning + User Feedback
                    # ================================================================
                    
                    # Prepare auditor results for reward calculator
                    _agg = locals().get("aggregated", None)
                    auditor_full_results = {
                        'reward': auditor_reward,
                        'confidence': confidence if 'confidence' in locals() else 0.5,
                        'reasoning': getattr(_agg, 'reasoning', auditor_feedback),
                        'method': getattr(_agg, 'method', 'legacy'),
                        'test_breakdown': getattr(_agg, 'test_breakdown', []),
                    }
                    
                    # Compute unified reward with transparent breakdown
                    reward_breakdown = self.reward_calculator.compute_subtask_reward(
                        task=task,
                        auditor_results=auditor_full_results,
                        context={
                            'todo': self.todo,
                            'trajectory_predictor': self.trajectory_predictor if hasattr(self, 'trajectory_predictor') else None,
                            'iteration': iteration,
                            'state': state,
                            'action': action
                        }
                    )
                    
                    cooperative_reward = reward_breakdown.total
                    
                    # Log reward breakdown for transparency
                    logger.info(f"📊 Reward Breakdown for {task.task_id}:")
                    logger.info(reward_breakdown.explain())
                    
                    # 🧠 Record episode for Bayesian learning (if test results available)
                    if 'aggregated' in locals() and aggregated.test_breakdown:
                        self.test_aggregator.record_episode(
                            test_results=aggregated.test_breakdown,
                            final_quality=cooperative_reward
                        )
                    
                    self.todo.complete_task(task.task_id, {'reward': cooperative_reward})
                    cumulative_reward += cooperative_reward
                    
                    # 📋 REAL-TIME UI: Emit task_list after sequential complete
                    _tl_scomplete = self._build_task_list_event()
                    if _tl_scomplete:
                        yield _tl_scomplete
                    
                    # 🔴 A-TEAM FIX: Store SUCCESS with outcome for pattern extraction
                    # Shannon: -log P(success) = low info, but still valuable for procedural memory
                    # 🧬 Stores in BOTH shared_memory AND local_memories[actor]
                    try:
                        _success_content = f"""✅ SUCCESS (Low Information Event - Store Compactly)
Task: {task.description}
Actor: {task.actor}
Reward: {cooperative_reward:.3f}
Strategy: {smart_truncate(auditor_feedback, max_tokens=75) if auditor_feedback else 'N/A'}"""
                        _success_ctx = {
                            'actor': task.actor,
                            'task': task.task_id,
                            'failure': False,
                            'reward': cooperative_reward
                        }
                        self._store_memory(
                            content=_success_content,
                            level=MemoryLevel.PROCEDURAL,
                            context=_success_ctx,
                            goal=goal,
                            actor_name=task.actor,
                            outcome="success"
                        )
                        # 🧠 Emit memory_update event for frontend
                        yield self._build_memory_update_event(
                            content=f"✅ SUCCESS: {task.description} (reward={cooperative_reward:.3f})",
                            level="procedural", actor=task.actor,
                            context=_success_ctx
                        )
                    except Exception as mem_err:
                        logger.debug(f"Failed to store success in memory: {mem_err}")
                    
                    # 🌍 Track task completion in environment
                    if self.env_manager:
                        try:
                            completion_info = []
                            completion_info.append(f"✅ **Task Completed Successfully**")
                            completion_info.append(f"  - Task ID: {task.task_id}")
                            completion_info.append(f"  - Description: {task.description}")  # Full description
                            completion_info.append(f"  - Actor: {task.actor}")
                            completion_info.append(f"  - Reward: {cooperative_reward:.3f}")
                            completion_info.append(f"  - Auditor Feedback: {auditor_feedback}")  # Full feedback
                            
                            # Add reward breakdown if available
                            if 'reward_breakdown' in locals():
                                completion_info.append(f"  - Quality Score: {reward_breakdown.quality:.2f}")
                                completion_info.append(f"  - Learning Score: {reward_breakdown.learning:.2f}")
                                completion_info.append(f"  - Cooperation Score: {reward_breakdown.cooperation:.2f}")
                            
                            # Add timing info
                            task_duration = time.time() - task_start_time
                            completion_info.append(f"  - Duration: {task_duration:.2f}s")
                            completion_info.append(f"  - Iteration: {iteration}")
                            
                            # Add progress info
                            total_tasks = len(self.todo.subtasks)
                            completed_count = len(self.todo.completed_tasks)
                            completion_info.append(f"  - Progress: {completed_count}/{total_tasks} tasks completed ({completed_count/total_tasks*100:.1f}%)")
                            
                            async for event in self.env_manager.add_to_current_env_stream("\n".join(completion_info)):
                                yield event
                            logger.debug(f"✅ Tracked task completion in environment")
                        except Exception as e:
                            logger.warning(f"⚠️  Failed to track task completion in environment: {e}")
                            yield {"module": "Synapse.core.conductor", "message": f"I encountered a warning while tracking task completion: {str(e)}"}
                    
                    # 🔴 CRITICAL FIX: Update EnhancedAgenticAgentSelector Q-function
                    self.enhanced_agent_selector.update(
                        agent=task.actor,
                        task=task,
                        reward=cooperative_reward
                    )
                    logger.debug(f"  📊 Updated agent Q-function: {task.actor} | reward={cooperative_reward:.3f}")
                    
                    # 🔴 A-TEAM FIX 27: Propagate Q-value back to SubtaskState for RL-driven task selection
                    # TD-like update: estimated_reward ← estimated_reward + α(reward - estimated_reward)
                    alpha = getattr(self.config, 'task_q_learning_rate', 0.3)
                    old_estimate = task.estimated_reward
                    task.estimated_reward = old_estimate + alpha * (cooperative_reward - old_estimate)
                    task.confidence = min(1.0, task.confidence + 0.1)  # Increase confidence with more data
                    logger.debug(f"  📊 Updated SubtaskState Q: {old_estimate:.3f} → {task.estimated_reward:.3f}")
                    
                    # ✅ INCREMENTAL SAVE: Save after first successful task
                    if iteration == 1 and self.persistence_manager:
                        logger.info("💾 Saving initial state after first task completion")
                        self.persistence_manager.save_markovian_todo(self.todo)
                    
                    # ✅ INCREMENTAL SAVE: Save after critical actors complete
                    # 🔴 A-TEAM FIX 29: No hardcoded actor names - save after ANY actor
                    # that has dependencies (i.e., other tasks depend on its output)
                    has_dependents = any(
                        task.task_id in t.depends_on 
                        for t in self.todo.subtasks.values() if t.task_id != task.task_id
                    )
                    if has_dependents and self.persistence_manager:
                        logger.info(f"💾 Saving state after {task.actor} completion (has dependents)")
                        self.persistence_manager.save_markovian_todo(self.todo)
                        if hasattr(self, 'shared_memory') and self.config.enable_memory and self.config.persist_memories:
                            self.persistence_manager.save_memory(self.shared_memory, name="shared")
                    
                    # Record intermediary values (NO HARDCODING - dynamic tracking)
                    task_duration = time.time() - task_start_time
                    self.todo.record_intermediary_values(task.task_id, {  # Fixed: task.id → task.task_id
                        'duration_seconds': task_duration,
                        'reward_obtained': cooperative_reward,
                        'auditor_passed': True,
                        'iteration': iteration,
                        'timestamp': time.time(),
                        'q_value': q_value,
                        'confidence': confidence
                    })
                    
                    # 📋 REAL-TIME UI UPDATE: Emit updated task list + DAG after completion
                    task_list_event = self._build_task_list_event()
                    if task_list_event:
                        yield task_list_event
                    # 🔴 A-TEAM AUDIT FIX: Re-emit DAG with updated statuses
                    dag_update = self._build_dag_event_from_todo()
                    if dag_update:
                        yield dag_update
                    
                    # Record success for learning
                    self.q_predictor.record_outcome(state, action, cooperative_reward)
                    
                    # Store SUCCESS with summary (low info content = less detail)
                    # 🔴 A-TEAM FIX: Use _store_memory to populate BOTH shared + local memories
                    _success_summary = f"✅ {task.description}: {smart_truncate(auditor_feedback, max_tokens=125)}"
                    self._store_memory(
                        content=_success_summary,
                        level=MemoryLevel.SEMANTIC,
                        context={
                            'actor': task.actor,
                            'task': task.task_id,
                            'web_search_context': self.shared_context.get('web_search_context') if self.shared_context else None
                        },
                        goal=goal,
                        actor_name=task.actor,
                        initial_value=getattr(self.config, 'success_memory_weight', 0.7),
                        outcome="success"
                    )
                    # 🧠 Emit memory_update for frontend
                    yield self._build_memory_update_event(
                        content=_success_summary, level="semantic", actor=task.actor,
                        context={'actor': task.actor, 'task': task.task_id}
                    )
                else:
                    # 🎯 A-TEAM: Handle strategy actions (retry/stop/re_evaluate)
                    # 🔴 A-TEAM FIX: Use `strategy_action` to avoid shadowing the Q-learning `action` dict
                    # Previously `action` (the rich Q-learning dict from line ~4584) was overwritten here
                    # with a string like "retry", causing ALL failure Q-entries to record
                    # `ACTOR: retry` instead of the actual task details. This destroyed learning.
                    strategy = auditor_strategy if 'auditor_strategy' in locals() else {}
                    strategy_action = strategy.get("action", "retry" if task.attempts < task.max_attempts else "stop")
                    action_reasoning = strategy.get("reasoning", "")
                    execution_guidance = strategy.get("execution_guidance", {})
                    
                    logger.info(f"🎯 Auditor strategy: action={strategy_action}, reasoning={action_reasoning[:100]}")
                    
                    # 🔴 Record this failure BEFORE rerouting check (synapse_core handles
                    # internal retries but never populates failure_reasons on the task object).
                    if not hasattr(task, 'failure_reasons'):
                        task.failure_reasons = []
                    task.failure_reasons.append(
                        f"[{task.actor}] Auditor rejected: {smart_truncate(auditor_feedback, max_tokens=200)}"
                    )
                    
                    # ================================================================
                    # 🔴 A-TEAM SOTA: LLM-BASED FAILURE REROUTING
                    # Trigger whenever a task has ANY failure history, regardless of auditor
                    # strategy. synapse_core already handled up to 5 internal retries, so
                    # if we're here the task genuinely failed.
                    # Consult LLM to decide: SWITCH_ACTOR | RETRY_SAME | DECOMPOSE | FAIL_PERMANENT
                    #
                    # 🔴 A-TEAM FIX BUG E-2: Previously only triggered when strategy_action
                    # was "retry". If the auditor said "re_evaluate", the failure analyst was
                    # NEVER consulted and the system could not switch actors (e.g., Terminal→
                    # Browser). Now always consulted, and its recommendation can override the
                    # auditor strategy. This is the critical path for actor switching.
                    # ================================================================
                    if hasattr(task, 'failure_reasons') and len(task.failure_reasons) >= 1:
                        # Pure LLM-based rerouting: consult failure analyst on each retry decision.
                        logger.warning(
                            f"🔴 RETRY REVIEW (auditor path): Task {task.task_id} has {len(task.failure_reasons)} failure(s); consulting LLM failure analyst"
                        )
                        yield {
                            "module": "Synapse.core.conductor",
                            "message": f"🔴 Retry review for {task.task_id}: consulting LLM for reroute/retry decision"
                        }

                        # 🧠 Use LLM-based FailureReroutingSignature instead of hardcoded for-loop
                        reroute_result = None
                        if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                            try:
                                # 🔴 A-TEAM FIX: self.actors values are AgentConfig dataclasses, not dicts
                                available_agents_list = [
                                    self.actors[aname] if isinstance(self.actors[aname], AgentConfig)
                                    else AgentConfig(name=aname, capabilities=getattr(self.actors[aname], 'capabilities', []))
                                    for aname in self.actors
                                ]
                                # Pass raw context to LLM — let the FailureReroutingSignature
                                # determine failure type (infrastructure vs logic) from the
                                # auditor feedback. No hardcoded keyword matching.
                                reroute_context = {
                                    'goal': goal,
                                    'iteration': iteration,
                                    'q_value': q_value,
                                    'confidence': confidence,
                                    'total_tasks': len(self.todo.subtasks),
                                    'completed_tasks': len(self.todo.completed_tasks),
                                    'auditor_feedback_summary': smart_truncate(auditor_feedback, max_tokens=300),
                                    'failure_count': len(task.failure_reasons),
                                }
                                async for event in self.enhanced_agent_selector.reroute_on_failure_stream(
                                    task=task,
                                    available_agents=available_agents_list,
                                    failure_history=task.failure_reasons,
                                    context=reroute_context,
                                ):
                                    if isinstance(event, dict) and event.get("type") == "result":
                                        reroute_result = event.get("result")
                                    else:
                                        yield event
                            except Exception as reroute_err:
                                logger.warning(f"⚠️ LLM failure rerouting failed: {reroute_err}")

                        # Apply the rerouting decision
                        if reroute_result:
                            reroute_action = reroute_result.get("action", "FAIL_PERMANENT")
                            reroute_target = reroute_result.get("target_actor", "N/A")
                            reroute_reasoning = reroute_result.get("reasoning", "")

                            if reroute_action == "SWITCH_ACTOR" and reroute_target in self.actors:
                                logger.info(f"  🔀 LLM rerouting: {task.actor} → {reroute_target}")
                                yield {"module": "Synapse.core.conductor", "message": f"LLM decided to switch {task.task_id} from {task.actor} to {reroute_target}: {reroute_reasoning[:100]}"}
                                task.actor = reroute_target
                                task.failure_reasons.clear()  # Reset for new actor
                                # 🔴 A-TEAM FIX BUG E-2: Override strategy to "retry" so the
                                # switched actor gets a fresh attempt instead of the original
                                # strategy (e.g., re_evaluate) re-decomposing with the OLD actor.
                                strategy_action = "retry"
                                action_reasoning = f"LLM rerouted to {reroute_target}: {reroute_reasoning}"
                                # Re-emit DAG after actor switch
                                dag_update = self._build_dag_event_from_todo()
                                if dag_update:
                                    yield dag_update
                            elif reroute_action == "RETRY_SAME":
                                logger.info(f"  🔄 LLM says retry same actor: {reroute_reasoning[:100]}")
                                yield {"module": "Synapse.core.conductor", "message": f"LLM decided to retry with same actor: {reroute_reasoning[:100]}"}
                                # Override strategy to "retry" so it goes through the retry path
                                strategy_action = "retry"
                            elif reroute_action == "DECOMPOSE":
                                logger.info(f"  🔨 LLM recommends task decomposition")
                                yield {"module": "Synapse.core.conductor", "message": f"LLM recommends decomposing task: {reroute_reasoning[:100]}"}
                                strategy_action = "re_evaluate"
                                action_reasoning = reroute_reasoning
                            else:  # FAIL_PERMANENT or unknown
                                logger.warning(f"🛑 LLM decided permanent failure: {reroute_reasoning[:100]}")
                                strategy_action = "stop"
                                action_reasoning = f"LLM failure analyst: {reroute_reasoning}"
                        else:
                            logger.warning(
                                f"⚠️ LLM rerouting unavailable for {task.task_id}; keeping current auditor strategy action={strategy_action}"
                            )
                    
                    if strategy_action == "stop":
                        # Permanent failure - mark as failed permanently
                        self.todo.fail_task(task.task_id, auditor_feedback)
                        self.todo.mark_task_permanent_failure(task.task_id, execution_guidance.get("why_impossible", "Task marked as impossible"))
                        logger.info(f"🛑 Task {task.task_id} marked as permanent failure: {action_reasoning[:100]}")
                        yield {"module": "Synapse.core.conductor", "message": f"Task {task.task_id} marked as permanent failure: {action_reasoning[:100]}"}
                        # Re-emit DAG + task list after failure
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        task_list_evt = self._build_task_list_event()
                        if task_list_evt:
                            yield task_list_evt
                    
                    elif strategy_action in ("pass", "pass_partial"):
                        # LLM strategy can intentionally move forward with explicit unresolved gaps.
                        partial_credit = execution_guidance.get("partial_credit", auditor_reward)
                        try:
                            partial_credit = float(partial_credit)
                        except Exception:
                            partial_credit = auditor_reward
                        partial_credit = max(0.0, min(1.0, partial_credit))
                        self.todo.complete_task(task.task_id, result, partial_credit)
                        unresolved_items = execution_guidance.get("unresolved_items", [])
                        logger.info(
                            f"🟡 Task {task.task_id} accepted by strategy ({strategy_action}) | credit={partial_credit:.2f} | unresolved={smart_truncate(str(unresolved_items), max_tokens=100)}"
                        )
                        yield {
                            "module": "Synapse.core.conductor",
                            "message": f"Task {task.task_id} accepted as partial completion; unresolved: {smart_truncate(str(unresolved_items), max_tokens=125)}"
                        }
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        task_list_evt = self._build_task_list_event()
                        if task_list_evt:
                            yield task_list_evt
                    
                    elif strategy_action == "retry":
                        # 🧠 A-TEAM ENHANCEMENT E1: Proactive Q-value-based re-delegation on retry
                        # Before retrying with same actor, check if a significantly BETTER actor exists
                        retry_feedback = execution_guidance.get("feedback_to_inject", auditor_feedback)
                        reassigned = False
                        if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                            try:
                                current_q = self.enhanced_agent_selector._get_q_value(
                                    task.actor,
                                    self.enhanced_agent_selector._extract_task_features(task)
                                )
                                best_alt_agent = None
                                best_alt_q = current_q
                                redelegate_margin = getattr(self.config, 'redelegate_q_margin', 0.15)
                                for aname in self.actors:
                                    if aname != task.actor:
                                        alt_q = self.enhanced_agent_selector._get_q_value(
                                            aname,
                                            self.enhanced_agent_selector._extract_task_features(task)
                                        )
                                        if alt_q > best_alt_q + redelegate_margin:
                                            best_alt_q = alt_q
                                            best_alt_agent = aname
                                if best_alt_agent:
                                    logger.info(f"🔀 Q-VALUE RE-DELEGATION: {task.actor} (Q={current_q:.3f}) → {best_alt_agent} (Q={best_alt_q:.3f})")
                                    yield {"module": "Synapse.core.conductor", "message": f"Re-delegating task from {task.actor} to {best_alt_agent} based on Q-values (Q={best_alt_q:.3f} vs {current_q:.3f})"}
                                    task.actor = best_alt_agent
                                    reassigned = True
                            except Exception as e:
                                logger.debug(f"Q-value re-delegation check failed: {e}")
                        self.todo.mark_for_retry(task.task_id, retry_feedback, execution_guidance)
                        if reassigned:
                            logger.info(f"🔄 Task {task.task_id} re-assigned to {task.actor} and marked for retry")
                            yield {"module": "Synapse.core.conductor", "message": f"Task {task.task_id} re-assigned to {task.actor} for retry"}
                        else:
                            logger.info(f"🔄 Task {task.task_id} marked for retry with feedback injection (same actor)")
                        yield {"module": "Synapse.core.conductor", "message": f"Task {task.task_id} will be retried with enhanced feedback"}
                        
                        # 🔴 A-TEAM FIX: Store retry memory so the system learns from partial attempts
                        # Previously only success/failure stored memories, missing retry learnings
                        try:
                            _retry_content = (
                                f"Retry attempt for task '{smart_truncate(task.description, max_tokens=100)}': "
                                f"Feedback: {smart_truncate(str(retry_feedback), max_tokens=200)}. "
                                f"Guidance: {smart_truncate(str(execution_guidance), max_tokens=100)}"
                            )
                            self._store_memory(
                                content=_retry_content,
                                level=MemoryLevel.EPISODIC,
                                context={
                                    'task_id': task.task_id,
                                    'actor': task.actor,
                                    'attempt': getattr(task, 'attempt_count', 0),
                                    'reassigned': reassigned,
                                    'event_type': 'retry',
                                },
                                goal=goal,
                                actor_name=task.actor,
                                initial_value=0.3,  # Low initial value for retry memories
                                outcome='retry'
                            )
                        except Exception as _retry_mem_err:
                            logger.debug(f"Retry memory storage failed (non-critical): {_retry_mem_err}")
                        
                        # 🔴 A-TEAM: Re-emit DAG + task_list after retry/re-delegation
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        _tl_retry = self._build_task_list_event()
                        if _tl_retry:
                            yield _tl_retry
                    
                    elif strategy_action == "re_evaluate":
                        logger.info(f"🔄 Re-evaluating task {task.task_id} with different breakdown/actors")
                        yield {"module": "Synapse.core.conductor", "message": f"Re-evaluating task {task.task_id}..."}
                        async for event in self._re_evaluate_task_stream(task, execution_guidance, auditor_feedback):
                                yield event
                        # Re-emit DAG + task_list after re-evaluation (may have added/modified subtasks)
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        _tl_reeval = self._build_task_list_event()
                        if _tl_reeval:
                            yield _tl_reeval
                    
                    else:
                        # Default: fail task
                        self.todo.fail_task(task.task_id, auditor_feedback)
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        _tl_fail = self._build_task_list_event()
                        if _tl_fail:
                            yield _tl_fail

                    # 🔴 A-TEAM FIX: Auditor→TODO task mutation integration
                    # If auditor suggests TODO-level changes (new prereq tasks, actor changes, etc.)
                    todo_suggestions = strategy.get("todo_suggestions", execution_guidance.get("todo_changes", []))
                    if todo_suggestions and isinstance(todo_suggestions, list):
                        for suggestion in todo_suggestions[:5]:  # Limit to 5 suggestions
                            try:
                                stype = suggestion.get("type", "")
                                if stype == "insert_before":
                                    new_task = SubtaskState(
                                        task_id=f"auditor_prereq_{task.task_id}_{int(time.time())}",
                                        description=suggestion.get("description", "Prerequisite task"),
                                        actor=suggestion.get("actor", task.actor),
                                        depends_on=task.depends_on.copy(),
                                    )
                                    self.todo.insert_task_after(
                                        task.depends_on[-1] if task.depends_on else list(self.todo.subtasks.keys())[0],
                                        new_task
                                    )
                                    task.depends_on.append(new_task.task_id)
                                    logger.info(f"  📋 Auditor inserted prereq: {new_task.task_id}")
                                elif stype == "change_actor":
                                    new_actor = suggestion.get("actor")
                                    if new_actor and new_actor in self.actors:
                                        task.actor = new_actor
                                        logger.info(f"  🔄 Auditor changed actor to: {new_actor}")
                                elif stype == "update_description":
                                    new_desc = suggestion.get("description")
                                    if new_desc:
                                        self.todo.update_task(task.task_id, description=new_desc)
                                        logger.info(f"  📝 Auditor updated task description")
                            except Exception as e:
                                logger.debug(f"  ⚠️ Failed to apply auditor TODO suggestion: {e}")
                        if todo_suggestions:
                            yield {"module": "Synapse.core.conductor", "message": f"Applied {len(todo_suggestions)} auditor TODO suggestions"}
                            # 🔴 A-TEAM: Re-emit DAG + task list after TODO mutations
                            dag_update = self._build_dag_event_from_todo()
                            if dag_update:
                                yield dag_update
                            task_list_evt = self._build_task_list_event()
                            if task_list_evt:
                                yield task_list_evt

                    # 🎯 A-TEAM GAP #3: Use AgenticFeedbackRouter for intelligent failure routing
                    yield {"module": "Synapse.core.agentic_feedback_router", "message": f"Routing feedback for failed task: {task.actor}"}
                    routing_decision = await self._route_failure_to_collaborators(
                        task=task,
                        auditor_feedback=auditor_feedback,
                        context={
                            'iteration': iteration,
                            'q_value': q_value,
                            'confidence': confidence,
                            'state': state
                        }
                    )
                    
                    # If routing suggests collaboration, create new task for target agent
                    if routing_decision and routing_decision.get('should_route'):
                        target_agent = routing_decision['target_agent']
                        reason = routing_decision.get('reason', 'collaboration needed')
                        yield {"module": "Synapse.core.agentic_feedback_router", "message": f"Routing to {target_agent}: {reason[:100]}"}
                        new_task_desc = routing_decision.get('suggested_task', 
                            f"Research and provide guidance for: {task.description}"
                        )
                        
                        # Insert new research/collaboration task
                        # 🔴 A-TEAM FIX: Removed local import of SubtaskState — it's already
                        # imported at module level (line 83). The local import caused Python
                        # to treat SubtaskState as a local variable throughout the entire run()
                        # method, making earlier uses crash with UnboundLocalError.
                        research_task = SubtaskState(
                            task_id=f"{task.task_id}_research",
                            description=new_task_desc,
                            actor=target_agent,
                            depends_on=[],  # Can run immediately
                            priority=task.priority + 0.5  # Higher priority
                        )
                        self.todo.insert_task_after(task.task_id, research_task)
                        logger.info(f"✅ Inserted research task for {target_agent}: {new_task_desc[:60]}...")
                        
                        # 🔴 A-TEAM FIX: Send feedback context to target agent via AgentSlack
                        # Without this, the target agent gets the task but no context about WHY
                        if self.agent_slack and routing_decision.get('feedback_messages'):
                            for fb_msg in routing_decision['feedback_messages']:
                                try:
                                    self.agent_slack.send(
                                        from_agent=task.actor,
                                        to_agent=getattr(fb_msg, 'target_actor', target_agent),
                                        data={
                                            "message_type": "failure_routing",
                                            "original_task": task.description,
                                            "failure_reason": auditor_feedback[:500],
                                            "routing_reason": reason,
                                            "context": getattr(fb_msg, 'context', {}),
                                        }
                                    )
                                except Exception as _slack_err:
                                    logger.debug(f"  ⚠️ Failed to send routing context via AgentSlack: {_slack_err}")
                        
                        # 🔴 A-TEAM: Re-emit DAG + task list after new task insertion
                        dag_update = self._build_dag_event_from_todo()
                        if dag_update:
                            yield dag_update
                        task_list_evt = self._build_task_list_event()
                        if task_list_evt:
                            yield task_list_evt

                    # ═════════════════════════════════════════════════════════
                    # 🧠 A-TEAM: AUTO SKILL REQUEST ON REPEATED CAPABILITY GAPS
                    # ═════════════════════════════════════════════════════════
                    # When an actor fails ≥2 times on the same task, analyse the
                    # failure trajectory via LLM to decide if the root cause is a
                    # missing tool/skill.  If so, fire a request_skill action
                    # automatically so the skill-building pipeline activates
                    # WITHOUT requiring the actor to manually emit the action.
                    # ═════════════════════════════════════════════════════════
                    retry_count = getattr(task, 'attempts', 0)
                    if retry_count >= 2 and hasattr(self, 'skill_registry') and self.skill_registry is not None:
                        try:
                            _cap_sig = dspy.Signature(
                                "task_description, failure_history, actor_tools -> needs_skill: bool, capability_description: str",
                            )
                            _cap_cot = dspy.ChainOfThought(_cap_sig)
                            # Gather failure history
                            _fail_hist = smart_truncate(
                                json.dumps(getattr(task, 'intermediary_values', [])[-3:], default=str),
                                max_tokens=400,
                            )
                            _actor_cfg = self.actors.get(task.actor)
                            _actor_tools_desc = "unknown"
                            if _actor_cfg:
                                _underlying = getattr(_actor_cfg, 'agent', _actor_cfg)
                                _tool_names = [getattr(t, '__name__', str(t)) for t in getattr(_underlying, 'tools', [])[:20]]
                                _actor_tools_desc = ", ".join(_tool_names) if _tool_names else "none listed"
                            
                            with dspy.context(lm=self.lm):
                                _cap_result = await asyncio.to_thread(
                                    _cap_cot,
                                    task_description=task.description[:500],
                                    failure_history=_fail_hist,
                                    actor_tools=_actor_tools_desc,
                                )
                            _needs_skill = str(getattr(_cap_result, 'needs_skill', 'false')).strip().lower() in ('true', 'yes', '1')
                            _cap_desc = str(getattr(_cap_result, 'capability_description', '')).strip()
                            if _needs_skill and _cap_desc:
                                logger.info(f"🧠 [AUTO-SKILL-REQUEST] Actor '{task.actor}' needs capability: {_cap_desc[:200]}")
                                skill_action = {
                                    "type": "request_skill",
                                    "data": {
                                        "capability": _cap_desc[:500],
                                        "context": {"task_id": task.task_id, "actor": task.actor},
                                        "preferred_owner": "terminal",
                                    }
                                }
                                async for _sk_evt in self._handle_request_skill_stream(skill_action, task.actor, {}):
                                    yield _sk_evt
                        except Exception as _sk_err:
                            logger.debug(f"⚠️ Auto skill-request analysis failed (non-critical): {_sk_err}")

                    # 🔍 A-TEAM: Web search on auditor failure for recovery guidance
                    web_search_context = None
                    if auditor_feedback and "error" in auditor_feedback.lower():
                        # Create a pseudo-exception for web search
                        class AuditorFailure(Exception):
                            pass
                        pseudo_error = AuditorFailure(smart_truncate(auditor_feedback, max_tokens=125))
                        web_search_context = await self._web_search_on_error(
                            pseudo_error,
                            {
                                'task': task.description,
                                'actor': task.actor,
                                'iteration': iteration,
                                'auditor_feedback': smart_truncate(auditor_feedback, max_tokens=125)
                            }
                        )

                    if hasattr(self, 'shared_context') and self.shared_context:
                        failure_ctx = {
                            'actor': task.actor,
                            'task': task.task_id,
                            'reason': smart_truncate(auditor_feedback, max_tokens=125),
                            'iteration': iteration
                        }
                        if web_search_context:
                            failure_ctx['web_search_context'] = web_search_context
                            self.shared_context.set('web_search_context', web_search_context)
                        self.shared_context.set('last_failure_context', failure_ctx)
                    
                    # Record intermediary values for failure (NO HARDCODING)
                    task_duration = time.time() - task_start_time
                    self.todo.record_intermediary_values(task.task_id, {  # Fixed: task.id → task.task_id
                        'duration_seconds': task_duration,
                        'reward_obtained': 0.0,
                        'auditor_passed': False,
                        'iteration': iteration,
                        'timestamp': time.time(),
                        'q_value': q_value,
                        'confidence': confidence,
                        'failure_reason': smart_truncate(auditor_feedback, max_tokens=125)
                    })
                    
                    # Record failure
                    self.q_predictor.record_outcome(state, action, 0.0)
                    
                    # 🔴 A-TEAM FIX 27: Propagate failure to SubtaskState Q-value
                    alpha = getattr(self.config, 'task_q_learning_rate', 0.3)
                    old_estimate = task.estimated_reward
                    task.estimated_reward = old_estimate + alpha * (0.0 - old_estimate)
                    task.confidence = min(1.0, task.confidence + 0.05)  # Slight confidence increase even on failure (we learned something)
                    logger.debug(f"  📉 Updated SubtaskState Q (failure): {old_estimate:.3f} → {task.estimated_reward:.3f}")
                    
                    # 🔥 A-TEAM: Get trajectory correction recommendations on failure
                    if hasattr(self.q_predictor, 'recommend_trajectory_correction'):
                        try:
                            correction = self.q_predictor.recommend_trajectory_correction(
                                current_todo_state=self.todo.get_state_summary(),
                                failed_tasks=[{
                                    'description': task.description,
                                    'failure_reasons': [auditor_feedback],
                                    'actor': task.actor,
                                    'attempts': task.attempts
                                }]
                            )
                            if correction.get('should_correct'):
                                logger.warning(f"🔄 Q-LEARNING TRAJECTORY CORRECTION RECOMMENDED:")
                                logger.warning(f"   Strategy: {correction.get('correction_strategy', 'N/A')}")
                                for avoid in correction.get('actions_to_avoid', [])[:3]:
                                    logger.warning(f"   ⛔ Avoid: {avoid}")
                                for suggest in correction.get('specific_actions', [])[:3]:
                                    logger.warning(f"   ✅ Try: {suggest}")
                                # Store correction in shared context for future steps
                                # 🔴 A-TEAM FIX (BUG S): Use .set() not [] — SharedContext
                                # does NOT implement __setitem__, so dict-style assignment
                                # silently failed, preventing trajectory corrections from
                                # being injected into retried actors.
                                if self.shared_context:
                                    self.shared_context.set('trajectory_correction', correction)
                                yield {"module": "Synapse.core.conductor", "message": f"Q-learning recommends: {correction.get('correction_strategy', 'change approach')}"}
                        except Exception as e:
                            logger.debug(f"Trajectory correction failed: {e}")
                    
                    # 🔬 A-TEAM ENHANCEMENT: Store FAILURE with outcome for automatic pattern extraction
                    # Shannon: -log P(failure) = high info when failures are rare
                    # 🧬 Stores in BOTH shared_memory AND local_memories[actor]
                    try:
                        _fail_content = f"""❌ FAILURE ANALYSIS (High Information Event)
Task: {task.description}
Actor: {task.actor}
Reason: {auditor_feedback}
State: {smart_truncate(json.dumps(state, default=str), max_tokens=125)}
Attempt #{task.attempts + 1}"""
                        _fail_ctx = {
                            'actor': task.actor,
                            'task': task.task_id,
                            'failure': True,
                            'web_search_context': self.shared_context.get('web_search_context') if self.shared_context else None,
                            'auditor_feedback': smart_truncate(auditor_feedback, max_tokens=125)
                        }
                        self._store_memory(
                            content=_fail_content,
                            level=MemoryLevel.EPISODIC,
                            context=_fail_ctx,
                            goal=goal,
                            actor_name=task.actor,
                            outcome="failure"
                        )
                        logger.info(f"💾 Stored auditor failure in memory (outcome=failure) for pattern extraction")
                        # 🧠 Emit memory_update for frontend
                        yield self._build_memory_update_event(
                            content=f"❌ FAILURE: {task.description} — {smart_truncate(auditor_feedback, max_tokens=80)}",
                            level="episodic", actor=task.actor,
                            context=_fail_ctx
                        )
                    except Exception as mem_err:
                        logger.debug(f"Failed to store failure in memory: {mem_err}")
                
                # Track in trajectory
                # 🔧 CRITICAL FIX: Include FULL ReAct trajectory for Auditor visibility
                task_end_time = time.time()  # 🔧 FIX: Set task end time
                react_trajectory = {}
                if hasattr(result, 'output'):
                    inner = result.output
                    if hasattr(inner, 'trajectory') and isinstance(inner.trajectory, dict):
                        react_trajectory = inner.trajectory
                    elif hasattr(inner, '__dict__') and 'trajectory' in vars(inner):
                        react_trajectory = vars(inner).get('trajectory', {})
                
                # 🔴 A-TEAM FIX: Extract tool_calls from react_trajectory so _get_current_state
                # can build rich tool usage context (URLs, selectors, commands, results).
                # Previously step_result never had 'tool_calls', making the tool context always empty.
                extracted_tool_calls = []
                if react_trajectory and isinstance(react_trajectory, dict):
                    # ReAct trajectory stores tools as tool_name_0, tool_args_0, observation_0, etc.
                    step_idx = 0
                    while f'tool_name_{step_idx}' in react_trajectory:
                        tool_name = react_trajectory.get(f'tool_name_{step_idx}', '')
                        tool_args = react_trajectory.get(f'tool_args_{step_idx}', {})
                        observation = react_trajectory.get(f'observation_{step_idx}', '')
                        
                        tc_entry = {
                            'tool': tool_name,
                            'params': tool_args if isinstance(tool_args, dict) else {},
                            'success': True,  # Will be refined below
                        }
                        
                        # Extract key result info from observation
                        if isinstance(observation, str):
                            obs_lower = observation.lower()
                            # Detect failures from observation text
                            if any(kw in obs_lower for kw in ['error', 'failed', 'timeout', 'exception', 'blocked']):
                                tc_entry['success'] = False
                                tc_entry['error'] = smart_truncate(observation, max_tokens=80)
                            # Extract URL/page info from observations
                            if 'current_url' in obs_lower or 'url' in obs_lower:
                                try:
                                    obs_dict = json.loads(observation)
                                    for key in ['current_url', 'url', 'title', 'file_path', 'status']:
                                        if key in obs_dict:
                                            tc_entry[key] = str(obs_dict[key])[:120]
                                except (json.JSONDecodeError, TypeError):
                                    pass
                        elif isinstance(observation, dict):
                            for key in ['current_url', 'url', 'title', 'file_path', 'status', 'error']:
                                if key in observation:
                                    tc_entry[key] = str(observation[key])[:120]
                            if 'error' in observation:
                                tc_entry['success'] = False
                        
                        # Extract key params (URL, selector, query etc.)
                        if isinstance(tool_args, dict):
                            for key in ['url', 'selector', 'query', 'search_query', 'text', 'file_path', 'command', 'keystrokes', 'script']:
                                if key in tool_args:
                                    tc_entry[key] = smart_truncate(str(tool_args[key]), max_tokens=80)
                        
                        extracted_tool_calls.append(tc_entry)
                        step_idx += 1
                
                step_result = {
                    'iteration': iteration,
                    'task': task.task_id,  # Fixed: task.id → task.task_id
                    'actor': task.actor,
                    'passed': auditor_passed,
                    'reward': auditor_reward if auditor_passed else 0.0,
                    'feedback': auditor_feedback,
                    'success': auditor_passed,
                    'actor_output': result,  # ✅ Full actor output
                    'react_trajectory': react_trajectory,  # ✅ Full ReAct trajectory with thoughts/observations
                    'tool_calls': extracted_tool_calls,  # 🔴 A-TEAM FIX: tool_calls for _get_current_state context
                    'execution_time': task_end_time - task_start_time
                }
                self.trajectory.append(step_result)
                
                # ================================================================
                # DIVERGENCE LEARNING: Compare prediction with reality (A-Team Fix)
                # ================================================================
                # 🧠 A-TEAM FIX: Wire divergence → Q-table update → Lesson extraction → Prompt update
                if self.trajectory_predictor and self._last_prediction and self.divergence_memory:
                    try:
                        # Build actual trajectory from what happened
                        actual = ActualTrajectory(
                            steps=[step_result],
                            actual_reward=auditor_reward if auditor_passed else 0.0
                        )
                        
                        # Compute divergence (this is the "loss")
                        divergence = self.trajectory_predictor.compute_divergence(
                            self._last_prediction, actual
                        )
                        
                        # Store by information content (Shannon)
                        self.divergence_memory.store(divergence)
                        
                        # Update predictor from divergence (this is the "weight update")
                        self.trajectory_predictor.update_from_divergence(divergence)
                        
                        # ================================================================
                        # 🧠 A-TEAM FIX: Use divergence as TD error for Q-table update!
                        # ================================================================
                        # Information asymmetry = what we learned from execution vs planning
                        info_asymmetry = divergence.information_content
                        
                        # Divergence-weighted reward: penalize for wrong predictions
                        divergence_penalty = 1.0 - min(1.0, divergence.total_divergence())
                        q_reward = (auditor_reward if auditor_passed else 0.0) * divergence_penalty
                        
                        # Update Q-table with divergence-adjusted reward
                        # 🔥 A-TEAM: Use async queue if available, else sync
                        # 🔴 A-TEAM FIX: Reuse the RICH action dict (line ~4662) instead of sparse stub
                        # The `action` variable already contains actor, task, task_id, priority,
                        # attempts, max_attempts, previous_failures, retry_feedback, dependencies.
                        # Enrich further with execution results for Q-learning granularity.
                        divergence_action = dict(action)  # Clone the rich action dict
                        divergence_action['execution_tool_calls'] = extracted_tool_calls[-5:] if extracted_tool_calls else []
                        divergence_action['execution_time'] = task_end_time - task_start_time
                        divergence_action['auditor_passed'] = auditor_passed
                        divergence_action['divergence_penalty'] = divergence_penalty
                        divergence_action['info_asymmetry'] = info_asymmetry
                        
                        experience_data = {
                            'state': state,
                            'action': divergence_action,
                            'reward': q_reward,
                            'next_state': self._get_current_state(current_subtask=task),
                            'done': False,
                            'divergence_adjusted': True  # Flag to use lower failure threshold (0.05)
                        }
                        
                        if self.async_q_updater:
                            # Non-blocking async update
                            await self.async_q_updater.queue_experience(**experience_data)
                            logger.debug("🔥 Q-experience queued for async update")
                        else:
                            # Sync fallback
                            self.q_predictor.add_experience(**experience_data)
                        
                        # 🔥 A-TEAM: Record prediction outcome for meta-learning
                        # predicted_q_value and confidence were set before execution
                        # 🔴 A-TEAM FIX: Use the rich divergence_action dict instead of sparse stub
                        # for proper meta-learning context. The sparse dict was losing all execution
                        # details (tool calls, timing, failure history) critical for prediction calibration.
                        if self.async_q_updater:
                            await self.async_q_updater.queue_prediction_outcome(
                                state=state,
                                action=divergence_action,
                                predicted_q=predicted_q_value,
                                confidence=confidence,
                                actual_reward=q_reward
                            )
                            logger.debug("🧠 Prediction outcome queued for meta-learning")
                        elif hasattr(self.q_predictor, 'record_prediction_outcome'):
                            self.q_predictor.record_prediction_outcome(
                                state=state,
                                action=divergence_action,
                                predicted_q=predicted_q_value,
                                confidence=confidence,
                                actual_reward=q_reward
                            )
                        
                        # ================================================================
                        # 🧠 A-TEAM FIX: Extract lessons from divergence for prompt updates
                        # ================================================================
                        if hasattr(self.q_predictor, 'Q') and self.q_predictor.Q:
                            key = list(self.q_predictor.Q.keys())[-1]  # Most recent
                            lessons = self.q_predictor.Q[key].get('learned_lessons', [])
                            if lessons:
                                logger.info(f"📚 Learned: {lessons[-1][:80]}...")
                        
                        logger.debug(f"📊 Divergence: {divergence.total_divergence():.2f}, info={info_asymmetry:.2f}, Q-reward={q_reward:.2f}")
                    except Exception as e:
                        logger.debug(f"Divergence learning failed: {e}")
                
                # ================================================================
                # 🧠 A-TEAM ENHANCEMENT E6: Intra-Episode Policy Checkpoint
                # After each task, re-evaluate remaining task priorities using
                # UPDATED Q-values (which just learned from this task's outcome).
                # This enables online policy adjustment within the episode.
                # ================================================================
                policy_checkpoint_interval = getattr(self.config, 'policy_checkpoint_interval', 3)
                if iteration > 0 and iteration % policy_checkpoint_interval == 0:
                    try:
                        # Re-score all pending tasks with updated Q-values
                        pending_tasks = [
                            t for t in self.todo.subtasks.values()
                            if t.status == TaskStatus.PENDING
                        ]
                        if pending_tasks and hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                            updated_scores = {}
                            for pt in pending_tasks:
                                # Get current Q-value for the assigned actor
                                q_val = self.enhanced_agent_selector._get_q_value(
                                    pt.actor,
                                    self.enhanced_agent_selector._extract_task_features(pt)
                                )
                                # Combined score: Q-value * priority * confidence
                                updated_scores[pt.task_id] = q_val * pt.priority * pt.confidence
                                # Propagate Q-value to estimated_reward for RL-aware ordering
                                if q_val != 0.5:  # Only update if we have actual learned data
                                    blend = 0.3  # Blend learned Q with prior estimate
                                    pt.estimated_reward = (1 - blend) * pt.estimated_reward + blend * q_val
                            
                            # Re-sync dependency graph with updated scores
                            if hasattr(self, 'dependency_graph'):
                                new_order = self.dependency_graph.get_execution_order(task_scores=updated_scores)
                                if new_order:
                                    logger.info(f"🔄 [POLICY CHECKPOINT] Re-ordered {len(new_order)} tasks using updated Q-values")
                                    yield {"module": "Synapse.core.conductor", "message": f"Policy checkpoint: re-evaluated {len(pending_tasks)} pending tasks with updated Q-values"}
                    except Exception as e:
                        logger.debug(f"Policy checkpoint failed: {e}")
                
                # Update context with new TODO state
                self.context_guard.clear()
                self.context_guard.register_critical("ROOT_GOAL", goal)
                self.context_guard.register_critical("TODO_STATE", self.todo.get_state_summary())
                
                # Check if all tasks are in a terminal state (COMPLETED, FAILED, or SKIPPED)
                # A task is "done" if it can no longer be picked up for execution.
                # Previously only checked COMPLETED, so any permanently failed task
                # caused the loop to run until max_iterations — the P8 stuck-task bug.
                _terminal_states = (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.SKIPPED)
                all_tasks_terminal = all(
                    t.status in _terminal_states
                    for t in self.todo.subtasks.values()
                )
                if all_tasks_terminal:
                    _completed_count = sum(1 for t in self.todo.subtasks.values() if t.status == TaskStatus.COMPLETED)
                    _failed_count = sum(1 for t in self.todo.subtasks.values() if t.status == TaskStatus.FAILED)
                    _skipped_count = sum(1 for t in self.todo.subtasks.values() if t.status == TaskStatus.SKIPPED)
                    all_auditors_passed = True
                    logger.info(
                        f"🎉 All tasks reached terminal state! "
                        f"completed={_completed_count}, failed={_failed_count}, skipped={_skipped_count}"
                    )
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"All {len(self.todo.subtasks)} tasks reached terminal state: "
                                   f"{_completed_count} completed, {_failed_count} failed, {_skipped_count} skipped"
                    }
                
                # ============================================================
                # 🎯 A-TEAM: ADVISORY SUBTASK COMPLETION CHECK
                # Non-mandatory, non-blocking advisory that logs which pending
                # subtasks of the same actor APPEAR to be covered by the
                # completed work.  Does NOT auto-mark them complete — the
                # next iteration will pick them up and the actor can confirm.
                #
                # If the auditor's strategy says "already_covered", only then
                # do we mark the subtask as complete (explicit LLM decision).
                #
                # This prevents both:
                # 1. Blindly marking everything as done (old aggressive approach)
                # 2. Re-executing work that was clearly finished
                # ============================================================
                if auditor_passed and result:
                    completed_work_str = smart_truncate(str(result), max_tokens=500)
                    same_actor_pending = [
                        (tid, t) for tid, t in self.todo.subtasks.items()
                        if t.status == TaskStatus.PENDING and t.actor == task.actor and tid != task.task_id
                    ]
                    if same_actor_pending:
                        advisory_notes = []
                        for other_id, other_task in same_actor_pending:
                            # Quick heuristic: if the other task's key terms appear
                            # in the completed output, flag it as advisory
                            key_terms = [w.lower() for w in other_task.description.split()
                                         if len(w) > 4][:5]
                            matches = sum(1 for term in key_terms if term in completed_work_str.lower())
                            if matches >= 2:
                                advisory_notes.append(
                                    f"   📋 Advisory: subtask '{other_id}' ({other_task.description[:60]}) "
                                    f"may already be covered ({matches}/{len(key_terms)} key terms found)"
                                )
                        if advisory_notes:
                            logger.info(f"📋 ADVISORY SUBTASK CHECK for {task.actor}:")
                            for note in advisory_notes:
                                logger.info(note)
                            yield {
                                "module": "Synapse.core.conductor",
                                "message": f"Advisory: {len(advisory_notes)} pending subtask(s) for {task.actor} may already be covered by completed work. "
                                           f"They will be verified in subsequent iterations.",
                                "type": "advisory_subtask_check",
                                "data": {"notes": advisory_notes, "actor": task.actor}
                            }
                
                # Auto-save state periodically (NO HARDCODED INTERVAL - from config)
                if self.persistence_manager and self.persistence_manager.should_auto_save(iteration):
                    self.persistence_manager.save_markovian_todo(self.todo)
                    logger.info(f"💾 Auto-saved state at iteration {iteration}")

                # Collect runtime metrics for diagnostics
                if hasattr(self, 'shared_context') and self.shared_context:
                    metrics = self._collect_runtime_metrics()
                    if metrics:
                        self.shared_context.set('runtime_metrics', metrics)
                
            except Exception as e:
                if isinstance(e, TimeoutError):
                    await asyncio.to_thread(self._checkpoint_state, "timeout", task)
                    self.todo.fail_task(task.task_id, f"Timeout: {e}")
                    logger.warning(f"⏰ Actor '{task.actor}' timed out: {e}")
                    if hasattr(self, 'shared_context') and self.shared_context:
                        actor_outputs = self.shared_context.get('actor_outputs') or {}
                        actor_outputs[task.actor] = {"error": f"Timeout: {e}", "task": task.task_id}
                        self.shared_context.set('actor_outputs', actor_outputs)
                    dag_update = self._build_dag_event_from_todo()
                    if dag_update:
                        yield dag_update
                    _tl = self._build_task_list_event()
                    if _tl:
                        yield _tl
                    continue

                logger.error(f"Actor execution failed: {e}")
                if hasattr(self, 'shared_context') and self.shared_context:
                    actor_outputs = self.shared_context.get('actor_outputs') or {}
                    actor_outputs[task.actor] = {"error": str(e), "task": task.task_id}
                    self.shared_context.set('actor_outputs', actor_outputs)
                import traceback as tb  # Local import to avoid scope issues
                logger.error(f"Full traceback: {tb.format_exc()}")
                
                # 🔥 A-TEAM FIX: Store failure in memory BEFORE deciding if fatal!
                # This ensures we learn from ALL failures, not just Auditor failures
                failure_context = {
                    'actor': task.actor,
                    'task': task.task_id,
                    'error_type': type(e).__name__,
                    'error_message': smart_truncate(str(e), max_tokens=125),
                    'iteration': iteration
                }
                if hasattr(self, 'shared_context') and self.shared_context:
                    self.shared_context.set('last_failure_context', failure_context)
                
                # 🔴 A-TEAM SOTA: LLM-Based Stuck Detection (exception path)
                # If the same task has failed 2+ consecutive times with the same error type,
                # use FailureReroutingSignature to intelligently decide recovery action.
                # No hardcoded for-loop iteration — fully agentic decision.
                error_type_name = type(e).__name__
                error_msg_l = str(e).lower()
                auth_provider_markers = [
                    "unauthorized",
                    "invalid token",
                    "authenticationerror",
                    "statuscode\": 403",
                    "statuscode: 403",
                    "serper",
                    "api key",
                    "forbidden",
                ]
                auth_provider_failure = any(marker in error_msg_l for marker in auth_provider_markers)

                if auth_provider_failure or (hasattr(task, 'failure_reasons') and len(task.failure_reasons) >= 2):
                    recent_errors = task.failure_reasons[-2:] if hasattr(task, 'failure_reasons') and len(task.failure_reasons) >= 2 else []
                    repeated_same_error_type = bool(recent_errors) and all(error_type_name in str(err) for err in recent_errors)
                    if auth_provider_failure or repeated_same_error_type:
                        logger.warning(f"🔴 STUCK DETECTION (exception path): Task {task.task_id} has failed "
                                      f"{len(task.failure_reasons)} times with same error type ({error_type_name})")
                        yield {"module": "Synapse.core.conductor", "message": f"🔴 Stuck: {task.task_id} repeated {error_type_name} — consulting LLM failure analyst"}
                        
                        # 🧠 Use LLM-based rerouting instead of hardcoded for-loop
                        reroute_result = None
                        if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                            try:
                                # 🔴 A-TEAM FIX: self.actors values are AgentConfig dataclasses, not dicts
                                available_agents_list = [
                                    self.actors[aname] if isinstance(self.actors[aname], AgentConfig)
                                    else AgentConfig(name=aname, capabilities=getattr(self.actors[aname], 'capabilities', []))
                                    for aname in self.actors
                                ]
                                reroute_context = {
                                    'goal': goal,
                                    'iteration': iteration,
                                    'error_type': error_type_name,
                                    'error_message': smart_truncate(str(e), max_tokens=125),
                                }
                                async for event in self.enhanced_agent_selector.reroute_on_failure_stream(
                                    task=task,
                                    available_agents=available_agents_list,
                                    failure_history=task.failure_reasons,
                                    context=reroute_context,
                                ):
                                    if isinstance(event, dict) and event.get("type") == "result":
                                        reroute_result = event.get("result")
                                    else:
                                        yield event
                            except Exception as reroute_err:
                                logger.warning(f"⚠️ LLM failure rerouting failed in exception path: {reroute_err}")
                        
                        # Apply the rerouting decision
                        if reroute_result:
                            reroute_action = reroute_result.get("action", "FAIL_PERMANENT")
                            reroute_target = reroute_result.get("target_actor", "N/A")
                            reroute_reasoning = reroute_result.get("reasoning", "")
                            
                            if reroute_action == "SWITCH_ACTOR" and reroute_target in self.actors:
                                logger.info(f"  🔀 LLM rerouting (exception): {task.actor} → {reroute_target}")
                                yield {"module": "Synapse.core.conductor", "message": f"LLM switched {task.task_id} to {reroute_target}: {reroute_reasoning[:100]}"}
                                task.actor = reroute_target
                                task.status = TaskStatus.PENDING
                                task.failure_reasons.clear()
                                # Emit DAG + task list update after actor switch
                                dag_update = self._build_dag_event_from_todo()
                                if dag_update:
                                    yield dag_update
                                _tl = self._build_task_list_event()
                                if _tl:
                                    yield _tl
                            elif reroute_action == "RETRY_SAME":
                                logger.info(f"  🔄 LLM says retry same actor in exception path")
                                yield {"module": "Synapse.core.conductor", "message": f"LLM decided to retry same actor: {reroute_reasoning[:80]}"}
                                # Don't continue — let normal retry logic handle it
                            else:
                                # FAIL_PERMANENT or DECOMPOSE
                                self.todo.fail_task(task.task_id, f"LLM decided: {reroute_action} — {reroute_reasoning[:100]}")
                                if hasattr(self.todo, 'mark_task_permanent_failure'):
                                    self.todo.mark_task_permanent_failure(task.task_id, reroute_reasoning[:200])
                                yield {"module": "Synapse.core.conductor", "message": f"🔴 Task {task.task_id} permanently failed: {reroute_reasoning[:100]}"}
                                # Emit DAG + task list update after permanent failure
                                dag_update = self._build_dag_event_from_todo()
                                if dag_update:
                                    yield dag_update
                                _tl = self._build_task_list_event()
                                if _tl:
                                    yield _tl
                        else:
                            # No LLM available — mark as permanently failed
                            self.todo.fail_task(task.task_id, f"Stuck: repeated {error_type_name} failures, LLM rerouting unavailable")
                            if hasattr(self.todo, 'mark_task_permanent_failure'):
                                self.todo.mark_task_permanent_failure(task.task_id, f"Repeated {error_type_name} failures")
                            yield {"module": "Synapse.core.conductor", "message": f"🔴 Task {task.task_id} permanently failed (LLM rerouting unavailable)"}
                            dag_update = self._build_dag_event_from_todo()
                            if dag_update:
                                yield dag_update
                            _tl = self._build_task_list_event()
                            if _tl:
                                yield _tl
                        continue
                
                # 🔍 A-TEAM: Web search on error for recovery guidance (LLM-based)
                web_search_context = await self._web_search_on_error(
                    e,
                    {
                        'task': task.description,
                        'actor': task.actor,
                        'iteration': iteration
                    }
                )
                if web_search_context and hasattr(self, 'shared_context') and self.shared_context:
                    self.shared_context.set('web_search_context', web_search_context)
                    failure_context['web_search_context'] = web_search_context
                
                # 🔬 A-TEAM ENHANCEMENT: Store failure with outcome for automatic pattern extraction
                # 🔴 A-TEAM FIX: Use _store_memory to populate BOTH shared + local memories
                if hasattr(self, 'shared_memory') and self.shared_memory:
                    try:
                        self._store_memory(
                            content=f"""❌ EXECUTION FAILURE (High Information Event)
Task: {task.description}
Actor: {task.actor}
Error: {type(e).__name__}: {smart_truncate(str(e), max_tokens=125)}
Iteration: {iteration}

This failure contains valuable learning information!
Strategy: Check if recoverable, adapt retry approach.
""",
                            level=MemoryLevel.CAUSAL,
                            context={
                                **failure_context,
                                'web_search_context': self.shared_context.get('web_search_context') if self.shared_context else None,
                                'error_type': type(e).__name__,
                                'task_type': smart_truncate(task.description, max_tokens=50)
                            },
                            goal=goal,
                            actor_name=task.actor,
                            outcome="failure"  # This triggers automatic pattern extraction to semantic memory
                        )
                        logger.info(f"💾 Stored execution failure in memory (outcome=failure) for pattern extraction")
                        # 🧠 Emit memory_update for frontend
                        yield self._build_memory_update_event(
                            content=f"❌ EXEC FAILURE: {task.description} — {type(e).__name__}: {smart_truncate(str(e), max_tokens=80)}",
                            level="episodic", actor=task.actor,
                            context={'actor': task.actor, 'task': task.task_id}
                        )
                    except Exception as mem_error:
                        logger.warning(f"Failed to store execution failure in memory: {mem_error}")
                
                # 🔬 A-TEAM ENHANCEMENT: Trigger consolidation if enough failures accumulated
                # Check if we have enough episodic failures to extract patterns
                episodic_failures = []
                if hasattr(self, 'shared_memory') and self.shared_memory and hasattr(self.shared_memory, 'memories'):
                    try:
                        episodic_failures = [
                            m for m in self.shared_memory.memories.get(MemoryLevel.EPISODIC, {}).values()
                            if m.context.get('failure', False) or 'FAILURE' in m.content
                        ]
                    except (KeyError, AttributeError) as mem_error:
                        logger.warning(f"Failed to access episodic failures for consolidation: {mem_error}")
                        episodic_failures = []
                if len(episodic_failures) >= getattr(self.config, 'min_failures_for_consolidation', 3):
                    logger.info(f"🧠 Triggering consolidation: {len(episodic_failures)} failures accumulated")
                    # Schedule consolidation (non-blocking)
                    if hasattr(self, '_consolidation_task') and not self._consolidation_task.done():
                        pass  # Already consolidating
                    else:
                        self._consolidation_task = asyncio.create_task(
                            self.shared_memory.consolidate()
                        )
                
                # 🔥 A-TEAM FIX: Smart TypeError classification
                # Not all TypeErrors are fatal! Some are recoverable.
                ALWAYS_FATAL_ERRORS = (AttributeError, NameError, ModuleNotFoundError, ImportError)
                
                if isinstance(e, TypeError):
                    # Check if it's a recoverable type error
                    error_msg = str(e)
                    RECOVERABLE_TYPE_ERROR_PATTERNS = [
                        "cannot be used with isinstance",  # Union, generics - Python limitation
                        "got an unexpected keyword argument",  # Parameter mismatch - can filter
                    ]
                    
                    is_recoverable = any(pattern in error_msg for pattern in RECOVERABLE_TYPE_ERROR_PATTERNS)
                    
                    if is_recoverable:
                        logger.warning(f"⚠️  Recoverable TypeError detected: {error_msg[:200]}")
                        logger.info(f"🧠 LEARNING: This error has been stored in memory for future adaptation")
                        logger.info(f"   📦 Marking task as failed, but not stopping execution")
                        self.todo.fail_task(task.task_id, str(e))
                        # 📋 REAL-TIME UI: Emit task_list after recoverable error
                        _tl_recov = self._build_task_list_event()
                        if _tl_recov:
                            yield _tl_recov
                        # Don't re-raise! Continue to next task
                    else:
                        # Truly fatal TypeError (e.g., calling non-callable)
                        logger.critical(f"🔴 FATAL TypeError detected: {error_msg[:200]}")
                        logger.critical("This error indicates a code bug, not a transient issue")
                        if self.persistence_manager:
                            logger.info("💾 Saving state after fatal error (for debugging)")
                            try:
                                self.persistence_manager.save_markovian_todo(self.todo)
                            except Exception as save_error:
                                logger.error(f"Failed to save state after error: {save_error}")
                        self.todo.fail_task(task.task_id, str(e))
                        # 📋 REAL-TIME UI: Emit before fatal re-raise
                        _tl_fatal = self._build_task_list_event()
                        if _tl_fatal:
                            yield _tl_fatal
                        raise  # Re-raise to stop execution
                
                elif isinstance(e, ALWAYS_FATAL_ERRORS):
                    logger.critical(f"🔴 FATAL ERROR detected ({type(e).__name__}), not retrying")
                    logger.critical("This error indicates a code bug, not a transient issue")
                    # Save state for debugging
                    if self.persistence_manager:
                        logger.info("💾 Saving state after fatal error (for debugging)")
                        try:
                            self.persistence_manager.save_markovian_todo(self.todo)
                        except Exception as save_error:
                            logger.error(f"Failed to save state after error: {save_error}")
                    self.todo.fail_task(task.task_id, str(e))
                    # 📋 REAL-TIME UI: Emit before fatal re-raise
                    _tl_fatal2 = self._build_task_list_event()
                    if _tl_fatal2:
                        yield _tl_fatal2
                    raise  # Re-raise to stop execution
                
                else:
                    # Other exceptions - potentially recoverable
                    logger.warning(f"⚠️  Exception during execution: {type(e).__name__}")
                    logger.info(f"🧠 LEARNING: Stored in memory, marking task as failed, continuing")
                    
                    # 📮 DLQ: Add to Dead Letter Queue for potential retry
                    if self.dead_letter_queue:
                        self.dead_letter_queue.add(
                            operation_name=f"{actor_config.name}.execute",
                            args=(actor_config, task, context, kwargs, actor_context_dict),
                            kwargs={},
                            error=e
                        )
                        logger.info(f"📮 Added failed operation to DLQ (queue size: {len(self.dead_letter_queue.queue)})")
                
                # ✅ SAVE STATE BEFORE FAILURE: Preserve state for debugging
                if self.persistence_manager:
                    logger.info("💾 Saving state after error (for debugging)")
                    try:
                        self.persistence_manager.save_markovian_todo(self.todo)
                    except Exception as save_error:
                        logger.error(f"Failed to save state after error: {save_error}")
                
                    self.todo.fail_task(task.task_id, str(e))  # Mark failed, but don't raise
                
                # 🔴 A-TEAM: Re-emit DAG + task list after any exception-path task state change
                dag_update = self._build_dag_event_from_todo()
                if dag_update:
                    yield dag_update
                _tl = self._build_task_list_event()
                if _tl:
                    yield _tl
            
            # ─── GUARANTEED END-OF-ITERATION task_list EMISSION ───────────
            # Ensures the frontend always gets an up-to-date task list,
            # regardless of which execution path was taken in this iteration.
            _tl_eoi = self._build_task_list_event()
            if _tl_eoi:
                yield _tl_eoi
            
            # ─── C2: Consensus-Based Abandonment (near iteration limit) ──────
            # Instead of a hard stop at max_iterations, invoke LLM-based consensus
            # when approaching the ceiling.  Actors negotiate whether remaining tasks
            # are genuinely impossible or if extending iterations would help.
            _near_limit_pct = 0.85  # Check when 85% of ceiling reached
            if (not _consensus_abandonment_checked
                    and iteration >= int(max_iterations * _near_limit_pct)
                    and not all_auditors_passed):
                _consensus_abandonment_checked = True
                try:
                    import json as _json_mod
                    _pending = [
                        t for t in self.todo.subtasks.values()
                        if t.status in (TaskStatus.PENDING, TaskStatus.IN_PROGRESS)
                    ]
                    if _pending:
                        _attempt_history = _json_mod.dumps([
                            {"attempt": s.get("attempt", "?"),
                             "error": smart_truncate(str(s.get("error", "")), max_tokens=60),
                             "approach": smart_truncate(str(s.get("task", "")), max_tokens=60),
                             "outcome": s.get("feedback", "")}
                            for s in self.trajectory[-20:]
                        ], ensure_ascii=True)[:6000]
                        _available_res = _json_mod.dumps(
                            [{"actor": n, "tools": len(getattr(a.agent, "TOOLS", []))}
                             for n, a in self.actors.items()],
                            ensure_ascii=True
                        )[:3000]
                        
                        yield {"module": "Synapse.core.conductor",
                               "message": f"🤝 Approaching iteration ceiling ({iteration}/{max_iterations}). "
                                          f"Invoking consensus negotiation on {len(_pending)} remaining tasks."}
                        
                        from Synapse.signatures.auditor_strategy_signatures import TaskAbandonmentConsensusSignature
                        _abandon_agent = dspy.ChainOfThought(TaskAbandonmentConsensusSignature)
                        _abandon_pred = await asyncio.to_thread(
                            _abandon_agent,
                            task_description=", ".join(t.description[:100] for t in _pending[:5]),
                            attempt_history_json=_attempt_history,
                            actor_assessment=f"Iteration {iteration}/{max_iterations} reached with {len(_pending)} tasks remaining",
                            auditor_assessment=f"Cumulative reward: {cumulative_reward:.3f}. "
                                               f"Completed: {len(self.todo.completed_tasks)}/{len(self.todo.subtasks)}",
                            available_resources=_available_res,
                            user_goal_context=smart_truncate(goal, max_tokens=200),
                        )
                        
                        _should_abandon = str(getattr(_abandon_pred, "consensus_reached", "false")).strip().lower() in ("true", "yes", "1")
                        _rec_action = str(getattr(_abandon_pred, "recommended_action", "continue")).strip().lower()
                        _user_explanation = str(getattr(_abandon_pred, "user_facing_explanation", ""))[:500]
                        _reasoning = str(getattr(_abandon_pred, "reasoning", ""))[:500]
                        
                        yield {"module": "Synapse.core.conductor",
                               "message": f"🤝 Consensus result: abandon={_should_abandon}, action={_rec_action}. {_reasoning[:200]}"}
                        
                        if _should_abandon and _rec_action == "abandon":
                            logger.info(f"🛑 Consensus-based abandonment: {_reasoning[:200]}")
                            # Mark remaining tasks as failed with consensus reason
                            for t in _pending:
                                self.todo.fail_task(t.task_id, f"Consensus abandonment: {_user_explanation[:120]}")
                            all_auditors_passed = True  # Exit loop gracefully
                            _tl_final = self._build_task_list_event()
                            if _tl_final:
                                yield _tl_final
                        elif _rec_action == "escalate_to_user":
                            yield {"module": "Synapse.core.conductor",
                                   "type": "user_escalation",
                                   "message": f"🆘 System recommends user input: {_user_explanation}"}
                        else:
                            # Continue — extend ceiling by 50% to give actors more room
                            _extension = max(20, int(max_iterations * 0.5))
                            max_iterations += _extension
                            _consensus_abandonment_checked = False  # Allow re-check near new ceiling
                            logger.info(f"🔄 Consensus: continue. Extended ceiling to {max_iterations} (+{_extension})")
                            yield {"module": "Synapse.core.conductor",
                                   "message": f"🔄 Extended iteration ceiling to {max_iterations} based on consensus to continue"}
                except Exception as _abandon_err:
                    logger.warning(f"⚠️ Consensus abandonment check failed: {_abandon_err}")
                    # Don't block — the hard ceiling is still there as ultimate safety valve

            # ─── Item 189: Periodic Anomaly Detection ──────────────────────
            if iteration % 3 == 0:  # Check every 3 iterations to avoid per-step overhead
                for anomaly_alert in self._detect_anomalies(iteration, start_time):
                    yield anomaly_alert
            # ───────────────────────────────────────────────────────────────
        
        # Episode complete - update learner
        self.swarm_learner.record_episode(
            self.trajectory,
            outcome=all_auditors_passed,
            insights=[t['feedback'] for t in self.trajectory if t.get('feedback')]
        )
        
        # Update prompts if threshold reached
        # 🔴 A-TEAM FIX: Write updated prompts to versioned directory, not overwriting originals
        # This prevents LLM output from corrupting original prompt files and enables rollback
        if self.swarm_learner.should_update_prompts():
            updated_prompts_dir = None
            if hasattr(self, 'persistence_manager') and self.persistence_manager:
                updated_prompts_dir = self.persistence_manager.run_synapse_dir / "updated_prompts"
                updated_prompts_dir.mkdir(parents=True, exist_ok=True)
            
            for actor_name, actor_config in self.actors.items():
                for prompt_path in actor_config.architect_prompts + actor_config.auditor_prompts:
                    if Path(prompt_path).exists():
                        current = Path(prompt_path).read_text()
                        updated, changes = self.swarm_learner.update_prompt(
                            prompt_path, current
                        )
                        if changes:
                            if updated_prompts_dir:
                                # Save to versioned directory (safe — doesn't overwrite originals)
                                safe_name = Path(prompt_path).name
                                version_path = updated_prompts_dir / f"{safe_name}.v{self.episode_count}"
                                version_path.write_text(updated)
                                logger.info(f"📝 Versioned prompt update saved: {version_path}")
                            else:
                                # Fallback: write to original (legacy behavior)
                                Path(prompt_path).write_text(updated)
                            logger.info(f"📝 Updated prompt: {prompt_path}")
        
        # =====================================================================
        # 🔥 A-TEAM FIX: Drain async Q-learning queue BEFORE save & tiering
        # Previously, async_q_updater.stop() ran AFTER tiering, so pending
        # experiences weren't reflected in the Q-table summary or persistence.
        # =====================================================================
        if self.async_q_updater:
            try:
                await self.async_q_updater.stop()
                logger.info("🔥 ASYNC_Q_LEARNING: Drained & stopped background updater before final save")
            except Exception as e:
                logger.warning(f"Failed to stop async Q-learning updater: {e}")
            self.async_q_updater = None  # Prevent double-stop later

        # =====================================================================
        # FINAL COMPREHENSIVE STATE SAVE (NO HARDCODING)
        # =====================================================================
        if self.persistence_manager:
            self.persistence_manager.save_all(self)
        
        # =====================================================================
        # DEAD LETTER QUEUE: Retry failed operations if system recovered
        # =====================================================================
        if self.dead_letter_queue and len(self.dead_letter_queue.queue) > 0:
            logger.info(f"📮 DLQ: {len(self.dead_letter_queue.queue)} failed operations in queue")
            
            # Only retry if we had overall success (system recovered)
            if all_auditors_passed:
                logger.info("📮 DLQ: System recovered successfully, retrying failed operations...")
                
                def retry_operation(operation_name: str, *args, **kwargs):
                    """Retry a failed operation."""
                    logger.info(f"🔄 DLQ: Retrying {operation_name}...")
                    # Async retry is handled by UniversalRetryHandler in the main execution flow
                    logger.info(f"📮 DLQ: Retry queued for {operation_name} (handled by UniversalRetryHandler)")
                
                stats = self.dead_letter_queue.retry_all(retry_operation)
                logger.info(f"📮 DLQ Retry Stats: {stats}")
            else:
                logger.info("📮 DLQ: System did not fully recover, keeping failed operations for later")
        
        # Episode counter increment
        self.episode_counter += 1
        
        # ✅ A-TEAM: Return typed SwarmResult!
        # Get final output from last actor result (GENERIC - no domain knowledge)
        final_output = None
        if self.io_manager.outputs:
            last_actor = list(self.io_manager.outputs.values())[-1]
            # 🔴 A-TEAM FIX: output_fields can be a string (e.g. when DSPy returns
            # a raw string prediction instead of structured output). Guard with
            # isinstance check to prevent 'str' object has no attribute 'get'.
            _output_fields = getattr(last_actor, 'output_fields', None)
            if isinstance(_output_fields, str):
                # output_fields is a raw string — use it directly as final_output
                logger.info(f"🔍 [FINAL OUTPUT] output_fields is a string ({len(_output_fields)} chars), using directly")
                final_output = _output_fields
            elif isinstance(_output_fields, dict) and _output_fields:
                # Generic field names only - try common patterns
                # Priority: final_output (standard), output (common), result (generic)
                final_output = (
                    _output_fields.get('final_output') or
                    _output_fields.get('output') or
                    _output_fields.get('result')
                )
                
                # 🔍 A-TEAM DEBUG: Log what we found (generic logging)
                logger.info(f"🔍 [FINAL OUTPUT] Last actor: {list(self.io_manager.outputs.keys())[-1]}")
                logger.info(f"🔍 [FINAL OUTPUT] Available fields: {list(_output_fields.keys())}")
                logger.info(f"🔍 [FINAL OUTPUT] Extracted final_output: {final_output is not None} (type={type(final_output).__name__ if final_output is not None else 'None'})")
                if final_output:
                    logger.info(f"🔍 [FINAL OUTPUT] Preview: {str(final_output)[:200]}...")
                
                # 🔴 A-TEAM FIX: LLM-based output extraction instead of field guessing
                if not final_output:
                    try:
                        # Use LLM to intelligently extract the best output
                        # 🔴 A-TEAM FIX: Renamed 'output_fields' to 'actor_outputs_json'
                        # because 'output_fields' clashes with DSPy's internal
                        # Signature.output_fields property, causing:
                        #   "field must be declared with InputField or OutputField"
                        class OutputExtractionSignature(dspy.Signature):
                            """Given an actor's output data and the original goal, extract the most relevant final output.
                            Identify which field(s) contain the actual deliverable vs intermediate reasoning."""
                            goal: str = dspy.InputField(desc="The original user goal")
                            actor_outputs_json: str = dspy.InputField(desc="JSON of all output fields from the actor")
                            extracted_output: str = dspy.OutputField(desc="The most relevant output content that fulfills the goal")
                            selected_field: str = dspy.OutputField(desc="Which field(s) the output came from")
                        
                        extractor = dspy.ChainOfThought(OutputExtractionSignature)
                        fields_json = json.dumps(
                            {k: smart_truncate(str(v), max_tokens=125) for k, v in _output_fields.items() if v},
                            default=str
                        )
                        extraction_result = extractor(
                            goal=smart_truncate(goal, max_tokens=125),
                            actor_outputs_json=smart_truncate(fields_json, max_tokens=750)
                        )
                        if hasattr(extraction_result, 'extracted_output') and extraction_result.extracted_output:
                            final_output = extraction_result.extracted_output
                            logger.info(f"🔍 [FINAL OUTPUT] LLM extracted from '{getattr(extraction_result, 'selected_field', 'unknown')}' field")
                    except Exception as llm_err:
                        logger.warning(f"⚠️ LLM output extraction failed: {llm_err}, falling back to heuristic")
                        # Fallback: combine all text fields
                        text_fields = []
                        for key, value in _output_fields.items():
                            if isinstance(value, str) and value and not key.startswith('_') and key not in ['commands', 'collaboration_actions']:
                                text_fields.append(f"{key}: {value}")
                        if text_fields:
                            final_output = "\n\n".join(text_fields)
                            logger.info(f"🔍 [FINAL OUTPUT] Fallback: Combined {len(text_fields)} text fields")
                    
                    if final_output:
                        logger.info(f"🔍 [FINAL OUTPUT] Constructed output (length={len(str(final_output))}): {str(final_output)[:200]}...")
        
        # =====================================================================
        # 🧠 NEUROCHUNK MEMORY MANAGEMENT: Tier memories at end of episode
        # =====================================================================
        if hasattr(self, 'q_learner') and self.q_learner:
            try:
                episode_reward = cumulative_reward
                _pre_tier_q_size = len(self.q_learner.Q)
                logger.info(f"🧠 Tiering Q-Learning memories (NeuroChunk)... "
                           f"[pre-tier Q size={_pre_tier_q_size}, "
                           f"q_learner is q_predictor={self.q_learner is self.q_predictor}]")
                
                # Promote/demote memories between tiers based on retention scores
                self.q_learner._promote_demote_memories(episode_reward=episode_reward)
                
                # Prune Tier 3 using causal impact scoring (every episode)
                # Sample 10% for efficiency
                self.q_learner.prune_tier3_by_causal_impact(sample_rate=0.1)
                
                _post_tier_q_size = len(self.q_learner.Q)
                if _post_tier_q_size < _pre_tier_q_size:
                    logger.warning(f"⚠️ Q-table pruned: {_pre_tier_q_size} → {_post_tier_q_size} entries")
                
                # Log memory statistics
                summary = self.q_learner.get_q_table_summary()
                logger.info(f"🧠 Q-Table Stats:")
                logger.info(f"   Total entries: {summary['size']}")
                logger.info(f"   Tier 1 (Working): {summary.get('tier1_size', 0)} memories")
                logger.info(f"   Tier 2 (Clusters): {summary.get('tier2_clusters', 0)} clusters")
                logger.info(f"   Tier 3 (Archive): {summary.get('tier3_size', 0)} memories")
                logger.info(f"   Tier 1 threshold: {summary.get('tier1_threshold', 0.8):.3f}")
                logger.info(f"   Avg Q-value: {summary.get('avg_value', 0.0):.3f}")
                
            except Exception as e:
                logger.warning(f"⚠️  NeuroChunk memory tiering failed: {e}")
        # =====================================================================
        
        # Determine success using BOTH auditor signal and terminal task state.
        # Actor output buffers can be empty in some valid execution paths, so
        # success must not depend solely on io_manager outputs.
        actor_outputs = self.io_manager.get_all_outputs()
        # 🔴 A-TEAM FIX: get_state_summary() returns a str, not a dict.
        # Extract counts directly from MarkovianTODO attributes.
        _tasks_total = len(self.todo.subtasks) if hasattr(self, "todo") and self.todo and hasattr(self.todo, 'subtasks') else 0
        _tasks_completed = len(self.todo.completed_tasks) if hasattr(self, "todo") and self.todo and hasattr(self.todo, 'completed_tasks') else 0
        _tasks_failed = len(self.todo.failed_tasks) if hasattr(self, "todo") and self.todo and hasattr(self.todo, 'failed_tasks') else 0
        _tasks_skipped = sum(
            1 for t in self.todo.subtasks.values() if t.status == TaskStatus.SKIPPED
        ) if hasattr(self, "todo") and self.todo and hasattr(self.todo, 'subtasks') else 0
        _terminal_success = (
            _tasks_total > 0
            and _tasks_failed == 0
            and (_tasks_completed + _tasks_skipped) >= _tasks_total
        )
        _has_output_signal = bool(actor_outputs) or bool(final_output)
        success = bool(all_auditors_passed) and (_has_output_signal or _terminal_success)
        logger.info(
            f"✅ Success evaluation | auditors_passed={bool(all_auditors_passed)} | "
            f"has_output_signal={_has_output_signal} | terminal_success={_terminal_success} | "
            f"tasks={_tasks_completed}/{_tasks_total} failed={_tasks_failed}"
        )

        # If run is successful but explicit final_output is missing, synthesize
        # a concise final output from terminal completed tasks.
        if success and not final_output:
            try:
                _recent_completed = list(getattr(self.todo, "completed_tasks", []))[-5:]
                _summaries = []
                for _tid in _recent_completed:
                    _t = self.todo.subtasks.get(_tid)
                    if not _t:
                        continue
                    _desc = str(getattr(_t, "description", ""))[:120]
                    _res = getattr(_t, "result", None)
                    _res_preview = ""
                    if _res is not None:
                        _res_preview = smart_truncate(str(_res), max_tokens=100)
                    _summaries.append(f"- {_tid}: {_desc}" + (f"\n  result: {_res_preview}" if _res_preview else ""))
                if _summaries:
                    final_output = "Run completed successfully. Completed tasks:\n" + "\n".join(_summaries)
                    logger.info("🧩 Synthesized fallback final_output from completed task results")
            except Exception as _final_err:
                logger.debug(f"Fallback final_output synthesis skipped: {_final_err}")
        
        # =====================================================================
        # 🎯 NASH BARGAINING CREDIT ASSIGNMENT (TODO 3)
        # =====================================================================
        if success and self.agent_slack and hasattr(self.agent_slack, 'get_cooperation_stats'):
            try:
                coop_stats = self.agent_slack.get_cooperation_stats()
                
                if coop_stats.get('total_events', 0) > 0:
                    logger.info(f"🎯 Nash Bargaining: Distributing credit for {coop_stats['total_events']} cooperation events")
                    
                    # Prepare agent contributions - A-TEAM FIX: Include TASK COMPLETION data, not just cooperation metrics
                    agents_and_contributions = []
                    for agent_name in self.actors.keys():
                        agent_steps = [t for t in self.trajectory if t.get('actor') == agent_name]
                        tasks_completed = len([t for t in agent_steps if t.get('reward', 0) > 0.3])
                        tasks_failed = len([t for t in agent_steps if t.get('reward', 0) <= 0.3])
                        avg_quality = sum(t.get('reward', 0) for t in agent_steps) / max(len(agent_steps), 1)
                        
                        contribution = {
                            'agent': agent_name,
                            'actions_taken': len(agent_steps),
                            'tasks_completed_successfully': tasks_completed,  # A-TEAM: Track actual completions
                            'tasks_failed': tasks_failed,  # A-TEAM: Track failures too
                            'average_quality': round(avg_quality, 3),  # A-TEAM: Quality of work done
                            'help_given': coop_stats.get('help_given', {}).get(agent_name, 0),
                            'help_received': coop_stats.get('help_received', {}).get(agent_name, 0),
                            'messages_sent': coop_stats.get('messages_sent', {}).get(agent_name, 0),
                            'knowledge_shared': coop_stats.get('knowledge_shared', {}).get(agent_name, 0),
                            'produced_output': any(t.get('result') for t in agent_steps)  # A-TEAM: Did it produce actual output?
                        }
                        agents_and_contributions.append(contribution)
                    
                    # Calculate Nash Bargaining solution
                    # 🔴 A-TEAM FIX: assign_credit() expects (trajectory: ActualTrajectory, 
                    #   predictions: Dict[str, PredictedTrajectory], final_reward: float)
                    # Previously called with wrong kwargs (agents=, system_reward=, cooperation_history=)
                    if self.cooperative_credit:
                        try:
                            actual_trajectory = ActualTrajectory(
                                steps=[
                                    {
                                        'agent': contrib['agent'],
                                        'success': contrib['average_quality'] > 0.3,
                                        'actions_taken': contrib['actions_taken'],
                                        'help_given': contrib.get('help_given', 0),
                                        'help_received': contrib.get('help_received', 0),
                                    }
                                    for contrib in agents_and_contributions
                                ],
                                actual_reward=cumulative_reward,
                            )
                            # 🔴 A-TEAM FIX: Use accumulated per-agent predictions (was typo: _last_predictions vs _last_prediction)
                            stored_predictions = getattr(self, '_agent_predictions', {})
                            reward_distribution = self.cooperative_credit.assign_credit(
                                trajectory=actual_trajectory,
                                predictions=stored_predictions,
                                final_reward=cumulative_reward,
                            )
                        except Exception as credit_err:
                            logger.warning(f"⚠️ assign_credit failed, using equal distribution: {credit_err}")
                            # Fallback: equal distribution
                            n_agents = max(len(agents_and_contributions), 1)
                            reward_distribution = {
                                c['agent']: cumulative_reward / n_agents
                                for c in agents_and_contributions
                            }
                        
                        # 🔬 A-TEAM v9.0: Record episode for variance tracking
                        self.cooperative_credit.record_episode(reward_distribution)
                        
                        logger.info(f"🎯 Nash Bargaining Reward Distribution:")
                        for agent, reward in reward_distribution.items():
                            logger.info(f"   {agent}: {reward:.3f}")
                            
                            # Store individual rewards in Q-learning
                            if self.q_learner:
                                # 🔴 A-TEAM FIX: Include per-agent contribution details
                                # for richer state representation in Q-table
                                _agent_contrib = next(
                                    (c for c in agents_and_contributions if c.get('agent') == agent),
                                    {}
                                )
                                _nash_exp = dict(
                                    state={
                                        'agent': agent, 
                                        'task': goal, 
                                        'collaborated': True,
                                        'query': smart_truncate(goal, max_tokens=500),
                                        'collaboration_agents': list(reward_distribution.keys()),
                                        'agent_contribution': {
                                            'tasks_completed': _agent_contrib.get('tasks_completed_successfully', 0),
                                            'tasks_failed': _agent_contrib.get('tasks_failed', 0),
                                            'avg_quality': _agent_contrib.get('average_quality', 0),
                                            'help_given': _agent_contrib.get('help_given', 0),
                                            'help_received': _agent_contrib.get('help_received', 0),
                                            'produced_output': _agent_contrib.get('produced_output', False),
                                        },
                                        'todo': {
                                            'completed': len(self.todo.completed_tasks) if self.todo else 0,
                                            'pending': len([t for t in self.todo.subtasks.values() if t.status == TaskStatus.PENDING]) if self.todo else 0,
                                        }
                                    },
                                    action={
                                        'type': 'collaboration', 
                                        'agent': agent, 
                                        'goal': smart_truncate(goal, max_tokens=200),
                                        'actions_taken': _agent_contrib.get('actions_taken', 0),
                                    },
                                    reward=reward,
                                    next_state={
                                        'agent': agent, 
                                        'task': goal, 
                                        'completed': True,
                                        'collaboration_reward': reward,
                                        'total_system_reward': cumulative_reward,
                                    },
                                    done=True
                                )
                                # Use async updater to avoid blocking LLM call
                                if self.async_q_updater:
                                    await self.async_q_updater.queue_experience(**_nash_exp)
                                else:
                                    self.q_learner.add_experience(**_nash_exp)
                        
                        logger.info(f"✅ Nash Bargaining credit assignment complete")
                
            except Exception as e:
                logger.warning(f"⚠️ Nash Bargaining credit assignment failed: {e}")
        # =====================================================================
        
        # =====================================================================
        # 📊 CONFIG LEARNING: Record episode and update configs (TODO 9)
        # =====================================================================
        if self.config_learner:
            try:
                # Record episode performance
                self.config_learner.record_episode(
                    config=self.config.__dict__ if hasattr(self.config, '__dict__') else {},
                    performance={
                        'success': success,
                        'reward': cumulative_reward,
                        'time': time.time() - start_time,
                        'error': None if success else 'Task failed',
                        'iterations': iteration
                    }
                )
                
                # Learn and apply updates periodically
                if self.episode_counter % 20 == 0 and self.config_learner.should_update_config():
                    logger.info(f"📊 Learning config updates from {len(self.config_learner.performance_history)} episodes")
                    
                    updates = self.config_learner.learn_config_updates()
                    
                    if updates and getattr(self.config, 'auto_apply_config_updates', False):
                        self.config_learner.apply_updates(updates, auto_apply=False, confidence_threshold=0.8)
                        logger.info(f"✅ Config updates applied")
                    elif updates:
                        logger.info(f"📊 Config updates available but auto_apply disabled")
                
            except Exception as e:
                logger.warning(f"⚠️ Config learning failed: {e}")
        # =====================================================================
        
        # 🔴 CRITICAL FIX: Cooperative Reward Distribution (Nash Bargaining)
        logger.info("🤝 Distributing cooperative rewards among agents...")
        agent_contributions = {}
        for step in self.trajectory:
            actor = step.get('actor')
            if actor:
                if actor not in agent_contributions:
                    agent_contributions[actor] = {
                        'tasks_completed': 0,
                        'total_reward': 0.0,
                        'actions': []
                    }
                agent_contributions[actor]['tasks_completed'] += 1
                agent_contributions[actor]['total_reward'] += step.get('reward', 0.0)
                agent_contributions[actor]['actions'].append(step.get('task', ''))
        
        # Use CooperationReasoner for fair reward distribution
        distributed_rewards = self.cooperation_reasoner.distribute_rewards(
            agents=list(agent_contributions.keys()),
            system_reward=cumulative_reward,
            trajectory=self.trajectory,
            contributions=agent_contributions
        )
        
        logger.info(f"  📊 Cooperative reward distribution: {distributed_rewards}")
        
        # Store distributed rewards in metadata
        cooperation_metadata = {
            'distributed_rewards': distributed_rewards,
            'agent_contributions': agent_contributions,
            'cooperation_principles_applied': True
        }
        
        total_duration = time.time() - start_time
        logger.info(f"⏱️ [CONDUCTOR RUN COMPLETE] Conductor.run | total_duration={total_duration:.3f}s | episode={self.episode_count}")
        
        # =================================================================
        # 🔥 A-TEAM FIX #1: TD(λ) LEARNING UPDATE (CRITICAL)
        # =================================================================
        # Richard Sutton + David Silver: "TD(λ) requires end_episode() to 
        # propagate rewards backward through eligibility traces. Without this,
        # temporal credit assignment is completely broken."
        #
        # This call enables the system to learn from delayed rewards and
        # temporal dependencies - critical for multi-step reasoning tasks.
        # =================================================================
        try:
            if hasattr(self, 'td_learner') and self.td_learner:
                # Calculate final episode reward based on overall success
                final_reward = self._calculate_episode_reward(
                    success=success,
                    cumulative_reward=cumulative_reward,
                    target_reward=target_reward,
                    iterations=iteration,
                    max_iterations=max_iterations
                )
                
                # 🔥 CRITICAL: Call end_episode to propagate rewards via eligibility traces
                # Flatten hierarchical memory for TD learner
                all_memories = {}
                if hasattr(self, 'shared_memory') and self.shared_memory:
                    for level in self.shared_memory.memories:
                        all_memories.update(self.shared_memory.memories[level])
                
                self.td_learner.end_episode(
                    final_reward=final_reward,
                    memories=all_memories,
                    goal_hierarchy=self.goal_hierarchy if hasattr(self, 'goal_hierarchy') else None
                )
                logger.info(f"✅ TD(λ) learning updated via end_episode(): final_reward={final_reward:.3f}, memories={len(all_memories)}")
                
                # Persist TD(λ) state for cross-session learning
                if hasattr(self, 'persistence_manager') and self.persistence_manager:
                    try:
                        self.persistence_manager.save_td_lambda_state(self.td_learner)
                        logger.debug("✅ TD(λ) state persisted")
                    except Exception as persist_err:
                        logger.warning(f"⚠️ TD(λ) persistence failed: {persist_err}")
        
        except Exception as e:
            # Don't fail the entire run if TD(λ) update fails - just log it
            logger.error(f"❌ TD(λ) update failed: {e}", exc_info=True)
            yield {"module": "Synapse.core.conductor", "message": f"I encountered an error during TD(λ) update: {str(e)}"}
        
        # =====================================================================
        # 🆕 A-TEAM: Generate user-friendly communication using UserCommunicationAgent
        # =====================================================================
        user_message = None
        user_message_type = None
        suggested_actions = []
        detailed_answer = None  # 🆕 A-TEAM: Detailed markdown for "View More" modal
        
        if self.user_communication_agent:
            try:
                yield {"module": "Synapse.core.conductor", "message": "I am generating a user-friendly summary of the results"}
                
                # Build context for communication agent
                task_status = "completed" if success else "failed"
                error_context = ""
                if not success and self.trajectory:
                    # Find the last error in trajectory
                    for step in reversed(self.trajectory):
                        if step.get('error'):
                            error_context = f"Error: {step.get('error')}"
                            break
                
                context_parts = [
                    f"Status: {task_status}",
                    f"Success: {success}",
                    f"Iterations: {iteration}",
                    f"Execution time: {time.time() - start_time:.2f}s",
                ]
                
                if final_output:
                    # 🔴 A-TEAM FIX: Token-aware truncation for UserCommunicationAgent context
                    output_preview = smart_truncate(str(final_output), max_tokens=500)
                    context_parts.append(f"Output preview: {output_preview}")
                
                if error_context:
                    context_parts.append(error_context)
                
                if actor_outputs:
                    context_parts.append(f"Actors involved: {', '.join(actor_outputs.keys())}")
                
                communication_context = "\n".join(context_parts)
                
                # Generate user communication
                communication = self.user_communication_agent.generate(
                    task_description=goal,
                    context=communication_context
                )
                
                user_message = communication.message
                user_message_type = communication.communication_type
                suggested_actions = communication.suggested_actions
                detailed_answer = communication.detailed_answer
                
                logger.info(f"💬 User communication generated: [{user_message_type}] {user_message[:100]}...")
                if detailed_answer:
                    logger.info(f"📄 Detailed answer included ({len(detailed_answer)} chars)")
                yield {"module": "Synapse.core.conductor", "message": f"Generated user communication: {user_message}"}
                
            except Exception as comm_err:
                logger.warning(f"⚠️ UserCommunicationAgent failed: {comm_err}")
                # Fallback to consciousness-like message
                if success:
                    user_message = "I've finished what you asked. Everything went smoothly."
                    user_message_type = "COMPLETION"
                else:
                    user_message = "I ran into some difficulties while working on this. Let me know if you'd like me to try a different approach."
                    user_message_type = "ERROR"
        else:
            # No agent available - use consciousness-like fallback
            if success:
                user_message = "I've finished what you asked. Everything went smoothly."
                user_message_type = "COMPLETION"
            else:
                user_message = "I ran into some difficulties while working on this. Let me know if you'd like me to try a different approach."
                user_message_type = "ERROR"
        # =====================================================================
        
        final_result = SwarmResult(
            success=success,
            final_output=final_output,
            actor_outputs=actor_outputs,
            trajectory=self.trajectory,
            metadata={
                'iterations': iteration,
                'cumulative_reward': cumulative_reward,
                'todo_state': self.todo.get_state_summary(),
                'execution_time': time.time() - start_time,
                'exploration_count': self.policy_explorer.exploration_count,
                'run_dir': output_dir,
                **cooperation_metadata,  # Include cooperative reward distribution
            },
            user_message=user_message,
            user_message_type=user_message_type,
            suggested_actions=suggested_actions,
            detailed_answer=detailed_answer  # 🆕 A-TEAM: Markdown for "View More" modal
        )
        
        execution_time = time.time() - start_time
        logger.info(f"✅ Conductor run completed | success={success} | iterations={iteration} | duration={execution_time:.3f}s")
        
        # 🎯 Log final output clearly
        if final_output:
            logger.info(f"🎯 FINAL SWARM OUTPUT: {str(final_output)[:500]}{'...' if len(str(final_output)) > 500 else ''}")
        else:
            logger.warning(f"⚠️ No final output extracted from actor outputs")
        
        # 💬 Log user-friendly message
        if user_message:
            logger.info(f"💬 USER MESSAGE [{user_message_type}]: {user_message}")
        
        yield {"module": "Synapse.core.conductor", "message": f"I have completed the conductor run with success={success} after {iteration} iterations in {execution_time:.2f} seconds"}
        
        # Convert SwarmResult to JSON-serializable dict
        from dataclasses import asdict
        
        def convert_to_json_serializable(obj, _depth=0, _max_depth=8):
            """Recursively convert objects to JSON-serializable format (depth-limited)."""
            if _depth > _max_depth:
                return f"<{type(obj).__name__} (depth limit)>"
            if isinstance(obj, (str, int, float, bool, type(None))):
                return obj
            elif isinstance(obj, dict):
                return {str(k): convert_to_json_serializable(v, _depth + 1, _max_depth) for k, v in list(obj.items())[:100]}
            elif isinstance(obj, (list, tuple)):
                return [convert_to_json_serializable(item, _depth + 1, _max_depth) for item in obj[:200]]
            elif hasattr(obj, '__dataclass_fields__'):
                # Handle dataclasses
                return convert_to_json_serializable(asdict(obj), _depth + 1, _max_depth)
            elif hasattr(obj, '_store') and isinstance(getattr(obj, '_store', None), dict):
                # DSPy Prediction
                return {'_type': 'DSPyPrediction', '_store': convert_to_json_serializable(obj._store, _depth + 1, _max_depth)}
            elif hasattr(obj, '__dict__'):
                # Handle objects with __dict__
                return convert_to_json_serializable(
                    {k: v for k, v in vars(obj).items() if not k.startswith('_') and not callable(v)},
                    _depth + 1, _max_depth
                )
            else:
                # Fallback: convert to string representation
                try:
                    return str(obj)[:2000]
                except Exception:
                    return f"<{type(obj).__name__}>"
        
        # 🔥 A-TEAM: Async Q-Learning updater already drained before save/tiering.
        # Guard: stop if still running (shouldn't happen with None guard above).
        if self.async_q_updater:
            try:
                await self.async_q_updater.stop()
                logger.info("🔥 ASYNC_Q_LEARNING: Late stop (backup guard)")
            except Exception as e:
                logger.debug(f"Async Q-learning updater already stopped: {e}")
        
        # 💾 FINAL PERSISTENCE: Save all state before returning
        if self.persistence_manager:
            try:
                self.persistence_manager.save_all(self)
                logger.info("💾 Final state saved successfully")
                yield {"module": "Synapse.core.conductor", "message": "Final state persisted (Q-values, memory, TODO)"}
            except Exception as e:
                logger.warning(f"Failed to save final state: {e}")
        
        # ─── Run Summary Report (Item 181) ──────────────────────────────
        try:
            todo_state = self.todo.get_state_summary() if hasattr(self.todo, 'get_state_summary') else {}
            completed_count = len(self.todo.completed_tasks)
            failed_count = len(self.todo.failed_tasks) if hasattr(self.todo, 'failed_tasks') else 0
            total_tasks = len(self.todo.subtasks) if hasattr(self.todo, 'subtasks') else 0
            retry_count = sum(
                getattr(st, 'attempts', 0) for st in (self.todo.subtasks.values() if hasattr(self.todo, 'subtasks') else [])
            )
            fan_out_count = getattr(self, '_fan_out_count', 0)
            memory_event_count = self._event_seq
            
            # Lifecycle telemetry
            lifecycle_summary = {}
            try:
                from .llm_gateway import get_gateway_telemetry
                telemetry = get_gateway_telemetry()
                lifecycle_summary = telemetry.summary()
            except Exception:
                pass
            
            run_summary = {
                "tasks_completed": completed_count,
                "tasks_failed": failed_count,
                "tasks_total": total_tasks,
                "total_retries": retry_count,
                "fan_out_count": fan_out_count,
                "total_events_emitted": memory_event_count,
                "execution_time_seconds": round(execution_time, 2),
                "iterations": iteration,
                "cumulative_reward": round(cumulative_reward, 4) if isinstance(cumulative_reward, (int, float)) else 0,
                "success": success,
                "gateway_lifecycle": lifecycle_summary,
            }
            
            yield {
                "module": "Synapse.core.conductor",
                "type": "run_summary",
                "message": f"Run complete: {completed_count}/{total_tasks} tasks, {failed_count} failed, {iteration} iterations in {execution_time:.1f}s",
                "data": run_summary
            }
            logger.info(f"📊 Run Summary: {json.dumps(run_summary, indent=2, default=str)}")
        except Exception as e:
            logger.warning(f"Failed to build run summary: {e}")
        
        # 🛑 Final environment summarization + stop background threads.
        # This MUST happen here (while litellm/dspy thread pools are still alive)
        # rather than in the atexit handler (where pools are already shut down).
        if self.env_manager:
            try:
                if self.env_manager.env_file.exists():
                    file_size = self.env_manager.env_file.stat().st_size
                    if file_size > self.env_manager.max_size_before_summarize:
                        logger.info("🗜️  Triggering final environment summarization before exit...")
                        self.env_manager.force_summarize()
                self.env_manager.stop_auto_summarization()
                logger.info("🛑 Environment Manager stopped at end of run")
            except Exception as e:
                logger.debug(f"⚠️ Failed to stop EnvironmentManager: {e}")
        
        # Convert SwarmResult to dict
        result_dict = convert_to_json_serializable(final_result)
        yield {"type": "result", "result": result_dict, "module": "Synapse.core.conductor", "message": "I am returning the final execution result"}
        
        return
    
    async def _initialize_todo_from_goal_stream(self, goal: str, kwargs: Dict) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Initialize TODO items from goal using Synapse_new multi-agent flow.
        
        🆕 SYNAPSE_NEW INTEGRATION: Uses TaskBreakdownAgent + TodoCreatorAgent
        
        Flow:
        1. TaskBreakdownAgent: Break goal into TaskDAG (Chain of Thought)
        2. TodoCreatorAgent: Validate DAG and assign actors (ReAct)
        3. Convert ExecutableDAG to MarkovianTODO for execution
        
        Fallback: If Synapse_new agents unavailable, use old DynamicTaskPlanner flow
        
        Yields:
            Event dictionaries with module and conversational message
        """
        yield {"module": "Synapse.core.conductor", "message": f"I am initializing TODO items from goal: {goal[:100] if len(goal) > 100 else goal}"}
        synapse_new_failure_reason = None
        # =====================================================================
        # 🆕 SYNAPSE_NEW FLOW: TaskBreakdownAgent + TodoCreatorAgent
        # =====================================================================
        if self.task_breakdown_agent and self.todo_creator_agent:
            try:
                import time
                from Synapse.agents import Actor
                
                logger.info("🆕 Using Synapse_new multi-agent TODO breakdown flow")
                yield {"module": "Synapse.core.conductor", "message": "I am using Synapse_new multi-agent TODO breakdown flow"}
                
                # Step 1: Break down goal into TaskDAG using Chain of Thought
                logger.info(f"📋 Step 1: TaskBreakdownAgent analyzing goal: {goal[:100]}...")
                yield {"module": "Synapse.core.conductor", "message": f"I am starting Step 1: TaskBreakdownAgent analyzing goal"}
                breakdown_start = time.time()
                
                # Wrap goal with environment context
                enhanced_goal = self._wrap_instruction_with_env_context(goal)
                logger.info(f"🌍 Wrapped goal with environment context ({len(enhanced_goal) - len(goal)} chars added)")
                yield {"module": "Synapse.core.conductor", "message": f"I wrapped the goal with environment context ({len(enhanced_goal) - len(goal)} chars added)"}
                
                yield {"module": "Synapse.core.conductor", "message": "I am calling TaskBreakdownAgent to break down the goal"}
                # 🔴 A-TEAM FIX: Run synchronous LLM call in thread executor to avoid blocking async event loop
                # This allows events to be yielded while the LLM is processing
                task_dag = await asyncio.to_thread(
                    self.task_breakdown_agent.forward,
                    enhanced_goal
                )
                
                breakdown_duration = time.time() - breakdown_start
                logger.info(f"⏱️ [TASK BREAKDOWN] Duration={breakdown_duration:.3f}s | Tasks={len(task_dag.tasks)}")
                yield {"module": "Synapse.core.conductor", "message": f"I completed task breakdown in {breakdown_duration:.3f}s, got {len(task_dag.tasks)} tasks"}
                
                # Count total dependencies across all tasks
                total_deps = sum(len(task.depends_on) for task in task_dag.tasks.values())
                logger.info(f"📋 TaskDAG created: {len(task_dag.tasks)} tasks, {total_deps} dependencies")
                yield {"module": "Synapse.core.conductor", "message": f"I created a TaskDAG with {len(task_dag.tasks)} tasks and {total_deps} dependencies"}
                
                # 🔴 A-TEAM AUDIT FIX: Store task_dag for later re-emission
                self._task_dag = task_dag
                
                # 🎯 EMIT DAG for frontend visualization
                dag_event = self._build_dag_event(task_dag)
                if dag_event:
                    yield dag_event
                
                # Step 2: Create Actor list from available agents
                actors = []
                for name, config in self.actors.items():
                    if config.enabled:
                        capabilities = config.capabilities or []
                        if not capabilities and config.metadata:
                            capabilities = config.metadata.get('capabilities', [])
                        
                        actors.append(Actor(
                            name=name,
                            capabilities=capabilities,
                            description=self._get_agent_description(name, config)
                        ))
                
                logger.info(f"🤖 Created {len(actors)} actors for assignment")
                yield {"module": "Synapse.core.conductor", "message": f"I created {len(actors)} actors for assignment"}
                
                # Step 3: Validate DAG and assign actors using ReAct
                logger.info("✅ Step 2: TodoCreatorAgent validating DAG and assigning actors...")
                yield {"module": "Synapse.core.conductor", "message": "I am starting Step 2: TodoCreatorAgent validating DAG and assigning actors"}
                assignment_start = time.time()
                
                # Convert Actor objects to dicts format expected by create_executable_dag
                available_actors_dicts = [
                    {
                        'name': actor.name,
                        'capabilities': actor.capabilities,
                        'description': actor.description
                    }
                    for actor in actors
                ]
                
                yield {"module": "Synapse.core.conductor", "message": "I am calling TodoCreatorAgent to create executable DAG"}
                # 🔴 A-TEAM FIX: Run synchronous LLM call in thread executor to avoid blocking async event loop
                # This allows events to be yielded while the LLM is processing
                executable_dag = await asyncio.to_thread(
                    self.todo_creator_agent.create_executable_dag,
                    task_dag,
                    available_actors_dicts
                )
                
                assignment_duration = time.time() - assignment_start
                logger.info(f"⏱️ [ACTOR ASSIGNMENT] Duration={assignment_duration:.3f}s | Assignments={len(executable_dag.assignments)}")
                yield {"module": "Synapse.core.conductor", "message": f"I completed actor assignment in {assignment_duration:.3f}s, got {len(executable_dag.assignments)} assignments"}
                
                if not executable_dag.validation_passed:
                    logger.warning(f"⚠️  DAG validation found issues: {executable_dag.validation_issues}")
                    yield {"module": "Synapse.core.conductor", "message": f"I found DAG validation issues: {executable_dag.validation_issues}"}
                    if executable_dag.fixes_applied:
                        logger.info(f"🔧 Applied fixes: {executable_dag.fixes_applied}")
                        yield {"module": "Synapse.core.conductor", "message": f"I applied fixes: {executable_dag.fixes_applied}"}
                
                # Step 4: Convert ExecutableDAG to MarkovianTODO
                logger.info("🔄 Step 3: Converting ExecutableDAG to MarkovianTODO...")
                yield {"module": "Synapse.core.conductor", "message": "I am starting Step 3: Converting ExecutableDAG to MarkovianTODO"}
                conversion_start = time.time()
                
                self._convert_executable_dag_to_todo(executable_dag)
                
                conversion_duration = time.time() - conversion_start
                logger.info(f"⏱️ [DAG CONVERSION] Duration={conversion_duration:.3f}s")
                yield {"module": "Synapse.core.conductor", "message": f"I completed DAG conversion in {conversion_duration:.3f}s"}
                
                total_duration = breakdown_duration + assignment_duration + conversion_duration
                logger.info(f"✅ Synapse_new flow complete | Total={total_duration:.3f}s | Tasks={len(task_dag.tasks)}")
                yield {"module": "Synapse.core.conductor", "message": f"I completed Synapse_new flow in {total_duration:.3f}s with {len(task_dag.tasks)} tasks"}
                
                # 🌍 Track TODO creation completion in environment with full TODO structure
                if self.env_manager:
                    try:
                        # Build complete TODO structure for environment (NO TRUNCATION)
                        todo_structure = []
                        todo_structure.append("✅ TODO creation complete:")
                        todo_structure.append(f"  - Tasks created: {len(task_dag.tasks)}")
                        todo_structure.append(f"  - Actor assignments: {len(executable_dag.assignments)}")
                        todo_structure.append(f"  - DAG validation: {'✅ Passed' if executable_dag.validation_passed else '⚠️ Issues found'}")
                        todo_structure.append(f"  - Total duration: {total_duration:.3f}s")
                        todo_structure.append("\n📋 **TODO Task List:**")
                        
                        # Add each task with full details
                        for task_id, task in task_dag.tasks.items():
                            actor = executable_dag.assignments.get(task_id)
                            actor_name = actor.name if actor else "Unassigned"
                            
                            # 🔧 FIX: Ensure all values are strings to prevent type errors
                            task_name = str(task.name) if task.name else "Unnamed"
                            task_type_value = str(task.task_type.value) if hasattr(task.task_type, 'value') else str(task.task_type)
                            task_description = str(task.description) if task.description else "No description"
                            
                            todo_structure.append(f"\n  **Task {task_id}:** {task_name}")
                            todo_structure.append(f"    - Actor: {actor_name}")
                            todo_structure.append(f"    - Type: {task_type_value}")
                            todo_structure.append(f"    - Description: {task_description}")
                            
                            if task.depends_on:
                                # 🔧 FIX: Ensure dependencies are strings (they should be, but defensive programming)
                                deps_list = [str(dep) for dep in task.depends_on]
                                todo_structure.append(f"    - Dependencies: {', '.join(deps_list)}")
                        
                        # Add execution stages info
                        stages = task_dag.get_execution_stages()
                        todo_structure.append(f"\n  **Execution Plan:** {len(stages)} stages")
                        for i, stage in enumerate(stages, 1):
                            # 🔧 FIX: get_execution_stages() returns List[List[Task]], so convert Task objects to IDs
                            stage_task_ids = [task.id for task in stage]
                            todo_structure.append(f"    Stage {i}: {', '.join(stage_task_ids)}")
                        
                        async for event in self.env_manager.add_to_current_env_stream("\n".join(todo_structure)):
                            yield event
                        logger.info(f"✅ Tracked complete TODO structure in environment ({len(todo_structure)} lines)")
                        yield {"module": "Synapse.core.conductor", "message": f"I tracked complete TODO structure in environment ({len(todo_structure)} lines)"}
                    except Exception as e:
                        logger.warning(f"Failed to track TODO creation in environment: {e}")
                        yield {"module": "Synapse.core.conductor", "message": f"I encountered a warning while tracking TODO creation: {str(e)}"}
                
                # 🔍 DEBUG: Yield complete task list for frontend debugging
                try:
                    all_tasks = self.todo.get_all_tasks_list()
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"I have created {len(all_tasks)} tasks in total",
                        "type": "task_list",
                        "data": {
                            "total_tasks": len(all_tasks),
                            "tasks": all_tasks,
                            "root_task": self.todo.root_task,
                            "completed_count": len(self.todo.completed_tasks),
                            "failed_count": len(self.todo.failed_tasks) if hasattr(self.todo, 'failed_tasks') else 0
                        }
                    }
                    logger.info(f"🔍 Yielded complete task list: {len(all_tasks)} tasks")
                except Exception as e:
                    logger.warning(f"Failed to yield task list: {e}")
                
                return  # Success - exit early
                
            except Exception as e:
                logger.error(f"❌ Synapse_new flow failed: {e}")
                yield {"module": "Synapse.core.conductor", "message": f"I encountered an error in Synapse_new flow: {str(e)}"}
                import traceback
                logger.error(f"Traceback: {traceback.format_exc()}")
                synapse_new_failure_reason = str(e)
                # Fall through to fallback
        
        # =====================================================================
        # FALLBACK: Use old DynamicTaskPlanner flow
        # =====================================================================
        logger.warning("⚠️  Falling back to DynamicTaskPlanner (Synapse_new agents not available)")
        yield {"module": "Synapse.core.conductor", "message": "I am falling back to DynamicTaskPlanner (Synapse_new agents not available)"}
        
        # 🔴 A-TEAM FIX: No keyword matching for model/auth failure detection.
        # Just try the planner directly — if it fails, the except block catches it.
        # This avoids hardcoded string matching and lets the system self-discover issues.
        planner = getattr(self, "_task_planner", None)
        if planner:
            try:
                # Build planner-facing agent metadata
                available_agents = []
                for name, config in self.actors.items():
                    if not config.enabled:
                        continue
                    capabilities = config.capabilities or []
                    if not capabilities and config.metadata:
                        capabilities = config.metadata.get("capabilities", [])
                    available_agents.append(
                        {
                            "name": name,
                            "capabilities": capabilities,
                            "description": self._get_agent_description(name, config),
                        }
                    )

                # Include env context so fallback quality remains high
                enhanced_goal = self._wrap_instruction_with_env_context(goal)
                planner_context = kwargs.get("context", "") if isinstance(kwargs, dict) else ""

                yield {
                    "module": "Synapse.core.conductor",
                    "message": f"I am invoking DynamicTaskPlanner fallback with {len(available_agents)} available agents",
                }

                plan = None
                async for event in planner.decompose_goal_stream(
                    goal=enhanced_goal,
                    available_agents=available_agents,
                    context=planner_context,
                ):
                    yield event
                    if isinstance(event, dict) and event.get("type") == "result":
                        plan = event.get("result")

                if plan and getattr(plan, "tasks", None):
                    plan_dict = plan.to_dict() if hasattr(plan, "to_dict") else plan
                    self.todo.initialize_from_plan(plan_dict)

                    # Normalize unassigned actors so selector can assign at execution time.
                    for task in self.todo.subtasks.values():
                        if isinstance(task.actor, str) and not task.actor.strip():
                            task.actor = None

                    # Keep score signals fresh after plan initialization.
                    # NOTE: Conductor has no _estimate_task_rewards() helper in this branch;
                    # MarkovianTODO already recalculates progress/remaining in initialize_from_plan().
                    if hasattr(self, "_estimate_task_rewards"):
                        self._estimate_task_rewards()
                    elif hasattr(self.todo, "_estimate_remaining"):
                        self.todo._estimate_remaining()

                    # Re-emit DAG for frontend visibility.
                    dag_update = self._build_dag_event_from_todo()
                    if dag_update:
                        yield dag_update

                    # Emit task list for frontend debug parity with Synapse_new path.
                    try:
                        all_tasks = self.todo.get_all_tasks_list()
                        yield {
                            "module": "Synapse.core.conductor",
                            "message": f"I have created {len(all_tasks)} tasks in total",
                            "type": "task_list",
                            "data": {
                                "total_tasks": len(all_tasks),
                                "tasks": all_tasks,
                                "root_task": self.todo.root_task,
                                "completed_count": len(self.todo.completed_tasks),
                                "failed_count": len(self.todo.failed_tasks)
                                if hasattr(self.todo, "failed_tasks")
                                else 0,
                            },
                        }
                    except Exception as e:
                        logger.warning(f"Failed to emit fallback task list: {e}")

                    logger.info(
                        f"✅ DynamicTaskPlanner fallback initialized TODO with {len(self.todo.subtasks)} tasks"
                    )
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"I initialized TODO using DynamicTaskPlanner fallback with {len(self.todo.subtasks)} tasks",
                    }
                    return

                logger.warning("⚠️ DynamicTaskPlanner fallback produced empty plan")
                yield {
                    "module": "Synapse.core.conductor",
                    "message": "DynamicTaskPlanner fallback produced an empty plan; switching to minimal fallback",
                }
            except Exception as e:
                logger.error(f"❌ DynamicTaskPlanner fallback failed: {e}")
                yield {
                    "module": "Synapse.core.conductor",
                    "message": f"DynamicTaskPlanner fallback failed: {str(e)}",
                }

        # 2) Final safety-net fallback: single task (never hard fail here)
        self.todo.subtasks.clear()
        self.todo.execution_order.clear()
        self.todo.completed_tasks.clear()
        if hasattr(self.todo, "failed_tasks"):
            self.todo.failed_tasks.clear()
        self.todo.current_task_id = None

        self.todo.add_task(
            task_id="task_1",
            description=goal,
            actor="",
            depends_on=[],
            priority=1.0,
        )
        if "task_1" in self.todo.subtasks:
            # Ensure dynamic selector is engaged for unassigned task.
            self.todo.subtasks["task_1"].actor = None

        # NOTE: Avoid calling non-existent Conductor helper in minimal fallback.
        if hasattr(self, "_estimate_task_rewards"):
            self._estimate_task_rewards()
        elif hasattr(self.todo, "_estimate_remaining"):
            self.todo._estimate_remaining()

        dag_update = self._build_dag_event_from_todo()
        if dag_update:
            yield dag_update

        yield {
            "module": "Synapse.core.conductor",
            "message": "I initialized a minimal single-task TODO as final fallback",
        }
        logger.warning("⚠️ Using final safety-net fallback TODO initialization (single task)")
        return
    
    async def _initialize_todo_from_goal(self, goal: str, kwargs: Dict):
        """Synchronous wrapper for _initialize_todo_from_goal_stream."""
        async for event in self._initialize_todo_from_goal_stream(goal, kwargs):
            pass
    
    def _wrap_instruction_with_env_context(self, instruction: str) -> str:
        """
        Wrap instruction with current environment context.
        
        Format:
            Instruction
            <instruction>
            
            Current State
            <output of get_current_env()>
        
        Args:
            instruction: Original instruction/plan/query
        
        Returns:
            Enhanced instruction with environment context
        """
        if not self.env_manager:
            return instruction
        
        try:
            current_env = self.env_manager.get_current_env()
            
            # Format: Instruction + Current State
            wrapped = f"""Instruction
{instruction}

Current State
{current_env}"""
            
            logger.debug(f"📦 Wrapped instruction with environment context ({len(current_env)} chars)")
            return wrapped
            
        except Exception as e:
            logger.warning(f"⚠️  Failed to wrap instruction with environment context: {e}")
            return instruction
    
    def _get_agent_description(self, name: str, config: 'AgentConfig') -> str:
        """
        Extract RICH agent description including skills and tools for task planning.
        
        🔴 A-TEAM FIX: Descriptions must clearly define agent skills (tools and
        tasks they can perform) so the DynamicTaskPlanner and TodoCreatorAgent
        can make informed task assignment decisions.
        
        Priority:
        1. config.metadata['description'] if exists
        2. Agent class docstring
        3. Agent class name (CamelCase → readable)
        4. Default based on name
        
        Then ENRICHES with tool names and capabilities extracted from the agent.
        """
        base_description = ""
        
        # Source 1: Config metadata
        if config.metadata and 'description' in config.metadata:
            base_description = config.metadata['description']
        
        # Source 2: Agent class docstring (FULL — includes Skills/Tools for task planning)
        agent = config.agent
        if not base_description and agent and hasattr(agent, '__doc__') and agent.__doc__:
            raw_doc = agent.__doc__.strip()
            # Extract FULL docstring, collapsing multi-line into compact form
            # Docstrings follow: "One-liner.\n\nSkills: ...\nTools: ..."
            doc_lines = [line.strip() for line in raw_doc.split('\n') if line.strip()]
            if doc_lines:
                base_description = ' '.join(doc_lines)
        
        # Source 3: Agent class name
        if not base_description and agent and hasattr(agent, '__class__'):
            class_name = agent.__class__.__name__
            # Convert CamelCase to readable (no regex)
            readable_parts = []
            for i, ch in enumerate(class_name):
                if i > 0 and ch.isupper() and (class_name[i - 1].islower() or (i + 1 < len(class_name) and class_name[i + 1].islower())):
                    readable_parts.append(" ")
                readable_parts.append(ch)
            readable = "".join(readable_parts).strip()
            base_description = f"{readable} agent"
        
        # Source 4: Default to name only (no hardcoded descriptions)
        if not base_description:
            base_description = f"{name} agent"
        
        # =====================================================================
        # 🔴 A-TEAM FIX: Enrich with TOOLS and SKILLS for task planning
        # =====================================================================
        # The task planner needs to know what each agent CAN DO, not just
        # a vague label. Extract tool names from the agent class.
        tool_names = []
        try:
            # Try multiple sources for tool discovery
            if agent:
                # Source A: TOOLS class attribute (most Surface agents define this)
                tools_attr = getattr(agent, 'TOOLS', None) or getattr(type(agent), 'TOOLS', None)
                if tools_attr and isinstance(tools_attr, (list, tuple)):
                    for tool in tools_attr:
                        tool_name = getattr(tool, '__name__', None) or getattr(tool, 'name', None)
                        if tool_name:
                            tool_names.append(tool_name)
                
                # Source B: _tools_list instance attribute (BaseSwarmAgent stores resolved tools here)
                if not tool_names:
                    tools_list = getattr(agent, '_tools_list', None)
                    if tools_list and isinstance(tools_list, (list, tuple)):
                        for tool in tools_list:
                            tool_name = getattr(tool, '__name__', None) or getattr(tool, 'name', None)
                            if tool_name:
                                tool_names.append(tool_name)
                
                # Source C: ReAct module tools (agent.generate.tools)
                if not tool_names:
                    react_module = getattr(agent, 'generate', None)
                    if react_module:
                        react_tools = getattr(react_module, 'tools', None)
                        if react_tools and isinstance(react_tools, (list, tuple)):
                            for tool in react_tools:
                                tool_name = getattr(tool, '__name__', None) or getattr(tool, 'name', None)
                                if tool_name:
                                    tool_names.append(tool_name)
        except Exception as e:
            logger.debug(f"Tool extraction for {name} failed: {e}")
        
        # Build enriched description
        if tool_names:
            # Deduplicate while preserving order
            seen = set()
            unique_tools = []
            for t in tool_names:
                if t not in seen:
                    seen.add(t)
                    unique_tools.append(t)
            
            tools_str = ", ".join(unique_tools[:15])  # Cap at 15 tools to avoid bloat
            enriched = f"{base_description} | Tools: [{tools_str}]"
            
            # Add capability count if many tools
            if len(unique_tools) > 15:
                enriched += f" (+{len(unique_tools) - 15} more)"
            
            return enriched
        
        return base_description
    
    def _convert_executable_dag_to_todo(self, executable_dag):
        """
        Convert ExecutableDAG from Synapse_new to MarkovianTODO for execution.
        
        Args:
            executable_dag: ExecutableDAG with validated tasks and actor assignments
        """
        from Synapse.domain.entities import TaskStatus as SynapseTaskStatus
        
        # Clear existing TODO
        self.todo.subtasks.clear()
        self.todo.execution_order.clear()
        self.todo.completed_tasks.clear()
        self.todo.failed_tasks.clear()
        
        # Convert each task in the DAG
        for task in executable_dag.dag.tasks.values():
            # Get assigned actor
            actor = executable_dag.assignments.get(task.id)
            actor_name = actor.name if actor else "unassigned"
            
            # Map TaskStatus to TODO status
            if task.status == SynapseTaskStatus.COMPLETED:
                # Add to completed tasks
                self.todo.completed_tasks.add(task.id)
                continue
            elif task.status == SynapseTaskStatus.FAILED:
                # Add to failed tasks
                self.todo.failed_tasks.add(task.id)
                continue
            elif task.status == SynapseTaskStatus.SKIPPED:
                # Skip tasks marked as skipped
                logger.debug(f"   Skipping task {task.id}: {task.name}")
                continue
            
            # Add task to TODO (handles PENDING, IN_PROGRESS, etc.)
            self.todo.add_task(
                task_id=task.id,
                description=task.description or task.name,
                actor=actor_name,
                depends_on=list(task.depends_on),  # Correct parameter name
                estimated_duration=getattr(task, 'estimated_duration', 60.0),
                priority=getattr(task, 'priority', 1.0)
            )
        
        # Log conversion results
        logger.info(f"📋 Converted ExecutableDAG to MarkovianTODO:")
        logger.info(f"   Total tasks: {len(self.todo.subtasks)}")
        logger.info(f"   Completed: {len(self.todo.completed_tasks)}")
        logger.info(f"   Failed: {len(self.todo.failed_tasks)}")
    
    def _build_agent_directory(self) -> Dict[str, Dict[str, Any]]:
        """
        Build agent directory from GenericAgentRegistry for agent collaboration.
        
        Leverages existing GenericAgentRegistry to create a directory format
        suitable for agents to discover and communicate with each other.
        
        Returns:
            Dict mapping agent names to directory entries with capabilities,
            role, status, and performance metrics.
        """
        if not self.agent_registry:
            logger.warning("⚠️ No agent_registry available - cannot build agent directory")
            return {}
        
        try:
            # Use GenericAgentRegistry's built-in method
            directory = self.agent_registry.get_directory_for_agents()
            logger.info(f"📋 Built agent directory with {len(directory)} agents")
            return directory
        except Exception as e:
            logger.error(f"❌ Failed to build agent directory: {e}")
            return {}
    
    def _extract_collaboration_actions(self, result: Any) -> List[Dict]:
        """
        Extract collaboration_actions from agent output.
        
        Handles multiple result types:
        - EpisodeResult: Extract from result.output._store['collaboration_actions']
        - DSPy Prediction: Extract from result._store['collaboration_actions']
        - Direct attribute: Extract from result.collaboration_actions
        
        Args:
            result: Agent execution result (EpisodeResult, Prediction, or dict)
            
        Returns:
            List of collaboration action dicts
        """
        actions = []
        import json
        
        # 🔥 A-TEAM FIX: Handle EpisodeResult wrapper
        if hasattr(result, 'output') and result.output is not None:
            # Result is EpisodeResult, extract from output
            actual_result = result.output
        else:
            actual_result = result
        
        # Try to extract from DSPy Prediction _store
        if hasattr(actual_result, '_store') and isinstance(actual_result._store, dict):
            if 'collaboration_actions' in actual_result._store:
                actions_data = actual_result._store['collaboration_actions']
                if actions_data:
                    try:
                        # If it's already a list/dict, use it directly
                        if isinstance(actions_data, (list, dict)):
                            if isinstance(actions_data, list):
                                actions = actions_data
                            else:
                                actions = [actions_data]
                        # If it's a string, parse JSON
                        elif isinstance(actions_data, str):
                            actions = json.loads(actions_data)
                            if not isinstance(actions, list):
                                actions = [actions] if actions else []
                    except (json.JSONDecodeError, ValueError, TypeError) as e:
                        logger.debug(f"Failed to parse collaboration_actions from _store: {e}")
                        actions = []
        
        # Fallback: Check if result has collaboration_actions field directly
        if not actions and hasattr(actual_result, 'collaboration_actions'):
            actions_str = str(actual_result.collaboration_actions)
            
            # Parse JSON
            try:
                actions = json.loads(actions_str)
                if not isinstance(actions, list):
                    actions = [actions] if actions else []
            except (json.JSONDecodeError, ValueError):
                # If not JSON, try to extract from string
                logger.debug(f"collaboration_actions is not JSON, treating as empty")
                actions = []
        
        return actions

    # 🔴 A-TEAM: Dead code removed — _get_shared_skills_registry, _skill_id_from_name,
    # _register_shared_skill were legacy methods superseded by SkillRegistry lifecycle
    # handlers (_handle_propose_skill_stream, _handle_publish_skill_stream, etc.).
    
    async def _process_collaboration_action_stream(
        self,
        action: Dict,
        from_actor: str,
        context: Dict
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Process a single collaboration action.
        
        Args:
            action: Collaboration action dict
            from_actor: Name of actor that requested the action
            context: Execution context
        
        Yields:
            Event dictionaries with module and conversational message
        """
        # 🔴 A-TEAM FIX: Normalize collaboration action key names
        # LLMs sometimes use alternative key names (e.g., "type" instead of "action",
        # "agent" instead of "target_agent", "target" instead of "target_agent").
        # Normalize these to the canonical format before processing.
        action_type = action.get("action") or action.get("type") or action.get("action_type")
        target_agent = (action.get("target_agent") or action.get("agent") 
                       or action.get("target") or action.get("to_agent")
                       or action.get("to") or action.get("recipient"))
        
        # Write normalized keys back so downstream handlers can use them
        if action_type and "action" not in action:
            action["action"] = action_type
        if target_agent and "target_agent" not in action:
            action["target_agent"] = target_agent
        
        yield {"module": "Synapse.core.conductor", "message": f"I am processing collaboration action '{action_type}' from actor '{from_actor}'"}
        
        # 🔴 A-TEAM FIX 17: Actor→TODO communication — handle before target_agent check
        # update_todo actions target the TODO system, not another agent
        if action_type == "update_todo":
            async for event in self._handle_actor_todo_update_stream(action, from_actor):
                yield event
            return
        
        if not action_type or not target_agent:
            logger.warning(f"⚠️ Invalid collaboration action: missing action={action_type} or target_agent={target_agent} | raw_keys={list(action.keys())}")
            yield {"module": "Synapse.core.conductor", "message": f"I noticed invalid collaboration action: missing action or target_agent (keys: {list(action.keys())})"}
            return
        
        # ============================================================
        # COLLABORATION ROUND-TRIP TRACKING
        # ============================================================
        # Agents CAN go back and forth (A→B→A→B...) — that's real
        # collaboration, not a deadlock. We only guard against
        # runaway infinite recursion by capping total round-trips
        # between any pair to MAX_ROUNDTRIPS.
        #
        # Key insight: the conductor processes collaboration actions
        # sequentially, so there's no concurrent deadlock risk.
        # A→B completes, B responds, then A can respond again.
        # ============================================================
        
        if not hasattr(self, '_collaboration_roundtrips'):
            self._collaboration_roundtrips = {}  # "A↔B" -> count
        
        # Canonical pair key (order-independent so A→B and B→A share a counter)
        pair_key = "↔".join(sorted([from_actor, target_agent]))
        
        MAX_ROUNDTRIPS = 5  # Allow up to 5 back-and-forth exchanges per pair
        current_trips = self._collaboration_roundtrips.get(pair_key, 0)
        
        if current_trips >= MAX_ROUNDTRIPS:
            logger.warning(
                f"⚠️ COLLABORATION LIMIT: {from_actor} ↔ {target_agent} "
                f"hit {MAX_ROUNDTRIPS} round-trips — asking agents to converge"
            )
            yield {
                "module": "Synapse.core.conductor",
                "message": (
                    f"Collaboration between {from_actor} and {target_agent} "
                    f"has exchanged {MAX_ROUNDTRIPS} times. Asking both to "
                    f"converge on a final answer with what they have."
                )
            }
            return
        
        # Track this round-trip
        self._collaboration_roundtrips[pair_key] = current_trips + 1
        
        logger.info(
            f"💬 Collaboration #{current_trips + 1}/{MAX_ROUNDTRIPS}: "
            f"{from_actor} → {target_agent} ({action_type})"
        )
        
        # ─── Item 103: Dual-Attribution Wrapper ──────────────────────
        # Route each collaboration event to BOTH the requester's and
        # target agent's UI cards by yielding the event twice with
        # different _actor_name tags.
        async def _dual_route(inner_gen):
            async for event in inner_gen:
                if isinstance(event, dict):
                    # First: route to requester's card
                    ev_req = dict(event)
                    ev_req["_actor_name"] = from_actor
                    ev_req["_collaboration_role"] = "requester"
                    ev_req.setdefault("_collaboration_pair", f"{from_actor}→{target_agent}")
                    yield ev_req
                    # Second: route to target's card (only if target is a different actor)
                    if target_agent and target_agent != from_actor and target_agent != "all":
                        ev_tgt = dict(event)
                        ev_tgt["_actor_name"] = target_agent
                        ev_tgt["_collaboration_role"] = "responder"
                        ev_tgt["_collaboration_pair"] = f"{from_actor}→{target_agent}"
                        yield ev_tgt
                else:
                    yield event
        # ──────────────────────────────────────────────────────────────

        try:
            if action_type == "request_help":
                async for event in _dual_route(self._handle_help_request_stream(action, from_actor, context)):
                    yield event
            elif action_type == "request_skill":
                async for event in _dual_route(self._handle_request_skill_stream(action, from_actor, context)):
                    yield event
            elif action_type == "propose_skill":
                async for event in _dual_route(self._handle_propose_skill_stream(action, from_actor)):
                    yield event
            elif action_type == "publish_skill":
                async for event in _dual_route(self._handle_publish_skill_stream(action, from_actor)):
                    yield event
            elif action_type == "deprecate_skill":
                async for event in _dual_route(self._handle_deprecate_skill_stream(action, from_actor)):
                    yield event
            elif action_type == "execute_skill":
                async for event in _dual_route(self._handle_execute_skill_stream(action, from_actor)):
                    yield event
            elif action_type == "share_knowledge":
                async for event in _dual_route(self._handle_knowledge_share_stream(action, from_actor)):
                    yield event
            elif action_type == "broadcast":
                async for event in _dual_route(self._handle_broadcast_stream(action, from_actor)):
                    yield event
            else:
                logger.warning(f"⚠️ Unknown collaboration action type: {action_type}")
                yield {"module": "Synapse.core.conductor", "message": f"I noticed unknown collaboration action type: {action_type}"}
        except Exception as e:
            logger.error(f"❌ Collaboration error ({from_actor} → {target_agent}): {e}")
            yield {
                "module": "Synapse.core.conductor",
                "message": f"Collaboration failed: {from_actor} → {target_agent}: {str(e)[:200]}"
            }
    
    async def _process_collaboration_action(
        self,
        action: Dict,
        from_actor: str,
        context: Dict
    ) -> None:
        """Synchronous wrapper for _process_collaboration_action_stream."""
        async for event in self._process_collaboration_action_stream(action, from_actor, context):
            pass
    
    async def _handle_help_request_stream(
        self,
        action: Dict,
        from_actor: str,
        context: Dict
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle help request by invoking target agent."""
        requested_agent = action.get("target_agent")
        request_type = action.get("type", "general")
        data = action.get("data", {})
        problem = data.get("problem", "Help needed")
        request_context = data.get("context", {})
        
        logger.info(f"🆘 Help request: {from_actor} → {requested_agent} ({request_type})")
        yield {"module": "Synapse.core.conductor", "message": f"I am handling help request from '{from_actor}' to '{requested_agent}' ({request_type})"}
        
        # 🆕 A-TEAM: Resolve target agent name (may be incorrect/deprecated)
        target_agent = self._resolve_target_agent(
            target_agent=requested_agent,
            knowledge_type=request_type,
            data=data
        )
        
        if target_agent == "all":
            logger.warning(f"⚠️ Could not resolve '{requested_agent}', broadcasting to all agents")
            yield {"module": "Synapse.core.conductor", "message": f"I could not resolve '{requested_agent}', will broadcast to all agents"}
            # Handle broadcast case
            if self.agent_slack:
                for agent_name in self.agent_directory.keys():
                    if agent_name != from_actor:
                        self.agent_slack.send(
                            from_agent=from_actor,
                            to_agent=agent_name,
                            data={
                                "message_type": "help_request",
                                "request_type": request_type,
                                "problem": problem,
                                "context": request_context
                            }
                        )
            yield {"module": "Synapse.core.conductor", "message": f"I broadcasted help request to all agents"}
            return
        
        # Get target actor config
        target_config = None
        for actor_config in self.actors.values():
            if actor_config.name == target_agent:
                target_config = actor_config
                break
        
        if not target_config:
            logger.error(f"❌ Unknown target agent: {target_agent} (resolved from '{requested_agent}')")
            yield {"module": "Synapse.core.conductor", "message": f"I encountered an error: unknown target agent '{target_agent}'"}
            return
        
        # Build instruction for target agent
        import json
        # 🔴 A-TEAM FIX: Extract ALL data fields, not just files and purpose
        files_to_read = data.get('files', [])
        specific_request = data.get('purpose', problem)
        command_to_execute = data.get('command', '')
        script_content = data.get('script', '') or data.get('script_content', '') or data.get('content', '')
        script_path = data.get('script_path', '')
        
        instruction = f"""
HELP REQUEST from {from_actor}:

Type: {request_type}
Problem: {problem}
Specific Request: {specific_request}
Context: {json.dumps(request_context, indent=2, default=str)}
"""
        
        # 🔴 A-TEAM FIX: Include command/script content if provided
        if command_to_execute:
            instruction += f"""
COMMAND TO EXECUTE:
{command_to_execute}
"""
        
        if script_path:
            instruction += f"""
SCRIPT PATH:
{script_path}
"""
        
        if script_content:
            # 🔴 A-TEAM FIX: Use smart_truncate instead of hardcoded [:10000]
            content_preview = smart_truncate(script_content, max_tokens=2500)
            instruction += f"""
SCRIPT CONTENT (provided by {from_actor}):
```
{content_preview}
```
"""
        
        # Add file-specific instructions if files are specified
        if files_to_read:
            instruction += f"""
FILES TO READ:
{chr(10).join(f'- {f}' for f in files_to_read)}

Please read these files and provide their contents. Store the file contents in your output so they can be shared back with {from_actor}.
"""
        
        # 🔴 A-TEAM FIX: Include ALL remaining data fields not yet handled
        handled_keys = {'files', 'purpose', 'command', 'script', 'script_content', 
                       'content', 'script_path', 'problem', 'context'}
        extra_data = {k: v for k, v in data.items() if k not in handled_keys and v}
        if extra_data:
            instruction += f"""
ADDITIONAL DATA:
{smart_truncate(json.dumps(extra_data, indent=2, default=str), max_tokens=1250)}
"""
        
        if not files_to_read and not command_to_execute and not script_content:
            instruction += "\nPlease provide assistance.\n"
        
        yield {"module": "Synapse.core.conductor", "message": f"I built an instruction for target agent '{target_agent}'"}
        # Execute target agent (with overflow protection!)
        try:
            # TodoItem is defined in this file (line ~208)
            yield {"module": "Synapse.core.conductor", "message": f"I am executing target agent '{target_agent}' to provide help"}
            # _execute_actor_with_overflow_protection is now an async generator
            response = None
            async for event in self._execute_actor_with_overflow_protection(
                actor_config=target_config,
                task=TodoItem(
                    id="help_request",
                    description=instruction,
                    actor=target_agent,
                    status="pending",
                    priority=0.7,  # Medium-high priority for help requests
                    estimated_reward=getattr(self.config, 'default_estimated_reward', 0.5)
                ),
                context=instruction,
                kwargs=context,
                actor_context_dict=None  # 🔴 A-TEAM FIX: Add missing parameter
            ):
                # Yield all events from actor execution
                yield event
                # Extract result from final event
                if isinstance(event, dict) and event.get("type") == "result":
                    response = event.get("result")
            
            # 🔥 A-TEAM COMPLETE FIX: Extract and store collaboration results
            collaboration_results = None
            if response:
                # Extract data from EpisodeResult or Prediction
                actual_response = response.output if hasattr(response, 'output') else response
                
                # Extract file contents or relevant data from TerminalExecutor
                file_contents = {}
                analysis = ''
                plan = ''
                commands = ''
                reasoning = ''
                terminal_output = ''
                
                # Try to extract from EpisodeResult._store
                if hasattr(actual_response, '_store') and isinstance(actual_response._store, dict):
                    store = actual_response._store
                    analysis = store.get('analysis', '') or getattr(actual_response, 'analysis', '')
                    plan = store.get('plan', '') or getattr(actual_response, 'plan', '')
                    commands = store.get('commands', '') or getattr(actual_response, 'commands', '')
                    reasoning = store.get('reasoning', '') or getattr(actual_response, 'reasoning', '')
                    
                    # Extract file contents from trajectory/observations
                    trajectory = store.get('trajectory', {})
                    if isinstance(trajectory, dict):
                        # Look for observations containing file content
                        for key, value in trajectory.items():
                            if isinstance(value, str):
                                # Check if this contains any requested file paths
                                for file_path in data.get('files', []):
                                    if file_path in value and file_path not in file_contents:
                                        # Try to extract file content from observation
                                        # File content usually appears after the file path or command
                                        if 'cat' in value.lower() or 'read' in value.lower() or file_path in value:
                                            # Extract content after file path or command
                                            idx = value.find(file_path)
                                            if idx != -1:
                                                # Look for content after file path (skip command part)
                                                content_start = idx + len(file_path)
                                                # Skip whitespace and newlines
                                                while content_start < len(value) and value[content_start] in [' ', '\n', '\t']:
                                                    content_start += 1
                                                if content_start < len(value):
                                                    file_contents[file_path] = value[content_start:].strip()
                    
                    # Also check terminal_state for file contents
                    terminal_state = store.get('terminal_state', '') or getattr(actual_response, 'terminal_state', '')
                    if terminal_state:
                        for file_path in data.get('files', []):
                            if file_path in terminal_state and file_path not in file_contents:
                                # Extract content from terminal state
                                idx = terminal_state.find(file_path)
                                if idx != -1:
                                    content_start = idx + len(file_path)
                                    while content_start < len(terminal_state) and terminal_state[content_start] in [' ', '\n', '\t']:
                                        content_start += 1
                                    if content_start < len(terminal_state):
                                        file_contents[file_path] = terminal_state[content_start:].strip()
                        terminal_output = terminal_state
                
                # Fallback: Extract directly from Prediction attributes
                if not file_contents and hasattr(actual_response, 'analysis'):
                    analysis = getattr(actual_response, 'analysis', '') or analysis
                    plan = getattr(actual_response, 'plan', '') or plan
                    commands = getattr(actual_response, 'commands', '') or commands
                    reasoning = getattr(actual_response, 'reasoning', '') or reasoning
                    terminal_state = getattr(actual_response, 'terminal_state', '') or terminal_output
                    
                    # Try to extract file contents from terminal_state
                    if terminal_state:
                        for file_path in data.get('files', []):
                            if file_path in terminal_state:
                                # Simple extraction: content after file path
                                idx = terminal_state.find(file_path)
                                if idx != -1:
                                    # Look for content after the file path
                                    lines = terminal_state.split('\n')
                                    for i, line in enumerate(lines):
                                        if file_path in line:
                                            # Collect subsequent lines as file content
                                            content_lines = []
                                            for j in range(i + 1, min(i + 1000, len(lines))):  # Limit to 1000 lines
                                                content_lines.append(lines[j])
                                            if content_lines:
                                                file_contents[file_path] = '\n'.join(content_lines).strip()
                                                break
                
                # Build collaboration results
                collaboration_results = {
                    "request_type": request_type,
                    "request_context": request_context,
                    "file_contents": file_contents,
                    "analysis": analysis,
                    "plan": plan,
                    "commands": commands,
                    "reasoning": reasoning,
                    "terminal_output": smart_truncate(terminal_output, max_tokens=2500) if terminal_output else None,
                    "helper_agent": target_agent
                }
                
                # If no file contents extracted, store full response as fallback
                if not file_contents and actual_response:
                    collaboration_results["full_response"] = smart_truncate(str(actual_response), max_tokens=2500)
            
            # Store collaboration results in shared_context for requesting agent
            collaboration_key = None
            if collaboration_results and hasattr(self, 'shared_context') and self.shared_context:
                collaboration_key = f"collaboration_results_{from_actor}"
                self.shared_context.set(collaboration_key, collaboration_results)
                logger.info(f"💾 Stored collaboration results for '{from_actor}' in shared_context['{collaboration_key}']")
                yield {"module": "Synapse.core.conductor", "message": f"I stored collaboration results in shared context for '{from_actor}'"}
            
            # Send response back via agent_slack
            if self.agent_slack:
                self.agent_slack.send(
                    from_agent=target_agent,
                    to_agent=from_actor,
                    data={
                        "message_type": "help_response",
                        "in_response_to": action.get("request_id"),
                        "response": response,
                        "request_type": request_type,
                        "collaboration_results_key": collaboration_key
                    }
                )
            
            logger.info(f"✅ Help provided: {target_agent} → {from_actor}")
            yield {"module": "Synapse.core.conductor", "message": f"I successfully provided help from '{target_agent}' to '{from_actor}'"}
            
            # 🔥 A-TEAM COMPLETE FIX: Re-execute requesting agent with collaboration results
            if collaboration_results:
                yield {"module": "Synapse.core.conductor", "message": f"I am re-executing '{from_actor}' with collaboration results from '{target_agent}'"}
                
                # Get requesting agent config
                requesting_config = None
                for actor_config in self.actors.values():
                    if actor_config.name == from_actor:
                        requesting_config = actor_config
                        break
                
                if requesting_config:
                    # Build enhanced instruction with collaboration results
                    original_task = context.get('goal') or context.get('query') or context.get('instruction', '')
                    enhanced_instruction = f"""
{original_task}

📥 COLLABORATION RESULTS AVAILABLE:
I have received help from {target_agent} for your request: {request_type}

The collaboration results are stored in shared_context['{collaboration_key}'].
You can access them via:
- shared_context.get('{collaboration_key}')['file_contents'] - File contents read
- shared_context.get('{collaboration_key}')['analysis'] - Analysis from helper agent
- shared_context.get('{collaboration_key}')['plan'] - Plan from helper agent

Please use this information to complete your task.
"""
                    
                    # Create new task for re-execution
                    re_execution_task = TodoItem(
                        id=f"collaboration_retry_{from_actor}",
                        description=enhanced_instruction,
                        actor=from_actor,
                        status="pending",
                        priority=0.8,  # High priority for retries
                        estimated_reward=getattr(self.config, 'default_estimated_reward', 0.5)
                    )
                    
                    # Build enhanced context with collaboration results
                    enhanced_context = context.copy()
                    enhanced_context['collaboration_results'] = collaboration_results
                    enhanced_context['collaboration_key'] = collaboration_key
                    enhanced_context['_collaboration_available'] = True
                    
                    # Re-execute requesting agent
                    try:
                        logger.info(f"🔄 Re-executing '{from_actor}' with collaboration results")
                        async for event in self._execute_actor_with_overflow_protection(
                            actor_config=requesting_config,
                            task=re_execution_task,
                            context=enhanced_instruction,
                            kwargs=enhanced_context,
                            actor_context_dict=None
                        ):
                            yield event
                        logger.info(f"✅ Re-execution of '{from_actor}' completed")
                        yield {"module": "Synapse.core.conductor", "message": f"I successfully re-executed '{from_actor}' with collaboration results"}
                    except Exception as e:
                        logger.error(f"❌ Failed to re-execute '{from_actor}': {e}")
                        yield {"module": "Synapse.core.conductor", "message": f"I encountered an error while re-executing '{from_actor}': {str(e)}"}
                        import traceback
                        logger.debug(traceback.format_exc())
                else:
                    logger.warning(f"⚠️ Could not find requesting agent config for '{from_actor}'")
                    yield {"module": "Synapse.core.conductor", "message": f"I could not find requesting agent '{from_actor}' for re-execution"}
            
        except Exception as e:
            logger.error(f"❌ Help request failed: {e}")
            yield {"module": "Synapse.core.conductor", "message": f"I encountered an error while handling help request: {str(e)}"}
            import traceback
            logger.debug(traceback.format_exc())
    
    async def _handle_help_request(
        self,
        action: Dict,
        from_actor: str,
        context: Dict
    ) -> None:
        """Synchronous wrapper for _handle_help_request_stream."""
        async for event in self._handle_help_request_stream(action, from_actor, context):
            pass

    async def _handle_request_skill_stream(
        self,
        action: Dict,
        from_actor: str,
        context: Dict,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Find an existing approved skill for the requested capability.
        If none exists, create a skill-synthesis TODO for an appropriate actor.
        """
        data = action.get("data", {}) or {}
        capability = str(data.get("capability") or data.get("problem") or "").strip()
        if not capability:
            yield {"module": "Synapse.core.conductor", "message": "Skill request missing capability."}
            return
        if not self.skill_registry:
            yield {"module": "Synapse.core.conductor", "message": "Dynamic skill registry is disabled."}
            return

        yield {"module": "Synapse.core.conductor", "message": f"I am searching approved skills for capability: {capability[:120]}"}
        selection = await self.skill_registry.select_skills_semantic(
            skill_request=capability,
            actor_name=from_actor,
            max_results=3,
        )
        selected = selection.get("selected", []) if isinstance(selection, dict) else []
        if selected:
            skill_payload = {
                "message_type": "skill_match",
                "requested_capability": capability,
                "skills": selected,
                "reasoning": selection.get("reasoning", ""),
            }
            if self.agent_slack:
                self.agent_slack.send(
                    from_agent="SkillRegistry",
                    to_agent=from_actor,
                    data=skill_payload,
                )
            if hasattr(self, "shared_context") and self.shared_context:
                self.shared_context.set(f"skills_for_{from_actor}", skill_payload)
            yield {
                "module": "Synapse.core.conductor",
                "message": f"I found {len(selected)} reusable skills and shared them with '{from_actor}'.",
            }
            return

        # No reusable skill found -> enqueue synthesis task
        preferred = str(data.get("preferred_owner") or action.get("target_agent") or "").strip()
        synth_actor = self._resolve_target_agent(
            target_agent=preferred or "terminal",
            knowledge_type="skill_synthesis",
            data=data,
        )
        if not synth_actor or synth_actor == "all":
            synth_actor = from_actor

        skill_plan = {
            "capability": capability,
            "requester": from_actor,
            "context": data.get("context", {}),
            "required_io": data.get("required_io", {}),
        }
        new_id = f"skill_build_{uuid.uuid4().hex[:8]}"
        new_task = SubtaskState(
            task_id=new_id,
            description=f"Synthesize and validate reusable skill for capability: {capability}",
            actor=synth_actor,
            depends_on=[],
            priority=1.0,
        )
        self.todo.subtasks[new_id] = new_task
        if hasattr(self, "shared_context") and self.shared_context:
            self.shared_context.set(f"skill_plan_{new_id}", skill_plan)
        yield {
            "module": "Synapse.core.conductor",
            "message": f"No approved skill found; queued skill synthesis task '{new_id}' for actor '{synth_actor}'.",
        }
        _tl = self._build_task_list_event()
        if _tl:
            yield _tl

    async def _handle_propose_skill_stream(
        self,
        action: Dict,
        from_actor: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Register and validate a proposed skill artifact."""
        if not (self.skill_registry and self.skill_validator):
            yield {"module": "Synapse.core.conductor", "message": "Dynamic skill tooling is disabled."}
            return

        data = action.get("data", {}) or {}
        name = str(data.get("name") or "").strip()
        description = str(data.get("description") or "").strip()
        module_path = str(data.get("module_path") or "").strip()
        if not name or not description or not module_path:
            yield {"module": "Synapse.core.conductor", "message": "Skill proposal missing required fields (name/description/module_path)."}
            return

        test_cmd = data.get("test_command")
        if test_cmd and not isinstance(test_cmd, list):
            test_cmd = None

        yield {"module": "Synapse.core.conductor", "message": f"I am validating proposed skill '{name}' from '{from_actor}'."}
        validation = await self.skill_validator.validate(
            module_path=module_path,
            expected_entrypoint=str(data.get("entrypoint") or "run"),
            test_command=test_cmd,
        )
        if not validation.valid:
            yield {
                "module": "Synapse.core.conductor",
                "message": f"Skill proposal rejected for now. Issues: {validation.issues[:5]}",
            }
            return

        artifact = await self.skill_registry.register_skill(
            name=name,
            description=description,
            module_path=module_path,
            owner_actor=str(data.get("owner_actor") or from_actor),
            entrypoint=str(data.get("entrypoint") or "run"),
            status="candidate",
            dependencies=data.get("dependencies") or [],
            input_schema=data.get("input_schema") or {},
            output_schema=data.get("output_schema") or {},
            safety_profile=data.get("safety_profile") or {},
            quality_signals={
                **(data.get("quality_signals") or {}),
                "validator": "deterministic",
                "tests_ok": validation.tests_ok,
                "static_ok": validation.static_ok,
            },
            provenance={
                "proposed_by": from_actor,
                "proposal_action": "propose_skill",
            },
            tags=data.get("tags") or [],
        )
        # 🔴 A-TEAM FIX: Set last_validated_at so needs_revalidation tracking works.
        # Without this, every skill always reports needs_revalidation=True because
        # last_validated_at defaults to 0.0 and is never updated.
        artifact.last_validated_at = time.time()
        await self.skill_registry.save()
        
        if getattr(self.config, "dynamic_skill_auto_publish", False):
            await self.skill_registry.update_skill_status(artifact.skill_id, "approved")
            msg = f"Skill '{artifact.name}' auto-approved and indexed as {artifact.skill_id}."
        else:
            msg = f"Skill '{artifact.name}' registered as candidate: {artifact.skill_id}."
        yield {"module": "Synapse.core.conductor", "message": msg}

    async def _handle_publish_skill_stream(
        self,
        action: Dict,
        from_actor: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Promote candidate skill to approved status."""
        if not self.skill_registry:
            yield {"module": "Synapse.core.conductor", "message": "Dynamic skill registry is disabled."}
            return
        data = action.get("data", {}) or {}
        skill_id = str(data.get("skill_id") or "").strip()
        if not skill_id:
            yield {"module": "Synapse.core.conductor", "message": "publish_skill missing skill_id."}
            return
        art = await self.skill_registry.update_skill_status(
            skill_id=skill_id,
            status="approved",
            extra_quality=data.get("quality_signals") or {},
        )
        if not art:
            yield {"module": "Synapse.core.conductor", "message": f"Skill not found: {skill_id}"}
            return
        yield {"module": "Synapse.core.conductor", "message": f"Skill approved: {art.name} ({skill_id}) by {from_actor}."}

    async def _handle_deprecate_skill_stream(
        self,
        action: Dict,
        from_actor: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Deprecate an existing skill while preserving history and migration paths."""
        if not self.skill_registry:
            yield {"module": "Synapse.core.conductor", "message": "Dynamic skill registry is disabled."}
            return
        data = action.get("data", {}) or {}
        skill_id = str(data.get("skill_id") or "").strip()
        reason = str(data.get("reason") or "No reason provided").strip()
        superseded_by = str(data.get("superseded_by") or "").strip() or None
        if not skill_id:
            yield {"module": "Synapse.core.conductor", "message": "deprecate_skill missing skill_id."}
            return
        # 🔴 A-TEAM FIX: Use deprecate_skill() which preserves migration paths,
        # superseded_by tracking, and provenance history — not update_skill_status()
        # which just changes the status string and loses all deprecation context.
        art = await self.skill_registry.deprecate_skill(
            skill_id=skill_id,
            reason=reason,
            superseded_by=superseded_by,
        )
        if not art:
            yield {"module": "Synapse.core.conductor", "message": f"Skill not found: {skill_id}"}
            return
        migration_note = f" (superseded by {superseded_by})" if superseded_by else ""
        yield {"module": "Synapse.core.conductor", "message": f"Skill deprecated: {art.name} ({skill_id}){migration_note}."}

    async def _handle_execute_skill_stream(
        self,
        action: Dict,
        from_actor: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Execute an approved skill and hand result back to requesting actor."""
        if not (self.skill_registry and self.skill_runtime):
            yield {"module": "Synapse.core.conductor", "message": "Dynamic skill runtime is disabled."}
            return
        data = action.get("data", {}) or {}
        skill_id = str(data.get("skill_id") or "").strip()
        payload = data.get("payload") or {}
        if not skill_id:
            yield {"module": "Synapse.core.conductor", "message": "execute_skill missing skill_id."}
            return

        art = await self.skill_registry.get_skill(skill_id)
        if not art:
            yield {"module": "Synapse.core.conductor", "message": f"Skill not found: {skill_id}"}
            return
        if art.status != "approved":
            yield {"module": "Synapse.core.conductor", "message": f"Skill {skill_id} is not approved (status={art.status})."}
            return

        yield {"module": "Synapse.core.conductor", "message": f"I am executing approved skill '{art.name}' ({skill_id})."}
        result = await self.skill_runtime.execute(
            module_path=art.module_path,
            entrypoint=art.entrypoint,
            payload=payload if isinstance(payload, dict) else {},
            timeout_seconds=getattr(self.config, "dynamic_skill_runtime_timeout_seconds", 60.0),
            policy=art.safety_profile if isinstance(art.safety_profile, dict) else {"profile": "read_only"},
        )
        skill_success = bool(result.get("success"))
        await self.skill_registry.record_usage(skill_id, skill_success)
        # 🔴 A-TEAM FIX: On successful execution, refresh last_validated_at
        # to extend the revalidation window — a successful real-world execution
        # is the strongest validation signal.
        if skill_success:
            art.last_validated_at = time.time()
            await self.skill_registry.save()

        if self.agent_slack:
            self.agent_slack.send(
                from_agent="SkillRuntime",
                to_agent=from_actor,
                data={
                    "message_type": "skill_execution_result",
                    "skill_id": skill_id,
                    "skill_name": art.name,
                    "result": result,
                },
            )
        if hasattr(self, "shared_context") and self.shared_context:
            self.shared_context.set(
                f"skill_execution_{from_actor}_{skill_id}",
                {"skill_id": skill_id, "skill_name": art.name, "result": result},
            )
        msg = f"Skill execution completed for {skill_id}: {'success' if result.get('success') else 'failed'}."
        yield {"module": "Synapse.core.conductor", "message": msg}
    
    async def _handle_knowledge_share_stream(
        self,
        action: Dict,
        from_actor: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle knowledge share action with target agent validation."""
        target_agent = action.get("target_agent")
        knowledge_type = action.get("type", "general")
        data = action.get("data", {})
        
        logger.info(f"📤 Knowledge share: {from_actor} → {target_agent} ({knowledge_type})")
        yield {"module": "Synapse.core.conductor", "message": f"I am handling knowledge share from '{from_actor}' to '{target_agent}' ({knowledge_type})"}
        
        # 🔥 A-TEAM FIX: Validate and resolve target_agent before sending
        # Agents may use incorrect names (e.g., "WhatsAppManager" instead of "BrowserExecutor")
        resolved_target = self._resolve_target_agent(target_agent, knowledge_type, data)
        
        if resolved_target != target_agent:
            logger.warning(f"⚠️ Target agent '{target_agent}' not found, resolved to '{resolved_target}'")
            yield {"module": "Synapse.core.conductor", "message": f"I resolved target agent from '{target_agent}' to '{resolved_target}'"}
        
        if self.agent_slack:
            if resolved_target == "all":
                # Broadcast to all agents
                yield {"module": "Synapse.core.conductor", "message": f"I am broadcasting knowledge share to all agents"}
                for agent_name in self.agent_directory.keys():
                    if agent_name != from_actor:
                        self.agent_slack.send(
                            from_agent=from_actor,
                            to_agent=agent_name,
                            data={
                                "message_type": "knowledge_share",
                                "knowledge_type": knowledge_type,
                                "data": data
                            }
                        )
                yield {"module": "Synapse.core.conductor", "message": f"I successfully broadcast knowledge share to all agents"}
            else:
                yield {"module": "Synapse.core.conductor", "message": f"I am sending knowledge share to '{resolved_target}'"}
                self.agent_slack.send(
                    from_agent=from_actor,
                    to_agent=resolved_target,
                    data={
                        "message_type": "knowledge_share",
                        "knowledge_type": knowledge_type,
                        "data": data
                    }
                )
                yield {"module": "Synapse.core.conductor", "message": f"I successfully sent knowledge share to '{resolved_target}'"}
    
    def _resolve_target_agent(
        self,
        target_agent: str,
        knowledge_type: str,
        data: Dict
    ) -> str:
        """
        Resolve target agent name with validation and fuzzy matching.
        
        Agents may output incorrect or deprecated target names (e.g., "WhatsAppManager" or "WhatsAppExecutor" instead of "BrowserExecutor").
        Note: WhatsAppExecutor has been removed - WhatsApp tasks should use BrowserExecutor.
        This method validates and resolves to the correct agent.
        
        Args:
            target_agent: The requested target agent name
            knowledge_type: Type of knowledge being shared
            data: The data being shared
            
        Returns:
            Resolved agent name, or "all" if no match found
        """
        if not target_agent or target_agent == "all":
            return "all"
        
        # Check if exact match exists
        if target_agent in self.agent_directory:
            return target_agent
        
        # Check actors registry directly (may differ from directory)
        if target_agent in self.actors:
            return target_agent
        
        logger.warning(f"⚠️ Target agent '{target_agent}' not found in agent directory")
        
        # 🔴 A-TEAM FIX: NO hardcoded keyword_mappings!
        # Instead, use capability-based matching from agent_directory
        # The agent_directory contains LLM-inferred capabilities for each actor
        target_lower = target_agent.lower()
        
        # Try matching by capability in agent_directory (semantic, not keyword)
        for agent_name, agent_info in self.agent_directory.items():
            capabilities = agent_info.get("capabilities", [])
            if isinstance(capabilities, list):
                caps_lower = [c.lower() for c in capabilities if isinstance(c, str)]
                # Check if any capability matches target keywords
                if any(target_lower in cap or cap in target_lower for cap in caps_lower):
                    logger.info(f"📍 Resolved '{target_agent}' → '{agent_name}' via capability matching")
                    return agent_name
        
        # 🆕 A-TEAM: Use AgentResolverAgent for intelligent LLM-based resolution
        if self.agent_resolver_agent and self.agent_directory:
            try:
                logger.info(f"🤖 Using AgentResolverAgent to resolve '{target_agent}' for '{knowledge_type}'")
                resolution_result = self.agent_resolver_agent.forward(
                    requested_agent_name=target_agent,
                    knowledge_type=knowledge_type,
                    request_context=data,
                    available_agents=self.agent_directory
                )
                
                resolved_name = resolution_result.get("resolved_agent_name", "all")
                confidence = resolution_result.get("confidence", 0.0)
                reasoning = resolution_result.get("reasoning", "")
                
                if resolved_name != "all" and confidence > 0.3:
                    logger.info(
                        f"✅ AgentResolverAgent resolved '{target_agent}' → '{resolved_name}' "
                        f"(confidence: {confidence:.2f})"
                    )
                    logger.debug(f"   Reasoning: {reasoning}")
                    return resolved_name
                else:
                    logger.warning(
                        f"⚠️ AgentResolverAgent could not confidently resolve '{target_agent}' "
                        f"(confidence: {confidence:.2f}), falling back to 'all'"
                    )
            except Exception as e:
                logger.error(f"❌ AgentResolverAgent failed: {e}")
                import traceback
                logger.debug(traceback.format_exc())
        
        # Last resort: broadcast to all agents
        logger.warning(f"⚠️ Could not resolve '{target_agent}', broadcasting to all agents instead")
        return "all"
    
    async def _handle_knowledge_share(
        self,
        action: Dict,
        from_actor: str
    ) -> None:
        """Synchronous wrapper for _handle_knowledge_share_stream."""
        async for event in self._handle_knowledge_share_stream(action, from_actor):
            pass
    
    async def _handle_actor_todo_update_stream(
        self,
        action: Dict,
        from_actor: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Handle actor→TODO communication for task splitting/signaling.
        
        🔴 A-TEAM FIX 17: Actors can signal TODO changes via collaboration_actions
        with action="update_todo". Supported sub-actions:
        - split_task: Actor says task is too complex, provides subtask list
        - add_subtask: Actor discovers new prerequisite or follow-up work
        - skip_task: Actor determines a task is unnecessary
        - update_description: Actor has better understanding of what's needed
        - signal_blocked: Actor signals it's blocked on a dependency
        
        Args:
            action: Dict with 'todo_action' and relevant params
            from_actor: Name of actor making the request
            
        Yields:
            Event dictionaries with module and conversational message
        """
        todo_action = action.get("todo_action", "")
        task_id = action.get("task_id", "")
        
        yield {
            "module": "Synapse.core.conductor",
            "message": f"I am processing TODO update from actor '{from_actor}': {todo_action}"
        }
        
        try:
            if todo_action == "split_task":
                # Actor wants to split its current task into subtasks
                subtasks = action.get("subtasks", [])
                if not subtasks:
                    logger.warning(f"⚠️ Actor {from_actor} requested split_task but provided no subtasks")
                    return
                
                for i, sub in enumerate(subtasks[:10]):  # Limit to 10 subtasks
                    new_id = f"{task_id}_sub{i}_{int(time.time())}"
                    new_task = SubtaskState(
                        task_id=new_id,
                        description=sub.get("description", f"Subtask {i} of {task_id}"),
                        actor=sub.get("actor", from_actor),
                        depends_on=sub.get("depends_on", [task_id] if i == 0 else [f"{task_id}_sub{i-1}_{int(time.time())}"]),
                        priority=sub.get("priority", 1.0)
                    )
                    self.todo.insert_task_after(task_id, new_task)
                    logger.info(f"  📋 Actor split: added subtask {new_id}")
                
                yield {
                    "module": "Synapse.core.conductor",
                    "message": f"Actor '{from_actor}' split task into {len(subtasks)} subtasks"
                }
                
            elif todo_action == "add_subtask":
                # Actor discovers new work needed
                desc = action.get("description", "")
                actor = action.get("target_actor", from_actor)
                depends_on = action.get("depends_on", [])
                new_id = f"actor_req_{from_actor}_{int(time.time())}"
                
                new_task = SubtaskState(
                    task_id=new_id,
                    description=desc,
                    actor=actor,
                    depends_on=depends_on,
                    priority=action.get("priority", 1.0)
                )
                
                # Insert after current task or at end
                insert_after = action.get("insert_after", task_id)
                if insert_after and insert_after in self.todo.subtasks:
                    self.todo.insert_task_after(insert_after, new_task)
                else:
                    # Add at the end
                    self.todo.subtasks[new_id] = new_task
                
                logger.info(f"  📋 Actor added subtask: {new_id} - {desc[:60]}")
                yield {
                    "module": "Synapse.core.conductor",
                    "message": f"Actor '{from_actor}' added new subtask: {desc[:80]}"
                }
                
            elif todo_action == "skip_task":
                # Actor determines a task is unnecessary
                reason = action.get("reason", "Actor determined task is unnecessary")
                skip_id = action.get("skip_task_id", task_id)
                if skip_id in self.todo.subtasks:
                    self.todo.subtasks[skip_id].status = TaskStatus.SKIPPED
                    logger.info(f"  ⏭️ Actor skipped task {skip_id}: {reason}")
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"Actor '{from_actor}' skipped task {skip_id}: {reason[:80]}"
                    }
                    
            elif todo_action == "update_description":
                # Actor has better understanding of what's needed
                new_desc = action.get("description", "")
                update_id = action.get("update_task_id", task_id)
                if new_desc and update_id in self.todo.subtasks:
                    self.todo.update_task(update_id, description=new_desc)
                    logger.info(f"  📝 Actor updated description for {update_id}")
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"Actor '{from_actor}' updated task description for {update_id}"
                    }
                    
            elif todo_action == "signal_blocked":
                # Actor signals it's blocked waiting for something
                blocked_on = action.get("blocked_on", "")
                blocked_id = action.get("blocked_task_id", task_id)
                if blocked_id in self.todo.subtasks:
                    self.todo.subtasks[blocked_id].status = TaskStatus.BLOCKED
                    logger.info(f"  🚫 Actor {from_actor} signals blocked: {blocked_on}")
                    yield {
                        "module": "Synapse.core.conductor",
                        "message": f"Actor '{from_actor}' is blocked on: {blocked_on[:80]}"
                    }
            else:
                logger.warning(f"⚠️ Unknown actor TODO action: {todo_action}")
                yield {
                    "module": "Synapse.core.conductor",
                    "message": f"Unknown actor TODO action: {todo_action}"
                }
            
            # 🔴 A-TEAM: Always re-emit DAG + task list after any TODO mutation
            if todo_action in ("split_task", "add_subtask", "skip_task", "update_description", "signal_blocked"):
                dag_update = self._build_dag_event_from_todo()
                if dag_update:
                    yield dag_update
                task_list_evt = self._build_task_list_event()
                if task_list_evt:
                    yield task_list_evt
                
        except Exception as e:
            logger.error(f"❌ Failed to process actor TODO update: {e}")
            yield {
                "module": "Synapse.core.conductor",
                "message": f"Failed to process actor TODO update: {str(e)[:100]}"
            }
    
    async def _handle_broadcast_stream(
        self,
        action: Dict,
        from_actor: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle broadcast action."""
        message_type = action.get("type", "general")
        data = action.get("data", {})
        
        logger.info(f"📢 Broadcast: {from_actor} → all ({message_type})")
        yield {"module": "Synapse.core.conductor", "message": f"I am handling broadcast from '{from_actor}' to all agents ({message_type})"}
        
        if self.agent_slack:
            for agent_name in self.agent_directory.keys():
                if agent_name != from_actor:
                    self.agent_slack.send(
                        from_agent=from_actor,
                        to_agent=agent_name,
                        data={
                            "message_type": "broadcast",
                            "broadcast_type": message_type,
                            "data": data
                        }
                    )
            yield {"module": "Synapse.core.conductor", "message": f"I successfully broadcast message to all agents"}
    
    async def _handle_broadcast(
        self,
        action: Dict,
        from_actor: str
    ) -> None:
        """Synchronous wrapper for _handle_broadcast_stream."""
        async for event in self._handle_broadcast_stream(action, from_actor):
            pass
    
    async def _run_pre_execution_research_stream(
        self,
        goal: str,
        kwargs: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Automatically call DomainExpert to research needed libraries/tools.
        
        🔥 A-TEAM CONSENSUS (2026-01-28): Use LLM-based inference, NO KEYWORDS!
        
        This delegates to DomainExpert agent to INFER what research is needed
        through LLM reasoning, not hardcoded keyword matching.
        
        Called BEFORE task execution to gather knowledge proactively.
        This is FULLY GENERIC and works for ANY task type.
        
        Args:
            goal: The main goal
            kwargs: Execution context
        
        Yields:
            Event dictionaries with module and conversational message
        """
        yield {"module": "Synapse.core.conductor", "message": "I am starting pre-execution research phase"}
        # Check if DomainExpert exists
        domain_expert_config = None
        for name, actor_config in self.actors.items():
            if "DomainExpert" in name or "domain" in name.lower():
                domain_expert_config = actor_config
                break
        
        if not domain_expert_config:
            logger.debug("⏭️  No DomainExpert found - skipping pre-execution research")
            yield {"module": "Synapse.core.conductor", "message": "I noticed no DomainExpert found, skipping pre-execution research"}
            return
        
        logger.info("🔬 Phase: Pre-Execution Research (LLM-based, zero hardcoding)")
        yield {"module": "Synapse.core.conductor", "message": "I am starting pre-execution research phase (LLM-based, zero hardcoding)"}
        
        # 🔥 NEW APPROACH: Delegate research need identification to DomainExpert
        # The DomainExpert uses its LLM to infer what domains are involved
        # and what libraries/tools need research. NO keyword matching here!
        
        base_research_instruction = f"""
RESEARCH NEED ANALYSIS (Pre-Execution):

Goal: {goal}

Your task:
1. Analyze this goal and determine what technical domains are involved
2. Infer what libraries, tools, or frameworks might be needed
3. Use web_search to research EACH domain you identify
4. Document your findings (installation, API, edge cases, best practices)
5. Share findings with other agents via collaboration_actions

CRITICAL RULES:
- DO NOT assume you know the libraries - RESEARCH them!
- Use web_search for EVERY domain you identify
- Be comprehensive - better to research too much than too little
- Infer domains through reasoning, NOT keyword matching
- This goal might involve domains you've never seen - that's OK, research them!

Process:
1. Read goal and infer domains (image processing? data analysis? web scraping? quantum computing?)
2. For each domain, formulate research query
3. Execute web_search(research_query)
4. Synthesize findings
5. Share with collaboration_actions

Example workflow (for ANY goal, not just this specific case):
→ Infer domains from goal semantics
→ web_search("Python libraries for [domain1]")  
→ web_search("Best practices for [domain2]")
→ web_search("[specific_tool] edge cases and gotchas")
→ Share findings: collaboration_actions = [{{"action": "share_knowledge", ...}}]

Start your research now!
"""
        
        # Wrap research instruction with environment context
        research_instruction = self._wrap_instruction_with_env_context(base_research_instruction)
        logger.info(f"🌍 Wrapped research instruction with environment context")
        yield {"module": "Synapse.core.conductor", "message": "I wrapped the research instruction with environment context"}
        
        try:
            logger.info("  📡 Delegating research need inference to DomainExpert...")
            yield {"module": "Synapse.core.conductor", "message": "I am delegating research need inference to DomainExpert"}
            
            # _execute_actor_with_overflow_protection is now an async generator
            async for event in self._execute_actor_with_overflow_protection(
                actor_config=domain_expert_config,
                task=TodoItem(
                    id="pre_research_inference",
                    description=research_instruction,
                    actor=domain_expert_config.name,
                    status="pending",
                    priority=0.6,  # Medium priority for research
                    estimated_reward=getattr(self.config, 'default_estimated_reward', 0.5)
                ),
                context=research_instruction,
                kwargs=kwargs,
                actor_context_dict=None  # 🔴 A-TEAM FIX: Add missing parameter
            ):
                # Yield all events from actor execution
                yield event
            
            logger.info("  ✅ DomainExpert completed pre-execution research")
            yield {"module": "Synapse.core.conductor", "message": "DomainExpert completed pre-execution research"}
            
        except Exception as e:
            logger.warning(f"  ⚠️  Pre-execution research failed: {e}")
            yield {"module": "Synapse.core.conductor", "message": f"I encountered an error during pre-execution research: {str(e)}"}
        
        logger.info("✅ Pre-execution research phase complete")
        yield {"module": "Synapse.core.conductor", "message": "I completed pre-execution research phase"}
    
    async def _run_pre_execution_research(
        self,
        goal: str,
        kwargs: Dict[str, Any]
    ) -> None:
        """Synchronous wrapper for _run_pre_execution_research_stream."""
        async for event in self._run_pre_execution_research_stream(goal, kwargs):
            pass
    
    # =========================================================================
    # 🎯 A-TEAM GAP FIXES: Helper Methods for Advanced Integrations
    # =========================================================================
    
    async def _re_evaluate_task_stream(
        self,
        failed_task: SubtaskState,
        execution_guidance: Dict[str, Any],
        failure_feedback: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        🎯 A-TEAM: Re-evaluate a failed task by sending it back through task breakdown flow.
        
        Flow:
        1. Extract original goal/context from failed task
        2. Add failure analysis to context
        3. Call TaskBreakdownAgent with enhanced context
        4. Call TodoCreatorAgent with updated actor suggestions
        5. Convert new ExecutableDAG to tasks
        6. Insert new tasks into TODO
        7. Mark original task as replaced
        
        Args:
            failed_task: The task that failed
            execution_guidance: Strategy execution guidance with actor suggestions
            failure_feedback: Auditor feedback explaining the failure
        """
        yield {"module": "Synapse.core.conductor", "message": f"Re-evaluating task {failed_task.task_id}..."}
        
        try:
            # Extract original goal
            original_goal = failed_task.description
            failure_notes = execution_guidance.get("breakdown_instructions", failure_feedback)
            
            # Enhance goal with failure context
            enhanced_goal = f"""
{original_goal}

RE-EVALUATION CONTEXT:
Previous attempt failed with: {smart_truncate(failure_feedback, max_tokens=125)}
Suggested improvements: {execution_guidance.get('breakdown_instructions', 'Re-evaluate task breakdown and actor assignment')}

Previous actor: {failed_task.actor}
Suggested actors: {', '.join([a.get('name', '') for a in execution_guidance.get('suggested_actors', [])])}
"""
            
            yield {"module": "Synapse.core.conductor", "message": f"Breaking down task with enhanced context..."}
            
            # Call TaskBreakdownAgent if available
            if hasattr(self, 'task_breakdown_agent') and self.task_breakdown_agent:
                # 🔴 A-TEAM FIX: Run synchronous DSPy forward() in thread to avoid blocking async event loop.
                # TaskBreakdownAgent.forward() makes LLM calls which can take seconds.
                task_dag = await asyncio.to_thread(
                    self.task_breakdown_agent.forward, implementation_plan=enhanced_goal
                )
            else:
                # Fallback: Use DynamicTaskPlanner
                if DYNAMIC_TASK_PLANNER_AVAILABLE and hasattr(self, 'task_planner'):
                    task_dag = await self.task_planner.breakdown_goal(enhanced_goal)
                else:
                    logger.warning("⚠️ No task breakdown agent available, cannot re-evaluate")
                    yield {"module": "Synapse.core.conductor", "message": "Cannot re-evaluate: no task breakdown agent available"}
                    return
            
            # Get suggested actors from guidance
            suggested_actors = execution_guidance.get("suggested_actors", [])
            
            # Call TodoCreatorAgent with actor hints
            if hasattr(self, 'todo_creator_agent') and self.todo_creator_agent:
                # Create actor list with hints
                actors = []
                for name, config in self.actors.items():
                    if config.enabled:
                        capabilities = config.capabilities or []
                        if not capabilities and config.metadata:
                            capabilities = config.metadata.get('capabilities', [])
                        
                        # Check if this actor is suggested
                        is_suggested = any(a.get('name') == name for a in suggested_actors)
                        priority_boost = 0.5 if is_suggested else 0.0
                        
                        from Synapse.agents.todo_creator_agent import Actor
                        actors.append(Actor(
                            name=name,
                            capabilities=capabilities,
                            description=self._get_agent_description(name, config),
                            priority_boost=priority_boost
                        ))
                
                # 🔴 A-TEAM FIX: create_executable_dag only accepts (dag, available_actors).
                # actor_hints are already encoded as priority_boost on Actor objects above,
                # so no need to pass them separately (which crashed with unexpected kwarg).
                # Convert Actor objects to dicts expected by create_executable_dag
                reeval_actors_dicts = [
                    {
                        'name': a.name,
                        'capabilities': a.capabilities,
                        'description': a.description,
                        'priority_boost': a.priority_boost,
                    }
                    for a in actors
                ]
                executable_dag = await asyncio.to_thread(
                    self.todo_creator_agent.create_executable_dag,
                    task_dag,
                    reeval_actors_dicts
                )
            else:
                logger.warning("⚠️ No TodoCreatorAgent available, using simple assignment")
                # Simple fallback: assign to first available actor
                executable_dag = task_dag  # Use task_dag as-is
            
            # Convert to TODO tasks
            new_task_ids = []
            yield {"module": "Synapse.core.conductor", "message": f"Creating {len(executable_dag.assignments)} new tasks from re-evaluation..."}
            
            for task_id, task in executable_dag.assignments.items():
                new_task_id = f"{failed_task.task_id}_reeval_{task_id}"
                
                # Convert dependencies
                new_deps = [f"{failed_task.task_id}_reeval_{dep}" for dep in task.depends_on]
                
                # Add task to TODO
                self.todo.add_task(
                    task_id=new_task_id,
                    description=task.description,
                    actor=task.actor.name if hasattr(task.actor, 'name') else str(task.actor),
                    depends_on=new_deps,
                    priority=failed_task.priority
                )
                new_task_ids.append(new_task_id)
            
            # Mark original as replaced
            self.todo.mark_task_replaced(failed_task.task_id, new_task_ids)
            
            yield {"module": "Synapse.core.conductor", "message": f"Re-evaluation complete: created {len(new_task_ids)} new tasks to replace {failed_task.task_id}"}
            logger.info(f"✅ Re-evaluation complete: {failed_task.task_id} → {len(new_task_ids)} new tasks")
            
        except Exception as e:
            logger.error(f"❌ Re-evaluation failed: {e}")
            logger.debug(f"Traceback: {traceback.format_exc()}")
            yield {"module": "Synapse.core.conductor", "message": f"Re-evaluation failed: {str(e)[:100]}"}
            # Fallback: mark original as failed
            self.todo.fail_task(failed_task.task_id, failure_feedback)
            # 📋 REAL-TIME UI: Emit task_list after re-evaluation failure
            _tl_reeval_fail = self._build_task_list_event()
            if _tl_reeval_fail:
                yield _tl_reeval_fail
    
    async def _sync_todo_with_dep_graph_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Sync MarkovianTODO state with DynamicDependencyGraph.
        
        🎯 A-TEAM GAP #2: Enables parallel execution and dynamic reordering.
        🔧 FIX: Made async and fixed method calls to match DynamicDependencyGraph API
        
        Yields:
            Event dictionaries with module and conversational message
        """
        yield {"module": "Synapse.core.conductor", "message": "I am syncing TODO state with dependency graph"}
        # Add all tasks to dependency graph
        yield {"module": "Synapse.core.conductor", "message": f"I am adding {len(self.todo.subtasks)} tasks to dependency graph"}
        for task_id, task in self.todo.subtasks.items():
            # Check if task exists by checking if it's in dependencies dict
            if task_id not in self.dependency_graph._dependencies:
                async for event in self.dependency_graph.add_task_stream(task_id):
                    yield event
        
        # Add dependencies
        yield {"module": "Synapse.core.conductor", "message": "I am adding task dependencies to the graph"}
        for task_id, task in self.todo.subtasks.items():
            for dep in task.depends_on:
                if dep in self.todo.subtasks:
                    # Ensure dependency task exists
                    if dep not in self.dependency_graph._dependencies:
                        async for event in self.dependency_graph.add_task_stream(dep):
                            yield event
                    # Add dependency relationship (dep must complete before task_id)
                    async for event in self.dependency_graph.add_dependency_stream(dep, task_id):
                        yield event
        
        # Mark completed tasks
        yield {"module": "Synapse.core.conductor", "message": f"I am marking {len(self.todo.completed_tasks)} completed tasks"}
        for completed_id in self.todo.completed_tasks:  # FIX: completed → completed_tasks (set)
            async for event in self.dependency_graph.mark_completed_stream(completed_id):
                yield event
        
        # Mark failed tasks
        if hasattr(self.todo, 'failed_tasks'):
            yield {"module": "Synapse.core.conductor", "message": f"I am marking {len(self.todo.failed_tasks)} failed tasks"}
            for failed_id in self.todo.failed_tasks:  # FIX: failed_tasks is a set, not dict
                async for event in self.dependency_graph.mark_failed_stream(failed_id):
                    yield event
        # 🔴 A-TEAM FIX 14: Bi-directional sync — DAG→TODO for completed tasks
        # If dependency graph has tasks marked completed that TODO doesn't know about
        if hasattr(self.dependency_graph, '_completed_tasks'):
            dag_completed = getattr(self.dependency_graph, '_completed_tasks', set())
            todo_completed = self.todo.completed_tasks
            newly_completed = dag_completed - todo_completed
            if newly_completed:
                for task_id in newly_completed:
                    if task_id in self.todo.subtasks:
                        logger.info(f"  🔄 DAG→TODO sync: marking {task_id} as completed")
                        self.todo.complete_task(task_id)
                # 📋 REAL-TIME UI: Emit task_list after DAG→TODO complete sync
                _tl_dag_sync = self._build_task_list_event()
                if _tl_dag_sync:
                    yield _tl_dag_sync
        
        # 🔴 A-TEAM FIX 14: Bi-directional sync — DAG→TODO for failed tasks
        if hasattr(self.dependency_graph, '_failed_tasks'):
            dag_failed = getattr(self.dependency_graph, '_failed_tasks', set())
            todo_failed = self.todo.failed_tasks if hasattr(self.todo, 'failed_tasks') else set()
            newly_failed = dag_failed - todo_failed
            if newly_failed:
                for task_id in newly_failed:
                    if task_id in self.todo.subtasks:
                        logger.info(f"  🔄 DAG→TODO sync: marking {task_id} as failed")
                        self.todo.fail_task(task_id, "Failed in dependency graph (synced from DAG)")
                # 📋 REAL-TIME UI: Emit task_list after DAG→TODO fail sync
                _tl_dag_fail = self._build_task_list_event()
                if _tl_dag_fail:
                    yield _tl_dag_fail
        
        yield {"module": "Synapse.core.conductor", "message": "I completed syncing TODO state with dependency graph (bi-directional)"}
        
        # 🔍 DEBUG: Yield complete task list for frontend debugging
        try:
            all_tasks = self.todo.get_all_tasks_list()
            yield {
                "module": "Synapse.core.conductor",
                "message": f"I have created {len(all_tasks)} tasks in total",
                "type": "task_list",
                "data": {
                    "total_tasks": len(all_tasks),
                    "tasks": all_tasks,
                    "root_task": self.todo.root_task,
                    "completed_count": len(self.todo.completed_tasks),
                    "failed_count": len(self.todo.failed_tasks) if hasattr(self.todo, 'failed_tasks') else 0
                }
            }
        except Exception as e:
            logger.warning(f"Failed to yield task list: {e}")
    
    async def _sync_todo_with_dep_graph(self):
        """Synchronous wrapper for _sync_todo_with_dep_graph_stream."""
        async for event in self._sync_todo_with_dep_graph_stream():
            pass
    
    async def _adapt_todo_with_learning_stream(
        self,
        recent_failures: List[Dict],
        q_learning_insights: Dict,
        marl_predictions: Dict,
        brain_memory_patterns: List[Dict]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Use AgenticTODOAdapter to mutate TODO based on learning.
        
        🎯 A-TEAM GAP #1: LLM-based TODO mutation (no hardcoding).
        
        Yields:
            Event dictionaries with module and conversational message
        """
        yield {"module": "Synapse.core.conductor", "message": "I am adapting TODO with learning insights"}
        try:
            yield {"module": "Synapse.core.conductor", "message": "I am calling AgenticTODOAdapter to mutate TODO based on learning"}
            # 🔴 A-TEAM FIX: Pass agent_directory so LLM can assign actors to new tasks
            agent_dir = ""
            try:
                agent_dir = self._build_agent_directory()
            except Exception:
                agent_dir = json.dumps(list(self.actors.keys()))
            
            actions = await self.todo_adapter.adapt_todo(
                todo=self.todo,
                recent_failures=recent_failures,
                q_learning_insights=q_learning_insights,
                marl_predictions=marl_predictions,
                brain_memory_patterns=brain_memory_patterns,
                agent_directory=agent_dir
            )
            
            if actions:
                logger.info(f"🔄 TODO adapted: {len(actions)} changes applied")
                yield {"module": "Synapse.core.conductor", "message": f"I adapted TODO with {len(actions)} changes"}
                # Re-sync with dependency graph after changes
                async for event in self._sync_todo_with_dep_graph_stream():
                    yield event
                
                # 🔴 A-TEAM AUDIT FIX: Re-emit DAG and task list after adaptation
                dag_event = self._build_dag_event_from_todo()
                if dag_event:
                    yield dag_event
                _tl_adapt = self._build_task_list_event()
                if _tl_adapt:
                    yield _tl_adapt
                
                # 🔴 A-TEAM FIX: Checkpoint after TODO adaptation changes
                # Ensures adapted state is preserved if process is interrupted
                try:
                    self.todo.checkpoint()
                    if self.persistence_manager:
                        self.persistence_manager.save_markovian_todo(self.todo)
                        logger.info(f"💾 Checkpoint saved after TODO adaptation ({len(actions)} changes)")
                except Exception as e:
                    logger.debug(f"  ⚠️ Checkpoint after adaptation failed: {e}")
                
                # Update shared_context with new TODO state
                if hasattr(self, 'shared_context') and self.shared_context:
                    try:
                        self.shared_context.set('todo_state', self.todo.get_state_summary())
                    except Exception:
                        pass
            
            yield {"type": "result", "result": actions, "module": "Synapse.core.conductor", "message": "I am returning the adapted TODO actions"}
            return
        except Exception as e:
            logger.error(f"TODO adaptation failed: {e}")
            yield {"module": "Synapse.core.conductor", "message": f"I encountered an error while adapting TODO: {str(e)}"}
            yield {"type": "result", "result": [], "module": "Synapse.core.conductor", "message": "I am returning empty list due to error"}
            return
    
    async def _route_failure_to_collaborators(
        self,
        task: 'SubtaskState',
        auditor_feedback: str,
        context: Dict
    ) -> Optional[Dict]:
        """
        Use AgenticFeedbackRouter to decide if failure should be routed to another actor.
        
        🎯 A-TEAM GAP #3: Intelligent failure routing for collaboration.
        🧠 A-TEAM ENHANCEMENT E7: Q-value enriched routing decisions.
        """
        try:
            # 🔧 FIX: Build proper parameters for AgenticFeedbackRouter
            # Convert available_agents from List[str] to Dict[str, Dict]
            available_actors_dict = {}
            for actor_name in self.actors.keys():
                actor_config = self.actors[actor_name]
                # 🧠 E7: Add Q-value context for each actor so routing is data-driven
                q_value_for_task = 0.5  # default
                if hasattr(self, 'enhanced_agent_selector') and self.enhanced_agent_selector:
                    try:
                        q_value_for_task = self.enhanced_agent_selector._get_q_value(
                            actor_name,
                            self.enhanced_agent_selector._extract_task_features(task)
                        )
                    except Exception:
                        pass
                available_actors_dict[actor_name] = {
                    'capabilities': getattr(actor_config, 'capabilities', []),
                    'provides': getattr(actor_config, 'provides', []),
                    'dependencies': getattr(actor_config, 'dependencies', []),
                    'goal': getattr(actor_config, 'goal', ''),
                    'q_value_for_task': q_value_for_task,  # 🧠 E7: Q-value context
                    'success_rate': getattr(actor_config, 'success_rate', None),
                }
            
            # Build task dependencies
            task_dependencies = {}
            for task_id, subtask in self.todo.subtasks.items():
                task_dependencies[subtask.actor] = subtask.depends_on
            
            # Build swarm state
            swarm_state = {
                'completed_tasks': [t.task_id for t in self.todo.subtasks.values() if t.status == TaskStatus.COMPLETED],
                'pending_tasks': [t.task_id for t in self.todo.subtasks.values() if t.status == TaskStatus.PENDING],
                'failed_tasks': list(self.todo.failed_tasks.keys()) if hasattr(self.todo.failed_tasks, 'keys') else []
            }
            
            # Build shared scratchpad (actor outputs)
            shared_scratchpad = {}
            if hasattr(self, 'io_manager') and self.io_manager:
                all_outputs = self.io_manager.get_all_outputs()
                for actor_name, output in all_outputs.items():
                    if hasattr(output, 'output_fields'):
                        shared_scratchpad[actor_name] = output.output_fields
                    else:
                        shared_scratchpad[actor_name] = smart_truncate(str(output), max_tokens=125)  # 🔴 A-TEAM FIX
            
            feedback_messages = await self.feedback_router.route_feedback(
                error_message=auditor_feedback,
                failing_actor_name=task.actor,
                failing_actor_goal=task.description,
                available_actors=available_actors_dict,
                task_dependencies=task_dependencies,
                swarm_state=swarm_state,
                shared_scratchpad=shared_scratchpad
            )
            
            # Convert List[FeedbackMessage] to dict format expected by caller
            if feedback_messages and len(feedback_messages) > 0:
                # Extract target agents and reasons from feedback messages
                target_agents = [msg.target_actor for msg in feedback_messages]
                reasons = [msg.context.get('reasoning', 'No reasoning provided') for msg in feedback_messages]
                
                routing_decision = {
                    'should_route': True,
                    'target_agent': target_agents[0] if target_agents else None,
                    'target_agents': target_agents,
                    'reason': reasons[0] if reasons else 'Agentic routing decision',
                    'feedback_messages': feedback_messages
                }
                
                logger.info(f"🔀 Routing failure to {target_agents}: {reasons[0] if reasons else 'No reason'}")
                return routing_decision
            
            return None
        except Exception as e:
            logger.error(f"Failure routing failed: {e}")
            return None
    
    def _get_current_state(self, current_subtask=None) -> Dict[str, Any]:
        """
        Get RICH current state for Q-prediction.
        
        🔥 A-TEAM CRITICAL: State must capture semantic context!
        
        Includes:
        1. Query semantics (what user asked)
        2. Current subtask context (what's being worked on NOW)
        3. Error patterns (what failed)
        4. Tool usage (what worked)
        5. Actor outputs (what was produced)
        6. Memory context (what was learned)
        
        Args:
            current_subtask: Optional SubtaskState being executed (provides rich task desc)
        """
        # === 1. TASK PROGRESS (with completed task descriptions) ===
        completed_descs = []
        pending_descs = []
        failed_descs = []
        if hasattr(self, 'todo') and self.todo:
            for t in self.todo.subtasks.values():
                if t.task_id in self.todo.completed_tasks:
                    completed_descs.append(smart_truncate(t.description, max_tokens=60))
                elif t.status == TaskStatus.PENDING:
                    pending_descs.append(smart_truncate(t.description, max_tokens=60))
                elif t.task_id in self.todo.failed_tasks:
                    failed_descs.append(smart_truncate(t.description, max_tokens=60))
        
        state = {
            'todo': {
                'completed': len(completed_descs),
                'completed_tasks': completed_descs[:5],  # Last 5 for context
                'pending': len(pending_descs),
                'pending_tasks': pending_descs[:3],  # Next 3 for planning
                'failed': len(failed_descs),
                'failed_tasks': failed_descs[:3],  # Recent failures for learning
            },
            'trajectory_length': len(self.trajectory),
            'recent_outcomes': [t.get('passed', False) for t in self.trajectory[-5:]]
        }
        
        # === 1b. CURRENT SUBTASK CONTEXT (what's being worked on NOW) ===
        if current_subtask:
            subtask_ctx = {
                'description': smart_truncate(current_subtask.description, max_tokens=200),
                'actor': current_subtask.actor,
                'attempt_count': current_subtask.attempts,  # 🔴 A-TEAM FIX: was attempt_count (wrong attr name)
                'max_attempts': current_subtask.max_attempts,
                'status': str(current_subtask.status),
                'priority': current_subtask.priority,
            }
            # Include failure history for context (critical for avoiding repeated mistakes)
            if current_subtask.failure_reasons:
                subtask_ctx['previous_failures'] = current_subtask.failure_reasons[-3:]
            if current_subtask.retry_feedback:
                subtask_ctx['retry_feedback'] = [
                    smart_truncate(str(fb.get('feedback', '')), max_tokens=80) 
                    for fb in current_subtask.retry_feedback[-2:]
                ]
            if current_subtask.depends_on:
                subtask_ctx['depends_on'] = current_subtask.depends_on
            state['current_subtask'] = subtask_ctx
        
        # === 2. QUERY CONTEXT (CRITICAL!) ===
        # Try multiple sources for query
        query = None
        
        # Source 1: SharedContext
        if hasattr(self, 'shared_context') and self.shared_context:
            query = self.shared_context.get('query') or self.shared_context.get('goal')
        
        # Source 2: Context guard buffers (if available)
        if not query and hasattr(self, 'context_guard') and self.context_guard:
            # SmartContextGuard stores content in buffers
            for priority_buffer in self.context_guard.buffers.values():
                for key, content, _ in priority_buffer:
                    if key == 'ROOT_GOAL':
                        query = content
                        break
                if query:
                    break
        
        # Source 3: TODO root task
        if not query and hasattr(self, 'todo') and self.todo:
            query = self.todo.root_task
        
        if query:
            state['query'] = smart_truncate(str(query), max_tokens=500)  # 🔴 A-TEAM FIX: was 125, now 500
        
        # === 2b. MEMORY CONTEXT (what was learned from past runs) ===
        if hasattr(self, 'shared_memory') and self.shared_memory:
            try:
                # Retrieve recent memories relevant to current context
                retrieval_query = query or (current_subtask.description if current_subtask else "")
                if retrieval_query:
                    # 🔴 A-TEAM FIX: Use correct HierarchicalMemory.retrieve() API
                    # Was passing top_k=3 which is wrong — needs goal + budget_tokens
                    _goal = self.todo.root_task if hasattr(self, 'todo') and self.todo else str(retrieval_query)
                    memories = self.shared_memory.retrieve(
                        query=smart_truncate(str(retrieval_query), max_tokens=100),
                        goal=_goal,
                        budget_tokens=500
                    )
                    if memories:
                        mem_summaries = []
                        for mem in memories[:3]:
                            content = getattr(mem, 'content', '') if hasattr(mem, 'content') else (mem.get('content', '') if isinstance(mem, dict) else str(mem))
                            mem_summaries.append(smart_truncate(str(content), max_tokens=150))
                        state['relevant_memories'] = mem_summaries
            except Exception as e:
                logger.debug(f"Memory retrieval for state context failed (non-critical): {e}")
        
        
        # === 4. ACTOR OUTPUT CONTEXT ===
        if hasattr(self, 'io_manager') and self.io_manager:
            all_outputs = self.io_manager.get_all_outputs()
            output_summary = {}
            for actor_name, output in all_outputs.items():
                if hasattr(output, 'output_fields') and output.output_fields:
                    output_summary[actor_name] = list(output.output_fields.keys())
            if output_summary:
                state['actor_outputs'] = output_summary
        
        # === 5. ERROR PATTERNS (CRITICAL FOR LEARNING!) ===
        if self.trajectory and self.error_pattern_extractor:
            try:
                result = self.error_pattern_extractor(
                    trajectory_json=smart_truncate(json.dumps(self.trajectory, default=str), max_tokens=750),
                    goal_context=smart_truncate(self.todo.root_task, max_tokens=500) if self.todo else ""
                )
                if hasattr(result, "error_patterns"):
                    state['errors'] = json.loads(result.error_patterns)
            except Exception as e:
                logger.debug(f"Error pattern extraction failed: {e}")
        
        # === 6. TOOL USAGE PATTERNS (with params and results for learning) ===
        successful_tools = []
        failed_tools = []
        tool_calls = []
        tool_details = []  # Rich tool call info for LLM understanding
        
        for step in self.trajectory:
            if step.get('tool_calls'):
                for tc in step.get('tool_calls', []):
                    tool_name = tc.get('tool') if isinstance(tc, dict) else str(tc)
                    tool_calls.append(tool_name)
                    
                    if isinstance(tc, dict):
                        if tc.get('success'):
                            successful_tools.append(tool_name)
                        else:
                            failed_tools.append(tool_name)
                        
                        # Capture rich tool details (params + key results) for context
                        detail = {'tool': tool_name, 'success': tc.get('success', False)}
                        # Include key parameters (URL, selector, query - critical for learning)
                        params = tc.get('params', tc.get('args', {}))
                        if isinstance(params, dict):
                            for key in ['url', 'selector', 'query', 'search_query', 'text', 'file_path', 'command']:
                                if key in params:
                                    detail[key] = smart_truncate(str(params[key]), max_tokens=60)
                        # Include key results
                        result = tc.get('result', tc.get('output', {}))
                        if isinstance(result, dict):
                            for key in ['current_url', 'title', 'status', 'error', 'file_path']:
                                if key in result:
                                    detail[key] = smart_truncate(str(result[key]), max_tokens=60)
                        tool_details.append(detail)
        
        if tool_calls:
            state['tool_calls'] = tool_calls[-10:]
        if successful_tools:
            state['successful_tools'] = list(dict.fromkeys(successful_tools))
        if failed_tools:
            state['failed_tools'] = list(dict.fromkeys(failed_tools))
        if tool_details:
            state['tool_details'] = tool_details[-5:]  # Last 5 with full context
        
        # === 7. CURRENT ACTOR ===
        if self.trajectory and self.trajectory[-1].get('actor'):
            state['current_actor'] = self.trajectory[-1]['actor']
        
        # === 8. VALIDATION CONTEXT ===
        for step in self.trajectory[-3:]:  # Last 3 steps
            if step.get('architect_confidence'):
                state['architect_confidence'] = step['architect_confidence']
            if step.get('auditor_result'):
                state['auditor_result'] = step['auditor_result']
            if step.get('validation_passed') is not None:
                state['validation_passed'] = step['validation_passed']
        
        # === 9. EXECUTION STATS ===
        state['attempts'] = len(self.trajectory)
        state['success'] = any(t.get('passed', False) for t in self.trajectory)
        
        # === 10. VISUAL CONTEXT AVAILABILITY ===
        # 🔴 A-TEAM FIX: Indicate VLM capabilities for actors that need visual state
        # Visual state = P(state | image, current_task, react_state, issue_context, goal)
        # Any actor can use visual inspection tools on demand for:
        # - Browser state (current app state, button locations, UI errors)
        # - Presentation appearance (design fidelity, layout, colors)
        # - Terminal rendering (front-end output, file content verification)
        # - Code files (indentation errors, formatting issues)
        visual_tools_available = False
        try:
            # Check if visual inspector tools are registered in any actor's toolset
            for actor_name, actor_config in self.actors.items():
                agent = actor_config.agent
                if agent:
                    tools_list = getattr(agent, '_tools_list', None) or getattr(agent, 'TOOLS', None) or getattr(type(agent), 'TOOLS', None)
                    if tools_list:
                        for tool in tools_list:
                            tool_name = getattr(tool, '__name__', '')
                            if 'visual_inspect' in tool_name or 'screenshot' in tool_name:
                                visual_tools_available = True
                                break
                if visual_tools_available:
                    break
        except Exception:
            pass
        
        state['visual_context'] = {
            'vlm_available': visual_tools_available,
            'capabilities': [
                'screenshot_and_inspect',
                'file_to_image_and_inspect',
                'parallel_visual_inspection',
                'pptx_slide_inspection',
                'browser_state_extraction',
                'code_indentation_check'
            ] if visual_tools_available else [],
            'note': 'Actors can call visual inspection tools on-demand to extract '
                     'visual state from images, files, or screenshots for informed decision-making.'
        }
        
        return state
    
    def _get_available_actions(self) -> List[Dict[str, Any]]:
        """Get available actions for exploration."""
        actions = []
        for name, config in self.actors.items():
            actions.append({
                'actor': name,
                'action': 'execute',
                'enabled': config.enabled
            })
        return actions
    
    def _clone_actor_config(self, original: ActorConfig, clone_id: int = 1) -> Optional[ActorConfig]:
        """
        🧬 A-TEAM: Clone an ActorConfig for parallel same-actor execution.
        
        Creates a NEW agent instance from the same agent class, with:
        - Independent internal state (no shared mutation)
        - Same tools, prompts, and configuration
        - A unique clone_id suffix for logging/debugging
        
        Strategy:
        - Instantiate a fresh agent from agent_class (stored on config)
        - Copy all non-agent config fields
        - Return new ActorConfig with independent agent instance
        
        Context Management on Divergence:
        - Each clone stores results under task_id (not just actor name)
        - After parallel execution, results merge back into shared_context
        - Original actor instance is NOT mutated
        
        Returns:
            Cloned ActorConfig or None if cloning fails.
        """
        try:
            import copy
            
            # Get the agent class from the original instance
            # 🔥 A-TEAM CRITICAL FIX: Unwrap SynapseCore to get the actual agent!
            # After __init__, original.agent is SynapseCore(actor=RealAgent).
            # We must clone the REAL agent, not the wrapper.
            #
            # 🚨 IMPORT PATH BUG FIX: isinstance() fails when the same class is
            # imported via different sys.path entries (e.g. "Synapse.core.synapse_core"
            # vs "core.synapse_core"). Use class-name check + .actor attribute instead.
            agent_instance = original.agent
            _is_synapse_wrapper = (
                type(agent_instance).__name__ == 'SynapseCore'
                and hasattr(agent_instance, 'actor')
            )
            if _is_synapse_wrapper:
                agent_instance = agent_instance.actor  # Unwrap to real agent (e.g. BrowserExecutor)
                logger.info(f"🧬 Unwrapped SynapseCore → actual agent: {type(agent_instance).__name__}")
            else:
                logger.info(f"🧬 Agent is NOT SynapseCore wrapper (type={type(agent_instance).__name__}), using as-is")
            agent_class = type(agent_instance) if agent_instance else None
            
            if agent_class is None:
                logger.warning(f"🧬 Cannot clone {original.name}: no agent instance")
                return None
            
            # Create a new agent instance from the same class
            try:
                # Try to instantiate with no args (most DSPy agents)
                new_agent = agent_class()
                logger.info(f"🧬 Cloned {original.name} clone #{clone_id} via default constructor")
            except TypeError:
                try:
                    # Fall back to shallow copy (preserves class structure)
                    new_agent = copy.copy(agent_instance)
                    logger.info(f"🧬 Cloned {original.name} clone #{clone_id} via shallow copy")
                except Exception:
                    # Last resort: use the original (better than failing)
                    new_agent = agent_instance
                    logger.warning(f"🧬 Clone failed for {original.name}, sharing original instance")
            
            # Transfer tools and additional tools from original
            if hasattr(agent_instance, '_synapse_additional_tools'):
                new_agent._synapse_additional_tools = agent_instance._synapse_additional_tools
            if hasattr(agent_instance, 'TOOLS'):
                if not hasattr(new_agent, 'TOOLS') or new_agent.TOOLS != agent_instance.TOOLS:
                    new_agent.TOOLS = agent_instance.TOOLS
            
            # Create cloned config (reuse all fields except agent)
            cloned = ActorConfig(
                name=original.name,  # Keep same name for task routing
                agent=new_agent,
                architect_prompts=original.architect_prompts,
                auditor_prompts=original.auditor_prompts,
                capabilities=original.capabilities if hasattr(original, 'capabilities') else None,
                dependencies=original.dependencies if hasattr(original, 'dependencies') else [],
                metadata=original.metadata if hasattr(original, 'metadata') else None,
                validation_mode=original.validation_mode,
                model=original.model if hasattr(original, 'model') else None,
                gateway=original.gateway if hasattr(original, 'gateway') else None,
                api_key_env=original.api_key_env if hasattr(original, 'api_key_env') else None,
                api_base_env=original.api_base_env if hasattr(original, 'api_base_env') else None,
                is_critical=original.is_critical,
                max_retries=original.max_retries,
                retry_strategy=original.retry_strategy,
                is_executor=original.is_executor if hasattr(original, 'is_executor') else False,
                enabled=original.enabled,
            )
            
            # Apply the same SynapseCore wrapping that the original got
            try:
                cloned.agent = self._wrap_actor_with_synapse(cloned)
                logger.info(f"🧬 SynapseCore wrapped for clone #{clone_id} of {original.name}")
            except Exception as e:
                logger.warning(f"🧬 SynapseCore wrap failed for clone: {e}")
            
            return cloned
            
        except Exception as e:
            logger.error(f"🧬 Actor cloning failed for {original.name}: {e}")
            return None
    
    def _build_actor_context(
        self, 
        task: TodoItem, 
        actor_config: ActorConfig
    ) -> Tuple[Tuple[str, Dict], Dict, list]:
        """
        Build context for actor execution.
        
        A-Team Enhancement: FUTURE-AWARE retrieval.
        Considers not just current task but upcoming TODO items.
        
        Returns:
            Tuple of ((context_string, context_meta), actor_context_from_provider, memory_events)
            where memory_events is a list of dicts to yield to the frontend for the Memory panel.
        """
        build_start = time.time()
        logger.info(f"🔨 BUILD_ACTOR_CONTEXT: actor={actor_config.name} | task={task.task_id} | "
                   f"task_desc='{task.description[:100]}...'")
        
        # 🧠 Collect memory events for the frontend Memory panel
        _memory_events: list = []
        
        # Use context guard to build within limits
        logger.debug(f"  Step 1: Creating SmartContextGuard | max_tokens={self.config.max_context_tokens}")
        guard = SmartContextGuard(self.config.max_context_tokens, config=self.config)
        logger.debug(f"  ✅ SmartContextGuard created")
        
        # CRITICAL: Task and goal
        logger.debug(f"  Step 2: Registering CRITICAL context")
        logger.debug(f"    Registering CURRENT_TASK: '{task.description[:100]}...'")
        guard.register_critical("CURRENT_TASK", task.description)
        logger.debug(f"    Registering ROOT_GOAL: '{self.todo.root_task[:100] if self.todo.root_task else 'None'}...'")
        guard.register_critical("ROOT_GOAL", self.todo.root_task)
        logger.debug(f"  Step 3: Registering TODO_STATE")
        if hasattr(self, "todo") and self.todo:
            try:
                todo_summary = self.todo.get_state_summary()
                logger.debug(f"    TODO_STATE length: {len(str(todo_summary))} chars")
                guard.register("TODO_STATE", todo_summary, guard.HIGH)
                logger.debug(f"    ✅ TODO_STATE registered")
            except Exception as e:
                logger.debug(f"    ⚠️  TODO summary unavailable: {e}")
        else:
            logger.debug(f"    ⚠️  No TODO available")

        # HIGH: Reusable dynamic skills catalog for this actor (if enabled).
        # Item 236: Enriched with effective_confidence, needs_revalidation, and
        # recently-added marker + usage examples from memory when available.
        if self.skill_registry:
            try:
                skills = []
                _recently_added = []
                _now = time.time()
                _recent_threshold = 86400 * 2  # Skills added in last 2 days = "recent"
                # Async API, but _build_actor_context is sync; use cached registry snapshot via direct index read.
                if hasattr(self.skill_registry, "_artifacts"):
                    for _sid, _art in self.skill_registry._artifacts.items():
                        if getattr(_art, "status", "") == "approved":
                            _entry = {
                                "skill_id": getattr(_art, "skill_id", ""),
                                "name": getattr(_art, "name", ""),
                                "description": getattr(_art, "description", ""),
                                "entrypoint": getattr(_art, "entrypoint", "run"),
                                "module_path": getattr(_art, "module_path", ""),
                                "tags": getattr(_art, "tags", []),
                                "success_rate": getattr(_art, "success_rate", 1.0),
                                # Item 229: Include confidence metadata
                                "effective_confidence": getattr(_art, "effective_confidence", 1.0),
                                "needs_revalidation": getattr(_art, "needs_revalidation", False),
                            }
                            skills.append(_entry)
                            # Item 236: Mark recently added skills
                            if (_now - getattr(_art, "created_at", 0)) < _recent_threshold:
                                _recently_added.append(_entry["name"])
                
                # Item 236: Enrich with usage examples from memory (if available)
                if skills and self.shared_memory:
                    try:
                        # 🔴 A-TEAM FIX: Use correct HierarchicalMemory.retrieve() API
                        _skill_goal = self.todo.root_task if hasattr(self, 'todo') and self.todo else "skill usage"
                        _skill_memories = self.shared_memory.retrieve(
                            query="skill usage example",
                            goal=_skill_goal,
                            budget_tokens=300
                        )
                        if _skill_memories:
                            _usage_hints = [
                                smart_truncate(str(getattr(m, 'content', m)), max_tokens=80)
                                for m in _skill_memories[:3]
                            ]
                            skills.append({
                                "_usage_examples_from_memory": _usage_hints,
                                "_recently_added_skills": _recently_added[:5],
                            })
                    except Exception:
                        pass  # Memory unavailable — skip enrichment
                
                if skills:
                    guard.register("AVAILABLE_SKILLS", json.dumps(skills[:30], default=str), guard.HIGH)
                    logger.debug(f"    ✅ AVAILABLE_SKILLS registered | count={len(skills)} | recent={len(_recently_added)}")
            except Exception as _skills_ctx_err:
                logger.debug(f"    ⚠️  Skill context unavailable: {_skills_ctx_err}")
        
        # HIGH: Recent trajectory
        logger.debug(f"  Step 4: Registering RECENT_TRAJECTORY")
        recent = self.trajectory[-5:] if self.trajectory else []
        logger.debug(f"    Recent trajectory items: {len(recent)}")
        recent_json = json.dumps(recent, default=str)
        logger.debug(f"    RECENT_TRAJECTORY length: {len(recent_json)} chars")
        guard.register("RECENT_TRAJECTORY", recent_json, guard.HIGH)
        logger.debug(f"    ✅ RECENT_TRAJECTORY registered")

        # HIGH: Attempt-adaptation context (preserves what was already tried)
        # This reduces context loss across retries and supports evolving decisions.
        task_attempt_context = {
            "attempts": getattr(task, "attempts", 0),
            "max_attempts": getattr(task, "max_attempts", 0),
            "failure_reasons": [str(r)[:500] for r in getattr(task, "failure_reasons", [])[-5:]],
            "retry_feedback": [str(r)[:500] for r in getattr(task, "retry_feedback", [])[-5:]],
            "replaced_by": getattr(task, "replaced_by", None),
            "permanent_failure_reason": getattr(task, "permanent_failure_reason", None),
            "adaptation_instruction": (
                "Use prior attempt evidence to avoid repeating identical actions. "
                "If key info remains unavailable after substantive attempts, produce partial completion "
                "with explicit unresolved items and next-step guidance instead of stalling."
            ),
        }
        task_attempt_context_json = json.dumps(task_attempt_context, default=str)
        guard.register("TASK_ATTEMPT_CONTEXT", task_attempt_context_json, guard.HIGH)
        logger.debug(f"    ✅ TASK_ATTEMPT_CONTEXT registered | length={len(task_attempt_context_json)} chars")
        
        # ================================================================
        # 🔴 A-TEAM FIX (E7d): Inject COMPLETED_TASKS into actor context
        # so the actor knows what has already been done and can build on it.
        # This prevents redundant work and context loss across tasks.
        # ================================================================
        try:
            completed_summaries = []
            for ct_id in list(self.todo.completed_tasks)[-10:]:  # Last 10 to avoid bloat
                ct = self.todo.subtasks.get(ct_id)
                if ct:
                    ct_result = ""
                    if hasattr(self, 'shared_context') and self.shared_context:
                        ct_output = self.shared_context.get(f'output_{ct_id}')
                        if ct_output:
                            ct_result = smart_truncate(str(ct_output), max_tokens=100)
                    completed_summaries.append({
                        "task_id": ct_id,
                        "description": ct.description[:200],
                        "actor": ct.actor,
                        "result_summary": ct_result,
                    })
            if completed_summaries:
                guard.register(
                    "COMPLETED_TASKS",
                    json.dumps(completed_summaries, default=str),
                    guard.MEDIUM
                )
                logger.debug(f"    ✅ COMPLETED_TASKS injected | count={len(completed_summaries)}")
        except Exception as _ct_err:
            logger.debug(f"    ⚠️  Failed to inject completed_tasks: {_ct_err}")
        
        # ================================================================
        # Item 204: SKILL SYNTHESIS CONTEXT INJECTION
        # When the task is a skill_build_* task, inject the full skill plan
        # (capability, requester, context, required I/O) so the synthesizer
        # actor (usually TerminalExecutor) has all the context it needs to
        # build, test, and propose the skill back to the conductor.
        # ================================================================
        if hasattr(task, 'task_id') and str(task.task_id).startswith("skill_build_"):
            _skill_plan = None
            if hasattr(self, "shared_context") and self.shared_context:
                _skill_plan = self.shared_context.get(f"skill_plan_{task.task_id}")
            if _skill_plan and isinstance(_skill_plan, dict):
                _synth_instructions = {
                    "skill_synthesis_plan": _skill_plan,
                    "synthesis_instructions": (
                        "You are tasked with SYNTHESIZING a new reusable skill. Steps:\n"
                        "1. Analyze the requested capability and required I/O.\n"
                        "2. Write a Python module with an async `run(**kwargs)` entrypoint.\n"
                        "3. Save the module to the shared workspace using save_file().\n"
                        "4. Write basic tests and save them alongside the module.\n"
                        "5. Use the `propose_skill` collaboration action to submit the skill:\n"
                        "   {action: 'propose_skill', target_agent: 'Conductor', data: {\n"
                        "     name: '<skill_name>', description: '<what it does>',\n"
                        "     module_path: '<absolute path to saved module>',\n"
                        "     entrypoint: 'run', owner_actor: '<your_name>',\n"
                        "     dependencies: [], input_schema: {}, output_schema: {},\n"
                        "     test_command: ['python', '-m', 'pytest', '<test_file_path>']\n"
                        "   }}\n"
                        "6. The conductor will validate and approve/reject the skill.\n"
                        "IMPORTANT: No hardcoded values inside the skill — all params via kwargs.\n"
                        "IMPORTANT: Use async interface (async def run) for non-blocking execution.\n"
                        "IMPORTANT: Include error handling and return structured {success, result/error}."
                    ),
                }
                guard.register("SKILL_SYNTHESIS_PLAN", json.dumps(_synth_instructions, default=str), guard.CRITICAL)
                logger.info(f"    ✅ SKILL_SYNTHESIS_PLAN injected for task {task.task_id}")

        # ================================================================
        # FUTURE-AWARE RETRIEVAL (A-Team Fix)
        # Get memories for CURRENT + UPCOMING tasks
        # ================================================================
        logger.debug(f"  Step 5: FUTURE-AWARE memory retrieval")
        
        # 🚀 A-TEAM SPEED FIX: Single unified retrieval instead of two redundant calls.
        # Previously we made two sequential LLM-powered retrievals:
        #   1) SEMANTIC+PROCEDURAL+META (500 tokens) 
        #   2) ALL levels (1000 tokens) — which re-retrieved the same levels
        # This doubled the LLM overhead. Now we do ONE retrieval across ALL levels
        # with the full budget. The LLM scorer handles relevance across all levels.
        current_mem_start = time.time()
        all_memories = self.shared_memory.retrieve(
            query=task.description,
            goal=self.todo.root_task,
            budget_tokens=1500,  # Combined budget for all memory levels
            context_hints=f"Task: {task.description}, Actor: {actor_config.name}"
        )
        current_mem_duration = time.time() - current_mem_start
        logger.info(f"    ✅ Memory retrieval: {len(all_memories)} items | duration={current_mem_duration:.3f}s")
        
        # 📊 Diagnostic: Log when memory retrieval returns empty unexpectedly
        if not all_memories:
            is_null = getattr(self, '_memory_disabled_diagnostic', False)
            if is_null:
                logger.warning(f"  ⚠️ Memory retrieval returned empty (memory backend DISABLED)")
            else:
                logger.warning(f"  ⚠️ Memory retrieval returned empty for '{task.description[:80]}' — no matching entries found")
        
        # 🧠 Emit retrieval events for all retrieved memories
        for mem in all_memories[:8]:  # Cap at 8 to avoid event flood
            mem_level = getattr(mem, 'level', None)
            level_str = mem_level.value if hasattr(mem_level, 'value') else str(mem_level) if mem_level else 'unknown'
            _memory_events.append(self._build_memory_update_event(
                content=str(getattr(mem, 'content', mem))[:1200],
                level=level_str,
                actor=actor_config.name,
                operation="retrieved",
                context={'task': task.task_id, 'retrieval_type': level_str},
            ))
        
        # 🔴 A-TEAM FIX: Retrieve CAUSAL gotchas/pitfalls for this task
        # 🧠 A-TEAM ENHANCEMENT E5: Confidence-scored gotcha injection
        # Only inject gotchas above a confidence threshold to avoid noise
        causal_gotchas = []
        try:
            causal_links = self.shared_memory.retrieve_causal(
                query=f"{task.description} {task.actor}",
                context={'actor': actor_config.name, 'task': task.task_id, 'domain': actor_config.name}
            )
            if causal_links:
                # Filter by confidence threshold — don't inject low-confidence noise
                gotcha_confidence_threshold = getattr(self.config, 'gotcha_confidence_threshold', 0.3)
                high_confidence = [cl for cl in causal_links if cl.confidence >= gotcha_confidence_threshold]
                
                if high_confidence:
                    # Sort by confidence descending — most certain gotchas first
                    high_confidence.sort(key=lambda cl: cl.confidence, reverse=True)
                    gotcha_text = "⚠️ KNOWN GOTCHAS & PITFALLS (from past failures, ranked by certainty):\n"
                    for cl in high_confidence[:5]:  # Top 5 most relevant + confident
                        severity = "🔴 CRITICAL" if cl.confidence > 0.8 else "🟡 IMPORTANT" if cl.confidence > 0.5 else "🟢 NOTE"
                        gotcha_text += f"  {severity} [{cl.confidence:.0%}]: {cl.cause} → {cl.effect}\n"
                    
                    # Add retry-specific gotcha if this task has been attempted before
                    if task.attempts > 0 and hasattr(task, 'failure_reasons') and task.failure_reasons:
                        gotcha_text += f"\n  🔄 PREVIOUS ATTEMPT FAILURES (attempt #{task.attempts}):\n"
                        for reason in task.failure_reasons[-3:]:  # Last 3 failure reasons
                            gotcha_text += f"    - {smart_truncate(str(reason), max_tokens=75)}\n"
                    
                    causal_gotchas = [gotcha_text]
                    all_memories = causal_gotchas + all_memories  # Gotchas first!
                    logger.info(f"    🚨 Injected {len(high_confidence)} causal gotchas (of {len(causal_links)} total, threshold={gotcha_confidence_threshold})")
                    
                    # 🧠 Emit retrieval events for causal gotchas
                    for cl in high_confidence[:3]:  # Cap at 3
                        _memory_events.append(self._build_memory_update_event(
                            content=f"Gotcha: {cl.cause} → {cl.effect}",
                            level='causal',
                            actor=actor_config.name,
                            operation="retrieved",
                            context={'task': task.task_id, 'retrieval_type': 'causal', 'confidence': cl.confidence},
                        ))
                else:
                    logger.debug(f"    Found {len(causal_links)} causal links but none above confidence threshold ({gotcha_confidence_threshold})")
        except Exception as e:
            logger.debug(f"    Causal memory retrieval failed: {e}")
        
        logger.debug(
            f"    ✅ Memory retrieval complete: {len(all_memories)} current (+{len(causal_gotchas)} causal overlays) "
            f"| duration={current_mem_duration:.3f}s"
        )
        
        # Upcoming tasks memories (40% of budget)
        logger.debug(f"    Finding upcoming tasks")
        upcoming = [t for t in self.todo.subtasks.values() 
                    if t.status == TaskStatus.PENDING and t.task_id != task.task_id][:3]  # Fixed: .id → .task_id
        logger.debug(f"    Found {len(upcoming)} upcoming tasks")
        
        future_memories = []
        for i, upcoming_task in enumerate(upcoming):
            logger.debug(f"    Retrieving memories for upcoming task[{i}]: '{upcoming_task.description[:50]}...' | budget=500 tokens")
            future_mem_start = time.time()
            fm = self.shared_memory.retrieve(
                query=upcoming_task.description,
                goal=self.todo.root_task,
                budget_tokens=500  # Budget for future task memories
            )
            future_mem_duration = time.time() - future_mem_start
            logger.debug(f"      Retrieved {len(fm)} memories | duration={future_mem_duration:.3f}s")
            future_memories.extend(fm)
        
        logger.debug(f"    Total future memories: {len(future_memories)} items")
        
        # Combine (deduplicate by key) - unified retrieval + future memories
        logger.debug(f"    Combining and deduplicating memories (current + future)")
        seen_keys = set()
        combined_memories = []
        for mem in all_memories + future_memories:
            # Handle both memory objects and injected string overlays (e.g., causal gotcha summaries).
            mem_key = getattr(mem, 'key', None) or f"raw::{hash(str(mem))}"
            if mem_key in seen_keys:
                continue
            seen_keys.add(mem_key)
            combined_memories.append(mem)
        
        total_before_dedup = len(all_memories) + len(future_memories)
        all_memories = combined_memories
        logger.debug(f"    ✅ Combined memories: {len(all_memories)} unique items (from {total_before_dedup} total)")
        memories_str = str(all_memories)
        logger.debug(f"    Registering SHARED_MEMORIES | length={len(memories_str)} chars")
        guard.register("SHARED_MEMORIES", memories_str, guard.MEDIUM)
        logger.debug(f"    ✅ SHARED_MEMORIES registered")
        
        # MEDIUM: Local actor memory
        logger.debug(f"  Step 6: Retrieving LOCAL_MEMORIES")
        logger.debug(f"    Actor: {actor_config.name} | budget=1000 tokens")
        local_mem_start = time.time()
        # 🔴 A-TEAM FIX: Guard against missing actor in local_memories
        # (can happen if actor was dynamically added after _initialize_actors)
        _local_mem_instance = self.local_memories.get(actor_config.name) if hasattr(self, 'local_memories') else None
        if _local_mem_instance:
            local_mem = _local_mem_instance.retrieve(
                query=task.description,
                goal=self.todo.root_task,
                budget_tokens=1000  # Budget for local actor memories
            )
        else:
            local_mem = []
            logger.debug(f"    ⚠️ No local memory for actor '{actor_config.name}' — skipping local retrieval")
        local_mem_duration = time.time() - local_mem_start
        logger.debug(f"    ✅ Local memories retrieved: {len(local_mem)} items | duration={local_mem_duration:.3f}s")
        
        # 🧠 Emit retrieval events for local actor memories
        for mem in local_mem[:3]:  # Cap at 3
            _memory_events.append(self._build_memory_update_event(
                content=str(getattr(mem, 'content', mem))[:200],
                level='local',
                actor=actor_config.name,
                operation="retrieved",
                context={'task': task.task_id, 'retrieval_type': 'local'},
            ))
        
        local_mem_str = str(local_mem)
        logger.debug(f"    Registering LOCAL_MEMORIES | length={len(local_mem_str)} chars")
        guard.register("LOCAL_MEMORIES", local_mem_str, guard.MEDIUM)
        logger.debug(f"    ✅ LOCAL_MEMORIES registered")
        
        # ✅ A-TEAM FIX: Collect dependency outputs FIRST (before metadata_provider)
        # This ensures previous_outputs is always available for both metadata_provider
        # and direct DEPENDENCY_RESULTS injection into actor context
        logger.debug(f"  Step 7: Collecting dependency outputs from shared_context")
        previous_outputs = {}
        if hasattr(self, 'shared_context') and self.shared_context:
            logger.debug(f"      shared_context available")
            
            # Strategy 1: Look up by task_id from task.depends_on
            # This is the primary path — SubtaskState.depends_on contains task_ids
            if hasattr(task, 'depends_on') and task.depends_on:
                for dep_task_id in task.depends_on:
                    dep_output = self.shared_context.get(f'output_{dep_task_id}')
                    if dep_output is not None:
                        previous_outputs[dep_task_id] = dep_output
                        logger.debug(f"        ✅ Found output for dep task_id={dep_task_id}")
                    else:
                        logger.debug(f"        ⚠️  No output found for dep task_id={dep_task_id}")
            
            # Strategy 2: Look up by actor name from actor_config.dependencies (fallback)
            actor_outputs_dict = self.shared_context.get('actor_outputs') or {}
            if actor_outputs_dict:
                logger.debug(f"      actor_outputs found: {list(actor_outputs_dict.keys())}")
                if actor_config.dependencies:
                    for dep_name in actor_config.dependencies:
                        logger.debug(f"        Checking actor dependency: {dep_name}")
                        if dep_name in actor_outputs_dict and dep_name not in previous_outputs:
                            previous_outputs[dep_name] = actor_outputs_dict[dep_name]
                            logger.debug(f"          ✅ Added output for actor {dep_name}")

            if not previous_outputs:
                logger.debug(f"      No dependency outputs found (task.depends_on={getattr(task, 'depends_on', [])}, "
                             f"actor_config.dependencies={actor_config.dependencies})")
        else:
            logger.debug(f"      No shared_context available")
                
        logger.debug(f"    Previous outputs collected: {list(previous_outputs.keys())}")
        
        # Call metadata_provider protocol for domain-specific context (if available)
        logger.debug(f"  Step 7a: Calling metadata_provider.get_context_for_actor")
        actor_context_from_provider = None
        if self.metadata_provider and hasattr(self.metadata_provider, 'get_context_for_actor'):
            logger.debug(f"    ✅ metadata_provider has get_context_for_actor method")
            try:
                logger.debug(f"    Calling get_context_for_actor | actor={actor_config.name} | query_length={len(task.description)}")
                
                # Call the GENERIC protocol (no SQL hardcoding!)
                provider_start = time.time()
                actor_context_from_provider = self.metadata_provider.get_context_for_actor(
                    actor_name=actor_config.name,
                    query=task.description,
                    previous_outputs=previous_outputs,
                    actor_config=actor_config,
                    **self.context_providers
                )
                provider_duration = time.time() - provider_start
                logger.info(f"    ✅ get_context_for_actor returned | "
                           f"result_type={type(actor_context_from_provider).__name__} | "
                           f"duration={provider_duration:.3f}s")
                
                if isinstance(actor_context_from_provider, dict):
                    if actor_context_from_provider:
                        logger.debug(f"    Result is dict with {len(actor_context_from_provider)} keys: {list(actor_context_from_provider.keys())}")
                        # Register each metadata field with the guard
                        registered_count = 0
                        skipped_count = 0
                        for key, value in actor_context_from_provider.items():
                            if value and isinstance(value, str) and len(value) > 10:
                                # Use MEDIUM priority for metadata (important but not critical)
                                logger.debug(f"      Registering METADATA_{key.upper()} | length={len(value)} chars")
                                guard.register(f"METADATA_{key.upper()}", value, guard.MEDIUM)
                                registered_count += 1
                            else:
                                skipped_count += 1
                                value_type = type(value).__name__ if value else 'None'
                                value_len = len(str(value)) if value else 0
                                logger.debug(f"      Skipping {key}: type={value_type}, length={value_len} (needs str > 10 chars)")
                        logger.info(f"    ✅ Registered {registered_count} metadata fields from provider for {actor_config.name} | "
                                   f"skipped={skipped_count} (too short or not string)")
                    else:
                        logger.warning(f"    ⚠️  get_context_for_actor returned empty dict (no metadata provided) | "
                                     f"actor={actor_config.name} | query='{task.description[:100]}...'")
                        logger.debug(f"    This is normal if the metadata provider has no context for this actor/query combination")
                else:
                    logger.warning(f"    ⚠️  get_context_for_actor returned non-dict: {type(actor_context_from_provider).__name__} | "
                                 f"value={str(actor_context_from_provider)[:200]}")
            except Exception as e:
                logger.error(f"    ❌ MetadataProvider call failed for {actor_config.name}: {e}", exc_info=True)
        else:
            logger.debug(f"    ⚠️  metadata_provider missing or no get_context_for_actor method")

        # 🔴 A-TEAM FIX: Inject dependency results directly into actor context
        # This ensures downstream actors see upstream outputs even without metadata_provider
        logger.debug(f"  Step 7b: Injecting DEPENDENCY_RESULTS into context")
        if previous_outputs:
            dep_results_str = json.dumps(
                {k: smart_truncate(str(v), max_tokens=500) for k, v in previous_outputs.items()},
                default=str, indent=2
            )
            logger.debug(f"    Registering DEPENDENCY_RESULTS | {len(previous_outputs)} deps | length={len(dep_results_str)} chars")
            guard.register("DEPENDENCY_RESULTS", dep_results_str, guard.HIGH)
            logger.debug(f"    ✅ DEPENDENCY_RESULTS registered")
        else:
            logger.debug(f"    No dependency results to inject")

        # Optional: inject web search context (if enabled and available)
        logger.debug(f"  Step 8: Checking for web_search_context and failure_context")
        if hasattr(self, 'shared_context') and self.shared_context:
            web_ctx = self.shared_context.get('web_search_context')
            if web_ctx:
                max_chars = getattr(self.config, "web_search_context_max_chars", 4000)
                web_ctx_str = str(web_ctx)[:max_chars]
                logger.debug(f"    Registering WEB_SEARCH_CONTEXT | length={len(web_ctx_str)} chars")
                guard.register("WEB_SEARCH_CONTEXT", web_ctx_str, guard.MEDIUM)
                logger.debug(f"    ✅ WEB_SEARCH_CONTEXT registered")
            else:
                logger.debug(f"    No web_search_context available")

            failure_ctx = self.shared_context.get('last_failure_context')
            if failure_ctx:
                failure_ctx_str = json.dumps(failure_ctx, default=str)
                logger.debug(f"    Registering LAST_FAILURE_CONTEXT | length={len(failure_ctx_str)} chars")
                guard.register("LAST_FAILURE_CONTEXT", failure_ctx_str, guard.MEDIUM)
                logger.debug(f"    ✅ LAST_FAILURE_CONTEXT registered")
            else:
                logger.debug(f"    No last_failure_context available")
        else:
            logger.debug(f"    No shared_context available")
        
        # 🔴 A-TEAM AUDIT FIX: Inject COOPERATION_INSTRUCTIONS so agents know
        # how to ask other actors for help, share files, request debug info etc.
        logger.debug(f"  Step 8b: Registering COOPERATION_INSTRUCTIONS")
        cooperation_instructions = (
            "🤝 COOPERATION PROTOCOL:\n"
            "You are part of a multi-agent team. If you encounter a task that requires "
            "capabilities outside your specialization, or if you need information from "
            "another agent's previous work, you can request collaboration.\n\n"
            "HOW TO COOPERATE:\n"
            "Set 'collaboration_actions' in your output with a list of action objects.\n\n"
            "COLLABORATION ACTION TYPES:\n"
            "1. request_help — Ask another agent for assistance:\n"
            "   {\"type\": \"request_help\", \"target_agent\": \"AgentName\", "
            "\"request_type\": \"file_read|analysis|debug|discussion|execution\", "
            "\"message\": \"what you need\"}\n"
            "2. share_knowledge — Share findings with a specific agent:\n"
            "   {\"type\": \"share_knowledge\", \"target_agent\": \"AgentName\", "
            "\"data\": {\"key\": \"value\"}}\n"
            "3. broadcast — Share information with all agents:\n"
            "   {\"type\": \"broadcast\", \"data\": {\"message\": \"...\"} }\n\n"
            "🧠 SKILL LIFECYCLE ACTIONS (for reusable capabilities):\n"
            "4. request_skill — Search for or trigger creation of a reusable skill:\n"
            "   {\"type\": \"request_skill\", \"data\": {\"capability\": \"what you need\", "
            "\"context\": {}, \"preferred_owner\": \"AgentName or empty\"}}\n"
            "   The system will search approved skills first; if none match, a synthesis task is queued.\n"
            "5. propose_skill — Register a new skill you created (code file on disk):\n"
            "   {\"type\": \"propose_skill\", \"data\": {\"name\": \"skill_name\", "
            "\"description\": \"what it does\", \"module_path\": \"/path/to/skill.py\", "
            "\"entrypoint\": \"run\", \"tags\": [\"tag1\"], \"dependencies\": [], "
            "\"test_command\": [\"python\", \"-m\", \"pytest\", \"tests/\"]}}\n"
            "6. execute_skill — Run an approved skill by ID:\n"
            "   {\"type\": \"execute_skill\", \"data\": {\"skill_id\": \"skill_xxx\", "
            "\"payload\": {\"arg1\": \"val1\"}}}\n"
            "7. publish_skill — Promote a candidate skill to approved:\n"
            "   {\"type\": \"publish_skill\", \"data\": {\"skill_id\": \"skill_xxx\"}}\n"
            "8. deprecate_skill — Mark a skill as deprecated:\n"
            "   {\"type\": \"deprecate_skill\", \"data\": {\"skill_id\": \"skill_xxx\", "
            "\"reason\": \"why\"}}\n\n"
            "WHEN TO COOPERATE:\n"
            "- You need a file read/written that another agent produced\n"
            "- You need visual inspection (VLM) of a screenshot or document\n"
            "- You need terminal commands executed (ask TerminalExecutor)\n"
            "- You need web research (ask WebSearchAgent)\n"
            "- You are stuck and need a different perspective\n"
            "- You need to convert a file format (e.g., PPTX→PDF→images)\n"
            "- You need a reusable tool/skill that doesn't exist yet (request_skill)\n"
            "- You built a useful utility and want to persist it for the team (propose_skill)\n\n"
            "Check AVAILABLE_SKILLS in your context for skills already approved.\n"
            "Check _agent_directory before requesting help to target the right agent."
        )
        guard.register("COOPERATION_INSTRUCTIONS", cooperation_instructions, guard.MEDIUM)
        logger.debug(f"    ✅ COOPERATION_INSTRUCTIONS registered")
        
        # LOW: Annotations
        logger.debug(f"  Step 9: Registering ANNOTATIONS")
        if self.annotations:
            annotations_str = smart_truncate(json.dumps(self.annotations), max_tokens=250)
            logger.debug(f"    Registering ANNOTATIONS | length={len(annotations_str)} chars")
            guard.register("ANNOTATIONS", annotations_str, guard.LOW)
            logger.debug(f"    ✅ ANNOTATIONS registered")
        else:
            logger.debug(f"    No annotations available")
        
        # 🕐 TIME-AWARE CONTEXT - REMOVED
        # Timeout warnings and enforcement have been removed - LLM has freedom to execute
        
        # Build final context string + metadata
        logger.debug(f"  Step 10: Building final context string")
        build_ctx_start = time.time()
        context_string, context_meta = guard.build_context()
        build_ctx_duration = time.time() - build_ctx_start
        logger.info(f"  ✅ Final context built | length={len(context_string)} chars | "
                   f"meta_keys={list(context_meta.keys()) if context_meta else 'None'} | "
                   f"duration={build_ctx_duration:.3f}s")
        
        total_duration = time.time() - build_start
        logger.info(f"✅ BUILD_ACTOR_CONTEXT COMPLETE: actor={actor_config.name} | "
                   f"context_length={len(context_string)} | "
                   f"actor_context_keys={list(actor_context_from_provider.keys()) if actor_context_from_provider else 'None'} | "
                   f"total_duration={total_duration:.3f}s")
        
        # 🔥 A-TEAM CRITICAL FIX: Return both context string AND actor_context dict
        # The dict will be merged into resolved_kwargs in _execute_actor
        logger.debug(f"  📨 Memory events collected for UI: {len(_memory_events)} events")
        return (context_string, context_meta), actor_context_from_provider, _memory_events
    
    def _build_param_mappings(self, custom_mappings: Optional[Dict[str, List[str]]]) -> Dict[str, List[str]]:
        """
        Build parameter mappings: defaults + config + user-provided.
        
        🆕 A-TEAM: Makes SYNAPSE truly generic by allowing users to define
        domain-specific parameter name mappings!
        
        Priority: user_mappings > config_mappings > defaults
        """
        # Minimal generic defaults (domain-agnostic)
        default_mappings = {
            # Core generic patterns
            'content': ['content', 'text', 'body'],
            'data': ['data', 'output_data', 'results'],
            'file': ['file', 'filepath', 'path', 'file_path'],
            'url': ['url', 'uri', 'link', 'href'],
        }
        
        # Start with defaults
        mappings = default_mappings.copy()
        
        # Merge config mappings (if provided)
        if hasattr(self.config, 'custom_param_mappings') and self.config.custom_param_mappings:
            for key, aliases in self.config.custom_param_mappings.items():
                if key in mappings:
                    # Extend existing (remove duplicates)
                    mappings[key] = list(set(mappings[key] + aliases))
                else:
                    # Add new
                    mappings[key] = aliases
        
        # Merge user mappings (highest priority)
        if custom_mappings:
            for key, aliases in custom_mappings.items():
                if key in mappings:
                    # Extend existing (remove duplicates)
                    mappings[key] = list(set(mappings[key] + aliases))
                else:
                    # Add new
                    mappings[key] = aliases
        
        logger.info(f"📋 Parameter mappings: {len(mappings)} keys, {sum(len(v) for v in mappings.values())} total aliases")
        if mappings:
            logger.debug(f"   Mappings: {list(mappings.keys())}")
        
        return mappings
    
    
    async def _attempt_parameter_recovery(
        self,
        actor_config: ActorConfig,
        missing_params: List[str],
        context: Dict[str, Any],
        shared_context: Dict[str, Any],
        max_attempts: int = 2
    ) -> Dict[str, Any]:
        """
        🛠️ INTELLIGENT PARAMETER RECOVERY
        
        PRIORITY ORDER (A-TEAM FINAL):
        1. Check IOManager (actor outputs) ← WHERE AGENT DATA LIVES!
        2. Check SharedContext['metadata'] (only if not found in IOManager)
        3. Invoke MetaDataFetcher (on-demand fetch)
        4. (Future) Re-invoke failed dependencies
        """
        recovered = {}
        logger.info(f"🔍 Recovery Strategy for {actor_config.name}: analyzing {len(missing_params)} missing parameters")
        
        for param in missing_params:
            logger.info(f"   🔍 Attempting recovery for '{param}'...")
            
            # 🔥 STRATEGY 1: Check IOManager (ACTOR OUTPUTS) - THIS IS THE PRIMARY DATA FLOW!
            if hasattr(self, 'io_manager') and self.io_manager:
                all_outputs = self.io_manager.get_all_outputs()
                for actor_name, actor_output in all_outputs.items():
                    if hasattr(actor_output, 'output_fields') and actor_output.output_fields:
                        # Exact match
                        if param in actor_output.output_fields:
                            recovered[param] = actor_output.output_fields[param]
                            logger.info(f"   ✅ Found '{param}' in IOManager['{actor_name}']")
                            break
                        
                        # Check aliases (e.g., 'tables' matches 'relevant_tables')
                        aliases = {
                            'tables': ['relevant_tables', 'selected_tables', 'table_list'],
                            'columns': ['selected_columns', 'column_list'],
                            'resolved_terms': ['terms', 'business_terms'],
                            'filters': ['filter_conditions', 'where_conditions'],
                        }
                        
                        if param in aliases:
                            for alias in aliases[param]:
                                if alias in actor_output.output_fields:
                                    recovered[param] = actor_output.output_fields[alias]
                                    logger.info(f"   ✅ Found '{param}' as '{alias}' in IOManager['{actor_name}']")
                                    break
                        
                        if param in recovered:
                            break
            
            if param in recovered:
                continue
            
            # Strategy 2: Check SharedContext['metadata'] (ONLY if not in IOManager!)
            if self.shared_context and 'metadata' in self.shared_context.data:
                metadata = self.shared_context.get('metadata')
                if metadata and isinstance(metadata, dict):
                    # Direct match
                    if param in metadata:
                        recovered[param] = metadata[param]
                        logger.info(f"   ✅ Found '{param}' in SharedContext['metadata']")
                        continue
                    
                    # 🔥 A-TEAM: ALIAS MATCHING (before agentic search)
                    aliases = {
                        'tables': ['relevant_tables', 'selected_tables', 'table_list', 'available_tables'],
                        'table_names': ['available_tables', 'all_tables', 'tables'],
                        'columns': ['selected_columns', 'column_list'],
                        'resolved_terms': ['terms', 'business_terms'],
                        'filters': ['filter_conditions', 'where_conditions'],
                    }
                    
                    if param in aliases:
                        for alias in aliases[param]:
                            if alias in metadata:
                                recovered[param] = metadata[alias]
                                logger.info(f"   ✅ Found '{param}' via alias '{alias}' in SharedContext['metadata']")
                                break
                    
                    if param in recovered:
                        continue
                    
                    # 🔥 A-TEAM: AGENTIC SEMANTIC SEARCH (NO FUZZY MATCHING!)
                    # Use AgenticParameterResolver for intelligent, LLM-based matching
                    logger.info(f"   🔍 Using agentic search for '{param}' in metadata...")
                    
                    if hasattr(self, 'param_resolver') and self.param_resolver:
                        # Get parameter info from signature
                        param_info = {}
                        param_type_str = 'str'
                        if actor_config.name in self.actor_signatures:
                            sig = self.actor_signatures[actor_config.name]
                            if isinstance(sig, dict) and param in sig:
                                param_info = sig[param]
                                param_type = param_info.get('annotation')
                                if param_type and hasattr(param_type, '__name__'):
                                    param_type_str = param_type.__name__
                        
                        # Prepare available data with rich descriptions
                        available_data = {}
                        for key, value in metadata.items():
                            available_data[key] = {
                                'value': value,
                                'type': type(value).__name__,
                                'description': f"Metadata key '{key}' containing {type(value).__name__}",
                                'tags': ['metadata', 'available'],
                                'source': 'SharedContext[metadata]'
                            }
                        
                        try:
                            # Use agentic resolver with LLM intelligence  
                            matched_key, confidence, reasoning = self.param_resolver.resolve_parameter(
                                actor_name=actor_config.name,
                                parameter_name=param,
                                parameter_type=param_type_str,
                                parameter_purpose=f"Required parameter for {actor_config.name}",
                                available_data=available_data
                            )
                            
                            if matched_key and matched_key in metadata:
                                if confidence > 0.7:  # High confidence threshold
                                    recovered[param] = metadata[matched_key]
                                    logger.info(f"   ✅ Agentic match: '{param}' → '{matched_key}' (confidence: {confidence:.2f})")
                                    logger.info(f"   📝 Reasoning: {reasoning[:150]}...")
                                else:
                                    logger.warning(f"   ⚠️ Low confidence match: '{param}' → '{matched_key}' (conf: {confidence:.2f})")
                                    logger.info(f"   📝 Reasoning: {reasoning[:100]}...")
                            else:
                                logger.warning(f"   ❌ No agentic match found for '{param}'")
                        
                        except Exception as e:
                            logger.error(f"   ❌ Agentic resolver failed: {e}")
                            import traceback
                            logger.error(f"Traceback: {traceback.format_exc()}")
                    else:
                        logger.warning(f"   ⚠️ AgenticParameterResolver not available - parameter '{param}' cannot be resolved from metadata")
            
            if param in recovered:
                continue
            
            # Strategy 3: Invoke MetaDataFetcher for on-demand fetch
            if self.metadata_fetcher and hasattr(self.metadata_fetcher, 'tools'):
                logger.info(f"   🔍 Asking MetaDataFetcher to fetch '{param}'...")
                try:
                    # Check if any tool matches this parameter
                    for tool in self.metadata_fetcher.tools:
                        tool_name = tool.name.lower() if hasattr(tool, 'name') else str(tool)
                        if param.lower() in tool_name or tool_name in param.lower():
                            logger.info(f"   📞 Calling tool '{tool.name}' for '{param}'")
                            try:
                                result = tool.func() if hasattr(tool, 'func') else None
                                if result:
                                    recovered[param] = result
                                    logger.info(f"   ✅ Fetcher retrieved '{param}'")
                                    break
                            except Exception as e:
                                logger.warning(f"   ⚠️  Tool call failed: {e}")
                except Exception as e:
                    logger.warning(f"   ⚠️  MetaDataFetcher recovery failed: {e}")
            
            if param not in recovered:
                logger.warning(f"   ❌ Could not recover '{param}'")
        
        still_missing = [p for p in missing_params if p not in recovered]
        
        logger.info(f"🏁 Recovery complete: {len(recovered)}/{len(missing_params)} recovered")
        if still_missing:
            logger.warning(f"   Still missing: {still_missing}")
        
        return {
            'recovered': recovered,
            'still_missing': still_missing
        }
    
    def _find_parameter_producer(self, parameter_name: str, requesting_actor: str) -> Optional[str]:
        """
        Find which actor produces a given parameter using dependency graph.
        
        🔥 A-TEAM: Uses signature introspection + IOManager to route requests intelligently.
        """
        logger.info(f"🔍 [DEP GRAPH] Finding producer for '{parameter_name}' (requested by {requesting_actor})")
        
        # Check actor signatures for outputs
        for actor_name, sig in self.actor_signatures.items():
            if actor_name == requesting_actor:
                continue  # Don't ask yourself
            
            # Check if signature has this in outputs
            if isinstance(sig, dict) and 'outputs' in sig:
                if parameter_name in sig['outputs']:
                    logger.info(f"✅ [DEP GRAPH] {actor_name} produces '{parameter_name}' (from signature)")
                    return actor_name
        
        # Check IOManager for actual outputs
        if hasattr(self, 'io_manager') and self.io_manager:
            all_outputs = self.io_manager.get_all_outputs()
            for actor_name in all_outputs:
                if actor_name == requesting_actor:
                    continue
                output_fields = self.io_manager.get_output_fields(actor_name)
                if parameter_name in output_fields:
                    logger.info(f"✅ [DEP GRAPH] {actor_name} produces '{parameter_name}' (from IOManager)")
                    return actor_name
        
        logger.warning(f"⚠️ [DEP GRAPH] No producer found for '{parameter_name}'")
        return None
    
    async def _route_to_producer(
        self,
        producer_actor: str,
        parameters_needed: List[str],
        requesting_actor: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Route request to producer actor and retrieve data.
        
        🔥 A-TEAM: Intelligent routing using dependency graph.
        If producer already executed, retrieve from IOManager.
        If not, execute producer first.
        """
        logger.info(f"📢 [ROUTING] {requesting_actor} → {producer_actor}")
        logger.info(f"   Requesting: {parameters_needed}")
        
        # Check if producer already executed
        if hasattr(self, 'io_manager') and self.io_manager:
            all_outputs = self.io_manager.get_all_outputs()
            if producer_actor in all_outputs:
                logger.info(f"✅ [ROUTING] {producer_actor} already executed")
                output_fields = self.io_manager.get_output_fields(producer_actor)
                
                recovered = {}
                for param in parameters_needed:
                    if param in output_fields:
                        recovered[param] = output_fields[param]
                        logger.info(f"   ✅ Retrieved '{param}': {type(output_fields[param]).__name__}")
                
                if recovered:
                    return recovered
        
        # Producer hasn't executed - need to execute it first
        logger.info(f"⚠️ [ROUTING] {producer_actor} not executed yet, executing now...")
        
        if producer_actor not in self.actors:
            logger.error(f"❌ [ROUTING] Producer actor '{producer_actor}' not found in swarm")
            return {}
        
        producer_config = self.actors[producer_actor]
        
        # Build kwargs for producer
        try:
            producer_kwargs = {}
            
            # Get producer's signature
            if producer_actor in self.actor_signatures:
                sig = self.actor_signatures[producer_actor]
                if isinstance(sig, dict):
                    for param_name, param_info in sig.items():
                        # Resolve producer's parameters
                        value = self._resolve_parameter(
                            param_name,
                            param_info,
                            context.get('kwargs', {}),
                            self.shared_context.data if hasattr(self, 'shared_context') else {}
                        )
                        if value is not None:
                            producer_kwargs[param_name] = value
            
            # Execute producer
            logger.info(f"🔄 [ROUTING] Executing {producer_actor} to generate data...")
            
            # Get or create SYNAPSE-wrapped actor
            actor = producer_config.actor
            if hasattr(actor, 'arun'):
                result = await actor.arun(context.get('goal', ''), **producer_kwargs)
            else:
                # Not wrapped, execute directly
                result = actor(**producer_kwargs)
                # Wrap in EpisodeResult
                from .data_structures import EpisodeResult
                result = EpisodeResult(
                    output=result,
                    success=True,
                    trajectory=[],
                    tagged_outputs=[],
                    episode=0
                )
            
            if result.success and result.output:
                # Register output in IOManager
                if hasattr(self, 'io_manager'):
                    self.io_manager.register_output(
                        actor_name=producer_actor,
                        output=result.output,
                        actor=actor,
                        success=True
                    )
                
                # Extract requested parameters
                recovered = {}
                for param in parameters_needed:
                    if hasattr(result.output, param):
                        recovered[param] = getattr(result.output, param)
                    elif hasattr(result.output, '_store') and param in result.output._store:
                        recovered[param] = result.output._store[param]
                
                logger.info(f"✅ [ROUTING] Producer executed, recovered {len(recovered)} params")
                return recovered
            else:
                logger.error(f"❌ [ROUTING] Producer {producer_actor} failed")
                return {}
        
        except Exception as e:
            logger.error(f"❌ [ROUTING] Failed to execute producer {producer_actor}: {e}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            return {}
    
    async def _intelligent_recovery_with_routing(
        self,
        actor_config: ActorConfig,
        missing_params: List[str],
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Intelligent parameter recovery using dependency graph routing.
        
        🔥 A-TEAM: Full intelligence stack:
        1. Check IOManager (already executed actors)
        2. Check SharedContext metadata
        3. Use dependency graph to find producers
        4. Route requests to producer actors
        5. Re-execute producers if needed
        6. Fallback to MetaDataFetcher
        7. Fallback to smart defaults
        """
        recovered = {}
        logger.info(f"🛠️  [INTELLIGENT RECOVERY] for {actor_config.name}")
        logger.info(f"   Missing: {missing_params}")
        
        for param in missing_params:
            # Strategy 1: IOManager (already executed)
            if hasattr(self, 'io_manager') and self.io_manager:
                all_outputs = self.io_manager.get_all_outputs()
                for actor_name in all_outputs:
                    output_fields = self.io_manager.get_output_fields(actor_name)
                    if param in output_fields:
                        recovered[param] = output_fields[param]
                        logger.info(f"   ✅ Found '{param}' in IOManager[{actor_name}]")
                        break
            
            if param in recovered:
                continue
            
            # Strategy 2: SharedContext metadata
            if hasattr(self, 'shared_context') and self.shared_context:
                if self.shared_context.has('metadata'):
                    metadata = self.shared_context.get('metadata')
                    if isinstance(metadata, dict) and param in metadata:
                        recovered[param] = metadata[param]
                        logger.info(f"   ✅ Found '{param}' in SharedContext[metadata]")
                        continue
            
            # Strategy 3: 🔥 DEPENDENCY GRAPH ROUTING
            producer = self._find_parameter_producer(param, actor_config.name)
            if producer:
                logger.info(f"   🎯 Dependency graph: '{param}' from {producer}")
                
                # Route request to producer
                producer_data = await self._route_to_producer(
                    producer_actor=producer,
                    parameters_needed=[param],
                    requesting_actor=actor_config.name,
                    context=context
                )
                
                if param in producer_data:
                    recovered[param] = producer_data[param]
                    logger.info(f"   ✅ Routed to {producer}, retrieved '{param}'")
                    continue
            
            # Strategy 4: MetaDataFetcher (fallback)
            if hasattr(self, 'metadata_fetcher') and self.metadata_fetcher:
                logger.info(f"   🔍 Asking MetaDataFetcher for '{param}'...")
                # ... (existing MetaDataFetcher logic if needed)
        
        logger.info(f"🏁 [INTELLIGENT RECOVERY] Complete: {len(recovered)}/{len(missing_params)} recovered")
        if len(recovered) < len(missing_params):
            still_missing = [p for p in missing_params if p not in recovered]
            logger.warning(f"   Still missing: {still_missing}")
        
        return recovered
    
    def _introspect_actor_signature(self, actor_config: ActorConfig):
        """
        Introspect actor's signature for auto-resolution.
        🔥 A-TEAM FIX: Use DSPy Signature object, NOT forward() method directly!
        """
        actor = actor_config.agent
        
        # Strategy 1: DSPy module with signature attribute (BEST)
        if hasattr(actor, 'signature') and hasattr(actor.signature, 'input_fields'):
            try:
                params = {}
                for field_name in actor.signature.input_fields:
                    # 🔥 A-TEAM CRITICAL FIX: Extract REAL type from DSPy field!
                    field = actor.signature.input_fields[field_name]
                    field_type = Any  # default
                    
                    # DSPy fields have a 'annotation' or '_type' attribute
                    if hasattr(field, 'annotation'):
                        field_type = field.annotation
                    elif hasattr(field, '_type'):
                        field_type = field._type
                    elif hasattr(field, '__annotations__'):
                        # Check class annotations
                        for cls in type(field).__mro__:
                            if hasattr(cls, '__annotations__') and field_name in cls.__annotations__:
                                field_type = cls.__annotations__[field_name]
                                break
                    
                    # If still Any, try to infer from field's json_schema_extra or desc
                    if field_type is Any:
                        logger.debug(f"   ⚠️  Could not extract type for '{field_name}', defaulting to Any")
                    
                    params[field_name] = {
                        'annotation': field_type,
                        'default': inspect.Parameter.empty,
                        'required': True
                    }
                self.actor_signatures[actor_config.name] = params
                self.dependency_graph[actor_config.name] = []
                logger.info(f"  📋 {actor_config.name}: {len(params)} params (DSPy signature), deps=[]")
                return
            except Exception as e:
                logger.warning(f"⚠️  Failed to extract DSPy signature for {actor_config.name}: {e}")
        
        # Strategy 2: Inspect forward method (WITHOUT calling it)
        forward_method = getattr(actor, 'forward', None)
        if forward_method:
            try:
                sig = inspect.signature(forward_method)
                params = {}
                dependencies = []
                
                for param_name, param in sig.parameters.items():
                    # Skip self, args, kwargs, and variadic parameters
                    if param_name in ('self', 'args', 'kwargs'):
                        continue
                    # Skip *args (VAR_POSITIONAL) and **kwargs (VAR_KEYWORD) - never required
                    if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                        continue
                    
                    params[param_name] = {
                        'annotation': param.annotation,
                        'default': param.default,
                        'required': param.default == inspect.Parameter.empty
                    }
                
                self.actor_signatures[actor_config.name] = params
                self.dependency_graph[actor_config.name] = dependencies
                
                logger.info(f"  📋 {actor_config.name}: {len(params)} params, deps={dependencies}")
                return
            except Exception as e:
                logger.warning(f"⚠️  Failed to introspect forward method for {actor_config.name}: {e}")
        
        # Strategy 3: Fallback - inspect __call__
        if hasattr(actor, '__call__'):
            try:
                sig = inspect.signature(actor.__call__)
                params = {}
                for param_name, param in sig.parameters.items():
                    # Skip self, args, kwargs
                    if param_name in ('self', 'args', 'kwargs'):
                        continue
                    # Skip *args (VAR_POSITIONAL) and **kwargs (VAR_KEYWORD) - never required
                    if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                        continue
                    params[param_name] = {
                        'annotation': param.annotation,
                        'default': param.default,
                        'required': param.default == inspect.Parameter.empty
                    }
                self.actor_signatures[actor_config.name] = params
                self.dependency_graph[actor_config.name] = []
                logger.info(f"  📋 {actor_config.name}: {len(params)} params (__call__), deps=[]")
                return
            except Exception as e:
                logger.warning(f"⚠️  Failed to introspect __call__ for {actor_config.name}: {e}")
        
        # Fallback: No signature
        logger.warning(f"⚠️  Actor {actor_config.name} has no inspectable signature")
        self.actor_signatures[actor_config.name] = {}
        self.dependency_graph[actor_config.name] = []
    
    def resolve_input(self, input_spec: str, resolution_context: Dict) -> Any:
        """
        🆕 DECLARATIVE INPUT RESOLUTION (A-Team FINAL Solution)
        
        Resolve input from specification string with natural syntax:
        
        Examples:
            "input.query" → From swarm.run() kwargs
            "BusinessTermResolver.required_tables" → From previous actor output
            "context.current_date" → From context_providers
            "metadata.get_all_validations()" → Call metadata_manager method
            "metadata.get_partition_info_for_tables(BusinessTermResolver.required_tables)" → Method with arg
        
        Args:
            input_spec: Specification string describing where to get the value
            resolution_context: Dict containing:
                - 'inputs': kwargs from swarm.run()
                - 'actor_outputs': Dict of previous actor outputs
                - 'context_providers': Dict of context providers (metadata_manager, etc.)
        
        Returns:
            Resolved value or None
        """
        input_spec = input_spec.strip()
        
        # Pattern 1: input.{field} - From swarm.run() kwargs
        if input_spec.startswith("input."):
            field = input_spec.split(".", 1)[1]
            value = resolution_context.get('inputs', {}).get(field)
            if value is not None:
                logger.debug(f"   ✅ Resolved from input.{field}")
            return value
        
        # Pattern 2: context.{field} - From context_providers
        elif input_spec.startswith("context."):
            field = input_spec.split(".", 1)[1]
            value = resolution_context.get('context_providers', {}).get(field)
            if value is not None:
                logger.debug(f"   ✅ Resolved from context.{field}")
            return value
        
        # Pattern 3: metadata.{method}(...) or metadata.{attr} - From metadata_manager
        elif input_spec.startswith("metadata."):
            method_or_attr = input_spec.split(".", 1)[1]
            context_providers = resolution_context.get('context_providers', {})
            # ✅ A-TEAM FIX: Look for 'metadata' (new) or 'metadata_manager' (legacy)
            metadata_manager = context_providers.get('metadata') or context_providers.get('metadata_manager')
            
            logger.info(f"   🔍 Trying to resolve metadata.{method_or_attr}")
            logger.info(f"   🔍 context_providers keys: {list(context_providers.keys())}")
            logger.info(f"   🔍 metadata_manager found: {metadata_manager is not None}")
            
            if not metadata_manager:
                logger.warning(f"⚠️  metadata_manager not found in context_providers for '{input_spec}'")
                logger.warning(f"⚠️  Available providers: {list(context_providers.keys())}")
                return None
            
            # Check if it's a method call (has parentheses)
            if "(" in method_or_attr:
                method_name = method_or_attr.split("(")[0]
                args_str = method_or_attr.split("(")[1].rstrip(")")
                
                if not hasattr(metadata_manager, method_name):
                    logger.warning(f"⚠️  Method '{method_name}' not found on metadata_manager")
                    return None
                
                method = getattr(metadata_manager, method_name)
                
                # Parse and resolve arguments
                try:
                    if args_str.strip():
                        args = []
                        for arg_spec in args_str.split(","):
                            arg_spec = arg_spec.strip()
                            # Recursively resolve the argument
                            arg_value = self.resolve_input(arg_spec, resolution_context)
                            args.append(arg_value)
                        
                        logger.info(f"   🔧 Calling {method_name}({args})")
                        result = method(*args)
                        logger.info(f"   ✅ Result: {str(result)[:200]}")
                        return result
                    else:
                        logger.info(f"   🔧 Calling {method_name}()")
                        result = method()
                        logger.info(f"   ✅ Result: {str(result)[:200]}")
                        return result
                except Exception as e:
                    logger.error(f"   ❌ Error calling metadata.{method_name}: {e}")
                    import traceback
                    logger.error(f"   ❌ Traceback: {traceback.format_exc()}")
                    return None
            else:
                # Attribute access
                if hasattr(metadata_manager, method_or_attr):
                    value = getattr(metadata_manager, method_or_attr)
                    logger.debug(f"   ✅ Resolved from metadata.{method_or_attr}")
                    return value
                else:
                    logger.warning(f"⚠️  Attribute '{method_or_attr}' not found on metadata_manager")
                    return None
        
        # Pattern 4: {Actor}.{field} - From previous actor output
        elif "." in input_spec:
            actor_name, field = input_spec.split(".", 1)
            actor_outputs = resolution_context.get('actor_outputs', {})
            actor_output = actor_outputs.get(actor_name)
            
            if not actor_output:
                logger.debug(f"   ⚠️  Actor '{actor_name}' output not found")
                return None
            
            # Extract field from output using existing extraction logic
            value = self._extract_from_output(actor_output, field)
            if value is not None:
                logger.debug(f"   ✅ Resolved from {actor_name}.{field}")
            return value
        
        # Pattern 5: Direct value (fallback)
        logger.warning(f"⚠️  Unknown input specification format: '{input_spec}'")
        return None
    
    def _resolve_parameter(self, param_name: str, param_info: Dict, kwargs: Dict, shared_context: Dict) -> Any:
        """
        Resolve parameter from multiple sources.
        
#         🔥 A-TEAM FIX: CORRECT priority order!
        1. Direct kwargs (explicit overrides)
        2. SharedContext (for GLOBAL parameters like current_date)
        3. IOManager (previous actor outputs) ← THE MAIN DATA FLOW
        4. Metadata tools
        5. Defaults
        
#         ❌ NEVER resolve domain data from SharedContext['metadata'] - agents should call tools!
        """
        
        # Priority 1: Direct kwargs (explicit overrides)
        if param_name in kwargs:
            logger.debug(f"✅ Resolved '{param_name}' from kwargs")
            return kwargs[param_name]
        
        # Priority 2: SharedContext for GLOBAL parameters (current_date, current_datetime, etc.)
        # These are system-wide constants that should be shared across all actors
        if param_name in ['current_date', 'current_datetime', 'timezone']:
            if hasattr(self, 'shared_context') and self.shared_context:
                if self.shared_context.has(param_name):
                    value = self.shared_context.get(param_name)
                    logger.info(f"✅ Resolved '{param_name}' from SharedContext (global)")
                    return value
        
        # Priority 3: IOManager - previous actor outputs (MAIN DATA FLOW!)
        if hasattr(self, 'io_manager') and self.io_manager:
            all_outputs = self.io_manager.get_all_outputs()
            for actor_name, actor_output in all_outputs.items():
                if hasattr(actor_output, 'output_fields') and actor_output.output_fields:
                    # Exact match
                    if param_name in actor_output.output_fields:
                        value = actor_output.output_fields[param_name]
                        logger.info(f"✅ Resolved '{param_name}' from IOManager['{actor_name}']")
                        
                        # 🔥 A-TEAM FIX: AGENTIC TYPE TRANSFORMATION (ReAct agent with sandbox!)
                        expected_type = param_info.get('annotation', Any)
                        if expected_type != Any and value is not None:
                            actual_type = type(value)
                            # Get origin for typing generics (List[str] → list, Dict[str, Any] → dict)
                            import typing
                            expected_origin = typing.get_origin(expected_type) or expected_type
                            
                            # 🔥 A-TEAM FIX: Skip transformation for Union types IMMEDIATELY!
                            # Union types ALWAYS fail isinstance() checks and waste tokens
                            expected_str = str(expected_type)
                            if 'Union' in expected_str or expected_origin is typing.Union:
                                logger.debug(f"⏩ Skipping transformation for Union type: {expected_str}")
                                logger.debug(f"   Using raw value: {actual_type.__name__} (DSPy will coerce)")
                                continue  # Skip to next parameter
                            
                            if actual_type != expected_origin:
                                actual_name = actual_type.__name__
                                expected_name = getattr(expected_origin, '__name__', str(expected_type))
                                logger.info(f"🔄 Type mismatch detected: {actual_name} → {expected_name}")
                                
                                # 🔥 A-TEAM LEARNING FIX: Check memory for past transformation failures!
                                should_skip_transformation = False
                                if hasattr(self, 'shared_memory') and self.shared_memory:
                                    try:
                                        past_failures = self.shared_memory.retrieve(
                                            query=f"SmartDataTransformer {param_name} {actor_name} transformation failure",
                                            goal=self.todo.root_task if hasattr(self, 'todo') and self.todo else "transformation learning",
                                            budget_tokens=300
                                        )
                                        
                                        if past_failures:
                                            logger.info(f"🧠 LEARNING: Found {len(past_failures)} past transformation failures for {param_name}")
                                            
                                            # Check if Union isinstance error happened before
                                            for failure in past_failures:
                                                failure_content = str(failure.content) if hasattr(failure, 'content') else str(failure)
                                                if "Union cannot be used with isinstance" in failure_content or "Union" in failure_content:
                                                    logger.info(f"🧠 LEARNING: Skipping SmartDataTransformer for Union type (learned from past failure)")
                                                    logger.info(f"   📦 Using raw value: {type(value).__name__}")
                                                    should_skip_transformation = True
                                                    break
                                    except Exception as mem_e:
                                        logger.debug(f"Memory query failed: {mem_e}")
                                
                                if should_skip_transformation:
                                    # Skip transformation, use raw value
                                    logger.info(f"   📦 DSPy ReAct will handle type conversion")
                                else:
                                    logger.info(f"   🤖 Invoking SmartDataTransformer (ReAct agent with sandbox)")
                                    try:
                                        # Call transformer synchronously (it handles async internally)
                                        transformed = self.data_transformer.transform(
                                            source=value,
                                            target_type=expected_origin,  # Use origin type (list, dict, not List[str])
                                            context=f"Parameter '{param_name}' from {actor_name}. Agent needs {expected_name} to proceed.",
                                            param_name=param_name
                                        )
                                        if transformed is not None:
                                            value = transformed
                                            logger.info(f"✅ Agentic transformation successful: {type(value).__name__}")
                                        else:
                                            logger.warning(f"⚠️  Transformer returned None - using original value")
                                    except Exception as e:
                                        # 🔥 A-TEAM FIX: Don't fail the entire actor execution on transformation failure!
                                        # Just log the error and continue with the original value
                                        # DSPy ReAct signature system will handle type coercion
                                        logger.warning(f"⚠️  Agentic transformation failed: {e}")
                                        logger.info(f"   📦 Continuing with original value, DSPy will handle type conversion")
                        
                        return value
        
                    # 🔥 A-TEAM FIX: GENERIC PARAMETER ALIASING
                    # Common semantic aliases (NO domain-specific logic!)
                    aliases = {
                        'tables': ['relevant_tables', 'selected_tables', 'table_list', 'available_tables'],
                        'table_names': ['available_tables', 'all_tables', 'tables'],
                        'columns': ['selected_columns', 'column_list'],
                        'resolved_terms': ['terms', 'business_terms'],
                        'filters': ['filter_conditions', 'where_conditions'],
                    }
                    
                    # Check if param_name has known aliases
                    if param_name in aliases:
                        for alias in aliases[param_name]:
                            if alias in actor_output.output_fields:
                                value = actor_output.output_fields[alias]
                                logger.info(f"✅ Resolved '{param_name}' from IOManager['{actor_name}']['{alias}'] (alias)")
                                
                                # 🔥 CRITICAL FIX: Return immediately! Don't wait for type transformation!
                                # Type transformation is optional - if types match, we still need to return!
                                return value
        
        # Priority 3: Previous actor outputs from shared_context['actor_outputs'] (legacy path)
        actor_outputs = shared_context.get('actor_outputs', {})
        for actor_name, output in actor_outputs.items():
            value = self._extract_from_output(output, param_name)
            if value is not None:
                logger.info(f"✅ Resolved '{param_name}' from actor '{actor_name}' output")
                return value
        
        # Priority 4: SharedContext - ONLY for 'goal', 'query', 'conversation_history' (NOT metadata!)
        if hasattr(self, 'shared_context') and self.shared_context:
            # Whitelist of allowed SharedContext keys for parameters
            allowed_keys = {'goal', 'query', 'conversation_history', 'session_id'}
            
            if param_name in allowed_keys:
                # Try exact match
                if self.shared_context.has(param_name):
                    value = self.shared_context.get(param_name)
                    logger.info(f"✅ Resolved '{param_name}' from SharedContext")
                    return value
                
                # Try semantic match ONLY within allowed keys
                for key in allowed_keys:
                    if self.shared_context.has(key) and (param_name.lower() in key.lower() or key.lower() in param_name.lower()):
                        value = self.shared_context.get(key)
                        logger.info(f"✅ Resolved '{param_name}' from SharedContext['{key}'] (semantic match)")
                        return value  # 🔧 A-TEAM FIX: Return immediately when found!
            
            # 🔍 Special handling for search_query: try to extract from 'query' or 'goal' if available
            if param_name == 'search_query':
                if self.shared_context.has('query'):
                    query_value = self.shared_context.get('query')
                    if query_value and isinstance(query_value, str):
                        logger.info(f"✅ Resolved 'search_query' from SharedContext['query'] (extracted from task)")
                        return query_value
                if self.shared_context.has('goal'):
                    goal_value = self.shared_context.get('goal')
                    if goal_value and isinstance(goal_value, str):
                        logger.info(f"✅ Resolved 'search_query' from SharedContext['goal'] (extracted from task)")
                        return goal_value
        
        # Priority 5: Context providers (direct match)
        if param_name in self.context_providers:
            logger.info(f"✅ Resolved '{param_name}' from context_providers")
            return self.context_providers[param_name]
        
        # Priority 6: Shared context dict (non-metadata keys only)
        if param_name in shared_context and param_name != 'metadata':
            logger.info(f"✅ Resolved '{param_name}' from shared_context dict")
            return shared_context[param_name]
        
        # ✅ Priority 6.5: SharedContext['metadata'] - USER FEEDBACK: This was missing!
        # Check metadata directly instead of waiting for recovery
        metadata = shared_context.get('metadata', {})
        if param_name in metadata:
            logger.info(f"✅ Resolved '{param_name}' from SharedContext['metadata']")
            return metadata[param_name]
        
        # Check metadata with aliases (GENERIC - not domain specific!)
        aliases = {
            'tables': ['relevant_tables', 'selected_tables', 'table_list', 'available_tables', 'get_all_tables'],
            'table_names': ['available_tables', 'tables', 'relevant_tables', 'selected_tables', 'table_list', 'get_all_tables'],
            'columns': ['column_list', 'selected_columns', 'relevant_columns'],
            'resolved_terms': ['business_terms', 'terms', 'term_mapping', 'get_business_terms'],
            'tables_metadata': ['get_all_table_metadata', 'table_metadata', 'schema_info'],
            'columns_metadata': ['column_metadata', 'columns_info'],
            'business_terms': ['get_business_terms', 'business_context', 'get_business_context'],
        }
        param_aliases = aliases.get(param_name, [])
        for alias in param_aliases:
            if alias in metadata:
                logger.info(f"✅ Resolved '{param_name}' via alias '{alias}' from SharedContext['metadata']")
                return metadata[alias]
        
        # Priority 7: Default value from signature
        if param_info['default'] != inspect.Parameter.empty:
            logger.debug(f"✅ Using default value for '{param_name}'")
            return param_info['default']
        
        # No resolution found
        logger.debug(f"❌ Cannot resolve parameter '{param_name}'")
        return None
    
    def _extract_from_metadata_manager(self, metadata_manager, param_name: str) -> Any:
        """
        Extract parameter from metadata_manager (user-provided metadata).
        
        NO HARDCODING - just simple attribute mapping!
        """
        # Generic attribute mapping (NO domain-specific logic!)
        metadata_mappings = {
            'validation_criterias': 'validations',
            'business_context': 'business_context',
            'term_glossary': 'term_glossary',
            'filter_conditions': 'filter_conditions',
            'joining_conditions': 'joining_conditions',
            'table_metadata': 'table_metadata',
            'column_metadata': 'column_metadata',
            'widgets_context': 'widgets_context',
        }
        
        # Try direct mapping first
        attr_name = metadata_mappings.get(param_name, param_name)
        
        if hasattr(metadata_manager, attr_name):
            value = getattr(metadata_manager, attr_name)
            if value:
                logger.debug(f"   Extracted from metadata_manager.{attr_name}")
                return value
        
        return None
    
    def _semantic_extract(self, output: Any, param_name: str) -> Any:
        """
        Semantic extraction using LLM understanding.
        
        Replaces fuzzy matching with LLM-based semantic understanding.
        Handles synonyms, typos, variations.
        
        A-Team Decision: This is the NEW way to resolve parameters.
        """
        try:
            # Build available fields
            available = {}
            if hasattr(output, '__dict__'):
                available = {k: v for k, v in vars(output).items() if not k.startswith('_')}
            elif isinstance(output, dict):
                available = output
            else:
                return None  # Can't extract from non-object/non-dict
            
            if not available:
                return None
            
            # Quick check: exact match (skip LLM)
            if param_name in available:
                return available[param_name]
            
            # Ask LLM which field matches param_name
            match_result = self._llm_match_field(param_name, available)
            
            if match_result and match_result.confidence > 0.5:
                matched_field = match_result.field_name
                if matched_field in available:
                    logger.info(f"✅ Semantic match: '{param_name}' → '{matched_field}' (confidence={match_result.confidence:.2f})")
                    logger.info(f"   Reasoning: {match_result.reasoning}")
                    return available[matched_field]
            
            return None
        
        except Exception as e:
            logger.error(f"❌ Semantic extraction error: {e}")
            return None
    
    def _llm_match_field(self, param_name: str, available_fields: Dict) -> Optional[Any]:
        """Use LLM to match parameter name to available fields."""
        try:
            import dspy
            from dataclasses import dataclass
            
            class FieldMatchSignature(dspy.Signature):
                """Match parameter name to available field."""
                
                parameter_needed = dspy.InputField(desc="Parameter name being requested")
                available_fields = dspy.InputField(desc="Available fields with previews")
                
                best_match = dspy.OutputField(desc="""
                    Best matching field name from available fields.
                    
                    Consider:
                    - Semantic similarity (e.g., 'schema' matches 'structure')
                    - Typos (e.g., 'meta' matches 'metadata')
                    - Variations (e.g., 'user_data' matches 'userData')
                    
                    Return the exact field name or 'none' if no good match.
                """)
                
                confidence = dspy.OutputField(desc="Confidence in match (0.0-1.0)")
                reasoning = dspy.OutputField(desc="Brief explanation")
            
            # Format available fields for LLM
            fields_str = "\n".join([
                f"  - {name}: {type(value).__name__} = {str(value)[:100]}..."
                for name, value in available_fields.items()
            ])
            
            matcher = dspy.ChainOfThought(FieldMatchSignature)
            result = matcher(
                parameter_needed=param_name,
                available_fields=fields_str
            )
            
            @dataclass
            class MatchResult:
                field_name: str
                confidence: float
                reasoning: str
            
            # Parse confidence
            try:
                confidence = float(result.confidence)
                confidence = max(0.0, min(1.0, confidence))  # Clamp
            except (ValueError, TypeError, AttributeError):
                confidence = 0.5
            
            return MatchResult(
                field_name=result.best_match,
                confidence=confidence,
                reasoning=result.reasoning
            )
        
        except Exception as e:
            logger.warning(f"⚠️ LLM field matching unavailable: {e}")
            return None
    
    def _extract_from_output(self, output, param_name: str) -> Any:
        """Extract parameter from previous actor's output.
        
        Handles:
        1. EpisodeResult (from wrapped SYNAPSE actors) → extract from .output or tagged_outputs
        2. DSPy Prediction objects
        3. Dict-like outputs
        4. Parameter name variations (generic patterns)
        5. DataFrames, files, web content (extensible)
        
        🔑 A-TEAM FIX: Unwrap nested EpisodeResults WITHOUT recursion to prevent stack overflow!
        🆕 A-TEAM: Now uses SEMANTIC extraction instead of fuzzy matching!
        """
        # 🔍 A-TEAM DEBUG: Log extraction attempt (DEBUG level to reduce noise)
        logger.debug(f"🔍 [EXTRACT] Attempting to extract '{param_name}' from output type: {type(output)}")
        
        # 🔑 CRITICAL FIX: Unwrap nested EpisodeResults iteratively (NO RECURSION!)
        unwrapped = output
        max_unwrap = 10  # Safety limit
        unwrap_count = 0
        
        # ✅ A-TEAM FIX: Check if it's ACTUALLY an EpisodeResult, not just has 'output' attribute
        # DSPy Predictions may have 'output' field in signature, but they're not EpisodeResults!
        from .data_structures import EpisodeResult
        
        logger.debug(f"🔍 [EXTRACT] Is EpisodeResult: {isinstance(output, EpisodeResult)}")
        
        while isinstance(unwrapped, EpisodeResult) and unwrap_count < max_unwrap:
            logger.debug(f"🔍 [EXTRACT] Unwrapping EpisodeResult #{unwrap_count+1}")
            # This is an EpisodeResult
            if unwrapped.output is not None:
                logger.debug(f"🔍 [EXTRACT] EpisodeResult.output is NOT None, unwrapping...")
                unwrapped = unwrapped.output
                unwrap_count += 1
            else:
                logger.warning(f"⚠️  EpisodeResult.output is None, no trajectory output for {param_name}")
                # EpisodeResult.output is None, try tagged_outputs
                if hasattr(unwrapped, 'tagged_outputs') and unwrapped.tagged_outputs:
                    logger.info(f"🔍 Checking {len(unwrapped.tagged_outputs)} tagged outputs for {param_name}")
                    for tagged in unwrapped.tagged_outputs:
                        if hasattr(tagged, 'content'):
                            # Recursively unwrap tagged content (but with depth limit now)
                            value = self._extract_from_output(tagged.content, param_name)
                            if value is not None:
                                logger.info(f"✅ Found {param_name} in tagged output")
                                return value
                
                # Try trajectory if available
                if hasattr(unwrapped, 'trajectory'):
                    for step in unwrapped.trajectory:
                        if step.get('step') == 'actor' and 'output' in step:
                            step_output = step['output']
                            if step_output is not None:
                                logger.info(f"🔄 Found output in trajectory, extracting '{param_name}'")
                                # Don't recurse, just set unwrapped and let the loop continue
                                unwrapped = step_output
                                unwrap_count += 1
                                break
                    else:
                        # No output in trajectory either
                        logger.warning(f"⚠️  EpisodeResult.output is None, no trajectory output for {param_name}")
                        return None
                else:
                    logger.warning(f"⚠️  EpisodeResult.output is None, cannot extract {param_name}")
                    return None
        
        if unwrap_count >= max_unwrap:
            logger.error(f"❌ Max unwrap depth ({max_unwrap}) reached for '{param_name}' - possible circular reference!")
            return None
        
        # Now unwrapped is the actual data (Prediction, dict, etc.)
        output = unwrapped
        
        # Direct attribute access
        if hasattr(output, param_name):
            return getattr(output, param_name)
        
        # Dict access
        if isinstance(output, dict) and param_name in output:
            return output[param_name]
        
        # 🆕 A-TEAM: Use user-configurable mappings (NOT hardcoded!)
        # Try pattern matching with user-defined mappings
        if param_name in self.param_mappings:
            for attr in self.param_mappings[param_name]:
                if hasattr(output, attr):
                    value = getattr(output, attr)
                    if value is not None:  # Changed: accept 0, False, empty string
                        return value
                if isinstance(output, dict) and attr in output:
                    value = output[attr]
                    if value is not None:
                        return value
        
        # 🆕 A-TEAM: Semantic extraction (LLM-based, pure agentic)
        if self.registration_orchestrator:
            try:
                value = self._semantic_extract(output, param_name)
                if value is not None:
                    return value
                else:
                    # A-TEAM FIX: This is normal - trying to extract input params from output
                    # Should be DEBUG, not ERROR
                    logger.debug(f"🔍 Semantic extraction: '{param_name}' not found in {type(output).__name__}")
                    logger.debug(f"   (This is normal - tried to extract from previous actor output)")
                    return None
            except Exception as e:
                logger.error(f"❌ Semantic extraction failed for '{param_name}': {e}")
                logger.error(f"   Fix the semantic extraction logic or actor output structure!")
                raise RuntimeError(f"Parameter extraction failed for '{param_name}' - no fallbacks allowed!") from e
        
        # No registration orchestrator - this is a configuration error
        logger.error(f"❌ RegistrationOrchestrator not available - cannot extract '{param_name}'")
        raise RuntimeError(f"RegistrationOrchestrator must be enabled for semantic extraction!")
        
        return None
    
    # =========================================================================
    # 🎯 A-TEAM GAP #4: Agentic Retry System with Error Context Sharing
    # =========================================================================
    
    async def _execute_actor_with_retry(
        self,
        actor_config: ActorConfig,
        task: 'SubtaskState',
        context: str,
        kwargs: Dict,
        actor_context_dict: Optional[Dict] = None,
        max_retries: int = 3
    ) -> AsyncGenerator[Dict[str, Any], Any]:
        """
        Execute actor with intelligent retry on error.
        
        🎯 A-TEAM GAP #4: No hardcoding - uses LLM to:
        1. Extract error solutions from web search
        2. Modify parameters based on error context
        3. Share error context with other agents
        4. Decide when to stop retrying
        """
        last_error = None
        error_context_accumulated = []
        
        for attempt in range(max_retries):
            try:
                logger.info(f"🎯 Executing {actor_config.name} (attempt {attempt + 1}/{max_retries})")
                
                # If we have error context from previous attempts, augment context
                if error_context_accumulated:
                    error_summary = "\n\n".join([
                        f"Previous Attempt {i+1} Error:\n{ec['error']}\n\nSuggested Fix:\n{ec['solution']}"
                        for i, ec in enumerate(error_context_accumulated)
                    ])
                    # 🔴 A-TEAM FIX: Handle context as tuple (context_string, context_meta)
                    # Previously f"{context}" would stringify the entire tuple including metadata dict,
                    # producing garbage output like "('some context...', {'total_tokens': 5000})"
                    retry_suffix = f"\n\n🔧 RETRY CONTEXT:\n{error_summary}"
                    if isinstance(context, tuple):
                        context = (context[0] + retry_suffix, context[1])
                    else:
                        context = str(context) + retry_suffix
                    logger.info(f"📝 Augmented context with {len(error_context_accumulated)} previous error(s)")
                
                # Execute actor (with overflow protection!) - now an async generator
                result = None
                async for event in self._execute_actor_with_overflow_protection(
                    actor_config,
                    task,
                    context,
                    kwargs,
                    actor_context_dict
                ):
                    # Yield all events from execution
                    yield event
                    # Extract result from final event
                    if isinstance(event, dict) and event.get("type") == "result":
                        result = event.get("result")
                
                logger.info(f"✅ {actor_config.name} succeeded on attempt {attempt + 1}")
                # Result was already yielded, just return
                return
                
            except Exception as e:
                last_error = e
                error_str = str(e)
                logger.warning(f"❌ {actor_config.name} failed (attempt {attempt + 1}): {error_str[:200]}")
                
                # Record error for retry (auto error research handled in _execute_actor)
                error_context_accumulated.append({
                    'attempt': attempt + 1,
                    'error': error_str,
                    'solution': 'Will retry with error context',
                    'should_retry': True
                })
                
                # If this is the last attempt, raise
                if attempt == max_retries - 1:
                    logger.error(f"💥 {actor_config.name} exhausted all {max_retries} retries")
                    raise
                
                # Brief backoff
                await asyncio.sleep(0.5 * (attempt + 1))
        
        # If we get here, all retries failed
        raise RuntimeError(f"All {max_retries} retries failed. Last error: {last_error}")
    
    async def _execute_actor_with_overflow_protection(
        self,
        actor_config: ActorConfig,
        task: TodoItem,
        context: str,
        kwargs: Dict,
        actor_context_dict: Optional[Dict] = None
    ) -> AsyncGenerator[Dict[str, Any], Any]:
        """
        🛡️ A-TEAM ZERO-FAILURE: Execute actor with token overflow protection.
        
        This wrapper catches token overflow errors, learns actual limits,
        compresses context, and retries. NEVER fails on token limits!
        
        Flow:
        1. Try normal execution
        2. If token overflow: Detect (LLM), Extract limit (LLM), Learn, Persist
        3. Emergency compress (4-layer chain)
        4. Retry with compressed context
        5. SUCCESS guaranteed!
        """
        try:
            # Attempt normal execution - _execute_actor is now an async generator
            result = None
            async for event in self._execute_actor(
                actor_config, task, context, kwargs, actor_context_dict
            ):
                # Yield all events from _execute_actor
                yield event
                # Extract result from final event
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            
            # If we got here, execution succeeded - result was already yielded
            return
        
        except Exception as e:
            # Check if this is a token overflow error (LLM-based detection!)
            if hasattr(self, 'limit_learner'):
                try:
                    is_overflow = self.limit_learner.is_token_overflow(e)
                except Exception as detect_error:
                    logger.warning(f"Overflow detection failed: {detect_error}")
                    is_overflow = False
                
                if is_overflow:
                    logger.warning(f"🚨 TOKEN OVERFLOW DETECTED: {str(e)[:200]}")
                    
                    # Extract actual limit from error message (LLM-based!)
                    try:
                        actual_limit = self.limit_learner.extract_actual_limit(e)
                        if actual_limit:
                            logger.info(f"✅ Extracted actual limit from error: {actual_limit:,} tokens")
                            
                            # Learn this limit for future calls
                            # 🔴 A-TEAM FIX: Handle context as tuple (context_string, context_meta)
                            _overflow_ctx_str = context[0] if isinstance(context, tuple) else str(context)
                            context_size = self.context_guard.estimate_tokens(_overflow_ctx_str)
                            self.limit_learner.learn_from_error(
                                model_name=self.current_model_name or 'unknown',
                                error=e,
                                context_size=context_size
                            )
                            logger.info(f"📚 LEARNED LIMIT: {self.current_model_name} → {actual_limit:,} tokens (persisted)")
                            
                            # Emergency compress context (4-layer chain!)
                            target_limit = int(actual_limit * 0.9)  # Use 90% to be safe
                            compressed_context = self.context_guard.emergency_compress(
                                context=_overflow_ctx_str,
                                target_limit=target_limit
                            )
                            
                            logger.info(f"🔄 RETRYING with compressed context (target: {target_limit:,} tokens)")
                            yield {"module": "Synapse.core.conductor", "message": f"I am retrying execution with compressed context (target: {target_limit:,} tokens)"}
                            
                            # Retry with compressed context - _execute_actor is now an async generator
                            result = None
                            async for event in self._execute_actor(
                                actor_config, task, compressed_context, kwargs, actor_context_dict
                            ):
                                # Yield all events from retry
                                yield event
                                # Extract result from final event
                                if isinstance(event, dict) and event.get("type") == "result":
                                    result = event.get("result")
                            
                            # If retry succeeded, return (result was already yielded)
                            return
                        else:
                            logger.error("Could not extract limit from error - re-raising")
                    except Exception as learn_error:
                        logger.error(f"Failed to learn from overflow error: {learn_error}")
            
            # Not a token overflow (or learning failed), re-raise original error
            raise
    
    async def _execute_actor(
        self,
        actor_config: ActorConfig,
        task: TodoItem,
        context: str,
        kwargs: Dict,
        actor_context_dict: Optional[Dict] = None  # 🔥 A-TEAM: Actor-specific context from metadata_provider
    ) -> AsyncGenerator[Dict[str, Any], Any]:
        """
        Execute actor with parameter resolution.
        
        🆕 DECLARATIVE MODE (A-Team FINAL): If actor_config.inputs is provided,
        use declarative resolution. Otherwise, fall back to signature introspection.
        
        🤝 COORDINATION: Check for pending feedback from other agents before execution.
        """
        # 🌍 Wrap task description with environment context
        if self.env_manager and hasattr(task, 'description') and task.description:
            try:
                # Wrap the task description with current environment state
                original_description = task.description
                enhanced_description = self._wrap_instruction_with_env_context(original_description)
                
                # Create a new TodoItem with enhanced description to avoid mutating the original
                # TodoItem is a dataclass, so we can use replace
                try:
                    from dataclasses import replace
                    task = replace(task, description=enhanced_description)
                except Exception:
                    # Fallback: create new TodoItem manually with all fields
                    task = TodoItem(
                        id=task.id,
                        description=enhanced_description,
                        actor=getattr(task, 'actor', ''),
                        status=getattr(task, 'status', 'pending'),
                        priority=getattr(task, 'priority', 0.5),
                        estimated_reward=getattr(task, 'estimated_reward', 0.0),
                        dependencies=getattr(task, 'dependencies', []),
                        attempts=getattr(task, 'attempts', 0),
                        max_attempts=getattr(task, 'max_attempts', 5),
                        failure_reasons=getattr(task, 'failure_reasons', []),
                        completion_time=getattr(task, 'completion_time', None)
                    )
                
                logger.info(f"🌍 Enhanced task description with environment context (+{len(enhanced_description) - len(original_description)} chars)")
                logger.debug(f"   Original: {original_description[:100]}...")
                logger.debug(f"   Enhanced length: {len(enhanced_description)} chars")
            except Exception as e:
                logger.warning(f"⚠️  Failed to enhance task with environment context: {e}")
        
        actor = actor_config.agent
        
        # 🔥 SAFETY GUARD: If actor is a SynapseCore wrapper, that's expected.
        # SynapseCore.arun() will call self.actor internally.
        # But if somehow actor is double-wrapped (SynapseCore(actor=SynapseCore(...))),
        # unwrap to the correct level to prevent 'SynapseCore' object is not callable.
        # Use a while loop to handle arbitrary nesting depth.
        _unwrap_depth = 0
        while (type(actor).__name__ == 'SynapseCore' and hasattr(actor, 'actor')
                and type(actor.actor).__name__ == 'SynapseCore'):
            _unwrap_depth += 1
            logger.warning(f"⚠️ DOUBLE-WRAPPED SynapseCore detected for {actor_config.name} (depth={_unwrap_depth})! Unwrapping inner layer.")
            actor.actor = actor.actor.actor  # Fix in-place so all downstream calls use real agent
            if _unwrap_depth > 10:
                logger.error(f"❌ Infinite unwrap loop for {actor_config.name} — aborting")
                break
        
        # 🤝 NEW: Check for feedback from other agents
        if self.feedback_channel and self.feedback_channel.has_feedback(actor_config.name):
            messages = self.feedback_channel.get_for_actor(actor_config.name, clear=True)
            logger.info(f"📧 Actor '{actor_config.name}' received {len(messages)} feedback message(s)")
            
            # Format messages for injection
            feedback_context = self.feedback_channel.format_messages_for_agent(actor_config.name, messages)
            
            # Inject feedback into context for actor to see
            if 'feedback' not in kwargs:
                kwargs['feedback'] = feedback_context
            else:
                kwargs['feedback'] += "\n\n" + feedback_context
            
            logger.debug(f"📧 Feedback injected for '{actor_config.name}':\n{feedback_context[:200]}...")
        
        # Get shared context
        shared_context = kwargs.get('_shared_context', {'actor_outputs': {}})
        
        # 🔍 DEBUG: Log current state
        logger.info(f"🔍 DEBUG: Executing actor '{actor_config.name}'")
        logger.info(f"🔍 DEBUG: Available actor_outputs: {list(shared_context.get('actor_outputs', {}).keys())}")
        logger.info(f"🔍 DEBUG: _shared_context in kwargs: {'_shared_context' in kwargs}")
        
        # 🔄 AUTO-RESOLVE parameters with optional mappings override (A-Team FINAL - User Corrected)
        logger.info(f"✅ Resolving parameters for '{actor_config.name}'")
        signature = self.actor_signatures.get(actor_config.name, {})
        
        if not signature:
            # Fallback: basic kwargs
            logger.warning(f"⚠️  No signature for {actor_config.name}, using basic kwargs")
            # 🎯 A-TEAM CRITICAL FIX: Pass TASK DESCRIPTION as query, not full goal!
            resolved_kwargs = {}
            for k, v in kwargs.items():
                if k in ['conversation_history', 'session_id']:
                    resolved_kwargs[k] = v
            
            # 🎯 CRITICAL: Actor should execute THIS TASK, not the full user goal!
            # task.description = specific TODO item (e.g., "Create post-receive hook at /git/server/hooks/...")
            # kwargs['goal'] = full user goal (e.g., "Configure git server and webserver...")
            resolved_kwargs['query'] = task.description  # ← SPECIFIC TASK, NOT FULL GOAL!
            resolved_kwargs['goal'] = kwargs.get('goal', task.description)  # Keep full goal as context
            resolved_kwargs['instruction'] = task.description  # For agents expecting 'instruction' (e.g., BrowserExecutor)
            resolved_kwargs['terminal_state'] = kwargs.get('terminal_state', '')  # For agents needing terminal context
            logger.info(f"🎯 Actor query = TASK: {task.description[:80]}...")
        else:
            # 🎯 A-TEAM CRITICAL FIX: Inject task description into kwargs
            # Actor should execute THIS TASK, not the full user goal!
            task_kwargs = kwargs.copy()
            task_kwargs['query'] = task.description  # ← SPECIFIC TASK!
            task_kwargs['task_description'] = task.description
            task_kwargs['instruction'] = task.description  # For agents expecting 'instruction' (e.g., BrowserExecutor)
            task_kwargs['terminal_state'] = kwargs.get('terminal_state', '')  # For agents needing terminal context
            logger.info(f"🎯 Injected task.description into kwargs: {task.description[:80]}...")
            
            # Build resolution context for mappings
            resolution_context = {
                'inputs': task_kwargs,  # Now contains task.description as 'query'
                'actor_outputs': shared_context.get('actor_outputs', {}),
                'context_providers': self.context_providers,
            }
            
            # Build resolved kwargs
            resolved_kwargs = {}
            missing_required = []
            
            for param_name, param_info in signature.items():
                # 🆕 Check if there's an explicit mapping for this parameter
                parameter_mappings = getattr(actor_config, 'parameter_mappings', {}) or {}
                if parameter_mappings and param_name in parameter_mappings:
                    # Use explicit mapping (for special cases)
                    mapping_spec = parameter_mappings[param_name]
                    logger.info(f"   🔑 Using EXPLICIT mapping: {param_name} = {mapping_spec}")
                    try:
                        value = self.resolve_input(mapping_spec, resolution_context)
                        if value is not None:
                            logger.info(f"   ✅ Resolved '{param_name}' = {str(value)[:100]}")
                        else:
                            logger.warning(f"   ⚠️  Mapping for '{param_name}' returned None!")
                    except Exception as e:
                        logger.error(f"   ❌ Error resolving '{param_name}': {e}")
                        value = None
                else:
                    # Use auto-resolution (default) - use task_kwargs which contains instruction
                    value = self._resolve_parameter(param_name, param_info, task_kwargs, shared_context)
                
                if value is not None:
                    # 🔄 A-TEAM: SMART TYPE TRANSFORMATION
                    # Check if value type matches expected type from signature
                    expected_type = param_info.get('annotation', type(None))
                    # inspect is imported at module level (line 43)
                    if expected_type != inspect.Parameter.empty and expected_type != type(None):
                        actual_type = type(value)
                        if actual_type != expected_type and expected_type in (dict, list, str, int, float, bool):
                            logger.debug(f"🔄 Type mismatch for '{param_name}': {actual_type.__name__} → {expected_type.__name__}")
                            try:
                                value = self.data_transformer.transform(
                                    source=value,
                                    target_type=expected_type,
                                    context=f"Parameter for {actor_config.name}",
                                    param_name=param_name
                                )
                                logger.info(f"✅ Transformed '{param_name}' to {expected_type.__name__}")
                            except Exception as e:
                                logger.warning(f"⚠️  Transformation failed for '{param_name}': {e}")
                    
                    resolved_kwargs[param_name] = value
                elif param_info['required']:
                    missing_required.append(param_name)
            
            if missing_required:
                logger.warning(f"⚠️  {actor_config.name} missing: {missing_required}")
                
                # 🔥 A-TEAM INTELLIGENT RECOVERY: Attempt to recover missing parameters
                enable_recovery = getattr(self.config, 'enable_auto_recovery', True)  # Default True
                if enable_recovery:
                    logger.info(f"🛠️  Attempting intelligent recovery for {len(missing_required)} missing parameters...")
                    recovery_result = await self._attempt_parameter_recovery(
                        actor_config=actor_config,
                        missing_params=missing_required,
                        context=kwargs,
                        shared_context=shared_context
                    )
                    
                    if recovery_result['recovered']:
                        logger.info(f"✅ Recovered {len(recovery_result['recovered'])} parameters!")
                        resolved_kwargs.update(recovery_result['recovered'])
                        # Update missing list
                        missing_required = [p for p in missing_required if p not in recovery_result['recovered']]
                    
                    if missing_required:
                        logger.error(f"❌ Still missing after recovery: {missing_required}")
                        # Return early with failure if critical parameters still missing
                        allow_partial = getattr(self.config, 'allow_partial_execution', False)
                        if not allow_partial:
                            logger.error(f"❌ Cannot execute {actor_config.name} - missing required parameters: {missing_required}")
                            yield {"module": "Synapse.core.conductor", "message": f"I cannot execute {actor_config.name} - missing required parameters: {missing_required}"}
                            # Return a minimal EpisodeResult indicating failure
                            failure_result = EpisodeResult(
                                output=None,
                                success=False,
                                trajectory=[],
                                tagged_outputs=[],
                                episode=0,
                                execution_time=0.0,
                                architect_results=[],
                                auditor_results=[],
                                agent_contributions={},
                                alerts=[f"Missing required parameters: {missing_required}"]
                            )
                            yield {"type": "result", "result": failure_result, "module": "Synapse.core.conductor", "message": "I am returning failure result due to missing parameters"}
                            return
        
        # 🤝 NEW: Inject collaboration context for agent-to-agent communication
        if hasattr(actor, 'set_collaboration_context') and self.agent_slack and self.agent_directory:
            try:
                actor.set_collaboration_context(
                    agent_slack=self.agent_slack,
                    agent_directory=self.agent_directory,
                    my_name=actor_config.name
                )
                logger.debug(f"💬 [{actor_config.name}] Collaboration context injected")
            except Exception as e:
                logger.warning(f"⚠️ Failed to inject collaboration context for {actor_config.name}: {e}")
        
        # 🔥 A-TEAM CRITICAL FIX: Merge actor_context_dict into resolved_kwargs!
        # This is the context from metadata_provider.get_context_for_actor()
        if actor_context_dict and isinstance(actor_context_dict, dict):
            logger.info(f"🔧 Merging {len(actor_context_dict)} context items from metadata_provider into resolved_kwargs")
            for key, value in actor_context_dict.items():
                if key not in resolved_kwargs:  # Don't override existing
                    resolved_kwargs[key] = value
                    logger.debug(f"   ✅ Added '{key}' from actor_context")
                else:
                    logger.debug(f"   ⏭️  Skipped '{key}' (already in resolved_kwargs)")
        
        # 🤝 NEW: Add agent directory WITH task assignments for prompt injection
        # This helps agents know which agent to target for collaboration
        if self.agent_directory:
            import json
            # Build enhanced directory with current task assignments
            enhanced_directory = {}
            for agent_name, agent_info in self.agent_directory.items():
                enhanced_directory[agent_name] = dict(agent_info)  # Copy original info
                # Add current task assignment if any
                assigned_tasks = []
                for task_id, task in self.todo.subtasks.items():
                    if hasattr(task, 'actor') and task.actor == agent_name:
                        task_desc = task.description[:100] if hasattr(task, 'description') else ''
                        task_status = task.status if hasattr(task, 'status') else 'unknown'
                        assigned_tasks.append({
                            'task_id': task_id,
                            'description': task_desc,
                            'status': task_status
                        })
                if assigned_tasks:
                    enhanced_directory[agent_name]['current_tasks'] = assigned_tasks
            
            resolved_kwargs['_agent_directory'] = json.dumps(enhanced_directory, indent=2, default=str)
            logger.debug(f"📋 Injected enhanced agent directory with {len(enhanced_directory)} agents and task assignments")
        
        # 🔥 A-TEAM COMPLETE FIX: Inject collaboration results if available
        collaboration_key = f"collaboration_results_{actor_config.name}"
        if hasattr(self, 'shared_context') and self.shared_context:
            collaboration_results = self.shared_context.get(collaboration_key)
            if collaboration_results:
                logger.info(f"📥 Injecting collaboration results for '{actor_config.name}'")
                resolved_kwargs['_collaboration_results'] = json.dumps(collaboration_results, indent=2, default=str)
                resolved_kwargs['_collaboration_available'] = True
                
                # Also inject file contents directly if available
                if isinstance(collaboration_results, dict) and 'file_contents' in collaboration_results:
                    file_contents = collaboration_results.get('file_contents', {})
                    if file_contents:
                        resolved_kwargs['_file_contents'] = json.dumps(file_contents, indent=2, default=str)
                        logger.info(f"📄 Injected {len(file_contents)} file contents for '{actor_config.name}'")
            else:
                resolved_kwargs['_collaboration_available'] = False
        
        # 🔧 A-TEAM FIX: DON'T inject _metadata_tools as kwarg
        # The metadata tools are already available via metadata_manager
        # Injecting them as kwarg causes TypeError if forward() doesn't accept **kwargs
        if hasattr(self, 'metadata_tool_registry') and self.metadata_tool_registry:
            logger.debug(f"🔧 Metadata tools available ({len(self.metadata_tool_registry.tools)} tools) for '{actor_config.name}'")
        
        # 🔴 A-TEAM FIX (BUG I): PRESERVE agent_slack feedback through parameter resolution.
        # The feedback from FeedbackChannel is injected into kwargs['feedback'] above (line ~11629)
        # but gets silently dropped when resolved_kwargs is built from signature parameters.
        # Ensure the feedback context always reaches the actor.
        if 'feedback' in kwargs and kwargs['feedback'] and 'feedback' not in resolved_kwargs:
            resolved_kwargs['feedback'] = kwargs['feedback']
            logger.info(f"📧 A-TEAM FIX: Preserved agent_slack feedback in resolved_kwargs for '{actor_config.name}' | len={len(str(kwargs['feedback']))}")
        
        # =====================================================================
        # 🔴 A-TEAM CRITICAL FIX: INJECT SmartContextGuard context into instruction
        # The `context` parameter (built by _build_actor_context via SmartContextGuard)
        # contains ALL the rich orchestration context: shared memories, local memories,
        # recent trajectory, causal gotchas, completed tasks, available skills,
        # cooperation instructions, dependency results, web search context, etc.
        # Previously this was SILENTLY DISCARDED — never injected into resolved_kwargs.
        # The actor LLM was executing blind without any of this critical context.
        # =====================================================================
        if context:
            # Extract context string from tuple (context_string, context_meta) if needed
            if isinstance(context, tuple):
                context_string = context[0]
            elif isinstance(context, str):
                context_string = context
            else:
                context_string = str(context)
            
            if context_string and len(context_string.strip()) > 0:
                # Inject into 'instruction' by prepending the context
                # This ensures the LLM sees memories, trajectory, gotchas, skills, etc.
                original_instruction = resolved_kwargs.get('instruction', resolved_kwargs.get('query', task.description))
                resolved_kwargs['instruction'] = (
                    f"{context_string}\n\n"
                    f"{'=' * 60}\n"
                    f"TASK TO EXECUTE:\n"
                    f"{'=' * 60}\n"
                    f"{original_instruction}"
                )
                # Also update 'query' to match if present
                if 'query' in resolved_kwargs:
                    resolved_kwargs['query'] = resolved_kwargs['instruction']
                
                logger.info(f"📋 A-TEAM FIX: Injected SmartContextGuard context into instruction | "
                           f"context_len={len(context_string)} | "
                           f"original_instruction_len={len(original_instruction)} | "
                           f"final_instruction_len={len(resolved_kwargs['instruction'])}")
            else:
                logger.warning(f"⚠️ SmartContextGuard context string is empty for '{actor_config.name}'")
        else:
            logger.warning(f"⚠️ No SmartContextGuard context available for '{actor_config.name}' — actor will execute without memories/trajectory/gotchas")
        
        # =====================================================================
        # 🔮 MARL PREDICTION: Predict trajectory BEFORE execution (TODO 2)
        # =====================================================================
        marl_prediction = None
        if self.trajectory_predictor:
            try:
                # Get current state
                current_state = {
                    'goal': smart_truncate(kwargs.get('goal', ''), max_tokens=125),
                    'task': smart_truncate(task.description, max_tokens=125),
                    'actor': actor_config.name,
                    'completed_actors': list(self.io_manager.outputs.keys()) if hasattr(self, 'io_manager') else [],
                    'todo_state': self.todo.get_state_summary() if hasattr(self, 'todo') else {}
                }
                
                # Get other agents
                other_agents = [a for a in self.actors.keys() if a != actor_config.name]
                
                # Predict trajectory
                # 🔴 A-TEAM AUDIT FIX: Run in thread to avoid blocking event loop
                loop = asyncio.get_event_loop()
                _predict_goal = kwargs.get('goal', task.description)
                marl_prediction = await loop.run_in_executor(
                    None,
                    lambda: self.trajectory_predictor.predict(
                    current_state=current_state,
                    acting_agent=actor_config.name,
                    proposed_action={'task': task.description},
                    other_agents=other_agents,
                        goal=_predict_goal
                    )
                )
                
                # Extract collaboration suggestions
                collaboration_suggestions = self._extract_collaboration_from_prediction(marl_prediction)
                
                # Inject into agent context
                resolved_kwargs['_marl_predictions'] = json.dumps({
                    'predicted_trajectory': {
                        'horizon': marl_prediction.horizon,
                        'steps': [smart_truncate(str(s), max_tokens=50) for s in marl_prediction.steps],
                        'predicted_reward': marl_prediction.predicted_reward,
                        'confidence': marl_prediction.confidence
                    },
                    'collaboration_suggestions': collaboration_suggestions,
                    'timestamp': __import__('time').time()
                }, indent=2)
                
                logger.info(f"🔮 MARL Prediction: confidence={marl_prediction.confidence:.2f}, suggestions={len(collaboration_suggestions)}")
                
                # 🔴 A-TEAM FIX: Accumulate per-agent predictions for Nash bargaining
                if actor_config and actor_config.name:
                    self._agent_predictions[actor_config.name] = marl_prediction
                
            except Exception as e:
                logger.warning(f"⚠️ MARL prediction failed: {e}")
        # =====================================================================
        
        # 🧬 MULTI-BROWSER: Propagate instance_id into resolved_kwargs
        # This ensures each parallel agent thread can set its own browser routing context.
        _instance_id = kwargs.get("instance_id")
        if _instance_id and "instance_id" not in resolved_kwargs:
            resolved_kwargs["instance_id"] = _instance_id

        # 🖼️ Set actor name on thread for screenshot attribution
        try:
            from surface.tools.browser_tools import set_browser_actor_name
            set_browser_actor_name(actor_config.name)
        except ImportError:
            pass
        
        # Execute with enforced timeout (dynamic, generic)
        # 🔥 A-TEAM CRITICAL FIX: Call DSPy modules via forward/aforward!
        # DSPy modules should be called via forward() or aforward() (async generator)
        # Priority: aforward (async generator) > forward (sync) > other methods
        # Note: inspect is already imported at module level, use it directly
        
        # 🔥 NEW: Check for aforward first (async generator version of forward for DSPy modules)
        if hasattr(actor, 'aforward'):
            aforward_method = getattr(actor, 'aforward')
            if inspect.isasyncgenfunction(aforward_method):
                logger.info(f"📡 Calling {actor_config.name}.aforward() (async generator)")
                yield {"module": "Synapse.core.conductor", "message": f"I am calling {actor_config.name}.aforward() method"}
                # Async generator - yield all events and collect final result
                result = None
                async for event in aforward_method(**resolved_kwargs):
                    # 🔴 A-TEAM FIX D1: Tag event with actor name for frontend routing
                    if isinstance(event, dict):
                        event['_actor_name'] = actor_config.name
                        if event.get('module', '').startswith('Synapse.core.synapse_core'):
                            event['module'] = actor_config.name
                    yield event
                    # Extract result from final event
                    if isinstance(event, dict) and event.get("type") == "result":
                        result = event.get("result")
                logger.info(f"✅ {actor_config.name}.aforward() completed")
                yield {"module": "Synapse.core.conductor", "message": f"I have completed calling {actor_config.name}.aforward()"}
                
                # 📺 Broadcast actor output to its dedicated screen
                if result is not None:
                    yield self._build_actor_output_event(actor_config.name, result, task)
                
                # 🖼️ Drain screenshots captured during actor execution → render in agent screen
                for sc_evt in self._drain_and_build_screenshot_events(actor_config.name):
                    yield sc_evt
                
                # 🔥 A-TEAM CRITICAL FIX: Process collaboration actions BEFORE returning!
                # Without this, agents using aforward() would never have their collaboration_actions processed
                if result:
                    collaboration_actions = self._extract_collaboration_actions(result)
                    if collaboration_actions:
                        logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} collaboration actions (from aforward)")
                        yield {"module": "Synapse.core.conductor", "message": f"I am processing {len(collaboration_actions)} collaboration actions from {actor_config.name}"}
                        for action in collaboration_actions:
                            try:
                                async for collab_event in self._process_collaboration_action_stream(
                                    action,
                                    from_actor=actor_config.name,
                                    context=kwargs
                                ):
                                    yield collab_event
                            except Exception as e:
                                logger.error(f"❌ Failed to process collaboration action: {e}")
                
                yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result"}
                return
        
        # 🔴 A-TEAM FIX D1: Check for arun async generator BEFORE _call_actor()
        # SynapseCore uses arun() which is an async generator yielding reasoning/tool events.
        # Previously _call_actor() SWALLOWED all intermediate events — only the final result
        # was extracted, so BrowserExecutor/WebSearchAgent screens never received live events.
        # This block yields all intermediate events AND tags them with the actor name
        # so the frontend can route them to the correct module box.
        if hasattr(actor, 'arun'):
            arun_method = getattr(actor, 'arun')
            if inspect.isasyncgenfunction(arun_method):
                logger.info(f"📡 Calling {actor_config.name}.arun() (async generator — streaming events)")
                yield {"module": actor_config.name, "message": f"Starting execution of {actor_config.name}..."}
                result = None
                async for event in arun_method(**resolved_kwargs):
                    # 🔴 Tag every event with the executing actor's name
                    if isinstance(event, dict):
                        # Preserve original module for debugging, but set _actor_name for routing
                        event['_actor_name'] = actor_config.name
                        # Also override module to actor name for events that use generic synapse_core module
                        if event.get('module', '').startswith('Synapse.core.synapse_core'):
                            event['module'] = actor_config.name
                    yield event
                    if isinstance(event, dict) and event.get("type") == "result":
                        result = event.get("result")
                logger.info(f"✅ {actor_config.name}.arun() completed")
                yield {"module": actor_config.name, "message": f"{actor_config.name} execution completed"}
                
                # 📺 Broadcast actor output to its dedicated screen
                if result is not None:
                    yield self._build_actor_output_event(actor_config.name, result, task)
                
                # 🖼️ Drain screenshots captured during actor execution → render in agent screen
                for sc_evt in self._drain_and_build_screenshot_events(actor_config.name):
                    yield sc_evt
                
                # Process collaboration actions
                if result:
                    collaboration_actions = self._extract_collaboration_actions(result)
                    if collaboration_actions:
                        logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} collaboration actions (from arun)")
                        yield {"module": "Synapse.core.conductor", "message": f"I am processing {len(collaboration_actions)} collaboration actions from {actor_config.name}"}
                        for action in collaboration_actions:
                            try:
                                async for collab_event in self._process_collaboration_action_stream(
                                    action,
                                    from_actor=actor_config.name,
                                    context=kwargs
                                ):
                                    yield collab_event
                            except Exception as e:
                                logger.error(f"❌ Failed to process collaboration action: {e}")
                
                yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result"}
                return
        
        async def _call_actor():
            # inspect is already imported at module level (line 43)
            
            # Check for forward method FIRST (DSPy modules use this)
            if hasattr(actor, 'forward'):
                forward_method = getattr(actor, 'forward')
                logger.info(f"📡 Calling {actor_config.name}.forward()")
                # Check if forward is async or async generator
                if inspect.isasyncgenfunction(forward_method):
                    # Async generator - collect result
                    result = None
                    async for event in forward_method(**resolved_kwargs):
                        if isinstance(event, dict) and event.get("type") == "result":
                            result = event.get("result")
                    return result if result is not None else True
                elif asyncio.iscoroutinefunction(forward_method):
                    return await forward_method(**resolved_kwargs)
                # Forward is sync, run in executor
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(None, lambda: forward_method(**resolved_kwargs))
            
            # Check for async methods (including async generators)
            if hasattr(actor, 'run'):
                run_method = getattr(actor, 'run')
                if inspect.isasyncgenfunction(run_method):
                    # Async generator - collect result from final event
                    result = None
                    async for event in run_method(**resolved_kwargs):
                        if isinstance(event, dict) and event.get("type") == "result":
                            result = event.get("result")
                    return result if result is not None else True
                elif asyncio.iscoroutinefunction(run_method):
                    return await run_method(**resolved_kwargs)
            
            if hasattr(actor, 'arun'):
                arun_method = getattr(actor, 'arun')
                if inspect.isasyncgenfunction(arun_method):
                    # Async generator - collect result from final event
                    result = None
                    async for event in arun_method(**resolved_kwargs):
                        if isinstance(event, dict) and event.get("type") == "result":
                            result = event.get("result")
                    return result if result is not None else True
                elif asyncio.iscoroutinefunction(arun_method):
                    return await arun_method(**resolved_kwargs)
            
            # Check for forward method (BaseSwarmAgent uses this)
            if hasattr(actor, 'forward'):
                forward_method = getattr(actor, 'forward')
                # Check if forward is async or async generator
                if inspect.isasyncgenfunction(forward_method):
                    # Async generator - collect result
                    result = None
                    async for event in forward_method(**resolved_kwargs):
                        if isinstance(event, dict) and event.get("type") == "result":
                            result = event.get("result")
                    return result if result is not None else True
                elif asyncio.iscoroutinefunction(forward_method):
                    return await forward_method(**resolved_kwargs)
                # Forward is sync, run in executor
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(None, lambda: forward_method(**resolved_kwargs))
            
            # Check for __call__ method (DSPy modules)
            if hasattr(actor, '__call__'):
                # ✅ CORRECT: Call actor directly (works for DSPy modules and regular callables)
                if inspect.isasyncgenfunction(actor):
                    # Async generator - collect result
                    result = None
                    async for event in actor(**resolved_kwargs):
                        if isinstance(event, dict) and event.get("type") == "result":
                            result = event.get("result")
                    return result if result is not None else True
                elif asyncio.iscoroutinefunction(actor):
                    return await actor(**resolved_kwargs)
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(None, lambda: actor(**resolved_kwargs))
            
            raise ValueError(f"Actor {actor_config.name} has no callable method (checked: run, arun, forward, __call__)")

        # ⏱️ Hard timeout enforcement - REMOVED
        # LLM has freedom to execute without timeout constraints
        logger.info(f"⏱️ Executing {actor_config.name} (no timeout enforcement)")

        try:
            result = await _call_actor()
            # 📺 Broadcast actor output to its dedicated screen
            if result is not None:
                yield self._build_actor_output_event(actor_config.name, result, task)
            yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result"}
        except Exception as actor_error:
                # =====================================================================
                # 🔍 AUTO ERROR RESEARCH & RETRY (TODO 5)
                # =====================================================================
                import traceback
                logger.error(f"Stack trace:\n{traceback.format_exc()}")
                
                # 🔧 FIX: Build comprehensive error message with type and context
                error_type = type(actor_error).__name__
                error_msg = str(actor_error)
                if not error_msg or len(error_msg.strip()) == 0:
                    error_msg = error_type  # Use type if message is empty
                full_error_msg = f"{error_type}: {error_msg}" if error_msg != error_type else error_type
                
                logger.error(f"❌ Actor {actor_config.name} failed: {full_error_msg}")
                
                # 🔧 Skip auto error research for operational errors (not code bugs)
                SKIP_ERROR_RESEARCH = (
                    'TimeoutError',
                    'asyncio.TimeoutError',
                    'ConnectionError',
                    'ConnectionRefusedError',
                    'ConnectionResetError',
                    'KeyboardInterrupt',
                    'SystemExit',
                    'MemoryError',
                    'ResourceWarning'
                )
                
                should_skip_research = error_type in SKIP_ERROR_RESEARCH
                if should_skip_research:
                    logger.info(f"⏭️ Skipping error research for {error_type} (operational error, not code bug)")
                    raise actor_error
                
                # Try auto error research if web_search tool is available
                if self._task_planner and hasattr(self._task_planner, 'tools') and self._task_planner.tools:
                    web_search_tool = None
                    for tool in self._task_planner.tools:
                        if hasattr(tool, '__name__') and 'web_search' in tool.__name__.lower():
                            web_search_tool = tool
                            break
                    
                    if web_search_tool:
                        try:
                            from .error_solution_extractor import ErrorSolutionExtractor
                            
                            logger.info(f"🔍 Auto error research for: {full_error_msg}")
                            
                            # 🔧 FIX: Build more specific search query with context
                            search_query = f"{error_type} {error_msg} {actor_config.name} python fix"
                            search_results = web_search_tool(search_query)
                            
                            # Extract solutions
                            extractor = ErrorSolutionExtractor()
                            solutions = extractor.extract_solutions(
                                error=full_error_msg,
                                search_results=str(search_results),
                                context={'task': task.description, 'actor': actor_config.name}
                            )
                            
                            if solutions:
                                logger.info(f"✅ Found {len(solutions)} potential solutions")
                                
                                # Store solutions in BOTH shared + local memory
                                for i, solution in enumerate(solutions):
                                    try:
                                        self._store_memory(
                                            content=f"Solution for '{smart_truncate(full_error_msg, max_tokens=50)}': {solution.get('fix', '')}",
                                            level=MemoryLevel.EPISODIC,
                                            context={'actor': actor_config.name, 'type': 'error_solution', 'source': 'auto_research'},
                                            goal=kwargs.get('goal', ''),
                                            actor_name=actor_config.name
                                        )
                                    except Exception as store_error:
                                        logger.warning(f"Failed to store error solution in memory: {store_error}")
                                
                                # RETRY with solution context
                                logger.info(f"🔄 Retrying with error solutions in context")
                                resolved_kwargs['_error_solutions'] = json.dumps(solutions, indent=2)
                                resolved_kwargs['_previous_error'] = full_error_msg
                                
                                # Retry execution (no timeout enforcement)
                                result = await _call_actor()
                                # 📺 Broadcast actor output to its dedicated screen
                                if result is not None:
                                    yield self._build_actor_output_event(actor_config.name, result, task)
                                yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result after retry"}
                                
                                # If retry succeeds, store learning
                                if result and (not hasattr(result, 'success') or result.success):
                                    logger.info(f"✅ Retry succeeded with auto-researched solution!")
                            else:
                                raise actor_error  # Re-raise if no solutions found
                        
                        except Exception as research_error:
                            logger.warning(f"⚠️ Auto error research failed: {research_error}")
                            raise actor_error  # Re-raise original error
                    else:
                        raise actor_error  # Re-raise if no web_search tool
                else:
                    raise actor_error  # Re-raise if no task planner
                # =====================================================================
        else:
            result = await _call_actor()
            # 📺 Broadcast actor output to its dedicated screen
            if result is not None:
                yield self._build_actor_output_event(actor_config.name, result, task)
            yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result"}
        
        # =====================================================================
        # 🔧 A-TEAM v10.0: GENERIC DATA INTERCEPTION (CHUNKER & COMPRESSOR)
        # =====================================================================
        # GENERIC: Process ALL large fields in result, not just specific ones
        if result and hasattr(result, '__dict__'):
            for field_name, field_value in vars(result).items():
                # Skip if not a string or is None/empty
                if not isinstance(field_value, str) or not field_value:
                    continue
                
                # Check if field is large (generic check, no hardcoded field names!)
                estimated_tokens = len(field_value) // 4
                actor_budget = getattr(actor_config, 'max_context_tokens', None) or self.config.max_context_tokens or 16000
                threshold = actor_budget * self.config.chunking_threshold_ratio  # Configurable threshold
                
                if estimated_tokens > threshold:
                    logger.info(f"🔍 Large field detected: '{field_name}' ({estimated_tokens} tokens > {threshold:.0f})")
                    
                    # Infer data type from field name (improved heuristics)
                    data_type = self._infer_field_type(field_name, field_value)
                    
                    # Process the large field
                    try:
                        processed = await self._process_large_data(
                            field_value,
                            actor_config,
                            data_type,
                            task.description
                        )
                        # Update result field with processed data
                        setattr(result, field_name, processed)
                        logger.info(f"✅ Processed large field '{field_name}' ({data_type})")
                    except Exception as e:
                        logger.warning(f"⚠️ Failed to process large field '{field_name}': {e}")
        
        # Compress context if needed before next actor
        context = await self._compress_if_needed(context, actor_config, task.description)
        # =====================================================================
        
        # 🔑 Store output in shared context (UNIFIED STORAGE)
        # 🔴 A-TEAM FIX: Write to BOTH kwargs['_shared_context'] AND self.shared_context
        # so that _build_actor_context (which reads self.shared_context) can find results
        shared_context['actor_outputs'][actor_config.name] = result
        kwargs['_shared_context'] = shared_context
        
        # Also store in self.shared_context (the canonical SharedContext instance)
        if hasattr(self, 'shared_context') and self.shared_context:
            # Store by task_id for dependency-based lookup
            if hasattr(task, 'task_id'):
                self.shared_context.set(f'output_{task.task_id}', result)
            # Store in actor_outputs dict for actor-name-based lookup
            sc_actor_outputs = self.shared_context.get('actor_outputs') or {}
            sc_actor_outputs[actor_config.name] = result
            self.shared_context.set('actor_outputs', sc_actor_outputs)
        
        # =====================================================================
        # 📊 DIVERGENCE LEARNING: Compare prediction with reality (TODO 2)
        # =====================================================================
        if marl_prediction and self.divergence_memory:
            try:
                # Extract actual outcome
                actual_outcome = {
                    'actor': actor_config.name,
                    'success': result.success if hasattr(result, 'success') else True,
                    'output': smart_truncate(str(result), max_tokens=125),  # 🔴 A-TEAM FIX
                    'timestamp': __import__('time').time()
                }
                
                # Compute divergence
                from .predictive_marl import ActualTrajectory
                actual_trajectory = ActualTrajectory(
                    steps=[actual_outcome],
                    actual_reward=1.0 if actual_outcome['success'] else 0.0,
                    timestamp=actual_outcome['timestamp']
                )
                
                divergence = self.trajectory_predictor.compute_divergence(
                    marl_prediction,
                    actual_trajectory
                )
                
                if divergence and divergence.total_divergence() > 0.3:
                    logger.info(f"📊 Divergence detected: {divergence.total_divergence():.2f}")
                    
                    # Update agent model
                    self.trajectory_predictor.update_agent_model(
                        agent_name=actor_config.name,
                        divergence=divergence
                    )
                    
                    # (Brain memory removed — divergence stored via HierarchicalMemory if needed)
                
            except Exception as e:
                logger.warning(f"⚠️ Divergence learning failed: {e}")
        # =====================================================================
        
        # 🤝 NEW: Process collaboration actions from agent output
        collaboration_actions = self._extract_collaboration_actions(result)
        if collaboration_actions:
            logger.info(f"🤝 [{actor_config.name}] Processing {len(collaboration_actions)} collaboration actions")
            for action in collaboration_actions:
                try:
                    async for event in self._process_collaboration_action_stream(
                        action,
                        from_actor=actor_config.name,
                        context=kwargs
                    ):
                        yield event
                except Exception as e:
                    logger.error(f"❌ Failed to process collaboration action: {e}")
        
        # 🔥 A-TEAM: RETRY LOGIC FOR EMPTY EPISODES
        # If actor failed or returned None, attempt intelligent recovery and retry
        if (hasattr(result, 'success') and not result.success) or \
           (hasattr(result, 'output') and result.output is None):
            logger.warning(f"⚠️ [{actor_config.name}] Failed or returned None - attempting intelligent recovery")
            
            # Extract missing parameters from error or signature
            missing_params = []
            
            # Check if result has error message with missing params (LLM-based)
            if hasattr(result, 'error') and result.error:
                signature = self.actor_signatures.get(actor_config.name, {})
                llm_missing = await self._extract_missing_params_llm(
                    error_message=str(result.error),
                    signature=signature,
                    provided_params=resolved_kwargs
                )
                for param in llm_missing:
                    if param and param not in missing_params:
                        missing_params.append(param)
            
            # Check signature for required params not in resolved_kwargs
            if actor_config.name in self.actor_signatures:
                sig = self.actor_signatures[actor_config.name]
                if isinstance(sig, dict):
                    for param_name, param_info in sig.items():
                        if param_info.get('required') and param_name not in resolved_kwargs:
                            if param_name not in missing_params:
                                missing_params.append(param_name)
            
            if missing_params:
                logger.info(f"🔄 [RETRY] Attempting recovery for {len(missing_params)} missing params: {missing_params}")
                
                # Use intelligent recovery with routing
                recovered = await self._intelligent_recovery_with_routing(
                    actor_config,
                    missing_params,
                    {'goal': kwargs.get('goal', kwargs.get('query', '')), 'kwargs': kwargs}
                )
                
                if recovered:
                    logger.info(f"✅ [RETRY] Recovered {len(recovered)} parameters")
                    
                    # 🔥 A-TEAM: BUILD RETRY CONTEXT + REASON for agent agency!
                    retry_context = f"""
🔄 RETRY ATTEMPT - You are being re-executed with additional context and data.

📋 REASON FOR RETRY:
- Previous execution failed or returned None
- Missing parameters were identified: {', '.join(missing_params)}

✅ WHAT WE DID TO FIX IT:
- Recovered {len(recovered)} parameter(s) from dependency graph and data sources
- Parameters now available: {', '.join(recovered.keys())}

📊 RECOVERED DATA:
"""
                    for param, value in recovered.items():
                        value_preview = str(value)[:100] if value else "None"
                        retry_context += f"- {param}: {type(value).__name__} = {value_preview}\n"
                    
                    retry_context += f"""
🎯 WHAT YOU SHOULD DO NOW:
- Use the newly provided parameters: {', '.join(recovered.keys())}
- Re-analyze the query with complete context
- Generate output based on ALL available data
- Previous attempt lacked: {', '.join(missing_params)}

💡 ADDITIONAL GUIDANCE:
- All required data is now available
- Focus on producing valid, complete output
- If you still encounter issues, clearly state what's missing
"""
                    
                    # Inject retry context into actor's context
                    if 'retry_context' not in resolved_kwargs:
                        resolved_kwargs['retry_context'] = retry_context
                    
                    # Update resolved_kwargs with recovered data
                    resolved_kwargs.update(recovered)
                    
                    # Log the retry context for debugging
                    logger.info(f"📝 [RETRY CONTEXT]:\n{retry_context}")
                    
                    # RETRY actor execution WITH CONTEXT
                    logger.info(f"🔄 [RETRY] Re-executing {actor_config.name} with context + recovered data...")
                    
                    try:
                        if asyncio.iscoroutinefunction(getattr(actor, 'run', None)):
                            result = await actor.run(**resolved_kwargs)
                        elif asyncio.iscoroutinefunction(getattr(actor, 'arun', None)):
                            result = await actor.arun(**resolved_kwargs)
                        elif hasattr(actor, '__call__'):
                            if asyncio.iscoroutinefunction(actor):
                                result = await actor(**resolved_kwargs)
                            else:
                                loop = asyncio.get_event_loop()
                                result = await loop.run_in_executor(None, lambda: actor(**resolved_kwargs))
                        
                        # Update shared context with retry result (UNIFIED STORAGE)
                        shared_context['actor_outputs'][actor_config.name] = result
                        kwargs['_shared_context'] = shared_context
                        
                        # Also store in self.shared_context for unified access
                        if hasattr(self, 'shared_context') and self.shared_context:
                            if hasattr(task, 'task_id'):
                                self.shared_context.set(f'output_{task.task_id}', result)
                            sc_outputs = self.shared_context.get('actor_outputs') or {}
                            sc_outputs[actor_config.name] = result
                            self.shared_context.set('actor_outputs', sc_outputs)
                        
                        if hasattr(result, 'success') and result.success:
                            logger.info(f"✅ [RETRY] Retry successful for {actor_config.name}")
                        else:
                            logger.warning(f"⚠️ [RETRY] Retry failed for {actor_config.name}")
                    
                    except Exception as e:
                        logger.error(f"❌ [RETRY] Retry execution failed: {e}")
                        import traceback
                        logger.error(f"Traceback: {traceback.format_exc()}")
                else:
                    logger.warning(f"⚠️ [RETRY] Could not recover any parameters")
            else:
                logger.warning(f"⚠️ [RETRY] No missing parameters identified for recovery")
        
        # ✅ A-TEAM: Register output in IOManager (typed outputs!)
        # 🔥 CRITICAL FIX: Extract the ACTUAL output (DSPy Prediction) from EpisodeResult wrapper!
        try:
            # 🔍 A-TEAM DEBUG: Log EVERYTHING about the result
            logger.info(f"🔍 [IOManager PREP] result type: {type(result)}")
            logger.info(f"🔍 [IOManager PREP] result has 'output': {hasattr(result, 'output')}")
            if hasattr(result, 'output'):
                logger.info(f"🔍 [IOManager PREP] result.output type: {type(result.output)}")
                logger.info(f"🔍 [IOManager PREP] result.output is None: {result.output is None}")
                if result.output and hasattr(result.output, '_store'):
                    logger.info(f"🔍 [IOManager PREP] result.output has _store with keys: {list(result.output._store.keys())}")
            if hasattr(result, 'success'):
                logger.info(f"🔍 [IOManager PREP] result.success: {result.success}")
            
            actual_output = result.output if hasattr(result, 'output') else result
            logger.info(f"🔍 [IOManager PREP] actual_output type: {type(actual_output)}")
            logger.info(f"🔍 [IOManager PREP] actual_output is None: {actual_output is None}")
            
            # 🆕 A-TEAM: Extract tagged attempts from trajectory (if available)
            tagged_attempts = []
            if hasattr(result, 'trajectory') and isinstance(result.trajectory, list):
                # Get the last trajectory entry (actor execution)
                for traj_entry in reversed(result.trajectory):
                    if isinstance(traj_entry, dict) and traj_entry.get('step') == 'actor':
                        tagged_attempts = traj_entry.get('tagged_attempts', [])
                        if tagged_attempts:
                            logger.info(f"🏷️  Retrieved {len(tagged_attempts)} tagged attempts from trajectory")
                            break
            
            self.io_manager.register_output(
                actor_name=actor_config.name,
                output=actual_output,  # ← FIXED! Pass the actual DSPy Prediction, not EpisodeResult!
                actor=actor,  # ✅ Pass actor for signature extraction!
                success=result.success if hasattr(result, 'success') else True,
                tagged_attempts=tagged_attempts  # 🆕 Pass tagged attempts!
            )
            logger.info(f"📦 Registered '{actor_config.name}' output in IOManager with {len(tagged_attempts)} tagged attempts")
        except Exception as e:
            logger.warning(f"⚠️  IOManager registration failed for '{actor_config.name}': {e}")
            import traceback as tb
            logger.warning(f"⚠️  Full traceback: {tb.format_exc()}")
        
        # =================================================================
        # 🎯 Q-LEARNING UPDATE: Natural Language Q-Table
        # =================================================================
        if hasattr(self, 'q_learner') and self.q_learner:
            try:
                # 🔴 A-TEAM FIX q8: Use rich _get_current_state() instead of generic dict
                # The old state was just {goal, actor, completed, attempts} — no semantic context.
                # _get_current_state() captures subtask desc, memory, tool usage, error patterns etc.
                state = self._get_current_state(current_subtask=task)
                # Supplement with execution-specific details
                state["executing_actor"] = actor_config.name
                state["tagged_attempts_count"] = len(tagged_attempts)
                
                # 🔴 A-TEAM FIX: Enrich legacy action dict with full task context
                # (mirrors the rich action dict from the main task execution path ~line 4562)
                action = {
                    "actor": actor_config.name,
                    "task": task.description,
                    "task_id": task.task_id,
                    "priority": getattr(task, 'priority', 0.5),
                    "attempts": getattr(task, 'attempts', 0),
                    "max_attempts": getattr(task, 'max_attempts', 3),
                }
                if hasattr(task, 'failure_reasons') and task.failure_reasons:
                    action['previous_failures'] = task.failure_reasons[-3:]
                if hasattr(task, 'retry_feedback') and task.retry_feedback:
                    action['retry_feedback'] = [
                        fb.get('feedback', '') if isinstance(fb, dict) else str(fb)
                        for fb in task.retry_feedback[-2:]
                    ]
                if hasattr(task, 'depends_on') and task.depends_on:
                    action['dependencies'] = task.depends_on
                
                next_state = self._get_current_state(current_subtask=task)
                completed_actors = list(self.io_manager.outputs.keys()) if hasattr(self, 'io_manager') and self.io_manager else []
                next_state["completed"] = completed_actors + [actor_config.name]
                
                # 🔴 A-TEAM FIX D2: Use nuanced reward from UnifiedRewardCalculator
                # instead of binary 0/1. This prevents the Q-table death spiral
                # where all auditor-failed tasks get reward=0 → penalty → Q→0.
                auditor_success = all(r.is_valid for r in result.auditor_results) if hasattr(result, 'auditor_results') and result.auditor_results else True
                
                if hasattr(self, 'reward_calculator') and self.reward_calculator:
                    try:
                        # Build minimal auditor results dict for the calculator
                        _aud_confidence = 0.5
                        _aud_reward_val = 1.0 if auditor_success else 0.0
                        if hasattr(result, 'auditor_results') and result.auditor_results:
                            _aud_confidence = max(
                                (getattr(r, 'confidence', 0.5) for r in result.auditor_results),
                                default=0.5
                            )
                            # Use average auditor reward instead of binary
                            _rewards = [getattr(r, 'reward', 0.0) for r in result.auditor_results if hasattr(r, 'reward')]
                            if _rewards:
                                _aud_reward_val = sum(_rewards) / len(_rewards)
                        
                        _q_aud_results = {
                            'reward': _aud_reward_val,
                            'confidence': _aud_confidence,
                            'reasoning': '',
                            'method': 'q_learning_inline',
                            'test_breakdown': []
                        }
                        _q_breakdown = self.reward_calculator.compute_subtask_reward(
                            task=task,
                            auditor_results=_q_aud_results,
                            context={'todo': self.todo}
                        )
                        reward = _q_breakdown.total
                        logger.debug(f"🎯 Q-Learning nuanced reward={reward:.3f} (quality={_q_breakdown.quality:.3f})")
                    except Exception as _rew_err:
                        logger.debug(f"Q-reward calc fallback to binary: {_rew_err}")
                        reward = 1.0 if auditor_success else 0.0
                else:
                    reward = 1.0 if auditor_success else 0.0
                
                # Check if terminal (all actors done)
                is_terminal = len(next_state["completed"]) == len(self.actors)
                
                # Add experience (this updates Q-table AND stores in buffer)
                # Use async updater when available to avoid blocking LLM call
                _legacy_exp = dict(state=state, action=action, reward=reward,
                                   next_state=next_state, done=is_terminal)
                if self.async_q_updater:
                    await self.async_q_updater.queue_experience(**_legacy_exp)
                else:
                    self.q_learner.add_experience(**_legacy_exp)
                
                logger.debug(f"🎯 Q-Learning updated: {actor_config.name} reward={reward:.2f}, terminal={is_terminal}")
                
                # Get learned context for injection into actor prompts
                learned_context = self.q_learner.get_learned_context(state, action)
                if learned_context:
                    logger.debug(f"📚 Learned context ({len(learned_context)} chars):")
                    logger.debug(learned_context[:200] + "..." if len(learned_context) > 200 else learned_context)
                
            except Exception as e:
                logger.warning(f"⚠️  Q-Learning update failed: {e}")
        
        # =================================================================
        # 📊 TD(λ) LEARNING UPDATE: Temporal Difference with Eligibility Traces
        # =================================================================
        # 🔥 FIX: TD(λ) updates happen at episode end via end_episode(), not per-actor.
        # The TDLambdaLearner doesn't have an update() method - it uses:
        # - record_access() during execution  
        # - end_episode() at terminal state
        # This per-actor update was incorrect - TD(λ) is called in run() at episode end.
        
        # 🔍 DEBUG: Log after storage
        logger.info(f"🔍 DEBUG: Stored output for '{actor_config.name}'")
        logger.info(f"🔍 DEBUG: Updated actor_outputs: {list(shared_context['actor_outputs'].keys())}")
        logger.info(f"🔍 DEBUG: Output type: {type(result)}")
        if hasattr(result, '__dict__'):
            logger.info(f"🔍 DEBUG: Output fields: {list(vars(result).keys())[:10]}")
        
        # 🔑 NEW: Register output in Data Registry (AGENTIC DISCOVERY)
        if self.data_registry and self.registration_orchestrator:
            # 🎯 A-TEAM FIX: Use await (not asyncio.run) since we're in async function
            logger.info("🎯 REGISTERING OUTPUT - START")
            logger.info(f"  Actor: {actor_config.name}")
            logger.info(f"  Output type: {type(result).__name__}")
            logger.info(f"  Registry: {self.data_registry is not None}")
            logger.info(f"  Orchestrator: {self.registration_orchestrator is not None}")
            
            registration_context = {
                'task': self.todo.root_task if hasattr(self.todo, 'root_task') else None,
                'goal': kwargs.get('goal', ''),
                'iteration': len(self.trajectory),
                'actor_config': actor_config
            }
            
            try:
                # ✅ A-TEAM: Use await (we're already in async function!)
                artifact_ids = await self.registration_orchestrator.register_output(
                    actor_name=actor_config.name,
                    output=result,
                    context=registration_context
                )
                logger.info("🎯 REGISTERING OUTPUT - COMPLETE")
                logger.info(f"  Artifacts registered: {len(artifact_ids)}")
                logger.info(f"  Artifact IDs: {artifact_ids}")
            except Exception as e:
                logger.error(f"❌ Agentic registration failed: {e}")
                logger.error(f"   Actor: {actor_config.name}")
                logger.error(f"   Output type: {type(result)}")
                raise RuntimeError(
                    f"Agentic registration failed for {actor_config.name}. "
                    f"This is a critical error - fix the registration logic or actor output!"
                ) from e
        
        yield {"type": "result", "result": _to_lightweight_result(result, actor_config.name, task.task_id), "module": "Synapse.core.conductor", "message": "I am returning the actor execution result"}
        return
    
    def _calculate_episode_reward(
        self,
        success: bool,
        cumulative_reward: float,
        target_reward: float,
        iterations: int,
        max_iterations: int
    ) -> float:
        """
        Calculate final episode reward for TD(λ) learning.
        
        🔥 A-TEAM FIX: Provides a comprehensive reward signal that captures:
        - Task success (binary component)
        - Quality of execution (cumulative reward)
        - Efficiency (iterations used vs max)
        
        Args:
            success: Whether the goal was achieved
            cumulative_reward: Sum of all intermediate rewards
            target_reward: Target reward threshold
            iterations: Number of iterations used
            max_iterations: Maximum allowed iterations
        
        Returns:
            Float reward in [0, 1] range
        """
        # Component 1: Success bonus (0.4 weight)
        success_component = 0.4 if success else 0.0
        
        # Component 2: Quality (0.4 weight) - normalized cumulative reward
        quality_component = 0.4 * min(1.0, cumulative_reward / max(target_reward, 0.1))
        
        # Component 3: Efficiency (0.2 weight) - penalize excessive iterations
        if iterations > 0:
            efficiency = 1.0 - (iterations / max_iterations)
            efficiency_component = 0.2 * max(0.0, efficiency)
        else:
            efficiency_component = 0.2  # Perfect efficiency if solved immediately
        
        # Total episode reward
        episode_reward = success_component + quality_component + efficiency_component
        
        # Clamp to [0, 1]
        episode_reward = max(0.0, min(1.0, episode_reward))
        
        logger.debug(f"📊 Episode reward breakdown: "
                    f"success={success_component:.3f}, "
                    f"quality={quality_component:.3f}, "
                    f"efficiency={efficiency_component:.3f}, "
                    f"total={episode_reward:.3f}")
        
        return episode_reward
    
    def _detect_output_type(self, output: Any) -> str:
        """Auto-detect output type."""
        if hasattr(output, 'to_dict'):  # DataFrame
            return 'dataframe'
        elif isinstance(output, str):
            if len(output) > 100:
                if '<html' in output[:100].lower():
                    return 'html'
                elif '#' in output[:100]:
                    return 'markdown'
            return 'text'
        elif isinstance(output, bytes):
            return 'binary'
        elif isinstance(output, dict):
            return 'json'
        elif hasattr(output, 'output'):  # EpisodeResult
            return 'episode_result'
        elif hasattr(output, '__dict__'):
            return 'prediction'
        return 'unknown'
    
    def _extract_schema(self, output: Any) -> Dict[str, str]:
        """Extract schema from output."""
        schema = {}
        
        # Handle EpisodeResult
        if hasattr(output, 'output') and hasattr(output, 'success'):
            if output.output is not None:
                return self._extract_schema(output.output)
            return {}
        
        if hasattr(output, '__dict__'):
            for field_name, field_value in vars(output).items():
                if not field_name.startswith('_'):
                    schema[field_name] = type(field_value).__name__
        
        elif isinstance(output, dict):
            for key, value in output.items():
                schema[key] = type(value).__name__
        
        elif hasattr(output, 'columns'):  # DataFrame
            schema = {col: 'column' for col in output.columns}
        
        return schema
    
    def _generate_preview(self, output: Any) -> str:
        """Generate preview of output."""
        try:
            if isinstance(output, str):
                return output[:200]
            elif hasattr(output, '__str__'):
                return str(output)[:200]
            elif hasattr(output, 'head'):  # DataFrame
                return str(output.head(3))[:200]
            return f"<{type(output).__name__}>"
        except Exception:
            return "<preview unavailable>"
    
    def _generate_tags(self, actor_name: str, output: Any, output_type: str) -> List[str]:
        """Generate semantic tags for output."""
        tags = [output_type, actor_name.lower()]
        
        # Handle EpisodeResult
        if hasattr(output, 'output') and hasattr(output, 'success'):
            if output.output is not None:
                return self._generate_tags(actor_name, output.output, output_type)
            return tags
        
        # Add field names as tags
        if hasattr(output, '__dict__'):
            field_names = [f for f in vars(output).keys() if not f.startswith('_')]
            tags.extend(field_names[:5])  # Top 5 fields
        
        elif isinstance(output, dict):
            tags.extend(list(output.keys())[:5])
        
        return tags
    
    def _register_output_in_registry(self, actor_name: str, output: Any):
        """Register output in Data Registry."""
        try:
            # Detect type
            output_type = self._detect_output_type(output)
            
            # Extract schema
            schema = self._extract_schema(output)
            
            # Generate tags
            tags = self._generate_tags(actor_name, output, output_type)
            
            # Generate preview
            preview = self._generate_preview(output)
            
            # Calculate size
            try:
                size = len(str(output))
            except Exception:
                size = 0
            
            # Create artifact
            artifact = DataArtifact(
                id=f"{actor_name}_{int(time.time() * 1000)}",
                name=actor_name,
                source_actor=actor_name,
                data=output,
                data_type=output_type,
                schema=schema,
                tags=tags,
                description=f"Output from {actor_name}",
                timestamp=time.time(),
                depends_on=[],
                size=size,
                preview=preview
            )
            
            # Register
            self.data_registry.register(artifact)
            
        except Exception as e:
            logger.warning(f"⚠️  Failed to register output in registry: {e}")
    
    def _register_output_in_registry_fallback(self, actor_name: str, output: Any):
        """
        DEPRECATED: Fallback registration removed - use semantic registration only!
        
        This method is kept for backwards compatibility but will raise an error.
        All registration MUST go through the agentic RegistrationOrchestrator.
        """
        raise RuntimeError(
            f"❌ Fallback registration called for {actor_name}! "
            f"This is not allowed - use RegistrationOrchestrator for semantic registration."
        )
    
    def _should_inject_registry_tool(self, actor_name: str) -> bool:
        """Check if actor signature requests data_registry."""
        signature = self.actor_signatures.get(actor_name, {})
        return 'data_registry' in signature
    
    async def _run_auditor_stream(
        self,
        actor_config: ActorConfig,
        result: Any,
        task: TodoItem
    ):
        """
        Run Auditor for actor result using LLM as judge with parallel test generation.
        Yields events for UI display.
        
        🎯 USER REQUIREMENT: Use LLM to define ALL things to check, execute in parallel
        
        Incorporates:
        - LLM generates test cases dynamically (no hardcoded checklists)
        - Tests execute in parallel (asyncio.gather)
        - Probabilistic assessment (not binary)
        - Intelligent failure routing
        
        Yields:
            Events for UI, final event has type="auditor_result"
        """
        # 🎯 USER FIX: Use ParallelTestGenerator for LLM-based test generation
        try:
            # Extract task info for test generation
            # 🎯 CRITICAL: Extract CORE instruction without environment wrapping
            task_description = task.description if hasattr(task, 'description') else str(task)
            
            # Strip environment context if present (format: "Instruction\n<instruction>\n\nCurrent State\n<env>")
            if "Current State" in task_description:
                # Extract just the instruction part
                parts = task_description.split("Current State", 1)
                core_instruction = parts[0].replace("Instruction\n", "").strip()
                logger.debug(f"🎯 Extracted core instruction from wrapped task (stripped {len(task_description) - len(core_instruction)} chars)")
                task_description = core_instruction
            
            expected_output = getattr(task, 'expected_output', "Task completion")
            domain = getattr(task, 'domain', "general")
            
            logger.info(f"🧪 Generating and running tests in parallel for task: {task.task_id}")
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"Generating tests for task: {task.task_id}"}
            logger.debug(f"   Task description length: {len(task_description)} chars")
            
            # 🔍 DEBUG: Log result structure
            logger.debug(f"   Result type: {type(result).__name__}")
            if hasattr(result, 'trajectory'):
                traj_len = len(result.trajectory) if isinstance(result.trajectory, list) else 'N/A'
                logger.debug(f"   Result.trajectory length: {traj_len}")
                if isinstance(result.trajectory, list) and result.trajectory:
                    logger.debug(f"   Last trajectory step keys: {list(result.trajectory[-1].keys()) if isinstance(result.trajectory[-1], dict) else 'N/A'}")
            if hasattr(result, 'output'):
                logger.debug(f"   Result.output type: {type(result.output).__name__}")
                if hasattr(result.output, 'rationale'):
                    logger.debug(f"   Result.output.rationale: {str(result.output.rationale)[:100]}")
            
            # Generate and execute tests in parallel (LLM as judge!) — stream to yield each test condition and full report
            test_results = None
            async for event in self.test_generator.generate_and_run_stream(
                task_description=task_description,
                expected_output=expected_output,
                domain=domain,
                actual_result=result
            ):
                if event.get("type") == "result":
                    test_results = event.get("result")
                else:
                    yield event
            if test_results is None:
                test_results = {"results": [], "total_tests": 0, "passed": 0, "failed": 0}
            
            num_tests = len(test_results.get('results', []))
            
            # 🎯 A-TEAM FIX: Use HybridTestAggregator instead of naive 60/40 split!
            # Use aggregate_stream since we're in an async context
            yield {"module": "Synapse.core.test_aggregation", "message": f"Aggregating {num_tests} test results..."}
            aggregated = None
            async for event in self.test_aggregator.aggregate_stream(
                test_results=test_results['results'],
                task_description=task_description,
                task_type=domain
            ):
                # Yield aggregation events if needed
                if isinstance(event, dict) and event.get("type") == "result":
                    aggregated = event.get("result")
            
            # Fallback if no result was yielded
            if aggregated is None:
                # Use bootstrap as fallback
                from Synapse.core.test_aggregation import bootstrap_aggregate
                aggregated = bootstrap_aggregate(test_results['results'])
            
            # Extract aggregated results
            reward = aggregated.reward
            confidence = aggregated.confidence
            aggregation_method = aggregated.method
            
            # Detailed feedback with aggregation details
            total_tests = len(test_results['results'])
            passed_tests = sum(1 for r in test_results['results'] if r.get('passed', False))
            failed_tests = [r for r in test_results['results'] if not r.get('passed', False)]
            
            # 🎯 LOG FAILED TESTS (with LLM reasoning!)
            if failed_tests:
                logger.warning(f"❌ {len(failed_tests)}/{total_tests} tests failed for task {task.task_id}")
                yield {"module": "Synapse.core.parallel_test_generator", "message": f"❌ {len(failed_tests)}/{total_tests} tests failed"}
                for i, ft in enumerate(failed_tests, 1):
                    test_name = ft.get('name', 'Unknown')
                    expected = ft.get('expected_output', 'N/A')
                    actual = ft.get('actual_result', 'N/A')
                    reasoning = ft.get('reasoning', 'No reasoning provided')
                    error = ft.get('error', '')
                    priority = ft.get('priority', 'unknown')
                    
                    logger.warning(f"   Test {i}: {test_name} (priority={priority})")
                    logger.warning(f"      Expected: {expected[:100]}")
                    logger.warning(f"      Actual: {actual[:100]}")
                    logger.warning(f"      LLM Reasoning: {reasoning[:200]}")
                    if error:
                        logger.warning(f"      Error: {error[:150]}")
                    # Yield each failed test
                    yield {"module": "Synapse.core.parallel_test_generator", "message": f"  ❌ {test_name}: {reasoning[:100]}"}
            else:
                logger.info(f"✅ All {total_tests} tests passed for task {task.task_id}")
                yield {"module": "Synapse.core.parallel_test_generator", "message": f"✅ All {total_tests} tests passed"}
                # Log passing test details too
                for i, pt in enumerate(test_results['results'][:3], 1):  # First 3
                    if pt.get('passed', False):
                        logger.info(f"   ✅ Test {i}: {pt.get('name', 'Unknown')}")
                        logger.info(f"      LLM Reasoning: {pt.get('reasoning', 'N/A')[:150]}")
            
            # Full report: every test with condition and pass/fail, then summary
            pct = (100 * passed_tests / total_tests) if total_tests else 0
            feedback_parts = [
                f"Test aggregation report: {passed_tests}/{total_tests} passed ({pct:.0f}%)",
                f"Aggregation: {aggregation_method} — reward={reward:.3f}, confidence={confidence:.2%}",
                f"Reasoning: {aggregated.reasoning}",
                "",
                "Test results:",
            ]
            for i, r in enumerate(test_results['results'], 1):
                status = "PASSED" if r.get('passed', False) else "FAILED"
                cond = r.get('expected_output') or r.get('name', f'Test {i}')
                reason = (r.get('reasoning') or r.get('error') or 'N/A')[:150]
                feedback_parts.append(f"  Test {i} ({status}): {cond}")
                feedback_parts.append(f"    Reasoning: {reason}")
            feedback_parts.append("")
            feedback_parts.append(f"Summary: {passed_tests}/{total_tests} passed ({pct:.0f}%), reward={reward:.3f}, confidence={confidence:.2%}")
            
            feedback = "\n".join(feedback_parts)
            
            # Pass if reward > threshold and confidence is high
            passed = (reward >= 0.7) and (confidence >= 0.6)
            
            logger.info(f"✅ Auditor complete: passed={passed}, reward={reward:.3f}, confidence={confidence:.2%}")
            yield {"module": "Synapse.core.test_aggregation", "message": feedback}
            
            # 🎯 A-TEAM: Generate strategy using compound logical reasoning
            strategy = await self._generate_auditor_strategy(
                passed=passed,
                reward=reward,
                confidence=confidence,
                feedback=feedback,
                test_results=test_results,
                task=task,
                actor_config=actor_config,
                aggregated=aggregated if 'aggregated' in locals() else None
            )
            
            # Yield final result with strategy
            yield {
                "type": "auditor_result",
                "passed": passed,
                "reward": reward,
                "confidence": confidence,
                "feedback": feedback,
                "strategy": strategy
            }
            
        except Exception as e:
            logger.error(f"❌ Parallel test generation failed: {e}")
            logger.debug(f"Traceback: {traceback.format_exc()}")
            yield {"module": "Synapse.core.parallel_test_generator", "message": f"❌ Test generation failed: {str(e)[:100]}"}
            
            # 🔴 A-TEAM FIX: No blind fallback pass. When test generation fails,
            # use LLM-based assessment of the result instead of assuming success.
            # This prevents false positives from bypassing the auditor entirely.
            try:
                from Synapse.signatures.auditor_strategy_signatures import AuditorStrategySignature
                _fallback_assessor = dspy.ChainOfThought(AuditorStrategySignature)
                _result_summary = smart_truncate(str(result), max_tokens=500) if result else "No result available"
                _assessment = await asyncio.to_thread(
                    _fallback_assessor.forward,
                    test_results=f"Test generation failed: {str(e)[:200]}. Raw result: {_result_summary}",
                    task_description=str(task.description)[:300] if hasattr(task, 'description') else "Unknown task",
                    actor_assigned=str(task.actor) if hasattr(task, 'actor') else "Unknown",
                    failure_analysis=f"Auditor pipeline error: {str(e)[:300]}",
                    available_actors=", ".join(self.actors.keys()) if hasattr(self, 'actors') else "",
                    attempt_count=str(getattr(task, 'attempts', 1)),
                    task_context="Test generation exception occurred — LLM assessment needed",
                    time_advisory_context="",
                    reward="0.0",
                    confidence="0.5"
                )
                _llm_passed = str(getattr(_assessment, 'action', 'retry')).strip().lower() in ('pass', 'pass_partial')
                _llm_confidence = 0.5
                try:
                    _llm_confidence = float(getattr(_assessment, 'action_confidence', 0.5))
                except (ValueError, TypeError):
                    pass
                _llm_feedback = str(getattr(_assessment, 'reasoning', f'LLM assessment after test gen failure: {e}'))
                yield {
                    "type": "auditor_result",
                    "passed": _llm_passed,
                    "reward": _llm_confidence * 0.8 if _llm_passed else 0.0,
                    "feedback": _llm_feedback
                }
            except Exception as _assess_err:
                logger.error(f"❌ LLM fallback assessment also failed: {_assess_err}")
                # Only now mark as fail with no fallback
                yield {
                    "type": "auditor_result",
                    "passed": False,
                    "reward": 0.0,
                    "feedback": f"Both test generation and LLM assessment failed: {str(e)[:150]} / {str(_assess_err)[:150]}"
                }
    
    async def _generate_auditor_strategy(
        self,
        passed: bool,
        reward: float,
        confidence: float,
        feedback: str,
        test_results: Dict[str, Any],
        task: SubtaskState,
        actor_config: ActorConfig,
        aggregated: Any = None
    ) -> Dict[str, Any]:
        """
        🎯 A-TEAM: Generate strategy using compound logical reasoning.
        
        Uses LLM-based reasoning to decide:
        - pass: Task passed
        - pass_partial: Task is materially complete with explicit unresolved gaps
        - retry: Recoverable failure
        - stop: Permanent failure
        - re_evaluate: Wrong actor/breakdown
        
        NO hardcoded thresholds - all decisions through reasoning.
        """
        if not DSPY_AVAILABLE:
            raise RuntimeError("DSPY is required for auditor strategy generation")
        
        try:
            from Synapse.signatures import AuditorStrategySignature
            
            # Prepare test results summary
            test_results_summary = {
                "passed": sum(1 for r in test_results.get('results', []) if r.get('passed', False)),
                "failed": sum(1 for r in test_results.get('results', []) if not r.get('passed', False)),
                "total": len(test_results.get('results', [])),
                "results": test_results.get('results', [])[:5],  # First 5 for context
                "patterns": self._extract_failure_patterns(test_results.get('results', []))
            }
            
            # Get actor capabilities
            actor_capabilities = actor_config.capabilities or []
            if not actor_capabilities and actor_config.metadata:
                actor_capabilities = actor_config.metadata.get('capabilities', [])
            
            actor_info = {
                "name": actor_config.name,
                "capabilities": actor_capabilities,
                "description": getattr(actor_config, 'description', '')
            }
            
            # Get available actors
            available_actors = []
            for name, config in self.actors.items():
                if config.enabled and name != actor_config.name:
                    caps = config.capabilities or []
                    if not caps and config.metadata:
                        caps = config.metadata.get('capabilities', [])
                    available_actors.append({
                        "name": name,
                        "capabilities": caps,
                        "description": self._get_agent_description(name, config)
                    })
            
            # Analyze failure
            failure_analysis = self._analyze_failure(
                passed=passed,
                test_results=test_results.get('results', []),
                feedback=feedback,
                aggregated=aggregated
            )
            
            # Prepare task context
            task_context = {
                "dependencies": task.depends_on,
                "attempts": task.attempts,
                "max_attempts": task.max_attempts,
                "priority": task.priority,
                "status": task.status.value if hasattr(task.status, 'value') else str(task.status)
            }
            # Advisory-only timing context (no timeout enforcement, no hard control logic).
            started_at = getattr(task, "started_at", None)
            elapsed_seconds = None
            try:
                if isinstance(started_at, (int, float)):
                    elapsed_seconds = max(0.0, time.time() - float(started_at))
                elif hasattr(started_at, "timestamp"):
                    elapsed_seconds = max(0.0, time.time() - float(started_at.timestamp()))
            except Exception:
                elapsed_seconds = None
            time_advisory_context = {
                "elapsed_seconds": elapsed_seconds,
                "attempt_count": task.attempts,
                "max_attempts": task.max_attempts,
                "avg_seconds_per_attempt": (
                    (elapsed_seconds / max(1, task.attempts)) if elapsed_seconds is not None else None
                ),
                "note": "Advisory signal only; never enforce timeout-based stopping."
            }
            
            # Generate strategy using LLM.
            class _AsyncStrategyAgent:
                def __init__(self, module):
                    self._module = module

                async def aforward(self, **kw):
                    if hasattr(self._module, "aforward"):
                        return await self._module.aforward(**kw)
                    return await asyncio.to_thread(self._module.forward, **kw)

            strategy_agent = _AsyncStrategyAgent(dspy.ChainOfThought(AuditorStrategySignature))
            result = await strategy_agent.aforward(
                test_results=json.dumps(test_results_summary, default=str),
                task_description=task.description,
                actor_assigned=json.dumps(actor_info, default=str),
                failure_analysis=failure_analysis,
                available_actors=json.dumps(available_actors, default=str),
                attempt_count=str(task.attempts),
                task_context=json.dumps(task_context, default=str),
                time_advisory_context=json.dumps(time_advisory_context, default=str),
                reward=str(reward),
                confidence=str(confidence)
            )
            
            # Parse execution guidance JSON
            execution_guidance = {}
            try:
                if result.execution_guidance:
                    execution_guidance = json.loads(result.execution_guidance)
            except (json.JSONDecodeError, AttributeError):
                execution_guidance = {}
            
            # Normalize action
            action = result.action.lower().strip() if hasattr(result, 'action') else ("pass" if passed else "retry")
            if action not in ["pass", "pass_partial", "retry", "stop", "re_evaluate"]:
                # Fallback logic
                if passed:
                    action = "pass"
                elif task.attempts >= task.max_attempts:
                    action = "stop"
                else:
                    action = "retry"
            
            # Get confidence
            action_confidence = float(result.action_confidence) if hasattr(result, 'action_confidence') else confidence

            # Parse decision metrics for expected-utility selection.
            decision_metrics = {}
            try:
                if hasattr(result, "decision_metrics") and result.decision_metrics:
                    decision_metrics = json.loads(result.decision_metrics)
            except Exception:
                decision_metrics = {}
            if not isinstance(decision_metrics, dict):
                decision_metrics = {}
            if isinstance(execution_guidance, dict) and isinstance(execution_guidance.get("decision_metrics"), dict):
                decision_metrics = {**decision_metrics, **execution_guidance.get("decision_metrics")}

            utility_scores, utility_action = self._compute_strategy_utilities(
                task=task,
                actor_name=actor_config.name,
                reward=reward,
                confidence=action_confidence,
                execution_guidance=execution_guidance,
                decision_metrics=decision_metrics,
            )
            if utility_action:
                action = utility_action
            
            strategy = {
                "action": action,
                "reasoning": result.reasoning if hasattr(result, 'reasoning') else f"Task {'passed' if passed else 'failed'}",
                "action_confidence": action_confidence,
                "execution_guidance": execution_guidance,
                "decision_metrics": decision_metrics,
                "utility_scores": utility_scores,
                "selected_by_utility": bool(utility_scores)
            }
            
            logger.info(f"🎯 Strategy generated: action={action}, confidence={action_confidence:.2f}")
            logger.debug(f"   Reasoning: {strategy['reasoning'][:200]}")
            
            return strategy
            
        except Exception as e:
            logger.error(f"❌ Strategy generation failed (no fallback): {e}")
            logger.debug(f"Traceback: {traceback.format_exc()}")
            raise

    def _compute_strategy_utilities(
        self,
        task: SubtaskState,
        actor_name: str,
        reward: float,
        confidence: float,
        execution_guidance: Dict[str, Any],
        decision_metrics: Dict[str, Any],
    ) -> Tuple[Dict[str, float], Optional[str]]:
        """
        Compute expected utility for strategy actions using:
        - LLM-estimated probabilities/costs (decision_metrics)
        - Learned Q priors from agent selector
        - Partial-credit semantics from execution guidance
        """
        try:
            def _clamp01(x, default):
                try:
                    return max(0.0, min(1.0, float(x)))
                except Exception:
                    return default

            def _clamp_cost(x, default=0.3):
                try:
                    return max(0.0, min(2.0, float(x)))
                except Exception:
                    return default

            blocker_p = _clamp01(decision_metrics.get("blocker_probability"), 1.0 - _clamp01(confidence, 0.5))
            unresolved_impact = _clamp01(decision_metrics.get("unresolved_impact"), 1.0 - _clamp01(reward, 0.5))
            retry_p = _clamp01(decision_metrics.get("retry_success_probability"), _clamp01(reward, 0.5) * 0.8)
            reevaluate_p = _clamp01(decision_metrics.get("re_evaluate_success_probability"), _clamp01(confidence, 0.5))
            rewire_p = _clamp01(decision_metrics.get("rewire_success_probability"), _clamp01(confidence, 0.5))
            info_gain = _clamp01(decision_metrics.get("expected_information_gain"), 0.2)

            cost_retry = _clamp_cost(decision_metrics.get("cost_retry"), 0.3)
            cost_reevaluate = _clamp_cost(decision_metrics.get("cost_re_evaluate"), 0.45)
            cost_rewire = _clamp_cost(decision_metrics.get("cost_rewire"), 0.4)

            partial_credit = _clamp01(
                (execution_guidance or {}).get("partial_credit", reward),
                _clamp01(reward, 0.5),
            )

            q_current = 0.5
            q_best_alt = 0.5
            if hasattr(self, "enhanced_agent_selector") and self.enhanced_agent_selector:
                try:
                    feats = self.enhanced_agent_selector._extract_task_features(task)
                    q_current = float(self.enhanced_agent_selector._get_q_value(actor_name, feats))
                    q_best_alt = q_current
                    for aname in self.actors:
                        if aname == actor_name:
                            continue
                        q_alt = float(self.enhanced_agent_selector._get_q_value(aname, feats))
                        if q_alt > q_best_alt:
                            q_best_alt = q_alt
                except Exception:
                    pass

            confidence = _clamp01(confidence, 0.5)
            reward = _clamp01(reward, 0.5)

            # Expected-utility formulation (argmax over actions; no hard thresholds).
            u_pass = reward * confidence + (1.0 - blocker_p) * (1.0 - unresolved_impact)
            u_pass_partial = partial_credit * (1.0 - unresolved_impact) * (1.0 - 0.5 * blocker_p) + 0.25 * info_gain
            u_retry = retry_p * (0.5 * (q_current + confidence)) + 0.3 * info_gain - cost_retry - 0.5 * blocker_p
            u_re_evaluate = reevaluate_p * (0.5 * (q_best_alt + confidence)) + 0.5 * info_gain - cost_reevaluate - 0.35 * blocker_p
            u_stop = blocker_p - 0.5 * (1.0 - confidence) - 0.25 * unresolved_impact

            utilities = {
                "pass": float(u_pass),
                "pass_partial": float(u_pass_partial),
                "retry": float(u_retry),
                "re_evaluate": float(u_re_evaluate),
                "stop": float(u_stop),
                "rewire_signal": float(rewire_p - cost_rewire),
            }
            best_action = max(
                ["pass", "pass_partial", "retry", "re_evaluate", "stop"],
                key=lambda a: utilities.get(a, -1e9),
            )
            return utilities, best_action
        except Exception:
            return {}, None
    
    def _extract_failure_patterns(self, test_results: List[Dict]) -> List[str]:
        """Extract common failure patterns from test results."""
        patterns = []
        error_types = {}
        
        for result in test_results:
            if not result.get('passed', False):
                error = result.get('error', '')
                reasoning = result.get('reasoning', '')
                
                # Extract error type
                if 'timeout' in error.lower() or 'timeout' in reasoning.lower():
                    error_types['timeout'] = error_types.get('timeout', 0) + 1
                if 'import' in error.lower() or 'module' in error.lower():
                    error_types['import'] = error_types.get('import', 0) + 1
                if 'permission' in error.lower() or 'access' in error.lower():
                    error_types['permission'] = error_types.get('permission', 0) + 1
        
        for error_type, count in error_types.items():
            if count > 1:
                patterns.append(f"{error_type}_error ({count} occurrences)")
        
        return patterns
    
    def _analyze_failure(
        self,
        passed: bool,
        test_results: List[Dict],
        feedback: str,
        aggregated: Any = None
    ) -> str:
        """Analyze failure to extract root causes."""
        if passed:
            return "Task passed validation"
        
        analysis_parts = []
        
        # Test-level analysis
        failed_tests = [r for r in test_results if not r.get('passed', False)]
        if failed_tests:
            analysis_parts.append(f"{len(failed_tests)}/{len(test_results)} tests failed")
            
            # Extract common failure reasons
            reasons = []
            for test in failed_tests[:3]:  # First 3 failures
                reason = test.get('reasoning', '') or test.get('error', '')
                if reason:
                    reasons.append(smart_truncate(reason, max_tokens=100))
            
            if reasons:
                analysis_parts.append(f"Failure reasons: {'; '.join(reasons)}")
        
        # Aggregated analysis
        if aggregated and hasattr(aggregated, 'reasoning'):
            analysis_parts.append(f"Aggregation reasoning: {smart_truncate(aggregated.reasoning, max_tokens=200)}")
        
        # Feedback summary
        if feedback:
            analysis_parts.append(f"Feedback: {smart_truncate(feedback, max_tokens=300)}")
        
        return "\n".join(analysis_parts) if analysis_parts else "No detailed analysis available"
    
    def get_actor_outputs(self) -> Dict[str, Any]:
        """
        Extract all actor outputs from trajectory.
        
        Returns:
            Dict mapping actor_name -> latest output
        """
        outputs = {}
        for step in self.trajectory:
            actor = step.get('actor')
            if actor and 'actor_output' in step:
                outputs[actor] = step['actor_output']
        return outputs
    
    def get_output_from_actor(self, actor_name: str, field: Optional[str] = None) -> Any:
        """
        Get specific output from an actor.
        
        Args:
            actor_name: Name of the actor
            field: Optional field to extract from output dict
        
        Returns:
            Actor output or specific field value
        """
        # Search from most recent to oldest
        for step in reversed(self.trajectory):
            if step.get('actor') == actor_name and 'actor_output' in step:
                output = step['actor_output']
                if field and isinstance(output, dict):
                    return output.get(field)
                return output
        return None
    
    def _fetch_all_metadata_directly(self) -> Dict[str, Any]:
        """
        🔥 A-TEAM CRITICAL FIX (User Insight): Fetch ALL metadata directly!
        
        USER QUESTION: "Why is react agent fetching when it's already in metadata manager?"
        ANSWER: YOU'RE RIGHT! We should just call ALL methods directly!
        
        NO ReAct agent overhead, NO guessing, NO missing data!
        
        This method calls ALL @synapse_method decorated methods from metadata_provider
        and returns a complete dictionary with ALL metadata.
        
        Returns:
            Dict with ALL metadata, using semantic keys (e.g., 'business_terms', 'table_names', etc.)
        """
        logger.info("🔍 Fetching ALL metadata directly (no ReAct agent, no guessing)...")
        metadata = {}
        start_time = time.time()
        
        # 🔥 Call ALL metadata methods directly!
        # 🔥 USER INSIGHT: No hardcoding! Store with original method names only.
        # AgenticResolver will do semantic matching with ONE LLM call.
        # This is generic and works for ANY naming convention!
        
        try:
            if hasattr(self.metadata_provider, 'get_all_business_contexts'):
                logger.debug("   📞 Calling get_all_business_contexts()...")
                result = self.metadata_provider.get_all_business_contexts()
                metadata['get_all_business_contexts'] = result
                logger.info(f"   ✅ get_all_business_contexts: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_business_contexts() failed: {e}")
        
        try:
            if hasattr(self.metadata_provider, 'get_all_table_metadata'):
                logger.debug("   📞 Calling get_all_table_metadata()...")
                result = self.metadata_provider.get_all_table_metadata()
                metadata['get_all_table_metadata'] = result
                logger.info(f"   ✅ get_all_table_metadata: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_table_metadata() failed: {e}")
        
        try:
            if hasattr(self.metadata_provider, 'get_all_filter_definitions'):
                logger.debug("   📞 Calling get_all_filter_definitions()...")
                result = self.metadata_provider.get_all_filter_definitions()
                metadata['get_all_filter_definitions'] = result
                logger.info(f"   ✅ get_all_filter_definitions: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_filter_definitions() failed: {e}")
        
        try:
            if hasattr(self.metadata_provider, 'get_all_column_metadata'):
                logger.debug("   📞 Calling get_all_column_metadata()...")
                result = self.metadata_provider.get_all_column_metadata()
                metadata['get_all_column_metadata'] = result
                logger.info(f"   ✅ get_all_column_metadata: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_column_metadata() failed: {e}")
        
        try:
            if hasattr(self.metadata_provider, 'get_all_term_definitions'):
                logger.debug("   📞 Calling get_all_term_definitions()...")
                result = self.metadata_provider.get_all_term_definitions()
                metadata['get_all_term_definitions'] = result
                logger.info(f"   ✅ get_all_term_definitions: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_term_definitions() failed: {e}")
        
        try:
            if hasattr(self.metadata_provider, 'get_all_validations'):
                logger.debug("   📞 Calling get_all_validations()...")
                result = self.metadata_provider.get_all_validations()
                metadata['get_all_validations'] = result
                logger.info(f"   ✅ get_all_validations: {len(str(result))} chars")
        except Exception as e:
            logger.warning(f"   ⚠️  get_all_validations() failed: {e}")
        
        # 🔥 Add any other discovered methods from metadata_tool_registry
        if hasattr(self, 'metadata_tool_registry'):
            for tool_name in self.metadata_tool_registry.tools.keys():
                if tool_name not in ['get_all_business_contexts', 'get_all_table_metadata', 
                                     'get_all_filter_definitions', 'get_all_column_metadata',
                                     'get_all_term_definitions', 'get_all_validations']:
                    try:
                        if hasattr(self.metadata_provider, tool_name):
                            # ✅ FIX: Skip methods requiring positional args (prefetch phase has no args).
                            try:
                                sig = inspect.signature(getattr(self.metadata_provider, tool_name))
                                required_positional = [
                                    p.name for p in sig.parameters.values()
                                    if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD) and p.default is p.empty
                                ]
                                if required_positional:
                                    logger.debug(f"   ⏭️  Skipping {tool_name}() prefetch (requires args: {required_positional})")
                                    continue
                            except Exception as e:
                                logger.debug(f"   ⏭️  Skipping {tool_name}() prefetch (signature inspect failed: {e})")
                                continue

                            logger.debug(f"   📞 Calling {tool_name}()...")
                            result = getattr(self.metadata_provider, tool_name)()
                            metadata[tool_name] = result
                            logger.info(f"   ✅ {tool_name}: {len(str(result))} chars")
                    except Exception as e:
                        logger.warning(f"   ⚠️  {tool_name}() failed: {e}")
        
        elapsed = time.time() - start_time
        logger.info(f"✅ Fetched {len(metadata)} metadata items in {elapsed:.2f}s (direct calls, no LLM!)")
        
        return metadata
    
    def _enrich_business_terms_with_filters(self, fetched_data: Dict[str, Any]):
        """
        🔥 A-TEAM CRITICAL FIX: Enrich business_terms with parsed filter conditions!
        
        This bridges metadata (SharedContext) with parameter flow (actor inputs).
        
        GENERIC - No hardcoding! Works for ANY domain where:
        - There are "business_terms" (categories/concepts)
        - There are "filter_conditions_parsed" (structured constraints)
        
        Args:
            fetched_data: Metadata returned by _fetch_all_metadata_directly()
        """
        # Check if we have both business terms and parsed filters
        business_terms = fetched_data.get('business_terms', {})
        parsed_filters = fetched_data.get('filter_conditions_parsed', {})
        
        if not business_terms or not parsed_filters:
            logger.debug("No enrichment needed (missing business_terms or parsed_filters)")
            return
        
        logger.info(f"🔄 Enriching {len(business_terms)} business terms with {len(parsed_filters)} filter specs")
        
        # Enrich each business term with matching filter conditions
        enriched_count = 0
        for term_name, term_data in business_terms.items():
            # Try to find matching filter (generic matching!)
            # Try exact match first
            if term_name in parsed_filters:
                filter_spec = parsed_filters[term_name]
                self._merge_filter_into_term(term_data, filter_spec, term_name)
                enriched_count += 1
                continue
            
            # Try case-insensitive match
            term_lower = term_name.lower()
            for filter_key, filter_spec in parsed_filters.items():
                if filter_key.lower() == term_lower:
                    self._merge_filter_into_term(term_data, filter_spec, term_name)
                    enriched_count += 1
                    break
            
            # Try substring match (e.g., "P2P" matches "P2P transactions")
            if not isinstance(term_data, dict) or 'fields' not in term_data:
                for filter_key, filter_spec in parsed_filters.items():
                    if term_lower in filter_key.lower() or filter_key.lower() in term_lower:
                        self._merge_filter_into_term(term_data, filter_spec, term_name)
                        enriched_count += 1
                        break
        
        logger.info(f"✅ Enriched {enriched_count}/{len(business_terms)} business terms with filter conditions")
        
        # Update in SharedContext
        fetched_data['business_terms'] = business_terms
        self.shared_context.set('metadata', fetched_data)
    
    def _merge_filter_into_term(self, term_data: Any, filter_spec: Dict[str, Any], term_name: str):
        """
        Merge filter specification into business term data.
        
        GENERIC - works with any field names!
        """
        if not isinstance(term_data, dict):
            # Can't merge into non-dict, convert to dict first
            term_data_new = {'original': term_data}
            term_data = term_data_new
        
        # Merge filter fields
        for key, value in filter_spec.items():
            if key not in term_data:
                term_data[key] = value
                logger.debug(f"  ✅ {term_name}: Added '{key}' from filter spec")
            else:
                logger.debug(f"  ⚠️  {term_name}: '{key}' already exists, skipping")
    
    def _extract_collaboration_from_prediction(self, prediction) -> List[Dict]:
        """
        Extract collaboration suggestions from MARL prediction.
        
        Args:
            prediction: PredictedTrajectory from trajectory_predictor
        
        Returns:
            List of collaboration suggestion dicts
        """
        suggestions = []
        
        try:
            if not prediction or not hasattr(prediction, 'steps'):
                return suggestions
            
            for step in prediction.steps:
                step_dict = step if isinstance(step, dict) else {}
                
                # Check for help needs
                if step_dict.get('needs_help') or step_dict.get('blocked'):
                    suggestions.append({
                        'action': 'request_help',
                        'target_agent': step_dict.get('helper_agent', 'DomainExpert'),
                        'reason': step_dict.get('block_reason', 'Predicted to need assistance'),
                        'urgency': 'high' if step_dict.get('critical') else 'normal',
                        'type': step_dict.get('help_type', 'general_assistance')
                    })
                
                # Check for knowledge sharing opportunities
                if step_dict.get('knowledge_to_share'):
                    suggestions.append({
                        'action': 'share_knowledge',
                        'target_agent': step_dict.get('recipient', 'all'),
                        'knowledge_type': step_dict.get('knowledge_type', 'insight'),
                        'knowledge': step_dict.get('knowledge_to_share'),
                        'value': step_dict.get('knowledge_value', 0.5)
                    })
            
            return suggestions
        except Exception as e:
            logger.warning(f"Failed to extract collaboration from prediction: {e}")
            return []
    
    # =========================================================================
    # 🔬 A-TEAM v10.0: GENERIC DATA PROCESSING (CHUNKER & COMPRESSOR)
    # =========================================================================
    
    def _infer_field_type(self, field_name: str, field_value: str) -> str:
        """
        A-Team Enhancement: Improved type inference (more robust than keyword matching).
        
        Uses both field name AND content analysis to avoid false positives.
        """
        field_lower = field_name.lower()
        content_sample = smart_truncate(field_value, max_tokens=125).lower() if field_value else ""
        
        # Terminal: Check for command/shell indicators
        terminal_name_keywords = ['terminal', 'command', 'shell', 'stdout', 'stderr', 'exec']
        terminal_content_indicators = ['$', '>>>', 'error:', 'traceback', 'exit code']
        if (any(kw in field_lower for kw in terminal_name_keywords) or
            any(ind in content_sample for ind in terminal_content_indicators)):
            return 'terminal'
        
        # Web: Check for HTML/HTTP indicators
        web_name_keywords = ['web', 'html', 'url', 'http', 'page', 'scrape']
        web_content_indicators = ['<html', '<div', 'http://', 'https://', '<body']
        if (any(kw in field_lower for kw in web_name_keywords) or
            any(ind in content_sample for ind in web_content_indicators)):
            return 'web'
        
        # File: Check for file/document indicators
        file_name_keywords = ['file', 'document', 'text', 'data']
        # Only classify as 'file' if name suggests it AND no other strong indicators
        if any(kw in field_lower for kw in file_name_keywords):
            return 'file'
        
        return 'general'
    
    def _should_chunk_data(self, data: Any, actor_config: ActorConfig, data_type: str) -> bool:
        """Intelligent threshold for chunking - configurable by data type."""
        if not data:
            return False
        
        actor_budget = getattr(actor_config, 'max_context_tokens', None) or self.config.max_context_tokens or 16000
        base_threshold = actor_budget * self.config.chunking_threshold_ratio
        
        # Adjust by data type (terminal output is noisier, needs more aggressive chunking)
        type_multipliers = {
            'terminal': 0.5,  # More aggressive for terminal (lots of noise)
            'web': 0.7,       # Moderate for web (HTML tags)
            'file': 1.0,      # Standard for files
            'general': 0.8    # Slightly aggressive for unknown
        }
        threshold = base_threshold * type_multipliers.get(data_type, 0.8)
        
        data_tokens = len(str(data)) // 4
        should_chunk = data_tokens > threshold
        
        if should_chunk:
            logger.info(f"📊 Data size check: {data_tokens} tokens > {threshold:.0f} threshold ({data_type})")
        
        return should_chunk
    
    async def _process_large_data(self, data: Any, actor_config: ActorConfig, data_type: str, goal: str) -> Any:
        """
        A-Team Enhancement: Use ContentIngestionPipeline for generic large data processing.
        
        This replaces the old AgenticChunker approach with the new Phase 0 architecture.
        """
        if not self._should_chunk_data(data, actor_config, data_type):
            return data
        
        data_str = str(data)
        logger.info(f"🔧 [PIPELINE] Processing large {data_type} data: {len(data_str)} chars")
        
        try:
            # Lazy-load ContentIngestionPipeline
            if not hasattr(self, '_content_ingestion_pipeline'):
                from .content_ingestion import ContentIngestionPipeline
                self._content_ingestion_pipeline = ContentIngestionPipeline(config=self.config)
                logger.info("📦 ContentIngestionPipeline initialized")
            
            actor_budget = getattr(actor_config, 'max_context_tokens', None) or self.config.max_context_tokens or 16000
            target_tokens = int(actor_budget * self.config.chunking_threshold_ratio)
            
            # Process through pipeline
            result = await self._content_ingestion_pipeline.process(
                content=data_str,
                max_tokens=target_tokens,
                query=goal,
                goal=goal,
                context_type=data_type
            )
            
            logger.info(f"✅ [PIPELINE] Processed: {result.original_tokens} → {result.final_tokens} tokens via {result.processing_path}")
            return result.content
        except Exception as e:
            logger.error(f"❌ [PIPELINE] Failed: {e}")
            return data
    
    async def _compress_if_needed(self, context: Any, actor_config: ActorConfig, task_description: str) -> Any:
        """
        A-Team Enhancement: Use ContentIngestionPipeline for generic context compression.
        
        This replaces the old AgenticCompressor approach with the new Phase 0 architecture.
        """
        if not context:
            return context
        
        # Lazy-load ContentIngestionPipeline
        if not hasattr(self, '_content_ingestion_pipeline'):
            from .content_ingestion import ContentIngestionPipeline
            self._content_ingestion_pipeline = ContentIngestionPipeline(config=self.config)
            logger.info("📦 ContentIngestionPipeline initialized")
        
        actor_budget = getattr(actor_config, 'max_context_tokens', None) or self.config.max_context_tokens or 16000
        context_str = str(context)
        current_tokens = len(context_str) // 4  # Quick estimate
        
        # Only compress if exceeding threshold
        threshold_ratio = self.config.compression_trigger_ratio
        if current_tokens < actor_budget * threshold_ratio:
            return context
        
        logger.info(f"🗜️ [PIPELINE] Context at {current_tokens}/{actor_budget} tokens ({int(current_tokens/actor_budget*100)}%)")
        
        try:
            target_tokens = int(actor_budget * self.config.compression_target_ratio)
            
            # Process through pipeline (force compression)
            result = await self._content_ingestion_pipeline.process(
                content=context_str,
                max_tokens=target_tokens,
                query=task_description,
                goal=task_description,
                context_type='context'
            )
            
            logger.info(f"✅ [PIPELINE] Compressed: {result.original_tokens} → {result.final_tokens} tokens via {result.processing_path}")
            return result.content
        except Exception as e:
            logger.error(f"❌ [PIPELINE] Failed: {e}")
            return context


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_conductor(
    actors: List[Tuple[str, Any, List[str], List[str]]],
    config_path: str = "user_configs/config/synapse_config.yml",
    annotations_path: str = "user_configs/human_input_kb/annotations/annotations.json",
    global_architect: str = None,
    global_auditor: str = None
) -> Conductor:
    """
    Factory to create Conductor from simple configuration.
    
    Args:
        actors: List of (name, actor_instance, architect_prompts, auditor_prompts)
        config_path: Path to SYNAPSE config YAML
        annotations_path: Path to annotations JSON
        global_architect: Optional global Architect prompt path
        global_auditor: Optional global Auditor prompt path
    
    Returns:
        Configured Conductor instance
    """
    import yaml
    
    # Load config
    config = SynapseConfig()
    if Path(config_path).exists():
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
            
            # ✅ COMPLETE CONFIG MAPPING (NO HARDCODING)
            cfg_root = cfg.get('synapse', cfg)
            
            # Persistence config
            persistence_cfg = cfg_root.get('persistence', {})
            config.save_interval = persistence_cfg.get('save_interval', 1)
            config.auto_save = persistence_cfg.get('auto_save', True)
            config.auto_load = persistence_cfg.get('auto_load', True)
            
            # Context config
            context_cfg = cfg_root.get('context', {})
            config.max_context_tokens = context_cfg.get('max_tokens', 28000)
            
            # Learning config
            learning_cfg = cfg_root.get('learning', {})
            config.gamma = learning_cfg.get('gamma', 0.95)

            # Web search config
            web_cfg = cfg_root.get('web_search', {})
            config.enable_web_search_tools = web_cfg.get('enable_tools', config.enable_web_search_tools)
            config.enable_web_crawl = web_cfg.get('enable_crawl', config.enable_web_crawl)
            config.enable_web_search_context = web_cfg.get('enable_context', config.enable_web_search_context)
            config.enable_actor_tool_injection = web_cfg.get('enable_actor_tool_injection', config.enable_actor_tool_injection)
            config.web_search_max_results = web_cfg.get('max_results', config.web_search_max_results)
            config.web_search_max_chars = web_cfg.get('max_chars', config.web_search_max_chars)
            config.web_search_cache_ttl_seconds = web_cfg.get('cache_ttl_seconds', config.web_search_cache_ttl_seconds)
            config.web_search_headless = web_cfg.get('headless', config.web_search_headless)
            config.web_search_cache_enabled = web_cfg.get('cache_enabled', config.web_search_cache_enabled)
            config.web_search_verbose = web_cfg.get('verbose', config.web_search_verbose)
            config.web_search_context_max_results = web_cfg.get('context_max_results', config.web_search_context_max_results)
            config.web_search_context_max_chars = web_cfg.get('context_max_chars', config.web_search_context_max_chars)
            
            # Tool cache config (bounded + TTL)
            tools_cfg = cfg_root.get('tools', {})
            config.tool_cache_ttl_seconds = tools_cfg.get('cache_ttl_seconds', config.tool_cache_ttl_seconds)
            config.tool_cache_max_entries = tools_cfg.get('cache_max_entries', config.tool_cache_max_entries)
            config.scratchpad_tool_cache_ttl_seconds = tools_cfg.get(
                'scratchpad_cache_ttl_seconds',
                config.scratchpad_tool_cache_ttl_seconds
            )
            config.scratchpad_tool_cache_max_entries = tools_cfg.get(
                'scratchpad_cache_max_entries',
                config.scratchpad_tool_cache_max_entries
            )
            
            # Timeout warning config — FULLY REMOVED
            # Time-based termination was causing random task kills.
            # Pattern-based stuck detection replaces this entirely.

            # Optimal task planning config (DP + memoization)
            opt_cfg = cfg_root.get('optimal_task_planning', {})
            config.enable_optimal_task_planning = opt_cfg.get('enable', config.enable_optimal_task_planning)
            config.optimal_task_cache_size = opt_cfg.get('cache_size', config.optimal_task_cache_size)

            # Agent registry config (capability discovery)
            reg_cfg = cfg_root.get('agent_registry', {})
            config.enable_agent_registry = reg_cfg.get('enable', config.enable_agent_registry)
            config.auto_infer_capabilities = reg_cfg.get('auto_infer_capabilities', config.auto_infer_capabilities)

            # Time budget planning config - REMOVED (will be added back properly later)
    
    # Create actor configs
    actor_configs = []
    for name, actor, architects, auditors in actors:
        actor_configs.append(ActorConfig(
            name=name,
            actor=actor,
            architect_prompts=architects,
            auditor_prompts=auditors
        ))
    
    return Conductor(
        actors=actor_configs,
        config=config,
        global_architect=global_architect,
        global_auditor=global_auditor,
        annotations_path=annotations_path
    )
