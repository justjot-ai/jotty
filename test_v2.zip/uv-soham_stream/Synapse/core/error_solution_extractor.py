"""Extract solutions from web search results for errors."""
import dspy
import json
import logging
from .token_utils import smart_truncate  # 🔴 A-TEAM FIX

logger = logging.getLogger(__name__)


class ErrorSolutionSignature(dspy.Signature):
    """Extract actionable solutions from search results for an error."""
    
    error_message = dspy.InputField(desc="The error message that occurred")
    search_results = dspy.InputField(desc="Web search results (JSON or text)")
    context = dspy.InputField(desc="Task context (what was being attempted)")
    
    solutions = dspy.OutputField(
        desc="""JSON array of solutions. Each solution:
        {
            "fix": "Specific code or command to fix",
            "explanation": "Why this fixes the error",
            "confidence": 0.0-1.0,
            "source": "URL or source of solution"
        }
        
        Example:
        [
            {
                "fix": "pip install opencv-python",
                "explanation": "Error indicates missing opencv module",
                "confidence": 0.95,
                "source": "stackoverflow.com/opencv-install"
            },
            {
                "fix": "import cv2\\nif img is None: raise FileNotFoundError()",
                "explanation": "cv2.imread returns None instead of exception",
                "confidence": 0.90,
                "source": "opencv docs"
            }
        ]
        """
    )
    reasoning = dspy.OutputField(desc="How you identified these solutions")


class ErrorSolutionExtractor:
    """Extract solutions from web search for errors."""
    
    def __init__(self):
        try:
            self.extractor = dspy.ChainOfThought(ErrorSolutionSignature)
        except Exception as e:
            logger.warning(f"Failed to initialize ErrorSolutionExtractor: {e}")
            self.extractor = None
    
    def extract_solutions(self, error: str, search_results: str, context: dict) -> list:
        """
        Extract solutions from search results using LLM intelligence.
        
        🔥 A-TEAM CRITICAL FIX: NO non-agentic fallbacks!
        - If LLM unavailable → THROW ERROR (don't return empty list)
        - If JSON parsing fails → LLM-based retry (not regex extraction)
        - Agentic system requires agentic intelligence throughout
        
        Args:
            error: The error message
            search_results: Web search results (string or dict)
            context: Task context
        
        Returns:
            List of solution dicts
        
        Raises:
            RuntimeError: If LLM is not configured or extraction fails
        """
        if not self.extractor:
            raise RuntimeError(
                "❌ ErrorSolutionExtractor requires LLM intelligence!\n"
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))\n"
                "\n"
                "Agentic error recovery cannot operate without LLM. "
                "No heuristic fallback available."
            )
        
        try:
            # Convert search_results to string if needed
            if isinstance(search_results, dict):
                search_results_str = json.dumps(search_results, indent=2)
            else:
                search_results_str = str(search_results)
            
            # 🔧 FIX: Use ContentIngestionPipeline for automatic chunking of large content
            from .content_ingestion import ContentIngestionPipeline
            if len(search_results_str) > 4000:
                pipeline = ContentIngestionPipeline()
                result = pipeline.process_sync(
                    content=search_results_str,
                    max_tokens=1000,  # ~4000 chars
                    query=f"Extract relevant solutions for error: {error[:200]}",
                    goal="Error solution extraction",
                    context_type="error_search_results"
                )
                # process_sync returns IngestionResult with .content attribute
                search_results_str = result.content
            
            result = self.extractor(
                error_message=smart_truncate(error, max_tokens=125),
                search_results=search_results_str,
                context=smart_truncate(json.dumps(context, indent=2), max_tokens=125)
            )
            
            # Parse solutions
            solutions = json.loads(result.solutions)
            
            if not isinstance(solutions, list):
                solutions = [solutions]
            
            logger.info(f"✅ Extracted {len(solutions)} solutions for error")
            return solutions
            
        except json.JSONDecodeError as e:
            # 🔥 LLM-BASED RETRY: Clarify prompt, don't fall back to regex!
            logger.warning(f"Solution JSON parsing failed, retrying with clarified prompt...")
            try:
                # Retry with explicit JSON formatting instruction
                result = self.extractor(
                    error_message=smart_truncate(error, max_tokens=125),
                    search_results=search_results_str,
                    context=smart_truncate(json.dumps(context, indent=2), max_tokens=125) + 
                           "\n\nCRITICAL: Return ONLY valid JSON array. "
                           "Example: [{\"fix\": \"pip install pandas\", "
                           "\"explanation\": \"Install missing library\", "
                           "\"confidence\": 0.9, \"source\": \"stackoverflow\"}]"
                )
                solutions = json.loads(result.solutions)
                if not isinstance(solutions, list):
                    solutions = [solutions]
                logger.info(f"✅ Retry successful, extracted {len(solutions)} solutions")
                return solutions
            except Exception as retry_error:
                raise RuntimeError(
                    f"❌ LLM-based solution extraction failed after retry.\n"
                    f"Original error: {e}\n"
                    f"Retry error: {retry_error}\n"
                    f"Cannot fall back to heuristics. Agentic system requires LLM intelligence."
                )
                
        except Exception as e:
            raise RuntimeError(
                f"❌ Solution extraction failed: {e}\n"
                "Agentic error recovery requires LLM intelligence. "
                "No heuristic fallback available. "
                "Please check LLM configuration and search results quality."
            )
