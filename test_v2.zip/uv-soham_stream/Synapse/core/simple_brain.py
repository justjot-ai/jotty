"""
Simple Brain - A-Team Approved Implementation
=============================================

The A-Team debated and decided:
1. Complexity should be HIDDEN - users should NEVER need to configure brain modes
2. Consolidation should have MULTIPLE triggers (not just episode count)
3. Chunk sizing should be MODEL-AWARE (ratio, not absolute)
4. Presets for easy config, advanced for experts
5. Public API: reval.consolidate() for manual control

This module provides the APPROVED brain features with:
- Zero-config default (works out of the box)
- Preset system (minimal, balanced, thorough)
- Multiple consolidation triggers
- Model-aware chunk sizing
- Context manager for on-exit consolidation

Usage:
    # Zero config (recommended)
    brain = SimpleBrain()
    
    # With preset
    brain = SimpleBrain.from_preset("thorough")
    
    # Manual consolidation
    brain.consolidate()
    
    # Auto consolidation on exit
    with brain.session() as session:
        session.process(experience)
    # Auto-consolidates here
"""

import time
import asyncio
import logging
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import dspy
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)


# =============================================================================
# PRESETS (A-Team Approved)
# =============================================================================

class BrainPreset(Enum):
    """
    Simple presets for brain configuration.
    Users pick ONE word, everything else is auto-configured.
    """
    MINIMAL = "minimal"      # Fast, low memory usage
    BALANCED = "balanced"    # Default, good for most cases
    THOROUGH = "thorough"    # Deep learning, high memory
    OFF = "off"              # Disable brain features entirely


class MemoryRetentionSignature(dspy.Signature):
    """
    LLM-based decision on whether to retain an experience.
    """
    experience = dspy.InputField(desc="Serialized experience data")
    context = dspy.InputField(desc="Current brain state summary")
    
    reasoning = dspy.OutputField(desc="Why this experience should be stored or skipped")
    should_store = dspy.OutputField(desc="True if experience should be stored")


# Preset configurations (internal, users don't see this)
PRESET_CONFIGS = {
    BrainPreset.MINIMAL: {
        'consolidation_interval': 100,
        'memory_buffer_size': 50,
        'chunk_ratio': 0.5,  # 50% of model context
        'prune_threshold': 0.3,
        'auto_consolidate': True
    },
    BrainPreset.BALANCED: {
        'consolidation_interval': 3,  # 🔧 A-TEAM: Consolidate every 3 episodes (prevent memory buildup!)
        'memory_buffer_size': 100,
        'chunk_ratio': 0.64,  # 64% of model context
        'prune_threshold': 0.15,
        'auto_consolidate': True
    },
    BrainPreset.THOROUGH: {
        'consolidation_interval': 25,
        'memory_buffer_size': 200,
        'chunk_ratio': 0.75,  # 75% of model context
        'prune_threshold': 0.1,
        'auto_consolidate': True
    },
    BrainPreset.OFF: {
        'consolidation_interval': float('inf'),
        'memory_buffer_size': 10,
        'chunk_ratio': 0.64,
        'prune_threshold': 1.0,  # Never prune
        'auto_consolidate': False
    }
}


# =============================================================================
# CONSOLIDATION TRIGGERS (A-Team Decision: Multiple, not just episodes)
# =============================================================================

class ConsolidationTrigger(Enum):
    """When to consolidate memory."""
    EPISODE_COUNT = "episode_count"      # After N episodes
    MEMORY_PRESSURE = "memory_pressure"  # When memory buffer > 80% full
    PIPELINE_STAGE = "pipeline_stage"    # After a pipeline stage completes
    EXPLICIT = "explicit"                # User calls consolidate()
    ON_EXIT = "on_exit"                  # When session/context manager exits
    IDLE = "idle"                        # No new experiences for N seconds


# =============================================================================
# MODEL-AWARE CHUNK SIZING (A-Team Decision: Ratio, not absolute)
# =============================================================================

MODEL_CONTEXTS = {
    # OpenAI
    "gpt-4": 8192,
    "gpt-4-32k": 32768,
    "gpt-4-turbo": 128000,
    "gpt-4.1": 30000,  # Effective usable
    "gpt-4o": 128000,
    "gpt-4o-mini": 128000,
    
    # Anthropic
    "claude-3-sonnet": 200000,
    "claude-3-opus": 200000,
    "claude-3.5-sonnet": 200000,
    
    # Local/Other
    "llama-7b": 4096,
    "mistral-7b": 8192,
    
    # Default
    "default": 28000
}


def get_model_context(model_name: str) -> int:
    """Get context window size for a model."""
    model_lower = model_name.lower().replace("-", "").replace("_", "")
    
    for key, value in MODEL_CONTEXTS.items():
        if key.replace("-", "").replace("_", "") in model_lower:
            return value
    
    return MODEL_CONTEXTS["default"]


def calculate_chunk_size(model_name: str, ratio: float = 0.64) -> int:
    """
    Calculate chunk size based on model context and ratio.
    
    A-Team Decision: Use ratio, not absolute value.
    This automatically adapts to any model.
    """
    context = get_model_context(model_name)
    chunk = int(context * ratio)
    
    # Ensure reasonable bounds
    chunk = max(1000, min(chunk, 100000))
    
    logger.debug(f"Chunk size for {model_name}: {chunk} ({ratio*100:.0f}% of {context})")
    return chunk


# =============================================================================
# SIMPLE BRAIN (A-Team Approved Implementation)
# =============================================================================

@dataclass
class Experience:
    """A single experience to potentially remember."""
    content: str
    reward: float
    timestamp: float = field(default_factory=time.time)
    agent: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


class SimpleBrain:
    """
    A-Team Approved brain implementation.
    
    Design Principles (from A-Team debate):
    1. ZERO CONFIG required - works out of box
    2. PRESETS for easy customization
    3. MULTIPLE consolidation triggers
    4. MODEL-AWARE chunk sizing
    5. PUBLIC API for manual control
    
    Usage:
        # Zero config (recommended)
        brain = SimpleBrain()
        
        # With preset
        brain = SimpleBrain.from_preset("thorough")
        
        # Manual consolidation
        brain.consolidate()
        
        # On-exit consolidation
        async with brain.session() as session:
            await session.process(experience)
        # Auto-consolidates when session exits
    """
    
    def __init__(
        self,
        preset: BrainPreset = BrainPreset.BALANCED,
        model_name: str = None,  # 🔴 A-TEAM: No hardcoded default; resolved from dspy.settings
        consolidate_on: ConsolidationTrigger = ConsolidationTrigger.EPISODE_COUNT
    ):
        self.preset = preset
        # 🔴 A-TEAM FIX: Resolve model name from dspy settings if not provided
        if model_name is None:
            try:
                import dspy
                if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                    model_name = getattr(dspy.settings.lm, 'model', 'gpt-4.1')
                else:
                    model_name = 'gpt-4.1'
            except (ImportError, AttributeError):
                model_name = 'gpt-4.1'
        self.model_name = model_name
        self.consolidate_on = consolidate_on
        
        # Get preset config
        self.config = PRESET_CONFIGS[preset]
        
        # Calculate model-aware chunk size
        self.chunk_size = calculate_chunk_size(
            model_name, 
            self.config['chunk_ratio']
        )
        
        # State
        self.experience_buffer: List[Experience] = []
        self.patterns_learned: List[str] = []
        self.episode_count = 0
        self.last_activity_time = time.time()
        self.is_consolidating = False
        
        # Stats
        self.consolidation_count = 0
        self.total_experiences = 0
        self.total_pruned = 0
        
        # LLM-based retention decision (no heuristics)
        self._retention_decider = dspy.ChainOfThought(MemoryRetentionSignature)
        
        if preset != BrainPreset.OFF:
            logger.info(
                f"🧠 SimpleBrain initialized: preset={preset.value}, "
                f"model={model_name}, chunk_size={self.chunk_size}"
            )
    
    @classmethod
    def from_preset(cls, preset_name: str, model_name: str = None) -> 'SimpleBrain':
        """
        Create brain from preset name.
        
        Options: "minimal", "balanced", "thorough", "off"
        """
        try:
            preset = BrainPreset(preset_name.lower())
        except ValueError:
            logger.warning(f"Unknown preset '{preset_name}', using 'balanced'")
            preset = BrainPreset.BALANCED
        
        return cls(preset=preset, model_name=model_name)
    
    def process(self, experience: Experience) -> bool:
        """
        Process an experience, potentially storing it.
        
        Returns True if experience was stored, False if filtered out.
        """
        if self.preset == BrainPreset.OFF:
            return False
        
        if self.is_consolidating:
            logger.debug("Brain is consolidating, experience queued")
            return False
        
        self.episode_count += 1
        self.total_experiences += 1
        self.last_activity_time = time.time()
        
        # LLM-based filtering (A-Team: weights should be learned, not hardcoded)
        should_store = self._should_remember(experience)
        
        if should_store:
            self.experience_buffer.append(experience)
            
            # Check buffer overflow
            if len(self.experience_buffer) > self.config['memory_buffer_size']:
                self._prune_buffer()
        
        # Check if should consolidate
        if self._should_consolidate():
            asyncio.create_task(self._async_consolidate())
        
        return should_store
    
    def _should_remember(self, exp: Experience) -> bool:
        """
        Adaptive filtering: Remember surprising and relevant experiences.
        
        🔥 A-TEAM CRITICAL FIX: NO silent fallback!
        A-Team Decision: No hardcoded thresholds (0.8, 0.2).
        Uses LLM-based retention decisions.
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        if not self._retention_decider:
            raise RuntimeError(
                "❌ SimpleBrain retention decisions require LLM intelligence!\n"
                "Memory retention is a critical agentic operation. "
                "Cannot fall back to keeping all experiences as it causes memory bloat. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        
        try:
            result = self._retention_decider(
                experience=str(exp)[:1500],
                context=f"episode_count={self.episode_count}, preset={self.preset.value}"
            )
            return bool(getattr(result, "should_store", True))
        except Exception as e:
            raise RuntimeError(
                f"❌ LLM retention decision failed: {e}\n"
                "Cannot fall back to keeping all experiences. "
                "Please check LLM configuration."
            )
    
    def _should_consolidate(self) -> bool:
        """Check all consolidation triggers."""
        if self.is_consolidating:
            return False
        
        if not self.config['auto_consolidate']:
            return False
        
        triggers = {
            ConsolidationTrigger.EPISODE_COUNT: (
                self.episode_count >= self.config['consolidation_interval']
            ),
            ConsolidationTrigger.MEMORY_PRESSURE: (
                len(self.experience_buffer) >= self.config['memory_buffer_size'] * 0.8
            ),
            ConsolidationTrigger.IDLE: (
                time.time() - self.last_activity_time > 30
            )
        }
        
        return triggers.get(self.consolidate_on, False)
    
    def _prune_buffer(self):
        """Remove low-value experiences to make room."""
        if not self.experience_buffer:
            return
        
        # Sort by reward (keep high and low, remove middle)
        sorted_exp = sorted(self.experience_buffer, key=lambda e: abs(e.reward - 0.5))
        
        # Keep top 80%
        keep_count = int(len(sorted_exp) * 0.8)
        self.experience_buffer = sorted_exp[:keep_count]
        
        pruned = len(sorted_exp) - keep_count
        self.total_pruned += pruned
        logger.debug(f"Pruned {pruned} experiences from buffer")
    
    async def _async_consolidate(self):
        """Async consolidation (internal)."""
        await self.consolidate(ConsolidationTrigger.EPISODE_COUNT)
    
    # =========================================================================
    # PUBLIC API (A-Team Decision: Users should be able to control this)
    # =========================================================================
    
    async def consolidate(
        self, 
        trigger: ConsolidationTrigger = ConsolidationTrigger.EXPLICIT
    ):
        """
        PUBLIC API: Consolidate memories.
        
        Users can call this directly for manual control:
            await brain.consolidate()
        """
        if self.is_consolidating:
            logger.debug("Already consolidating, skipping")
            return
        
        if not self.experience_buffer:
            logger.debug("No experiences to consolidate")
            return
        
        self.is_consolidating = True
        self.consolidation_count += 1
        
        logger.info(
            f"🌙 Consolidating ({trigger.value}): "
            f"{len(self.experience_buffer)} experiences"
        )
        
        try:
            # Extract patterns from experiences
            patterns = self._extract_patterns()
            self.patterns_learned.extend(patterns)
            
            # Keep patterns bounded
            if len(self.patterns_learned) > 100:
                self.patterns_learned = self.patterns_learned
            
            # Prune buffer after consolidation
            self._prune_buffer()
            
            # Reset episode counter
            self.episode_count = 0
            
            logger.info(
                f"☀️ Consolidation complete: "
                f"{len(patterns)} patterns extracted"
            )
            
        except Exception as e:
            logger.error(f"Consolidation failed: {e}")
        finally:
            self.is_consolidating = False
    
    def _extract_patterns(self) -> List[str]:
        """Extract patterns from experience buffer."""
        patterns = []
        
        # Group by outcome
        successes = [e for e in self.experience_buffer if e.reward > 0.7]
        failures = [e for e in self.experience_buffer if e.reward < 0.3]
        
        if len(successes) >= 3:
            patterns.append(f"SUCCESS_PATTERN: {len(successes)} successful experiences")
        
        if len(failures) >= 3:
            patterns.append(f"FAILURE_PATTERN: {len(failures)} failures to learn from")
        
        # Agent-specific patterns
        agents = {e.agent for e in self.experience_buffer if e.agent}
        for agent in agents:
            agent_exp = [e for e in self.experience_buffer if e.agent == agent]
            if len(agent_exp) >= 3:
                avg_reward = sum(e.reward for e in agent_exp) / len(agent_exp)
                patterns.append(
                    f"AGENT_PATTERN: {agent} has {avg_reward:.0%} avg success"
                )
        
        return patterns
    
    @asynccontextmanager
    async def session(self):
        """
        Context manager for automatic on-exit consolidation.
        
        Usage:
            async with brain.session() as session:
                session.process(experience1)
                session.process(experience2)
            # Auto-consolidates here
        """
        try:
            yield self
        finally:
            await self.consolidate(ConsolidationTrigger.ON_EXIT)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get brain statistics."""
        return {
            'preset': self.preset.value,
            'model': self.model_name,
            'chunk_size': self.chunk_size,
            'buffer_size': len(self.experience_buffer),
            'patterns_learned': len(self.patterns_learned),
            'consolidation_count': self.consolidation_count,
            'total_experiences': self.total_experiences,
            'total_pruned': self.total_pruned
        }
    
    def get_learned_patterns(self) -> List[str]:
        """Get patterns learned so far (for prompt injection)."""
        return self.patterns_learned.copy()


# =============================================================================
# SIMPLE CONFIG LOADER (A-Team: Single-level config with presets)
# =============================================================================

def load_brain_config(config: Dict[str, Any]) -> SimpleBrain:
    """
    Load SimpleBrain from config dict.
    
    Simple config (recommended):
        reval:
          brain: balanced  # or minimal, thorough, off
    
    Advanced config:
        reval:
          brain:
            preset: balanced
            model: gpt-4.1
            consolidate_on: pipeline_stage
    """
    brain_config = config.get('reval', {}).get('brain', 'balanced')
    
    if isinstance(brain_config, str):
        # Simple: just preset name
        return SimpleBrain.from_preset(brain_config)
    
    elif isinstance(brain_config, dict):
        # Advanced: dict with options
        preset_name = brain_config.get('preset', 'balanced')
        model = brain_config.get('model', 'gpt-4.1')
        consolidate_on_str = brain_config.get('consolidate_on', 'episode_count')
        
        try:
            consolidate_on = ConsolidationTrigger(consolidate_on_str)
        except ValueError:
            consolidate_on = ConsolidationTrigger.EPISODE_COUNT
        
        return SimpleBrain.from_preset(
            preset_name, 
            model_name=model
        )
    
    else:
        # Default
        return SimpleBrain()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'SimpleBrain',
    'BrainPreset',
    'ConsolidationTrigger',
    'Experience',
    'calculate_chunk_size',
    'get_model_context',
    'load_brain_config'
]

