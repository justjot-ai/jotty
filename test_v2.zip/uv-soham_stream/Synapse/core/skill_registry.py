"""
Dynamic Skill Registry for SYNAPSE
==================================

Persistent, actor-agnostic registry for validated skills.

Design goals:
- Persist skills across sessions with searchable index
- LLM-based semantic lookup (no brittle keyword routing)
- Versioned skill artifacts with audit metadata
- Async-safe file I/O paths
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


@dataclass
class SkillArtifact:
    """Canonical persisted metadata for a skill artifact."""

    skill_id: str
    name: str
    description: str
    version: str
    module_path: str
    entrypoint: str = "run"
    owner_actor: str = ""
    status: str = "candidate"  # candidate|approved|deprecated
    dependencies: List[str] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    safety_profile: Dict[str, Any] = field(default_factory=dict)
    quality_signals: Dict[str, Any] = field(default_factory=dict)
    provenance: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    usage_count: int = 0
    success_count: int = 0
    # ─── Item 229: Skill Confidence Metadata & Decay ─────────────────
    confidence: float = 1.0                    # Current confidence [0.0, 1.0]
    confidence_decay_rate: float = 0.01        # Decay per day since last successful use
    last_successful_use: float = 0.0           # Timestamp of last successful invocation
    revalidation_interval_days: float = 7.0    # Re-test after N days of non-use
    last_validated_at: float = 0.0             # Timestamp of last validation pass
    # ─────────────────────────────────────────────────────────────────

    @property
    def success_rate(self) -> float:
        if self.usage_count <= 0:
            return 1.0
        return self.success_count / max(self.usage_count, 1)

    @property
    def effective_confidence(self) -> float:
        """Confidence decayed by time since last successful use (Item 229)."""
        if self.last_successful_use <= 0:
            return self.confidence
        days_since = (time.time() - self.last_successful_use) / 86400.0
        decayed = max(0.0, self.confidence - (days_since * self.confidence_decay_rate))
        return round(decayed, 4)

    @property
    def needs_revalidation(self) -> bool:
        """True if the skill hasn't been validated within its revalidation window."""
        if self.last_validated_at <= 0:
            return True
        days_since_validation = (time.time() - self.last_validated_at) / 86400.0
        return days_since_validation >= self.revalidation_interval_days

    # Configurable confidence adjustment factors (override via config if needed)
    _confidence_boost_on_success: float = 0.05
    _confidence_penalty_on_failure: float = 0.1

    def record_usage(self, success: bool) -> None:
        """Record a usage event and update confidence accordingly."""
        self.usage_count += 1
        if success:
            self.success_count += 1
            self.last_successful_use = time.time()
            # Boost confidence on success (bounded)
            self.confidence = min(1.0, self.confidence + self._confidence_boost_on_success)
        else:
            # Reduce confidence on failure
            self.confidence = max(0.0, self.confidence - self._confidence_penalty_on_failure)
        self.updated_at = time.time()


if DSPY_AVAILABLE:
    class SkillSelectionSignature(dspy.Signature):
        """Select best reusable skills for a requested capability."""

        skill_request = dspy.InputField(desc="What capability is needed")
        actor_name = dspy.InputField(desc="Actor requesting the skill")
        available_skills = dspy.InputField(desc="Catalog of approved skills")

        selected_skill_ids = dspy.OutputField(desc="JSON array of skill IDs in ranked order")
        reasoning = dspy.OutputField(desc="Why these skills fit the request")


class SkillRegistry:
    """
    Persistent dynamic skill index with MCP-like modular design.

    Storage layout (lambda/MCP-style per-skill isolation):
      <root>/
        index.json              — global searchable index
        skills/
          <skill_id>/
            skill.py            — entrypoint module (async interface)
            manifest.json       — full metadata, schema, safety profile
            README.md           — auto-generated human-readable documentation
            deps.txt            — pip-style dependency list (if any)
            tests/              — optional test fixtures
              test_skill.py

    Design principles:
    - Each skill is a self-contained lambda: own folder, own deps, own docs
    - Async-first interface: all entrypoints are async or wrapped via asyncio.to_thread
    - No hardcoded values inside skills: all params via input_schema
    - Skills persist across sessions at a stable root path
    - Chunked loading: for large skill catalogs, load in pages
    """

    INDEX_FILE = "index.json"
    SKILLS_DIR = "skills"
    PAGE_SIZE = 50  # Chunked loading page size

    def __init__(self, root_dir: str):
        self.root = Path(root_dir).expanduser().resolve()
        self.skills_dir = self.root / self.SKILLS_DIR
        self.index_path = self.root / self.INDEX_FILE
        self._artifacts: Dict[str, SkillArtifact] = {}
        self._selector = dspy.ChainOfThought(SkillSelectionSignature) if DSPY_AVAILABLE else None
        self._init_dirs()

    def _init_dirs(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        if not self.index_path.exists():
            self.index_path.write_text(json.dumps({"skills": []}, indent=2))

    async def load(self) -> None:
        """Load registry state from disk."""
        def _read() -> Dict[str, Any]:
            with self.index_path.open("r", encoding="utf-8") as f:
                return json.load(f)

        payload = await asyncio.to_thread(_read)
        self._artifacts.clear()
        for item in payload.get("skills", []):
            try:
                art = SkillArtifact(**item)
                self._artifacts[art.skill_id] = art
            except Exception as exc:
                logger.warning(f"Skipping malformed skill entry: {exc}")

    async def save(self) -> None:
        """Persist current registry state to disk."""
        payload = {"skills": [asdict(v) for v in self._artifacts.values()]}

        def _write() -> None:
            with self.index_path.open("w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=True)

        await asyncio.to_thread(_write)

    async def list_skills(
        self,
        status: Optional[str] = None,
        owner_actor: Optional[str] = None,
    ) -> List[SkillArtifact]:
        await self.load()
        values = list(self._artifacts.values())
        if status:
            values = [v for v in values if v.status == status]
        if owner_actor:
            values = [v for v in values if v.owner_actor == owner_actor]
        return sorted(values, key=lambda x: x.updated_at, reverse=True)

    async def get_skill(self, skill_id: str) -> Optional[SkillArtifact]:
        await self.load()
        return self._artifacts.get(skill_id)

    async def register_skill(
        self,
        name: str,
        description: str,
        module_path: str,
        owner_actor: str,
        *,
        version: str = "0.1.0",
        entrypoint: str = "run",
        status: str = "candidate",
        dependencies: Optional[List[str]] = None,
        input_schema: Optional[Dict[str, Any]] = None,
        output_schema: Optional[Dict[str, Any]] = None,
        safety_profile: Optional[Dict[str, Any]] = None,
        quality_signals: Optional[Dict[str, Any]] = None,
        provenance: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> SkillArtifact:
        await self.load()
        skill_id = f"skill_{uuid.uuid4().hex[:12]}"
        now = time.time()
        artifact = SkillArtifact(
            skill_id=skill_id,
            name=name,
            description=description,
            version=version,
            module_path=module_path,
            entrypoint=entrypoint,
            owner_actor=owner_actor,
            status=status,
            dependencies=dependencies or [],
            input_schema=input_schema or {},
            output_schema=output_schema or {},
            safety_profile=safety_profile or {},
            quality_signals=quality_signals or {},
            provenance=provenance or {},
            tags=tags or [],
            created_at=now,
            updated_at=now,
        )
        self._artifacts[artifact.skill_id] = artifact
        await self.save()
        return artifact

    async def update_skill_status(
        self,
        skill_id: str,
        status: str,
        extra_quality: Optional[Dict[str, Any]] = None,
    ) -> Optional[SkillArtifact]:
        await self.load()
        art = self._artifacts.get(skill_id)
        if not art:
            return None
        art.status = status
        art.updated_at = time.time()
        if extra_quality:
            art.quality_signals.update(extra_quality)
        await self.save()
        return art

    async def record_usage(self, skill_id: str, success: bool) -> None:
        await self.load()
        art = self._artifacts.get(skill_id)
        if not art:
            return
        art.record_usage(success)
        await self.save()

    # ─── Item 230: Skill Deprecation and Migration Flow ──────────────
    async def deprecate_skill(
        self,
        skill_id: str,
        reason: str = "",
        superseded_by: Optional[str] = None,
    ) -> Optional[SkillArtifact]:
        """
        Deprecate a skill with optional migration path to a replacement.
        
        Args:
            skill_id: ID of the skill to deprecate.
            reason: Why this skill is being deprecated.
            superseded_by: Optional skill_id of the replacement skill.
        
        Returns:
            The deprecated SkillArtifact, or None if not found.
        """
        await self.load()
        art = self._artifacts.get(skill_id)
        if not art:
            logger.warning(f"⚠️ Cannot deprecate skill {skill_id}: not found")
            return None
        
        art.status = "deprecated"
        art.updated_at = time.time()
        art.provenance["deprecated_reason"] = reason
        art.provenance["deprecated_at"] = time.time()
        if superseded_by:
            art.provenance["superseded_by"] = superseded_by
            # Verify replacement exists
            replacement = self._artifacts.get(superseded_by)
            if replacement:
                if "supersedes" not in replacement.provenance:
                    replacement.provenance["supersedes"] = []
                replacement.provenance["supersedes"].append(skill_id)
                replacement.updated_at = time.time()
                logger.info(f"🔄 Skill {skill_id} deprecated → superseded by {superseded_by}")
            else:
                logger.warning(f"⚠️ Replacement skill {superseded_by} not found in registry")
        else:
            logger.info(f"🗑️ Skill {skill_id} deprecated (no replacement)")
        
        await self.save()
        return art

    async def migrate_skill_references(
        self,
        old_skill_id: str,
    ) -> Dict[str, Any]:
        """
        Find all references to a deprecated skill and suggest migration paths.
        
        Returns a dict with migration info: what was deprecated, what replaces it,
        and which actors were using the old skill.
        """
        await self.load()
        old_art = self._artifacts.get(old_skill_id)
        if not old_art:
            return {"status": "error", "reason": f"Skill {old_skill_id} not found"}
        
        replacement_id = old_art.provenance.get("superseded_by")
        replacement_art = self._artifacts.get(replacement_id) if replacement_id else None
        
        return {
            "status": "ok",
            "deprecated_skill": {
                "skill_id": old_skill_id,
                "name": old_art.name,
                "reason": old_art.provenance.get("deprecated_reason", ""),
            },
            "replacement": {
                "skill_id": replacement_id or "",
                "name": replacement_art.name if replacement_art else "",
                "description": replacement_art.description if replacement_art else "",
                "available": replacement_art is not None,
            } if replacement_id else None,
            "migration_action": "auto_replace" if replacement_art else "manual_review",
        }

    async def get_skills_needing_revalidation(self) -> List[SkillArtifact]:
        """Return approved skills whose revalidation window has expired (Item 229)."""
        await self.load()
        return [
            art for art in self._artifacts.values()
            if art.status == "approved" and art.needs_revalidation
        ]
    # ──────────────────────────────────────────────────────────────────

    async def select_skills_semantic(
        self,
        skill_request: str,
        actor_name: str,
        max_results: int = 3,
    ) -> Dict[str, Any]:
        """
        Select existing approved skills for a capability request.
        Uses LLM semantic matching when available.
        """
        approved = await self.list_skills(status="approved")
        if not approved:
            return {"success": True, "selected": [], "reasoning": "No approved skills available."}

        if not self._selector or not getattr(dspy.settings, "lm", None):
            # If no LLM configured, return explicit uncertainty (no silent heuristics).
            return {
                "success": False,
                "selected": [],
                "reasoning": "LLM not configured for semantic skill selection.",
            }

        catalog = []
        for s in approved:
            catalog.append(
                {
                    "skill_id": s.skill_id,
                    "name": s.name,
                    "description": s.description,
                    "tags": s.tags,
                    "input_schema": s.input_schema,
                    "output_schema": s.output_schema,
                    "success_rate": s.success_rate,
                }
            )

        try:
            pred = self._selector(
                skill_request=skill_request,
                actor_name=actor_name,
                available_skills=json.dumps(catalog, ensure_ascii=True)[:12000],
            )
            raw = pred.selected_skill_ids if hasattr(pred, "selected_skill_ids") else "[]"
            selected_ids = json.loads(raw) if isinstance(raw, str) else raw
            if not isinstance(selected_ids, list):
                selected_ids = []
            selected = [s for s in approved if s.skill_id in set(selected_ids)]
            selected = selected[: max(1, max_results)]
            return {
                "success": True,
                "selected": [asdict(s) for s in selected],
                "reasoning": getattr(pred, "reasoning", ""),
            }
        except Exception as exc:
            logger.warning(f"Skill semantic selection failed: {exc}")
            return {"success": False, "selected": [], "reasoning": f"Selection failed: {exc}"}

    # ─── Chunked Loading (for large skill catalogs) ─────────────────

    async def list_skills_paged(
        self,
        status: Optional[str] = None,
        page: int = 0,
        page_size: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Load skills in pages so actors don't need the full catalog in context."""
        ps = page_size or self.PAGE_SIZE
        all_skills = await self.list_skills(status=status)
        start = page * ps
        end = start + ps
        page_items = all_skills[start:end]
        return {
            "page": page,
            "page_size": ps,
            "total": len(all_skills),
            "has_more": end < len(all_skills),
            "skills": [asdict(s) for s in page_items],
        }

    # ─── Auto-Documentation Generation ──────────────────────────────

    async def generate_skill_readme(self, skill_id: str) -> Optional[str]:
        """Generate a README.md for a skill and persist it in the skill folder."""
        art = await self.get_skill(skill_id)
        if not art:
            return None

        skill_dir = self.skills_dir / skill_id
        skill_dir.mkdir(parents=True, exist_ok=True)

        readme_content = (
            f"# {art.name}\n\n"
            f"**ID:** `{art.skill_id}`  \n"
            f"**Version:** {art.version}  \n"
            f"**Status:** {art.status}  \n"
            f"**Owner:** {art.owner_actor}  \n"
            f"**Entrypoint:** `{art.entrypoint}()`  \n\n"
            f"## Description\n\n{art.description}\n\n"
            f"## Input Schema\n\n```json\n{json.dumps(art.input_schema, indent=2)}\n```\n\n"
            f"## Output Schema\n\n```json\n{json.dumps(art.output_schema, indent=2)}\n```\n\n"
            f"## Safety Profile\n\n```json\n{json.dumps(art.safety_profile, indent=2)}\n```\n\n"
            f"## Dependencies\n\n"
            + ("\n".join(f"- `{d}`" for d in art.dependencies) if art.dependencies else "_None_")
            + f"\n\n## Tags\n\n"
            + (", ".join(f"`{t}`" for t in art.tags) if art.tags else "_None_")
            + f"\n\n## Quality Signals\n\n"
            f"- Usage count: {art.usage_count}\n"
            f"- Success count: {art.success_count}\n"
            f"- Success rate: {art.success_rate:.1%}\n\n"
            f"## Provenance\n\n```json\n{json.dumps(art.provenance, indent=2)}\n```\n"
        )

        readme_path = skill_dir / "README.md"

        def _write():
            readme_path.write_text(readme_content, encoding="utf-8")

        await asyncio.to_thread(_write)
        logger.info(f"📝 Generated README for skill {art.name} at {readme_path}")
        return str(readme_path)

    async def write_skill_module(
        self,
        skill_id: str,
        code: str,
        deps: Optional[List[str]] = None,
    ) -> Dict[str, str]:
        """Write skill code and deps to the skill's folder. Returns paths."""
        skill_dir = self.skills_dir / skill_id
        skill_dir.mkdir(parents=True, exist_ok=True)

        module_path = skill_dir / "skill.py"
        deps_path = skill_dir / "deps.txt"

        def _write():
            module_path.write_text(code, encoding="utf-8")
            if deps:
                deps_path.write_text("\n".join(deps), encoding="utf-8")

        await asyncio.to_thread(_write)
        # Also generate README
        await self.generate_skill_readme(skill_id)
        return {
            "module_path": str(module_path),
            "deps_path": str(deps_path) if deps else "",
            "readme_path": str(skill_dir / "README.md"),
        }

    async def get_skill_catalog_summary(self, max_skills: int = 20) -> str:
        """Build a compact text summary of approved skills for context injection."""
        approved = await self.list_skills(status="approved")
        if not approved:
            return "No approved skills available."

        lines = [f"=== SKILL CATALOG ({len(approved)} approved) ==="]
        for s in approved[:max_skills]:
            lines.append(
                f"- [{s.skill_id}] {s.name}: {s.description[:120]} "
                f"(tags={','.join(s.tags[:3])}, success={s.success_rate:.0%})"
            )
        if len(approved) > max_skills:
            lines.append(f"  ... and {len(approved) - max_skills} more (use paged listing)")
        return "\n".join(lines)

