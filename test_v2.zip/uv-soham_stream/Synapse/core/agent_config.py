"""
Agent Configuration for SYNAPSE.

Defines configuration for individual agents in the swarm.

# ✅ GENERIC: No domain-specific logic.

SYNAPSE Naming Convention:
- Architect = Pre-execution planner
- Auditor = Post-execution validator
- Agent = User's actor module
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable

# 🔧 A-TEAM: Import ContextRequirements
try:
    from .enhanced_logging_and_context import ContextRequirements
except ImportError:
    ContextRequirements = None


@dataclass
class AgentConfig:
    """
    Configuration for a single agent in the SYNAPSE swarm.
    
    SYNAPSE v1.0: Complete naming overhaul
    - Architect = Plans execution, assesses inputs
    - Auditor = Validates outputs, quality check
    
    NEW in v9.1: Full tool support with separate Architect/Auditor tools.
    NEW in v10.0 (A-Team v2.0): Capabilities for dynamic orchestration.
    NEW in v11.0 (A-Team FINAL): Declarative input/output specification.
    """
    name: str
    agent: Any  # DSPy Module
    architect_prompts: List[str]  # Pre-execution planning prompts
    auditor_prompts: List[str]    # Post-execution validation prompts
    
    # Parameter mappings removed - handled by AgenticParameterResolver
    # Context requirements removed - handled by SmartAgentSlack
    
    # Tool configuration (SYNAPSE v1.0)
    architect_tools: List[Any] = field(default_factory=list)  # Tools for Architect
    auditor_tools: List[Any] = field(default_factory=list)    # Tools for Auditor
    
    # Feedback routing
    feedback_rules: Optional[List[Dict[str, Any]]] = None
    capabilities: Optional[List[str]] = None
    dependencies: Optional[List[str]] = field(default_factory=list)  # Default to empty list, not None
    metadata: Optional[Dict[str, Any]] = None
    
    # Validation Control
    enable_architect: bool = True   # Enable Architect for this agent
    enable_auditor: bool = True     # Enable Auditor for this agent
    validation_mode: str = "standard"  # 'quick', 'standard', 'thorough'
    
    # 🔴 A-TEAM FIX: Per-agent model override (config-driven, not hardcoded)
    # If None, uses SynapseConfig.default_model (which falls back to dspy.configure LM)
    model: Optional[str] = None  # e.g., 'openai/gpt-4o-mini' for a lightweight agent
    gateway: Optional[str] = None  # e.g., litellm/openai/anthropic/truefoundry
    api_key_env: Optional[str] = None  # Env var name that stores this agent's API key
    api_base_env: Optional[str] = None  # Env var name that stores this agent's API base URL

    # Invariants removed - use Auditor prompts instead for validation
    
    # Critical Agent Control
    is_critical: bool = False
    max_retries: int = 3
    retry_strategy: str = "with_hints"
    
    # SYNAPSE v1.0: Executor flag (replaces hardcoded SQL checks)
    # Set to True for agents that execute actions and return execution metadata
    # (e.g., query executors, API callers, file writers)
    is_executor: bool = False
    
    enabled: bool = True
    
    def __post_init__(self):
        """Initialize with validation."""
        # Ensure prompts are lists
        if self.architect_prompts is None:
            self.architect_prompts = []
        if self.auditor_prompts is None:
            self.auditor_prompts = []
