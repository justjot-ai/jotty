"""
SmartAgentSlack: Intelligent Agent Communication Layer

CRITICAL: This is NOT just a message bus. It's a SMART layer that:
1. Knows what format each agent wants (from signatures)
2. Auto-transforms data (using internal Transformer)
3. Auto-chunks huge files (using internal Chunker)
4. Auto-compresses context (using internal Compressor)
5. Manages message history
6. Handles ALL communication nuances
7. 🆕 FILE MODE: Large files (WAV, images, etc.) saved to shared storage, paths sent instead

User Insight: "It's a SMART Slack that knows what format and type 
the other agent is comfortable with"

Author: A-Team (Turing, Nash, Sutton, Chomsky, Modern AI Engineers)
Date: December 27, 2025
Updated: February 2, 2026 - Added file mode for large binary files
"""

import logging
import time
import uuid
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable, Tuple, AsyncGenerator, Union
from dataclasses import dataclass, field
from datetime import datetime
import dspy
import json
import sys
import os

# 🆕 Tiered file storage for large binary file transfer
from .file_storage import (
    TieredFileStorage,
    FileReference,
    ContentTypeDetector,
    is_binary_content_type,
    should_use_file_mode
)

logger = logging.getLogger(__name__)


@dataclass
class AgentCapabilities:
    """
    What an agent can handle (extracted from signature automatically).
    
    Agent Slack reads the agent's DSPy signature to understand:
    - What formats it prefers
    - What size limits it has
    - What context budget it has
    
    ZERO manual configuration needed!
    """
    agent_name: str
    preferred_format: str
    acceptable_formats: List[str]
    max_input_size: int  # bytes
    max_context_tokens: int
    
    def can_accept_format(self, format: str) -> bool:
        """Check if agent can accept this format."""
        return format in self.acceptable_formats
    
    def needs_compression(self, current_tokens: int) -> bool:
        """Check if context needs compression.
        
        🔴 A-TEAM FIX: Was hardcoded 70% — now uses configurable threshold.
        Default 80% of max context tokens (triggers compression before hitting limit).
        """
        threshold = getattr(self, 'compression_threshold', 0.8)
        return current_tokens > (self.max_context_tokens * threshold)


@dataclass
class Message:
    """Message passed between agents."""
    from_agent: str
    to_agent: str
    data: Any
    format: str
    size_bytes: int
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __str__(self):
        return f"Message({self.from_agent} → {self.to_agent}, {self.format}, {self.size_bytes}B)"


# =============================================================================
# 🆕 FILE REFERENCE - For large file transfer between agents
# =============================================================================

@dataclass
class FileReference:
    """
    Reference to a file in shared storage.
    
    Instead of sending large binary data (WAV, images, videos) directly,
    agents save to shared storage and send this reference.
    
    Benefits:
    - No memory explosion (file stays on disk)
    - Lazy loading (receiver loads when needed)
    - Integrity checking (SHA256 checksum)
    - Clean paths (predictable location)
    """
    path: str  # Absolute path to file
    content_type: str  # MIME type: 'audio/wav', 'image/png', etc.
    size_bytes: int
    checksum: Optional[str] = None  # SHA256 for integrity verification
    original_filename: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    
    def exists(self) -> bool:
        """Check if file still exists."""
        return os.path.exists(self.path)
    
    def read_bytes(self) -> bytes:
        """Read file as bytes (lazy loading)."""
        if not self.exists():
            raise FileNotFoundError(f"File not found: {self.path}")
        with open(self.path, 'rb') as f:
            return f.read()
    
    def read_text(self, encoding: str = 'utf-8') -> str:
        """Read file as text."""
        if not self.exists():
            raise FileNotFoundError(f"File not found: {self.path}")
        with open(self.path, 'r', encoding=encoding) as f:
            return f.read()
    
    def verify_checksum(self) -> bool:
        """Verify file integrity using checksum."""
        if not self.checksum:
            return True  # No checksum to verify
        if not self.exists():
            return False
        actual = hashlib.sha256(self.read_bytes()).hexdigest()
        return actual == self.checksum
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for message payload."""
        return {
            'type': 'file_reference',
            'path': self.path,
            'content_type': self.content_type,
            'size_bytes': self.size_bytes,
            'checksum': self.checksum,
            'original_filename': self.original_filename,
            'metadata': self.metadata,
            'created_at': self.created_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FileReference':
        """Create from dictionary."""
        return cls(
            path=data['path'],
            content_type=data['content_type'],
            size_bytes=data['size_bytes'],
            checksum=data.get('checksum'),
            original_filename=data.get('original_filename'),
            metadata=data.get('metadata', {}),
            created_at=data.get('created_at', time.time())
        )
    
    @staticmethod
    def is_file_reference(data: Any) -> bool:
        """Check if data is a file reference dict."""
        return (
            isinstance(data, dict) and 
            data.get('type') == 'file_reference' and
            'path' in data
        )


# =============================================================================
# 🆕 SHARED FILE STORAGE - Clean paths for inter-agent file transfer
# =============================================================================

class SharedFileStorage:
    """
    Shared file storage for large file transfer between agents.
    
    Provides:
    - Clean, predictable paths: /tmp/synapse_shared/{uuid}_{filename}
    - Automatic checksum generation
    - TTL-based cleanup
    - Content type inference
    
    Usage:
        storage = SharedFileStorage()
        ref = storage.save(audio_bytes, "speech.wav", "audio/wav")
        # ref.path = "/tmp/synapse_shared/a1b2c3d4_speech.wav"
    """
    
    # Magic numbers for content type detection
    MAGIC_NUMBERS = {
        b'RIFF': 'audio/wav',
        b'\xff\xd8\xff': 'image/jpeg',
        b'\x89PNG\r\n\x1a\n': 'image/png',
        b'GIF87a': 'image/gif',
        b'GIF89a': 'image/gif',
        b'%PDF': 'application/pdf',
        b'PK\x03\x04': 'application/zip',
        b'\x1f\x8b': 'application/gzip',
        b'ID3': 'audio/mpeg',
        b'\xff\xfb': 'audio/mpeg',
        b'OggS': 'audio/ogg',
        b'fLaC': 'audio/flac',
        b'\x00\x00\x00': 'video/mp4',  # Partial match for MP4/MOV
    }
    
    def __init__(self, base_path: str = "/tmp/synapse_shared"):
        """
        Initialize shared file storage.
        
        Args:
            base_path: Base directory for file storage
        """
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.file_registry: Dict[str, FileReference] = {}
        self._cleanup_threshold = 3600  # 1 hour default TTL
        logger.info(f"📁 [SHARED STORAGE] Initialized at {self.base_path}")
    
    def save(
        self,
        data: bytes,
        filename: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict] = None,
        compute_checksum: bool = True
    ) -> FileReference:
        """
        Save data to shared storage and return file reference.
        
        Args:
            data: Binary data to save
            filename: Original filename (for extension and identification)
            content_type: MIME type (auto-detected if not provided)
            metadata: Optional metadata dict
            compute_checksum: Whether to compute SHA256 checksum
            
        Returns:
            FileReference pointing to saved file
        """
        # Generate unique filename with clean path
        unique_id = str(uuid.uuid4())[:8]
        safe_filename = self._sanitize_filename(filename)
        clean_path = self.base_path / f"{unique_id}_{safe_filename}"
        
        # Write file
        with open(clean_path, 'wb') as f:
            f.write(data)
        
        # Auto-detect content type if not provided
        if content_type is None:
            content_type = self._infer_content_type(data, filename)
        
        # Compute checksum
        checksum = hashlib.sha256(data).hexdigest() if compute_checksum else None
        
        # Create reference
        ref = FileReference(
            path=str(clean_path),
            content_type=content_type,
            size_bytes=len(data),
            checksum=checksum,
            original_filename=filename,
            metadata=metadata or {}
        )
        
        # Register for tracking
        self.file_registry[ref.path] = ref
        
        logger.info(f"📁 [SHARED STORAGE] Saved: {ref.path} ({len(data)} bytes, {content_type})")
        return ref
    
    def save_from_path(
        self,
        source_path: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> FileReference:
        """
        Copy file from source path to shared storage.
        
        Args:
            source_path: Path to source file
            content_type: MIME type (auto-detected if not provided)
            metadata: Optional metadata dict
            
        Returns:
            FileReference pointing to saved file
        """
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source_path}")
        
        with open(source, 'rb') as f:
            data = f.read()
        
        return self.save(
            data=data,
            filename=source.name,
            content_type=content_type,
            metadata=metadata
        )
    
    def get(self, path: str) -> Optional[FileReference]:
        """Get file reference by path."""
        return self.file_registry.get(path)
    
    def load(self, ref: Union[FileReference, Dict, str]) -> bytes:
        """
        Load file data from reference.
        
        Args:
            ref: FileReference, dict, or path string
            
        Returns:
            File contents as bytes
        """
        if isinstance(ref, str):
            path = ref
        elif isinstance(ref, dict):
            path = ref['path']
        else:
            path = ref.path
        
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
        
        with open(path, 'rb') as f:
            return f.read()
    
    def delete(self, ref: Union[FileReference, str]) -> bool:
        """Delete file from storage."""
        path = ref.path if isinstance(ref, FileReference) else ref
        
        try:
            if os.path.exists(path):
                os.remove(path)
            if path in self.file_registry:
                del self.file_registry[path]
            logger.info(f"🗑️ [SHARED STORAGE] Deleted: {path}")
            return True
        except Exception as e:
            logger.error(f"❌ [SHARED STORAGE] Delete failed: {e}")
            return False
    
    def cleanup(self, max_age_seconds: Optional[int] = None):
        """
        Remove files older than max_age.
        
        Args:
            max_age_seconds: Max age in seconds (uses default if not provided)
        """
        max_age = max_age_seconds or self._cleanup_threshold
        now = time.time()
        removed = 0
        
        for path in list(self.file_registry.keys()):
            if os.path.exists(path):
                age = now - os.path.getmtime(path)
                if age > max_age:
                    self.delete(path)
                    removed += 1
        
        if removed > 0:
            logger.info(f"🧹 [SHARED STORAGE] Cleaned up {removed} old files")
    
    def list_files(self) -> List[FileReference]:
        """List all files in storage."""
        return list(self.file_registry.values())
    
    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        total_size = sum(ref.size_bytes for ref in self.file_registry.values())
        return {
            'base_path': str(self.base_path),
            'file_count': len(self.file_registry),
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2)
        }
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe path creation."""
        # Remove path separators and special characters
        safe = "".join(c for c in filename if c.isalnum() or c in '._-')
        return safe or 'file'
    
    def _infer_content_type(self, data: bytes, filename: str) -> str:
        """Infer content type from data magic numbers or filename extension."""
        # Try magic number detection first
        for magic, content_type in self.MAGIC_NUMBERS.items():
            if data.startswith(magic):
                return content_type
        
        # Fall back to extension-based detection
        ext = Path(filename).suffix.lower()
        ext_types = {
            '.wav': 'audio/wav',
            '.mp3': 'audio/mpeg',
            '.ogg': 'audio/ogg',
            '.flac': 'audio/flac',
            '.m4a': 'audio/mp4',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
            '.svg': 'image/svg+xml',
            '.bmp': 'image/bmp',
            '.mp4': 'video/mp4',
            '.webm': 'video/webm',
            '.mov': 'video/quicktime',
            '.avi': 'video/x-msvideo',
            '.pdf': 'application/pdf',
            '.json': 'application/json',
            '.xml': 'application/xml',
            '.txt': 'text/plain',
            '.html': 'text/html',
            '.css': 'text/css',
            '.js': 'application/javascript',
            '.py': 'text/x-python',
            '.csv': 'text/csv',
            '.zip': 'application/zip',
            '.tar': 'application/x-tar',
            '.gz': 'application/gzip',
        }
        
        return ext_types.get(ext, 'application/octet-stream')


class MessageBus:
    """Simple pub/sub message bus."""
    
    def __init__(self):
        self.subscribers: Dict[str, Callable] = {}
        self.message_count = 0
        logger.info("📡 [MESSAGE BUS] Initialized")
        
    def subscribe(self, agent_name: str, callback: Callable):
        """Subscribe agent to messages."""
        self.subscribers[agent_name] = callback
        logger.debug(f"📡 [MESSAGE BUS] Subscribed: {agent_name}")
        
    def publish(self, message: Message):
        """Publish message to target agent."""
        self.message_count += 1
        target = message.to_agent
        
        if target not in self.subscribers:
            logger.error(f"❌ [MESSAGE BUS] No subscriber: {target}")
            return False
            
        try:
            callback = self.subscribers[target]
            callback(message)
            logger.debug(f"✅ [MESSAGE BUS] Delivered #{self.message_count}: {message}")
            return True
        except Exception as e:
            logger.error(f"❌ [MESSAGE BUS] Delivery failed: {e}")
            return False


class FormatRegistry:
    """Tracks format preferences for all agents."""
    
    def __init__(self):
        self.registry: Dict[str, AgentCapabilities] = {}
        logger.info("📋 [FORMAT REGISTRY] Initialized")
        
    def register(self, agent_name: str, capabilities: AgentCapabilities):
        """Register agent's capabilities."""
        self.registry[agent_name] = capabilities
        logger.debug(f"📋 [FORMAT REGISTRY] Registered: {agent_name}")
        
    def get_capabilities(self, agent_name: str) -> Optional[AgentCapabilities]:
        """Get agent's capabilities."""
        return self.registry.get(agent_name)


class SmartAgentSlack:
    """
    INTELLIGENT agent communication layer with embedded helper agents.
    
    This is the KEY component for inter-agent communication. It:
    1. Auto-detects format needs from agent signatures
    2. Has Transformer agent internally (for format conversion)
    3. Has Chunker agent internally (for large file handling)
    4. Has Compressor agent internally (for context management)
    5. Manages message history and context budgets
    6. Handles ALL communication nuances automatically
    7. 🆕 Tracks cooperation events for credit assignment
    8. 🆕 Enables Nash Equilibrium communication decisions
    9. 🆕 FILE MODE: Large files (>1MB or binary) saved to shared storage, paths sent
    
    Agents just send/receive - Agent Slack handles the rest!
    """
    
    # Default threshold for file mode (1MB)
    DEFAULT_FILE_MODE_THRESHOLD = 1_000_000  # 1MB
    
    def __init__(self, config: Optional[Dict] = None, enable_cooperation: bool = True):
        """
        Initialize SmartAgentSlack with embedded helper agents.
        
        Args:
            config: Optional config dict with:
                - lm: Language model for helper agents
                - shared_storage_path: Path for file storage (default: /tmp/synapse_shared)
                - file_mode_threshold: Size threshold for file mode (default: 1MB)
                - enable_file_mode: Enable automatic file mode (default: True)
            enable_cooperation: Enable cooperation tracking (default: True)
        """
        # Core infrastructure
        self.message_bus = MessageBus()
        self.format_registry = FormatRegistry()
        
        # Message history (for context management & compression)
        self.message_history: List[Message] = []
        self.context_budget_tracker: Dict[str, int] = {}  # agent_name -> current_tokens
        
        # Agent capabilities registry
        self.agent_capabilities: Dict[str, AgentCapabilities] = {}
        
        # 🔥 CRITICAL: Agent Slack HAS helper agents internally!
        # These are initialized lazily when first needed
        self._transformer = None
        self._chunker = None
        self._compressor = None
        self._config = config or {}
        
        # 🆕 COOPERATION TRACKING
        self.enable_cooperation = enable_cooperation
        self.cooperation_events: List[Dict] = []  # Track all cooperation events
        self.help_matrix: Dict[Tuple[str, str], int] = {}  # (from, to) -> count
        self.communication_log: List[Dict] = []  # Track communication decisions for learning
        
        # 🆕 TIERED FILE STORAGE for large binary files (WAV, images, etc.)
        # A-TEAM FIX: Single file_storage initialization (was duplicated before)
        storage_path = self._config.get('storage_path', self._config.get('shared_storage_path', '/tmp/synapse_shared'))
        self.file_storage = TieredFileStorage(base_path=storage_path)
        self.file_mode_threshold = self._config.get('file_mode_threshold', self.DEFAULT_FILE_MODE_THRESHOLD)
        self.enable_file_mode = self._config.get('enable_file_mode', True)
        
        # 🆕 DELIVERY RECEIPTS: Track message delivery confirmations
        self.delivery_receipts: Dict[str, Dict] = {}  # message_id -> receipt
        self._message_retry_limit = 3
        
        # 🧠 A-TEAM ENHANCEMENT E3: Request-Response Tracking
        # Tracks pending requests so sender knows when receiver responds
        # Enables orchestrator-mediated round-trip collaboration
        self.pending_requests: Dict[str, Dict] = {}  # request_id -> {from, to, query, status, response}
        self.completed_responses: Dict[str, Dict] = {}  # request_id -> {response, timestamp}
        
        logger.info("💬 [SMART AGENT SLACK] Initialized")
        logger.info("  📊 Core: MessageBus + FormatRegistry ready")
        logger.info("  🔧 Helpers: Transformer, Chunker, Compressor (lazy-init)")
        logger.info(f"  📁 File Storage: {storage_path} (threshold: {self.file_mode_threshold:,} bytes)")
        if enable_cooperation:
            logger.info("  🤝 Cooperation: Tracking enabled")
        # Note: __init__ cannot yield, but initialization is logged
        
    @property
    def transformer(self):
        """Lazy-init Transformer agent."""
        if self._transformer is None:
            logger.info("🔧 [SMART AGENT SLACK] Lazy-initializing Transformer...")
            from .smart_data_transformer import SmartDataTransformer
            # Get LM from config or use global DSPy LM
            lm = self._config.get('lm') if self._config else None
            if lm is None:
                try:
                    import dspy
                    lm = dspy.settings.lm
                except (ImportError, AttributeError):
                    pass
            self._transformer = SmartDataTransformer(lm=lm)
            logger.info("  ✅ [HELPER] Transformer initialized")
        return self._transformer
    
    @property
    def chunker(self):
        """Lazy-init Chunker agent."""
        if self._chunker is None:
            logger.info("🔧 [SMART AGENT SLACK] Lazy-initializing Chunker...")
            from .unified_chunker import UnifiedChunker
            # Get LM from config or use global DSPy LM
            lm = self._config.get('lm') if self._config else None
            if lm is None:
                try:
                    import dspy
                    lm = dspy.settings.lm
                except (ImportError, AttributeError):
                    pass
            self._chunker = UnifiedChunker()
            logger.info("  ✅ [HELPER] Chunker initialized")
        return self._chunker
    
    @property
    def compressor(self):
        """Lazy-init Compressor agent."""
        if self._compressor is None:
            logger.info("🔧 [SMART AGENT SLACK] Lazy-initializing Compressor...")
            from .unified_compression import UnifiedCompressor
            # Get LM from config or use global DSPy LM
            lm = self._config.get('lm') if self._config else None
            synapse_config = self._config.get('synapse_config') if self._config else None
            if lm is None:
                try:
                    import dspy
                    lm = dspy.settings.lm
                except (ImportError, AttributeError):
                    pass
            self._compressor = UnifiedCompressor(lm=lm, config=synapse_config)
            logger.info("  ✅ [HELPER] Compressor initialized")
        return self._compressor
        
    def register_agent(
        self,
        agent_name: str,
        signature: Optional[dspy.Signature] = None,
        max_context: int = 16000,
        callback: Optional[Callable] = None,
        capabilities: Optional[AgentCapabilities] = None
    ):
        """
        Register agent and AUTOMATICALLY extract capabilities from signature.
        
        This is the KEY: Agent Slack READS the signature to understand:
        - What formats agent accepts
        - What size limits agent has
        - What data types agent expects
        - ALL automatically from signature!
        
        Args:
            agent_name: Name of the agent
            signature: DSPy signature (will extract capabilities from it)
            max_context: Max context window in tokens
            callback: Callback for receiving messages
            capabilities: Explicitly provided capabilities (if signature not available)
        """
        logger.info(f"📋 [AGENT SLACK] Registering '{agent_name}'")
        
        # Extract or use provided capabilities
        if capabilities:
            caps = capabilities
        elif signature:
            caps = self._extract_capabilities_from_signature(
                agent_name=agent_name,
                signature=signature,
                max_context=max_context
            )
        else:
            # Default capabilities
            caps = AgentCapabilities(
                agent_name=agent_name,
                preferred_format="dict",
                acceptable_formats=["dict", "str"],
                max_input_size=max_context * 4,  # Rough: 1 token ≈ 4 bytes
                max_context_tokens=max_context
            )
        
        self.agent_capabilities[agent_name] = caps
        self.context_budget_tracker[agent_name] = 0
        self.format_registry.register(agent_name, caps)
        
        if callback:
            self.message_bus.subscribe(agent_name, callback)
        
        # Log what we learned about this agent
        logger.info(f"  📊 Capabilities:")
        logger.info(f"    • Preferred format: {caps.preferred_format}")
        logger.info(f"    • Accepts formats: {caps.acceptable_formats}")
        logger.info(f"    • Max input size: {caps.max_input_size} bytes")
        logger.info(f"    • Max context: {caps.max_context_tokens} tokens")
        logger.info(f"  ✅ Registered successfully")
        
    async def send_stream(
        self,
        from_agent: str,
        to_agent: str,
        data: Any,
        field_name: str = "data",
        metadata: Optional[Dict] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        SMART SEND: Handles ALL communication nuances automatically with event streaming.
        
        WORKFLOW:
        1. Check target's format preference (from signature)
        2. Check if transformation needed → invoke internal Transformer
        3. Check if chunking needed → invoke internal Chunker
        4. Check if target's context full → invoke internal Compressor for target
        5. Deliver message
        6. Update context tracking
        
        ALL AUTOMATIC - agents don't need to worry about ANY of this!
        
        Args:
            from_agent: Sender agent name
            to_agent: Receiver agent name
            data: Data to send
            field_name: Name of the field (for metadata)
            metadata: Optional metadata dict
            
        Yields:
            Event dictionaries with module and conversational message
        Returns:
            True if message delivered successfully
        """
        logger.info(f"💬 [SMART AGENT SLACK] {from_agent} → {to_agent}")
        yield {"module": "Synapse.core.axon", "message": f"I am sending a message from {from_agent} to {to_agent}"}
        
        # Get target's capabilities (what they need)
        target_caps = self.agent_capabilities.get(to_agent)
        if not target_caps:
            logger.error(f"❌ Unknown agent: {to_agent} (not registered)")
            yield {"module": "Synapse.core.axon", "message": f"I encountered an error: unknown agent {to_agent}"}
            logger.error(f"   Known agents: {list(self.agent_capabilities.keys())}")
            yield {"type": "result", "result": False, "module": "Synapse.core.axon", "message": "I am returning failure status"}
            return
            
        # STEP 1: Check if target's context is getting full
        target_context = self.context_budget_tracker.get(to_agent, 0)
        target_max = target_caps.max_context_tokens
        
        if target_caps.needs_compression(target_context):
            logger.info(f"  ⚠️  {to_agent}'s context at {target_context}/{target_max} ({int(target_context/target_max*100)}%)")
            yield {"module": "Synapse.core.axon", "message": f"I noticed {to_agent}'s context is getting full at {int(target_context/target_max*100)}%"}
            if self.compressor:
                logger.info(f"  🗜️  [AUTO] Invoking internal Compressor for {to_agent}")
                yield {"module": "Synapse.core.axon", "message": f"I am invoking the internal Compressor for {to_agent}"}
                self._compress_agent_context(to_agent)
            else:
                logger.warning(f"  ⚠️  [AUTO] Compressor not available (skipping)")
                yield {"module": "Synapse.core.axon", "message": "I noticed the Compressor is not available"}
            
        # STEP 2: Detect current data format
        current_format = self._detect_format(data)
        current_size = self._estimate_size(data)
        logger.info(f"  📊 Data: format={current_format}, size={current_size} bytes")
        yield {"module": "Synapse.core.axon", "message": f"I detected data format {current_format} with size {current_size} bytes"}
        
        # 🆕 STEP 2.5: Check if file mode should be used
        # CRITICAL: Binary data (bytes) MUST use file mode - UnifiedChunker is TEXT ONLY!
        use_file_mode = should_use_file_mode(data, current_size, self.file_mode_threshold)
        
        if use_file_mode:
            logger.info(f"  📁 [FILE MODE] Using file storage for large/binary data ({current_size:,} bytes)")
            yield {"module": "Synapse.core.axon", "message": f"I am using file storage for this data ({current_size:,} bytes)"}
            
            # Determine filename and content type
            filename = (metadata or {}).get('filename', f'{field_name}.bin')
            content_type = self._infer_content_type(data, metadata, filename)
            
            # Convert to bytes if needed
            if isinstance(data, (dict, list)):
                data_bytes = json.dumps(data).encode('utf-8')
                content_type = 'application/json'
            elif isinstance(data, str):
                data_bytes = data.encode('utf-8')
                if content_type == 'application/octet-stream':
                    content_type = 'text/plain'
            else:
                data_bytes = data  # Already bytes
            
            # Save to tiered file storage
            file_ref = self.file_storage.save(
                data=data_bytes,
                filename=filename,
                content_type=content_type,
                metadata=metadata
            )
            
            logger.info(f"  📁 Saved to storage: {file_ref.file_id[:8]}... ({file_ref.content_type})")
            yield {"module": "Synapse.core.axon", "message": f"I saved the file to storage with ID {file_ref.file_id[:8]}..."}
            
            # Replace data with file reference payload (small message)
            data = file_ref.to_message_payload()
            current_format = 'file_reference'
            current_size = self._estimate_size(data)
            
            # Skip transformation and chunking for file references
            # (file references are small dict payloads, always acceptable)
        
        # STEP 3: Check if format transformation needed
        # Skip for file_reference (already handled above)
        if current_format != 'file_reference' and not target_caps.can_accept_format(current_format):
            target_format = target_caps.preferred_format
            logger.info(f"  🔄 [AUTO] Format mismatch: '{current_format}' not in {target_caps.acceptable_formats}")
            yield {"module": "Synapse.core.axon", "message": f"I detected a format mismatch, need to transform from {current_format} to {target_format}"}
            logger.info(f"  🔄 [AUTO] Invoking internal Transformer: {current_format} → {target_format}")
            yield {"module": "Synapse.core.axon", "message": f"I am invoking the internal Transformer to convert {current_format} to {target_format}"}
            
            try:
                transformed_data = self.transformer.transform(
                    data=data,
                    target_format=target_format,
                    source_agent=from_agent,
                    target_agent=to_agent
                )
                
                data = transformed_data
                current_format = target_format
                current_size = self._estimate_size(data)
                logger.info(f"  ✅ Transformed: new size={current_size} bytes, format={current_format}")
                yield {"module": "Synapse.core.axon", "message": f"I have successfully transformed the data to {current_format}, new size is {current_size} bytes"}
            except Exception as e:
                logger.error(f"  ❌ Transformation failed: {e}")
                yield {"module": "Synapse.core.axon", "message": f"I encountered an error during transformation: {str(e)}"}
                logger.info(f"  ℹ️  Proceeding with original format (may cause issues)")
            
        # STEP 4: Check if chunking needed (data too large for target)
        # CRITICAL: Skip for file_reference (already a small payload)
        # CRITICAL: UnifiedChunker is TEXT ONLY - do NOT chunk binary data!
        if current_format != 'file_reference' and current_size > target_caps.max_input_size:
            logger.info(f"  🔧 [AUTO] Data too large: {current_size} > {target_caps.max_input_size}")
            yield {"module": "Synapse.core.axon", "message": f"I noticed the data is too large ({current_size} > {target_caps.max_input_size}), need to handle it"}
            
            # SAFEGUARD: Check if format is text-based before chunking
            # UnifiedChunker uses token counting - ONLY works on text!
            text_formats = ('str', 'dict', 'list', 'json', 'text')
            
            if current_format in text_formats and self.chunker:
                # TEXT data - safe to chunk
                logger.info(f"  🔧 [AUTO] Invoking internal Chunker for text data")
                yield {"module": "Synapse.core.axon", "message": "I am invoking the internal Chunker for text data"}
                
                try:
                    chunked_file = self.chunker.chunk_and_consolidate(
                        data=data,
                        goal=f"Prepare data for {to_agent}",
                        target_agent_context=target_caps,
                        max_chunk_size=target_caps.max_input_size
                    )
                    
                    data = chunked_file
                    current_size = self._estimate_size(data)
                    logger.info(f"  ✅ Chunked: new size={current_size} bytes")
                    yield {"module": "Synapse.core.axon", "message": f"I have successfully chunked the data, new size is {current_size} bytes"}
                except Exception as e:
                    logger.error(f"  ❌ Chunking failed: {e}")
                    yield {"module": "Synapse.core.axon", "message": f"I encountered an error during chunking: {str(e)}"}
                    logger.info(f"  ℹ️  Proceeding with original data (may exceed limits)")
            elif current_format == 'bytes' or current_format not in text_formats:
                # BINARY data - cannot chunk! Use file mode instead
                logger.warning(f"  ⚠️ [AUTO] Cannot chunk binary/unknown format '{current_format}', using file mode")
                yield {"module": "Synapse.core.axon", "message": f"I cannot chunk binary format '{current_format}', switching to file mode"}
                
                # Convert to bytes and save to file storage
                if isinstance(data, bytes):
                    data_bytes = data
                else:
                    data_bytes = str(data).encode('utf-8')
                
                filename = (metadata or {}).get('filename', f'{field_name}.bin')
                file_ref = self.file_storage.save(
                    data=data_bytes,
                    filename=filename,
                    content_type='application/octet-stream',
                    metadata=metadata
                )
                
                data = file_ref.to_message_payload()
                current_format = 'file_reference'
                current_size = self._estimate_size(data)
                logger.info(f"  📁 Saved to file storage: {file_ref.file_id[:8]}...")
                yield {"module": "Synapse.core.axon", "message": f"I saved the data to file storage with ID {file_ref.file_id[:8]}..."}
            else:
                logger.warning(f"  ⚠️  [AUTO] Chunker not available (data may exceed limits)")
                yield {"module": "Synapse.core.axon", "message": "I noticed the Chunker is not available"}
            
        # STEP 5: Deliver message with retry and receipt tracking
        message_id = str(uuid.uuid4())
        message = Message(
            from_agent=from_agent,
            to_agent=to_agent,
            data=data,
            format=current_format,
            size_bytes=current_size,
            timestamp=time.time(),
            metadata={**(metadata or {}), 'message_id': message_id}
        )
        
        yield {"module": "Synapse.core.axon", "message": "I am delivering the message to the target agent"}
        
        # A-TEAM FIX: Retry delivery up to _message_retry_limit times
        success = False
        delivery_attempts = 0
        last_error = None
        
        for attempt in range(self._message_retry_limit):
            delivery_attempts = attempt + 1
            try:
                success = self.message_bus.publish(message)
                if success:
                    break
                last_error = "Message bus publish returned False"
            except Exception as e:
                last_error = str(e)
                logger.warning(f"  ⚠️ Delivery attempt {delivery_attempts} failed: {e}")
                if attempt < self._message_retry_limit - 1:
                    yield {"module": "Synapse.core.axon", "message": f"Delivery attempt {delivery_attempts} failed, retrying..."}
        
        # A-TEAM FIX: Record delivery receipt
        receipt = {
            'message_id': message_id,
            'from_agent': from_agent,
            'to_agent': to_agent,
            'delivered': success,
            'attempts': delivery_attempts,
            'timestamp': time.time(),
            'size_bytes': current_size,
            'format': current_format,
            'error': last_error if not success else None
        }
        self.delivery_receipts[message_id] = receipt
        
        if success:
            # STEP 6: Update context tracking
            data_tokens = self._estimate_tokens(data)
            self.context_budget_tracker[to_agent] = self.context_budget_tracker.get(to_agent, 0) + data_tokens
            self.message_history.append(message)
            
            # 🆕 COOPERATION TRACKING
            if self.enable_cooperation:
                self._record_cooperation_event(
                    event_type='share',
                    from_agent=from_agent,
                    to_agent=to_agent,
                    description=f"Shared {field_name} ({current_size} bytes)",
                    impact=1.0  # Positive impact (helping)
                )
            
            logger.info(f"  📨 Message delivered successfully (receipt: {message_id[:8]}..., attempts: {delivery_attempts})")
            yield {"module": "Synapse.core.axon", "message": f"I have successfully delivered the message to {to_agent} (receipt: {message_id[:8]}...)"}
            logger.info(f"  📊 {to_agent} context now: {self.context_budget_tracker[to_agent]}/{target_max} tokens")
            yield {"module": "Synapse.core.axon", "message": f"{to_agent}'s context is now at {self.context_budget_tracker[to_agent]}/{target_max} tokens"}
        else:
            logger.error(f"  ❌ Message delivery failed after {delivery_attempts} attempts: {last_error}")
            yield {"module": "Synapse.core.axon", "message": f"I encountered an error: message delivery failed after {delivery_attempts} attempts"}
        
        yield {"type": "result", "result": success, "receipt": receipt, "module": "Synapse.core.axon", "message": f"I am returning delivery status: {'success' if success else 'failed'}"}
        return
    
    async def send_files_stream(
        self,
        from_agent: str,
        to_agent: str,
        files: List[Dict[str, Any]],
        metadata: Optional[Dict] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        A-TEAM FIX: Send multiple files to an agent in a single operation.
        
        This enables complete file transfer between agents with delivery confirmation.
        Each file is sent via file storage (TieredFileStorage) and the recipient
        receives a manifest with all file references.
        
        Args:
            from_agent: Sender agent name
            to_agent: Receiver agent name
            files: List of file dicts, each with:
                - 'data': File content (bytes, str, dict, list)
                - 'filename': Name of the file
                - 'content_type': Optional MIME type
                - 'metadata': Optional per-file metadata
            metadata: Optional overall metadata dict
            
        Yields:
            Event dictionaries with progress and results
        """
        logger.info(f"📁 [AGENT SLACK] Sending {len(files)} files: {from_agent} → {to_agent}")
        yield {"module": "Synapse.core.axon", "message": f"I am sending {len(files)} files from {from_agent} to {to_agent}"}
        
        file_refs = []
        errors = []
        
        for i, file_info in enumerate(files):
            filename = file_info.get('filename', f'file_{i}.bin')
            content_type = file_info.get('content_type', 'application/octet-stream')
            file_data = file_info.get('data', b'')
            file_meta = file_info.get('metadata', {})
            
            try:
                # Convert to bytes if needed
                if isinstance(file_data, (dict, list)):
                    data_bytes = json.dumps(file_data).encode('utf-8')
                    content_type = content_type or 'application/json'
                elif isinstance(file_data, str):
                    data_bytes = file_data.encode('utf-8')
                    content_type = content_type or 'text/plain'
                else:
                    data_bytes = file_data
                
                # Save to tiered file storage
                file_ref = self.file_storage.save(
                    data=data_bytes,
                    filename=filename,
                    content_type=content_type,
                    metadata=file_meta
                )
                
                file_refs.append({
                    'file_id': file_ref.file_id,
                    'filename': filename,
                    'content_type': content_type,
                    'size_bytes': len(data_bytes),
                    'checksum': file_ref.checksum if hasattr(file_ref, 'checksum') else None
                })
                
                logger.info(f"  📁 [{i+1}/{len(files)}] Saved: {filename} ({len(data_bytes):,} bytes)")
                yield {"module": "Synapse.core.axon", "message": f"Saved file {i+1}/{len(files)}: {filename}"}
                
            except Exception as e:
                logger.error(f"  ❌ [{i+1}/{len(files)}] Failed: {filename}: {e}")
                errors.append({'filename': filename, 'error': str(e)})
                yield {"module": "Synapse.core.axon", "message": f"Failed to save file {filename}: {str(e)}"}
        
        if not file_refs:
            yield {"type": "result", "result": False, "module": "Synapse.core.axon", 
                   "message": "All file transfers failed", "errors": errors}
            return
        
        # Create manifest message with all file references
        manifest = {
            'type': 'file_manifest',
            'from_agent': from_agent,
            'total_files': len(files),
            'successful_files': len(file_refs),
            'failed_files': len(errors),
            'files': file_refs,
            'errors': errors if errors else None,
            'metadata': metadata
        }
        
        # Send manifest as a single message
        async for event in self.send_stream(
            from_agent=from_agent,
            to_agent=to_agent,
            data=manifest,
            field_name="file_manifest",
            metadata={'type': 'file_manifest', **(metadata or {})}
        ):
            yield event
    
    def get_delivery_receipt(self, message_id: str) -> Optional[Dict]:
        """
        Get delivery receipt for a message.
        
        Args:
            message_id: The message ID from a previous send
            
        Returns:
            Receipt dict or None if not found
        """
        return self.delivery_receipts.get(message_id)
    
    def get_all_receipts(self, from_agent: Optional[str] = None, to_agent: Optional[str] = None) -> List[Dict]:
        """
        Get all delivery receipts, optionally filtered by agent.
        
        Args:
            from_agent: Filter by sender
            to_agent: Filter by receiver
            
        Returns:
            List of receipt dicts
        """
        receipts = list(self.delivery_receipts.values())
        if from_agent:
            receipts = [r for r in receipts if r.get('from_agent') == from_agent]
        if to_agent:
            receipts = [r for r in receipts if r.get('to_agent') == to_agent]
        return receipts
    
    # =========================================================================
    # 🧠 A-TEAM ENHANCEMENT E3: Request-Response Tracking
    # Enables orchestrator-mediated round-trip collaboration between agents
    # =========================================================================
    
    async def send_request_stream(
        self,
        from_agent: str,
        to_agent: str,
        query: str,
        data: Any = None,
        metadata: Optional[Dict] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Send a REQUEST to another agent with tracking for response.
        
        Unlike regular send(), this creates a tracked request that the Conductor
        can match with a response. The sender doesn't block — the Conductor
        orchestrates the round-trip by:
        1. Delivering the request
        2. Creating a task for the target agent to respond
        3. Delivering the response back
        
        Args:
            from_agent: Requesting agent name
            to_agent: Target agent name
            query: What the requesting agent needs
            data: Optional supporting data
            metadata: Optional metadata
            
        Yields:
            Events with request_id for tracking
        """
        request_id = str(uuid.uuid4())
        
        # Record the pending request
        self.pending_requests[request_id] = {
            'from_agent': from_agent,
            'to_agent': to_agent,
            'query': query,
            'data': data,
            'status': 'pending',
            'created_at': time.time(),
            'metadata': metadata or {}
        }
        
        logger.info(f"📨 [REQUEST] {from_agent} → {to_agent}: {query[:100]}... (id={request_id[:8]})")
        yield {"module": "Synapse.core.axon", "message": f"I am sending a request from {from_agent} to {to_agent}: {query[:80]}..."}
        
        # Send the actual message via regular channel
        request_payload = {
            'type': 'request',
            'request_id': request_id,
            'from_agent': from_agent,
            'query': query,
            'data': data
        }
        
        async for event in self.send_stream(from_agent, to_agent, request_payload, field_name="request", metadata=metadata):
            if event.get('type') == 'result':
                # Replace result with request_id for tracking
                yield {"type": "result", "result": request_id, "module": "Synapse.core.axon", 
                       "message": f"Request sent successfully (id={request_id[:8]})"}
                return
            yield event
    
    async def send_response_stream(
        self,
        from_agent: str,
        request_id: str,
        response_data: Any,
        metadata: Optional[Dict] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Send a RESPONSE to a previously-received request.
        
        Args:
            from_agent: Responding agent name
            request_id: ID of the request being responded to
            response_data: The response data
            metadata: Optional metadata
            
        Yields:
            Events with delivery status
        """
        request = self.pending_requests.get(request_id)
        if not request:
            logger.error(f"❌ Unknown request_id: {request_id}")
            yield {"module": "Synapse.core.axon", "message": f"I could not find request {request_id[:8]}"}
            yield {"type": "result", "result": False, "module": "Synapse.core.axon", "message": "Request not found"}
            return
        
        to_agent = request['from_agent']  # Response goes back to requester
        
        # Update request status
        request['status'] = 'responded'
        request['response'] = response_data
        request['responded_at'] = time.time()
        
        # Move to completed
        self.completed_responses[request_id] = {
            'request': request,
            'response': response_data,
            'timestamp': time.time(),
            'from_agent': from_agent,
            'to_agent': to_agent
        }
        
        logger.info(f"📬 [RESPONSE] {from_agent} → {to_agent}: responding to request {request_id[:8]}")
        yield {"module": "Synapse.core.axon", "message": f"I am sending response from {from_agent} back to {to_agent}"}
        
        # Send response via regular channel
        response_payload = {
            'type': 'response',
            'request_id': request_id,
            'from_agent': from_agent,
            'data': response_data
        }
        
        async for event in self.send_stream(from_agent, to_agent, response_payload, field_name="response", metadata=metadata):
            yield event
    
    def get_pending_requests(self, agent_name: str) -> List[Dict]:
        """
        Get all pending requests FOR an agent (they need to respond).
        
        Args:
            agent_name: Agent to check pending requests for
            
        Returns:
            List of pending request dicts
        """
        return [
            {'request_id': rid, **req}
            for rid, req in self.pending_requests.items()
            if req['to_agent'] == agent_name and req['status'] == 'pending'
        ]
    
    def get_response(self, request_id: str) -> Optional[Any]:
        """
        Check if a response has been received for a request.
        
        Args:
            request_id: The request ID from send_request_stream
            
        Returns:
            Response data if available, None if still pending
        """
        completed = self.completed_responses.get(request_id)
        if completed:
            return completed['response']
        return None
    
    def get_request_status(self, request_id: str) -> str:
        """Get status of a request: 'pending', 'responded', or 'unknown'."""
        if request_id in self.completed_responses:
            return 'responded'
        req = self.pending_requests.get(request_id)
        if req:
            return req['status']
        return 'unknown'
    
    def read_files_from_manifest(self, manifest: Dict) -> List[Dict[str, Any]]:
        """
        Read all files from a file manifest message.
        
        Args:
            manifest: File manifest dict (from send_files_stream)
            
        Returns:
            List of dicts with 'filename', 'content', 'content_type', 'size_bytes'
        """
        if not isinstance(manifest, dict) or manifest.get('type') != 'file_manifest':
            logger.warning("read_files_from_manifest: data is not a file_manifest")
            return []
        
        results = []
        for file_info in manifest.get('files', []):
            file_id = file_info.get('file_id')
            if not file_id:
                continue
            
            content = self.file_storage.read_file(file_id)
            if content is not None:
                results.append({
                    'filename': file_info.get('filename', 'unknown'),
                    'content': content,
                    'content_type': file_info.get('content_type', 'application/octet-stream'),
                    'size_bytes': file_info.get('size_bytes', len(content))
                })
            else:
                logger.warning(f"  ⚠️ Could not read file: {file_info.get('filename')}")
        
        return results
    
    def send(
        self,
        from_agent: str,
        to_agent: str,
        data: Any,
        field_name: str = "data",
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Synchronous wrapper for send_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use sync version directly
                return self._send_sync(from_agent, to_agent, data, field_name, metadata)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            result = None
            async for event in self.send_stream(from_agent, to_agent, data, field_name, metadata):
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            return result if result is not None else False
        
        return asyncio.run(_run())
    
    def _send_sync(
        self,
        from_agent: str,
        to_agent: str,
        data: Any,
        field_name: str = "data",
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Synchronous implementation (for backward compatibility).
        """
        logger.info(f"💬 [SMART AGENT SLACK] {from_agent} → {to_agent}")
        
        # Get target's capabilities (what they need)
        target_caps = self.agent_capabilities.get(to_agent)
        if not target_caps:
            logger.error(f"❌ Unknown agent: {to_agent} (not registered)")
            logger.error(f"   Known agents: {list(self.agent_capabilities.keys())}")
            return False
            
        # STEP 1: Check if target's context is getting full
        target_context = self.context_budget_tracker.get(to_agent, 0)
        target_max = target_caps.max_context_tokens
        
        if target_caps.needs_compression(target_context):
            logger.info(f"  ⚠️  {to_agent}'s context at {target_context}/{target_max} ({int(target_context/target_max*100)}%)")
            if self.compressor:
                logger.info(f"  🗜️  [AUTO] Invoking internal Compressor for {to_agent}")
                self._compress_agent_context(to_agent)
            else:
                logger.warning(f"  ⚠️  [AUTO] Compressor not available (skipping)")
            
        # STEP 2: Detect current data format
        current_format = self._detect_format(data)
        current_size = self._estimate_size(data)
        logger.info(f"  📊 Data: format={current_format}, size={current_size} bytes")
        
        # 🆕 STEP 2.5: Check if file mode should be used
        # CRITICAL: Binary data (bytes) MUST use file mode - UnifiedChunker is TEXT ONLY!
        use_file_mode = should_use_file_mode(data, current_size, self.file_mode_threshold)
        
        if use_file_mode:
            logger.info(f"  📁 [FILE MODE] Using file storage for large/binary data ({current_size:,} bytes)")
            
            # Determine filename and content type
            filename = (metadata or {}).get('filename', f'{field_name}.bin')
            content_type = self._infer_content_type(data, metadata, filename)
            
            # Convert to bytes if needed
            if isinstance(data, (dict, list)):
                data_bytes = json.dumps(data).encode('utf-8')
                content_type = 'application/json'
            elif isinstance(data, str):
                data_bytes = data.encode('utf-8')
                if content_type == 'application/octet-stream':
                    content_type = 'text/plain'
            else:
                data_bytes = data  # Already bytes
            
            # Save to tiered file storage
            file_ref = self.file_storage.save(
                data=data_bytes,
                filename=filename,
                content_type=content_type,
                metadata=metadata
            )
            
            logger.info(f"  📁 Saved to storage: {file_ref.file_id[:8]}... ({file_ref.content_type})")
            
            # Replace data with file reference payload (small message)
            data = file_ref.to_message_payload()
            current_format = 'file_reference'
            current_size = self._estimate_size(data)
        
        # STEP 3: Check if format transformation needed
        # Skip for file_reference (already handled above)
        if current_format != 'file_reference' and not target_caps.can_accept_format(current_format):
            target_format = target_caps.preferred_format
            logger.info(f"  🔄 [AUTO] Format mismatch: '{current_format}' not in {target_caps.acceptable_formats}")
            logger.info(f"  🔄 [AUTO] Invoking internal Transformer: {current_format} → {target_format}")
            
            try:
                transformed_data = self.transformer.transform(
                    data=data,
                    target_format=target_format,
                    source_agent=from_agent,
                    target_agent=to_agent
                )
                
                data = transformed_data
                current_format = target_format
                current_size = self._estimate_size(data)
                logger.info(f"  ✅ Transformed: new size={current_size} bytes, format={current_format}")
            except Exception as e:
                logger.error(f"  ❌ Transformation failed: {e}")
                logger.info(f"  ℹ️  Proceeding with original format (may cause issues)")
            
        # STEP 4: Check if chunking needed (data too large for target)
        # CRITICAL: Skip for file_reference, and UnifiedChunker is TEXT ONLY!
        if current_format != 'file_reference' and current_size > target_caps.max_input_size:
            logger.info(f"  🔧 [AUTO] Data too large: {current_size} > {target_caps.max_input_size}")
            
            # SAFEGUARD: Check if format is text-based before chunking
            text_formats = ('str', 'dict', 'list', 'json', 'text')
            
            if current_format in text_formats and self.chunker:
                # TEXT data - safe to chunk
                logger.info(f"  🔧 [AUTO] Invoking internal Chunker for text data")
                
                try:
                    chunked_file = self.chunker.chunk_and_consolidate(
                        data=data,
                        goal=f"Prepare data for {to_agent}",
                        target_agent_context=target_caps,
                        max_chunk_size=target_caps.max_input_size
                    )
                    
                    data = chunked_file
                    current_size = self._estimate_size(data)
                    logger.info(f"  ✅ Chunked: new size={current_size} bytes")
                except Exception as e:
                    logger.error(f"  ❌ Chunking failed: {e}")
                    logger.info(f"  ℹ️  Proceeding with original data (may exceed limits)")
            elif current_format == 'bytes' or current_format not in text_formats:
                # BINARY data - cannot chunk! Use file mode instead
                logger.warning(f"  ⚠️ [AUTO] Cannot chunk binary/unknown format '{current_format}', using file mode")
                
                if isinstance(data, bytes):
                    data_bytes = data
                else:
                    data_bytes = str(data).encode('utf-8')
                
                filename = (metadata or {}).get('filename', f'{field_name}.bin')
                file_ref = self.file_storage.save(
                    data=data_bytes,
                    filename=filename,
                    content_type='application/octet-stream',
                    metadata=metadata
                )
                
                data = file_ref.to_message_payload()
                current_format = 'file_reference'
                current_size = self._estimate_size(data)
                logger.info(f"  📁 Saved to file storage: {file_ref.file_id[:8]}...")
            else:
                logger.warning(f"  ⚠️  [AUTO] Chunker not available (data may exceed limits)")
            
        # STEP 5: Deliver message
        message = Message(
            from_agent=from_agent,
            to_agent=to_agent,
            data=data,
            format=current_format,
            size_bytes=current_size,
            timestamp=time.time(),
            metadata=metadata or {}
        )
        
        success = self.message_bus.publish(message)
        
        if success:
            # STEP 6: Update context tracking
            data_tokens = self._estimate_tokens(data)
            self.context_budget_tracker[to_agent] = self.context_budget_tracker.get(to_agent, 0) + data_tokens
            self.message_history.append(message)
            
            # 🆕 COOPERATION TRACKING
            if self.enable_cooperation:
                self._record_cooperation_event(
                    event_type='share',
                    from_agent=from_agent,
                    to_agent=to_agent,
                    description=f"Shared {field_name} ({current_size} bytes)",
                    impact=1.0  # Positive impact (helping)
                )
            
            logger.info(f"  📨 Message delivered successfully")
            logger.info(f"  📊 {to_agent} context now: {self.context_budget_tracker[to_agent]}/{target_max} tokens")
        else:
            logger.error(f"  ❌ Message delivery failed")
        
        return success
        
    def receive(self, agent_name: str) -> List[Message]:
        """
        Get all messages for an agent.
        
        Args:
            agent_name: Agent requesting messages
            
        Returns:
            List of messages for this agent
        """
        messages = [m for m in self.message_history if m.to_agent == agent_name]
        logger.debug(f"📬 [AGENT SLACK] {agent_name} received {len(messages)} messages")
        return messages
        
    def _compress_agent_context(self, agent_name: str):
        """
        Compress an agent's accumulated context using internal Compressor.
        
        This is called automatically when agent hits 70% context budget.
        
        A-TEAM FIX: Uses correct UnifiedCompressor API (content: str, max_tokens: int)
        instead of broken (messages=..., target_ratio=...) call.
        """
        # Get agent's message history
        agent_messages = [m for m in self.message_history if m.to_agent == agent_name]
        
        if not agent_messages:
            logger.debug(f"  ℹ️  No messages to compress for {agent_name}")
            return
            
        # Compress using internal Compressor
        original_tokens = self.context_budget_tracker[agent_name]
        target_tokens = int(original_tokens * 0.5)  # Compress to 50%
        
        # A-TEAM FIX: Serialize messages to text for UnifiedCompressor
        # UnifiedCompressor.compress() takes (content: str, max_tokens: int)
        try:
            message_texts = []
            for m in agent_messages:
                data_str = str(m.data) if not isinstance(m.data, str) else m.data
                message_texts.append(f"[{m.from_agent} → {m.to_agent}]: {data_str}")
            
            combined_context = "\n---\n".join(message_texts)
            
            import asyncio
            
            async def _do_compress():
                return await self.compressor.compress(
                    content=combined_context,
                    max_tokens=target_tokens,
                    task_description=f"Compress accumulated context for agent {agent_name}",
                    purpose="context_management",
                    goal=f"Reduce context from {original_tokens} to {target_tokens} tokens while preserving critical information"
                )
            
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # Can't await in sync context - just estimate reduction
                    new_tokens = target_tokens
                    logger.info(f"  ⚠️ Async loop running, estimated compression for {agent_name}: {original_tokens} → {new_tokens} tokens")
                else:
                    compressed = asyncio.run(_do_compress())
                    new_tokens = self._estimate_tokens(compressed)
                    logger.info(f"  ✅ Compressed {agent_name} context: {original_tokens} → {new_tokens} tokens")
            except RuntimeError:
                # No event loop
                compressed = asyncio.run(_do_compress())
                new_tokens = self._estimate_tokens(compressed)
                logger.info(f"  ✅ Compressed {agent_name} context: {original_tokens} → {new_tokens} tokens")
            
            # Update tracking
            self.context_budget_tracker[agent_name] = new_tokens
            
        except Exception as e:
            logger.error(f"  ❌ Compression failed: {e}")
            # Fallback: just halve the token count estimate
            self.context_budget_tracker[agent_name] = target_tokens
            logger.info(f"  ⚠️ Fallback: estimated {agent_name} context at {target_tokens} tokens")
        
    def _extract_capabilities_from_signature(
        self,
        agent_name: str,
        signature: dspy.Signature,
        max_context: int
    ) -> AgentCapabilities:
        """
        AUTOMATICALLY extract agent's capabilities from its DSPy signature.
        
        This is the MAGIC: We READ the signature to understand everything
        the agent needs, so Agent Slack can handle it automatically!
        
        Args:
            agent_name: Name of the agent
            signature: DSPy signature to analyze
            max_context: Max context window in tokens
            
        Returns:
            AgentCapabilities extracted from signature
        """
        # Default values
        preferred_format = "dict"
        acceptable_formats = ["dict", "str", "list"]
        max_input_size = max_context * 4  # Rough estimate: 1 token ≈ 4 bytes
        
        # Try to extract format preferences from signature
        # NOTE: This is a best-effort extraction. DSPy signatures may not have explicit format hints.
        # We look for common patterns in field descriptions or annotations.
        
        try:
            # Check if signature has input_fields
            if hasattr(signature, 'input_fields'):
                for field_name, field in signature.input_fields.items():
                    # Check for format hints in description
                    if hasattr(field, 'desc') and field.desc:
                        desc_lower = field.desc.lower()
                        if 'json' in desc_lower:
                            preferred_format = 'json'
                            acceptable_formats = ['json', 'dict']
                        elif 'csv' in desc_lower:
                            preferred_format = 'csv'
                            acceptable_formats = ['csv', 'str']
                        elif 'text' in desc_lower or 'string' in desc_lower:
                            preferred_format = 'str'
                            acceptable_formats = ['str', 'text']
                    
                    # Check for type annotations
                    if hasattr(field, 'annotation'):
                        annotation = field.annotation
                        if annotation == dict or str(annotation) == 'Dict':
                            preferred_format = 'dict'
                            acceptable_formats = ['dict', 'json']
                        elif annotation == str:
                            preferred_format = 'str'
                            acceptable_formats = ['str', 'text']
                        elif annotation == list or str(annotation) == 'List':
                            preferred_format = 'list'
                            acceptable_formats = ['list', 'json']
        except Exception as e:
            logger.warning(f"  ⚠️  Could not extract format from signature: {e}")
            logger.warning(f"  ℹ️  Using default capabilities")
        
        return AgentCapabilities(
            agent_name=agent_name,
            preferred_format=preferred_format,
            acceptable_formats=acceptable_formats,
            max_input_size=max_input_size,
            max_context_tokens=max_context
        )
    
    def _detect_format(self, data: Any) -> str:
        """Detect format of data."""
        if isinstance(data, dict):
            return 'dict'
        elif isinstance(data, list):
            return 'list'
        elif isinstance(data, str):
            # STRICT POLICY: avoid content-based heuristics (no regex/keyword matching).
            # Treat all strings as 'str' unless the sender explicitly provides format metadata.
            return 'str'
        elif isinstance(data, bytes):
            return 'bytes'
        else:
            return 'unknown'
    
    def _estimate_size(self, data: Any) -> int:
        """Estimate size of data in bytes."""
        try:
            if isinstance(data, (str, bytes)):
                return len(data)
            elif isinstance(data, (dict, list)):
                return len(json.dumps(data))
            else:
                return sys.getsizeof(data)
        except (TypeError, ValueError, AttributeError) as e:
            logger.debug(f"Size estimation failed: {e}, using default")
            return 1000  # Default estimate
    
    def _estimate_tokens(self, data: Any) -> int:
        """Estimate token count (rough: 1 token ≈ 4 chars)."""
        size_bytes = self._estimate_size(data)
        return size_bytes // 4
    
    def _infer_content_type(self, data: Any, metadata: Optional[Dict], filename: str = None) -> str:
        """
        Infer content type from data or metadata.
        
        Priority:
        1. Explicit content_type in metadata
        2. Magic number detection for binary data
        3. Filename extension
        4. Default based on data type
        """
        # Check metadata first
        if metadata and 'content_type' in metadata:
            return metadata['content_type']
        
        # Use ContentTypeDetector for binary data
        if isinstance(data, bytes):
            return ContentTypeDetector.detect(data, filename)
        
        # Infer from data type
        if isinstance(data, dict):
            return 'application/json'
        elif isinstance(data, list):
            return 'application/json'
        elif isinstance(data, str):
            return 'text/plain'
        
        # Default
        return 'application/octet-stream'
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about Agent Slack activity including file storage and delivery receipts."""
        # A-TEAM FIX: Include delivery receipt stats
        total_receipts = len(self.delivery_receipts)
        successful_deliveries = sum(1 for r in self.delivery_receipts.values() if r.get('delivered'))
        failed_deliveries = total_receipts - successful_deliveries
        
        return {
            'total_messages': len(self.message_history),
            'registered_agents': len(self.agent_capabilities),
            'context_budgets': dict(self.context_budget_tracker),
            'agent_capabilities': {
                name: {
                    'preferred_format': caps.preferred_format,
                    'max_context': caps.max_context_tokens
                }
                for name, caps in self.agent_capabilities.items()
            },
            # 🆕 File storage statistics
            'file_storage': self.file_storage.get_stats(),
            'file_mode_enabled': self.enable_file_mode,
            'file_mode_threshold_bytes': self.file_mode_threshold,
            # A-TEAM FIX: Delivery receipt statistics
            'delivery_receipts': {
                'total': total_receipts,
                'successful': successful_deliveries,
                'failed': failed_deliveries,
                'success_rate': successful_deliveries / max(total_receipts, 1)
            }
        }
    
    def reset_context(self, agent_name: Optional[str] = None):
        """Reset context budget for agent(s)."""
        if agent_name:
            self.context_budget_tracker[agent_name] = 0
            logger.info(f"🔄 [AGENT SLACK] Reset context for {agent_name}")
        else:
            self.context_budget_tracker = {name: 0 for name in self.agent_capabilities.keys()}
            logger.info(f"🔄 [AGENT SLACK] Reset context for all agents")
    
    # =========================================================================
    # 🆕 COOPERATION METHODS
    # =========================================================================
    
    def _record_cooperation_event(
        self,
        event_type: str,
        from_agent: str,
        to_agent: str,
        description: str,
        impact: float
    ):
        """
        Record a cooperation event.
        
        Args:
            event_type: 'share', 'help', 'unblock', 'request'
            from_agent: Agent providing help
            to_agent: Agent receiving help
            description: What happened
            impact: Impact score (0.0-1.0)
        """
        event = {
            'type': event_type,
            'from': from_agent,
            'to': to_agent,
            'description': description,
            'impact': impact,
            'timestamp': time.time()
        }
        
        self.cooperation_events.append(event)
        
        # Update help matrix
        key = (from_agent, to_agent)
        self.help_matrix[key] = self.help_matrix.get(key, 0) + 1
        
        logger.debug(f"🤝 [COOPERATION] {from_agent} → {to_agent}: {event_type}")
    
    def get_cooperation_stats(self) -> Dict[str, Any]:
        """
        Get cooperation statistics.
        
        Returns:
            {
                'total_events': int,
                'help_matrix': {(from, to): count},
                'most_helpful': agent_name,
                'most_helped': agent_name,
                'recent_events': [events]
            }
        """
        if not self.enable_cooperation:
            return {'enabled': False}
        
        # Find most helpful agent (gives most help)
        help_given = {}
        for (from_agent, to_agent), count in self.help_matrix.items():
            help_given[from_agent] = help_given.get(from_agent, 0) + count
        
        most_helpful = max(help_given.items(), key=lambda x: x[1])[0] if help_given else None
        
        # Find most helped agent (receives most help)
        help_received = {}
        for (from_agent, to_agent), count in self.help_matrix.items():
            help_received[to_agent] = help_received.get(to_agent, 0) + count
        
        most_helped = max(help_received.items(), key=lambda x: x[1])[0] if help_received else None
        
        return {
            'enabled': True,
            'total_events': len(self.cooperation_events),
            'help_matrix': dict(self.help_matrix),
            'help_given': help_given,
            'help_received': help_received,
            'most_helpful': most_helpful,
            'most_helped': most_helped,
            'recent_events': self.cooperation_events[-10:]  # Last 10
        }
    
    def should_communicate(
        self,
        from_agent: str,
        to_agent: str,
        information_value: float,
        cost_estimate: float = 0.1,
        receiver_confidence_before: float = 0.5,
        context_budget_remaining: float = 1.0
    ) -> bool:
        """
        Nash Equilibrium: Should I communicate this information?
        
        🔬 A-TEAM ENHANCEMENTS (per GRF MARL paper):
        - Learn value from (receiver confidence lift, predicted reward lift)
        - Learn cost from context budget + latency history
        - Log decisions for learning
        
        Communicate if: Value_of_information > Cost_of_communication
        
        Args:
            from_agent: Sender
            to_agent: Receiver
            information_value: Estimated value to receiver (0.0-1.0)
            cost_estimate: Cost of communication (default: 0.1)
            receiver_confidence_before: Receiver's confidence before receiving info
            context_budget_remaining: How much context budget receiver has (0.0-1.0)
        
        Returns:
            True if should communicate
        """
        # 🔬 LEARNED VALUE: Incorporate historical cooperation success
        pair_key = (from_agent, to_agent)
        historical_success = self._get_cooperation_success_rate(from_agent, to_agent)
        
        # Value = base_value * historical_success * (1 - receiver_confidence)
        # Higher value if receiver needs it (low confidence) and history shows benefit
        confidence_gap = 1.0 - receiver_confidence_before
        learned_value = information_value * (0.5 + 0.5 * historical_success) * (0.5 + 0.5 * confidence_gap)
        
        # 🔬 LEARNED COST: Incorporate context budget and latency
        # Higher cost if receiver has low context budget (might get compressed/lost)
        budget_penalty = 0.2 * (1.0 - context_budget_remaining)  # 0-0.2 extra cost
        latency_history = self._get_average_latency(from_agent, to_agent)
        latency_penalty = min(0.1, latency_history / 10.0)  # 0-0.1 extra cost
        
        learned_cost = cost_estimate + budget_penalty + latency_penalty
        
        # Nash equilibrium: communicate if net positive
        net_value = learned_value - learned_cost
        
        should_send = net_value > 0
        
        # 🔬 LOG FOR LEARNING
        self._log_communication_decision(
            from_agent=from_agent,
            to_agent=to_agent,
            raw_value=information_value,
            learned_value=learned_value,
            raw_cost=cost_estimate,
            learned_cost=learned_cost,
            decision=should_send,
            historical_success=historical_success
        )
        
        if should_send:
            logger.debug(f"🤝 [NASH] {from_agent} → {to_agent}: SEND (learned_value={learned_value:.2f}, learned_cost={learned_cost:.2f}, history_success={historical_success:.2f})")
        else:
            logger.debug(f"🤝 [NASH] {from_agent} → {to_agent}: SKIP (learned_value={learned_value:.2f}, learned_cost={learned_cost:.2f}, history_success={historical_success:.2f})")
        
        return should_send
    
    def _get_cooperation_success_rate(self, from_agent: str, to_agent: str) -> float:
        """Get historical success rate for this agent pair."""
        pair_key = (from_agent, to_agent)
        if pair_key in self.help_matrix:
            help_count = self.help_matrix[pair_key]
            # Simple heuristic: more help = more success (cap at 1.0)
            return min(1.0, help_count / 5.0)
        return 0.5  # Default: neutral
    
    def _get_average_latency(self, from_agent: str, to_agent: str) -> float:
        """Get average communication latency for this pair (in seconds)."""
        # Check recent comms for this pair
        pair_comms = [
            c for c in self.communication_log[-20:]
            if c.get('from') == from_agent and c.get('to') == to_agent
        ]
        if pair_comms:
            latencies = [c.get('latency', 0.1) for c in pair_comms]
            return sum(latencies) / len(latencies)
        return 0.1  # Default
    
    def _log_communication_decision(self, **kwargs):
        """Log communication decision for learning."""
        self.communication_log.append({
            'timestamp': time.time(),
            'type': 'nash_decision',
            **kwargs
        })
    
    # =========================================================================
    # 🆕 FILE STORAGE METHODS
    # =========================================================================
    
    def read_file_from_reference(self, message_data: Dict, verify_checksum: bool = True) -> Optional[bytes]:
        """
        Read file content from a file reference message.
        
        This is the receiver-side method to extract actual file content
        from a file_reference message payload.
        
        Args:
            message_data: Message data dict containing file reference
            verify_checksum: Whether to verify SHA256 integrity
            
        Returns:
            File content as bytes, or None if failed
            
        Example:
            ```python
            def on_message(message: Message):
                data = message.data
                if isinstance(data, dict) and data.get('type') == 'file_reference':
                    # It's a file reference - load the actual content
                    content = agent_slack.read_file_from_reference(data)
                    if content:
                        # Process the file content
                        process_audio(content)
            ```
        """
        if not isinstance(message_data, dict):
            logger.warning("read_file_from_reference: data is not a dict")
            return None
        
        if message_data.get('type') != 'file_reference':
            logger.warning("read_file_from_reference: data is not a file_reference")
            return None
        
        file_id = message_data.get('file_id')
        if not file_id:
            logger.error("read_file_from_reference: no file_id in reference")
            return None
        
        return self.file_storage.read_file(file_id, verify_checksum=verify_checksum)
    
    def is_file_reference(self, data: Any) -> bool:
        """
        Check if data is a file reference.
        
        Args:
            data: Message data
            
        Returns:
            True if data is a file_reference payload
        """
        return (
            isinstance(data, dict) and 
            data.get('type') == 'file_reference' and 
            'file_id' in data
        )
    
    def run_storage_maintenance(self):
        """
        Run storage maintenance tasks.
        
        - Transitions files between tiers based on age
        - Cleans up expired archives
        
        Call this periodically (e.g., hourly) or after task completion.
        """
        logger.info("📁 [STORAGE] Running maintenance...")
        self.file_storage.run_tier_transition()
        self.file_storage.cleanup_expired()
        logger.info("📁 [STORAGE] Maintenance complete")
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get file storage statistics."""
        return self.file_storage.get_stats()

