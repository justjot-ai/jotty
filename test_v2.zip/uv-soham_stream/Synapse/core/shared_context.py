"""
SharedContext - Smart Shared Data Store

Thread-safe AND async-safe key-value store with SEMANTIC SEARCH for sharing data between agents.

Design:
- MetaDataFetcher writes (stores fetched metadata)
- Domain agents read (via SwarmReVal parameter resolution)
- 🧠 A-TEAM ENHANCEMENT E2: Semantic search across keys and values
  so actors can find relevant data without knowing exact keys
- Dual-lock architecture:
  - threading.Lock for sync methods (thread-safe, used from non-async code)
  - asyncio.Lock for async stream methods (non-blocking, used from async code)
"""

import asyncio
import logging
import time
from difflib import SequenceMatcher
from typing import Dict, Any, List, Optional, AsyncGenerator, Tuple
from threading import Lock

from .logging_config import get_logger

logger = get_logger(__name__)


class SharedContext:
    """
    Simple shared data store for agent communication.
    
    DESIGN PRINCIPLES:
    - Simple dict-like interface
    - Thread-safe for concurrent access
    - No complex features (compression, semantic search, etc.)
    - MetaDataFetcher writes, domain agents read via SwarmReVal
    
    Example:
        context = SharedContext()
        
        # MetaDataFetcher writes
        context.set('business_terms', {'ENTITY_A': 'Description of entity A'})
        context.set('data_schemas', {'data_source_1': {...}})
        
        # SwarmReVal reads for domain agents
        terms = context.get('business_terms')  # For BusinessTermResolver
        schemas = context.get('table_schemas')  # For ColumnFilterSelector
    """
    
    def __init__(self):
        """Initialize empty shared context."""
        start_time = time.time()
        self.data: Dict[str, Any] = {}
        self._lock = Lock()  # For sync methods (thread-safe)
        self._async_lock: Optional[asyncio.Lock] = None  # Lazy-init for async methods
        
        logger.info(f"🔧 INIT: SharedContext | duration={time.time() - start_time:.3f}s")
        # Note: __init__ cannot be async generator, but we log the initialization
    
    def _get_async_lock(self) -> asyncio.Lock:
        """
        Get or create the asyncio.Lock for async methods.
        
        🔴 A-TEAM FIX: Lazy initialization ensures the lock is created
        within an active event loop. threading.Lock blocks the event loop
        when used in async methods; asyncio.Lock yields control properly.
        """
        if self._async_lock is None:
            self._async_lock = asyncio.Lock()
        return self._async_lock
    
    def set(self, key: str, value: Any):
        """
        Store data in shared context.
        
        Args:
            key: Semantic key (e.g., 'business_terms', 'table_schemas')
            value: Data to store (any type)
        
        Thread-safe.
        """
        set_start = time.time()
        value_type = type(value).__name__
        value_size = len(str(value)) if isinstance(value, (str, list, dict)) else 1
        
        with self._lock:
            self.data[key] = value
            duration = time.time() - set_start
        
        logger.info(f"📝 SET: SharedContext | key='{key}' | type={value_type} | "
                   f"size={value_size} | duration={duration:.3f}s")
        # Yield event for streaming (but method remains sync for compatibility)
        # Callers should use set_stream() for async generator version
        logger.debug(f"    Value preview: {str(value)[:200]}{'...' if value_size > 200 else ''}")
    
    async def set_stream(self, key: str, value: Any) -> AsyncGenerator[Dict[str, Any], None]:
        """Set value with event streaming. Uses asyncio.Lock for non-blocking async safety."""
        set_start = time.time()
        value_type = type(value).__name__
        value_size = len(str(value)) if isinstance(value, (str, list, dict)) else 1
        
        async with self._get_async_lock():
            self.data[key] = value
            duration = time.time() - set_start
        
        logger.info(f"📝 SET: SharedContext | key='{key}' | type={value_type} | "
                   f"size={value_size} | duration={duration:.3f}s")
        yield {"module": "Synapse.core.shared_context", "message": f"I am storing data in shared context with key '{key}' of type {value_type}"}
        logger.debug(f"    Value preview: {str(value)[:200]}{'...' if value_size > 200 else ''}")
    
    def get(self, key: str) -> Optional[Any]:
        """
        Retrieve data from shared context.
        
        Args:
            key: Semantic key
        
        Returns:
            Stored data, or None if key doesn't exist
        
        Thread-safe.
        """
        get_start = time.time()
        
        with self._lock:
            value = self.data.get(key)
            duration = time.time() - get_start
        
        if value is not None:
            value_type = type(value).__name__
            value_size = len(str(value)) if isinstance(value, (str, list, dict)) else 1
            logger.info(f"📖 GET: SharedContext | key='{key}' | found=True | "
                       f"type={value_type} | size={value_size} | duration={duration:.3f}s")
        else:
            logger.info(f"📖 GET: SharedContext | key='{key}' | found=False | duration={duration:.3f}s")
        
        return value
    
    async def get_stream(self, key: str) -> AsyncGenerator[Dict[str, Any], None]:
        """Get value with event streaming. Uses asyncio.Lock for non-blocking async safety."""
        get_start = time.time()
        
        async with self._get_async_lock():
            value = self.data.get(key)
            duration = time.time() - get_start
        
        if value is not None:
            value_type = type(value).__name__
            value_size = len(str(value)) if isinstance(value, (str, list, dict)) else 1
            logger.info(f"📖 GET: SharedContext | key='{key}' | found=True | "
                       f"type={value_type} | size={value_size} | duration={duration:.3f}s")
            yield {"module": "Synapse.core.shared_context", "message": f"I found data in shared context with key '{key}' of type {value_type}"}
        else:
            logger.info(f"📖 GET: SharedContext | key='{key}' | found=False | duration={duration:.3f}s")
            yield {"module": "Synapse.core.shared_context", "message": f"I did not find data in shared context for key '{key}'"}
        
        yield {"type": "result", "result": value, "module": "Synapse.core.shared_context", "message": f"I am returning the value for key '{key}'"}
        return
    
    def get_all(self) -> Dict[str, Any]:
        """
        Get all data in shared context.
        
        Returns:
            Copy of all data
        
        Thread-safe.
        """
        get_all_start = time.time()
        
        with self._lock:
            result = self.data.copy()
            duration = time.time() - get_all_start
        
        logger.info(f"📚 GET_ALL: SharedContext | keys={len(result)} | duration={duration:.3f}s")
        logger.debug(f"    Keys: {list(result.keys())}")
        
        return result
    
    async def get_all_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Get all data with event streaming. Uses asyncio.Lock for non-blocking async safety."""
        get_all_start = time.time()
        
        async with self._get_async_lock():
            result = self.data.copy()
            duration = time.time() - get_all_start
        
        logger.info(f"📚 GET_ALL: SharedContext | keys={len(result)} | duration={duration:.3f}s")
        yield {"module": "Synapse.core.shared_context", "message": f"I am retrieving all data from shared context, found {len(result)} keys"}
        logger.debug(f"    Keys: {list(result.keys())}")
        
        yield {"type": "result", "result": result, "module": "Synapse.core.shared_context", "message": "I am returning all data from shared context"}
        return
    
    def keys(self) -> List[str]:
        """
        Get all keys in shared context.
        
        Returns:
            List of all keys
        
        Thread-safe.
        """
        keys_start = time.time()
        
        with self._lock:
            result = list(self.data.keys())
            duration = time.time() - keys_start
        
        logger.info(f"🔑 KEYS: SharedContext | count={len(result)} | duration={duration:.3f}s")
        
        return result
    
    async def keys_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Get all keys with event streaming. Uses asyncio.Lock for non-blocking async safety."""
        keys_start = time.time()
        
        async with self._get_async_lock():
            result = list(self.data.keys())
            duration = time.time() - keys_start
        
        logger.info(f"🔑 KEYS: SharedContext | count={len(result)} | duration={duration:.3f}s")
        yield {"module": "Synapse.core.shared_context", "message": f"I found {len(result)} keys in shared context"}
        
        yield {"type": "result", "result": result, "module": "Synapse.core.shared_context", "message": "I am returning the list of keys"}
        return
    
    def has(self, key: str) -> bool:
        """
        Check if key exists in shared context.
        
        Args:
            key: Key to check
        
        Returns:
            True if key exists, False otherwise
        
        Thread-safe.
        """
        with self._lock:
            return key in self.data
    
    def clear(self):
        """
        Clear all data from shared context.
        
        Thread-safe.
        """
        with self._lock:
            self.data.clear()
            logger.debug("🗂️  SharedContext cleared")
    
    def summary(self) -> str:
        """
        Get summary of shared context for logging.
        
        Returns:
            Human-readable summary
        """
        with self._lock:
            keys = list(self.data.keys())
            return f"SharedContext({len(keys)} items: {keys})"
    
    def __repr__(self) -> str:
        """String representation."""
        return self.summary()
    
    def __contains__(self, key: str) -> bool:
        """
        Support 'in' operator: 'key' in shared_context
        
        Args:
            key: Key to check
        
        Returns:
            True if key exists, False otherwise
        """
        return self.has(key)

    # =========================================================================
    # 🧠 A-TEAM ENHANCEMENT E2: Semantic Search for Knowledge Repo
    # =========================================================================
    
    def search(self, query: str, threshold: float = 0.3, max_results: int = 10) -> List[Tuple[str, Any, float]]:
        """
        Semantic search across keys and values.
        
        Finds entries where the key or value content matches the query
        using fuzzy string matching + keyword overlap scoring.
        
        This allows agents to find data WITHOUT knowing exact keys.
        E.g., search("SQL results") could match key "output_task_sql_gen".
        
        Args:
            query: Natural language search query
            threshold: Minimum relevance score (0.0-1.0) to include
            max_results: Maximum number of results to return
            
        Returns:
            List of (key, value, score) tuples sorted by relevance (descending)
        """
        search_start = time.time()
        results = []
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        with self._lock:
            for key, value in self.data.items():
                score = self._compute_relevance(key, value, query_lower, query_words)
                if score >= threshold:
                    results.append((key, value, score))
        
        # Sort by relevance (descending)
        results.sort(key=lambda x: x[2], reverse=True)
        results = results[:max_results]
        
        duration = time.time() - search_start
        logger.info(f"🔍 SEARCH: SharedContext | query='{query}' | matches={len(results)} | "
                   f"threshold={threshold} | duration={duration:.3f}s")
        
        return results
    
    async def search_stream(self, query: str, threshold: float = 0.3, max_results: int = 10) -> AsyncGenerator[Dict[str, Any], None]:
        """Semantic search with event streaming."""
        results = self.search(query, threshold, max_results)
        yield {"module": "Synapse.core.shared_context", "message": f"I found {len(results)} matching entries for query '{query}'"}
        yield {"type": "result", "result": results, "module": "Synapse.core.shared_context", "message": f"I am returning {len(results)} search results"}
        return
    
    def _compute_relevance(self, key: str, value: Any, query_lower: str, query_words: set) -> float:
        """
        Compute relevance score between query and a key-value pair.
        
        Uses multi-signal scoring:
        1. Key fuzzy match (SequenceMatcher)
        2. Key keyword overlap 
        3. Value content keyword overlap (for string values)
        4. Exact substring bonus
        
        Returns:
            Relevance score in [0.0, 1.0]
        """
        scores = []
        key_lower = key.lower()
        key_words = set(key_lower.replace('_', ' ').replace('-', ' ').split())
        
        # Signal 1: Fuzzy key match (handles "sql results" matching "output_task_sql_gen")
        key_normalized = key_lower.replace('_', ' ').replace('-', ' ')
        fuzzy_score = SequenceMatcher(None, query_lower, key_normalized).ratio()
        scores.append(fuzzy_score * 0.4)  # 40% weight
        
        # Signal 2: Keyword overlap in key
        if query_words and key_words:
            overlap = len(query_words & key_words)
            keyword_score = overlap / max(len(query_words), 1)
            scores.append(keyword_score * 0.3)  # 30% weight
        else:
            scores.append(0.0)
        
        # Signal 3: Value content matching (for string/dict values)
        value_str = ""
        if isinstance(value, str):
            value_str = value.lower()[:2000]  # Only check first 2000 chars for performance
        elif isinstance(value, dict):
            value_str = ' '.join(str(v) for v in value.keys()).lower()[:2000]
        elif isinstance(value, (list, tuple)):
            value_str = ' '.join(str(v) for v in value[:20]).lower()[:2000]
        
        if value_str and query_words:
            value_words = set(value_str.split()[:200])
            value_overlap = len(query_words & value_words)
            value_score = value_overlap / max(len(query_words), 1)
            scores.append(value_score * 0.2)  # 20% weight
        else:
            scores.append(0.0)
        
        # Signal 4: Exact substring bonus
        if query_lower in key_lower or query_lower in value_str:
            scores.append(0.1)  # 10% bonus
        else:
            # Check partial substrings from query words
            partial_bonus = 0.0
            for word in query_words:
                if len(word) > 2 and (word in key_lower or word in value_str):
                    partial_bonus += 0.02
            scores.append(min(0.1, partial_bonus))
        
        return min(1.0, sum(scores))
    
    def search_by_type(self, value_type: type, max_results: int = 50) -> List[Tuple[str, Any]]:
        """
        Find all entries whose value is of a specific type.
        
        Useful for actors looking for specific data types
        (e.g., all dict outputs, all string results).
        
        Args:
            value_type: Python type to filter by
            max_results: Maximum entries to return
            
        Returns:
            List of (key, value) tuples matching the type
        """
        results = []
        with self._lock:
            for key, value in self.data.items():
                if isinstance(value, value_type):
                    results.append((key, value))
                    if len(results) >= max_results:
                        break
        
        logger.info(f"🔍 TYPE_SEARCH: SharedContext | type={value_type.__name__} | matches={len(results)}")
        return results
    
    def get_outputs_summary(self) -> Dict[str, str]:
        """
        Get a summary of all stored outputs for agent context building.
        
        Returns a dict mapping keys to value type + size descriptions,
        useful for injecting into agent prompts so they know what data
        is available.
        
        Returns:
            Dict mapping keys to human-readable descriptions
        """
        summary = {}
        with self._lock:
            for key, value in self.data.items():
                if isinstance(value, str):
                    summary[key] = f"str({len(value)} chars)"
                elif isinstance(value, dict):
                    summary[key] = f"dict({len(value)} keys: {list(value.keys())[:5]})"
                elif isinstance(value, (list, tuple)):
                    summary[key] = f"{type(value).__name__}({len(value)} items)"
                else:
                    summary[key] = f"{type(value).__name__}"
        return summary







