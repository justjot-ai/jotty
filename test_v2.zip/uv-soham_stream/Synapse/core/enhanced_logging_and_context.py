"""
🔧 A-TEAM CLEANUP: Context Management for Synapse

This module provides:
- ContextRequirements: Actor-specific context filtering

✅ CLEANED: Removed 288 lines of unused code
- EnhancedLogger (NEVER USED)
- TokenBudgetManager (DUPLICATE of learning.DynamicBudgetManager)
- SemanticFilter (NEVER USED)
- SemanticChunker (moved to unified_chunker.py)
"""

from typing import List, Optional, Dict
from dataclasses import dataclass, field


# ============================================================================
# CONTEXT MANAGEMENT
# ============================================================================

@dataclass
class ContextRequirements:
    """
    Defines what context an actor needs.
    
    🔧 A-TEAM: Enables semantic filtering - only load what's needed!
    """
    # Metadata requirements
    metadata_fields: Optional[List[str]] = None  # e.g., ['tables', 'columns']
    metadata_detail: str = 'full'  # 'full', 'summary', 'names_only'
    
    # Memory requirements
    memories_scope: str = 'recent'  # 'recent', 'similar', 'all', 'none'
    memories_limit: int = 5
    
    # History requirements
    trajectory_needed: bool = True
    previous_outputs_needed: Optional[List[str]] = None  # Which actor outputs
    
    # Budget allocation (proportions)
    budget_proportions: Dict[str, float] = field(default_factory=lambda: {
        'metadata': 0.4,
        'memories': 0.2,
        'trajectory': 0.1,
        'previous_outputs': 0.3
    })


__all__ = ['ContextRequirements']
