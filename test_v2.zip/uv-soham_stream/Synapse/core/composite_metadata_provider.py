"""
CompositeMetadataProvider - Combines multiple metadata providers.

Design goals:
- No hardcoded mappings (generic composition)
- Preserve @synapse_method discovery via __dir__/__getattr__
- Safe merging of context outputs
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from .logging_config import get_logger

logger = get_logger(__name__)


class CompositeMetadataProvider:
    """
    Compose multiple metadata providers into a single interface.

    This enables built-in system tools (e.g., web search) to coexist with
    user-provided metadata providers without hardcoded wiring.
    """

    def __init__(self, providers: List[Any]):
        start_time = time.time()
        logger.info(f"🔧 INIT: CompositeMetadataProvider | providers={len(providers)}")
        
        self._providers = [p for p in providers if p is not None]
        logger.debug(f"  📋 Filtered providers: {len(self._providers)} (removed {len(providers) - len(self._providers)} None values)")
        
        for i, provider in enumerate(self._providers):
            logger.debug(f"  Provider[{i}]: {type(provider).__name__}")
        
        self._multi_provider_methods = {"get_context_for_actor"}
        logger.debug(f"  🔗 Multi-provider methods: {self._multi_provider_methods}")
        
        method_map_start = time.time()
        self._method_owner = self._build_method_map()
        method_map_duration = time.time() - method_map_start
        
        logger.info(f"✅ INIT COMPLETE: CompositeMetadataProvider | "
                   f"methods_mapped={len(self._method_owner)} | "
                   f"duration={time.time() - start_time:.3f}s | "
                   f"method_map_duration={method_map_duration:.3f}s")

    def __synapse_validate__(self) -> bool:
        start_time = time.time()
        logger.info(f"🔍 VALIDATE: CompositeMetadataProvider | checking {len(self._providers)} providers")
        
        ok = True
        validation_results = []
        
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            logger.debug(f"  Validating provider[{i}]: {provider_name}")
            
            validate = getattr(provider, "__synapse_validate__", None)
            if callable(validate):
                try:
                    provider_start = time.time()
                    result = bool(validate())
                    provider_duration = time.time() - provider_start
                    ok = result and ok
                    validation_results.append(f"{provider_name}: {'✅' if result else '❌'} ({provider_duration:.3f}s)")
                    logger.debug(f"    {provider_name} validation: {'PASS' if result else 'FAIL'} ({provider_duration:.3f}s)")
                except Exception as e:
                    logger.warning(f"⚠️  {provider_name} validation failed: {e}", exc_info=True)
                    ok = False
                    validation_results.append(f"{provider_name}: ❌ EXCEPTION")
            else:
                logger.debug(f"    {provider_name}: No __synapse_validate__ method")
                validation_results.append(f"{provider_name}: ⚠️  No validator")
        
        duration = time.time() - start_time
        logger.info(f"{'✅ VALIDATION PASSED' if ok else '❌ VALIDATION FAILED'}: "
                   f"CompositeMetadataProvider | duration={duration:.3f}s")
        logger.debug(f"  Results: {', '.join(validation_results)}")
        
        return ok

    def get_context_for_actor(
        self,
        actor_name: str,
        query: str,
        previous_outputs: Optional[Dict[str, Any]] = None,
        actor_config: Optional[Any] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Combine context from all providers that implement get_context_for_actor.
        """
        start_time = time.time()
        logger.info(f"📥 GET_CONTEXT: actor={actor_name} | query_length={len(query)} | "
                   f"providers={len(self._providers)}")
        logger.debug(f"  Query: {query[:100]}{'...' if len(query) > 100 else ''}")
        logger.debug(f"  Previous outputs keys: {list(previous_outputs.keys()) if previous_outputs else 'None'}")
        logger.debug(f"  Additional kwargs: {list(kwargs.keys())}")
        
        merged: Dict[str, Any] = {}
        provider_results = []
        
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            
            if hasattr(provider, "get_context_for_actor"):
                logger.debug(f"  Provider[{i}]: {provider_name} | has get_context_for_actor")
                try:
                    provider_start = time.time()
                    data = provider.get_context_for_actor(
                        actor_name=actor_name,
                        query=query,
                        previous_outputs=previous_outputs,
                        actor_config=actor_config,
                        **kwargs
                    )
                    provider_duration = time.time() - provider_start
                    
                    if not data:
                        logger.debug(f"    {provider_name}: Empty context returned")
                        provider_results.append(f"{provider_name}: empty")
                        continue
                    
                    if not isinstance(data, dict):
                        logger.warning(
                            f"⚠️  {provider_name} returned non-dict context: {type(data).__name__}"
                        )
                        provider_results.append(f"{provider_name}: invalid_type({type(data).__name__})")
                        continue
                    
                    logger.debug(f"    {provider_name}: Returned {len(data)} context keys | duration={provider_duration:.3f}s")
                    logger.debug(f"    Keys: {list(data.keys())}")
                    
                    collisions = []
                    for key, value in data.items():
                        if key in merged:
                            new_key = f"{provider_name}_{key}"
                            merged[new_key] = value
                            collisions.append(f"{key}->{new_key}")
                            logger.warning(
                                f"⚠️  Context key collision: '{key}' -> '{new_key}'"
                            )
                        else:
                            merged[key] = value
                    
                    if collisions:
                        provider_results.append(f"{provider_name}: {len(data)} keys ({len(collisions)} collisions)")
                    else:
                        provider_results.append(f"{provider_name}: {len(data)} keys")
                        
                except Exception as e:
                    logger.warning(
                        f"⚠️  {provider_name} get_context_for_actor failed: {e}",
                        exc_info=True
                    )
                    provider_results.append(f"{provider_name}: ERROR({type(e).__name__})")
            else:
                logger.debug(f"  Provider[{i}]: {provider_name} | no get_context_for_actor method")
                provider_results.append(f"{provider_name}: skipped")
        
        duration = time.time() - start_time
        logger.info(f"📤 GET_CONTEXT COMPLETE: actor={actor_name} | "
                   f"merged_keys={len(merged)} | duration={duration:.3f}s")
        logger.debug(f"  Provider results: {', '.join(provider_results)}")
        logger.debug(f"  Merged keys: {list(merged.keys())}")
        
        return merged

    def __getattr__(self, name: str) -> Any:
        logger.debug(f"🔍 GETATTR: CompositeMetadataProvider | attribute='{name}'")
        
        # First check if it's a callable method we've mapped
        owner = self._method_owner.get(name)
        if owner is not None:
            owner_name = type(owner).__name__
            logger.debug(f"  ✅ Found in method_map: {owner_name}.{name}")
            result = getattr(owner, name)
            logger.debug(f"  ✅ Returning method from {owner_name}")
            return result
        
        # If not in method map, search providers for the attribute
        # This handles attributes like 'config' and 'registry' that appear in __dir__
        # but aren't callable methods (or weren't discovered during method mapping)
        logger.debug(f"  🔍 Not in method_map, searching {len(self._providers)} providers...")
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            if hasattr(provider, name):
                logger.debug(f"  Provider[{i}]: {provider_name} | has '{name}'")
                try:
                    result = getattr(provider, name)
                    logger.debug(f"  ✅ Returning attribute from {provider_name}.{name}")
                    return result
                except (AttributeError, Exception) as e:
                    logger.debug(f"  ⚠️  {provider_name}.{name} access failed: {e}")
                    continue
            else:
                logger.debug(f"  Provider[{i}]: {provider_name} | no '{name}'")
        
        # Only log at DEBUG level - these are expected when checking for optional methods
        # The AttributeError will be caught by hasattr() checks, so no need for WARNING noise
        logger.debug(f"❌ GETATTR FAILED: CompositeMetadataProvider has no attribute '{name}' "
                    f"(this is normal when checking for optional methods)")
        raise AttributeError(f"{type(self).__name__} has no attribute '{name}'")

    def get_stats(self) -> Dict[str, Any]:
        """Aggregate stats from providers that expose get_stats()."""
        start_time = time.time()
        logger.info(f"📊 GET_STATS: CompositeMetadataProvider | providers={len(self._providers)}")
        
        stats: Dict[str, Any] = {}
        stats_collected = []
        
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            if hasattr(provider, "get_stats"):
                logger.debug(f"  Provider[{i}]: {provider_name} | collecting stats")
                try:
                    provider_start = time.time()
                    provider_stats = provider.get_stats()
                    provider_duration = time.time() - provider_start
                    stats[provider_name] = provider_stats
                    stats_collected.append(f"{provider_name}: {len(provider_stats)} keys ({provider_duration:.3f}s)")
                    logger.debug(f"    {provider_name}: Collected {len(provider_stats)} stat keys")
                except Exception as e:
                    logger.warning(f"⚠️  {provider_name} get_stats() failed: {e}", exc_info=True)
                    stats_collected.append(f"{provider_name}: ERROR")
            else:
                logger.debug(f"  Provider[{i}]: {provider_name} | no get_stats method")
                stats_collected.append(f"{provider_name}: skipped")
        
        duration = time.time() - start_time
        logger.info(f"📊 GET_STATS COMPLETE: {len(stats)} providers | duration={duration:.3f}s")
        logger.debug(f"  Stats collected: {', '.join(stats_collected)}")
        
        return stats

    def __dir__(self) -> List[str]:
        logger.debug(f"📋 DIR: CompositeMetadataProvider | building attribute list")
        
        public = set(self.__dict__.keys())
        logger.debug(f"  Base attributes: {len(public)}")
        
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            provider_attrs = [attr for attr in dir(provider) if not attr.startswith("_")]
            public.update(provider_attrs)
            logger.debug(f"  Provider[{i}]: {provider_name} | added {len(provider_attrs)} attributes")
        
        result = sorted(public)
        logger.debug(f"📋 DIR COMPLETE: {len(result)} total attributes")
        
        return result

    def _build_method_map(self) -> Dict[str, Any]:
        logger.debug(f"🗺️  BUILD_METHOD_MAP: CompositeMetadataProvider | providers={len(self._providers)}")
        
        method_owner: Dict[str, Any] = {}
        method_counts = {}
        
        for i, provider in enumerate(self._providers):
            provider_name = type(provider).__name__
            provider_methods = []
            
            for name in dir(provider):
                if name.startswith("_"):
                    continue
                try:
                    attr = getattr(provider, name)
                except Exception as e:
                    logger.debug(f"    Provider[{i}]: {provider_name} | failed to get '{name}': {e}")
                    continue
                
                if callable(attr):
                    if name in method_owner:
                        if name in self._multi_provider_methods:
                            logger.debug(f"    Provider[{i}]: {provider_name} | '{name}' is multi-provider, skipping")
                            continue
                        existing_owner = type(method_owner[name]).__name__
                        error_msg = (
                            f"Duplicate method '{name}' in CompositeMetadataProvider: "
                            f"already owned by {existing_owner}, conflict with {provider_name}"
                        )
                        logger.error(f"❌ {error_msg}")
                        raise ValueError(error_msg)
                    
                    method_owner[name] = provider
                    provider_methods.append(name)
                    logger.debug(f"    Provider[{i}]: {provider_name} | mapped method '{name}'")
            
            method_counts[provider_name] = len(provider_methods)
            logger.debug(f"  Provider[{i}]: {provider_name} | mapped {len(provider_methods)} methods")
        
        logger.info(f"🗺️  BUILD_METHOD_MAP COMPLETE: {len(method_owner)} total methods mapped")
        logger.debug(f"  Method counts: {', '.join(f'{k}:{v}' for k, v in method_counts.items())}")
        logger.debug(f"  Mapped methods: {sorted(method_owner.keys())}")
        
        return method_owner


__all__ = ["CompositeMetadataProvider"]
