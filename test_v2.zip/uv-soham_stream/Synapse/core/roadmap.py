"""
Synapse v6.1 - Enhanced State Representation
==========================================

A-Team Consensus Implementation:
- AgenticState: Rich state with trajectory, memories, predictions
- DecomposedQFunction: Multi-objective value estimation
- MarkovianTODO: Long-horizon task management
- ThoughtLevelCredit: Reasoning step credit assignment
- TrajectoryPredictor: DQN-style next-state prediction
- StateCheckpointer: Full resume support

Dr. Manning: "State approximation is the key to intelligent agents"
Dr. Chen: "CoT steps are the state trajectory"
Dr. Agarwal: "100+ step tasks need Markovian tracking"
Aristotle: "Understanding WHY enables prediction"
Shannon: "Efficient state compression maximizes information"
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Set
from enum import Enum, auto
from datetime import datetime
from pathlib import Path
import json
import hashlib
import logging
import time

# Import dspy and set availability flag
try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False
    dspy = None

from .logging_config import get_logger
from .token_utils import smart_truncate

logger = get_logger(__name__)


# =============================================================================
# TODO ITEM - Shared across modules
# =============================================================================

@dataclass
class TodoItem:
    """A single TODO item with RL metadata."""
    id: str
    description: str
    actor: str  # Which actor handles this
    status: str  # pending, in_progress, completed, failed, blocked
    priority: float  # 0-1, learned priority
    estimated_reward: float  # Q-value estimate
    dependencies: List[str] = field(default_factory=list)
    attempts: int = 0
    max_attempts: int = 5
    failure_reasons: List[str] = field(default_factory=list)
    completion_time: Optional[float] = None


# =============================================================================
# AGENTIC STATE - Rich State Representation
# =============================================================================

@dataclass
class TrajectoryStep:
    """Single step in agent trajectory."""
    step_idx: int
    timestamp: datetime
    
    # Action taken
    action_type: str  # 'thought', 'tool_call', 'decision', 'output'
    action_content: str
    
    # Context at this step
    context_summary: str
    activated_memories: List[str]
    
    # Outcome
    observation: str
    reward: float
    
    # Predictions made at this step
    predicted_outcome: Optional[str] = None
    prediction_confidence: float = 0.0
    actual_divergence: float = 0.0  # How wrong was prediction?


@dataclass
class AgenticState:
    """
    Rich state representation for LLM agents.
    
    A-Team Enhancement: Goes beyond (goal, agent_name) to capture
    the full context needed for intelligent policy learning.
    """
    
    # Identity
    state_id: str = ""
    agent_name: str = ""
    episode_id: str = ""
    
    # Task Context
    task_description: str = ""
    task_decomposition: List[str] = field(default_factory=list)
    current_subtask_idx: int = 0
    subtask_completion: Dict[str, float] = field(default_factory=dict)
    
    # Agent Trajectory - THE KEY ENHANCEMENT
    trajectory: List[TrajectoryStep] = field(default_factory=list)
    reasoning_trace: List[str] = field(default_factory=list)
    tool_calls: List[Dict] = field(default_factory=list)
    
    # Memory Context
    activated_memories: List[str] = field(default_factory=list)
    memory_relevance_scores: Dict[str, float] = field(default_factory=dict)
    
    # Predictions (DQN-style)
    predicted_next_action: str = ""
    action_confidence: float = 0.5
    predicted_outcome: str = ""
    predicted_reward: float = 0.0
    uncertainty: float = 0.5
    
    # Causal Understanding
    active_causal_chains: List[Tuple[str, str]] = field(default_factory=list)
    intervention_effects: Dict[str, float] = field(default_factory=dict)
    
    # Meta
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    
    def __post_init__(self):
        if not self.state_id:
            self.state_id = self._generate_id()
    
    def _generate_id(self) -> str:
        """Generate unique state ID from content."""
        content = f"{self.agent_name}:{self.task_description}:{len(self.trajectory)}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def add_trajectory_step(self, 
                           action_type: str,
                           action_content: str,
                           observation: str,
                           reward: float,
                           context_summary: str = "",
                           activated_memories: List[str] = None):
        """Add a step to the trajectory."""
        step = TrajectoryStep(
            step_idx=len(self.trajectory),
            timestamp=datetime.now(),
            action_type=action_type,
            action_content=action_content,
            context_summary=context_summary,
            activated_memories=activated_memories or [],
            observation=observation,
            reward=reward
        )
        self.trajectory.append(step)
        self.last_updated = datetime.now()
    
    def add_reasoning_step(self, thought: str):
        """Add a CoT reasoning step."""
        self.reasoning_trace.append(thought)
        self.last_updated = datetime.now()
    
    def add_tool_call(self, tool_name: str, args: Dict, result: Any, success: bool):
        """Record a tool call."""
        self.tool_calls.append({
            'tool': tool_name,
            'args': args,
            'result': str(result),  # 🔥 NO TRUNCATION - FULL content
            'success': success,
            'step_idx': len(self.trajectory)
        })
    
    def to_key(self) -> str:
        """Generate state key for Q-table lookup."""
        # Include trajectory summary for richer state representation
        trajectory_summary = f"steps:{len(self.trajectory)}"
        if self.trajectory:
            last_action = self.trajectory[-1].action_type
            trajectory_summary += f":last:{last_action}"
        
        return f"{self.agent_name}|{self.task_description}|{trajectory_summary}"
    
    def to_llm_summary(self) -> str:
        """Generate LLM-friendly state summary for Q-value estimation."""
        summary_parts = [
            f"Agent: {self.agent_name}",
            f"Task: {self.task_description}",
            f"Progress: {self.current_subtask_idx}/{len(self.task_decomposition)} subtasks",
            f"Trajectory: {len(self.trajectory)} steps taken",
        ]
        
        if self.reasoning_trace:
            recent_thoughts = self.reasoning_trace
            summary_parts.append(f"Recent reasoning: {' -> '.join(recent_thoughts)}")
        
        if self.tool_calls:
            recent_tools = [tc['tool'] for tc in self.tool_calls]
            summary_parts.append(f"Recent tools: {', '.join(recent_tools)}")
        
        if self.predicted_outcome:
            summary_parts.append(f"Prediction: {self.predicted_outcome} (conf: {self.action_confidence:.2f})")
        
        return "\n".join(summary_parts)
    
    def to_dict(self) -> Dict:
        """Serialize to dictionary."""
        return {
            'state_id': self.state_id,
            'agent_name': self.agent_name,
            'episode_id': self.episode_id,
            'task_description': self.task_description,
            'task_decomposition': self.task_decomposition,
            'current_subtask_idx': self.current_subtask_idx,
            'subtask_completion': self.subtask_completion,
            'trajectory': [
                {
                    'step_idx': s.step_idx,
                    'timestamp': s.timestamp.isoformat(),
                    'action_type': s.action_type,
                    'action_content': s.action_content,
                    'observation': s.observation,
                    'reward': s.reward
                }
                for s in self.trajectory
            ],
            'reasoning_trace': self.reasoning_trace,  # Keep recent
            'tool_calls': self.tool_calls,
            'activated_memories': self.activated_memories,
            'predictions': {
                'next_action': self.predicted_next_action,
                'confidence': self.action_confidence,
                'outcome': self.predicted_outcome,
                'reward': self.predicted_reward,
                'uncertainty': self.uncertainty
            },
            'created_at': self.created_at.isoformat(),
            'last_updated': self.last_updated.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'AgenticState':
        """Deserialize from dictionary."""
        state = cls(
            state_id=data.get('state_id', ''),
            agent_name=data.get('agent_name', ''),
            episode_id=data.get('episode_id', ''),
            task_description=data.get('task_description', ''),
            task_decomposition=data.get('task_decomposition', []),
            current_subtask_idx=data.get('current_subtask_idx', 0),
            subtask_completion=data.get('subtask_completion', {})
        )
        
        # Restore predictions
        preds = data.get('predictions', {})
        state.predicted_next_action = preds.get('next_action', '')
        state.action_confidence = preds.get('confidence', 0.5)
        state.predicted_outcome = preds.get('outcome', '')
        state.predicted_reward = preds.get('reward', 0.0)
        state.uncertainty = preds.get('uncertainty', 0.5)
        
        return state


# =============================================================================
# DECOMPOSED Q-FUNCTION
# =============================================================================

class DecomposedQFunction:
    """
    Multi-objective Q-function for agentic systems.
    
    A-Team Enhancement: Instead of single Q-value, decompose into:
    - Q_task: How good is action for task completion?
    - Q_explore: How informative is action for learning?
    - Q_causal: Does action help understand causality?
    - Q_safety: Does action satisfy constraints?
    
    Dr. Manning: "Different objectives require different value estimates"
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        
        # Separate Q-tables for each objective
        self.q_task: Dict[Tuple[str, str], float] = {}
        self.q_explore: Dict[Tuple[str, str], float] = {}
        self.q_causal: Dict[Tuple[str, str], float] = {}
        self.q_safety: Dict[Tuple[str, str], float] = {}
        
        # Adaptive weights (can change based on phase)
        self.weights = {
            'task': self.config.get('task_weight', 0.5),
            'explore': self.config.get('explore_weight', 0.2),
            'causal': self.config.get('causal_weight', 0.15),
            'safety': self.config.get('safety_weight', 0.15)
        }
        
        # Default values
        self.default_value = self.config.get('default_value', 0.5)
        
        # Learning rates per objective
        self.alphas = {
            'task': self.config.get('alpha_task', 0.05),
            'explore': self.config.get('alpha_explore', 0.1),
            'causal': self.config.get('alpha_causal', 0.08),
            'safety': self.config.get('alpha_safety', 0.03)
        }
    
    def get_q_value(self, state: AgenticState, action: str, objective: str = None) -> float:
        """Get Q-value for state-action pair."""
        state_key = state.to_key()
        key = (state_key, action)
        
        if objective:
            q_table = getattr(self, f'q_{objective}', self.q_task)
            return q_table.get(key, self.default_value)
        
        # Combined value
        return self.get_combined_value(state, action)
    
    def get_combined_value(self, state: AgenticState, action: str) -> float:
        """Get weighted combination of all Q-values."""
        state_key = state.to_key()
        key = (state_key, action)
        
        q_t = self.q_task.get(key, self.default_value)
        q_e = self.q_explore.get(key, self.default_value)
        q_c = self.q_causal.get(key, self.default_value)
        q_s = self.q_safety.get(key, self.default_value)
        
        return (self.weights['task'] * q_t +
                self.weights['explore'] * q_e +
                self.weights['causal'] * q_c +
                self.weights['safety'] * q_s)
    
    def update(self, 
               state: AgenticState, 
               action: str,
               reward_decomposition: Dict[str, float],
               next_state: AgenticState,
               gamma: float = 0.95):
        """
        Update all Q-functions with decomposed rewards.
        
        reward_decomposition should have keys: 'task', 'explore', 'causal', 'safety'
        """
        state_key = state.to_key()
        next_state_key = next_state.to_key()
        key = (state_key, action)
        
        for objective in ['task', 'explore', 'causal', 'safety']:
            q_table = getattr(self, f'q_{objective}')
            alpha = self.alphas[objective]
            
            # Current Q-value
            current_q = q_table.get(key, self.default_value)
            
            # Reward for this objective
            reward = reward_decomposition.get(objective, 0.0)
            
            # Max Q for next state (greedy)
            next_q_values = [
                q_table.get((next_state_key, a), self.default_value)
                for a in self._get_possible_actions(next_state)
            ]
            max_next_q = max(next_q_values) if next_q_values else self.default_value
            
            # TD update
            td_target = reward + gamma * max_next_q
            td_error = td_target - current_q
            new_q = current_q + alpha * td_error
            
            q_table[key] = new_q
    
    def _get_possible_actions(self, state: AgenticState) -> List[str]:
        """
        Get possible actions for a state by introspecting the Q-tables.
        
        🔴 A-TEAM FIX: Replaced hardcoded ['proceed', 'retry', 'refine', 'escalate']
        with dynamic action discovery from learned Q-table entries.
        
        Strategy:
        1. Collect all unique actions observed across all Q-tables
        2. If no actions have been observed yet, return configurable default set
        """
        # Collect all unique actions from all Q-tables
        observed_actions = set()
        for q_table in [self.q_task, self.q_explore, self.q_causal, self.q_safety]:
            for (_, action) in q_table.keys():
                observed_actions.add(action)
        
        if observed_actions:
            return list(observed_actions)
        
        # Bootstrap defaults (only used until first experience is recorded)
        return self.config.get('default_actions', ['proceed', 'retry', 'refine', 'escalate'])
    
    def adjust_weights(self, phase: str):
        """
        Adjust weights based on learning phase.
        
        🔴 A-TEAM FIX: Replaced hardcoded phase-to-weights mappings with
        config-driven presets. Unknown phases leave weights unchanged.
        """
        # Config-driven phase presets (user can override in config)
        phase_presets = self.config.get('phase_weight_presets', {
            'exploration':     {'task': 0.3, 'explore': 0.4, 'causal': 0.2, 'safety': 0.1},
            'exploitation':    {'task': 0.6, 'explore': 0.1, 'causal': 0.15, 'safety': 0.15},
            'safety_critical': {'task': 0.3, 'explore': 0.1, 'causal': 0.1, 'safety': 0.5},
        })
        
        if phase in phase_presets:
            self.weights = phase_presets[phase].copy()
        else:
            logger.warning(f"⚠️ Unknown phase '{phase}' — weights unchanged. "
                           f"Known phases: {list(phase_presets.keys())}")
    
    def get_action_ranking(self, state: AgenticState, actions: List[str]) -> List[Tuple[str, float]]:
        """Rank actions by combined Q-value."""
        rankings = []
        for action in actions:
            value = self.get_combined_value(state, action)
            rankings.append((action, value))
        return sorted(rankings, key=lambda x: x[1], reverse=True)
    
    def to_dict(self) -> Dict:
        """Serialize to dictionary."""
        return {
            'q_task': {f"{k[0]}|{k[1]}": v for k, v in self.q_task.items()},
            'q_explore': {f"{k[0]}|{k[1]}": v for k, v in self.q_explore.items()},
            'q_causal': {f"{k[0]}|{k[1]}": v for k, v in self.q_causal.items()},
            'q_safety': {f"{k[0]}|{k[1]}": v for k, v in self.q_safety.items()},
            'weights': self.weights,
            'alphas': self.alphas
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'DecomposedQFunction':
        """Deserialize from dictionary."""
        qfunc = cls()
        
        def parse_key(key_str):
            parts = key_str.rsplit('|', 1)
            return (parts[0], parts[1]) if len(parts) == 2 else (key_str, '')
        
        qfunc.q_task = {parse_key(k): v for k, v in data.get('q_task', {}).items()}
        qfunc.q_explore = {parse_key(k): v for k, v in data.get('q_explore', {}).items()}
        qfunc.q_causal = {parse_key(k): v for k, v in data.get('q_causal', {}).items()}
        qfunc.q_safety = {parse_key(k): v for k, v in data.get('q_safety', {}).items()}
        qfunc.weights = data.get('weights', qfunc.weights)
        qfunc.alphas = data.get('alphas', qfunc.alphas)
        
        return qfunc


# =============================================================================
# MARKOVIAN TODO - Long Horizon Task Management
# =============================================================================

class TaskStatus(Enum):
    """Status of a subtask."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


@dataclass
class SubtaskState:
    """
    State of an individual subtask.
    
    UNIFIED TASK REPRESENTATION - Merges features from TaskItem and SubtaskState
    to provide complete RL-ready task tracking with NO HARDCODED VALUES.
    """
    # Identity
    task_id: str
    description: str
    actor: str = ""  # Which actor/agent executes this task
    
    # Status
    status: TaskStatus = TaskStatus.PENDING
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)
    blocks: List[str] = field(default_factory=list)
    
    # Progress
    attempts: int = 0
    max_attempts: int = 3  # Can be overridden per task
    progress: float = 0.0  # 0.0 to 1.0
    
    # RL Attributes (for Q-learning)
    priority: float = 1.0  # Task priority (0-inf, higher = more important)
    estimated_reward: float = 0.5  # Q-value estimate (0-1)
    confidence: float = 0.5  # Confidence in Q-value (0-1)
    
    # Timing
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    estimated_duration: float = 60.0  # seconds (can be learned)
    
    # Intermediary Values (NO HARDCODING - stores runtime metrics)
    intermediary_values: Dict[str, Any] = field(default_factory=dict)
    # e.g., {"llm_calls": 8, "time_elapsed": 4.2, "protection_blocks": 2}
    
    # Predictions (for predictive MARL)
    predicted_next_task: Optional[str] = None
    predicted_duration: Optional[float] = None
    predicted_reward: Optional[float] = None
    
    # Learning History
    failure_reasons: List[str] = field(default_factory=list)
    
    # 🎯 A-TEAM: Retry and re-evaluation tracking
    retry_feedback: List[Dict[str, Any]] = field(default_factory=list)  # Feedback history for retries
    replaced_by: List[str] = field(default_factory=list)  # Task IDs that replaced this task
    permanent_failure_reason: Optional[str] = None  # Reason for permanent failure
    
    # Outcome
    result: Optional[Dict] = None
    error: Optional[str] = None
    
    def can_start(self, completed_tasks: Set[str]) -> bool:
        """Check if all dependencies are satisfied."""
        return all(dep in completed_tasks for dep in self.depends_on)
    
    def start(self):
        """Mark task as started."""
        self.status = TaskStatus.IN_PROGRESS
        self.started_at = datetime.now()
        self.attempts += 1
    
    def complete(self, result: Dict = None, completion_ratio: float = 1.0):
        """Mark task as completed."""
        self.status = TaskStatus.COMPLETED
        self.completed_at = datetime.now()
        try:
            completion_ratio = float(completion_ratio)
        except Exception:
            completion_ratio = 1.0
        self.progress = max(0.0, min(1.0, completion_ratio))
        self.result = result
    
    def fail(self, error: str):
        """Mark task as failed or pending retry.
        
        🔴 A-TEAM FIX: Track failure history in failure_reasons list
        so learning systems can access full failure trajectory.
        """
        self.failure_reasons.append(error)  # Track ALL failures for learning
        self.error = error
        if self.attempts >= self.max_attempts:
            self.status = TaskStatus.FAILED
        else:
            self.status = TaskStatus.PENDING  # Retry


@dataclass
class MarkovianTODO:
    """
    Long-horizon task management with Markov state tracking.
    
    A-Team Enhancement: Handles 100+ step tasks with:
    - Task hierarchy decomposition
    - Dependency tracking
    - State transition probabilities
    - Progress estimation
    - Checkpoint/resume support
    
    Dr. Agarwal: "Real tasks need structured tracking"
    """
    
    # Identity
    todo_id: str = ""
    root_task: str = ""
    
    # Task Hierarchy
    subtasks: Dict[str, SubtaskState] = field(default_factory=dict)
    execution_order: List[str] = field(default_factory=list)
    current_task_id: Optional[str] = None
    
    # State Tracking
    completed_tasks: Set[str] = field(default_factory=set)
    failed_tasks: Set[str] = field(default_factory=set)
    
    # 🔴 A-TEAM FIX: Track completion ORDER (set has no ordering)
    _completion_order: List[str] = field(default_factory=list)
    
    # Transition Probabilities (learned)
    transition_probs: Dict[Tuple[str, str], float] = field(default_factory=dict)
    
    # Predictions
    estimated_remaining_steps: int = 0
    completion_probability: float = 0.5
    risk_factors: List[str] = field(default_factory=list)
    
    # Checkpointing
    checkpoints: List[Dict] = field(default_factory=list)
    last_checkpoint: Optional[datetime] = None
    
    # 🔴 A-TEAM FIX: Archive deleted/completed tasks so agents retain full context
    # Even when a task is deleted (by TODO adapter), its description, actor,
    # and outcome are preserved here.  This prevents information loss.
    _deleted_tasks_archive: List[Dict[str, Any]] = field(default_factory=list)
    
    @property
    def current_path(self) -> List[str]:
        """Return the current execution path (ordered completed tasks) for exploration tracking.
        
        🔴 A-TEAM FIX: Use _completion_order (list) instead of completed_tasks (set).
        Sets have no ordering, so list(set) was returning an arbitrary order,
        breaking exploration tracking that depends on chronological sequence.
        """
        return list(self._completion_order)
    
    def __post_init__(self):
        if not self.todo_id:
            self.todo_id = hashlib.md5(
                f"{self.root_task}:{datetime.now().isoformat()}".encode()
            ).hexdigest()
    
    def add_task(self, 
                 task_id: str, 
                 description: str,
                 actor: str = "",
                 depends_on: List[str] = None,
                 estimated_duration: float = 60.0,
                 priority: float = 1.0):
        """
        Add a subtask - NO HARDCODING.
        
        All parameters are configurable at runtime.
        """
        add_start = time.time()
        logger.info(f"➕ ADD_TASK: MarkovianTODO | task_id={task_id} | actor={actor} | "
                   f"description_length={len(description)} | depends_on={len(depends_on) if depends_on else 0}")
        
        self.subtasks[task_id] = SubtaskState(
            task_id=task_id,
            description=description,
            actor=actor,
            depends_on=depends_on or [],
            estimated_duration=estimated_duration,
            priority=priority
        )
        if task_id not in self.execution_order:
            self.execution_order.append(task_id)
        
        update_start = time.time()
        self._update_blocks()
        self._estimate_remaining()
        update_duration = time.time() - update_start
        
        duration = time.time() - add_start
        logger.info(f"✅ ADD_TASK COMPLETE: MarkovianTODO | task_id={task_id} | "
                   f"total_tasks={len(self.subtasks)} | duration={duration:.3f}s")
    
    def _update_blocks(self):
        """Update which tasks block which."""
        # Recompute from scratch each time to avoid duplicate block entries.
        for task in self.subtasks.values():
            task.blocks = []
        for task_id, task in self.subtasks.items():
            for dep_id in task.depends_on:
                if dep_id in self.subtasks:
                    self.subtasks[dep_id].blocks.append(task_id)
    
    def get_next_task(self) -> Optional[SubtaskState]:
        """
        Get next task OBJECT that can be started.
        
        🔴 A-TEAM FIX 19: RL-driven task selection.
        Instead of blindly following static execution_order, collect ALL ready 
        tasks and rank them by expected value:
            score = priority * estimated_reward * confidence * urgency_factor
        
        This means Q-learning updates to estimated_reward and confidence 
        directly influence task selection without needing to reorder the list.
        
        Falls back to execution_order position for tie-breaking.
        
        Returns SubtaskState object (not string ID) to match
        SwarmReVal interface expectations (task.actor, task.description, etc.)
        """
        get_start = time.time()
        logger.info(f"🔍 GET_NEXT_TASK: MarkovianTODO | total_tasks={len(self.subtasks)} | "
                   f"completed={len(self.completed_tasks)} | execution_order_length={len(self.execution_order)}")
        
        # Collect ALL ready tasks (not just the first one)
        ready_tasks = []
        checked_count = 0
        for task_id in self.execution_order:
            if task_id not in self.subtasks:
                continue
            task = self.subtasks[task_id]
            checked_count += 1
            if task.status == TaskStatus.PENDING and task.can_start(self.completed_tasks):
                ready_tasks.append(task)
        
        if not ready_tasks:
            duration = time.time() - get_start
            logger.info(f"⚠️  GET_NEXT_TASK: No available task | checked={checked_count} | duration={duration:.3f}s")
            return None
        
        if len(ready_tasks) == 1:
            selected = ready_tasks[0]
            duration = time.time() - get_start
            logger.info(f"✅ GET_NEXT_TASK FOUND: MarkovianTODO | task_id={selected.task_id} | "
                       f"actor={selected.actor} | checked={checked_count} | duration={duration:.3f}s")
            return selected
        
        # 🔴 A-TEAM FIX: RL-driven scoring for multiple ready tasks
        # score = priority * estimated_reward * confidence * urgency_factor
        # urgency_factor penalizes tasks that have been waiting (attempts > 0 means retried)
        def task_score(task: SubtaskState) -> float:
            urgency = 1.0 + (0.2 * task.attempts)  # Retried tasks get slight boost
            # Blocked-then-unblocked tasks get urgency boost
            if task.depends_on:
                urgency *= 1.1  # Tasks with satisfied deps are more urgent
            score = task.priority * task.estimated_reward * task.confidence * urgency
            return score
        
        # Sort by score (descending), then by execution_order position (ascending) for ties
        order_index = {tid: i for i, tid in enumerate(self.execution_order)}
        ready_tasks.sort(
            key=lambda t: (-task_score(t), order_index.get(t.task_id, float('inf')))
        )
        
        selected = ready_tasks[0]
        duration = time.time() - get_start
        logger.info(
            f"✅ GET_NEXT_TASK FOUND (RL-scored): MarkovianTODO | task_id={selected.task_id} | "
            f"actor={selected.actor} | score={task_score(selected):.3f} | "
            f"ready_count={len(ready_tasks)} | checked={checked_count} | duration={duration:.3f}s"
        )
        return selected

    def unblock_ready_tasks(self) -> int:
        """
        Unblock tasks whose dependencies have been satisfied.
        
        This enables true "await dependency" semantics:
        - A task can be BLOCKED while waiting for upstream outputs.
        - Once all deps are completed, it becomes PENDING again.
        
        Returns:
            Number of tasks unblocked.
        """
        unblock_start = time.time()
        logger.info(f"🔓 UNBLOCK_READY_TASKS: MarkovianTODO | checking {len(self.subtasks)} tasks")
        
        unblocked = 0
        unblocked_tasks = []
        for task in self.subtasks.values():
            if task.status == TaskStatus.BLOCKED and task.can_start(self.completed_tasks):
                task.status = TaskStatus.PENDING
                unblocked += 1
                unblocked_tasks.append(task.task_id)
                logger.debug(f"    Unblocked task: {task.task_id} | actor={task.actor}")
        
        duration = time.time() - unblock_start
        logger.info(f"✅ UNBLOCK_READY_TASKS COMPLETE: MarkovianTODO | unblocked={unblocked} | "
                   f"tasks={unblocked_tasks} | duration={duration:.3f}s")
        
        return unblocked
    
    def start_task(self, task_id: str):
        """Start a task."""
        logger.info(f"▶️  START_TASK: MarkovianTODO | task_id={task_id}")
        
        if task_id in self.subtasks:
            task = self.subtasks[task_id]
            task.start()
            self.current_task_id = task_id
            logger.info(f"✅ START_TASK COMPLETE: MarkovianTODO | task_id={task_id} | "
                       f"actor={task.actor} | status={task.status.value}")
        else:
            logger.warning(f"⚠️  START_TASK FAILED: Task {task_id} not found")
    
    def complete_task(self, task_id: str, result: Dict = None, completion_ratio: float = 1.0):
        """Mark task as completed (idempotent: no-op if already completed)."""
        complete_start = time.time()
        # Idempotency guard: skip if already completed
        if task_id in self.completed_tasks:
            logger.info(f"⏭️  COMPLETE_TASK: Skipped (already completed) | task_id={task_id}")
            return
        # Handle both dict and non-dict results for logging
        if result is None:
            result_str = 'None'
        elif isinstance(result, dict):
            result_str = f"keys={list(result.keys())}"
        else:
            result_str = f"value={result}"
        logger.info(f"✅ COMPLETE_TASK: MarkovianTODO | task_id={task_id} | "
                   f"result={result_str}")
        
        if task_id in self.subtasks:
            task = self.subtasks[task_id]
            task.complete(result, completion_ratio)
            self.completed_tasks.add(task_id)
            self._completion_order.append(task_id)  # 🔴 A-TEAM FIX: Track order
            if self.current_task_id == task_id:
                self.current_task_id = None
            
            estimate_start = time.time()
            self._estimate_remaining()
            estimate_duration = time.time() - estimate_start
            
            # Update transition probabilities
            # 🔴 A-TEAM FIX: Use _completion_order (list) instead of set for reliable ordering
            if len(self._completion_order) > 1:
                prev_task = self._completion_order[-2]
                key = (prev_task, task_id)
                self.transition_probs[key] = self.transition_probs.get(key, 0) + 1
                logger.debug(f"    Updated transition prob: {prev_task} -> {task_id}")
            
            duration = time.time() - complete_start
            logger.info(f"✅ COMPLETE_TASK COMPLETE: MarkovianTODO | task_id={task_id} | "
                       f"completed_count={len(self.completed_tasks)} | "
                       f"estimate_duration={estimate_duration:.3f}s | total_duration={duration:.3f}s")
        else:
            logger.warning(f"⚠️  COMPLETE_TASK FAILED: Task {task_id} not found")
    
    def insert_task_after(self, after_task_id: str, new_task: SubtaskState):
        """
        Insert a new task after a specific task in execution order.
        
        🎯 A-TEAM: Dynamic task insertion for adaptive planning.
        """
        logger.info(f"➕ INSERT_TASK_AFTER: MarkovianTODO | after={after_task_id} | new_task={new_task.task_id}")
        
        # Add task to subtasks
        self.subtasks[new_task.task_id] = new_task
        
        # Insert in execution order after the specified task
        try:
            index = self.execution_order.index(after_task_id)
            self.execution_order.insert(index + 1, new_task.task_id)
            logger.info(f"✅ Inserted {new_task.task_id} after {after_task_id} at index {index + 1}")
        except ValueError:
            # Task not in execution order, append at end
            self.execution_order.append(new_task.task_id)
            logger.warning(f"⚠️  {after_task_id} not in execution order, appended {new_task.task_id} at end")
        
        self._update_blocks()
        self._estimate_remaining()
    
    def update_task(self, task_id: str, **updates):
        """
        Update task properties dynamically.
        
        🎯 A-TEAM: LLM-based task mutation.
        """
        logger.info(f"🔄 UPDATE_TASK: MarkovianTODO | task_id={task_id} | updates={list(updates.keys())}")
        
        if task_id not in self.subtasks:
            logger.warning(f"⚠️  UPDATE_TASK FAILED: Task {task_id} not found")
            return
        
        task = self.subtasks[task_id]
        for key, value in updates.items():
            if hasattr(task, key):
                setattr(task, key, value)
                logger.debug(f"    Updated {key} = {value}")
            else:
                logger.warning(f"⚠️  Task has no attribute '{key}'")
        
        self._update_blocks()
        self._estimate_remaining()
        logger.info(f"✅ UPDATE_TASK COMPLETE: {task_id}")
    
    def delete_task(self, task_id: str):
        """
        Delete a task from the active TODO.
        
        🔴 A-TEAM FIX: SOFT DELETE — archives the task first so agents retain
        context about what was planned/done.  The Markov process and memory
        already store high-level outcomes, but the concrete task description,
        actor, attempt count, and failure reasons are only here.
        
        Archived tasks appear in get_state_summary() under "🗑️ Archived" so the
        LLM can reason about previously attempted/completed work without
        re-planning the same action.
        """
        logger.info(f"🗑️  DELETE_TASK: MarkovianTODO | task_id={task_id}")
        
        if task_id not in self.subtasks:
            logger.warning(f"⚠️  DELETE_TASK FAILED: Task {task_id} not found")
            return
        
        # ── Archive before removing ──
        task = self.subtasks[task_id]
        self._deleted_tasks_archive.append({
            'task_id': task_id,
            'description': task.description,
            'actor': task.actor,
            'status': task.status.value,
            'attempts': task.attempts,
            'failure_reasons': list(task.failure_reasons),
            'result': task.result,
            'deleted_at': datetime.now().isoformat(),
            'was_completed': task_id in self.completed_tasks,
        })
        logger.info(f"📦 Archived task {task_id} before deletion (archive size={len(self._deleted_tasks_archive)})")
        
        # Remove from subtasks
        del self.subtasks[task_id]
        
        # Remove from execution order
        if task_id in self.execution_order:
            self.execution_order.remove(task_id)
        
        # Remove from completed/failed sets
        self.completed_tasks.discard(task_id)
        self.failed_tasks.discard(task_id)
        
        # Remove dependencies on this task
        for task in self.subtasks.values():
            if task_id in task.depends_on:
                task.depends_on.remove(task_id)
            if task_id in task.blocks:
                task.blocks.remove(task_id)
        
        self._update_blocks()
        self._estimate_remaining()
        logger.info(f"✅ DELETE_TASK COMPLETE: {task_id} (archived)")
    
    def reprioritize(self, priority_map: Dict[str, float]):
        """
        Update priorities for multiple tasks.
        
        🎯 A-TEAM: Dynamic priority adjustment based on learning.
        """
        logger.info(f"🔢 REPRIORITIZE: MarkovianTODO | tasks={len(priority_map)}")
        
        for task_id, new_priority in priority_map.items():
            if task_id in self.subtasks:
                old_priority = self.subtasks[task_id].priority
                self.subtasks[task_id].priority = new_priority
                logger.debug(f"    {task_id}: {old_priority:.2f} → {new_priority:.2f}")
            else:
                logger.warning(f"⚠️  Task {task_id} not found for reprioritization")
        
        logger.info(f"✅ REPRIORITIZE COMPLETE")
    
    def reorder_tasks(self, new_order: List[str]):
        """
        Reorder execution sequence.
        
        🎯 A-TEAM: LLM-based task reordering for optimal execution.
        """
        logger.info(f"🔄 REORDER_TASKS: MarkovianTODO | new_order_length={len(new_order)}")
        
        # Validate all tasks exist
        for task_id in new_order:
            if task_id not in self.subtasks:
                logger.warning(f"⚠️  REORDER_TASKS FAILED: Task {task_id} not found")
                return
        
        # Ensure all existing tasks are in new order
        missing = set(self.subtasks.keys()) - set(new_order)
        if missing:
            logger.warning(f"⚠️  REORDER_TASKS: Missing tasks in new order: {missing}")
            # Append missing tasks at end
            new_order.extend(list(missing))
        
        self.execution_order = new_order
        logger.info(f"✅ REORDER_TASKS COMPLETE: new_order={new_order[:5]}...")
    
    def fail_task(self, task_id: str, error: str):
        """Mark task as failed (idempotent: no-op if already permanently failed)."""
        fail_start = time.time()
        # Idempotency guard: skip if already failed (prevents double counting / side effects)
        if task_id in self.failed_tasks:
            logger.info(f"⏭️  FAIL_TASK: Skipped (already failed) | task_id={task_id}")
            return
        logger.info(f"❌ FAIL_TASK: MarkovianTODO | task_id={task_id} | "
                   f"error_length={len(error)}")
        logger.debug(f"    Error: {error[:200]}{'...' if len(error) > 200 else ''}")
        
        if task_id in self.subtasks:
            task = self.subtasks[task_id]
            task.fail(error)
            if task.status == TaskStatus.FAILED:
                self.failed_tasks.add(task_id)
            
            estimate_start = time.time()
            self._estimate_remaining()
            estimate_duration = time.time() - estimate_start
            
            duration = time.time() - fail_start
            logger.info(f"❌ FAIL_TASK COMPLETE: MarkovianTODO | task_id={task_id} | "
                       f"failed_count={len(self.failed_tasks)} | "
                       f"estimate_duration={estimate_duration:.3f}s | total_duration={duration:.3f}s")
        else:
            logger.warning(f"⚠️  FAIL_TASK FAILED: Task {task_id} not found")
    
    def mark_for_retry(self, task_id: str, feedback: str, execution_guidance: Dict[str, Any] = None):
        """
        🎯 A-TEAM: Mark task for retry with feedback context.
        
        🔴 A-TEAM FIX: DO NOT increment attempts here!
        Attempts are incremented by task.start() when the task begins execution.
        mark_for_retry only resets status to PENDING and stores feedback.
        Double-incrementing was causing tasks to exhaust max_attempts too fast
        and created infinite loops when combined with the missing start() call.
        
        Args:
            task_id: Task to mark for retry
            feedback: Feedback to inject into next attempt
            execution_guidance: Strategy execution guidance (approach changes, parameter modifications, etc.)
        """
        if task_id in self.subtasks:
            task = self.subtasks[task_id]
            # Guard against infinite retry loops.
            # task.attempts is already incremented by task.start() for the current attempt
            if task.attempts >= task.max_attempts:
                task.status = TaskStatus.FAILED
                self.failed_tasks.add(task_id)
                logger.warning(
                    f"⚠️  MARK_FOR_RETRY: Max attempts reached for {task_id} "
                    f"({task.attempts}/{task.max_attempts}); marking failed"
                )
                return

            # 🔴 A-TEAM FIX: Do NOT increment attempts here — start() does that
            # Just reset status to PENDING so get_next_task() will pick it up
            task.status = TaskStatus.PENDING
            
            # Store retry feedback and guidance
            if not hasattr(task, 'retry_feedback'):
                task.retry_feedback = []
            task.retry_feedback.append({
                'feedback': feedback,
                'execution_guidance': execution_guidance or {},
                'timestamp': datetime.now().isoformat()
            })
            
            # Remove from failed tasks if it was there
            self.failed_tasks.discard(task_id)
            
            logger.info(f"🔄 Task {task_id} marked for retry (attempt {task.attempts}/{task.max_attempts})")
        else:
            logger.warning(f"⚠️  MARK_FOR_RETRY FAILED: Task {task_id} not found")
    
    def mark_task_replaced(self, old_task_id: str, new_task_ids: List[str]):
        """
        🎯 A-TEAM: Mark task as replaced by new tasks.
        
        Args:
            old_task_id: Original task that was replaced
            new_task_ids: List of new task IDs that replace it
        """
        if old_task_id in self.subtasks:
            task = self.subtasks[old_task_id]
            task.status = TaskStatus.SKIPPED
            
            # Store replacement info
            if not hasattr(task, 'replaced_by'):
                task.replaced_by = []
            task.replaced_by.extend(new_task_ids)
            
            # Update dependencies: tasks that depended on old_task_id now depend on new_task_ids
            for other_task_id, other_task in self.subtasks.items():
                if old_task_id in other_task.depends_on:
                    # Remove old dependency
                    other_task.depends_on.remove(old_task_id)
                    # Add new dependencies
                    other_task.depends_on.extend(new_task_ids)
                    logger.debug(f"   Updated dependencies for {other_task_id}: removed {old_task_id}, added {new_task_ids}")
            
            logger.info(f"🔄 Task {old_task_id} marked as replaced by {len(new_task_ids)} new tasks: {new_task_ids}")
        else:
            logger.warning(f"⚠️  MARK_TASK_REPLACED FAILED: Task {old_task_id} not found")
    
    def mark_task_permanent_failure(self, task_id: str, reason: str):
        """
        🎯 A-TEAM: Mark task as permanent failure (won't be retried).
        
        Args:
            task_id: Task to mark as permanent failure
            reason: Why this task cannot succeed
        """
        if task_id in self.subtasks:
            task = self.subtasks[task_id]
            task.status = TaskStatus.FAILED
            task.attempts = task.max_attempts  # Set to max to prevent retries
            
            # 🔴 A-TEAM FIX: Store permanent failure reason unconditionally.
            # Previous code used `if not hasattr(task, 'permanent_failure_reason')`
            # but hasattr() always returns True for dataclass fields (even if None),
            # so the reason was NEVER stored.
            task.permanent_failure_reason = reason
            
            self.failed_tasks.add(task_id)
            
            logger.info(f"🛑 Task {task_id} marked as permanent failure: {reason[:100]}")
        else:
            logger.warning(f"⚠️  MARK_TASK_PERMANENT_FAILURE FAILED: Task {task_id} not found")
    
    def _estimate_remaining(self):
        """Estimate remaining steps and completion probability.
        
        🔴 A-TEAM FIX: Improved heuristic that accounts for:
        - Tasks blocked by permanent failures (unreachable)
        - Success rate momentum (recent completions vs failures)
        - Retry-exhausted tasks
        
        NOTE: Not LLM-based because this runs on every complete_task()/fail_task()
        call. The periodic AgenticTODOAdapter provides LLM-based replanning.
        """
        total = len(self.subtasks)
        if total == 0:
            self.estimated_remaining_steps = 0
            self.completion_probability = 1.0
            return
        
        completed = len(self.completed_tasks)
        permanently_failed = sum(
            1 for t in self.subtasks.values()
            if t.status == TaskStatus.FAILED and t.attempts >= t.max_attempts
        )
        
        # Tasks blocked by permanent failures (can never complete)
        blocked_by_failure = sum(
            1 for t in self.subtasks.values()
            if t.status == TaskStatus.PENDING and any(
                dep in self.failed_tasks for dep in t.depends_on
            )
        )
        
        # 🔴 A-TEAM FIX: Remaining should exclude completed, skipped, AND permanently
        # failed tasks (plus those blocked by failures). Previously, permanently failed
        # tasks were counted as "remaining" which inflated the estimate.
        remaining = [
            t for t in self.subtasks.values()
            if t.status not in [TaskStatus.COMPLETED, TaskStatus.SKIPPED]
            and not (t.status == TaskStatus.FAILED and t.attempts >= t.max_attempts)
            and not (t.status == TaskStatus.PENDING and any(
                dep in self.failed_tasks for dep in t.depends_on
            ))
        ]
        self.estimated_remaining_steps = len(remaining)
        
        achievable = total - permanently_failed - blocked_by_failure
        if achievable > 0:
            self.completion_probability = completed / achievable
        else:
            self.completion_probability = 0.0
        
        self.completion_probability = max(0.0, min(1.0, self.completion_probability))
    
    def checkpoint(self) -> Dict:
        """Create checkpoint of current state."""
        checkpoint = {
            'todo_id': self.todo_id,
            'timestamp': datetime.now().isoformat(),
            'current_task_id': self.current_task_id,
            'completed_tasks': list(self.completed_tasks),
            'failed_tasks': list(self.failed_tasks),
            'subtask_states': {
                tid: {
                    'status': t.status.value,
                    'progress': t.progress,
                    'attempts': t.attempts
                }
                for tid, t in self.subtasks.items()
            }
        }
        self.checkpoints.append(checkpoint)
        self.last_checkpoint = datetime.now()
        return checkpoint
    
    def restore_from_checkpoint(self, checkpoint: Dict):
        """Restore state from checkpoint."""
        self.current_task_id = checkpoint.get('current_task_id')
        self.completed_tasks = set(checkpoint.get('completed_tasks', []))
        self.failed_tasks = set(checkpoint.get('failed_tasks', []))
        
        for tid, state in checkpoint.get('subtask_states', {}).items():
            if tid in self.subtasks:
                self.subtasks[tid].status = TaskStatus(state['status'])
                self.subtasks[tid].progress = state['progress']
                self.subtasks[tid].attempts = state['attempts']
    
    def get_progress_summary(self) -> str:
        """Get human-readable progress summary."""
        total = len(self.subtasks)
        completed = len(self.completed_tasks)
        failed = len(self.failed_tasks)
        in_progress = sum(1 for t in self.subtasks.values() if t.status == TaskStatus.IN_PROGRESS)
        
        return (
            f"TODO Progress: {completed}/{total} completed "
            f"({in_progress} in progress, {failed} failed)\n"
            f"Current: {self.current_task_id or 'None'}\n"
            f"Estimated remaining: {self.estimated_remaining_steps} steps\n"
            f"Completion probability: {self.completion_probability:.1%}"
        )
    
    def should_replan(
        self,
        elapsed_time: float = 0.0,
        global_deadline: float = 0.0,
        replan_interval: float = 60.0,
        success_threshold: float = 0.7
    ) -> Tuple[bool, str]:
        """
        🔬 A-TEAM ENHANCEMENT: Progress-based replanning.
        
        🔴 A-TEAM FIX: Removed ALL time-based triggers (DEADLINE_EXCEEDED, BEHIND_SCHEDULE).
        Time-based termination was randomly killing tasks that just needed more iterations.
        Replanning is now driven ONLY by failure patterns and stuck detection.
        
        Returns:
            (should_replan: bool, reason: str)
        """
        total = len(self.subtasks)
        if total == 0:
            return False, "No tasks to replan"
        
        completed = len(self.completed_tasks)
        failed = len(self.failed_tasks)
        
        # 1. HIGH FAILURE RATE CHECK (pattern-based, not time-based)
        if total > 0 and failed / total > 0.3:
            return True, f"HIGH_FAILURE_RATE: {failed}/{total} = {failed/total:.1%} failed"
        
        # 2. STUCK CHECK: tasks attempted too many times without progress
        stuck_tasks = [
            t for t in self.subtasks.values()
            if t.status == TaskStatus.IN_PROGRESS and t.attempts > 3
        ]
        if stuck_tasks:
            stuck_ids = [t.task_id for t in stuck_tasks]
            return True, f"STUCK_TASKS: {len(stuck_tasks)} tasks with >3 attempts: {stuck_ids[:3]}"
        
        # 3. REPEATED FAILURE PATTERN CHECK: same tasks failing with same errors
        repeated_failure_tasks = []
        for t in self.subtasks.values():
            if len(t.failure_reasons) >= 2:
                # Check if last 2 failures have similar patterns
                recent = t.failure_reasons[-2:]
                if len(set(recent)) == 1:  # Exact same error
                    repeated_failure_tasks.append(t.task_id)
        if len(repeated_failure_tasks) >= 2:
            return True, f"REPEATED_FAILURES: {len(repeated_failure_tasks)} tasks with identical consecutive errors"
        
        return False, "On track"
    
    def replan(self, observation: str = "") -> List[str]:
        """
        🔬 A-TEAM ENHANCEMENT: Trigger replanning.
        
        Actions:
        1. Skip blocked tasks with failed dependencies
        2. Reprioritize based on remaining time
        3. Add emergency subtasks if needed
        
        Returns: List of actions taken
        """
        actions = []
        
        # 1. Skip tasks blocked by failures
        for task_id, task in self.subtasks.items():
            if task.status in [TaskStatus.PENDING, TaskStatus.BLOCKED]:
                # Check if any dependency failed
                failed_deps = [dep for dep in task.depends_on if dep in self.failed_tasks]
                if failed_deps:
                    task.status = TaskStatus.SKIPPED
                    actions.append(f"SKIP:{task_id} (deps failed: {failed_deps})")
        
        # 2. Reprioritize remaining tasks
        pending = [
            t for t in self.subtasks.values()
            if t.status in [TaskStatus.PENDING, TaskStatus.BLOCKED]
        ]
        if pending:
            # Sort by: priority * (1 / (1 + len(depends_on)))
            pending.sort(
                key=lambda t: t.priority * (1.0 / (1.0 + len(t.depends_on))),
                reverse=True
            )
            new_order = [t.task_id for t in pending]
            actions.append(f"REPRIORITIZE: {new_order[:3]}...")
        
        # 3. Add observation to risk factors
        if observation:
            self.risk_factors.append(f"[REPLAN] {observation}")
            actions.append(f"RISK_NOTED: {observation[:50]}")
        
        self._estimate_remaining()
        
        return actions
    
    def to_dict(self) -> Dict:
        """Serialize to dictionary.
        
        🔴 A-TEAM FIX: Serialize ALL fields needed for faithful state restoration.
        Previously missing: estimated_reward, confidence, max_attempts, result,
        error, retry_feedback, replaced_by, permanent_failure_reason,
        intermediary_values, started_at, completed_at.
        """
        return {
            'todo_id': self.todo_id,
            'root_task': self.root_task,
            'subtasks': {
                tid: {
                    'description': t.description,
                    'actor': t.actor,
                    'status': t.status.value,
                    'depends_on': t.depends_on,
                    'progress': t.progress,
                    'attempts': t.attempts,
                    'max_attempts': t.max_attempts,
                    'failure_reasons': t.failure_reasons,
                    'estimated_duration': t.estimated_duration,
                    'priority': t.priority,
                    # 🔴 A-TEAM FIX: RL state — critical for learning continuity
                    'estimated_reward': t.estimated_reward,
                    'confidence': t.confidence,
                    # 🔴 A-TEAM FIX: Task outcomes — needed for context on restore
                    'result': t.result,
                    'error': t.error,
                    # 🔴 A-TEAM FIX: Retry/failure tracking
                    'retry_feedback': t.retry_feedback,
                    'replaced_by': t.replaced_by,
                    'permanent_failure_reason': t.permanent_failure_reason,
                    # 🔴 A-TEAM FIX: Runtime metrics
                    'intermediary_values': t.intermediary_values,
                    # 🔴 A-TEAM FIX: Timing data
                    'started_at': t.started_at.isoformat() if t.started_at else None,
                    'completed_at': t.completed_at.isoformat() if t.completed_at else None,
                }
                for tid, t in self.subtasks.items()
            },
            'execution_order': self.execution_order,
            'current_task_id': self.current_task_id,
            'completed_tasks': list(self.completed_tasks),
            'failed_tasks': list(self.failed_tasks),
            'completion_order': list(self._completion_order),
            'deleted_tasks_archive': self._deleted_tasks_archive,
            'checkpoints': self.checkpoints[-5:],  # Keep last 5
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'MarkovianTODO':
        """
        Restore TODO state from serialized dict.
        
        🔴 A-TEAM FIX: Restore ALL fields that to_dict() serializes.
        Previously missing: failure_reasons, estimated_reward, confidence,
        max_attempts, result, error, retry_feedback, replaced_by,
        permanent_failure_reason, intermediary_values, started_at, completed_at.
        This caused learning history and task outcomes to be silently lost
        on persistence restore.
        """
        todo = cls(
            root_task=data.get('root_task', ''),
            todo_id=data.get('todo_id', '')
        )

        # Restore subtasks with ALL fields
        for tid, tdata in data.get('subtasks', {}).items():
            todo.subtasks[tid] = SubtaskState(
                task_id=tid,
                description=tdata.get('description', ''),
                actor=tdata.get('actor', ''),
                depends_on=tdata.get('depends_on', []),
                estimated_duration=tdata.get('estimated_duration', 60.0),
                priority=tdata.get('priority', 1.0),
            )
            task = todo.subtasks[tid]
            
            # Status
            status_val = tdata.get('status', TaskStatus.PENDING.value)
            try:
                task.status = TaskStatus(status_val)
            except Exception:
                task.status = TaskStatus.PENDING
            
            # Progress and attempts
            task.progress = tdata.get('progress', 0.0)
            task.attempts = tdata.get('attempts', 0)
            task.max_attempts = tdata.get('max_attempts', 3)
            
            # 🔴 A-TEAM FIX: Restore failure/learning history (was silently dropped)
            task.failure_reasons = tdata.get('failure_reasons', [])
            
            # 🔴 A-TEAM FIX: Restore RL state
            task.estimated_reward = tdata.get('estimated_reward', 0.5)
            task.confidence = tdata.get('confidence', 0.5)
            
            # 🔴 A-TEAM FIX: Restore task outcomes
            task.result = tdata.get('result')
            task.error = tdata.get('error')
            
            # 🔴 A-TEAM FIX: Restore retry/failure tracking
            task.retry_feedback = tdata.get('retry_feedback', [])
            task.replaced_by = tdata.get('replaced_by', [])
            task.permanent_failure_reason = tdata.get('permanent_failure_reason')
            
            # 🔴 A-TEAM FIX: Restore runtime metrics
            task.intermediary_values = tdata.get('intermediary_values', {})
            
            # 🔴 A-TEAM FIX: Restore timing data
            started_at = tdata.get('started_at')
            if started_at:
                try:
                    task.started_at = datetime.fromisoformat(started_at)
                except (ValueError, TypeError):
                    task.started_at = None
            
            completed_at = tdata.get('completed_at')
            if completed_at:
                try:
                    task.completed_at = datetime.fromisoformat(completed_at)
                except (ValueError, TypeError):
                    task.completed_at = None

        todo.execution_order = data.get('execution_order', list(todo.subtasks.keys()))
        todo.current_task_id = data.get('current_task_id')
        todo.completed_tasks = set(data.get('completed_tasks', []))
        todo.failed_tasks = set(data.get('failed_tasks', []))
        todo._completion_order = data.get('completion_order', list(todo.completed_tasks))
        todo._deleted_tasks_archive = data.get('deleted_tasks_archive', [])
        todo.checkpoints = data.get('checkpoints', [])
        todo._update_blocks()
        todo._estimate_remaining()
        return todo
    
    # =========================================================================
    # 🎯 A-TEAM FIX: Initialize from LLM-decomposed plan
    # =========================================================================
    
    def initialize_from_plan(self, plan: Dict):
        """
        Initialize TODO from LLM-generated task plan.
        
        🔬 A-TEAM FIX: This is the CRITICAL missing method that connects
        DynamicTaskPlanner output to MarkovianTODO input.
        
        Args:
            plan: Dict with 'tasks' key containing list of task specs.
                  Each task has:
                  - task_id: Semantic identifier (e.g., 'extract_git_history')
                  - agent: Which agent executes this
                  - description: SPECIFIC action description (not "Execute X pipeline")
                  - depends_on: List of task_ids this depends on
                  - inputs_needed: What data from previous tasks
                  - outputs_produced: What this task produces
        
        Example:
            plan = {
                'tasks': [
                    {
                        'task_id': 'find_current_branch',
                        'agent': 'CodeMaster',
                        'description': 'Get current git branch name',
                        'depends_on': [],
                        'inputs_needed': [],
                        'outputs_produced': ['current_branch']
                    },
                    {
                        'task_id': 'find_lost_commits',
                        'agent': 'CodeMaster',
                        'description': 'Search git reflog for missing commits',
                        'depends_on': ['find_current_branch'],
                        'inputs_needed': ['current_branch'],
                        'outputs_produced': ['lost_commit_shas']
                    }
                ]
            }
            todo.initialize_from_plan(plan)
        """
        # Clear existing state
        self.subtasks.clear()
        self.execution_order.clear()
        self.completed_tasks.clear()
        self.failed_tasks.clear()
        self.current_task_id = None
        
        tasks = plan.get('tasks', [])
        
        if not tasks:
            logger.warning("initialize_from_plan: Empty task list received")
            return
        
        # Calculate priority based on dependency depth
        # Tasks with fewer dependencies get higher priority (run first)
        task_depths = self._calculate_dependency_depths(tasks)
        max_depth = max(task_depths.values()) if task_depths else 0
        
        for task_spec in tasks:
            task_id = task_spec.get('task_id', 'unknown')
            depth = task_depths.get(task_id, 0)
            
            # Priority decreases with depth (0 depth = 1.0, max depth = 0.1)
            if max_depth > 0:
                priority = 1.0 - (depth / (max_depth + 1)) * 0.9
            else:
                priority = 1.0
            
            self.add_task(
                task_id=task_id,
                description=task_spec.get('description', f'Execute {task_id}'),
                actor=task_spec.get('agent', ''),
                depends_on=task_spec.get('depends_on', []),
                estimated_duration=60.0,  # Default, can be overridden
                priority=priority
            )
            
            # Store additional metadata in intermediary_values
            if task_id in self.subtasks:
                self.subtasks[task_id].intermediary_values.update({
                    'inputs_needed': task_spec.get('inputs_needed', []),
                    'outputs_produced': task_spec.get('outputs_produced', []),
                    'decomposition_source': plan.get('decomposition_method', 'llm')
                })
        
        # Reorder execution_order based on topological sort
        self.execution_order = self._topological_sort()
        
        self._update_blocks()
        self._estimate_remaining()
        
        logger.info(f"✅ Initialized TODO from plan: {len(self.subtasks)} tasks")
    
    def _calculate_dependency_depths(self, tasks: List[Dict]) -> Dict[str, int]:
        """
        Calculate dependency depth for each task (for priority calculation).
        
        Depth 0 = no dependencies (runs first)
        Depth N = depends on tasks of depth N-1
        """
        task_deps = {t.get('task_id', ''): t.get('depends_on', []) for t in tasks}
        depths = {}
        
        def get_depth(task_id: str, visited: set = None) -> int:
            if visited is None:
                visited = set()
            
            if task_id in depths:
                return depths[task_id]
            
            if task_id in visited:
                # Circular dependency - return 0 to avoid infinite loop
                return 0
            
            visited.add(task_id)
            deps = task_deps.get(task_id, [])
            
            if not deps:
                depths[task_id] = 0
                return 0
            
            max_dep_depth = max(get_depth(dep, visited.copy()) for dep in deps if dep in task_deps)
            depths[task_id] = max_dep_depth + 1
            return depths[task_id]
        
        for task_id in task_deps:
            get_depth(task_id)
        
        return depths
    
    def _topological_sort(self) -> List[str]:
        """
        Sort tasks in topological order (respecting dependencies).
        
        Uses Kahn's algorithm for deterministic ordering.
        """
        # Build in-degree map
        in_degree = {task_id: 0 for task_id in self.subtasks}
        
        for task_id, task in self.subtasks.items():
            for dep in task.depends_on:
                if dep in self.subtasks:
                    in_degree[task_id] = in_degree.get(task_id, 0) + 1
        
        # Start with tasks that have no dependencies
        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        queue.sort()  # Deterministic ordering
        
        result = []
        
        while queue:
            current = queue.pop(0)
            result.append(current)
            
            # Reduce in-degree of dependents
            for task_id, task in self.subtasks.items():
                if current in task.depends_on:
                    in_degree[task_id] -= 1
                    if in_degree[task_id] == 0:
                        queue.append(task_id)
                        queue.sort()  # Maintain deterministic order
        
        # If not all tasks in result, there's a cycle - append remaining
        remaining = [tid for tid in self.subtasks if tid not in result]
        result.extend(sorted(remaining))
        
        return result
    
    # =========================================================================
    # NEW METHODS - Complete SwarmReVal Integration (NO HARDCODING)
    # =========================================================================
    
    def get_state_summary(self) -> str:
        """
        Get comprehensive state summary for context/display.
        
        NO HARDCODING: Dynamically generates summary from current state.
        Used by SwarmReVal for context building and display.
        
        🔴 A-TEAM FIX: Now includes COMPLETED and ARCHIVED tasks so agents
        retain full context of what was already done, preventing redundant
        re-planning or loss of information.
        """
        pending = [t for t in self.subtasks.values() if t.status == TaskStatus.PENDING]
        in_progress = [t for t in self.subtasks.values() if t.status == TaskStatus.IN_PROGRESS]
        completed = [t for t in self.subtasks.values() if t.status == TaskStatus.COMPLETED]
        skipped = [t for t in self.subtasks.values() if t.status == TaskStatus.SKIPPED]
        
        summary = f"### TODO State\n"
        summary += f"**Root Task:** {self.root_task}\n"
        summary += f"**Progress:** {len(self.completed_tasks)}/{len(self.subtasks)} completed\n\n"
        
        # ── Completed tasks (CRITICAL for context) ──
        if completed:
            summary += "#### ✅ Completed\n"
            # Use _completion_order for chronological display
            ordered_completed = []
            for tid in self._completion_order:
                if tid in self.subtasks and self.subtasks[tid].status == TaskStatus.COMPLETED:
                    ordered_completed.append(self.subtasks[tid])
            # Add any completed tasks not in _completion_order (edge case)
            ordered_ids = {t.task_id for t in ordered_completed}
            for t in completed:
                if t.task_id not in ordered_ids:
                    ordered_completed.append(t)
            
            for task in ordered_completed:
                summary += f"- ✅ {task.description} (Actor: {task.actor})\n"
            summary += "\n"
        
        if in_progress:
            summary += "#### 🔄 In Progress\n"
            for task in in_progress:
                q_val = task.estimated_reward
                priority = task.priority
                summary += f"- {task.description} (Actor: {task.actor}, Q={q_val:.2f}, P={priority:.1f}, Attempt #{task.attempts+1})\n"
            summary += "\n"
        
        if pending:
            summary += "#### ⏳ Next Up\n"
            # Sort by priority * Q-value (NO HARDCODED THRESHOLD)
            sorted_pending = sorted(pending, key=lambda t: t.priority * t.estimated_reward, reverse=True)
            for task in sorted_pending:
                score = task.priority * task.estimated_reward
                summary += f"- {task.description} (Actor: {task.actor}, Score={score:.2f})\n"
            summary += "\n"
        
        if self.failed_tasks:
            summary += "#### ❌ Failed (Need Retry/Exploration)\n"
            for task_id in list(self.failed_tasks):
                if task_id in self.subtasks:
                    task = self.subtasks[task_id]
                    reason = task.failure_reasons[-1] if task.failure_reasons else "Unknown"
                    summary += f"- {task.description} - {reason}\n"
            summary += "\n"
        
        if skipped:
            summary += "#### ⏭️ Skipped/Replaced\n"
            for task in skipped:
                replaced_by = getattr(task, 'replaced_by', [])
                if replaced_by:
                    summary += f"- {task.description} → replaced by {replaced_by}\n"
                else:
                    summary += f"- {task.description} (skipped)\n"
            summary += "\n"
        
        # ── Archived / deleted tasks (retain context) ──
        if self._deleted_tasks_archive:
            summary += "#### 🗑️ Archived (Previously Planned/Done)\n"
            for archived in self._deleted_tasks_archive[-10:]:  # Last 10
                status_icon = "✅" if archived.get('was_completed') else "🗑️"
                summary += f"- {status_icon} {archived['description']} (Actor: {archived['actor']}, was: {archived['status']})\n"
            if len(self._deleted_tasks_archive) > 10:
                summary += f"  ... and {len(self._deleted_tasks_archive) - 10} more archived tasks\n"
            summary += "\n"
        
        # Add progress statistics (NO HARDCODED THRESHOLDS)
        summary += f"**Completion Probability:** {self.completion_probability:.1%}\n"
        summary += f"**Estimated Remaining:** {self.estimated_remaining_steps} tasks\n"
        
        return summary
    
    def update_q_value(self, task_id: str, q_value: float, confidence: float):
        """
        Update Q-value for a task.
        
        NO HARDCODING: Values are learned/predicted, not hardcoded.
        """
        if task_id in self.subtasks:
            self.subtasks[task_id].estimated_reward = max(0.0, min(1.0, q_value))
            self.subtasks[task_id].confidence = max(0.0, min(1.0, confidence))
    
    def record_intermediary_values(self, task_id: str, values: Dict[str, Any]):
        """
        Record intermediary runtime values (LLM calls, time, etc).
        
        NO HARDCODING: Stores any runtime metrics dynamically.
        Perfect for tracking performance without hardcoded fields.
        """
        if task_id in self.subtasks:
            self.subtasks[task_id].intermediary_values.update(values)
    
    def predict_next(self, task_id: str, next_task_id: Optional[str], 
                    duration: Optional[float] = None, reward: Optional[float] = None):
        """
        Record predictions for trajectory planning.
        
        NO HARDCODING: Predictions come from LLM or learned models.
        """
        if task_id in self.subtasks:
            self.subtasks[task_id].predicted_next_task = next_task_id
            if duration is not None:
                self.subtasks[task_id].predicted_duration = duration
            if reward is not None:
                self.subtasks[task_id].predicted_reward = reward
    
    def get_task_by_id(self, task_id: str) -> Optional[SubtaskState]:
        """Get task object by ID."""
        return self.subtasks.get(task_id)
    
    def get_all_tasks_list(self) -> List[Dict[str, Any]]:
        """
        Get complete list of all tasks with their details.
        
        Returns structured list suitable for frontend display/debugging.
        🔴 A-TEAM FIX: Also includes archived (deleted) tasks so the frontend
        can show full task history.
        """
        tasks_list = []
        for task_id, task in self.subtasks.items():
            tasks_list.append({
                'task_id': task_id,
                'description': task.description,
                'actor': task.actor,
                'status': task.status.value,
                'priority': task.priority,
                'estimated_reward': task.estimated_reward,
                'confidence': task.confidence,
                'progress': task.progress,
                'depends_on': task.depends_on,
                'depends_on_status': {
                    dep_id: self.subtasks[dep_id].status.value
                    for dep_id in (task.depends_on or [])
                    if dep_id in self.subtasks
                },
                'blocks': task.blocks,
                'attempts': task.attempts,
                'max_attempts': task.max_attempts,
                'failure_reasons': task.failure_reasons,
                'started_at': task.started_at.isoformat() if task.started_at else None,
                'completed_at': task.completed_at.isoformat() if task.completed_at else None,
                'estimated_duration': task.estimated_duration if hasattr(task, 'estimated_duration') else None,
            })
        
        # Include archived tasks with 'archived' status
        for archived in self._deleted_tasks_archive:
            tasks_list.append({
                'task_id': archived['task_id'],
                'description': archived['description'],
                'actor': archived['actor'],
                'status': 'archived',
                'priority': 0.0,
                'estimated_reward': 0.0,
                'confidence': 0.0,
                'progress': 1.0 if archived.get('was_completed') else 0.0,
                'depends_on': [],
                'blocks': [],
                'attempts': archived.get('attempts', 0),
                'max_attempts': 0,
                'failure_reasons': archived.get('failure_reasons', []),
                'started_at': None,
                'completed_at': archived.get('deleted_at'),
                'estimated_duration': None,
            })
        
        return tasks_list
    
    # =========================================================================
    # Compatibility Properties (for backward compatibility with old code)
    # =========================================================================
    
    @property
    def items(self) -> Dict[str, SubtaskState]:
        """Alias for .subtasks (backward compatibility)."""
        return self.subtasks
    
    @property
    def completed(self) -> Set[str]:
        """Alias for .completed_tasks (backward compatibility)."""
        return self.completed_tasks


# =============================================================================
# THOUGHT-LEVEL CREDIT ASSIGNMENT
# =============================================================================

class ThoughtLevelCredit:
    """
    Assign credit to individual reasoning steps.
    
    A-Team Enhancement: Goes beyond agent-level credit to
    attribute success/failure to specific thoughts and tool calls.
    
    Dr. Chen: "CoT steps should get individual credit"
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.temporal_weight = self.config.get('temporal_weight', 0.3)
        self.tool_weight = self.config.get('tool_weight', 0.4)
        self.decision_weight = self.config.get('decision_weight', 0.3)
        # STRICT POLICY: no fuzzy/keyword matching. If an LM is provided, use it.
        self.lm = self.config.get('lm')
    
    def assign_credit(self,
                      reasoning_trace: List[str],
                      tool_calls: List[Dict],
                      outcome: float,
                      trajectory: List[TrajectoryStep] = None) -> Dict[int, float]:
        """
        Assign credit to each step in reasoning trace.
        
        Returns: Dict mapping step index to credit value
        """
        if not reasoning_trace:
            return {}
        
        credits = {}
        n_steps = len(reasoning_trace)
        
        # 1. Temporal credit (later steps get more credit)
        for i, thought in enumerate(reasoning_trace):
            temporal_factor = (i + 1) / n_steps
            credits[i] = outcome * temporal_factor * self.temporal_weight
        
        # 2. Tool-linked credit
        tool_step_outcomes = self._compute_tool_credits(reasoning_trace, tool_calls)
        for step_idx, tool_credit in tool_step_outcomes.items():
            credits[step_idx] = credits.get(step_idx, 0) + tool_credit * self.tool_weight
        
        # 3. Decision point credit
        decision_steps = self._identify_decision_steps(reasoning_trace)
        for step_idx in decision_steps:
            credits[step_idx] = credits.get(step_idx, 0) + outcome * self.decision_weight / max(len(decision_steps), 1)
        
        # Normalize to sum to outcome
        total = sum(credits.values())
        if total > 0:
            credits = {k: v / total * abs(outcome) for k, v in credits.items()}
        
        return credits
    
    def _compute_tool_credits(self, 
                              reasoning_trace: List[str],
                              tool_calls: List[Dict]) -> Dict[int, float]:
        """Compute credit for tool-linked reasoning steps."""
        tool_credits = {}
        
        for tool_call in tool_calls:
            tool_name = tool_call.get('tool', '')
            tool_success = 1.0 if tool_call.get('success', False) else -0.5
            
            # Find which reasoning step led to this tool call
            linked_idx = self._find_linked_thought(reasoning_trace, tool_name)
            if linked_idx is not None:
                tool_credits[linked_idx] = tool_credits.get(linked_idx, 0) + tool_success
        
        return tool_credits
    
    def _find_linked_thought(self, reasoning_trace: List[str], tool_name: str) -> Optional[int]:
        """
        Find which reasoning step led to a tool call.
        
        STRICT POLICY: no regex/fuzzy/keyword heuristics. If no LM is available,
        return None (no linkage).
        """
        if not reasoning_trace or not tool_name:
            return None

        if not self.lm:
            return None

        try:
            import dspy

            class ToolLinkSignature(dspy.Signature):
                reasoning_steps = dspy.InputField(desc="JSON list of reasoning steps in order")
                tool_name = dspy.InputField(desc="Exact tool name that was called")
                output = dspy.OutputField(
                    desc=(
                        "JSON object: {\"linked_index\": int | null, \"reason\": str}. "
                        "linked_index must be an integer index into reasoning_steps, or null if not linkable."
                    )
                )

            linker = dspy.ChainOfThought(ToolLinkSignature)
            with dspy.context(lm=self.lm):
                res = linker(
                    reasoning_steps=json.dumps(reasoning_trace),
                    tool_name=tool_name,
                )

            parsed = json.loads(res.output)
            idx = parsed.get("linked_index")
            if isinstance(idx, int) and 0 <= idx < len(reasoning_trace):
                return idx
            return None
        except Exception:
            return None
    
    def _identify_decision_steps(self, reasoning_trace: List[str]) -> List[int]:
        """
        Identify steps that are decision points using LLM semantic analysis.
        
        🔴 A-TEAM FIX: Uses LLM to classify which reasoning steps are decisions
        vs analysis. Falls back to structural heuristic if LLM unavailable.
        """
        if not reasoning_trace:
            return []
        
        # Try LLM-based identification
        if DSPY_AVAILABLE and self.lm:
            try:
                identifier = dspy.Predict(
                    "reasoning_steps -> decision_indices: str"
                )
                with dspy.context(lm=self.lm):
                    result = identifier(
                        reasoning_steps=json.dumps([
                            f"[{i}] {smart_truncate(step, max_tokens=50)}" for i, step in enumerate(reasoning_trace)
                        ])
                    )
                # Parse indices from LLM output
                import re
                indices = [int(x) for x in re.findall(r'\d+', result.decision_indices)]
                valid = [i for i in indices if 0 <= i < len(reasoning_trace)]
                if valid:
                    return valid
            except Exception:
                pass  # Fall through to heuristic
        
        # Fallback: structural heuristic
        decision_steps = []
        for i, thought in enumerate(reasoning_trace):
            # Final third of reasoning (likely conclusions)
            if len(reasoning_trace) > 2 and i >= len(reasoning_trace) * 0.7:
                decision_steps.append(i)
            # Step immediately after a long analysis step
            elif i > 0 and len(reasoning_trace[i - 1]) > len(thought) * 2:
                decision_steps.append(i)
        
        # Always include last step as a decision
        if reasoning_trace and (len(reasoning_trace) - 1) not in decision_steps:
            decision_steps.append(len(reasoning_trace) - 1)
        
        return decision_steps
    
    def get_step_value_summary(self, credits: Dict[int, float], reasoning_trace: List[str]) -> str:
        """Generate summary of credit assignment."""
        if not credits:
            return "No credits assigned"
        
        lines = ["Step Credit Assignment:"]
        for idx, credit in sorted(credits.items()):
            thought_preview = reasoning_trace[idx] if idx < len(reasoning_trace) else "?"
            lines.append(f"  Step {idx}: {credit:.3f} - '{thought_preview}...'")
        
        return "\n".join(lines)


# =============================================================================
# STATE CHECKPOINTER
# =============================================================================

class StateCheckpointer:
    """
    Full state checkpointing with resume support.
    
    A-Team Enhancement: Save complete state at decision points,
    enable resume from any checkpoint.
    """
    
    def __init__(self, checkpoint_dir: str = "agent_generated/checkpoints"):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    def save_checkpoint(self,
                        state: AgenticState,
                        q_function: DecomposedQFunction,
                        todo: MarkovianTODO,
                        episode_id: str) -> str:
        """Save complete checkpoint."""
        checkpoint_id = f"{episode_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.json"
        
        checkpoint = {
            'checkpoint_id': checkpoint_id,
            'episode_id': episode_id,
            'timestamp': datetime.now().isoformat(),
            'state': state.to_dict(),
            'q_function': q_function.to_dict(),
            'todo': todo.to_dict()
        }
        
        with open(checkpoint_path, 'w') as f:
            json.dump(checkpoint, f, indent=2, default=str)
        
        return checkpoint_id
    
    def load_checkpoint(self, checkpoint_id: str) -> Tuple[AgenticState, DecomposedQFunction, MarkovianTODO]:
        """Load checkpoint and restore state."""
        checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.json"
        
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_id}")
        
        with open(checkpoint_path, 'r') as f:
            checkpoint = json.load(f)
        
        state = AgenticState.from_dict(checkpoint['state'])
        q_function = DecomposedQFunction.from_dict(checkpoint['q_function'])
        
        todo = MarkovianTODO(
            root_task=checkpoint['todo'].get('root_task', ''),
            todo_id=checkpoint['todo'].get('todo_id', '')
        )
        # Restore todo state...
        
        return state, q_function, todo
    
    def list_checkpoints(self, episode_id: str = None) -> List[Dict]:
        """List available checkpoints."""
        checkpoints = []
        for cp_file in self.checkpoint_dir.glob("*.json"):
            try:
                with open(cp_file, 'r') as f:
                    data = json.load(f)
                if episode_id is None or data.get('episode_id') == episode_id:
                    checkpoints.append({
                        'checkpoint_id': data['checkpoint_id'],
                        'episode_id': data['episode_id'],
                        'timestamp': data['timestamp']
                    })
            except (KeyError, TypeError, json.JSONDecodeError) as e:
                logger.debug(f"Skipping checkpoint file {f}: {e}")
        
        return sorted(checkpoints, key=lambda x: x['timestamp'], reverse=True)
    
    def get_latest_checkpoint(self, episode_id: str = None) -> Optional[str]:
        """Get ID of most recent checkpoint."""
        checkpoints = self.list_checkpoints(episode_id)
        return checkpoints[0]['checkpoint_id'] if checkpoints else None


# =============================================================================
# TRAJECTORY PREDICTOR
# =============================================================================

class TrajectoryPredictorSignature(dspy.Signature):
    """Predict next action and outcome given current state."""
    
    state_summary: str = dspy.InputField(desc="Current state summary")
    trajectory_history: str = dspy.InputField(desc="Recent trajectory steps")
    available_actions: str = dspy.InputField(desc="Possible actions")
    
    reasoning: str = dspy.OutputField(desc="Analysis of likely next steps")
    predicted_action: str = dspy.OutputField(desc="Most likely next action")
    confidence: float = dspy.OutputField(desc="Confidence 0.0-1.0")
    predicted_outcome: str = dspy.OutputField(desc="Expected outcome")
    uncertainty_factors: str = dspy.OutputField(desc="What could go wrong")


class TrajectoryPredictor:
    """
    DQN-style trajectory prediction.
    
    A-Team Enhancement: Predict next states and outcomes
    to enable look-ahead planning.
    """
    
    def __init__(self):
        self.predictor = dspy.ChainOfThought(TrajectoryPredictorSignature)
        self.prediction_history: List[Dict] = []
    
    def predict(self, 
                state: AgenticState,
                available_actions: List[str]) -> Dict:
        """Predict next action and outcome."""
        try:
            result = self.predictor(
                state_summary=state.to_llm_summary(),
                trajectory_history=self._format_trajectory(state.trajectory),
                available_actions=", ".join(available_actions)
            )
            
            prediction = {
                'predicted_action': result.predicted_action,
                'confidence': float(result.confidence),
                'predicted_outcome': result.predicted_outcome,
                'uncertainty_factors': result.uncertainty_factors,
                'reasoning': result.reasoning
            }
            
            self.prediction_history.append({
                'timestamp': datetime.now().isoformat(),
                'state_key': state.to_key(),
                'prediction': prediction
            })
            
            return prediction
            
        except Exception as e:
            return {
                'predicted_action': available_actions[0] if available_actions else 'unknown',
                'confidence': 0.3,
                'predicted_outcome': 'uncertain',
                'uncertainty_factors': str(e),
                'reasoning': 'Prediction failed'
            }
    
    def _format_trajectory(self, trajectory: List[TrajectoryStep]) -> str:
        """Format trajectory for LLM."""
        if not trajectory:
            return "No trajectory yet"
        
        lines = []
        for step in trajectory:
            lines.append(f"Step {step.step_idx}: {step.action_type} - {step.action_content}")
            if step.reward != 0:
                lines.append(f"  Reward: {step.reward:.2f}")
        
        return "\n".join(lines)
    
    def evaluate_prediction_accuracy(self, 
                                     prediction: Dict,
                                     actual_action: str,
                                     actual_outcome: str) -> float:
        """Evaluate how accurate a prediction was.
        
        🔴 A-TEAM FIX: Uses LLM-based semantic evaluation when available,
        falls back to improved heuristic for cost-efficiency.
        """
        # Try LLM-based evaluation (semantic matching)
        if DSPY_AVAILABLE:
            try:
                evaluator = dspy.Predict("predicted_action, actual_action, predicted_outcome, actual_outcome -> accuracy_score: float")
                result = evaluator(
                    predicted_action=prediction.get('predicted_action', ''),
                    actual_action=actual_action,
                    predicted_outcome=prediction.get('predicted_outcome', ''),
                    actual_outcome=actual_outcome
                )
                score = float(result.accuracy_score)
                return max(0.0, min(1.0, score))
            except Exception:
                pass  # Fall through to heuristic
        
        # Fallback: improved heuristic
        action_match = 1.0 if prediction.get('predicted_action', '') == actual_action else 0.0
        
        pred_outcome = prediction.get('predicted_outcome', '').lower()
        actual_lower = actual_outcome.lower()
        
        # Check for semantic polarity match (success/fail)
        pred_positive = any(w in pred_outcome for w in ['success', 'pass', 'complete', 'done'])
        pred_negative = any(w in pred_outcome for w in ['fail', 'error', 'crash', 'timeout'])
        actual_positive = any(w in actual_lower for w in ['success', 'pass', 'complete', 'done'])
        actual_negative = any(w in actual_lower for w in ['fail', 'error', 'crash', 'timeout'])
        
        if pred_positive == actual_positive and pred_negative == actual_negative:
            outcome_match = 1.0
        elif pred_positive != actual_positive and pred_negative != actual_negative:
            outcome_match = 0.0
        else:
            outcome_match = 0.3  # Partial match
        
        return (action_match + outcome_match) / 2


# =============================================================================
# 🎯 A-TEAM: LLM-BASED TODO ADAPTATION AGENT (NO HARDCODING)
# =============================================================================

if DSPY_AVAILABLE:
    class TODOAdaptationSignature(dspy.Signature):
        """
        Decide how to adapt TODO based on current state and learnings.
        
        NO HARDCODING! LLM analyzes:
        - Q-values (which tasks have low success probability)
        - MARL predictions (what agents need)
        - Brain memory patterns (what worked before)
        - Current failures (what's blocking progress)
        
        Then decides:
        - Reorder (change sequence based on dependencies)
        - Reprioritize (boost urgent tasks)
        - Insert (add validation/research steps)
        - Delete (remove obsolete tasks)
        - Update (modify task descriptions with more detail)
        """
        
        current_todo_state: str = dspy.InputField(
            desc="Current TODO state: tasks, statuses, dependencies"
        )
        
        recent_failures: str = dspy.InputField(
            desc="Recent task failures with error messages"
        )
        
        q_learning_insights: str = dspy.InputField(
            desc="Q-learning insights: low-value tasks, high-value alternatives"
        )
        
        marl_predictions: str = dspy.InputField(
            desc="MARL predictions: collaboration needs, bottlenecks"
        )
        
        brain_memory_patterns: str = dspy.InputField(
            desc="Brain memory patterns: what worked in similar situations"
        )
        
        # 🔴 A-TEAM FIX: Agent directory for informed task assignment
        agent_directory: str = dspy.InputField(
            desc="Available agents with capabilities. Use this to assign correct actors to new/updated tasks."
        )
        
        adaptation_decision: str = dspy.OutputField(
            desc="""JSON object with adaptation actions:
            {
                "actions": [
                    {
                        "type": "reorder" | "reprioritize" | "insert" | "delete" | "update",
                        "task_id": "task_id",
                        "params": {...}
                    }
                ],
                "reasoning": "why these adaptations improve success probability"
            }
            """
        )


class AgenticTODOAdapter:
    """
    LLM-based TODO adaptation - NO hardcoding!
    
    Analyzes current state and learning to dynamically adapt the task graph.
    
    🎯 A-TEAM FIX: Corrected API mismatches (reprioritize takes Dict not two args),
    fixed void return value checks (MarkovianTODO methods return None, not bool),
    replaced hardcoded [:60] truncation with smart_truncate.
    """
    
    def __init__(self, lm=None):
        self.lm = lm
        if DSPY_AVAILABLE:
            self.adapter = dspy.ChainOfThought(TODOAdaptationSignature)
        else:
            self.adapter = None
        logger.info("🎯 AgenticTODOAdapter initialized (LLM-based, no hardcoding)")
    
    async def adapt_todo(
        self,
        todo: 'MarkovianTODO',
        recent_failures: List[Dict],
        q_learning_insights: Dict,
        marl_predictions: Dict,
        brain_memory_patterns: List[Dict],
        agent_directory: str = "[]"  # 🔴 A-TEAM FIX: Agent directory for task assignment
    ) -> List[Dict]:
        """
        Adapt TODO based on learning and current state.
        
        Returns list of actions taken.
        """
        if not self.adapter:
            logger.warning("AgenticTODOAdapter: DSPy not available")
            return []
        
        # 🔴 A-TEAM FIX: Use smart_truncate instead of hardcoded [:60]
        try:
            from Synapse.core.token_utils import smart_truncate
        except ImportError:
            def smart_truncate(text, max_tokens=30, **kwargs):
                return text[:120] if len(text) > 120 else text
        
        # Prepare context
        todo_state = {
            'tasks': [
                {
                    'id': t.task_id,
                    'description': smart_truncate(t.description, max_tokens=30),
                    'status': t.status.value,
                    'priority': t.priority,
                    'depends_on': t.depends_on,
                    'actor': t.actor,
                    'attempts': t.attempts,
                    'estimated_reward': t.estimated_reward
                }
                for t in todo.subtasks.values()
            ],
            'completed': len(todo.completed_tasks),
            'failed': len(todo.failed_tasks),
            'execution_order': todo.execution_order,
            'completion_probability': todo.completion_probability
        }
        
        # Call LLM adapter
        try:
            with dspy.context(lm=self.lm):
                result = self.adapter(
                    current_todo_state=json.dumps(todo_state, indent=2),
                    recent_failures=json.dumps(recent_failures, indent=2),
                    q_learning_insights=json.dumps(q_learning_insights, indent=2),
                    marl_predictions=json.dumps(marl_predictions, indent=2),
                    brain_memory_patterns=json.dumps(brain_memory_patterns, indent=2),
                    agent_directory=agent_directory  # 🔴 A-TEAM FIX
                )
            
            # Parse and execute adaptations
            adaptations = json.loads(result.adaptation_decision)
            actions_taken = []
            
            for action in adaptations.get('actions', []):
                try:
                    action_type = action.get('type', '')
                    task_id = action.get('task_id', '')
                    params = action.get('params', {})
                    
                    if action_type == 'reorder':
                        new_order = params.get('new_order', [])
                        # 🔴 A-TEAM FIX: reorder_tasks returns None (void).
                        # Call it, then always record the action.
                        todo.reorder_tasks(new_order)
                        actions_taken.append(action)
                        logger.info(f"  ✅ Reordered tasks: {new_order[:3]}...")
                    
                    elif action_type == 'reprioritize':
                        # 🔴 A-TEAM FIX: reprioritize() takes Dict[str, float],
                        # NOT (task_id, priority) two-arg form. Build the dict.
                        new_priority = params.get('priority', 1.0)
                        priority_map = {task_id: new_priority}
                        todo.reprioritize(priority_map)
                        actions_taken.append(action)
                        logger.info(f"  ✅ Reprioritized {task_id} → {new_priority}")
                    
                    elif action_type == 'insert':
                        # Create new task from params
                        new_task_id = params.get('new_task_id', f'inserted_{task_id}')
                        new_task = SubtaskState(
                            task_id=new_task_id,
                            description=params.get('description', 'Inserted task'),
                            actor=params.get('actor', ''),
                            depends_on=params.get('depends_on', []),
                            priority=params.get('priority', 1.0)
                        )
                        # 🔴 A-TEAM FIX: insert_task_after returns None (void).
                        todo.insert_task_after(task_id, new_task)
                        actions_taken.append(action)
                        logger.info(f"  ✅ Inserted {new_task_id} after {task_id}")
                    
                    elif action_type == 'delete':
                        # 🔴 A-TEAM FIX: delete_task returns None (void).
                        todo.delete_task(task_id)
                        actions_taken.append(action)
                        logger.info(f"  ✅ Deleted task {task_id}")
                    
                    elif action_type == 'update':
                        # 🔴 A-TEAM FIX: update_task returns None (void).
                        todo.update_task(task_id, **params)
                        actions_taken.append(action)
                        logger.info(f"  ✅ Updated task {task_id}: {list(params.keys())}")
                    
                    else:
                        logger.warning(f"  ⚠️  Unknown action type: {action_type}")
                
                except Exception as action_error:
                    logger.error(f"  ❌ Failed to apply action {action}: {action_error}")
                    # Continue to next action, don't abort all adaptations
            
            logger.info(f"🎯 AgenticTODOAdapter: {len(actions_taken)}/{len(adaptations.get('actions', []))} adaptations applied")
            logger.info(f"   Reasoning: {adaptations.get('reasoning', 'N/A')}")
            
            return actions_taken
            
        except Exception as e:
            logger.error(f"AgenticTODOAdapter: Failed to parse adaptations: {e}")
            return []


# =============================================================================
# EXPORT
# =============================================================================

__all__ = [
    'AgenticState',
    'TrajectoryStep',
    'DecomposedQFunction',
    'MarkovianTODO',
    'SubtaskState',
    'TaskStatus',
    'ThoughtLevelCredit',
    'StateCheckpointer',
    'TrajectoryPredictor',
    'AgenticTODOAdapter',  # NEW: LLM-based TODO adaptation
    'TODOAdaptationSignature'  # NEW: Signature for adaptation
]


