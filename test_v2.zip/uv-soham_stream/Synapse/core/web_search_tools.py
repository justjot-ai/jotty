"""
Open-source web search tools for Synapse using DuckDuckGo (no API keys required).

Design goals:
- No hardcoded mappings (generic tool discovery via @synapse_method)
- Simple function-based implementation with all logic inline
- Config-driven behavior and caching
- Uses DuckDuckGo search (free, no API key needed)

Dependencies:
- duckduckgo-search: pip install duckduckgo-search (required)
- requests: pip install requests (required for URL scraping)
- beautifulsoup4: pip install beautifulsoup4 (required for HTML parsing)
"""

from __future__ import annotations

import logging
import threading
import time
import requests
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from .data_structures import SynapseConfig
from .metadata_protocol import synapse_method

logger = logging.getLogger(__name__)

# Disable SSL verification for DuckDuckGo library (uses httpx/httpcore internally)
import os
import ssl
import warnings

# Set environment variable to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Patch SSL context creation before any imports
def _create_unverified_context(purpose=ssl.Purpose.SERVER_AUTH, *, cafile=None, capath=None, cadata=None):
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context

ssl._create_default_https_context = _create_unverified_context
ssl.create_default_context = _create_unverified_context

# Patch httpcore (used by httpx) before httpx is imported
try:
    import httpcore
    
    # Patch the connection pool and transport classes
    if hasattr(httpcore, 'SyncHTTPTransport'):
        _orig_sync_transport = httpcore.SyncHTTPTransport.__init__
        def _new_sync_transport(self, *args, **kwargs):
            kwargs.setdefault('verify', False)
            return _orig_sync_transport(self, *args, **kwargs)
        httpcore.SyncHTTPTransport.__init__ = _new_sync_transport
    
    if hasattr(httpcore, 'AsyncHTTPTransport'):
        _orig_async_transport = httpcore.AsyncHTTPTransport.__init__
        def _new_async_transport(self, *args, **kwargs):
            kwargs.setdefault('verify', False)
            return _orig_async_transport(self, *args, **kwargs)
        httpcore.AsyncHTTPTransport.__init__ = _new_async_transport
    
    # Also patch the connection classes directly
    if hasattr(httpcore, 'Connection'):
        _orig_connection = httpcore.Connection.__init__
        def _new_connection(self, *args, **kwargs):
            kwargs.setdefault('verify', False)
            return _orig_connection(self, *args, **kwargs)
        httpcore.Connection.__init__ = _new_connection
except (ImportError, AttributeError):
    pass

# Patch httpx to disable SSL verification (used by duckduckgo_search)
try:
    import httpx
    _orig_client_init = httpx.Client.__init__
    _orig_async_init = httpx.AsyncClient.__init__
    
    def _new_client_init(self, *args, **kwargs):
        kwargs.setdefault('verify', False)
        return _orig_client_init(self, *args, **kwargs)
    
    def _new_async_init(self, *args, **kwargs):
        kwargs.setdefault('verify', False)
        return _orig_async_init(self, *args, **kwargs)
    
    httpx.Client.__init__ = _new_client_init
    httpx.AsyncClient.__init__ = _new_async_init
except ImportError:
    pass

# Suppress SSL warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
warnings.filterwarnings('ignore', category=DeprecationWarning)
try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

# Require duckduckgo_search library (must be imported after SSL patches)
try:
    from duckduckgo_search import DDGS
except ImportError:
    raise ImportError(
        "duckduckgo_search library is required. Install with: pip install duckduckgo-search"
    )


@dataclass
class _CacheEntry:
    value: str
    created_at: float
    ttl_seconds: float

    def is_expired(self) -> bool:
        return (time.time() - self.created_at) > self.ttl_seconds


# Module-level cache and state
_cache: Dict[Tuple[str, str], _CacheEntry] = {}
_cache_lock = threading.Lock()
_stats = {
    "search_calls": 0,
    "crawl_calls": 0,
    "search_failures": 0,
    "crawl_failures": 0
}


def _scrape_url(url: str) -> str:
    """Scrape a URL and return text content."""
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        raise ImportError(
            "beautifulsoup4 is required for URL scraping. Install with: pip install beautifulsoup4"
        )
    
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        # Disable SSL verification for requests
        response = requests.get(url, headers=headers, timeout=10, verify=False)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, "html.parser")
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        text = soup.get_text(separator="\n", strip=True)
        return text[:50000]  # Limit to 50k chars
    except Exception as e:
        logger.warning(f"[🔍 SCRAPE] Failed to scrape {url}: {e}")
        raise


class OpenSourceWebSearchProvider:
    """
    Open-source web search provider for Synapse.
    
    Static class wrapper for @synapse_method discovery.
    Config is stored as class variable, no instance state needed.
    All tool logic is self-contained in each method.
    """
    
    _config: Optional[SynapseConfig] = None

    def __init__(self, config: SynapseConfig):
        """Store config as class variable for static access."""
        OpenSourceWebSearchProvider._config = config

    def __synapse_validate__(self) -> bool:
        """Validate that web search tool dependencies are available."""
        try:
            # Check if duckduckgo_search is available
            from duckduckgo_search import DDGS
            # Check if requests is available
            import requests
            # Check if beautifulsoup4 is available
            from bs4 import BeautifulSoup
            return True
        except ImportError as e:
            logger.warning(f"⚠️ Web search dependencies missing: {e}")
            logger.warning("Install with: pip install duckduckgo-search requests beautifulsoup4")
            return False

    def get_context_for_actor(
        self,
        actor_name: str,
        query: str,
        previous_outputs: Optional[Dict[str, Any]] = None,
        actor_config: Optional[Any] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Optional context provider hook for actors."""
        config = OpenSourceWebSearchProvider._config
        if not config:
            return {}
            
        if not getattr(config, "enable_web_search_context", False):
            return {}

        if not query or not isinstance(query, str):
            return {}

        max_results = getattr(config, "web_search_context_max_results", 3)
        max_chars = getattr(config, "web_search_context_max_chars", 4000)

        result = self.web_search(search_query=query, max_results=max_results, max_chars=max_chars)
        if not result or "error" in result.lower():
            return {}

        return {"web_search_context": result}

    @synapse_method(
        desc="Search the web for external information. CRITICAL: search_query parameter is REQUIRED - you MUST provide it when calling this tool. Do NOT call without search_query - it will fail.",
        when="Use when you need external facts, documentation, libraries, or verification. You MUST call with search_query parameter.",
        cache=True,
        timeout=60.0,
        for_architect=True,
        for_auditor=True
    )
    def web_search(
        self,
        search_query: str,  # REQUIRED
        max_results: Optional[int] = None,
        max_chars: Optional[int] = None
    ) -> str:
        """Search the web using open-source providers."""
        config = OpenSourceWebSearchProvider._config
        if not config:
            return "error: web search provider not initialized"
        
        # Validate dependencies are available
        try:
            from duckduckgo_search import DDGS
        except ImportError as e:
            error_msg = f"error: web search dependencies missing. Install with: pip install duckduckgo-search. Original error: {e}"
            logger.error(f"[🔍 WEB SEARCH] ERROR | {error_msg}")
            return error_msg
            
        search_start = time.time()
        logger.info(f"[🔍 WEB SEARCH] START | search_query={search_query[:100]} | max_results={max_results} | timestamp={search_start}")
        
        if not search_query:
            error_msg = "ERROR: search_query parameter is REQUIRED. Do NOT call this tool without search_query."
            logger.error(f"[🔍 WEB SEARCH] ERROR | {error_msg} | duration={time.time() - search_start:.3f}s")
            return error_msg

        max_results = max_results or getattr(config, "web_search_max_results", 5)
        max_chars = max_chars or getattr(config, "web_search_max_chars", 6000)

        # Check cache
        cache_key = ("web_search", f"{search_query}:{max_results}:{max_chars}")
        ttl = getattr(config, "web_search_cache_ttl_seconds", 300)
        if ttl > 0:
            with _cache_lock:
                entry = _cache.get(cache_key)
                if entry and not entry.is_expired():
                    total_duration = time.time() - search_start
                    logger.info(f"[🔍 WEB SEARCH] CACHE HIT | search_query={search_query[:100]} | duration={total_duration:.3f}s | result_length={len(entry.value)}")
                    return entry.value
                if entry and entry.is_expired():
                    _cache.pop(cache_key, None)

        try:
            _stats["search_calls"] += 1
            api_call_start = time.time()
            logger.info(f"[🔍 WEB SEARCH] API CALL START | search_query={search_query[:100]} | timestamp={api_call_start}")
            
            # Implement web search using DuckDuckGo (disable SSL verification)
            with DDGS(verify=False) as ddgs:
                ddg_results = list(ddgs.text(search_query, max_results=max_results))
                results: List[Dict[str, str]] = [
                    {
                        "title": item.get("title", ""),
                        "url": item.get("href", ""),
                        "snippet": item.get("body", "")
                    }
                    for item in ddg_results
                ]
            
            api_call_duration = time.time() - api_call_start
            logger.info(f"[🔍 WEB SEARCH] API CALL COMPLETE | search_query={search_query[:100]} | api_duration={api_call_duration:.3f}s | results_count={len(results) if results else 0}")
            
            # Format results inline
            if not results:
                formatted = "No results found."
            else:
                lines = []
                for idx, item in enumerate(results, start=1):
                    title = getattr(item, "title", "") or str(item.get("title", ""))
                    url = getattr(item, "url", "") or str(item.get("url", ""))
                    snippet = getattr(item, "snippet", "") or str(item.get("snippet", ""))
                    lines.append(f"{idx}. {title}\n{snippet}\n{url}")
                text = "\n\n".join(lines)
                formatted = text[:max_chars] if len(text) > max_chars else text
            
            # Cache result
            if ttl > 0:
                with _cache_lock:
                    _cache[cache_key] = _CacheEntry(value=formatted, created_at=time.time(), ttl_seconds=ttl)
            
            total_duration = time.time() - search_start
            logger.info(f"[🔍 WEB SEARCH] COMPLETE | search_query={search_query[:100]} | total_duration={total_duration:.3f}s | result_length={len(formatted)}")
            return formatted
        except Exception as e:
            _stats["search_failures"] += 1
            total_duration = time.time() - search_start
            logger.warning(f"[🔍 WEB SEARCH] ERROR | search_query={search_query[:100]} | error={e} | duration={total_duration:.3f}s")
            return f"error: web search failed ({e})"

    @synapse_method(
        desc="Search and crawl top results for detailed content. CRITICAL: search_query parameter is REQUIRED - you MUST provide it when calling this tool. Do NOT call without search_query - it will fail.",
        when="Use when you need detailed documentation or deep verification. You MUST call with search_query parameter.",
        cache=True,
        timeout=120.0,
        for_architect=True,
        for_auditor=True
    )
    def web_search_and_crawl(
        self,
        search_query: str,  # REQUIRED
        max_results: Optional[int] = None,
        max_chars: Optional[int] = None
    ) -> str:
        """Search and crawl the web for detailed content."""
        config = OpenSourceWebSearchProvider._config
        if not config:
            return "error: web search provider not initialized"
        
        # Validate dependencies are available
        try:
            from duckduckgo_search import DDGS
            from bs4 import BeautifulSoup
        except ImportError as e:
            error_msg = f"error: web search dependencies missing. Install with: pip install duckduckgo-search beautifulsoup4. Original error: {e}"
            logger.error(f"[🔍 WEB SEARCH+CRAWL] ERROR | {error_msg}")
            return error_msg
            
        crawl_start = time.time()
        logger.info(f"[🔍 WEB SEARCH+CRAWL] START | search_query={search_query[:100]} | max_results={max_results} | timestamp={crawl_start}")
        
        if not search_query:
            error_msg = "ERROR: search_query parameter is REQUIRED. Do NOT call this tool without search_query."
            logger.error(f"[🔍 WEB SEARCH+CRAWL] ERROR | {error_msg} | duration={time.time() - crawl_start:.3f}s")
            return error_msg

        if not getattr(config, "enable_web_crawl", True):
            logger.warning(f"[🔍 WEB SEARCH+CRAWL] ERROR | crawling disabled | duration={time.time() - crawl_start:.3f}s")
            return "error: crawling disabled by config"

        max_results = max_results or getattr(config, "web_search_max_results", 3)
        max_chars = max_chars or getattr(config, "web_search_max_chars", 8000)

        # Check cache
        cache_key = ("web_search_and_crawl", f"{search_query}:{max_results}:{max_chars}")
        ttl = getattr(config, "web_search_cache_ttl_seconds", 300)
        if ttl > 0:
            with _cache_lock:
                entry = _cache.get(cache_key)
                if entry and not entry.is_expired():
                    total_duration = time.time() - crawl_start
                    logger.info(f"[🔍 WEB SEARCH+CRAWL] CACHE HIT | search_query={search_query[:100]} | duration={total_duration:.3f}s | result_length={len(entry.value)}")
                    return entry.value
                if entry and entry.is_expired():
                    _cache.pop(cache_key, None)

        try:
            _stats["search_calls"] += 1
            _stats["crawl_calls"] += 1
            
            api_call_start = time.time()
            logger.info(f"[🔍 WEB SEARCH+CRAWL] API CALL START | search_query={search_query[:100]} | timestamp={api_call_start}")
            
            # Implement search + crawl using DuckDuckGo (disable SSL verification)
            # Step 1: Search using DuckDuckGo
            with DDGS(verify=False) as ddgs:
                ddg_results = list(ddgs.text(search_query, max_results=max_results))
                search_results = [
                    {
                        "title": item.get("title", ""),
                        "url": item.get("href", ""),
                        "snippet": item.get("body", "")
                    }
                    for item in ddg_results
                ]
            
            # Step 2: Crawl top results
            crawl_results = []
            for item in search_results:
                url = item.get("url", "")
                if not url:
                    continue
                
                # Scrape the URL using requests - fail if scraping fails
                content = _scrape_url(url)
                crawl_results.append({
                    "title": item.get("title", ""),
                    "url": url,
                    "content": content
                })
            
            data: Dict[str, Any] = {"results": crawl_results}
            
            api_call_duration = time.time() - api_call_start
            logger.info(f"[🔍 WEB SEARCH+CRAWL] API CALL COMPLETE | search_query={search_query[:100]} | api_duration={api_call_duration:.3f}s")
            
            # Format results inline
            if not data or "results" not in data:
                formatted = "No crawl results."
            else:
                parts = []
                for item in data.get("results", []):
                    title = item.get("title") or ""
                    url = item.get("url") or ""
                    content = item.get("content") or ""
                    if not content:
                        continue
                    parts.append(f"# {title}\n{url}\n\n{content}")
                text = "\n\n---\n\n".join(parts)
                formatted = text[:max_chars] if len(text) > max_chars else text
            
            # Cache result
            if ttl > 0:
                with _cache_lock:
                    _cache[cache_key] = _CacheEntry(value=formatted, created_at=time.time(), ttl_seconds=ttl)
            
            total_duration = time.time() - crawl_start
            logger.info(f"[🔍 WEB SEARCH+CRAWL] COMPLETE | search_query={search_query[:100]} | total_duration={total_duration:.3f}s | result_length={len(formatted)}")
            return formatted
        except Exception as e:
            _stats["crawl_failures"] += 1
            total_duration = time.time() - crawl_start
            logger.warning(f"[🔍 WEB SEARCH+CRAWL] ERROR | search_query={search_query[:100]} | error={e} | duration={total_duration:.3f}s")
            return f"error: web search+crawl failed ({e})"

    @synapse_method(
        desc="Crawl a single URL and return extracted content.",
        when="Use when you already have a URL and need its content.",
        cache=True,
        timeout=120.0,
        for_architect=True,
        for_auditor=True
    )
    def web_crawl(
        self,
        url: str,
        query: Optional[str] = None,
        max_chars: Optional[int] = None
    ) -> str:
        """Crawl a single URL for content."""
        config = OpenSourceWebSearchProvider._config
        if not config:
            return "error: web search provider not initialized"
        
        # Validate dependencies are available
        try:
            from bs4 import BeautifulSoup
        except ImportError as e:
            error_msg = f"error: web crawl dependencies missing. Install with: pip install beautifulsoup4. Original error: {e}"
            logger.error(f"[🔍 WEB CRAWL] ERROR | {error_msg}")
            return error_msg
            
        crawl_start = time.time()
        logger.info(f"[🔍 WEB CRAWL] START | url={url[:100]} | query={query[:50] if query else None} | timestamp={crawl_start}")
        
        if not url:
            logger.warning(f"[🔍 WEB CRAWL] ERROR | url is required | duration={time.time() - crawl_start:.3f}s")
            return "error: url is required"

        if not getattr(config, "enable_web_crawl", True):
            logger.warning(f"[🔍 WEB CRAWL] ERROR | crawling disabled | duration={time.time() - crawl_start:.3f}s")
            return "error: crawling disabled by config"

        max_chars = max_chars or getattr(config, "web_search_max_chars", 8000)

        # Check cache
        cache_key = ("web_crawl", f"{url}:{query}:{max_chars}")
        ttl = getattr(config, "web_search_cache_ttl_seconds", 300)
        if ttl > 0:
            with _cache_lock:
                entry = _cache.get(cache_key)
                if entry and not entry.is_expired():
                    total_duration = time.time() - crawl_start
                    logger.info(f"[🔍 WEB CRAWL] CACHE HIT | url={url[:100]} | duration={total_duration:.3f}s | result_length={len(entry.value)}")
                    return entry.value
                if entry and entry.is_expired():
                    _cache.pop(cache_key, None)

        try:
            _stats["crawl_calls"] += 1
            
            api_call_start = time.time()
            logger.info(f"[🔍 WEB CRAWL] API CALL START | url={url[:100]} | timestamp={api_call_start}")
            
            # Implement web crawling using requests
            content = _scrape_url(url)
            
            api_call_duration = time.time() - api_call_start
            logger.info(f"[🔍 WEB CRAWL] API CALL COMPLETE | url={url[:100]} | api_duration={api_call_duration:.3f}s")
            
            formatted = content[:max_chars] if content else "error: empty content"
            
            # Cache result
            if ttl > 0:
                with _cache_lock:
                    _cache[cache_key] = _CacheEntry(value=formatted, created_at=time.time(), ttl_seconds=ttl)
            
            total_duration = time.time() - crawl_start
            logger.info(f"[🔍 WEB CRAWL] COMPLETE | url={url[:100]} | total_duration={total_duration:.3f}s | result_length={len(formatted)}")
            return formatted
        except Exception as e:
            _stats["crawl_failures"] += 1
            total_duration = time.time() - crawl_start
            logger.warning(f"[🔍 WEB CRAWL] ERROR | url={url[:100]} | error={e} | duration={total_duration:.3f}s")
            return f"error: web crawl failed ({e})"

    def get_stats(self) -> Dict[str, int]:
        """Get usage statistics."""
        return dict(_stats)


__all__ = ["OpenSourceWebSearchProvider"]
