"""
ToolShed - Agentic Tool Discovery and Management
=================================================

🎯 NO HARDCODING - All tool mappings are discovered agentically.
🔬 SWARM INTELLIGENCE - Internal micro-agents handle tool selection.

Key Features:
- Automatic tool discovery from metadata providers
- LLM-based tool selection (no regex/keyword matching)
- Capability index (type/schema → producer)
- Tool I/O schema tracking
- Caching to prevent redundant tool calls

Research Foundations:
- GRF MARL: Role assignment and credit (Song et al., 2023)
- No hardcoded role → tool mappings
"""

import logging
import inspect
import json
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable, Type, Tuple, AsyncGenerator
import time

logger = logging.getLogger(__name__)

# Try DSPy for agentic selection
try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


# =============================================================================
# TOOL SCHEMA
# =============================================================================

@dataclass
class ToolSchema:
    """
    Schema describing a tool's inputs and outputs.
    
    🔬 A-TEAM: Enables intelligent tool selection and chaining.
    """
    name: str
    description: str
    
    # Input parameters
    input_params: Dict[str, Type] = field(default_factory=dict)
    required_params: List[str] = field(default_factory=list)
    
    # Output schema
    output_type: Optional[Type] = None
    output_fields: Dict[str, Type] = field(default_factory=dict)
    
    # Discovery metadata
    producer_of: List[str] = field(default_factory=list)  # What this tool produces
    consumer_of: List[str] = field(default_factory=list)  # What this tool needs
    
    # Usage statistics
    call_count: int = 0
    success_rate: float = 1.0
    avg_latency: float = 0.0
    
    def to_prompt_string(self) -> str:
        """Convert to LLM-readable description."""
        params_str = ", ".join([
            f"{k}: {v.__name__ if hasattr(v, '__name__') else str(v)}"
            for k, v in self.input_params.items()
        ])
        output_str = str(self.output_type.__name__) if self.output_type and hasattr(self.output_type, '__name__') else "Any"
        
        return (
            f"TOOL: {self.name}\n"
            f"  Description: {self.description}\n"
            f"  Parameters: ({params_str})\n"
            f"  Returns: {output_str}\n"
            f"  Produces: {', '.join(self.producer_of) or 'N/A'}\n"
            f"  Needs: {', '.join(self.consumer_of) or 'nothing'}"
        )


@dataclass
class ToolResult:
    """Result from a tool call with metadata."""
    tool_name: str
    success: bool
    result: Any
    error: Optional[str] = None
    latency: float = 0.0
    cached: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'tool': self.tool_name,
            'success': self.success,
            'result': str(self.result)[:200],
            'error': self.error,
            'latency': self.latency,
            'cached': self.cached,
        }


# =============================================================================
# AGENTIC TOOL SELECTOR (LLM-based, no regex/keywords)
# =============================================================================

if DSPY_AVAILABLE:
    class ToolSelectionSignature(dspy.Signature):
        """
        Given a task and available tools, select the best tool(s).
        
        NO HARDCODED MAPPINGS - Pure LLM reasoning.
        """
        task_description = dspy.InputField(desc="What needs to be done")
        required_output = dspy.InputField(desc="What type of output is needed (e.g., 'list of tables', 'SQL query', 'DataFrame')")
        available_tools = dspy.InputField(desc="List of available tools with their descriptions")
        current_context = dspy.InputField(desc="What data/outputs are already available")
        
        selected_tools = dspy.OutputField(desc="Comma-separated list of tool names to use, in order")
        reasoning = dspy.OutputField(desc="Why these tools were selected")


class AgenticToolSelector:
    """
    🔬 NO HARDCODING - LLM selects tools based on task.
    
    This replaces regex/keyword matching with pure reasoning.
    """
    
    def __init__(self):
        if DSPY_AVAILABLE:
            self.selector = dspy.ChainOfThought(ToolSelectionSignature)
        else:
            self.selector = None
        logger.info("🔧 AgenticToolSelector initialized (pure LLM, no regex)")
    
    async def select_tools_stream(
        self,
        task: str,
        required_output: str,
        available_tools: List[ToolSchema],
        current_context: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], List[str]]:
        """
        Select tools agentically (no hardcoding).
        
        🔥 A-TEAM CRITICAL FIX: NO silent fallback!
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            List of tool names in execution order
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        yield {"module": "Synapse.core.tool_shed", "message": f"I am selecting tools agentically for task: {task[:100] if len(task) > 100 else task}"}
        if not self.selector:
            yield {"module": "Synapse.core.tool_shed", "message": "I noticed LLM is not configured, cannot perform agentic tool selection"}
            raise RuntimeError(
                "❌ ToolShed requires LLM intelligence for tool selection!\n"
                "Agentic tool selection is critical for task execution. "
                "Cannot fall back to returning all tools as it causes inefficiency and errors. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        
        try:
            # Format tools for LLM
            yield {"module": "Synapse.core.tool_shed", "message": f"I am formatting {len(available_tools)} available tools for LLM analysis"}
            tools_str = "\n\n".join([t.to_prompt_string() for t in available_tools])
            
            # Format context
            context_str = ", ".join([
                f"{k}: {type(v).__name__}" for k, v in current_context.items()
            ])
            
            # LLM selection
            yield {"module": "Synapse.core.tool_shed", "message": "I am calling the LLM to select appropriate tools"}
            result = self.selector(
                task_description=task,
                required_output=required_output,
                available_tools=tools_str,
                current_context=context_str or "empty"
            )
            
            # Parse selected tools
            selected = [t.strip() for t in result.selected_tools.split(",")]
            
            # Validate against available
            valid_names = {t.name for t in available_tools}
            selected = [t for t in selected if t in valid_names]
            
            logger.debug(f"🎯 Selected tools: {selected}")
            logger.debug(f"   Reasoning: {result.reasoning}")
            yield {"module": "Synapse.core.tool_shed", "message": f"I selected {len(selected)} tools: {selected}"}
            yield {"module": "Synapse.core.tool_shed", "message": f"Reasoning: {result.reasoning[:200] if len(result.reasoning) > 200 else result.reasoning}"}
            
            final_selected = selected[: self.max_tools] if self.max_tools else selected
            yield {"type": "result", "result": final_selected}
            return
            
        except Exception as e:
            logger.warning(f"⚠️ Agentic selection failed: {e}, returning all tools")
            yield {"module": "Synapse.core.tool_shed", "message": f"I encountered an error during tool selection: {e}, returning all available tools"}
            names = [t.name for t in available_tools]
            final_names = names[: self.max_tools] if self.max_tools else names
            yield {"type": "result", "result": final_names}
            return
    
    def select_tools(
        self,
        task: str,
        required_output: str,
        available_tools: List[ToolSchema],
        current_context: Dict[str, Any]
    ) -> List[str]:
        """Synchronous wrapper for select_tools_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use select_tools_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.select_tools_stream(task, required_output, available_tools, current_context):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_select_tools(task, required_output, available_tools, current_context))
    
    async def _sync_select_tools(
        self,
        task: str,
        required_output: str,
        available_tools: List[ToolSchema],
        current_context: Dict[str, Any]
    ) -> List[str]:
        """Helper for sync wrapper."""
        result = None
        async for event in self.select_tools_stream(task, required_output, available_tools, current_context):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else []


# =============================================================================
# AGENTIC AGENT SELECTOR (LLM-based, no hardcoding)
# =============================================================================

if DSPY_AVAILABLE:
    class AgentSelectionSignature(dspy.Signature):
        """
        Given a task goal and available agents with their specializations,
        select only the relevant agent(s) needed to complete the task.
        
        NO HARDCODED MAPPINGS - Pure LLM reasoning based on agent descriptions.
        """
        goal = dspy.InputField(desc="The task goal/instruction to accomplish")
        available_agents = dspy.InputField(desc="JSON list of available agents with their names and descriptions/specializations")
        
        selected_agents = dspy.OutputField(desc="Comma-separated list of agent names that should handle this task (often just 1)")
        reasoning = dspy.OutputField(desc="Why these specific agents were selected")


class AgenticAgentSelector:
    """
    🔬 NO HARDCODING - LLM selects agents based on task goal.
    
    This analyzes the task and determines which agent(s) are appropriate,
    avoiding the anti-pattern of scheduling ALL agents for every task.
    
    Example:
        - Git recovery task → CodeMaster only
        - ML model training → DataMind only
        - Security audit → SecureSentry only
        - Complex task spanning domains → Multiple agents
    """
    
    def __init__(self):
        if DSPY_AVAILABLE:
            self.selector = dspy.ChainOfThought(AgentSelectionSignature)
        else:
            self.selector = None
        logger.info("🎯 AgenticAgentSelector initialized (pure LLM, no hardcoding)")
    
    async def select_agents_stream(
        self,
        goal: str,
        available_agents: List[Dict[str, str]],
    ) -> AsyncGenerator[Dict[str, Any], Tuple[List[str], str]]:
        """
        Select agents agentically based on goal (no hardcoding).
        
        Args:
            goal: The task goal/instruction
            available_agents: List of dicts with 'name' and 'description' keys
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            Tuple of (list of selected agent names, reasoning string)
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        yield {"module": "Synapse.core.tool_shed", "message": f"I am selecting agents agentically for goal: {goal[:100] if len(goal) > 100 else goal}"}
        if not self.selector:
            yield {"module": "Synapse.core.tool_shed", "message": "I noticed LLM is not configured, cannot perform agentic agent selection"}
            raise RuntimeError(
                "❌ AgenticAgentSelector requires LLM intelligence!\n"
                "Agentic agent selection is critical for multi-agent coordination. "
                "Cannot fall back to returning all agents as it causes inefficiency and coordination failures. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        
        if not available_agents:
            yield {"module": "Synapse.core.tool_shed", "message": "I noticed no agents are available"}
            yield {"type": "result", "result": ([], "No agents available")}
            return
        
        try:
            # Format agents for LLM
            agents_json = json.dumps(available_agents, indent=2)
            
            # ⏱️ AGGRESSIVE TIMING: LLM call for agent selection
            llm_call_start = time.time()
            logger.info(f"⏱️ [LLM CALL START] AgenticAgentSelector.select_agents | goal_length={len(goal)} | agents_count={len(available_agents)}")
            yield {"module": "Synapse.core.tool_shed", "message": f"I am calling the LLM to select agents from {len(available_agents)} available agents"}
            
            # LLM selection
            result = self.selector(
                goal=goal,
                available_agents=agents_json
            )
            
            llm_call_duration = time.time() - llm_call_start
            logger.info(f"⏱️ [LLM CALL COMPLETE] AgenticAgentSelector.select_agents | duration={llm_call_duration:.3f}s")
            yield {"module": "Synapse.core.tool_shed", "message": f"I received a response from the LLM (duration: {llm_call_duration:.3f}s)"}
            
            # Extract token usage if available
            if hasattr(result, '_completions') and result._completions:
                for i, completion in enumerate(result._completions):
                    if hasattr(completion, 'usage'):
                        usage = completion.usage
                        logger.info(f"⏱️ [LLM TOKENS] AgenticAgentSelector completion[{i}] | input_tokens={getattr(usage, 'prompt_tokens', 'N/A')} | output_tokens={getattr(usage, 'completion_tokens', 'N/A')} | total_tokens={getattr(usage, 'total_tokens', 'N/A')}")
            
            # Parse selected agents
            parse_start = time.time()
            selected = [a.strip() for a in result.selected_agents.split(",")]
            parse_duration = time.time() - parse_start
            logger.info(f"⏱️ [PARSE AGENTS] AgenticAgentSelector.select_agents | parse_duration={parse_duration:.3f}s | selected_count={len(selected)}")
            yield {"module": "Synapse.core.tool_shed", "message": f"I parsed {len(selected)} selected agents"}
            
            # Validate against available agents
            validation_start = time.time()
            valid_names = {a['name'] for a in available_agents}
            selected = [a for a in selected if a in valid_names]
            validation_duration = time.time() - validation_start
            logger.info(f"⏱️ [VALIDATE AGENTS] AgenticAgentSelector.select_agents | validation_duration={validation_duration:.3f}s")
            
            # Ensure at least one agent is selected
            if not selected:
                logger.warning("⚠️ No valid agents selected, using first available")
                yield {"module": "Synapse.core.tool_shed", "message": "I did not find valid agents, using first available agent"}
                selected = [available_agents[0]['name']]
                result.reasoning = f"Fallback to {selected[0]}"
            
            logger.info(f"🎯 Selected agents: {selected}")
            logger.info(f"   Reasoning: {result.reasoning}")
            yield {"module": "Synapse.core.tool_shed", "message": f"I selected agents: {selected}"}
            yield {"module": "Synapse.core.tool_shed", "message": f"Reasoning: {result.reasoning[:200] if len(result.reasoning) > 200 else result.reasoning}"}
            
            result_tuple = (selected, result.reasoning)
            yield {"type": "result", "result": result_tuple}
            return
            
        except Exception as e:
            logger.warning(f"⚠️ Agentic agent selection failed: {e}, returning first agent")
            yield {"module": "Synapse.core.tool_shed", "message": f"I encountered an error during agent selection: {e}, returning first available agent"}
            if available_agents:
                result_tuple = ([available_agents[0]['name']], f"Selection failed: {e}")
                yield {"type": "result", "result": result_tuple}
                return
            result_tuple = ([], f"Selection failed: {e}")
            yield {"type": "result", "result": result_tuple}
            return
    
    def select_agents(
        self,
        goal: str,
        available_agents: List[Dict[str, str]],
    ) -> Tuple[List[str], str]:
        """Synchronous wrapper for select_agents_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use select_agents_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.select_agents_stream(goal, available_agents):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_select_agents(goal, available_agents))
    
    async def _sync_select_agents(
        self,
        goal: str,
        available_agents: List[Dict[str, str]],
    ) -> Tuple[List[str], str]:
        """Helper for sync wrapper."""
        result = None
        async for event in self.select_agents_stream(goal, available_agents):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else ([], "No result")


# =============================================================================
# CAPABILITY INDEX
# =============================================================================

class CapabilityIndex:
    """
    🔬 A-TEAM: Maps (output_type, schema) → producers.
    
    Enables:
    - "I need a DataFrame with columns [a,b,c]" → "Use SQLGenerator"
    - Automatic tool chaining based on I/O compatibility
    """
    
    def __init__(self):
        # type/field → list of producers
        self.producers: Dict[str, List[str]] = {}
        # producer → list of what it produces
        self.produces: Dict[str, List[str]] = {}
        # producer → list of what it consumes
        self.consumes: Dict[str, List[str]] = {}
        
        logger.info("📊 CapabilityIndex initialized")
    
    def register_tool(self, schema: ToolSchema):
        """Register a tool's capabilities."""
        # What it produces
        for output in schema.producer_of:
            if output not in self.producers:
                self.producers[output] = []
            if schema.name not in self.producers[output]:
                self.producers[output].append(schema.name)
        
        self.produces[schema.name] = schema.producer_of.copy()
        self.consumes[schema.name] = schema.consumer_of.copy()
        
        logger.debug(f"📝 Registered {schema.name}: produces={schema.producer_of}, consumes={schema.consumer_of}")
    
    def find_producers(self, output_type: str) -> List[str]:
        """Find tools that can produce a given output type."""
        return self.producers.get(output_type, [])
    
    def can_chain(self, producer: str, consumer: str) -> bool:
        """Check if producer's output can feed consumer's input."""
        produced = set(self.produces.get(producer, []))
        needed = set(self.consumes.get(consumer, []))
        return bool(produced & needed)
    
    def find_chain(self, start: str, end: str, max_depth: int = 5) -> List[str]:
        """
        Find a chain of tools from start capability to end capability.
        
        Returns list of tool names, or empty if no chain found.
        """
        # BFS to find shortest path
        from collections import deque
        
        queue = deque([(self.find_producers(start), [start])])
        visited = set()
        
        while queue and len(visited) < max_depth * 10:
            producers, path = queue.popleft()
            
            for producer in producers:
                if producer in visited:
                    continue
                visited.add(producer)
                
                new_path = path + [producer]
                
                # Check if this producer can produce the end
                if end in self.produces.get(producer, []):
                    return new_path[1:]  # Skip start capability
                
                # Add downstream capabilities
                for produced in self.produces.get(producer, []):
                    if produced not in visited:
                        downstream = self.find_producers(produced)
                        if downstream:
                            queue.append((downstream, new_path + [produced]))
        
        return []
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'producers': self.producers,
            'produces': self.produces,
            'consumes': self.consumes,
        }


# =============================================================================
# TOOL SHED (Main Class)
# =============================================================================

class ToolShed:
    """
    Central repository for tools with agentic discovery.
    
    🎯 NO HARDCODING - All mappings are discovered.
    🔬 SWARM INTELLIGENCE - LLM selects appropriate tools.
    
    Features:
    - Automatic schema extraction from callables
    - Capability-based tool discovery
    - LLM-based tool selection
    - Call caching to prevent redundant calls
    - Usage statistics for learning
    """
    
    def __init__(
        self,
        max_tools: Optional[int] = None,
        cache_ttl_seconds: float = 300.0,
        cache_max_entries: int = 1000,
    ):
        self.tools: Dict[str, Callable] = {}
        self.schemas: Dict[str, ToolSchema] = {}
        self.capability_index = CapabilityIndex()
        self.selector = AgenticToolSelector()
        self.max_tools = max_tools
        
        # Call cache (prevents redundant tool calls) - bounded + TTL
        self.cache: "OrderedDict[str, Tuple[Any, float]]" = OrderedDict()
        self.cache_ttl: float = cache_ttl_seconds
        self.cache_max_entries: int = cache_max_entries
        
        # Usage statistics
        self.call_stats: Dict[str, Dict[str, Any]] = {}
        
        logger.info("🏠 ToolShed initialized (agentic discovery, no hardcoding)")

    def _evict_expired(self):
        if self.cache_ttl is None:
            return
        now = time.time()
        expired_keys = []
        for key, (_, ts) in self.cache.items():
            if now - ts >= self.cache_ttl:
                expired_keys.append(key)
        for key in expired_keys:
            self.cache.pop(key, None)

    def _ensure_capacity(self):
        if self.cache_max_entries is None:
            return
        while len(self.cache) > self.cache_max_entries:
            self.cache.popitem(last=False)
    
    def register(
        self,
        tool: Callable,
        name: Optional[str] = None,
        description: Optional[str] = None,
        produces: Optional[List[str]] = None,
        consumes: Optional[List[str]] = None,
    ):
        """
        Register a tool with automatic schema extraction.
        
        Parameters:
        -----------
        tool : Callable
            The function/method to register.
            
        name : str, optional
            Override the tool's name (default: function name).
            
        description : str, optional
            Override description (default: docstring).
            
        produces : List[str], optional
            What this tool produces (auto-inferred if not provided).
            
        consumes : List[str], optional
            What this tool needs (auto-inferred from parameters).
        """
        tool_name = name or tool.__name__
        
        # Extract schema automatically
        schema = self._extract_schema(
            tool=tool,
            name=tool_name,
            description=description,
            produces=produces,
            consumes=consumes,
        )
        
        self.tools[tool_name] = tool
        self.schemas[tool_name] = schema
        self.capability_index.register_tool(schema)
        
        logger.debug(f"📦 Registered tool: {tool_name}")
    
    def _extract_schema(
        self,
        tool: Callable,
        name: str,
        description: Optional[str] = None,
        produces: Optional[List[str]] = None,
        consumes: Optional[List[str]] = None,
    ) -> ToolSchema:
        """Extract schema from callable."""
        # Get signature
        sig = inspect.signature(tool)
        
        # Extract input params
        input_params = {}
        required_params = []
        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'cls', 'kwargs', 'args'):
                continue
            
            param_type = param.annotation if param.annotation != inspect.Parameter.empty else Any
            input_params[param_name] = param_type
            
            if param.default == inspect.Parameter.empty:
                required_params.append(param_name)
        
        # Get return type
        return_type = sig.return_annotation if sig.return_annotation != inspect.Signature.empty else None
        
        # Get description from docstring
        desc = description or (tool.__doc__ or "").split("\n")[0].strip() or f"Tool: {name}"
        
        # Infer produces from return type
        if produces is None:
            produces = []
            if return_type:
                produces.append(str(return_type.__name__) if hasattr(return_type, '__name__') else str(return_type))
        
        # Infer consumes from required params
        if consumes is None:
            consumes = required_params.copy()
        
        return ToolSchema(
            name=name,
            description=desc,
            input_params=input_params,
            required_params=required_params,
            output_type=return_type,
            producer_of=produces,
            consumer_of=consumes,
        )
    
    async def select_tools_stream(
        self,
        task: str,
        required_output: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[Dict[str, Any], List[str]]:
        """
        Select tools for a task (agentically, no hardcoding).
        
        Uses LLM to reason about which tools to use.
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            List of selected tool names
        """
        yield {"module": "Synapse.core.tool_shed", "message": f"I am selecting tools for task: {task[:100] if len(task) > 100 else task}"}
        schemas = list(self.schemas.values())
        selected = None
        async for event in self.selector.select_tools_stream(
            task=task,
            required_output=required_output,
            available_tools=schemas,
            current_context=context or {},
        ):
            yield event
            if event.get("type") == "result":
                selected = event.get("result")
        
        if selected is None:
            selected = []
        
        if self.max_tools and selected:
            final_selected = selected[: self.max_tools]
            yield {"module": "Synapse.core.tool_shed", "message": f"I limited selection to {self.max_tools} tools: {final_selected}"}
            yield {"type": "result", "result": final_selected}
            return
        
        yield {"type": "result", "result": selected}
        return
    
    def select_tools(
        self,
        task: str,
        required_output: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        """Synchronous wrapper for select_tools_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use select_tools_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.select_tools_stream(task, required_output, context):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_toolshed_select_tools(task, required_output, context))
    
    async def _sync_toolshed_select_tools(
        self,
        task: str,
        required_output: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        """Helper for sync wrapper."""
        result = None
        async for event in self.select_tools_stream(task, required_output, context):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else []
    
    def call(
        self,
        tool_name: str,
        use_cache: bool = True,
        **kwargs
    ) -> ToolResult:
        """
        Call a tool with caching and statistics.
        
        Parameters:
        -----------
        tool_name : str
            Name of tool to call.
            
        use_cache : bool, default=True
            Use cached result if available.
            
        **kwargs : Any
            Parameters to pass to tool.
        
        Returns:
        --------
        ToolResult with success, result, error, timing.
        """
        if tool_name not in self.tools:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                result=None,
                error=f"Tool '{tool_name}' not found",
            )
        
        # Check cache
        cache_key = f"{tool_name}:{hash(frozenset(kwargs.items()))}"
        if use_cache:
            self._evict_expired()
            if cache_key in self.cache:
                cached_result, cached_time = self.cache[cache_key]
                if self.cache_ttl is None or time.time() - cached_time < self.cache_ttl:
                    self.cache.move_to_end(cache_key)
                    logger.debug(f"🎯 Cache hit: {tool_name}")
                    return ToolResult(
                        tool_name=tool_name,
                        success=True,
                        result=cached_result,
                        cached=True,
                    )
                self.cache.pop(cache_key, None)
        
        # Call tool
        start_time = time.time()
        try:
            result = self.tools[tool_name](**kwargs)
            latency = time.time() - start_time
            
            # Update cache (bounded + TTL)
            self.cache[cache_key] = (result, time.time())
            self.cache.move_to_end(cache_key)
            self._ensure_capacity()
            
            # Update stats
            self._update_stats(tool_name, success=True, latency=latency)
            
            return ToolResult(
                tool_name=tool_name,
                success=True,
                result=result,
                latency=latency,
            )
            
        except Exception as e:
            latency = time.time() - start_time
            self._update_stats(tool_name, success=False, latency=latency)
            
            return ToolResult(
                tool_name=tool_name,
                success=False,
                result=None,
                error=str(e),
                latency=latency,
            )
    
    def _update_stats(self, tool_name: str, success: bool, latency: float):
        """Update usage statistics."""
        if tool_name not in self.call_stats:
            self.call_stats[tool_name] = {
                'calls': 0,
                'successes': 0,
                'total_latency': 0.0,
            }
        
        stats = self.call_stats[tool_name]
        stats['calls'] += 1
        stats['successes'] += 1 if success else 0
        stats['total_latency'] += latency
        
        # Update schema
        if tool_name in self.schemas:
            schema = self.schemas[tool_name]
            schema.call_count = stats['calls']
            schema.success_rate = stats['successes'] / stats['calls']
            schema.avg_latency = stats['total_latency'] / stats['calls']
    
    def get_tools_for_agent(self, agent_name: str, signature: Any = None) -> List[Callable]:
        """
        Get tools for an agent based on its signature.
        
        🔬 NO HARDCODING - Uses capability matching.
        """
        if signature is None:
            return list(self.tools.values())
        
        # Extract required inputs from signature
        required = []
        if hasattr(signature, 'input_fields'):
            required = list(signature.input_fields.keys())
        elif hasattr(signature, '__annotations__'):
            required = list(signature.__annotations__.keys())
        
        # Find tools that produce what agent needs
        matching_tools = []
        for req in required:
            producers = self.capability_index.find_producers(req)
            for producer in producers:
                if producer in self.tools:
                    matching_tools.append(self.tools[producer])
        
        return list(set(matching_tools)) or list(self.tools.values())
    
    def clear_cache(self):
        """Clear all cached results."""
        self.cache.clear()
        logger.info("🗑️  ToolShed cache cleared")
    
    def get_all_schemas(self) -> List[ToolSchema]:
        """Get all tool schemas."""
        return list(self.schemas.values())
    
    def to_prompt_string(self) -> str:
        """Format all tools for LLM prompt."""
        return "\n\n".join([
            schema.to_prompt_string() 
            for schema in self.schemas.values()
        ])


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'ToolShed',
    'ToolSchema',
    'ToolResult',
    'CapabilityIndex',
    'AgenticToolSelector',
    'AgenticAgentSelector',
]

