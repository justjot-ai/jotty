"""
Centralized LLM gateway resolution for Synapse/UV.

Provides a single place to map gateway names to credential env variables,
resolve runtime LM kwargs, and expose supported gateways for config files.
Includes lifecycle telemetry for init/reuse/dispose tracking.
"""

from dataclasses import dataclass, field
from typing import Dict, Optional, List
from datetime import datetime
import logging
import os
import threading

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GatewaySpec:
    name: str
    default_api_key_env: Optional[str] = None
    default_api_base_env: Optional[str] = None
    notes: str = ""


SUPPORTED_GATEWAYS: Dict[str, GatewaySpec] = {
    "litellm": GatewaySpec(
        name="litellm",
        default_api_key_env="LITELLM_API_KEY",
        default_api_base_env="LITELLM_BASE_URL",
        notes="OpenAI-compatible gateway; default in this stack.",
    ),
    "openai": GatewaySpec(
        name="openai",
        default_api_key_env="OPENAI_API_KEY",
        default_api_base_env="OPENAI_BASE_URL",
        notes="Direct OpenAI API key + optional base URL.",
    ),
    "anthropic": GatewaySpec(
        name="anthropic",
        default_api_key_env="ANTHROPIC_API_KEY",
        default_api_base_env="ANTHROPIC_BASE_URL",
        notes="Direct Anthropic API key + optional base URL.",
    ),
    "truefoundry": GatewaySpec(
        name="truefoundry",
        default_api_key_env="TRUEFOUNDRY_API_KEY",
        default_api_base_env="TRUEFOUNDRY_BASE_URL",
        notes="TrueFoundry OpenAI-compatible gateway.",
    ),
    "azure_openai": GatewaySpec(
        name="azure_openai",
        default_api_key_env="AZURE_OPENAI_API_KEY",
        default_api_base_env="AZURE_OPENAI_API_BASE",
        notes="Azure OpenAI endpoint/deployment routing.",
    ),
    "groq": GatewaySpec(
        name="groq",
        default_api_key_env="GROQ_API_KEY",
        default_api_base_env="GROQ_API_BASE",
        notes="Groq-hosted model gateway.",
    ),
    "together": GatewaySpec(
        name="together",
        default_api_key_env="TOGETHER_API_KEY",
        default_api_base_env="TOGETHER_API_BASE",
        notes="Together-hosted model gateway.",
    ),
    "bedrock": GatewaySpec(
        name="bedrock",
        default_api_key_env=None,
        default_api_base_env=None,
        notes="AWS credentials/roles are used instead of static API keys.",
    ),
}


def resolve_gateway_name(gateway: Optional[str], default: str = "litellm") -> str:
    """Return normalized gateway name, falling back to default if unknown."""
    chosen = (gateway or default or "litellm").strip().lower()
    if chosen not in SUPPORTED_GATEWAYS:
        return default
    return chosen


def resolve_lm_kwargs(
    model: str,
    gateway: Optional[str] = None,
    api_key_env: Optional[str] = None,
    api_base_env: Optional[str] = None,
) -> Dict[str, str]:
    """
    Build kwargs for dspy.LM from gateway + env wiring.

    Returns at least {"model": model} and conditionally includes:
      - api_key
      - api_base
    """
    gateway_name = resolve_gateway_name(gateway)
    spec = SUPPORTED_GATEWAYS[gateway_name]
    key_env = api_key_env or spec.default_api_key_env
    base_env = api_base_env or spec.default_api_base_env

    kwargs: Dict[str, str] = {"model": model}
    if key_env:
        api_key = os.getenv(key_env, "").strip()
        if api_key:
            kwargs["api_key"] = api_key
    if base_env:
        api_base = os.getenv(base_env, "").strip()
        if api_base:
            kwargs["api_base"] = api_base
    return kwargs


# =============================================================================
# LIFECYCLE TELEMETRY (Item 142)
# =============================================================================

@dataclass
class _GatewayLifecycleEntry:
    """Single lifecycle event for an LM/gateway."""
    model: str
    gateway: str
    action: str  # "initialized", "reused", "disposed"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class GatewayLifecycleTelemetry:
    """Thread-safe tracker for model/gateway initialization, reuse, and disposal.

    Usage:
        telemetry = get_gateway_telemetry()
        telemetry.record_init("claude-sonnet-4-20250514", "litellm")
        telemetry.record_reuse("claude-sonnet-4-20250514", "litellm")
        print(telemetry.summary())
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._events: List[_GatewayLifecycleEntry] = []
        self._init_counts: Dict[str, int] = {}   # "model::gateway" -> count
        self._reuse_counts: Dict[str, int] = {}
        self._dispose_counts: Dict[str, int] = {}

    def _key(self, model: str, gateway: str) -> str:
        return f"{model}::{gateway}"

    def record_init(self, model: str, gateway: str) -> None:
        key = self._key(model, gateway)
        with self._lock:
            self._init_counts[key] = self._init_counts.get(key, 0) + 1
            self._events.append(_GatewayLifecycleEntry(model, gateway, "initialized"))
        logger.debug(f"🔧 LM lifecycle: initialized {key} (total inits: {self._init_counts[key]})")

    def record_reuse(self, model: str, gateway: str) -> None:
        key = self._key(model, gateway)
        with self._lock:
            self._reuse_counts[key] = self._reuse_counts.get(key, 0) + 1
            self._events.append(_GatewayLifecycleEntry(model, gateway, "reused"))

    def record_dispose(self, model: str, gateway: str) -> None:
        key = self._key(model, gateway)
        with self._lock:
            self._dispose_counts[key] = self._dispose_counts.get(key, 0) + 1
            self._events.append(_GatewayLifecycleEntry(model, gateway, "disposed"))

    def summary(self) -> Dict[str, Dict[str, int]]:
        """Return { 'model::gateway': { initialized, reused, disposed } }."""
        with self._lock:
            keys = set(list(self._init_counts) + list(self._reuse_counts) + list(self._dispose_counts))
            return {
                k: {
                    "initialized": self._init_counts.get(k, 0),
                    "reused": self._reuse_counts.get(k, 0),
                    "disposed": self._dispose_counts.get(k, 0),
                }
                for k in sorted(keys)
            }

    def total_inits(self) -> int:
        with self._lock:
            return sum(self._init_counts.values())

    def total_reuses(self) -> int:
        with self._lock:
            return sum(self._reuse_counts.values())

    def recent_events(self, n: int = 20) -> List[Dict[str, str]]:
        with self._lock:
            return [
                {"model": e.model, "gateway": e.gateway, "action": e.action, "timestamp": e.timestamp}
                for e in self._events[-n:]
            ]


# Singleton
_telemetry_instance: Optional[GatewayLifecycleTelemetry] = None
_telemetry_lock = threading.Lock()


def get_gateway_telemetry() -> GatewayLifecycleTelemetry:
    """Get or create the singleton lifecycle telemetry tracker."""
    global _telemetry_instance
    if _telemetry_instance is None:
        with _telemetry_lock:
            if _telemetry_instance is None:
                _telemetry_instance = GatewayLifecycleTelemetry()
    return _telemetry_instance
