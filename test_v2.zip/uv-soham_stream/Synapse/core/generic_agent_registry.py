"""
Generic Agent Registry for ReVal - Domain Agnostic
=================================================

Central registry for actor discovery and capability-based routing.
Works with ANY type of actors in ANY domain.

A-Team Approved: Universal orchestration component
"""

from typing import Dict, List, Any, Optional, Callable, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime
import json
import logging

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


@dataclass
class ActorRegistration:
    """Complete actor registration information."""
    name: str
    actor: Any
    capabilities: List[str]
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Performance tracking
    call_count: int = 0
    success_count: int = 0
    total_execution_time: float = 0.0
    average_confidence: float = 0.0
    
    # Registration metadata
    registered_at: datetime = field(default_factory=datetime.now)
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.call_count == 0:
            return 1.0
        return self.success_count / self.call_count
    
    @property
    def avg_execution_time(self) -> float:
        """Calculate average execution time."""
        if self.call_count == 0:
            return 0.0
        return self.total_execution_time / self.call_count


class GenericAgentRegistry:
    """
    Universal registry for actors in multi-actor systems.
    Enables dynamic actor discovery and capability-based routing.
    
    Domain-agnostic: Works with SQL agents, code agents, data agents, etc.
    """
    
    def __init__(self, lm: Optional[Any] = None):
        self._actors: Dict[str, ActorRegistration] = {}
        self._capability_index: Dict[str, List[str]] = {}  # capability -> [actor_names]
        self.lm = lm
        if self.lm is None and DSPY_AVAILABLE:
            # Use global DSPy LM if configured (no hardcoding)
            self.lm = getattr(dspy.settings, "lm", None)
            if self.lm is not None:
                logger.info("🧭 GenericAgentRegistry using dspy.settings.lm for capability inference")
    
    def register(
        self,
        name: str,
        actor: Any,
        capabilities: Optional[List[str]] = None,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Register an actor with its capabilities.
        
        Args:
            name: Unique actor identifier
            actor: The actor instance (DSPy module or any callable)
            capabilities: List of capability names (auto-inferred if None)
            description: Human-readable description
            metadata: Optional custom metadata
        """
        if name in self._actors:
            print(f"⚠️  Actor '{name}' already registered, updating...")
        
        # Auto-infer capabilities if not provided
        if capabilities is None:
            capabilities = self._infer_capabilities(name, actor, description)
        
        registration = ActorRegistration(
            name=name,
            actor=actor,
            capabilities=capabilities,
            description=description,
            metadata=metadata or {}
        )
        
        self._actors[name] = registration
        
        # Update capability index
        for capability in capabilities:
            if capability not in self._capability_index:
                self._capability_index[capability] = []
            if name not in self._capability_index[capability]:
                self._capability_index[capability].append(name)
        
        print(f"✅ Registered actor: {name} with capabilities: {', '.join(capabilities)}")
        logger.info(f"✅ Registered actor: {name} with capabilities: {', '.join(capabilities)}")
        # Note: Sync method, async version would yield events
    
    def _infer_capabilities(self, name: str, actor: Any, description: str) -> List[str]:
        """
        Auto-infer actor capabilities.
        
        A-Team Requirement: LLM-only inference (no heuristics).
        If LLM is unavailable, return explicit uncertainty (empty list).
        """
        if DSPY_AVAILABLE and self.lm:
            return self._llm_infer_capabilities(name, actor, description)
        logger.warning("⚠️ LLM unavailable for capability inference; returning empty capabilities")
        return []
    
    def _llm_infer_capabilities(self, name: str, actor: Any, description: str) -> List[str]:
        """
        Use LLM to infer capabilities.
        
        Automatically adds base LLM capabilities since all actors are LLM-based agents.
        """
        # Base capabilities that all LLM agents have
        base_llm_capabilities = [
            "text_understanding",
            "text_generation",
            "summarization",
            "reasoning",
            "analysis",
            "natural_language_processing"
        ]
        
        try:
            class CapabilityInferenceSignature(dspy.Signature):
                """Infer actor-specific capabilities beyond base LLM capabilities."""
                actor_name = dspy.InputField(desc="Name of the actor")
                actor_description = dspy.InputField(desc="Description of what the actor does")
                actor_class = dspy.InputField(desc="Actor class name")
                
                capabilities = dspy.OutputField(desc="List of specialized capabilities as JSON array (excluding base LLM capabilities like text understanding, summarization, reasoning)")
            
            infer = dspy.ChainOfThought(CapabilityInferenceSignature)
            
            with dspy.context(lm=self.lm):
                result = infer(
                    actor_name=name,
                    actor_description=description or "No description",
                    actor_class=actor.__class__.__name__
                )
            
            specialized_capabilities = json.loads(result.capabilities)
            if not isinstance(specialized_capabilities, list):
                specialized_capabilities = [specialized_capabilities]
            
            # Combine base capabilities with specialized ones, remove duplicates
            all_capabilities = base_llm_capabilities + specialized_capabilities
            # Remove duplicates while preserving order
            seen = set()
            unique_capabilities = []
            for cap in all_capabilities:
                cap_lower = cap.lower()
                if cap_lower not in seen:
                    seen.add(cap_lower)
                    unique_capabilities.append(cap)
            
            return unique_capabilities
        except Exception as e:
            print(f"⚠️  LLM capability inference failed: {e}, returning base LLM capabilities only")
            # Even on failure, return base LLM capabilities
            return base_llm_capabilities
    
    def get_actor(self, name: str) -> Optional[ActorRegistration]:
        """Get actor by name."""
        return self._actors.get(name)
    
    def get_actors_by_capability(self, capability: str) -> List[ActorRegistration]:
        """Find all actors that have a specific capability."""
        actor_names = self._capability_index.get(capability, [])
        return [self._actors[name] for name in actor_names if name in self._actors]
    
    def get_all_actors(self) -> Dict[str, ActorRegistration]:
        """Get all registered actors."""
        return self._actors.copy()
    
    def update_metrics(
        self,
        actor_name: str,
        success: bool,
        execution_time: float,
        confidence: Optional[float] = None
    ) -> None:
        """Update actor performance metrics."""
        if actor_name not in self._actors:
            return
        
        actor = self._actors[actor_name]
        actor.call_count += 1
        if success:
            actor.success_count += 1
        actor.total_execution_time += execution_time
        
        if confidence is not None:
            # Running average of confidence
            if actor.call_count == 1:
                actor.average_confidence = confidence
            else:
                actor.average_confidence = (
                    (actor.average_confidence * (actor.call_count - 1) + confidence)
                    / actor.call_count
                )
    
    def find_best_actor(self, capability: str) -> Optional[str]:
        """
        Find the best actor for a capability using LLM-based ranking.
        
        A-Team Requirement: No heuristic scoring. If LLM is unavailable,
        return explicit uncertainty (None).
        """
        candidates = self.get_actors_by_capability(capability)
        if not candidates:
            return None
        
        if not (DSPY_AVAILABLE and self.lm):
            logger.warning("⚠️ LLM unavailable for actor ranking; returning None")
            return None
        
        try:
            class ActorSelectionSignature(dspy.Signature):
                """Select the best actor for a capability."""
                capability = dspy.InputField(desc="Capability needed")
                candidates = dspy.InputField(desc="JSON list of candidate actors with metrics")
                
                reasoning = dspy.OutputField(desc="Why this actor is best suited")
                selected_actor = dspy.OutputField(desc="Name of the best actor")
            
            selector = dspy.ChainOfThought(ActorSelectionSignature)
            
            candidate_summary = [
                {
                    "name": c.name,
                    "description": c.description,
                    "success_rate": c.success_rate,
                    "avg_execution_time": c.avg_execution_time,
                    "capabilities": c.capabilities
                }
                for c in candidates
            ]
            
            with dspy.context(lm=self.lm):
                result = selector(
                    capability=capability,
                    candidates=json.dumps(candidate_summary, default=str)
                )
            
            selected = str(getattr(result, "selected_actor", "")).strip()
            if selected and selected in self._actors:
                return selected
        except Exception as e:
            logger.warning(f"⚠️ LLM actor ranking failed: {e}")
        
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert registry to dictionary for LLM context."""
        actors_info = {}
        for name, actor in self._actors.items():
            actors_info[name] = {
                "name": name,
                "capabilities": actor.capabilities,
                "description": actor.description,
                "success_rate": f"{actor.success_rate:.2%}",
                "call_count": actor.call_count,
                "avg_time": f"{actor.avg_execution_time:.2f}s"
            }
        return actors_info
    
    def get_directory_for_agents(self) -> Dict[str, Dict[str, Any]]:
        """
        Get agent directory in format suitable for agent collaboration.
        
        Returns a dictionary mapping agent names to their directory entries,
        including capabilities, role, status, and performance metrics.
        
        This format is designed to be passed to agents so they can discover
        and communicate with other agents.
        
        Returns:
            Dict mapping agent names to directory entries with:
            - capabilities: List of capability strings
            - role: Inferred role (implementation, research, validation, etc.)
            - provides: What outputs/services this agent provides
            - accepts_requests_for: What this agent can help with
            - status: "available" | "busy"
            - description: Human-readable description
            - success_rate: Performance metric
            - avg_execution_time: Performance metric
            - confidence_domains: Domain-specific confidence scores (from metadata)
        """
        directory = {}
        
        for name, registration in self._actors.items():
            # Infer role from name and capabilities
            role = self._infer_role(name, registration)
            
            # Extract confidence domains from metadata if available
            confidence_domains = registration.metadata.get("confidence_domains", {})
            
            directory[name] = {
                "capabilities": registration.capabilities,
                "role": role,
                "provides": registration.capabilities,  # Could be enhanced with separate provides field
                "accepts_requests_for": registration.capabilities,  # Same as capabilities for now
                "status": "available",  # Could be enhanced with actual status tracking
                "description": registration.description,
                "success_rate": registration.success_rate,
                "avg_execution_time": registration.avg_execution_time,
                "confidence_domains": confidence_domains,
                "call_count": registration.call_count,
            }
        
        return directory
    
    def _infer_role(self, name: str, registration: ActorRegistration) -> str:
        """
        Infer agent role from name, description, and capabilities.
        
        🔴 A-TEAM FIX: LLM-based inference (no heuristics).
        Falls back to 'general' if LLM is unavailable.
        """
        if DSPY_AVAILABLE and self.lm:
            return self._llm_infer_role(name, registration)
        
        # Explicit uncertainty when LLM unavailable
        logger.warning(f"⚠️ LLM unavailable for role inference of '{name}'; returning 'general'")
        return "general"
    
    def _llm_infer_role(self, name: str, registration: ActorRegistration) -> str:
        """
        Use LLM to infer the agent's role from its name, description, and capabilities.
        
        Returns one of: 'implementation', 'research', 'validation', 'operations',
        'security', 'data_processing', 'scientific_computing', 'general'
        """
        try:
            class RoleInferenceSignature(dspy.Signature):
                """Infer the primary role of an agent from its name, description, and capabilities."""
                agent_name = dspy.InputField(desc="Name of the agent")
                agent_description = dspy.InputField(desc="Description of what the agent does")
                agent_capabilities = dspy.InputField(desc="JSON list of the agent's capabilities")
                
                role = dspy.OutputField(desc="One of: implementation, research, validation, operations, security, data_processing, scientific_computing, general")
            
            infer = dspy.Predict(RoleInferenceSignature)
            
            with dspy.context(lm=self.lm):
                result = infer(
                    agent_name=name,
                    agent_description=registration.description or "No description provided",
                    agent_capabilities=json.dumps(registration.capabilities[:10])  # Limit to avoid overflow
                )
            
            role = str(getattr(result, "role", "general")).strip().lower()
            
            # Validate against known roles
            valid_roles = {
                "implementation", "research", "validation", "operations",
                "security", "data_processing", "scientific_computing", "general"
            }
            if role in valid_roles:
                return role
            
            # LLM might return a close match — find closest
            for valid in valid_roles:
                if valid in role or role in valid:
                    return valid
            
            logger.debug(f"⚠️ LLM returned unknown role '{role}' for '{name}', using 'general'")
            return "general"
            
        except Exception as e:
            logger.warning(f"⚠️ LLM role inference failed for '{name}': {e}")
            return "general"
    
    def find_agent_for_capability(self, capability: str) -> Optional[str]:
        """
        Find an agent that has a specific capability.
        
        Returns the name of the first agent found with the capability,
        or None if no agent has it.
        
        Args:
            capability: The capability to search for
            
        Returns:
            Agent name or None
        """
        actors = self.get_actors_by_capability(capability)
        if actors:
            # Return the one with highest success rate
            best = max(actors, key=lambda a: a.success_rate)
            return best.name
        return None
    
    def __repr__(self) -> str:
        return f"GenericAgentRegistry(actors={len(self._actors)}, capabilities={len(self._capability_index)})"

