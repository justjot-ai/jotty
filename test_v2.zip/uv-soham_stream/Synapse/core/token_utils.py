"""
Token Counting Utilities for ReVal

# ✅ USER REQUIREMENT: Use tokencost library for accurate token counting
- Supports 400+ models (GPT, Claude, Gemini, Llama, etc.)
- Accurate tokenization per model
- Model limits included

REPLACES: tiktoken/transformers approach with unified tokencost
"""

import logging
from typing import Optional, Dict

# Import new TokenCounter (uses tokencost)
from .token_counter import TokenCounter, get_token_counter, count_tokens as _count_tokens, get_model_limits

logger = logging.getLogger(__name__)


def count_tokens_accurate(text: str, model: Optional[str] = None) -> int:
    """
    Count tokens accurately using tokencost library.
    
#     ✅ USER REQUIREMENT: Use tokencost (not tiktoken/transformers)
    - Accurate for 400+ models
    - Unified interface
    - Model-specific tokenization
    
    Args:
        text: Text to count tokens for
        model: Model name (e.g., "gpt-4o", "claude-3-opus", "llama-3-70b")
               If None, uses default model
    
    Returns:
        Exact token count (int)
    
    Examples:
        >>> count_tokens_accurate("Hello world", "gpt-4o")
        2  # Exact count from tokencost
        
        >>> count_tokens_accurate("Hello world", "claude-3-opus")  
        2  # Exact count from tokencost
    """
    if not text:
        return 0
    
    # Use TokenCounter (wraps tokencost)
    return _count_tokens(text, model)


def estimate_tokens(text: str) -> int:
    """
    Quick approximation of token count.
    
    ⚠️  This is approximate! Use count_tokens_accurate() when precision matters.
    
    Args:
        text: Text to estimate tokens for
    
    Returns:
        Estimated token count
    """
    # Still useful for quick estimates without model
    return len(text) // 4 + 1


def smart_truncate(text: str, max_tokens: int = 500, model: Optional[str] = None, 
                   suffix: str = "... [truncated]") -> str:
    """
    Token-aware text truncation — REPLACES all hardcoded [:N] slicing.
    
    🔴 A-TEAM CRITICAL: Never use text[:500] or text[:2000] directly.
    Character slicing can cut in the middle of a word/token/JSON and
    does NOT guarantee token budget compliance. This function:
    
    1. Counts actual tokens (not characters)
    2. Uses binary search for precise boundary
    3. Preserves whole words
    4. Adds truncation indicator
    
    Args:
        text: Text to truncate
        max_tokens: Maximum token budget (default: 500)
        model: Model for accurate tokenization (optional)
        suffix: Appended when text is truncated
    
    Returns:
        Truncated text within token budget
    
    Examples:
        >>> smart_truncate("Long error message...", max_tokens=100)
        "Long error message... [truncated]"
        
        >>> smart_truncate("Short text", max_tokens=100)
        "Short text"  # No truncation needed
    """
    if not text:
        return ""
    
    text = str(text)
    
    # Fast path: text is short enough
    total_tokens = count_tokens_accurate(text, model)
    if total_tokens <= max_tokens:
        return text
    
    # Reserve tokens for suffix
    suffix_tokens = count_tokens_accurate(suffix, model) if suffix else 0
    target_tokens = max_tokens - suffix_tokens
    
    if target_tokens <= 0:
        return suffix
    
    # Binary search for character position that fits target_tokens
    low = 0
    high = len(text)
    best = 0
    
    while low <= high:
        mid = (low + high) // 2
        tokens = count_tokens_accurate(text[:mid], model)
        
        if tokens <= target_tokens:
            best = mid
            low = mid + 1
        else:
            high = mid - 1
    
    # Try to break at a word boundary
    truncated = text[:best]
    last_space = truncated.rfind(' ')
    if last_space > best * 0.8:  # Only break at word if we don't lose too much
        truncated = truncated[:last_space]
    
    if suffix:
        truncated += suffix
    
    return truncated


def get_tokenizer_info(model: str) -> Dict[str, any]:
    """
    Get information about token counting for a model.
    
    Args:
        model: Model name
    
    Returns:
        Dict with tokenizer info:
        - available: bool (is tokencost available?)
        - type: str (always 'tokencost')
        - model: str (model name)
        - limits: dict (max_prompt, max_output)
        - accurate: bool (True if tokencost installed)
    """
    try:
        from tokencost import count_string_tokens
        
        # Get model limits
        limits = get_model_limits(model)
        
        return {
            'available': True,
            'type': 'tokencost',
            'model': model,
            'limits': limits,
            'accurate': True,
            'supported_models': '400+'
        }
    except ImportError:
        return {
            'available': False,
            'type': 'tokencost (not installed)',
            'model': model,
            'limits': {'max_prompt': 100000, 'max_output': 4096},
            'accurate': False,
            'install': 'pip install tokencost>=0.1.26'
        }

