"""
Runtime loader/executor for approved dynamic skills.
"""

from __future__ import annotations

import asyncio
import importlib.util
import inspect
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SkillRuntime:
    """Safe runtime wrapper for executing skill artifacts."""

    def __init__(
        self,
        *,
        default_timeout_seconds: float = 60.0,
        allowed_roots: Optional[List[str]] = None,
    ):
        self.default_timeout_seconds = float(default_timeout_seconds)
        self._module_cache: Dict[str, Any] = {}
        self.allowed_roots = [str(Path(p).expanduser().resolve()) for p in (allowed_roots or [])]

    def _is_allowed_module_path(self, module_path: str) -> bool:
        if not self.allowed_roots:
            return True
        mp = str(Path(module_path).expanduser().resolve())
        for root in self.allowed_roots:
            if mp.startswith(root + "/") or mp == root:
                return True
        return False

    async def load(self, module_path: str) -> Any:
        path = str(Path(module_path).expanduser().resolve())
        if not self._is_allowed_module_path(path):
            raise RuntimeError(f"Module path not allowed by runtime policy: {path}")
        if path in self._module_cache:
            return self._module_cache[path]

        def _do_import() -> Any:
            spec = importlib.util.spec_from_file_location(f"synapse_skill_{abs(hash(path))}", path)
            if not spec or not spec.loader:
                raise RuntimeError(f"Unable to load module spec for: {path}")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)  # type: ignore[attr-defined]
            return module

        mod = await asyncio.to_thread(_do_import)
        self._module_cache[path] = mod
        return mod

    async def execute(
        self,
        *,
        module_path: str,
        entrypoint: str = "run",
        payload: Optional[Dict[str, Any]] = None,
        timeout_seconds: Optional[float] = None,
        policy: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload = payload or {}
        timeout = float(timeout_seconds or self.default_timeout_seconds)
        policy = policy or {}
        required_profile = str(policy.get("profile", "read_only")).strip() or "read_only"

        # Keep runtime policy generic and config-driven:
        # read_only: no unsafe payload keys, no shell-like command keys
        # net_limited/exec_limited/full_guarded are reserved profiles for future enforcement layers.
        if required_profile == "read_only":
            forbidden_keys = {"command", "shell", "script", "bash", "zsh"}
            lower_keys = {str(k).lower() for k in payload.keys()}
            if forbidden_keys.intersection(lower_keys):
                return {
                    "success": False,
                    "error": "Payload violates read_only runtime policy",
                }

        mod = await self.load(module_path)
        fn = getattr(mod, entrypoint, None)
        if fn is None:
            return {"success": False, "error": f"Entrypoint not found: {entrypoint}"}

        try:
            if inspect.iscoroutinefunction(fn):
                result = await asyncio.wait_for(fn(**payload), timeout=timeout)
            else:
                result = await asyncio.wait_for(asyncio.to_thread(fn, **payload), timeout=timeout)
            return {"success": True, "result": result}
        except asyncio.TimeoutError:
            return {"success": False, "error": f"Skill execution timed out after {timeout}s"}
        except Exception as exc:
            logger.warning(f"Skill execution failed ({module_path}:{entrypoint}): {exc}")
            return {"success": False, "error": str(exc)}

