"""
DynamicTaskPlanner - LLM-based Goal Decomposition
==================================================

🎯 A-TEAM FIX: Implements TRUE recursive language model task decomposition.

The Problem:
- Conductor._initialize_todo_from_goal() creates FLAT tasks: "Execute X pipeline"
- This wastes ~10 bits of semantic information per task (Shannon analysis)
- MarkovianTODO has hierarchical structures but receives generic input

The Solution:
- DynamicTaskPlanner uses LLM to decompose goals into SEMANTIC subtasks
- Each subtask has: specific description, inputs_needed, outputs_produced
- Dependencies are explicit data flows, not just sequential ordering

Research Foundations:
- Recursive Language Models (Welleck et al., 2019)
- Hierarchical RL decomposition (Sutton MAXQ, Feudal RL)
- Information-theoretic task specification (Shannon)

Usage:
    planner = DynamicTaskPlanner()
    plan = await planner.decompose_goal(
        goal="Find git changes and merge to master",
        available_agents=[{"name": "CodeMaster", "capabilities": ["git", "coding"]}],
        context="Working on feature branch"
    )
    # Returns structured plan with semantic task descriptions

A-Team Approval: 2026-01-12
"""

import logging
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, AsyncGenerator

logger = logging.getLogger(__name__)

# Try DSPy for LLM-based decomposition
try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False
    logger.warning("DSPy not available - DynamicTaskPlanner will return explicit uncertainty")


# =============================================================================
# TASK DECOMPOSITION SIGNATURE
# =============================================================================

if DSPY_AVAILABLE:
    class TaskDecompositionSignature(dspy.Signature):
        """
        Decompose a high-level goal into fine-grained, semantic subtasks.
        
        🔬 A-TEAM REQUIREMENT: This is NOT about listing agents.
        It's about breaking the GOAL into atomic, actionable steps.
        
        🛠️ CRITICAL: You are operating in ReAct mode. You MUST follow this format:
        
        Step 1: Set next_thought = "I need to research algorithms for [problem]. Let me search..."
        Step 2: Set next_tool_name = "web_search"
        Step 3: Set next_tool_args = {"query": "your search query here"}
        
        After the tool returns, use the observation in your next thought, then call more tools.
        Repeat until you have enough information, then set next_tool_name = "finish" and provide reasoning and task_plan.
        
        You have access to web_search and scrape_website tools. 
        You MUST use these tools to research algorithms, libraries, and edge cases 
        BEFORE decomposing the goal. Call web_search() multiple times during your reasoning 
        to gather information, then use that research to create optimal task decomposition.
        
        ⚠️ DO NOT assume tools are unavailable - ALWAYS attempt to call them even if you 
        think API credentials might be missing. The tools will handle errors gracefully 
        and return error messages if needed. Your job is to CALL the tools, not to 
        preemptively decide they won't work.
        
        EXAMPLE FORMAT:
        next_thought: "I need to research chess board recognition algorithms"
        next_tool_name: "web_search"
        next_tool_args: {"query": "chess board recognition algorithms python"}
        
        DECOMPOSITION PRINCIPLES:
        1. RESEARCH FIRST: Use web_search() to research algorithms, libraries, and best practices
        2. ATOMICITY: Each subtask = single coherent action
        3. CLARITY: Description specifies WHAT to do, not just WHO does it
        4. DEPENDENCIES: Explicit data flow between subtasks
        5. PARALLELISM: Independent subtasks should not have dependencies
        
        BAD EXAMPLE (what we're fixing):
            task_id: "CodeMaster_main"
            description: "Execute CodeMaster pipeline"
            
        GOOD EXAMPLE (what we want):
            task_id: "resolve_date_reference"
            description: "Convert 'yesterday' to concrete date 2026-01-11 using system clock"
            outputs_produced: ["resolved_date", "date_format"]
        """
        
        goal = dspy.InputField(
            desc="The high-level goal to decompose (e.g., 'Find lost git changes and merge to master')"
        )
        available_agents = dspy.InputField(
            desc="JSON list of agents with their names and capabilities"
        )
        context = dspy.InputField(
            desc="Additional context: current state, constraints, user preferences. IMPORTANT: This includes system instructions about using web_search() and scrape_website() tools - you MUST use these tools during decomposition!"
        )
        
        reasoning = dspy.OutputField(
            desc="Step-by-step analysis of how to decompose this goal. MUST include web_search() calls to research algorithms, libraries, and edge cases before creating the task plan. Show your research findings from web searches."
        )
        task_plan = dspy.OutputField(
            desc="""JSON object with 'tasks' array. Each task has:
            - task_id: semantic identifier (e.g., 'extract_commit_history', NOT 'agent_main')
            - description: SPECIFIC action (e.g., 'Run git reflog to find dangling commits')
            - agent: (OPTIONAL) which agent executes this (from available_agents). If omitted, will be selected dynamically at execution time.
            - depends_on: list of task_ids this depends on ([] if none)
            - inputs_needed: what data from previous tasks (e.g., ['branch_name', 'commit_range'])
            - outputs_produced: what this task produces (e.g., ['lost_commits', 'reflog_output'])
            
            🔬 A-TEAM NOTE: You CAN provide agent suggestions, but they are NOT required.
            Dynamic agent selection (EnhancedAgenticAgentSelector) will choose the best agent
            at execution time using Q-learning based on task features and historical performance.
            
            Example:
            {
                "tasks": [
                    {
                        "task_id": "find_current_branch",
                        "description": "Get current git branch name using 'git branch --show-current'",
                        "depends_on": [],
                        "inputs_needed": [],
                        "outputs_produced": ["current_branch"]
                    },
                    {
                        "task_id": "find_lost_commits",
                        "description": "Run git reflog to identify dangling commits not in current branch", 
                        "description": "Search git reflog for commits not in current branch history",
                        "depends_on": ["find_current_branch"],
                        "inputs_needed": ["current_branch"],
                        "outputs_produced": ["lost_commit_shas", "reflog_analysis"]
                    }
                ]
            }"""
        )

    class JSONRepairSignature(dspy.Signature):
        """Repair malformed JSON into valid JSON."""
        input_text = dspy.InputField(desc="Malformed JSON or mixed text")
        schema_hint = dspy.InputField(desc="Expected schema description")
        
        repaired_json = dspy.OutputField(desc="Valid JSON only, no markdown")

    class PlanRepairSignature(dspy.Signature):
        """Repair a task plan with validation errors."""
        goal = dspy.InputField(desc="Original goal")
        available_agents = dspy.InputField(desc="JSON list of available agents")
        plan_json = dspy.InputField(desc="Current plan JSON")
        errors = dspy.InputField(desc="Validation errors to fix")
        
        repaired_plan = dspy.OutputField(desc="Fixed plan JSON")


# =============================================================================
# TASK PLAN DATA STRUCTURES
# =============================================================================

@dataclass
class TaskSpec:
    """
    Specification for a single decomposed task.
    
    A-TEAM FIX: 'agent' is now optional (defaults to None).
    Agent selection should be done by EnhancedAgenticAgentSelector at execution time,
    not during task decomposition.
    """
    task_id: str
    description: str
    agent: Optional[str] = None  # A-TEAM: Now optional, assigned at execution time
    depends_on: List[str] = field(default_factory=list)
    inputs_needed: List[str] = field(default_factory=list)
    outputs_produced: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            'task_id': self.task_id,
            'description': self.description,
            'depends_on': self.depends_on,
            'inputs_needed': self.inputs_needed,
            'outputs_produced': self.outputs_produced
        }
        # A-TEAM: Only include agent if it's assigned
        if self.agent is not None:
            result['agent'] = self.agent
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskSpec':
        return cls(
            task_id=data.get('task_id', 'unknown'),
            description=data.get('description', ''),
            agent=data.get('agent', None),  # A-TEAM: Defaults to None if not provided
            depends_on=data.get('depends_on', []),
            inputs_needed=data.get('inputs_needed', []),
            outputs_produced=data.get('outputs_produced', [])
        )


@dataclass
class TaskPlan:
    """Complete task plan from LLM decomposition."""
    tasks: List[TaskSpec] = field(default_factory=list)
    reasoning: str = ""
    decomposition_method: str = "llm"  # 'llm' or 'fallback'
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'tasks': [t.to_dict() for t in self.tasks],
            'reasoning': self.reasoning,
            'decomposition_method': self.decomposition_method
        }
    
    def validate(self) -> List[str]:
        """
        Validate the plan for consistency.
        
        Returns list of validation errors (empty if valid).
        """
        errors = []
        task_ids = {t.task_id for t in self.tasks}
        
        for task in self.tasks:
            # Check dependencies exist
            for dep in task.depends_on:
                if dep not in task_ids:
                    errors.append(f"Task '{task.task_id}' depends on unknown task '{dep}'")
            
            # Check for self-dependency
            if task.task_id in task.depends_on:
                errors.append(f"Task '{task.task_id}' depends on itself")
        
        # Check for cycles (simple DFS)
        if not errors:
            cycle_errors = self._detect_cycles(task_ids)
            errors.extend(cycle_errors)
        
        return errors
    
    def _detect_cycles(self, task_ids: set) -> List[str]:
        """Detect dependency cycles using DFS."""
        errors = []
        visited = set()
        rec_stack = set()
        
        task_map = {t.task_id: t for t in self.tasks}
        
        def dfs(task_id: str, path: List[str]) -> bool:
            visited.add(task_id)
            rec_stack.add(task_id)
            
            task = task_map.get(task_id)
            if task:
                for dep in task.depends_on:
                    if dep not in visited:
                        if dfs(dep, path + [task_id]):
                            return True
                    elif dep in rec_stack:
                        cycle_path = path + [task_id, dep]
                        errors.append(f"Dependency cycle detected: {' -> '.join(cycle_path)}")
                        return True
            
            rec_stack.remove(task_id)
            return False
        
        for task_id in task_ids:
            if task_id not in visited:
                dfs(task_id, [])
        
        return errors
    
    def get_topological_order(self) -> List[str]:
        """
        Get tasks in topological order (respecting dependencies).
        
        Returns task_ids in execution order.
        """
        task_map = {t.task_id: t for t in self.tasks}
        in_degree = {t.task_id: 0 for t in self.tasks}
        
        # Calculate in-degrees
        for task in self.tasks:
            for dep in task.depends_on:
                if dep in in_degree:
                    in_degree[task.task_id] = in_degree.get(task.task_id, 0) + 1
        
        # Kahn's algorithm
        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        result = []
        
        while queue:
            # Sort by task_id for deterministic ordering
            queue.sort()
            current = queue.pop(0)
            result.append(current)
            
            # Reduce in-degree of dependents
            for task in self.tasks:
                if current in task.depends_on:
                    in_degree[task.task_id] -= 1
                    if in_degree[task.task_id] == 0:
                        queue.append(task.task_id)
        
        return result


# =============================================================================
# DYNAMIC TASK PLANNER
# =============================================================================

class DynamicTaskPlanner:
    """
    🔬 LLM-based goal decomposition for MarkovianTODO.
    
    This is the MISSING PIECE that connects:
    - Goal understanding (what user wants)
    - Agent selection (who can do it)
    - Task decomposition (how to break it down)
    - TODO initialization (structured execution plan)
    
    Key difference from AgenticAgentSelector:
    - AgenticAgentSelector: Selects WHICH agents to use
    - DynamicTaskPlanner: Decomposes WHAT each agent should do
    
    Usage:
        planner = DynamicTaskPlanner()
        plan = await planner.decompose_goal(
            goal="Analyze sales data and create visualization",
            available_agents=[
                {"name": "DataMind", "capabilities": ["ML", "ETL", "analysis"]},
                {"name": "CodeMaster", "capabilities": ["coding", "visualization"]}
            ],
            context="CSV file at /data/sales.csv"
        )
        
        # Feed plan to MarkovianTODO
        todo.initialize_from_plan(plan.to_dict())
    """
    
    def __init__(self, max_tasks_per_agent: int = 10, tools: List[Any] = None, system_prompt_path: Optional[str] = None):
        """
        Initialize the planner.
        
        Args:
            max_tasks_per_agent: Maximum subtasks per agent (prevents LLM over-decomposition)
            tools: Optional list of tools for ReAct agent (e.g., web_search, web_search_and_crawl)
                  If provided, uses ReAct instead of ChainOfThought for better exploration
            system_prompt_path: Optional path to markdown file with system prompt/instructions
        """
        logger.info(f"🔧 DynamicTaskPlanner.__init__ called | tools={tools} | tools_type={type(tools)} | tools_is_none={tools is None}")
        self.max_tasks_per_agent = max_tasks_per_agent
        self.tools = tools if tools is not None else []
        logger.info(f"🔧 DynamicTaskPlanner.__init__ | self.tools={self.tools} | len={len(self.tools)} | tools_is_none={self.tools is None}")
        if self.tools:
            for i, tool in enumerate(self.tools):
                logger.info(f"🔧 DynamicTaskPlanner tool[{i}]: {tool} | type={type(tool)} | name={getattr(tool, '__name__', 'NO_NAME')}")
        self.system_prompt_path = system_prompt_path
        
        # Load system prompt if provided
        self.system_prompt = None
        if system_prompt_path:
            try:
                from pathlib import Path
                prompt_path = Path(system_prompt_path)
                if prompt_path.exists():
                    self.system_prompt = prompt_path.read_text()
                    logger.info(f"📄 Loaded task planner system prompt from {system_prompt_path}")
                else:
                    logger.warning(f"⚠️ Task planner prompt file not found: {system_prompt_path}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to load task planner prompt: {e}")
        
        if DSPY_AVAILABLE:
            # Use TaskDecompositionSignature - system prompt will be prepended to context
            signature = TaskDecompositionSignature
            
            if self.tools and len(self.tools) > 0:
                # Use ReAct agent with tools for better goal understanding
                # Tools allow planner to research domain/context before decomposing
                logger.info(f"🔧 Creating ReAct agent with {len(self.tools)} tools")
                logger.info(f"🔧 Tools before ReAct creation: {self.tools}")
                for i, tool in enumerate(self.tools):
                    logger.info(f"🔧 Passing tool[{i}] to ReAct: {tool} | type={type(tool)} | name={getattr(tool, '__name__', 'NO_NAME')}")
                self.decomposer = dspy.ReAct(
                    signature,
                    tools=self.tools,
                    max_iters=10  # Reasonable limit for task decomposition
                )
                # Verify tools were registered in ReAct
                if hasattr(self.decomposer, 'tools'):
                    logger.info(f"🔧 ReAct agent created | decomposer.tools={self.decomposer.tools} | len={len(self.decomposer.tools) if self.decomposer.tools else 0}")
                    if self.decomposer.tools:
                        for i, tool in enumerate(self.decomposer.tools):
                            logger.info(f"🔧 ReAct tool[{i}]: {tool} | type={type(tool)}")
                    else:
                        logger.warning(f"⚠️ ReAct agent created but tools list is empty or None!")
                else:
                    logger.warning(f"⚠️ ReAct agent created but has no 'tools' attribute!")
                tool_names = [getattr(t, '__name__', str(t)) for t in self.tools]
                logger.info(f"🎯 DynamicTaskPlanner initialized with ReAct agent | "
                          f"tools={len(self.tools)} ({', '.join(tool_names[:3])}{'...' if len(tool_names) > 3 else ''}) | "
                          f"max_tasks_per_agent={max_tasks_per_agent} | "
                          f"system_prompt={'loaded' if self.system_prompt else 'none'}")
            else:
                # Fallback to ChainOfThought if no tools
                self.decomposer = dspy.ChainOfThought(signature)
                logger.info(f"🎯 DynamicTaskPlanner initialized with ChainOfThought | "
                          f"max_tasks_per_agent={max_tasks_per_agent} | "
                          f"tools=None (pure LLM decomposition) | "
                          f"system_prompt={'loaded' if self.system_prompt else 'none'}")
        else:
            self.decomposer = None
            logger.warning("⚠️ DSPy not available - DynamicTaskPlanner cannot decompose goals")
    
    async def decompose_goal_stream(
        self,
        goal: str,
        available_agents: List[Dict[str, Any]],
        context: str = ""
    ) -> AsyncGenerator[Dict[str, Any], TaskPlan]:
        """
        Decompose a goal into semantic subtasks with event streaming.
        
        Args:
            goal: High-level goal to decompose
            available_agents: List of dicts with 'name' and 'capabilities'
            context: Additional context (constraints, current state, etc.)
        
        Yields:
            Event dictionaries with module and conversational message
        Returns:
            TaskPlan with semantic task decomposition
        """
        logger.info(f"🔧 decompose_goal (async) called | decomposer={self.decomposer} | decomposer_is_none={self.decomposer is None}")
        yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I am starting to decompose the goal: {goal[:100] if len(goal) > 100 else goal}"}
        logger.info(f"🔧 decompose_goal | self.tools={self.tools} | len={len(self.tools) if self.tools else 0}")
        if hasattr(self.decomposer, 'tools'):
            logger.info(f"🔧 decompose_goal | decomposer.tools={self.decomposer.tools} | len={len(self.decomposer.tools) if self.decomposer.tools else 0}")
        if not self.decomposer:
            logger.warning("DSPy not available - cannot decompose goal")
            yield {"module": "Synapse.core.dynamic_task_planner", "message": "I noticed DSPy is not available, cannot decompose goal"}
            result = self._explicit_uncertainty_plan("LLM unavailable for decomposition")
            yield {"type": "result", "result": result, "module": "Synapse.core.dynamic_task_planner", "message": "I am returning an uncertainty plan"}
            return
        
        try:
            # Enhance context with system prompt if available
            enhanced_context = context or "No additional context"
            if self.system_prompt:
                # Prepend system prompt to context so LLM sees instructions
                enhanced_context = f"{self.system_prompt}\n\n---\n\nAdditional Context:\n{enhanced_context}"
                logger.info(f"🔧 decompose_goal | System prompt prepended to context | prompt_length={len(self.system_prompt)}")
                yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I am enhancing the context with a system prompt (length: {len(self.system_prompt)})"}
            
            # 🔴 A-TEAM DEBATE RESOLUTION (2026-02-08):
            # Inject VLM CAPABILITY AWARENESS into the decomposition context.
            # This is NOT tool signatures — it's meta-capability knowledge.
            # The planner learns that visual verification is available to all agents
            # and should plan verification subtasks after creative/visual outputs.
            enhanced_context += (
                "\n\n---\n\n"
                "VISUAL VERIFICATION CAPABILITY:\n"
                "All agents have access to VLM (Vision Language Model) tools for visual "
                "state extraction and quality verification. After any task that produces "
                "a file, visual output, UI change, or creative artifact, you SHOULD plan "
                "a follow-up verification subtask where the SAME agent visually inspects "
                "its output and confirms quality. This is a generic capability — every "
                "agent can visually verify its own work. Verification subtasks should "
                "depend on the creation task and describe what to check relative to the "
                "goal (e.g., 'Visually verify output quality, checking alignment, contrast, "
                "readability, and goal compliance').\n"
            )
            
            logger.info(f"🔧 decompose_goal | Calling decomposer with goal length={len(goal)} | context_length={len(enhanced_context)}")
            logger.info(f"🔧 decompose_goal | Available agents: {[a.get('name', 'unknown') for a in available_agents]}")
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I am calling the LLM decomposer with goal length {len(goal)} and context length {len(enhanced_context)}"}
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I have {len(available_agents)} available agents: {[a.get('name', 'unknown') for a in available_agents]}"}
            # Call LLM for decomposition
            result = self.decomposer(
                goal=goal,
                available_agents=json.dumps(available_agents, indent=2),
                context=enhanced_context
            )
            logger.info(f"🔧 decompose_goal | Decomposer returned result | result_type={type(result)}")
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I received a response from the decomposer, parsing it now"}
            
            # Parse the task plan
            plan = self._parse_llm_response(result, available_agents)
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I parsed the LLM response into a task plan with {len(plan.tasks)} tasks"}
            
            # Validate
            errors = plan.validate()
            if errors:
                logger.warning(f"Plan validation errors: {errors}")
                yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I found validation errors in the plan: {errors}, attempting to fix them"}
                # Try to fix with LLM (no heuristics)
                plan = self._fix_plan_errors(plan, errors, goal, available_agents)
                if plan.validate():
                    logger.warning("Could not fix plan with LLM")
                    yield {"module": "Synapse.core.dynamic_task_planner", "message": "I could not fix the plan validation errors, returning uncertainty plan"}
                    result_plan = self._explicit_uncertainty_plan("Plan validation failed after LLM repair")
                    yield {"type": "result", "result": result_plan}
                    return
                yield {"module": "Synapse.core.dynamic_task_planner", "message": "I successfully fixed the plan validation errors"}
            
            # Enforce max tasks per agent
            plan = self._enforce_task_limits(plan)
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I enforced task limits, final plan has {len(plan.tasks)} tasks"}
            
            logger.info(f"✅ Decomposed goal into {len(plan.tasks)} tasks")
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I successfully decomposed the goal into {len(plan.tasks)} tasks"}
            yield {"type": "result", "result": plan}
            return
            
        except Exception as e:
            logger.error(f"LLM decomposition failed: {e}")
            yield {"module": "Synapse.core.dynamic_task_planner", "message": f"I encountered an error during decomposition: {e}"}
            result_plan = self._explicit_uncertainty_plan(f"LLM decomposition error: {e}")
            yield {"type": "result", "result": result_plan}
            return
    
    def _repair_json_with_llm(self, json_str: str) -> Optional[str]:
        """
        Repair malformed JSON using LLM (no regex/heuristics).
        
        Returns repaired JSON string or None.
        """
        if not (DSPY_AVAILABLE and self.decomposer):
            return None
        
        try:
            repair = dspy.ChainOfThought(JSONRepairSignature)
            result = repair(
                input_text=json_str,
                schema_hint="{'tasks': [ {task_id, agent, description, depends_on, inputs_needed, outputs_produced} ]}"
            )
            return str(getattr(result, "repaired_json", "")).strip()
        except Exception as e:
            logger.warning(f"LLM JSON repair failed: {e}")
            return None

    def _explicit_uncertainty_plan(self, reason: str) -> TaskPlan:
        """Return an explicit uncertainty plan (no heuristic fallback)."""
        return TaskPlan(
            tasks=[],
            reasoning=f"Explicit uncertainty: {reason}",
            decomposition_method="unavailable"
        )
    
    def _parse_llm_response(
        self,
        result: Any,
        available_agents: List[Dict[str, Any]]
    ) -> TaskPlan:
        """Parse LLM response into TaskPlan."""
        reasoning = getattr(result, 'reasoning', '')
        task_plan_str = getattr(result, 'task_plan', '{}')
        
        # Parse JSON with LLM repair (no heuristics)
        plan_data = {'tasks': []}
        try:
            plan_data = json.loads(task_plan_str)
        except (json.JSONDecodeError, ValueError, SyntaxError) as e:
            logger.warning(f"Failed to parse task plan JSON: {e}")
            repaired = self._repair_json_with_llm(task_plan_str)
            if repaired:
                try:
                    plan_data = json.loads(repaired)
                except Exception as repair_error:
                    logger.warning(f"Repaired JSON still invalid: {repair_error}")
                    return TaskPlan(tasks=[], reasoning="Invalid plan JSON", decomposition_method="unavailable")
            else:
                return TaskPlan(tasks=[], reasoning="LLM JSON repair unavailable", decomposition_method="unavailable")
        
        # Extract tasks
        tasks = []
        agent_names = {a['name'] for a in available_agents}
        
        for task_data in plan_data.get('tasks', []):
            task = TaskSpec.from_dict(task_data)
            
            # Validate agent exists
            if task.agent not in agent_names:
                # 🔴 A-TEAM FIX: Use semantic matching instead of silently defaulting
                # to first agent (which could assign a browser task to PresentationBuilder)
                matched = False
                task_agent_lower = task.agent.lower().replace('_', '').replace('-', '')
                for agent_info in available_agents:
                    agent_name_lower = agent_info['name'].lower().replace('_', '').replace('-', '')
                    # Try partial/fuzzy match (e.g., "PresentationBuilder" ↔ "presentation_builder")
                    if task_agent_lower in agent_name_lower or agent_name_lower in task_agent_lower:
                        logger.info(f"  🔄 Fuzzy matched agent '{task.agent}' → '{agent_info['name']}'")
                        task.agent = agent_info['name']
                        matched = True
                        break
                if not matched:
                    # Keep the LLM-assigned name — EnhancedAgenticAgentSelector will handle it
                    # downstream with full capability matching. Don't silently default.
                    logger.warning(f"  ⚠️  Agent '{task.agent}' not in available agents {list(agent_names)}, "
                                 f"keeping as-is for downstream resolution")
            
            tasks.append(task)
        
        return TaskPlan(
            tasks=tasks,
            reasoning=reasoning,
            decomposition_method='llm'
        )
    
    def _fix_plan_errors(
        self,
        plan: TaskPlan,
        errors: List[str],
        goal: str,
        available_agents: List[Dict[str, Any]]
    ) -> TaskPlan:
        """Attempt to fix plan validation errors using LLM (no heuristics)."""
        if not (DSPY_AVAILABLE and self.decomposer):
            return self._explicit_uncertainty_plan("LLM unavailable for plan repair")
        
        try:
            repair = dspy.ChainOfThought(PlanRepairSignature)
            result = repair(
                goal=goal,
                available_agents=json.dumps(available_agents, default=str),
                plan_json=json.dumps(plan.to_dict(), default=str),
                errors=json.dumps(errors)
            )
            repaired = self._repair_json_with_llm(str(getattr(result, "repaired_plan", "")))
            if repaired:
                repaired_data = json.loads(repaired)
                repaired_tasks = [TaskSpec.from_dict(t) for t in repaired_data.get("tasks", [])]
                return TaskPlan(
                    tasks=repaired_tasks,
                    reasoning=str(getattr(result, "reasoning", "")),
                    decomposition_method="llm"
                )
        except Exception as e:
            logger.warning(f"LLM plan repair failed: {e}")
        
        return self._explicit_uncertainty_plan("LLM plan repair failed")
    
    def _enforce_task_limits(self, plan: TaskPlan) -> TaskPlan:
        """Enforce maximum tasks per agent."""
        from collections import defaultdict
        
        agent_task_counts = defaultdict(int)
        limited_tasks = []
        
        for task in plan.tasks:
            if agent_task_counts[task.agent] < self.max_tasks_per_agent:
                limited_tasks.append(task)
                agent_task_counts[task.agent] += 1
            else:
                logger.warning(f"Dropped task '{task.task_id}' - agent '{task.agent}' at max capacity")
        
        return TaskPlan(
            tasks=limited_tasks,
            reasoning=plan.reasoning,
            decomposition_method=plan.decomposition_method
        )
    
    # NOTE: Heuristic fallback decomposition removed (A-Team requirement)
    
    async def decompose_goal(
        self,
        goal: str,
        available_agents: List[Dict[str, Any]],
        context: str = ""
    ) -> TaskPlan:
        """
        Async wrapper for decompose_goal_stream that extracts the final result.
        """
        result = None
        async for event in self.decompose_goal_stream(goal, available_agents, context):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else self._explicit_uncertainty_plan("No result from decomposition")
    
    def decompose_goal_sync(
        self,
        goal: str,
        available_agents: List[Dict[str, Any]],
        context: str = ""
    ) -> TaskPlan:
        """
        Synchronous version of decompose_goal.
        
        For use in non-async contexts.
        """
        import asyncio
        
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # We're already in an async context, can't use run()
                # Fall back to sync decomposition
                return self._sync_decompose(goal, available_agents, context)
            else:
                return loop.run_until_complete(
                    self.decompose_goal(goal, available_agents, context)
                )
        except RuntimeError:
            # No event loop
            return asyncio.run(
                self.decompose_goal(goal, available_agents, context)
            )
    
    def _sync_decompose(
        self,
        goal: str,
        available_agents: List[Dict[str, Any]],
        context: str = ""
    ) -> TaskPlan:
        """Synchronous decomposition without async."""
        logger.info(f"🔧 _sync_decompose called | decomposer={self.decomposer} | decomposer_is_none={self.decomposer is None}")
        logger.info(f"🔧 _sync_decompose | self.tools={self.tools} | len={len(self.tools) if self.tools else 0}")
        if hasattr(self.decomposer, 'tools'):
            logger.info(f"🔧 _sync_decompose | decomposer.tools={self.decomposer.tools} | len={len(self.decomposer.tools) if self.decomposer.tools else 0}")
        if not self.decomposer:
            return self._explicit_uncertainty_plan("LLM unavailable for decomposition (sync)")
        
        try:
            # Enhance context with system prompt if available (same as async version)
            enhanced_context = context or "No additional context"
            if self.system_prompt:
                # Prepend system prompt to context so LLM sees instructions
                enhanced_context = f"{self.system_prompt}\n\n---\n\nAdditional Context:\n{enhanced_context}"
                logger.info(f"🔧 _sync_decompose | System prompt prepended to context | prompt_length={len(self.system_prompt)}")
            
            # 🔴 A-TEAM DEBATE RESOLUTION: Inject VLM capability awareness (same as async)
            enhanced_context += (
                "\n\n---\n\n"
                "VISUAL VERIFICATION CAPABILITY:\n"
                "All agents have access to VLM (Vision Language Model) tools for visual "
                "state extraction and quality verification. After any task that produces "
                "a file, visual output, UI change, or creative artifact, you SHOULD plan "
                "a follow-up verification subtask where the SAME agent visually inspects "
                "its output and confirms quality. This is a generic capability — every "
                "agent can visually verify its own work. Verification subtasks should "
                "depend on the creation task and describe what to check relative to the "
                "goal.\n"
            )
            
            logger.info(f"🔧 _sync_decompose | Calling decomposer with goal length={len(goal)} | context_length={len(enhanced_context)}")
            logger.info(f"🔧 _sync_decompose | Available agents: {[a.get('name', 'unknown') for a in available_agents]}")
            try:
                # ⏱️ AGGRESSIVE TIMING: LLM call for task decomposition
                llm_call_start = time.time()
                logger.info(f"⏱️ [LLM CALL START] DynamicTaskPlanner._sync_decompose | goal_length={len(goal)} | context_length={len(enhanced_context)} | agents_count={len(available_agents)}")
                
                result = self.decomposer(
                    goal=goal,
                    available_agents=json.dumps(available_agents, indent=2),
                    context=enhanced_context
                )
                
                llm_call_duration = time.time() - llm_call_start
                logger.info(f"⏱️ [LLM CALL COMPLETE] DynamicTaskPlanner._sync_decompose | duration={llm_call_duration:.3f}s | result_type={type(result)}")
                
                # Extract token usage if available
                if hasattr(result, '_completions') and result._completions:
                    for i, completion in enumerate(result._completions):
                        if hasattr(completion, 'usage'):
                            usage = completion.usage
                            logger.info(f"⏱️ [LLM TOKENS] completion[{i}] | input_tokens={getattr(usage, 'prompt_tokens', 'N/A')} | output_tokens={getattr(usage, 'completion_tokens', 'N/A')} | total_tokens={getattr(usage, 'total_tokens', 'N/A')}")
                
                logger.info(f"🔧 _sync_decompose | Decomposer returned result | result_type={type(result)}")
                if hasattr(result, '__dict__'):
                    logger.info(f"🔧 _sync_decompose | Result attributes: {list(result.__dict__.keys())}")
            except Exception as e:
                error_msg = str(e)
                logger.error(f"🔧 _sync_decompose | Decomposer call failed | error={error_msg}")
                # Try to extract more details from the error
                if "LM Response" in error_msg or "Adapter" in error_msg:
                    logger.error(f"🔧 _sync_decompose | This appears to be a DSPy parsing error - LLM may have returned empty or malformed response")
                    logger.error(f"🔧 _sync_decompose | Error details: {error_msg[:500]}")
                raise
            
            # ⏱️ AGGRESSIVE TIMING: Parse and validate plan
            parse_start = time.time()
            plan = self._parse_llm_response(result, available_agents)
            parse_duration = time.time() - parse_start
            logger.info(f"⏱️ [PARSE PLAN] DynamicTaskPlanner._sync_decompose | parse_duration={parse_duration:.3f}s | tasks_count={len(plan.tasks) if plan and plan.tasks else 0}")
            
            validation_start = time.time()
            errors = plan.validate()
            validation_duration = time.time() - validation_start
            logger.info(f"⏱️ [VALIDATE PLAN] DynamicTaskPlanner._sync_decompose | validation_duration={validation_duration:.3f}s | errors_count={len(errors) if errors else 0}")
            
            if errors:
                fix_start = time.time()
                plan = self._fix_plan_errors(plan, errors, goal, available_agents)
                fix_duration = time.time() - fix_start
                logger.info(f"⏱️ [FIX PLAN ERRORS] DynamicTaskPlanner._sync_decompose | fix_duration={fix_duration:.3f}s")
                if plan.validate():
                    return self._explicit_uncertainty_plan("Plan validation failed after LLM repair (sync)")
            
            enforce_start = time.time()
            final_plan = self._enforce_task_limits(plan)
            enforce_duration = time.time() - enforce_start
            logger.info(f"⏱️ [ENFORCE LIMITS] DynamicTaskPlanner._sync_decompose | enforce_duration={enforce_duration:.3f}s")
            return final_plan
            
        except Exception as e:
            logger.error(f"Sync decomposition failed: {e}")
            return self._explicit_uncertainty_plan(f"Sync decomposition error: {e}")


# =============================================================================
# GENERIC TASK DECOMPOSITION PROMPT (for reference/debugging)
# =============================================================================

GENERIC_TASK_DECOMPOSITION_PROMPT = """
You are a Task Decomposition Agent implementing a RECURSIVE LANGUAGE MODEL pattern.

YOUR ROLE:
Given a high-level goal, decompose it into fine-grained subtasks that can be:
1. Assigned to specific agents
2. Executed with clear dependencies
3. Tracked for progress and credit assignment

DECOMPOSITION PRINCIPLES:
1. ATOMICITY: Each subtask should be a single coherent action
2. CLARITY: Description should specify WHAT to do, not just WHO does it
3. DEPENDENCIES: Explicit data flow between subtasks
4. PARALLELISM: Independent subtasks can run in parallel
5. VERIFICATION: Include visual-inspection / QC subtasks AFTER every creative output

BAD EXAMPLE:
- task_id: "agent1_main"
- description: "Execute agent1 pipeline"  ← Too vague! No semantic content!

GOOD EXAMPLE:
- task_id: "parse_date_reference"
- description: "Convert 'yesterday' to concrete date 2026-01-11 using system clock"
- agent: "CodeMaster"
- inputs_needed: ["raw_query"]
- outputs_produced: ["resolved_date", "date_format"]

VISUAL QC EXAMPLE (for any creative / file-producing agent):
After generating output (presentation, image, front-end), ALWAYS add a QC subtask:
- task_id: "visual_qc_slides"
- description: "Use inspect_pptx_slides() to visually verify slide contrast, alignment, overlap, and overall quality. Fix any issues found."
- agent: "PresentationBuilderAgent"
- depends_on: ["generate_slides"]
- inputs_needed: ["output_pptx_path"]
- outputs_produced: ["qc_report", "fixed_pptx_path"]

TASK OUTPUT FORMAT:
{
    "tasks": [
        {
            "task_id": "unique_semantic_id",
            "agent": "ResponsibleAgent",
            "description": "Specific action to perform",
            "depends_on": ["prerequisite_task_ids"],
            "inputs_needed": ["data from previous tasks"],
            "outputs_produced": ["data for downstream tasks"]
        }
    ]
}

NAMING CONVENTIONS:
- task_id: snake_case, semantic (e.g., "extract_git_history", NOT "CodeMaster_main")
- agent: Exact agent name from available_agents
- description: Imperative verb + specific action + context

DEPENDENCY RULES:
- depends_on: Only reference task_ids defined earlier in the list
- No circular dependencies
- Independent tasks should have depends_on: []

MANDATORY QC RULE:
- For EVERY agent that produces a file (presentation, code, image, document),
  include a follow-up subtask that inspects the output visually or structurally.
- All agents have VLM tools: visual_inspect(), inspect_browser_state(),
  inspect_file_visually(), inspect_pptx_slides(), inspect_code_for_errors().
- These QC tasks depend on the creation task and must run AFTER it.
"""


# =============================================================================
# EXPORT
# =============================================================================

__all__ = [
    'DynamicTaskPlanner',
    'TaskPlan',
    'TaskSpec',
    'GENERIC_TASK_DECOMPOSITION_PROMPT'
]
