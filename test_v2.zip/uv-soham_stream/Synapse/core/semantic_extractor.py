"""
Semantic Extraction Utilities - A-TEAM FIX #2
==============================================

Replaces positional string extraction with LLM-based semantic extraction.

Richard Sutton: "Positional extraction assumes structure. Semantic extraction learns structure."
DSPy Author: "This is what DSPy was built for - learned extraction, not heuristics."
"""

import dspy
from typing import List, Optional


class ExtractImportantWordsSignature(dspy.Signature):
    """Extract the most semantically important words from text for search/summarization."""
    
    text: str = dspy.InputField(desc="The text to extract important words from")
    max_words: int = dspy.InputField(desc="Maximum number of important words to extract")
    purpose: str = dspy.InputField(desc="Purpose of extraction (e.g., 'search', 'summary', 'keywords')")
    
    important_words: List[str] = dspy.OutputField(desc="List of the most semantically important words, ordered by importance")
    reasoning: str = dspy.OutputField(desc="Brief explanation of why these words were chosen")


class SemanticExtractor:
    """
    LLM-based semantic extraction to replace positional heuristics.
    
    A-TEAM FIX #2: Replace `words[:3] + words[-3:]` with semantic understanding.
    """
    
    def __init__(self):
        """Initialize the semantic extractor with DSPy."""
        self.extractor = dspy.ChainOfThought(ExtractImportantWordsSignature)
    
    def extract_important_words(
        self, 
        text: str, 
        max_words: int = 6,
        purpose: str = "search"
    ) -> List[str]:
        """
        Extract semantically important words from text.
        
        Args:
            text: The text to extract from
            max_words: Maximum number of words to extract
            purpose: Purpose of extraction (affects selection strategy)
        
        Returns:
            List of important words, ordered by semantic importance
        
        Example:
            >>> extractor = SemanticExtractor()
            >>> extractor.extract_important_words(
            ...     "How do I merge two pandas DataFrames on a common column?",
            ...     max_words=6,
            ...     purpose="search"
            ... )
            ['pandas', 'merge', 'DataFrames', 'common', 'column', 'join']
        """
        try:
            result = self.extractor(
                text=text,
                max_words=max_words,
                purpose=purpose
            )
            return result.important_words[:max_words]  # Ensure limit
        except Exception as e:
            # Fallback: Use the old heuristic if LLM fails
            # This ensures robustness while still preferring semantic extraction
            import logging
            logging.warning(f"Semantic extraction failed: {e}. Using fallback heuristic.")
            return self._fallback_extraction(text, max_words)
    
    def _fallback_extraction(self, text: str, max_words: int) -> List[str]:
        """
        Fallback heuristic extraction (original logic).
        Only used if LLM extraction fails.
        """
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
                      'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
                      'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                      'would', 'should', 'could', 'may', 'might', 'must', 'can', 'i', 'you',
                      'he', 'she', 'it', 'we', 'they', 'this', 'that', 'these', 'those',
                      'my', 'your', 'his', 'her', 'its', 'our', 'their', 'what', 'which',
                      'who', 'when', 'where', 'why', 'how'}
        
        words = text.lower().split()
        important_words = []
        
        for word in words:
            word_lower = word.strip('.,!?;:()[]{}"\'-').lower()
            if (len(word_lower) > 2 and 
                word_lower not in stop_words and
                not word_lower.isdigit() and
                word_lower.isalnum()):
                important_words.append(word_lower)
        
        # Take first half and last half (balanced approach)
        if len(important_words) > max_words:
            half = max_words // 2
            important_words = important_words[:half] + important_words[-half:]
        
        return important_words[:max_words]


# Global instance for reuse
_global_extractor: Optional[SemanticExtractor] = None


def get_semantic_extractor() -> SemanticExtractor:
    """Get or create the global semantic extractor instance."""
    global _global_extractor
    if _global_extractor is None:
        _global_extractor = SemanticExtractor()
    return _global_extractor
