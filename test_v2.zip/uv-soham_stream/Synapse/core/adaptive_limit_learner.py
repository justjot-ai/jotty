"""
🛡️ ADAPTIVE LIMIT LEARNER
=========================

A-Team Critical Fix: Learn actual model limits from API errors.

Problem:
- Model catalog may have wrong limits
- New models not in catalog
- API may have different limits than documented

Solution:
- Catch token overflow errors
- Extract actual limit from error message (LLM-based!)
- Learn and persist actual limits
- Use learned limits for future calls

This ensures ZERO FAILURES on token limits after first error.
"""

import json
import logging
from typing import Dict, Optional, AsyncGenerator, Any
from pathlib import Path
from dataclasses import dataclass, field

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

logger = logging.getLogger(__name__)


# =============================================================================
# DSPy SIGNATURES
# =============================================================================

if DSPY_AVAILABLE:
    class TokenOverflowDetectorSignature(dspy.Signature):
        """
        LLM-based token overflow error detection (NO REGEX!).
        
        Detects if an API error is due to token/context overflow.
        """
        error_message = dspy.InputField(
            desc="Full exception message from API call"
        )
        error_type = dspy.InputField(
            desc="Exception type (e.g., 'ValueError', 'APIError')"
        )
        
        reasoning = dspy.OutputField(
            desc="Step-by-step analysis of whether this is a token overflow error"
        )
        is_overflow = dspy.OutputField(
            desc="True if this is a token/context length overflow error, False otherwise"
        )
    
    class LimitExtractorSignature(dspy.Signature):
        """
        LLM-based extraction of actual token limit from error message.
        
        Examples:
        - "maximum context length is 128000 tokens" → 128000
        - "input is too long (150000 tokens, max is 200000)" → 200000
        - "Request too large. Max tokens: 4096" → 4096
        """
        error_message = dspy.InputField(
            desc="API error message mentioning token limit"
        )
        
        reasoning = dspy.OutputField(
            desc="Analysis of how the limit was extracted"
        )
        actual_limit = dspy.OutputField(
            desc="Extracted token limit as an integer (e.g., '128000')"
        )


# =============================================================================
# ADAPTIVE LIMIT LEARNER
# =============================================================================

@dataclass
class LearnedLimit:
    """A learned model limit with metadata."""
    model_name: str
    actual_limit: int
    learned_from_error: str
    timestamp: float
    confidence: float = 1.0  # Confidence in this limit (0-1)


class AdaptiveLimitLearner:
    """
    Learn actual model token limits from API errors.
    
    Features:
    1. LLM-based error detection (NO REGEX!)
    2. LLM-based limit extraction from error messages
    3. Persistence of learned limits
    4. Confidence-based limit selection
    5. Fallback to catalog if no learned limit
    """
    
    def __init__(self, persistence_dir: Optional[Path] = None):
        """
        Initialize the adaptive learner.
        
        Args:
            persistence_dir: Directory to save learned limits
        """
        self.learned_limits: Dict[str, LearnedLimit] = {}
        self.persistence_dir = persistence_dir
        
        # Initialize LLM-based detectors
        if DSPY_AVAILABLE:
            self.overflow_detector = dspy.ChainOfThought(TokenOverflowDetectorSignature)
            self.limit_extractor = dspy.ChainOfThought(LimitExtractorSignature)
        else:
            self.overflow_detector = None
            self.limit_extractor = None
            logger.warning("⚠️  DSPy not available - AdaptiveLimitLearner will not work!")
        
        # Load previously learned limits
        self.load_learned_limits()
        logger.info(f"✅ AdaptiveLimitLearner initialized | "
                   f"loaded {len(self.learned_limits)} previously learned limits")
    
    async def is_token_overflow_stream(self, error: Exception) -> AsyncGenerator[Dict[str, Any], bool]:
        """
        Detect if an error is due to token overflow (LLM-based, NO REGEX!).
        
        Args:
            error: Exception from API call
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            True if this is a token overflow error
        
        Raises:
            RuntimeError: If LLM detector not available
        """
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am checking if this error is a token overflow"}
        if not self.overflow_detector:
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I noticed DSPy is not available, cannot detect token overflow"}
            raise RuntimeError("DSPy not available - cannot detect token overflow!")
        
        try:
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am analyzing the error message with LLM to detect token overflow"}
            result = self.overflow_detector(
                error_message=str(error)[:1000],  # Limit length
                error_type=type(error).__name__
            )
            is_overflow = getattr(result, 'is_overflow', 'False').lower() in ['true', 'yes', '1']
            reasoning = getattr(result, 'reasoning', 'N/A')
            
            logger.debug(f"🔍 Token overflow detection: {is_overflow} | reasoning: {reasoning[:100]}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I found that this is {'a token overflow error' if is_overflow else 'not a token overflow error'}"}
            yield {"type": "result", "result": is_overflow}
            return
        except Exception as e:
            logger.warning(f"Token overflow detection failed: {e}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I encountered an error during token overflow detection: {e}"}
            # If LLM fails, raise to prevent silent fallback
            raise RuntimeError(f"LLM-based overflow detection failed: {e}")
    
    def is_token_overflow(self, error: Exception) -> bool:
        """Synchronous wrapper for is_token_overflow_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # In async context, need to use async version directly
                raise RuntimeError("Use is_token_overflow_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.is_token_overflow_stream(error):
                        result = event.get("result")
                        if result is not None:
                            return result
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            # Event loop is running, return False as fallback
            logger.warning("⚠️ Cannot check token overflow synchronously from running event loop. Returning False.")
            return False
    
    async def _sync_is_token_overflow(self, error: Exception) -> bool:
        """Helper for sync wrapper."""
        result = None
        async for event in self.is_token_overflow_stream(error):
            if "result" in event:
                result = event["result"]
        return result if result is not None else False
    
    async def extract_actual_limit_stream(self, error: Exception) -> AsyncGenerator[Dict[str, Any], Optional[int]]:
        """
        Extract actual token limit from error message (LLM-based!).
        
        Args:
            error: Token overflow exception
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            Actual token limit if found, None otherwise
        
        Raises:
            RuntimeError: If LLM extractor not available
        """
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am extracting the actual token limit from the error message"}
        if not self.limit_extractor:
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I noticed DSPy is not available, cannot extract limit"}
            raise RuntimeError("DSPy not available - cannot extract limit!")
        
        try:
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am using LLM to analyze the error and extract the token limit"}
            result = self.limit_extractor(
                error_message=str(error)[:1000]
            )
            limit_str = getattr(result, 'actual_limit', None)
            reasoning = getattr(result, 'reasoning', 'N/A')
            
            if limit_str:
                # Try to parse as integer
                try:
                    actual_limit = int(limit_str.replace(',', '').strip())
                    logger.info(f"✅ Extracted limit from error: {actual_limit:,} tokens | "
                               f"reasoning: {reasoning[:100]}")
                    yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I successfully extracted the token limit: {actual_limit:,} tokens"}
                    yield {"type": "result", "result": actual_limit}
                    return
                except ValueError:
                    logger.warning(f"Failed to parse limit: '{limit_str}'")
                    yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I could not parse the extracted limit: '{limit_str}'"}
                    yield {"type": "result", "result": None}
                    return
            
            logger.warning("LLM could not extract limit from error")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I could not extract a token limit from the error message"}
            yield {"type": "result", "result": None}
            return
        except Exception as e:
            logger.warning(f"Limit extraction failed: {e}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I encountered an error during limit extraction: {e}"}
            # If LLM fails, raise to prevent silent fallback
            raise RuntimeError(f"LLM-based limit extraction failed: {e}")
    
    def extract_actual_limit(self, error: Exception) -> Optional[int]:
        """Synchronous wrapper for extract_actual_limit_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use extract_actual_limit_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.extract_actual_limit_stream(error):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            # Event loop is running, return None as fallback
            logger.warning("⚠️ Cannot extract actual limit synchronously from running event loop. Returning None.")
            return None
    
    async def _sync_extract_actual_limit(self, error: Exception) -> Optional[int]:
        """Helper for sync wrapper."""
        result = None
        async for event in self.extract_actual_limit_stream(error):
            if event.get("type") == "result":
                result = event.get("result")
        return result
    
    async def learn_from_error_stream(self, model_name: str, error: Exception, context_size: int) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Learn actual model limit from an API error.
        
        Args:
            model_name: Name of the model that errored
            error: The API exception
            context_size: Size of context that was rejected
        
        Yields:
            Event dictionaries with module and conversational message
        
        Raises:
            RuntimeError: If learning fails (LLM not available, etc.)
        """
        import time
        
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I am learning the token limit for model {model_name} from this error"}
        
        # Extract actual limit from error
        actual_limit = None
        async for event in self.extract_actual_limit_stream(error):
            yield event
            if event.get("type") == "result":
                actual_limit = event.get("result")
        
        if actual_limit:
            # Store learned limit
            learned = LearnedLimit(
                model_name=model_name,
                actual_limit=actual_limit,
                learned_from_error=str(error)[:500],
                timestamp=time.time(),
                confidence=1.0  # High confidence from direct error
            )
            self.learned_limits[model_name] = learned
            
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I have stored the learned limit for {model_name}: {actual_limit:,} tokens"}
            
            # Persist immediately
            async for event in self.save_learned_limits_stream():
                yield event
            
            logger.info(f"📚 LEARNED NEW LIMIT: {model_name} → {actual_limit:,} tokens | "
                       f"rejected context was {context_size:,} tokens")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I successfully learned a new limit: {model_name} → {actual_limit:,} tokens (rejected context was {context_size:,} tokens)"}
        else:
            logger.warning(f"Could not extract limit from error for {model_name}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I could not extract a limit from the error for {model_name}"}
            raise RuntimeError(f"Failed to learn limit from error for {model_name}")
    
    def learn_from_error(self, model_name: str, error: Exception, context_size: int):
        """Synchronous wrapper for learn_from_error_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use learn_from_error_stream in async context")
            else:
                async def _run():
                    async for event in self.learn_from_error_stream(model_name, error, context_size):
                        pass
                loop.run_until_complete(_run())
        except RuntimeError:
            # Event loop is running, skip learning synchronously
            logger.warning(f"⚠️ Cannot learn from error synchronously from running event loop. Skipping.")
            return
    
    async def _sync_learn_from_error(self, model_name: str, error: Exception, context_size: int):
        """Helper for sync wrapper."""
        async for event in self.learn_from_error_stream(model_name, error, context_size):
            pass
    
    async def get_limit_stream(self, model_name: str) -> AsyncGenerator[Dict[str, Any], Optional[int]]:
        """
        Get learned limit for a model.
        
        Args:
            model_name: Model to get limit for
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            Learned limit if available, None otherwise
        """
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I am checking for a learned limit for model {model_name}"}
        if model_name in self.learned_limits:
            limit = self.learned_limits[model_name].actual_limit
            logger.debug(f"📚 Using LEARNED limit for {model_name}: {limit:,} tokens")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I found a learned limit for {model_name}: {limit:,} tokens"}
            yield {"type": "result", "result": limit}
            return
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I did not find a learned limit for {model_name}"}
        yield {"type": "result", "result": None}
        return
    
    def get_limit(self, model_name: str) -> Optional[int]:
        """
        Get the learned token limit for a model (synchronous, no event loop needed).
        
        🔴 A-TEAM FIX: Previous implementation tried to use asyncio which fails
        in a running event loop. Since learned_limits is already in-memory after
        __init__, this is just a simple dict lookup — no async needed.
        """
        learned = self.learned_limits.get(model_name)
        if learned and learned.actual_limit:
            logger.debug(f"🎯 Learned limit for {model_name}: {learned.actual_limit} (confidence={learned.confidence})")
            return learned.actual_limit
        return None
    
    async def _sync_get_limit(self, model_name: str) -> Optional[int]:
        """Helper for sync wrapper."""
        result = None
        async for event in self.get_limit_stream(model_name):
            if event.get("type") == "result":
                result = event.get("result")
        return result
    
    def has_learned_limit(self, model_name: str) -> bool:
        """Check if we have a learned limit for this model."""
        return model_name in self.learned_limits
    
    async def save_learned_limits_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Persist learned limits to disk."""
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am saving learned limits to disk"}
        if not self.persistence_dir:
            logger.debug("No persistence_dir set - skipping save")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I noticed no persistence directory is set, skipping save"}
            return
        
        try:
            filepath = self.persistence_dir / "learned_model_limits.json"
            self.persistence_dir.mkdir(parents=True, exist_ok=True)
            
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I am writing learned limits to {filepath}"}
            
            # Serialize learned limits
            data = {
                model: {
                    'actual_limit': limit.actual_limit,
                    'learned_from_error': limit.learned_from_error,
                    'timestamp': limit.timestamp,
                    'confidence': limit.confidence
                }
                for model, limit in self.learned_limits.items()
            }
            
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"💾 Saved {len(data)} learned limits to {filepath}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I successfully saved {len(data)} learned limits to disk"}
        except Exception as e:
            logger.error(f"Failed to save learned limits: {e}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I encountered an error while saving learned limits: {e}"}
            # Don't raise - this is not critical for execution
    
    def save_learned_limits(self):
        """
        Synchronous file-based saving of learned limits.
        
        🔴 A-TEAM FIX: Previous implementation tried to use asyncio.run_until_complete()
        which fails when called from a running event loop. Now uses plain synchronous
        file I/O which works in any context. Mirrors save_learned_limits_stream filename.
        """
        if not self.persistence_dir:
            return
        
        try:
            filepath = Path(self.persistence_dir) / "learned_model_limits.json"
            Path(self.persistence_dir).mkdir(parents=True, exist_ok=True)
            
            data = {
                model: {
                    'actual_limit': limit.actual_limit,
                    'learned_from_error': limit.learned_from_error,
                    'timestamp': limit.timestamp,
                    'confidence': limit.confidence
                }
                for model, limit in self.learned_limits.items()
            }
            
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"💾 Saved {len(self.learned_limits)} learned limits to {filepath}")
        except Exception as e:
            logger.warning(f"Failed to save learned limits synchronously: {e}")
    
    async def _sync_save_learned_limits(self):
        """Helper for sync wrapper."""
        async for event in self.save_learned_limits_stream():
            pass
    
    async def load_learned_limits_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Load previously learned limits from disk."""
        yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I am loading previously learned limits from disk"}
        if not self.persistence_dir:
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": "I noticed no persistence directory is set, skipping load"}
            return
        
        try:
            filepath = self.persistence_dir / "learned_model_limits.json"
            if not filepath.exists():
                logger.debug(f"No learned limits file found at {filepath}")
                yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I did not find a learned limits file at {filepath}"}
                return
            
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I found a learned limits file, reading it now"}
            with open(filepath) as f:
                data = json.load(f)
            
            # Deserialize learned limits
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I am deserializing {len(data)} learned limits"}
            for model, limit_data in data.items():
                self.learned_limits[model] = LearnedLimit(
                    model_name=model,
                    actual_limit=limit_data['actual_limit'],
                    learned_from_error=limit_data['learned_from_error'],
                    timestamp=limit_data['timestamp'],
                    confidence=limit_data.get('confidence', 1.0)
                )
            
            logger.info(f"📚 Loaded {len(self.learned_limits)} learned limits from disk")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I successfully loaded {len(self.learned_limits)} learned limits from disk"}
        except Exception as e:
            logger.warning(f"Failed to load learned limits: {e}")
            yield {"module": "Synapse.core.adaptive_limit_learner", "message": f"I encountered an error while loading learned limits: {e}"}
            # Don't raise - start fresh if load fails
    
    def load_learned_limits(self):
        """
        Synchronous file-based loading of learned limits.
        
        🔴 A-TEAM FIX: Previous implementation tried to use asyncio.run_until_complete()
        which fails when called from a running event loop (e.g. during Conductor init
        inside an async handler). Now uses plain synchronous file I/O which works
        in any context.
        """
        if not self.persistence_dir:
            return
        
        try:
            filepath = Path(self.persistence_dir) / "learned_model_limits.json"
            if not filepath.exists():
                logger.debug(f"No learned limits file found at {filepath}")
                return
            
            with open(filepath) as f:
                data = json.load(f)
            
            for model, limit_data in data.items():
                self.learned_limits[model] = LearnedLimit(
                    model_name=model,
                    actual_limit=limit_data['actual_limit'],
                    learned_from_error=limit_data['learned_from_error'],
                    timestamp=limit_data['timestamp'],
                    confidence=limit_data.get('confidence', 1.0)
                )
            
            logger.info(f"📚 Loaded {len(self.learned_limits)} learned limits from disk")
        except Exception as e:
            logger.warning(f"Failed to load learned limits: {e}")
            # Don't raise - start fresh if load fails
    
    async def _sync_load_learned_limits(self):
        """Helper for sync wrapper."""
        async for event in self.load_learned_limits_stream():
            pass


__all__ = [
    'AdaptiveLimitLearner',
    'LearnedLimit',
    'TokenOverflowDetectorSignature',
    'LimitExtractorSignature'
]
