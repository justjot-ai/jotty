"""
MetadataToolRegistry: Automatic discovery and registration of metadata tools.

# ✅ A-TEAM UNANIMOUS DESIGN (Vote: 5-0)
# ✅ LLM-driven tool selection
# ✅ Automatic discovery via @synapse_method decorator
# ✅ Rich metadata for LLM guidance
# ✅ Tool caching and monitoring

Design Philosophy:
- Discovers ALL @synapse_method decorated methods via introspection
- Extracts rich metadata (desc, when, params, returns)
- Creates LLM-friendly tool catalog
- Provides unified interface for tool calling
- Handles caching transparently
"""

from typing import Any, Dict, List, Optional, Callable, AsyncGenerator
import logging
import inspect
import time
from datetime import datetime

from .logging_config import get_logger

logger = get_logger(__name__)


class MetadataToolRegistry:
    """
    Discovers and manages metadata tools for Synapse actors.
    
#     ✅ A-TEAM DESIGN: Automatic discovery + LLM-driven selection
    
    Features:
    1. **Automatic Discovery**: Finds all @synapse_method decorated methods
    2. **Rich Metadata**: Extracts desc, when, params, returns for LLM
    3. **Tool Catalog**: Generates LLM-friendly documentation
    4. **Unified Calling**: Single interface for all tool calls
    5. **Smart Caching**: Caches results based on decorator config
    6. **Monitoring**: Tracks tool usage for optimization
    
    Usage:
        # User creates metadata
        metadata = MyMetadata(data_dir="/path/to/data")
        
        # ReVal creates registry (automatic!)
        registry = MetadataToolRegistry(metadata)
        
        # ReVal discovers tools
        print(registry.get_tool_catalog_for_llm())
        
        # Actors call tools
        result = registry.call_tool("get_business_terms")
    """
    
    def __init__(self, metadata_instance: Any):
        """
        Initialize tool registry with metadata instance.
        
        ✅ A-TEAM INTEGRATION: Now supports BaseMetadataProvider for safeguarded tools!
        
        RECOMMENDED: Inherit from BaseMetadataProvider for automatic safeguards:
        - Token budget tracking (prevents context explosion)
        - Automatic caching (prevents redundant calls)
        - Tool statistics (monitoring)
        - Protocol methods (ReVal integration)
        
        Args:
            metadata_instance: Instance of user's metadata class
                             (preferably inherits from BaseMetadataProvider)
        
        Example:
            ```python
            from Synapse.core.base_metadata_provider import BaseMetadataProvider
            from Synapse.core.metadata_protocol import synapse_method
            
            class MyMetadata(BaseMetadataProvider):
                def __init__(self):
                    super().__init__(token_budget=50000)  # ← Safeguards!
                
                @synapse_method(desc="...", for_architect=True)
                def get_terms(self):
                    return self.terms
            
            registry = MetadataToolRegistry(MyMetadata())
            # Tools have: budget + caching + metadata + role access!
            ```
        """
        start_time = time.time()
        metadata_type = type(metadata_instance).__name__
        logger.info(f"🔧 INIT: MetadataToolRegistry | metadata_type={metadata_type}")
        
        self.metadata = metadata_instance
        self.tools: Dict[str, Dict[str, Any]] = {}
        self._cache: Dict[str, Any] = {}
        self._usage_stats: Dict[str, int] = {}
        
        # ✅ A-TEAM INTEGRATION: Check if provider inherits from BaseMetadataProvider
        if hasattr(metadata_instance, 'get_tools') and callable(getattr(metadata_instance, 'get_tools')):
            logger.info(f"🔧 INTEGRATION: {metadata_type} inherits from BaseMetadataProvider!")
            logger.info(f"   Using safeguarded tools with: Token budget + Caching + Statistics")
            # Note: __init__ cannot yield, but initialization is logged
            
            try:
                # Get safeguarded tools from BaseMetadataProvider
                safeguarded_tools = metadata_instance.get_tools()
                
                # Convert to our format
                for tool in safeguarded_tools:
                    tool_name = getattr(tool, 'name', getattr(tool, '__name__', 'unknown'))
                    tool_name = tool_name.replace('metadata_', '')  # Remove prefix
                    
                    self.tools[tool_name] = {
                        'name': tool_name,
                        'desc': getattr(tool, 'description', getattr(tool, '__doc__', 'Tool')),
                        'callable': tool,  # Already safeguarded!
                        'safeguarded': True,
                        'provider_type': 'BaseMetadataProvider'
                    }
                
                logger.info(f"✅ INTEGRATED: {len(self.tools)} safeguarded tools")
            except Exception as e:
                logger.warning(f"⚠️  Failed to get safeguarded tools: {e}")
                logger.info(f"   Falling back to @synapse_method discovery...")
                self._discover_tools()
        else:
            # Standard discovery via @synapse_method decorator
            logger.info(f"🔍 DISCOVER: Starting tool discovery from {metadata_type}...")
            discovery_start = time.time()
            self._discover_tools()
            discovery_duration = time.time() - discovery_start
            logger.info(f"   Discovery duration: {discovery_duration:.3f}s")
        
        total_duration = time.time() - start_time
        logger.info(f"✅ INIT COMPLETE: MetadataToolRegistry | "
                   f"tools_discovered={len(self.tools)} | "
                   f"total_duration={total_duration:.3f}s")
        # Note: __init__ cannot yield, but initialization is logged
        
        if self.tools:
            tool_names = list(self.tools.keys())
            logger.debug(f"  Discovered tools: {', '.join(tool_names)}")
    
    async def _discover_tools_stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Discover tools with event streaming.
        """
        metadata_type = type(self.metadata).__name__
        logger.info(f"🔍 DISCOVER_TOOLS: Starting discovery from {metadata_type}")
        yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I am starting tool discovery from {metadata_type}"}
        
        # Call sync version but yield events
        self._discover_tools()
        
        yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I have completed tool discovery, found {len(self.tools)} tools"}
    
    def _discover_tools(self):
        """
        Discover all @synapse_method decorated methods via introspection.
        
#         ✅ A-TEAM DESIGN: Zero configuration, automatic discovery
        
        Process:
        1. Iterate through all attributes of metadata instance
        2. Check for _synapse_meta metadata (added by @synapse_method)
        3. Extract rich metadata (desc, when, params, returns, cache)
        4. Store as callable tool with metadata
        """
        start_time = time.time()
        metadata_type = type(self.metadata).__name__
        logger.info(f"🔍 DISCOVER_TOOLS: Starting discovery from {metadata_type}")
        
        discovered_count = 0
        skipped_count = 0
        error_count = 0
        discovered_tools = []
        
        all_attrs = dir(self.metadata)
        logger.debug(f"  Scanning {len(all_attrs)} total attributes")
        
        for attr_name in all_attrs:
            # Skip private/protected methods
            if attr_name.startswith('_'):
                skipped_count += 1
                continue
            
            try:
                attr_start = time.time()
                attr = getattr(self.metadata, attr_name)
                attr_duration = time.time() - attr_start
                
                logger.debug(f"  Inspecting '{attr_name}': type={type(attr).__name__} ({attr_duration:.3f}s)")
                
                # 🔧 A-TEAM FIX: Check for _synapse_meta (from metadata_protocol.py)
                if hasattr(attr, '_synapse_meta'):
                    tool_info = attr._synapse_meta
                    tool_name = attr_name  # Use the actual method name
                    
                    # 🔥 A-TEAM CRITICAL FIX: Extract for_architect/for_auditor flags!
                    for_architect = getattr(attr, '_synapse_for_architect', False)
                    for_auditor = getattr(attr, '_synapse_for_auditor', False)
                    
                    signature_start = time.time()
                    signature = self._extract_signature(attr)
                    signature_duration = time.time() - signature_start
                    
                    # Store tool with rich metadata
                    self.tools[tool_name] = {
                        'name': tool_name,
                        'desc': tool_info['desc'],
                        'when': tool_info['when'],
                        'params': tool_info.get('params', {}),  # May not exist
                        'returns': tool_info.get('returns', 'Data from metadata'),  # May not exist
                        'cache': tool_info['cache'],
                        'callable': attr,  # Bound method
                        'signature': signature,
                        'for_architect': for_architect,  # 🔥 A-TEAM: Val agent flag
                        'for_auditor': for_auditor  # 🔥 A-TEAM: Val agent flag
                    }
                    
                    param_count = len(signature.get('parameters', {}))
                    discovered_tools.append(f"{tool_name}({param_count} params)")
                    logger.info(f"  ✅ DISCOVERED: {tool_name}() | "
                              f"desc='{tool_info['desc'][:50]}...' | "
                              f"architect={for_architect} | "
                              f"auditor={for_auditor} | "
                              f"cache={tool_info['cache']} | "
                              f"signature_duration={signature_duration:.3f}s")
                    discovered_count += 1
                else:
                    logger.debug(f"    '{attr_name}': No _synapse_meta attribute (not a @synapse_method)")
            
            except Exception as e:
                error_count += 1
                logger.warning(f"  ⚠️  Failed to inspect '{attr_name}': {e}", exc_info=True)
        
        duration = time.time() - start_time
        
        if discovered_count == 0:
            logger.warning(
                f"⚠️  DISCOVERY COMPLETE: No @synapse_method decorated methods found in {metadata_type} | "
                f"scanned={len(all_attrs)} | skipped={skipped_count} | errors={error_count} | "
                f"duration={duration:.3f}s"
            )
            logger.warning(f"  Did you forget to add @synapse_method decorator?")
        else:
            logger.info(f"✅ DISCOVERY COMPLETE: {discovered_count} tools discovered | "
                       f"scanned={len(all_attrs)} | skipped={skipped_count} | errors={error_count} | "
                       f"duration={duration:.3f}s")
            logger.debug(f"  Discovered tools: {', '.join(discovered_tools)}")
    
    def _extract_signature(self, method: Callable) -> Dict[str, Any]:
        """
        Extract method signature for parameter validation.
        
        Args:
            method: Method to inspect
        
        Returns:
            Dict with parameter names, types, defaults
        """
        try:
            sig = inspect.signature(method)
            params = {}
            
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                
                params[param_name] = {
                    'annotation': param.annotation if param.annotation != inspect.Parameter.empty else Any,
                    'default': param.default if param.default != inspect.Parameter.empty else None,
                    'required': param.default == inspect.Parameter.empty
                }
            
            return {
                'parameters': params,
                'return_annotation': sig.return_annotation if sig.return_annotation != inspect.Signature.empty else Any
            }
        
        except Exception as e:
            logger.warning(f"⚠️  Failed to extract signature: {e}")
            return {'parameters': {}, 'return_annotation': Any}
    
    def get_tool_catalog_for_llm(self) -> str:
        """
        Generate LLM-friendly tool catalog.
        
#         ✅ A-TEAM DESIGN: Rich context for LLM decision-making
        
        Returns:
            Formatted string describing all available tools
            
        Example Output:
            Available Metadata Tools:
            
            Tool: get_business_terms()
              Description: Get all business term definitions with SQL mappings
              When to use: Agent needs to understand business terminology
              Returns: Dict of term -> {definition, sql_column, examples}
            
            Tool: get_table_schema(table_name)
              Description: Get schema information for a specific table
              When to use: Agent needs table structure, columns, types
              Parameters:
                - table_name: Name of the table to query
              Returns: Dict with columns, types, primary_key, foreign_keys
        """
        if not self.tools:
            return "No metadata tools available."
        
        catalog = "📚 Available Metadata Tools:\n\n"
        
        for tool_name, info in sorted(self.tools.items()):
            # Tool signature
            params_str = ""
            if info['signature']['parameters']:
                param_names = list(info['signature']['parameters'].keys())
                params_str = f"({', '.join(param_names)})"
            
            catalog += f"🔧 Tool: {tool_name}{params_str}\n"
            catalog += f"   Description: {info['desc']}\n"
            catalog += f"   When to use: {info['when']}\n"
            
            # Parameters
            if info['params']:
                catalog += f"   Parameters:\n"
                for param_name, param_desc in info['params'].items():
                    param_sig = info['signature']['parameters'].get(param_name, {})
                    required = " (required)" if param_sig.get('required', False) else " (optional)"
                    catalog += f"     • {param_name}: {param_desc}{required}\n"
            
            # Return value
            catalog += f"   Returns: {info['returns']}\n"
            
            # Usage stats (if available)
            if tool_name in self._usage_stats:
                catalog += f"   Usage: Called {self._usage_stats[tool_name]} times\n"
            
            catalog += "\n"
        
        return catalog
    
    async def call_tool_stream(self, tool_name: str, **kwargs) -> AsyncGenerator[Dict[str, Any], Any]:
        """Call tool with event streaming."""
        start_time = time.time()
        logger.info(f"🔧 CALL_TOOL: {tool_name}() | kwargs={list(kwargs.keys())}")
        yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I am calling tool {tool_name} with {len(kwargs)} parameters"}
        logger.debug(f"  Parameters: {kwargs}")
        
        if tool_name not in self.tools:
            available = ', '.join(self.tools.keys())
            logger.error(f"❌ CALL_TOOL FAILED: Tool '{tool_name}' not found | available={available}")
            yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I encountered an error: tool '{tool_name}' not found"}
            raise ValueError(f"❌ Tool '{tool_name}' not found. Available tools: {available}")
        
        tool = self.tools[tool_name]
        logger.debug(f"  Tool metadata: desc='{tool['desc'][:50]}...' | cache={tool['cache']}")
        
        # Check for cached result
        if tool['cache']:
            cache_key = self._make_cache_key(tool_name, kwargs)
            if cache_key in self._cache:
                duration = time.time() - start_time
                self._usage_stats[tool_name] = self._usage_stats.get(tool_name, 0) + 1
                logger.info(f"💾 CALL_TOOL CACHE_HIT: {tool_name}() | duration={duration:.3f}s")
                yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I found a cached result for tool {tool_name}"}
                result = self._cache[cache_key]
                yield {"type": "result", "result": result, "module": "Synapse.core.metadata_tool_registry", "message": f"I am returning the cached result from tool {tool_name}"}
                return
            else:
                logger.debug(f"  Cache miss for key: {cache_key}")
        
        # Validate parameters
        validation_start = time.time()
        self._validate_parameters(tool, kwargs)
        validation_duration = time.time() - validation_start
        logger.debug(f"  Parameter validation: PASS ({validation_duration:.3f}s)")
        
        # Call tool
        try:
            call_start = time.time()
            logger.info(f"  🔵 Executing {tool_name}({', '.join(f'{k}={v!r}' for k, v in kwargs.items())})")
            yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I am executing tool {tool_name}"}
            result = tool['callable'](**kwargs)
            call_duration = time.time() - call_start
            
            result_type = type(result).__name__
            logger.info(f"  ✅ Tool execution complete: {tool_name}() -> {result_type} | duration={call_duration:.3f}s")
            yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I have completed executing tool {tool_name}, got result type {result_type}"}
            
            # Cache if enabled
            if tool['cache']:
                cache_key = self._make_cache_key(tool_name, kwargs)
                self._cache[cache_key] = result
                logger.debug(f"  Cached result with key: {cache_key}")
            
            # Track usage
            self._usage_stats[tool_name] = self._usage_stats.get(tool_name, 0) + 1
            
            total_duration = time.time() - start_time
            logger.info(f"✅ CALL_TOOL COMPLETE: {tool_name}() | result_type={result_type} | "
                       f"call_duration={call_duration:.3f}s | total_duration={total_duration:.3f}s")
            yield {"type": "result", "result": result, "module": "Synapse.core.metadata_tool_registry", "message": f"I am returning the result from tool {tool_name}"}
            return
        
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"❌ CALL_TOOL FAILED: {tool_name}() | error={type(e).__name__}: {e} | duration={duration:.3f}s", exc_info=True)
            yield {"module": "Synapse.core.metadata_tool_registry", "message": f"I encountered an error while calling tool {tool_name}: {str(e)}"}
            raise
    
    def call_tool(self, tool_name: str, **kwargs) -> Any:
        """
        Call a tool by name with parameters.
        
#         ✅ A-TEAM DESIGN: Unified interface + smart caching
        
        Args:
            tool_name: Name of the tool to call
            **kwargs: Parameters to pass to the tool
        
        Returns:
            Tool result (cached if cache=True in decorator)
        
        Raises:
            ValueError: If tool not found
            TypeError: If required parameters missing
        
        Example:
            # No parameters
            terms = registry.call_tool("get_business_terms")
            
            # With parameters
            schema = registry.call_tool("get_table_schema", table_name="users")
        """
        start_time = time.time()
        logger.info(f"🔧 CALL_TOOL: {tool_name}() | kwargs={list(kwargs.keys())}")
        logger.debug(f"  Parameters: {kwargs}")
        
        if tool_name not in self.tools:
            available = ', '.join(self.tools.keys())
            logger.error(f"❌ CALL_TOOL FAILED: Tool '{tool_name}' not found | available={available}")
            raise ValueError(
                f"❌ Tool '{tool_name}' not found. "
                f"Available tools: {available}"
            )
        
        tool = self.tools[tool_name]
        logger.debug(f"  Tool metadata: desc='{tool['desc'][:50]}...' | cache={tool['cache']}")
        
        # Check for cached result
        if tool['cache']:
            cache_key = self._make_cache_key(tool_name, kwargs)
            if cache_key in self._cache:
                duration = time.time() - start_time
                self._usage_stats[tool_name] = self._usage_stats.get(tool_name, 0) + 1
                logger.info(f"💾 CALL_TOOL CACHE_HIT: {tool_name}() | duration={duration:.3f}s")
                return self._cache[cache_key]
            else:
                logger.debug(f"  Cache miss for key: {cache_key}")
        
        # Validate parameters
        validation_start = time.time()
        self._validate_parameters(tool, kwargs)
        validation_duration = time.time() - validation_start
        logger.debug(f"  Parameter validation: PASS ({validation_duration:.3f}s)")
        
        # Call tool
        try:
            call_start = time.time()
            logger.info(f"  🔵 Executing {tool_name}({', '.join(f'{k}={v!r}' for k, v in kwargs.items())})")
            result = tool['callable'](**kwargs)
            call_duration = time.time() - call_start
            
            result_type = type(result).__name__
            logger.info(f"  ✅ Tool execution complete: {tool_name}() -> {result_type} | duration={call_duration:.3f}s")
            
            # Cache if enabled
            if tool['cache']:
                cache_key = self._make_cache_key(tool_name, kwargs)
                self._cache[cache_key] = result
                logger.debug(f"  Cached result with key: {cache_key}")
            
            # Track usage
            self._usage_stats[tool_name] = self._usage_stats.get(tool_name, 0) + 1
            
            total_duration = time.time() - start_time
            logger.info(f"✅ CALL_TOOL COMPLETE: {tool_name}() | result_type={result_type} | "
                       f"call_duration={call_duration:.3f}s | total_duration={total_duration:.3f}s")
            
            return result
        
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"❌ CALL_TOOL FAILED: {tool_name}() | error={type(e).__name__}: {e} | duration={duration:.3f}s",
                        exc_info=True)
            raise
    
    def _make_cache_key(self, tool_name: str, kwargs: Dict[str, Any]) -> str:
        """Create cache key from tool name and parameters."""
        # Simple string-based key (can be enhanced with hashing if needed)
        params_str = "_".join(f"{k}={v}" for k, v in sorted(kwargs.items()))
        return f"{tool_name}_{params_str}" if params_str else tool_name
    
    def _validate_parameters(self, tool: Dict[str, Any], kwargs: Dict[str, Any]):
        """
        Validate that required parameters are provided.
        
        Args:
            tool: Tool metadata
            kwargs: Provided parameters
        
        Raises:
            TypeError: If required parameters are missing
        """
        signature = tool['signature']
        required_params = [
            name for name, info in signature['parameters'].items()
            if info['required']
        ]
        
        missing = [p for p in required_params if p not in kwargs]
        if missing:
            raise TypeError(
                f"❌ Tool {tool['name']}() missing required parameters: {missing}"
            )
    
    def list_tools(self) -> List[str]:
        """
        List all available tool names.
        
        Returns:
            List of tool names
        """
        return list(self.tools.keys())
    
    def get_tool_info(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed information about a specific tool.
        
        Args:
            tool_name: Name of the tool
        
        Returns:
            Tool metadata dict or None if not found
        """
        return self.tools.get(tool_name)
    
    def get_usage_stats(self) -> Dict[str, int]:
        """
        Get usage statistics for all tools.
        
        Returns:
            Dict mapping tool_name -> call_count
        """
        return self._usage_stats.copy()
    
    def clear_cache(self):
        """Clear all cached tool results."""
        self._cache.clear()
        logger.info(f"🗑️  Cleared tool cache")
    
    def __repr__(self) -> str:
        return (
            f"MetadataToolRegistry("
            f"tools={len(self.tools)}, "
            f"cached={len(self._cache)}, "
            f"total_calls={sum(self._usage_stats.values())}"
            f")"
        )


# Export public API
__all__ = [
    'MetadataToolRegistry',
]

