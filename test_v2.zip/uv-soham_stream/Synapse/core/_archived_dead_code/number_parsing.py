"""
Numeric parsing utilities (NO regex).

Provides safe numeric extraction without regex or heuristic string matching.
"""

from typing import Optional


def parse_first_float(text: str) -> Optional[float]:
    """
    Parse the first float-like number from text without regex.

    Returns None if no number is found.
    """
    if not text:
        return None

    num_chars = []
    in_number = False
    decimal_seen = False
    sign_allowed = True

    for ch in text:
        if ch in "+-" and sign_allowed:
            num_chars.append(ch)
            sign_allowed = False
            in_number = True
            continue
        if ch.isdigit():
            num_chars.append(ch)
            sign_allowed = False
            in_number = True
            continue
        if ch == "." and in_number and not decimal_seen:
            num_chars.append(ch)
            decimal_seen = True
            sign_allowed = False
            continue

        # Stop when leaving a number
        if in_number:
            break

        # Reset if we haven't started a number
        num_chars = []
        in_number = False
        decimal_seen = False
        sign_allowed = True

    if not num_chars:
        return None

    try:
        return float("".join(num_chars))
    except ValueError:
        return None


def parse_float_from_string(text: str) -> Optional[float]:
    """
    Parse a float from a string (alias for parse_first_float for compatibility).
    
    Returns None if no number is found.
    """
    return parse_first_float(text)
