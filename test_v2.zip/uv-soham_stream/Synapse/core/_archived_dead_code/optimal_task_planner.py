"""
OptimalTaskPlanner - DP + Memoization Task Optimization
=======================================================

Goal:
- Minimize execution time and number of tasks
- Use DP with memoization (no heuristics) to pick the smallest-cost plan
- Enforce dependencies and required outputs

Design Principles (A-Team):
1. No hardcoding: all decisions are data/LLM-driven
2. No regex: robust parsing via number_parsing utilities
3. Explicit uncertainty: if LLM unavailable, return unoptimized plan
4. Deterministic optimization: DP selects optimal subset given costs/outputs
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Set
import json
import logging
import hashlib

from .dynamic_task_planner import TaskPlan, TaskSpec
from .number_parsing import parse_float_from_string

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


# =============================================================================
# DSPy Signatures (LLM-based estimation; no heuristics)
# =============================================================================

if DSPY_AVAILABLE:
    class GoalRequirementSignature(dspy.Signature):
        """Infer required outputs to satisfy the goal."""
        goal = dspy.InputField(desc="User goal / objective")
        tasks = dspy.InputField(desc="JSON list of tasks with descriptions, outputs")
        context = dspy.InputField(desc="Additional context or constraints")

        required_outputs = dspy.OutputField(
            desc="JSON array of output tokens needed to satisfy the goal"
        )
        reasoning = dspy.OutputField(desc="Why these outputs are required")

    class TaskCostEstimateSignature(dspy.Signature):
        """Estimate time cost for a task given its description and IO."""
        task_description = dspy.InputField(desc="Task description")
        inputs_needed = dspy.InputField(desc="Inputs required for the task (JSON array)")
        outputs_produced = dspy.InputField(desc="Outputs produced (JSON array)")
        context = dspy.InputField(desc="Additional context")

        estimated_seconds = dspy.OutputField(
            desc="Estimated time to complete in seconds (numeric)"
        )
        confidence = dspy.OutputField(desc="Confidence 0-1")
        reasoning = dspy.OutputField(desc="Reasoning for estimate")


# =============================================================================
# Data Structures
# =============================================================================

@dataclass
class OptimizationResult:
    """Result of DP optimization."""
    optimized_plan: Optional[TaskPlan]
    success: bool
    reason: str
    selected_task_ids: List[str] = field(default_factory=list)
    estimated_total_seconds: Optional[float] = None
    required_outputs: List[str] = field(default_factory=list)


# =============================================================================
# Optimal Task Planner
# =============================================================================

class OptimalTaskPlanner:
    """
    DP + memoization planner that selects the minimal-cost task subset
    that satisfies required outputs and dependencies.
    """

    def __init__(self, cache_size: int = 1000):
        self.cache_size = cache_size
        self._cost_cache: Dict[str, float] = {}
        self._req_cache: Dict[str, List[str]] = {}

        if DSPY_AVAILABLE:
            self._requirement_infer = dspy.ChainOfThought(GoalRequirementSignature)
            self._cost_estimator = dspy.ChainOfThought(TaskCostEstimateSignature)
        else:
            self._requirement_infer = None
            self._cost_estimator = None

        logger.info("🧮 OptimalTaskPlanner initialized (DP + memoization)")

    def optimize_plan(
        self,
        plan: TaskPlan,
        goal: str,
        context: str = ""
    ) -> OptimizationResult:
        """
        Optimize a TaskPlan using DP + memoization to minimize total time and steps.
        """
        if not (DSPY_AVAILABLE and self._requirement_infer and self._cost_estimator):
            return OptimizationResult(
                optimized_plan=None,
                success=False,
                reason="LLM unavailable for cost estimation and goal requirements"
            )

        try:
            required_outputs = self._infer_required_outputs(plan, goal, context)
            if not required_outputs:
                return OptimizationResult(
                    optimized_plan=None,
                    success=False,
                    reason="No required outputs inferred (explicit uncertainty)",
                    required_outputs=[]
                )

            # Compute dependency closures and costs
            task_map = {t.task_id: t for t in plan.tasks}
            closure_map = self._compute_dependency_closures(task_map)

            task_costs = self._estimate_costs(plan.tasks, context)
            if not task_costs:
                return OptimizationResult(
                    optimized_plan=None,
                    success=False,
                    reason="Cost estimation failed (explicit uncertainty)",
                    required_outputs=required_outputs
                )

            # Build masks for DP
            output_index = {o: i for i, o in enumerate(required_outputs)}
            task_options = self._build_task_options(
                task_map=task_map,
                closure_map=closure_map,
                output_index=output_index,
                task_costs=task_costs
            )

            # DP over output coverage
            best = self._dp_min_cost(task_options, len(required_outputs))
            if best is None:
                return OptimizationResult(
                    optimized_plan=None,
                    success=False,
                    reason="DP optimization could not cover required outputs",
                    required_outputs=required_outputs
                )

            total_cost, selected_task_ids = best
            optimized_tasks = [task_map[tid] for tid in selected_task_ids if tid in task_map]
            optimized_plan = TaskPlan(
                tasks=self._topological_filter(plan, set(selected_task_ids)),
                reasoning=f"DP-optimized for minimal time ({total_cost:.1f}s)",
                decomposition_method=plan.decomposition_method
            )

            return OptimizationResult(
                optimized_plan=optimized_plan,
                success=True,
                reason="DP optimization succeeded",
                selected_task_ids=selected_task_ids,
                estimated_total_seconds=total_cost,
                required_outputs=required_outputs
            )
        except Exception as e:
            logger.warning(f"OptimalTaskPlanner failed: {e}")
            return OptimizationResult(
                optimized_plan=None,
                success=False,
                reason=f"Optimization error: {e}"
            )

    # ---------------------------------------------------------------------
    # Required outputs inference (LLM-based)
    # ---------------------------------------------------------------------

    def _infer_required_outputs(self, plan: TaskPlan, goal: str, context: str) -> List[str]:
        cache_key = self._hash_key("req", goal, json.dumps(plan.to_dict(), default=str), context)
        if cache_key in self._req_cache:
            return self._req_cache[cache_key]

        result = self._requirement_infer(
            goal=goal,
            tasks=json.dumps(plan.to_dict(), default=str),
            context=context or "No additional context"
        )

        raw = str(getattr(result, "required_outputs", "[]"))
        outputs = self._parse_json_list(raw)
        if outputs is None:
            outputs = []

        self._cache_set(self._req_cache, cache_key, outputs)
        return outputs

    # ---------------------------------------------------------------------
    # Cost estimation (LLM-based with memoization)
    # ---------------------------------------------------------------------

    def _estimate_costs(
        self,
        tasks: List[TaskSpec],
        context: str
    ) -> Dict[str, float]:
        costs: Dict[str, float] = {}

        for task in tasks:
            cache_key = self._hash_key(
                "cost",
                task.task_id,
                task.description,
                json.dumps(task.inputs_needed, default=str),
                json.dumps(task.outputs_produced, default=str),
                context
            )

            if cache_key in self._cost_cache:
                costs[task.task_id] = self._cost_cache[cache_key]
                continue

            result = self._cost_estimator(
                task_description=task.description,
                inputs_needed=json.dumps(task.inputs_needed, default=str),
                outputs_produced=json.dumps(task.outputs_produced, default=str),
                context=context or "No additional context"
            )
            raw = str(getattr(result, "estimated_seconds", "0"))
            value = parse_float_from_string(raw)
            if value is None:
                logger.warning(f"Cost estimate parse failed for task {task.task_id}")
                return {}

            costs[task.task_id] = float(value)
            self._cache_set(self._cost_cache, cache_key, float(value))

        return costs

    # ---------------------------------------------------------------------
    # DP Optimization
    # ---------------------------------------------------------------------

    def _compute_dependency_closures(
        self,
        task_map: Dict[str, TaskSpec]
    ) -> Dict[str, Set[str]]:
        closures: Dict[str, Set[str]] = {}

        def dfs(task_id: str, visiting: Set[str]) -> Set[str]:
            if task_id in closures:
                return closures[task_id]
            if task_id in visiting:
                return set()
            visiting.add(task_id)
            task = task_map.get(task_id)
            deps = set(task.depends_on) if task else set()
            closure = {task_id}
            for dep in deps:
                closure |= dfs(dep, visiting)
            visiting.remove(task_id)
            closures[task_id] = closure
            return closure

        for tid in task_map:
            dfs(tid, set())
        return closures

    def _build_task_options(
        self,
        task_map: Dict[str, TaskSpec],
        closure_map: Dict[str, Set[str]],
        output_index: Dict[str, int],
        task_costs: Dict[str, float]
    ) -> List[Tuple[int, float, Set[str]]]:
        options = []
        for task_id, task in task_map.items():
            closure = closure_map.get(task_id, {task_id})
            mask = 0
            for tid in closure:
                t = task_map.get(tid)
                if not t:
                    continue
                for out in t.outputs_produced:
                    if out in output_index:
                        mask |= 1 << output_index[out]
            cost = sum(task_costs.get(tid, 0.0) for tid in closure)
            options.append((mask, cost, closure))
        return options

    def _dp_min_cost(
        self,
        options: List[Tuple[int, float, Set[str]]],
        output_count: int
    ) -> Optional[Tuple[float, List[str]]]:
        target_mask = (1 << output_count) - 1
        dp: Dict[int, Tuple[float, Set[str]]] = {0: (0.0, set())}

        for mask, cost, tasks in options:
            if mask == 0:
                continue
            updates: Dict[int, Tuple[float, Set[str]]] = {}
            for existing_mask, (existing_cost, existing_tasks) in dp.items():
                new_mask = existing_mask | mask
                new_cost = existing_cost + cost
                new_tasks = existing_tasks | tasks
                prev = dp.get(new_mask)
                if prev is None or new_cost < prev[0] or (
                    new_cost == prev[0] and len(new_tasks) < len(prev[1])
                ):
                    updates[new_mask] = (new_cost, new_tasks)
            dp.update(updates)

        if target_mask not in dp:
            return None

        total_cost, tasks = dp[target_mask]
        return total_cost, sorted(tasks)

    # ---------------------------------------------------------------------
    # Utilities
    # ---------------------------------------------------------------------

    def _topological_filter(self, plan: TaskPlan, selected: Set[str]) -> List[TaskSpec]:
        order = plan.get_topological_order()
        task_map = {t.task_id: t for t in plan.tasks}
        return [task_map[tid] for tid in order if tid in selected]

    def _parse_json_list(self, raw: str) -> Optional[List[str]]:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(x) for x in parsed if isinstance(x, (str, int, float))]
        except Exception:
            return None
        return None

    def _hash_key(self, *parts: str) -> str:
        data = "|".join(str(p) for p in parts)
        return hashlib.sha256(data.encode("utf-8")).hexdigest()[:24]

    def _cache_set(self, cache: Dict[str, Any], key: str, value: Any) -> None:
        if len(cache) >= self.cache_size:
            # Drop an arbitrary entry to avoid unbounded growth
            cache.pop(next(iter(cache)))
        cache[key] = value


__all__ = [
    "OptimalTaskPlanner",
    "OptimizationResult"
]

