"""
Research Need Inference Module - LLM-based domain detection.

This module replaces hardcoded keyword-based domain detection with
LLM reasoning via DSPy signatures.

A-Team Consensus (2026-01-28): NO HARDCODING, USE LLM INFERENCE.

Approved by: Turing, Silver, Sutton, Shannon, von Neumann, Aristotle,
DSPy Author, OpenAI Agents Team, Anthropic Engineer, All A-Team members.
"""

import json
import logging
from typing import Any, Dict, List

try:
    import dspy
except ImportError:
    dspy = None
    logging.warning("DSPy not available - research need inference disabled")

logger = logging.getLogger(__name__)


class InferResearchNeeds(dspy.Signature) if dspy else object:
    """
    Infer what research is needed for a terminal task goal.
    
    This is a GENERIC inference task - no hardcoded domains.
    The LLM reasons about the goal and determines what needs research.
    
    A-Team Consensus: This approach is universal and doesn't require
    maintaining keyword lists or domain enumerations.
    """
    
    goal = dspy.InputField(
        desc="The terminal task goal that needs to be accomplished"
    ) if dspy else None
    
    research_needs = dspy.OutputField(
        desc="""JSON array of research needs inferred from the goal.

Analyze the goal deeply and determine:
1. What technical domains are involved?
2. What libraries or tools might be needed?
3. What knowledge gaps exist?
4. What research would help solve this?

Be comprehensive but not exhaustive. Focus on CRITICAL needs.

Format:
[
    {
        "domain": "descriptive domain name",
        "reason": "why this domain is relevant to the goal",
        "research_query": "specific question to research",
        "priority": "critical" | "high" | "medium"
    }
]

EXAMPLES:

Goal: "Extract data from CSV and generate bar chart"
Output: [
    {
        "domain": "data_processing",
        "reason": "Need to parse and manipulate CSV data",
        "research_query": "Python libraries for CSV parsing and data manipulation",
        "priority": "critical"
    },
    {
        "domain": "visualization",
        "reason": "Need to generate bar chart from data",
        "research_query": "Python libraries for creating bar charts and plots",
        "priority": "critical"
    }
]

Goal: "Find best move in chess puzzle image"
Output: [
    {
        "domain": "image_processing",
        "reason": "Need to load and process image file",
        "research_query": "Python libraries for image loading and processing",
        "priority": "critical"
    },
    {
        "domain": "chess_logic",
        "reason": "Need to analyze chess positions and find best moves",
        "research_query": "Python libraries for chess board representation and move analysis",
        "priority": "critical"
    },
    {
        "domain": "optical_recognition",
        "reason": "May need to recognize chess pieces from image",
        "research_query": "Methods for detecting and recognizing chess pieces in images",
        "priority": "high"
    }
]

Goal: "Compile C program with AddressSanitizer and run tests"
Output: [
    {
        "domain": "build_systems",
        "reason": "Need to compile C code with specific flags",
        "research_query": "How to use AddressSanitizer with GCC or Clang",
        "priority": "critical"
    },
    {
        "domain": "testing",
        "reason": "Need to run test suite",
        "research_query": "C testing frameworks and test execution",
        "priority": "medium"
    }
]

Goal: "Build quantum circuit with 5 qubits and apply Hadamard gates"
Output: [
    {
        "domain": "quantum_computing",
        "reason": "Need to construct and simulate quantum circuits",
        "research_query": "Python quantum computing libraries and frameworks",
        "priority": "critical"
    },
    {
        "domain": "quantum_gates",
        "reason": "Need to apply Hadamard and other quantum gates",
        "research_query": "How to apply quantum gates in Python frameworks",
        "priority": "critical"
    }
]

IMPORTANT:
- NO assumptions about specific libraries (don't assume 'pandas' or 'opencv')
- Infer domains from goal semantics, not keywords
- Be specific about WHY each domain is relevant
- Prioritize based on criticality to goal success
- Work for ANY domain, even ones you've never seen before
- If uncertain, add research need - better to research too much than too little
"""
    ) if dspy else None


class ResearchNeedInferenceModule(dspy.Module) if dspy else object:
    """
    Module that uses DSPy to infer research needs.
    
    This replaces the hardcoded keyword-based approach that violated
    the generic framework principle.
    
    Usage:
        module = ResearchNeedInferenceModule()
        result = module(goal="Build quantum circuit...")
        needs = json.loads(result.research_needs)
    """
    
    def __init__(self):
        if not dspy:
            raise ImportError("DSPy is required for research need inference")
        super().__init__()
        self.infer = dspy.ChainOfThought(InferResearchNeeds)
        logger.info("✅ ResearchNeedInferenceModule initialized (LLM-based, no keywords)")
    
    def forward(self, goal: str) -> Any:
        """
        Infer research needs for a goal using LLM reasoning.
        
        Args:
            goal: Terminal task goal
            
        Returns:
            Prediction with research_needs field (JSON string)
        """
        logger.info(f"🔍 Inferring research needs for: {goal[:100]}...")
        
        try:
            result = self.infer(goal=goal)
            
            # Validate JSON
            try:
                needs = json.loads(result.research_needs)
                logger.info(f"✅ Inferred {len(needs)} research needs")
                for i, need in enumerate(needs, 1):
                    logger.debug(f"   {i}. {need.get('domain', 'unknown')} - {need.get('research_query', 'N/A')}")
            except json.JSONDecodeError:
                logger.warning(f"⚠️ Research needs not valid JSON: {result.research_needs}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to infer research needs: {e}")
            # Return empty list on failure rather than crashing
            class EmptyResult:
                research_needs = "[]"
            return EmptyResult()


def infer_research_needs_from_goal(goal: str) -> List[Dict[str, Any]]:
    """
    Convenience function to infer research needs from a goal.
    
    This is the main entry point for the Conductor to use.
    
    Args:
        goal: The terminal task goal string
        
    Returns:
        List of research need dicts
        
    Example:
        >>> needs = infer_research_needs_from_goal("Parse XML and generate PDF")
        >>> print(needs[0]['domain'])
        'xml_parsing'
    """
    if not dspy:
        logger.warning("⚠️ DSPy not available - cannot infer research needs")
        return []
    
    try:
        module = ResearchNeedInferenceModule()
        result = module(goal=goal)
        needs = json.loads(result.research_needs)
        return needs if isinstance(needs, list) else []
    except Exception as e:
        logger.error(f"❌ Research need inference failed: {e}")
        return []


# Export main components
__all__ = [
    'InferResearchNeeds',
    'ResearchNeedInferenceModule',
    'infer_research_needs_from_goal'
]
