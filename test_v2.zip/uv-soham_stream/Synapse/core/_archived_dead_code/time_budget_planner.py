"""
TimeBudgetPlanner - Dynamic, Generic Time Allocation
====================================================

Goal:
- Plan time budgets dynamically from observed metrics
- No hardcoding of domain or prompts
- LLM-driven budget inference, deterministic validation

This module uses LLM to propose:
1) Phase allocation percentages (exploration, validation, mvp, refinement, verification)
2) Per-actor timeout overrides (optional)

If LLM is unavailable or output invalid, returns explicit uncertainty.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, AsyncGenerator
import json
import logging

from .number_parsing import parse_float_from_string

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


if DSPY_AVAILABLE:
    class TimeBudgetPlanningSignature(dspy.Signature):
        """Plan time budgets dynamically from metrics."""
        total_timeout_seconds = dspy.InputField(desc="Total timeout budget in seconds")
        actor_metrics = dspy.InputField(desc="JSON: per-actor metrics (avg/p95/timeout rate)")
        task_context = dspy.InputField(desc="Task context, complexity hints, plan size")
        global_metrics = dspy.InputField(desc="JSON: global runtime metrics")

        budget_plan = dspy.OutputField(
            desc=(
                "JSON object with keys: "
                "phase_allocations (percentages sum to 1.0), "
                "actor_timeouts (optional per-actor seconds)"
            )
        )
        reasoning = dspy.OutputField(desc="Why this budget plan is appropriate")


@dataclass
class TimeBudgetPlan:
    phase_allocations: Dict[str, float] = field(default_factory=dict)
    actor_timeouts: Dict[str, float] = field(default_factory=dict)
    reasoning: str = ""


@dataclass
class TimeBudgetResult:
    success: bool
    plan: Optional[TimeBudgetPlan] = None
    reason: str = ""


class TimeBudgetPlanner:
    """
    LLM-based dynamic time budgeting with strict validation.
    """

    def __init__(self):
        if DSPY_AVAILABLE:
            self._planner = dspy.ChainOfThought(TimeBudgetPlanningSignature)
        else:
            self._planner = None
        logger.info("⏳ TimeBudgetPlanner initialized")

    async def plan_stream(
        self,
        total_timeout_seconds: float,
        actor_metrics: Dict[str, Any],
        task_context: Dict[str, Any],
        global_metrics: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], TimeBudgetResult]:
        """
        Plan time budgets dynamically from observed metrics with event streaming.
        
        Yields:
            Event dictionaries with module and conversational message
        
        Returns:
            TimeBudgetResult with success status and plan
        """
        yield {"module": "Synapse.core.time_budget_planner", "message": f"I am planning time budgets with total timeout {total_timeout_seconds} seconds"}
        if not self._planner:
            yield {"module": "Synapse.core.time_budget_planner", "message": "I noticed LLM is not available for time budgeting"}
            result = TimeBudgetResult(success=False, reason="LLM unavailable for time budgeting")
            yield {"type": "result", "result": result}
            return

        try:
            yield {"module": "Synapse.core.time_budget_planner", "message": "I am calling the LLM planner to generate a time budget plan"}
            result = self._planner(
                total_timeout_seconds=float(total_timeout_seconds),
                actor_metrics=json.dumps(actor_metrics, default=str),
                task_context=json.dumps(task_context, default=str),
                global_metrics=json.dumps(global_metrics, default=str)
            )
            raw = str(getattr(result, "budget_plan", "")).strip()
            yield {"module": "Synapse.core.time_budget_planner", "message": "I received a response from the LLM planner, parsing it now"}
            plan = self._parse_plan_json(raw)
            if not plan:
                yield {"module": "Synapse.core.time_budget_planner", "message": "I could not parse the budget plan JSON, it appears invalid"}
                result = TimeBudgetResult(success=False, reason="Budget plan JSON invalid")
                yield {"type": "result", "result": result}
                return
            plan.reasoning = str(getattr(result, "reasoning", ""))
            yield {"module": "Synapse.core.time_budget_planner", "message": f"I successfully created a time budget plan with phase allocations: {list(plan.phase_allocations.keys())}"}
            final_result = TimeBudgetResult(success=True, plan=plan, reason="ok")
            yield {"type": "result", "result": final_result}
            return
        except Exception as e:
            yield {"module": "Synapse.core.time_budget_planner", "message": f"I encountered an error during budget planning: {e}"}
            error_result = TimeBudgetResult(success=False, reason=f"Budget planning failed: {e}")
            yield {"type": "result", "result": error_result}
            return
    
    def plan(
        self,
        total_timeout_seconds: float,
        actor_metrics: Dict[str, Any],
        task_context: Dict[str, Any],
        global_metrics: Dict[str, Any]
    ) -> TimeBudgetResult:
        """Synchronous wrapper for plan_stream."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise RuntimeError("Use plan_stream in async context")
            else:
                async def _get_result():
                    result = None
                    async for event in self.plan_stream(total_timeout_seconds, actor_metrics, task_context, global_metrics):
                        if event.get("type") == "result":
                            result = event.get("result")
                    return result
                return loop.run_until_complete(_get_result())
        except RuntimeError:
            return asyncio.run(self._sync_plan(total_timeout_seconds, actor_metrics, task_context, global_metrics))
    
    async def _sync_plan(
        self,
        total_timeout_seconds: float,
        actor_metrics: Dict[str, Any],
        task_context: Dict[str, Any],
        global_metrics: Dict[str, Any]
    ) -> TimeBudgetResult:
        """Helper for sync wrapper."""
        result = None
        async for event in self.plan_stream(total_timeout_seconds, actor_metrics, task_context, global_metrics):
            if event.get("type") == "result":
                result = event.get("result")
        return result if result is not None else TimeBudgetResult(success=False, reason="No result from planning")

    def _parse_plan_json(self, raw: str) -> Optional[TimeBudgetPlan]:
        try:
            data = json.loads(raw)
        except Exception:
            return None

        phase_allocations = {}
        actor_timeouts = {}

        phases = data.get("phase_allocations", {})
        for key, value in phases.items():
            parsed = parse_float_from_string(str(value))
            if parsed is None:
                return None
            parsed_val = float(parsed)
            if parsed_val < 0:
                return None
            phase_allocations[str(key)] = parsed_val

        if phase_allocations:
            total = sum(phase_allocations.values())
            if total <= 0:
                return None
            # Normalize to sum to 1.0 (deterministic, no heuristics)
            for key in list(phase_allocations.keys()):
                phase_allocations[key] = phase_allocations[key] / total

        per_actor = data.get("actor_timeouts", {})
        for key, value in per_actor.items():
            parsed = parse_float_from_string(str(value))
            if parsed is None:
                return None
            parsed_val = float(parsed)
            if parsed_val <= 0:
                continue
            actor_timeouts[str(key)] = parsed_val

        return TimeBudgetPlan(
            phase_allocations=phase_allocations,
            actor_timeouts=actor_timeouts
        )


__all__ = [
    "TimeBudgetPlanner",
    "TimeBudgetPlan",
    "TimeBudgetResult"
]

