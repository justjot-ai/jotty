"""
🔬 Unified Chunker - Token-Accurate Content Chunking
====================================================

A-Team Approved: The CANONICAL chunker for all of Synapse.

Extracted from `llm_rag.py` (SOTA implementation) and made reusable
for ALL chunking needs across the system.

Key Features:
1. Token-accurate chunking (binary search, NO heuristics)
2. Sliding window with configurable overlap
3. LLM-based relevance scoring (semantic, not keyword)
4. Budget-aware chunk selection
5. Query/goal-aware (not blind chunking)
6. Generic for ANY content type

Usage:
    ```python
    chunker = UnifiedChunker(chunk_size=16000, overlap=100)
    
    # Chunk content
    chunks = chunker.chunk_content(large_content, "source_key")
    
    # Chunk and select relevant (query-aware)
    selected = await chunker.chunk_and_select(
        content=large_content,
        query="What caused the error?",
        goal="Debug the system",
        max_tokens=10000
    )
    ```

A-Team Consensus: This is the ONLY chunker implementation.
All other chunkers are deprecated or deleted.
"""

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

import logging
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import json

logger = logging.getLogger(__name__)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class ContentChunk:
    """
    A chunk of content with metadata.
    
    Attributes:
        content: The actual chunk text
        chunk_index: Position in the sequence (0-based)
        total_chunks: Total number of chunks
        source_key: Identifier for the source document
        token_count: Accurate token count for this chunk
        start_char: Starting character position in original content
        end_char: Ending character position in original content
        has_overlap_before: Whether this chunk overlaps with previous
        has_overlap_after: Whether this chunk overlaps with next
        relevance_score: LLM-assigned relevance score (0.0-1.0)
    """
    content: str
    chunk_index: int
    total_chunks: int
    source_key: str
    token_count: int
    
    # Position info
    start_char: int
    end_char: int
    
    # Overlap info (for reconstruction)
    has_overlap_before: bool = False
    has_overlap_after: bool = False
    
    # Relevance (set by scorer)
    relevance_score: float = 0.0


# =============================================================================
# SLIDING WINDOW CHUNKER (Token-Accurate)
# =============================================================================

class SlidingWindowChunker:
    """
    Token-accurate chunking using binary search.
    
    A-Team Approved: NO heuristic "// 4" guessing!
    Uses actual token counting for precision.
    
    Features:
    - Binary search for exact token boundaries
    - Configurable overlap for context preservation
    - Handles edge cases (empty, single chunk, etc.)
    - Metadata tracking for reconstruction
    """
    
    def __init__(self, chunk_size: int = 16000, overlap: int = 100):
        """
        Initialize chunker.
        
        Args:
            chunk_size: Target tokens per chunk (default: 16000 - A-TEAM minimum 16k)
            overlap: Overlap tokens between chunks (default: 100)
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
        logger.debug(f"🔧 SlidingWindowChunker initialized (chunk_size={chunk_size}, overlap={overlap})")
    
    def chunk_content(self, content: str, source_key: str) -> List[ContentChunk]:
        """
        Chunk content into token-accurate segments.
        
        Args:
            content: The content to chunk
            source_key: Identifier for this content
        
        Returns:
            List of ContentChunk objects
        """
        if not content:
            return []
        
        from .token_utils import count_tokens_accurate
        
        # If content fits in one chunk, return as-is
        total_tokens = count_tokens_accurate(content)
        if total_tokens <= self.chunk_size:
            return [ContentChunk(
                content=content,
                chunk_index=0,
                total_chunks=1,
                source_key=source_key,
                token_count=total_tokens,
                start_char=0,
                end_char=len(content),
                has_overlap_before=False,
                has_overlap_after=False
            )]
        
        # Need chunking
        chunks: List[ContentChunk] = []
        start = 0
        chunk_index = 0
        
        while start < len(content):
            # Binary search for chunk end that fits token budget
            end = self._find_chunk_end(content, start, self.chunk_size)
            chunk_content = content[start:end]
            
            chunks.append(ContentChunk(
                content=chunk_content,
                chunk_index=chunk_index,
                total_chunks=-1,  # Will be updated after all chunks created
                source_key=source_key,
                token_count=count_tokens_accurate(chunk_content),
                start_char=start,
                end_char=end,
                has_overlap_before=start > 0,
                has_overlap_after=end < len(content)
            ))
            
            # Move start forward with overlap
            if self.overlap > 0:
                overlap_chars = self._chars_for_tokens(chunk_content, self.overlap)
                start = max(end - overlap_chars, start + 1)  # Ensure progress
            else:
                start = end
            
            chunk_index += 1
        
        # Update total_chunks for all chunks
        for chunk in chunks:
            chunk.total_chunks = len(chunks)
        
        logger.info(f"📄 Chunked content: {len(content)} chars → {len(chunks)} chunks (~{total_tokens} tokens)")
        return chunks
    
    def _find_chunk_end(self, content: str, start: int, target_tokens: int) -> int:
        """
        Binary search for character position that fits target_tokens.
        
        A-Team Approved: This is the SOTA approach for token-accurate chunking.
        """
        from .token_utils import count_tokens_accurate
        
        low = start + 1
        high = len(content)
        best = low
        
        while low <= high:
            mid = (low + high) // 2
            tokens = count_tokens_accurate(content[start:mid])
            
            if tokens <= target_tokens:
                best = mid
                low = mid + 1
            else:
                high = mid - 1
        
        return best
    
    def _chars_for_tokens(self, text: str, target_tokens: int) -> int:
        """
        Binary search for character count that equals target_tokens.
        
        Used for calculating overlap.
        """
        from .token_utils import count_tokens_accurate
        
        if target_tokens <= 0:
            return 0
        
        low = 0
        high = len(text)
        best = 0
        
        while low <= high:
            mid = (low + high) // 2
            # Count tokens from END of text (for overlap calculation)
            tokens = count_tokens_accurate(text[-mid:] if mid > 0 else "")
            
            if tokens <= target_tokens:
                best = mid
                low = mid + 1
            else:
                high = mid - 1
        
        return best


# =============================================================================
# LLM RELEVANCE SCORER (Semantic, not Keyword)
# =============================================================================

class RelevanceSignature(dspy.Signature):
    """
    Score relevance of chunks to a query using pure semantic understanding.
    
    NO KEYWORD MATCHING - works with:
    - Any language (English, Japanese, Chinese, mixed)
    - Code snippets (Python, SQL, any syntax)
    - Technical jargon
    - Synonyms and paraphrases
    
    CRITICAL: The 'scores' output MUST be valid JSON format.
    Example: {"0": 0.8, "1": 0.5, "2": 0.9}
    """
    
    query: str = dspy.InputField(desc="The current query/goal - can be ANY language or format")
    chunk_batch: str = dspy.InputField(desc="Batch of chunks to score (JSON)")
    context_hints: str = dspy.InputField(desc="Additional context about the task")
    
    reasoning: str = dspy.OutputField(desc="Step-by-step semantic analysis of each chunk's relevance")
    scores: str = dspy.OutputField(
        desc="JSON dict mapping chunk_index to relevance score 0.0-1.0. "
        "MUST be valid JSON. Example: {\"0\": 0.8, \"1\": 0.5, \"2\": 0.9}. "
        "DO NOT include any text before or after the JSON object."
    )


class LLMRelevanceScorer:
    """
    Pure LLM semantic scoring for chunk relevance.
    
    A-Team Approved: NO embeddings, NO keywords, PURE semantic understanding.
    
    Why LLM over embeddings:
    1. Embeddings fail on nuanced/technical text
    2. Can't reason about relevance
    3. No interpretability
    4. Context-dependent meaning missed
    
    Why LLM over keywords:
    1. Works with any language
    2. Understands code and technical terms
    3. Handles synonyms and paraphrases
    4. Semantic understanding, not string matching
    """
    
    def __init__(self, window_size: int = 10, use_cot: bool = True):
        """
        Initialize scorer.
        
        Args:
            window_size: Number of chunks to score per LLM call (batch size)
            use_cot: Use Chain-of-Thought for better reasoning
        """
        self.window_size = window_size
        self.use_cot = use_cot
        self.failure_count = 0  # Track consecutive failures
        self.max_failures_before_fallback = 5  # Switch to heuristic after 5 failures
        
        if not DSPY_AVAILABLE:
            logger.warning("⚠️ DSPy not available, LLM scoring will be disabled")
            self.scorer = None
            return
        
        # Create the scorer agent
        if use_cot:
            self.scorer = dspy.ChainOfThought(RelevanceSignature)
        else:
            self.scorer = dspy.Predict(RelevanceSignature)
        
        logger.debug(f"🔧 LLMRelevanceScorer initialized (window={window_size}, cot={use_cot})")
    
    def _heuristic_score(self, query: str, chunks: List[ContentChunk]) -> Dict[int, float]:
        """
        Fallback heuristic scoring when LLM fails.
        
        Uses simple rules:
        1. Earlier chunks get slightly higher scores (recency bias)
        2. Chunks with more content get slightly higher scores
        3. All scores in 0.4-0.6 range to maintain some variance
        
        This is NOT semantic, but better than uniform 0.5 scores.
        """
        scores = {}
        total = len(chunks)
        
        for chunk in chunks:
            # Position score: earlier chunks slightly preferred (0.1 to 0.0)
            position_score = 0.1 * (1.0 - chunk.chunk_index / max(total, 1))
            
            # Length score: longer chunks slightly preferred (0.0 to 0.1)
            avg_length = sum(c.token_count for c in chunks) / len(chunks)
            length_ratio = min(chunk.token_count / max(avg_length, 1), 2.0) / 2.0
            length_score = 0.1 * length_ratio
            
            # Base score of 0.4, plus bonuses
            scores[chunk.chunk_index] = 0.4 + position_score + length_score
        
        logger.info(f"📊 Using heuristic scoring (LLM unavailable)")
        return scores
    
    def score_chunks(
        self,
        query: str,
        chunks: List[ContentChunk],
        context_hints: str = ""
    ) -> Dict[int, float]:
        """
        Score chunks using PURE LLM semantic understanding.
        
        Args:
            query: The query/goal to score relevance against
            chunks: List of chunks to score
            context_hints: Additional context (optional)
        
        Returns:
            Dictionary mapping chunk_index → relevance score (0.0-1.0)
        """
        if not self.scorer:
            # Fallback: use heuristic scoring
            logger.warning("⚠️ No LLM scorer available, using heuristic scoring")
            return self._heuristic_score(query, chunks)
        
        # Check if we should skip LLM due to repeated failures
        if self.failure_count >= self.max_failures_before_fallback:
            logger.warning(
                f"⚠️ Too many LLM scoring failures ({self.failure_count}), "
                f"switching to heuristic scoring for this session"
            )
            return self._heuristic_score(query, chunks)
        
        all_scores = {}
        
        # Process in windows (batches)
        for i in range(0, len(chunks), self.window_size):
            batch = chunks[i:i + self.window_size]
            
            # Prepare batch for LLM
            batch_data = [
                {
                    "chunk_index": chunk.chunk_index,
                    "content_preview": chunk.content[:500],  # First 500 chars
                    "token_count": chunk.token_count,
                    "position": f"{chunk.chunk_index + 1}/{chunk.total_chunks}"
                }
                for chunk in batch
            ]
            
            try:
                result = self.scorer(
                    query=query,
                    chunk_batch=json.dumps(batch_data, ensure_ascii=False),
                    context_hints=context_hints
                )
                
                # Parse scores with improved error handling
                scores_json = getattr(result, "scores", "{}")
                
                # Debug logging for empty responses
                if not scores_json or scores_json.strip() == "":
                    self.failure_count += 1
                    logger.warning(
                        f"⚠️ LLM returned empty scores for batch {i} "
                        f"(failure {self.failure_count}/{self.max_failures_before_fallback})"
                    )
                    # Assign heuristic scores to this batch
                    batch_scores = self._heuristic_score(query, batch)
                    all_scores.update(batch_scores)
                    continue
                
                # Try parsing JSON
                try:
                    scores = json.loads(scores_json) if isinstance(scores_json, str) else scores_json
                    # Success! Reset failure count
                    self.failure_count = max(0, self.failure_count - 1)
                except json.JSONDecodeError as json_err:
                    self.failure_count += 1
                    logger.warning(
                        f"⚠️ JSON parsing failed for batch {i} "
                        f"(failure {self.failure_count}/{self.max_failures_before_fallback}): {json_err}\n"
                        f"   Raw response: {scores_json[:200]}..."
                    )
                    # Assign heuristic scores to this batch
                    batch_scores = self._heuristic_score(query, batch)
                    all_scores.update(batch_scores)
                    continue
                
                # Convert string keys to int and add to all_scores
                for key, value in scores.items():
                    try:
                        chunk_index = int(key) if isinstance(key, str) else key
                        score = float(value)
                        all_scores[chunk_index] = max(0.0, min(1.0, score))  # Clamp 0-1
                    except (ValueError, TypeError) as e:
                        logger.debug(f"Could not parse score for chunk {key}: {e}")
                        # Use the chunk's index from the batch
                        for chunk in batch:
                            if str(chunk.chunk_index) == str(key) or chunk.chunk_index == key:
                                all_scores[chunk.chunk_index] = 0.5  # Neutral fallback
                                break
            
            except Exception as e:
                self.failure_count += 1
                logger.warning(
                    f"⚠️ LLM scoring failed for batch {i} "
                    f"(failure {self.failure_count}/{self.max_failures_before_fallback}): "
                    f"{type(e).__name__}: {e}"
                )
                # Assign heuristic scores to this batch
                batch_scores = self._heuristic_score(query, batch)
                all_scores.update(batch_scores)
        
        return all_scores
    
    async def score_chunks_async(
        self,
        query: str,
        chunks: List[ContentChunk],
        context_hints: str = ""
    ) -> Dict[int, float]:
        """
        Async version of score_chunks (for async workflows).
        
        Note: Currently wraps sync version. True async scoring requires DSPy async support.
        """
        return self.score_chunks(query, chunks, context_hints)


# =============================================================================
# UNIFIED CHUNKER (Coordinator)
# =============================================================================

class UnifiedChunker:
    """
    Unified chunker that combines token-accurate chunking with LLM-based selection.
    
    A-Team Approved: This is the CANONICAL chunker for ALL of Synapse.
    
    Use this for:
    - Terminal output (huge logs)
    - Web scraping results (large HTML)
    - File contents (large documents)
    - Memory retrieval (many entries)
    - Actor outputs (verbose results)
    
    NO HARDCODING - works for everything.
    """
    
    def __init__(
        self,
        chunk_size: int = 16000,  # 🔴 A-TEAM FIX: 16k minimum per user requirement
        overlap: int = 100,  # 🔴 A-TEAM FIX: Increased overlap for better context preservation
        scorer_window: int = 10,
        use_cot: bool = True
    ):
        """
        Initialize unified chunker.
        
        Args:
            chunk_size: Target tokens per chunk (default: 16000 - A-TEAM minimum 16k)
            overlap: Overlap tokens between chunks (default: 100 for better context)
            scorer_window: Batch size for LLM scoring
            use_cot: Use Chain-of-Thought for relevance scoring
        """
        self.chunker = SlidingWindowChunker(chunk_size=chunk_size, overlap=overlap)
        self.scorer = LLMRelevanceScorer(window_size=scorer_window, use_cot=use_cot)
        
        logger.info(f"🔧 UnifiedChunker initialized (chunk_size={chunk_size}, overlap={overlap})")
    
    def chunk_content(self, content: str, source_key: str = "default") -> List[ContentChunk]:
        """
        Chunk content into token-accurate segments.
        
        This is the basic chunking operation (no relevance scoring).
        
        Args:
            content: Content to chunk
            source_key: Identifier for the content
        
        Returns:
            List of ContentChunk objects
        """
        return self.chunker.chunk_content(content, source_key)
    
    async def chunk_and_select(
        self,
        content: str,
        query: str,
        goal: Optional[str] = None,
        max_tokens: int = 10000,
        context_hints: str = "",
        source_key: str = "default"
    ) -> str:
        """
        Chunk content, score by relevance, and select within budget.
        
        This is the QUERY-AWARE operation (recommended for most use cases).
        
        Args:
            content: Content to process
            query: Query to score relevance against
            goal: Overall goal (optional, for context)
            max_tokens: Maximum tokens in final result
            context_hints: Additional context for scoring
            source_key: Identifier for the content
        
        Returns:
            Combined content from most relevant chunks within budget
        """
        # Step 1: Chunk
        chunks = self.chunker.chunk_content(content, source_key)
        
        if not chunks:
            return ""
        
        # If all chunks fit within budget, return all
        total_tokens = sum(c.token_count for c in chunks)
        if total_tokens <= max_tokens:
            logger.info(f"✅ All {len(chunks)} chunks fit within budget ({total_tokens}/{max_tokens} tokens)")
            return content
        
        # Step 2: Score relevance
        context = f"Query: {query}"
        if goal:
            context += f"\nGoal: {goal}"
        if context_hints:
            context += f"\n{context_hints}"
        
        scores = await self.scorer.score_chunks_async(query, chunks, context)
        
        # Update chunk relevance scores
        for chunk in chunks:
            chunk.relevance_score = scores.get(chunk.chunk_index, 0.5)
        
        # Step 3: Select within budget (greedy by relevance)
        selected_chunks = []
        tokens_used = 0
        
        # Sort by relevance (descending)
        sorted_chunks = sorted(chunks, key=lambda c: c.relevance_score, reverse=True)
        
        for chunk in sorted_chunks:
            if tokens_used + chunk.token_count <= max_tokens:
                selected_chunks.append(chunk)
                tokens_used += chunk.token_count
        
        # Step 4: Combine in original order
        selected_chunks.sort(key=lambda c: c.chunk_index)
        
        logger.info(
            f"📊 Selected {len(selected_chunks)}/{len(chunks)} chunks "
            f"({tokens_used}/{max_tokens} tokens, {int(tokens_used/max_tokens*100)}% of budget)"
        )
        
        # Combine with markers
        combined_parts = []
        for chunk in selected_chunks:
            marker = f"\n\n--- Chunk {chunk.chunk_index + 1}/{chunk.total_chunks} (relevance: {chunk.relevance_score:.2f}) ---\n"
            combined_parts.append(marker + chunk.content)
        
        return "\n".join(combined_parts)
    
    def chunk_and_select_sync(
        self,
        content: str,
        query: str,
        goal: Optional[str] = None,
        max_tokens: int = 10000,
        context_hints: str = "",
        source_key: str = "default"
    ) -> str:
        """
        Sync version of chunk_and_select (for sync workflows).
        """
        import asyncio
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        return loop.run_until_complete(
            self.chunk_and_select(content, query, goal, max_tokens, context_hints, source_key)
        )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'ContentChunk',
    'SlidingWindowChunker',
    'LLMRelevanceScorer',
    'UnifiedChunker',
]
