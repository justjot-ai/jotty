"""
Synapse v8.0 - Integration Module
================================

A-Team Approved: Ties all components together.

This module ensures:
1. GlobalContextGuard patches ALL DSPy calls
2. AlgorithmicCreditAssigner is used for credit
3. ContextAwareDocumentProcessor handles all file reads
4. All components are properly initialized

Usage:
    from Synapse.core.integration import initialize_synapse
    
    # Initialize with all protections
    synapse_system = initialize_synapse(config)
    
    # Now all DSPy calls are protected, credit is algorithmic, etc.
"""

import logging
from typing import Optional, Dict, Any
from pathlib import Path

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False

from .data_structures import SynapseConfig
from .global_context_guard import (
    GlobalContextGuard, 
    patch_dspy_with_guard,
    unpatch_dspy
)

logger = logging.getLogger(__name__)


class SynapseIntegration:
    """
    Central integration point for all Synapse v8.0 components.
    
    A-Team Fix: Simplified to core functionality after cleanup.
    
    Ensures:
    1. Context overflow protection on ALL LLM calls via GlobalContextGuard
    2. Centralized DSPy patching
    3. Singleton pattern for system-wide integration
    """
    
    _instance: Optional['SynapseIntegration'] = None
    _initialized: bool = False
    
    def __init__(self, config: SynapseConfig = None):
        self.config = config or SynapseConfig()
        
        # Context management - core functionality
        self.context_guard = GlobalContextGuard(
            max_tokens=self.config.max_context_tokens
        )
        
        # Statistics
        self.stats = {
            'dspy_calls': 0,
            'context_overflows_caught': 0,
        }
        
        logger.info("🧠 SynapseIntegration initialized (v10.0 Core Edition)")
    
    @classmethod
    def get_instance(cls, config: SynapseConfig = None) -> 'SynapseIntegration':
        """Get or create singleton instance."""
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance
    
    def patch_dspy(self):
        """
        Patch DSPy to protect all LLM calls from context overflow.
        
        MUST be called before any DSPy operations.
        """
        if not DSPY_AVAILABLE:
            logger.warning("DSPy not available, skipping patch")
            return
        
        patch_dspy_with_guard(self.context_guard)
        logger.info("✅ DSPy patched with GlobalContextGuard")
    
    def unpatch_dspy(self):
        """Remove DSPy patch."""
        unpatch_dspy()
        logger.info("✅ DSPy unpatched")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get integration statistics."""
        return {
            **self.stats,
            'context_guard_stats': self.context_guard.get_statistics()
        }


def initialize_synapse(config: SynapseConfig = None) -> SynapseIntegration:
    """
    Initialize SYNAPSE with all v8.0 protections.
    
    This is the recommended entry point for using SYNAPSE.
    
    Returns:
        SynapseIntegration instance with all components ready.
    """
    integration = SynapseIntegration.get_instance(config)
    
    # Patch DSPy to protect all LLM calls
    integration.patch_dspy()
    
    logger.info("🚀 Synapse v8.0 initialized with full algorithmic protection")
    
    return integration


# Singleton accessor
def get_synapse() -> Optional[SynapseIntegration]:
    """Get existing SYNAPSE integration or None if not initialized."""
    return SynapseIntegration._instance


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'SynapseIntegration',
    'initialize_synapse',
    'get_synapse',
]

