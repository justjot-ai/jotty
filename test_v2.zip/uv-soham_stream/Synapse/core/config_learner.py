"""Learn and update configs based on swarm performance."""
import json
import logging
import time
from pathlib import Path
from typing import Dict, Any, List
import dspy

logger = logging.getLogger(__name__)


class ConfigUpdateSignature(dspy.Signature):
    """Determine config updates based on performance data."""
    
    current_config = dspy.InputField(desc="Current configuration (JSON)")
    performance_data = dspy.InputField(desc="Recent performance metrics (JSON)")
    failure_patterns = dspy.InputField(desc="Common failure patterns")
    success_patterns = dspy.InputField(desc="Common success patterns")
    
    recommended_updates = dspy.OutputField(
        desc="""JSON object of config updates:
        {
            "parameter_name": {
                "current_value": ...,
                "recommended_value": ...,
                "reason": "why this change",
                "confidence": 0.0-1.0,
                "expected_improvement": "percentage or description"
            }
        }
        
        Example:
        {
            "alpha": {
                "current_value": 0.1,
                "recommended_value": 0.05,
                "reason": "Lower learning rate reduces oscillation in Q-values",
                "confidence": 0.85,
                "expected_improvement": "15% reduction in value variance"
            },
            "epsilon": {
                "current_value": 0.1,
                "recommended_value": 0.15,
                "reason": "More exploration needed - success rate plateaued",
                "confidence": 0.75,
                "expected_improvement": "Discover new successful strategies"
            }
        }
        """
    )
    reasoning = dspy.OutputField(desc="Overall reasoning for updates")


class ConfigLearner:
    """Learn optimal configs from swarm performance."""
    
    def __init__(self, config_path: str = None, auto_apply_threshold: float = 0.9):
        self.config_path = Path(config_path) if config_path else None
        self.auto_apply_threshold = auto_apply_threshold  # 🆕 A-TEAM: Conditional auto-apply
        try:
            self.updater = dspy.ChainOfThought(ConfigUpdateSignature)
        except Exception as e:
            logger.warning(f"Failed to initialize ConfigLearner: {e}")
            self.updater = None
        
        self.performance_history = []
        self.min_episodes_for_update = 20
    
    def record_episode(self, config: Dict, performance: Dict):
        """
        Record episode performance.
        
        Args:
            config: Configuration used for this episode
            performance: Performance metrics (success, reward, time, error, etc.)
        """
        self.performance_history.append({
            'config': config,
            'performance': performance,
            'timestamp': time.time()
        })
        
        # Keep only recent history (last 100 episodes)
        if len(self.performance_history) > 100:
            self.performance_history = self.performance_history[-100:]
    
    def should_update_config(self, min_episodes: int = None) -> bool:
        """Check if enough data to update config."""
        threshold = min_episodes if min_episodes is not None else self.min_episodes_for_update
        return len(self.performance_history) >= threshold
    
    def learn_config_updates(self) -> Dict[str, Any]:
        """
        Learn config updates from performance history.
        
        Returns:
            Dict of recommended updates
        """
        if not self.updater:
            logger.warning("Updater not initialized")
            return {}
        
        if not self.should_update_config():
            logger.info(f"Not enough episodes for config learning ({len(self.performance_history)}/{self.min_episodes_for_update})")
            return {}
        
        # Analyze performance
        failure_patterns = self._extract_failure_patterns()
        success_patterns = self._extract_success_patterns()
        
        # Get current config (from most recent episode)
        current_config = self.performance_history[-1]['config'] if self.performance_history else {}
        
        # Get LLM recommendations
        try:
            result = self.updater(
                current_config=json.dumps(current_config, indent=2)[:2000],  # Limit length
                performance_data=json.dumps(self._aggregate_performance(), indent=2),
                failure_patterns=json.dumps(failure_patterns, indent=2)[:1000],
                success_patterns=json.dumps(success_patterns, indent=2)[:1000]
            )
            
            updates = json.loads(result.recommended_updates)
            
            logger.info(f"📊 Config Learning Recommendations:")
            for param, update in updates.items():
                logger.info(f"   {param}: {update.get('current_value')} → {update.get('recommended_value')}")
                logger.info(f"      Reason: {update.get('reason', 'N/A')}")
                logger.info(f"      Confidence: {update.get('confidence', 0):.2f}")
            
            return updates
        except json.JSONDecodeError as e:
            logger.error(f"Config learning JSON parsing failed: {e}")
            return {}
        except Exception as e:
            logger.error(f"Config learning failed: {e}")
            return {}
    
    def apply_updates(self, updates: Dict[str, Any], auto_apply: bool = None, confidence_threshold: float = None):
        """
        Apply config updates.
        
        🆕 A-TEAM: Now uses self.auto_apply_threshold for conditional auto-apply.
        
        Args:
            updates: Updates to apply
            auto_apply: If True, force apply all. If None, use threshold-based decision.
            confidence_threshold: Override default (self.auto_apply_threshold)
        """
        if not updates:
            return
        
        if not self.config_path or not self.config_path.exists():
            logger.warning("No config path specified or file doesn't exist")
            return
        
        # Use instance threshold if not overridden
        threshold = confidence_threshold if confidence_threshold is not None else self.auto_apply_threshold
        
        # Load current config
        try:
            with open(self.config_path) as f:
                config = json.load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            return
        
        # Apply high-confidence updates
        applied = []
        skipped = []
        for param, update in updates.items():
            confidence = update.get('confidence', 0)
            
            # Decide whether to auto-apply
            should_apply = auto_apply if auto_apply is not None else (confidence >= threshold)
            
            if should_apply:
                config[param] = update['recommended_value']
                applied.append(param)
                logger.info(f"✅ AUTO-APPLIED: {param} = {update['recommended_value']} (confidence: {confidence:.2f})")
            else:
                skipped.append(param)
                logger.info(f"⏭️  SKIPPED: {param} (confidence: {confidence:.2f} < {threshold:.2f})")
        
        if applied:
            # Backup old config
            backup_path = self.config_path.with_suffix('.backup.json')
            try:
                with open(backup_path, 'w') as f:
                    json.dump(config, f, indent=2)
                logger.info(f"💾 Backup saved to: {backup_path}")
            except Exception as e:
                logger.warning(f"Failed to save backup: {e}")
            
            # Write new config
            try:
                with open(self.config_path, 'w') as f:
                    json.dump(config, f, indent=2)
                logger.info(f"✅ Applied {len(applied)} config updates: {applied}")
            except Exception as e:
                logger.error(f"Failed to write config: {e}")
    
    def _extract_failure_patterns(self) -> List[Dict]:
        """Extract common failure patterns."""
        failures = [h for h in self.performance_history if not h['performance'].get('success')]
        
        if not failures:
            return []
        
        patterns = {}
        for failure in failures:
            error = failure['performance'].get('error', 'unknown')
            if error not in patterns:
                patterns[error] = {'count': 0, 'configs': []}
            patterns[error]['count'] += 1
            patterns[error]['configs'].append(failure['config'])
        
        return [{'error': k, **v} for k, v in patterns.items()]
    
    def _extract_success_patterns(self) -> List[Dict]:
        """Extract common success patterns."""
        successes = [h for h in self.performance_history if h['performance'].get('success')]
        
        if not successes:
            return []
        
        # Simple aggregation
        return [{
            'count': len(successes),
            'avg_reward': sum(s['performance'].get('reward', 0) for s in successes) / len(successes),
            'avg_time': sum(s['performance'].get('time', 0) for s in successes) / len(successes)
        }]
    
    def _aggregate_performance(self) -> Dict:
        """Aggregate performance metrics."""
        if not self.performance_history:
            return {}
        
        total = len(self.performance_history)
        successes = sum(1 for h in self.performance_history if h['performance'].get('success'))
        
        return {
            'total_episodes': total,
            'success_rate': successes / total if total > 0 else 0,
            'avg_reward': sum(h['performance'].get('reward', 0) for h in self.performance_history) / total if total > 0 else 0,
            'avg_time': sum(h['performance'].get('time', 0) for h in self.performance_history) / total if total > 0 else 0,
            'recent_success_rate': sum(1 for h in self.performance_history[-10:] if h['performance'].get('success')) / min(10, total) if total > 0 else 0
        }
