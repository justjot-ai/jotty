"""
Time-Aware Execution Framework for Synapse
===========================================

A-Team Design Paradigms to Prevent Timeouts:

1. TIME-BOXED PHASES: Break task into phases with time budgets
2. STUCK DETECTION: Detect repetitive failure loops and pivot
3. PROGRESSIVE MVP: Get minimum viable solution first, then refine
4. ADAPTIVE TIME BUDGET: Reallocate time based on progress
5. FAIL-FAST VALIDATION: Validate approach feasibility before investing time

MIT RLM Paper Insight: Complex tasks degrade at shorter lengths because
they require processing EVERY piece of information. We need to prioritize
and time-box accordingly.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable, Tuple
from enum import Enum
from datetime import datetime, timedelta
import time
import logging
import hashlib

logger = logging.getLogger(__name__)


class PhaseType(Enum):
    """Task execution phases with different time characteristics."""
    EXPLORATION = "exploration"      # Understand the problem (15% of time)
    VALIDATION = "validation"        # Validate approach feasibility (10%)
    MVP = "mvp"                      # Get minimum viable solution (40%)
    REFINEMENT = "refinement"        # Improve the solution (25%)
    VERIFICATION = "verification"    # Final verification (10%)


@dataclass
class PhaseConfig:
    """Configuration for a single execution phase."""
    phase_type: PhaseType
    time_budget_pct: float          # Percentage of total time (0.0-1.0)
    min_time_seconds: float = 30    # Minimum time even if budget exhausted
    max_time_seconds: float = 600   # Maximum time even if budget allows
    can_skip: bool = False          # Can this phase be skipped?
    fail_fast: bool = False         # Should we fail fast if this phase fails?
    
    # Adaptive parameters
    extend_if_progress: bool = True  # Extend time if making progress?
    progress_extension_pct: float = 0.2  # How much to extend (20%)


@dataclass
class PhaseResult:
    """Result of executing a phase."""
    phase: PhaseType
    success: bool
    elapsed_seconds: float
    progress_pct: float            # 0.0-1.0, how much of phase goal completed
    output: Any = None
    pivot_recommended: bool = False
    pivot_reason: Optional[str] = None
    stuck_detected: bool = False


@dataclass
class StuckSignal:
    """Signal that the agent is stuck."""
    pattern_hash: str              # Hash of the repeated pattern
    repetitions: int
    first_seen: datetime
    last_seen: datetime
    recommendation: str


class StuckDetector:
    """
    Detects when an agent is stuck in a repetitive failure loop.
    
    🔴 A-TEAM FIX: All detection is now PATTERN-BASED, not time-based.
    Time-based thresholds were randomly terminating tasks.
    
    Patterns that indicate being stuck:
    1. Same error repeated N+ times (pattern-based)
    2. Same tool call with same args repeated N+ times (pattern-based)
    3. No progress for N consecutive checks (count-based, NOT time-based)
    4. Circular: A -> B -> A -> B pattern (pattern-based)
    """
    
    def __init__(
        self,
        max_repetitions: int = 3,
        pattern_window: int = 10,
        no_progress_threshold_seconds: float = 0.0  # DEPRECATED: kept for API compat, unused
    ):
        self.max_repetitions = max_repetitions
        self.pattern_window = pattern_window
        # no_progress_threshold is DEPRECATED — count-based detection is used instead
        
        # Tracking state
        self.action_history: List[Dict] = []
        self.error_history: List[str] = []
        self.progress_checkpoints: List[float] = []
    
    def record_action(self, action: Dict) -> Optional[StuckSignal]:
        """Record an action and check if stuck."""
        action_hash = self._hash_action(action)
        self.action_history.append({
            'hash': action_hash,
            'action': action,
            'timestamp': datetime.now()
        })
        
        # Keep window size
        if len(self.action_history) > self.pattern_window * 2:
            self.action_history = self.action_history[-self.pattern_window * 2:]
        
        return self._check_action_pattern()
    
    def record_error(self, error: str) -> Optional[StuckSignal]:
        """Record an error and check if stuck."""
        error_hash = self._hash_error(error)
        self.error_history.append(error_hash)
        
        # Keep window size
        if len(self.error_history) > self.pattern_window:
            self.error_history = self.error_history[-self.pattern_window:]
        
        return self._check_error_pattern()
    
    def record_progress(self, progress_pct: float) -> Optional[StuckSignal]:
        """Record progress and check if stuck with no progress.
        
        🔴 A-TEAM FIX: Removed time-based no_progress_threshold.
        Time-based stuck detection was randomly terminating tasks that just needed
        more iterations. Now uses COUNT-based detection: if progress hasn't changed
        for N consecutive checks, signal stuck.
        """
        now = datetime.now()
        self.progress_checkpoints.append(progress_pct)
        
        # Keep window manageable
        if len(self.progress_checkpoints) > self.pattern_window * 2:
            self.progress_checkpoints = self.progress_checkpoints[-self.pattern_window * 2:]
        
        # Count-based: no progress for max_repetitions consecutive checks
        if len(self.progress_checkpoints) >= self.max_repetitions:
            recent = self.progress_checkpoints[-self.max_repetitions:]
            # All progress values are the same → stuck
            if len(set(recent)) == 1 and recent[0] < 1.0:
                return StuckSignal(
                    pattern_hash="no_progress",
                    repetitions=self.max_repetitions,
                    first_seen=now,
                    last_seen=now,
                    recommendation=f"No progress for {self.max_repetitions} consecutive checks "
                                   f"(stuck at {recent[0]:.1%}). Consider: "
                                   "1) Pivoting to a simpler approach, "
                                   "2) Breaking down the current step, "
                                   "3) Asking for help via web search"
                )
        
        return None
    
    def _hash_action(self, action: Dict) -> str:
        """Create a hash of an action for comparison."""
        # Normalize action for comparison
        key_parts = []
        if 'tool' in action:
            key_parts.append(action['tool'])
        if 'args' in action:
            # Sort args for consistent hashing
            args_str = str(sorted(action['args'].items()) if isinstance(action['args'], dict) else action['args'])
            key_parts.append(args_str)
        return hashlib.md5('|'.join(key_parts).encode()).hexdigest()[:16]
    
    def _hash_error(self, error: str) -> str:
        """Create a hash of an error for comparison."""
        # Normalize: remove line numbers, file paths, etc.
        normalized = error.lower()
        # Remove common variable parts
        for pattern in ['line ', 'file "', 'at 0x']:
            if pattern in normalized:
                parts = normalized.split(pattern)
                normalized = parts[0]
        return hashlib.md5(normalized.encode()).hexdigest()[:16]
    
    def _check_action_pattern(self) -> Optional[StuckSignal]:
        """Check for repetitive action patterns."""
        if len(self.action_history) < self.max_repetitions:
            return None
        
        recent = self.action_history[-self.pattern_window:]
        hashes = [a['hash'] for a in recent]
        
        # Check for same action repeated
        for h in set(hashes):
            count = hashes.count(h)
            if count >= self.max_repetitions:
                first_idx = hashes.index(h)
                return StuckSignal(
                    pattern_hash=h,
                    repetitions=count,
                    first_seen=recent[first_idx]['timestamp'],
                    last_seen=recent[-1]['timestamp'],
                    recommendation=f"Same action repeated {count} times. Try a different approach."
                )
        
        # Check for A-B-A-B pattern (circular)
        if len(hashes) >= 4:
            for i in range(len(hashes) - 3):
                if hashes[i] == hashes[i+2] and hashes[i+1] == hashes[i+3]:
                    return StuckSignal(
                        pattern_hash=f"circular_{hashes[i]}_{hashes[i+1]}",
                        repetitions=2,
                        first_seen=recent[i]['timestamp'],
                        last_seen=recent[i+3]['timestamp'],
                        recommendation="Circular pattern detected (A→B→A→B). Break the cycle with a new approach."
                    )
        
        return None
    
    def _check_error_pattern(self) -> Optional[StuckSignal]:
        """Check for repetitive error patterns."""
        if len(self.error_history) < self.max_repetitions:
            return None
        
        recent = self.error_history[-self.pattern_window:]
        
        for h in set(recent):
            count = recent.count(h)
            if count >= self.max_repetitions:
                return StuckSignal(
                    pattern_hash=h,
                    repetitions=count,
                    first_seen=datetime.now() - timedelta(seconds=count * 30),  # Estimate
                    last_seen=datetime.now(),
                    recommendation=f"Same error repeated {count} times. "
                                   "Consider: 1) Web search for solution, "
                                   "2) Try different library/approach, "
                                   "3) Check prerequisites first"
                )
        
        return None
    
    def reset(self):
        """Reset stuck detection state."""
        self.action_history.clear()
        self.error_history.clear()
        self.progress_checkpoints.clear()


@dataclass
class TimeBox:
    """A time-boxed execution context."""
    phase: PhaseType
    start_time: datetime
    budget_seconds: float
    min_seconds: float
    max_seconds: float
    
    # Dynamic state
    elapsed_seconds: float = 0
    progress_pct: float = 0
    extended: bool = False
    extension_seconds: float = 0
    
    @property
    def remaining_seconds(self) -> float:
        """Get remaining time in this time box."""
        total_budget = self.budget_seconds + self.extension_seconds
        remaining = total_budget - self.elapsed_seconds
        
        # Enforce min/max
        if remaining < 0 and self.elapsed_seconds < self.min_seconds:
            remaining = self.min_seconds - self.elapsed_seconds
        
        if self.elapsed_seconds >= self.max_seconds:
            remaining = 0
        
        return max(0, remaining)
    
    @property
    def is_expired(self) -> bool:
        """Check if time box has expired."""
        return self.remaining_seconds <= 0
    
    @property
    def utilization_pct(self) -> float:
        """Get utilization percentage."""
        total = self.budget_seconds + self.extension_seconds
        return min(1.0, self.elapsed_seconds / total) if total > 0 else 1.0
    
    def update(self, elapsed: float, progress: float = None):
        """Update time box state."""
        self.elapsed_seconds = elapsed
        if progress is not None:
            self.progress_pct = progress
    
    def extend(self, extra_seconds: float):
        """Extend the time box."""
        max_extension = self.max_seconds - self.budget_seconds
        self.extension_seconds = min(extra_seconds, max_extension)
        self.extended = True


class TimeAwareExecutor:
    """
    Executes tasks with time-aware phase management.
    
    Design Principles:
    1. Never exceed total timeout
    2. Front-load exploration and validation
    3. Ensure MVP phase gets adequate time
    4. Detect stuck patterns and force pivots
    5. Progressive refinement only if time allows
    """
    
    DEFAULT_PHASE_CONFIG = [
        PhaseConfig(PhaseType.EXPLORATION, time_budget_pct=0.15, min_time_seconds=30, fail_fast=False),
        PhaseConfig(PhaseType.VALIDATION, time_budget_pct=0.10, min_time_seconds=20, fail_fast=True),
        PhaseConfig(PhaseType.MVP, time_budget_pct=0.40, min_time_seconds=60, fail_fast=False),
        PhaseConfig(PhaseType.REFINEMENT, time_budget_pct=0.25, min_time_seconds=30, can_skip=True),
        PhaseConfig(PhaseType.VERIFICATION, time_budget_pct=0.10, min_time_seconds=30, fail_fast=False),
    ]
    
    def __init__(
        self,
        total_timeout_seconds: float,
        phase_configs: List[PhaseConfig] = None,
        stuck_detector: StuckDetector = None,
        on_phase_start: Callable[[PhaseType, TimeBox], None] = None,
        on_phase_end: Callable[[PhaseResult], None] = None,
        on_stuck_detected: Callable[[StuckSignal], None] = None
    ):
        self.total_timeout = total_timeout_seconds
        self.phase_configs = phase_configs or self.DEFAULT_PHASE_CONFIG
        self.stuck_detector = stuck_detector or StuckDetector()
        
        # Callbacks
        self.on_phase_start = on_phase_start
        self.on_phase_end = on_phase_end
        self.on_stuck_detected = on_stuck_detected
        
        # State
        self.start_time: Optional[datetime] = None
        self.current_phase: Optional[PhaseType] = None
        self.current_timebox: Optional[TimeBox] = None
        self.phase_results: List[PhaseResult] = []
        self.time_boxes: Dict[PhaseType, TimeBox] = {}
        
        # Calculate time budgets
        self._calculate_time_budgets()
    
    def _calculate_time_budgets(self):
        """Calculate time budgets for each phase."""
        for config in self.phase_configs:
            budget_seconds = self.total_timeout * config.time_budget_pct
            
            # Enforce min/max
            budget_seconds = max(budget_seconds, config.min_time_seconds)
            budget_seconds = min(budget_seconds, config.max_time_seconds)
            
            self.time_boxes[config.phase_type] = TimeBox(
                phase=config.phase_type,
                start_time=None,
                budget_seconds=budget_seconds,
                min_seconds=config.min_time_seconds,
                max_seconds=config.max_time_seconds
            )
    
    def get_remaining_total(self) -> float:
        """Get remaining total time."""
        if not self.start_time:
            return self.total_timeout
        elapsed = (datetime.now() - self.start_time).total_seconds()
        return max(0, self.total_timeout - elapsed)
    
    def get_phase_budget(self, phase: PhaseType) -> float:
        """Get remaining budget for a phase."""
        if phase in self.time_boxes:
            return self.time_boxes[phase].remaining_seconds
        return 0
    
    def get_current_phase_info(self) -> Dict:
        """Get information about the current phase for injection into context."""
        if not self.current_timebox:
            return {}
        
        remaining_total = self.get_remaining_total()
        
        return {
            'current_phase': self.current_phase.value if self.current_phase else None,
            'phase_remaining_seconds': self.current_timebox.remaining_seconds,
            'phase_progress_pct': self.current_timebox.progress_pct * 100,
            'total_remaining_seconds': remaining_total,
            'total_remaining_pct': (remaining_total / self.total_timeout) * 100 if self.total_timeout > 0 else 0,
            'is_phase_expired': self.current_timebox.is_expired,
            'phase_guidance': self._get_phase_guidance()
        }
    
    def _get_phase_guidance(self) -> str:
        """Get guidance message for the current phase."""
        if not self.current_phase:
            return ""
        
        guidance = {
            PhaseType.EXPLORATION: (
                "🔍 EXPLORATION PHASE: Understand the problem. Read files, check requirements, "
                "identify dependencies. Do NOT start implementing yet."
            ),
            PhaseType.VALIDATION: (
                "✅ VALIDATION PHASE: Test if your approach will work. Create a minimal test, "
                "check if dependencies are available. If validation fails, PIVOT immediately."
            ),
            PhaseType.MVP: (
                "🏃 MVP PHASE: Get the MINIMUM working solution. Don't optimize, don't handle "
                "edge cases, just get something that passes the basic test."
            ),
            PhaseType.REFINEMENT: (
                "🔧 REFINEMENT PHASE: Now improve the MVP. Add error handling, optimize, "
                "handle edge cases. Only if you have time."
            ),
            PhaseType.VERIFICATION: (
                "🎯 VERIFICATION PHASE: Final checks. Run all tests, verify output format, "
                "ensure everything works end-to-end."
            )
        }
        
        base_guidance = guidance.get(self.current_phase, "")
        
        # Add time pressure guidance
        if self.current_timebox:
            remaining = self.current_timebox.remaining_seconds
            if remaining < 60:
                base_guidance += f"\n⚠️ TIME WARNING: Only {remaining:.0f}s left in this phase!"
            
            total_remaining = self.get_remaining_total()
            if total_remaining < 120:
                base_guidance += f"\n🚨 CRITICAL: Only {total_remaining:.0f}s total remaining! Prioritize MVP."
        
        return base_guidance
    
    def start_phase(self, phase: PhaseType) -> TimeBox:
        """Start a new phase."""
        self.current_phase = phase
        self.current_timebox = self.time_boxes.get(phase)
        
        if self.current_timebox:
            self.current_timebox.start_time = datetime.now()
            self.current_timebox.elapsed_seconds = 0
            self.current_timebox.progress_pct = 0
        
        if self.on_phase_start and self.current_timebox:
            self.on_phase_start(phase, self.current_timebox)
        
        logger.info(f"📍 Started phase: {phase.value} (budget: {self.current_timebox.budget_seconds:.0f}s)")
        
        return self.current_timebox
    
    def update_progress(self, progress_pct: float) -> Optional[StuckSignal]:
        """Update progress and check for stuck patterns."""
        if self.current_timebox:
            elapsed = (datetime.now() - self.current_timebox.start_time).total_seconds()
            self.current_timebox.update(elapsed, progress_pct)
        
        # Check stuck
        signal = self.stuck_detector.record_progress(progress_pct)
        if signal and self.on_stuck_detected:
            self.on_stuck_detected(signal)
        
        return signal
    
    def record_action(self, action: Dict) -> Optional[StuckSignal]:
        """Record an action and check for stuck patterns."""
        signal = self.stuck_detector.record_action(action)
        if signal and self.on_stuck_detected:
            self.on_stuck_detected(signal)
        return signal
    
    def record_error(self, error: str) -> Optional[StuckSignal]:
        """Record an error and check for stuck patterns."""
        signal = self.stuck_detector.record_error(error)
        if signal and self.on_stuck_detected:
            self.on_stuck_detected(signal)
        return signal
    
    def end_phase(self, success: bool, output: Any = None) -> PhaseResult:
        """End the current phase."""
        if not self.current_timebox:
            raise RuntimeError("No active phase to end")
        
        elapsed = (datetime.now() - self.current_timebox.start_time).total_seconds()
        
        result = PhaseResult(
            phase=self.current_phase,
            success=success,
            elapsed_seconds=elapsed,
            progress_pct=self.current_timebox.progress_pct,
            output=output
        )
        
        self.phase_results.append(result)
        
        if self.on_phase_end:
            self.on_phase_end(result)
        
        logger.info(f"✅ Ended phase: {self.current_phase.value} (success={success}, elapsed={elapsed:.0f}s)")
        
        return result
    
    def should_skip_to_mvp(self) -> bool:
        """Check if we should skip remaining phases and go straight to MVP."""
        remaining = self.get_remaining_total()
        
        # If less than 50% time remains and we haven't done MVP
        if remaining < self.total_timeout * 0.5:
            mvp_done = any(r.phase == PhaseType.MVP for r in self.phase_results)
            if not mvp_done:
                logger.warning("⚠️ Low time, skipping to MVP phase")
                return True
        
        return False
    
    def reallocate_time(self, from_phase: PhaseType, to_phase: PhaseType, seconds: float):
        """Reallocate time from one phase to another."""
        if from_phase in self.time_boxes and to_phase in self.time_boxes:
            from_box = self.time_boxes[from_phase]
            to_box = self.time_boxes[to_phase]
            
            # Can only reallocate unused time
            available = from_box.remaining_seconds
            transfer = min(seconds, available)
            
            from_box.budget_seconds -= transfer
            to_box.extend(transfer)
            
            logger.info(f"💱 Reallocated {transfer:.0f}s from {from_phase.value} to {to_phase.value}")
    
    def get_summary(self) -> Dict:
        """Get execution summary."""
        return {
            'total_timeout': self.total_timeout,
            'elapsed': (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
            'phases_completed': [r.phase.value for r in self.phase_results],
            'phases_successful': [r.phase.value for r in self.phase_results if r.success],
            'phase_times': {r.phase.value: r.elapsed_seconds for r in self.phase_results}
        }


# DSPy Signatures for Time-Aware Guidance
try:
    import dspy
    DSPY_AVAILABLE = True
    
    class TimeAwareGuidanceSignature(dspy.Signature):
        """Generate time-aware guidance for an agent based on current phase and remaining time."""
        
        current_phase: str = dspy.InputField(desc="Current execution phase (exploration/validation/mvp/refinement/verification)")
        remaining_seconds: float = dspy.InputField(desc="Seconds remaining in current phase")
        total_remaining_seconds: float = dspy.InputField(desc="Total seconds remaining for entire task")
        progress_pct: float = dspy.InputField(desc="Progress percentage in current phase (0-100)")
        task_description: str = dspy.InputField(desc="Brief description of the task")
        recent_actions: str = dspy.InputField(desc="Summary of recent actions taken")
        
        guidance: str = dspy.OutputField(desc="Specific, actionable guidance for what to do next given time constraints")
        priority_action: str = dspy.OutputField(desc="The single most important action to take right now")
        should_pivot: bool = dspy.OutputField(desc="Whether the agent should abandon current approach and try something new")
    
    class StuckResolutionSignature(dspy.Signature):
        """Generate resolution strategy when agent is stuck."""
        
        stuck_pattern: str = dspy.InputField(desc="Description of the stuck pattern detected")
        repetitions: int = dspy.InputField(desc="Number of times the pattern repeated")
        task_description: str = dspy.InputField(desc="Brief description of the task")
        attempted_approaches: str = dspy.InputField(desc="Summary of approaches already tried")
        remaining_seconds: float = dspy.InputField(desc="Seconds remaining for entire task")
        
        resolution_strategy: str = dspy.OutputField(desc="New strategy to break out of stuck pattern")
        alternative_approach: str = dspy.OutputField(desc="A completely different approach to try")
        web_search_query: str = dspy.OutputField(desc="If applicable, a web search query to find solutions")
        
except ImportError:
    DSPY_AVAILABLE = False


def create_time_aware_context_injection(
    executor: TimeAwareExecutor,
    task_description: str
) -> Dict[str, Any]:
    """
    Create context injection for actor with time awareness.
    
    This is injected into the actor's context to make it aware of:
    1. Current phase and its goals
    2. Time remaining in phase and overall
    3. Stuck detection signals
    4. Recommended next actions
    """
    phase_info = executor.get_current_phase_info()
    
    context = {
        'time_aware': True,
        'phase': phase_info.get('current_phase'),
        'phase_remaining_seconds': phase_info.get('phase_remaining_seconds', 0),
        'phase_progress_pct': phase_info.get('phase_progress_pct', 0),
        'total_remaining_seconds': phase_info.get('total_remaining_seconds', 0),
        'total_remaining_pct': phase_info.get('total_remaining_pct', 0),
        'phase_guidance': phase_info.get('phase_guidance', ''),
        
        # Time pressure indicators
        'time_pressure': 'low',
        'priority_message': ''
    }
    
    # Calculate time pressure
    total_remaining = phase_info.get('total_remaining_seconds', float('inf'))
    if total_remaining < 120:
        context['time_pressure'] = 'critical'
        context['priority_message'] = (
            "🚨 CRITICAL TIME: You have less than 2 minutes. "
            "Execute the simplest possible solution NOW. "
            "Skip optimizations, skip edge cases, just get a working answer."
        )
    elif total_remaining < 300:
        context['time_pressure'] = 'high'
        context['priority_message'] = (
            "⚠️ HIGH TIME PRESSURE: Less than 5 minutes remaining. "
            "Focus only on the core task. Test after each change."
        )
    elif total_remaining < 600:
        context['time_pressure'] = 'medium'
        context['priority_message'] = (
            "⏰ Moderate time remaining. Prioritize MVP over perfect solution."
        )
    
    return context


# Export
__all__ = [
    'PhaseType',
    'PhaseConfig',
    'PhaseResult',
    'StuckSignal',
    'StuckDetector',
    'TimeBox',
    'TimeAwareExecutor',
    'create_time_aware_context_injection',
    'DSPY_AVAILABLE',
]

if DSPY_AVAILABLE:
    __all__.extend(['TimeAwareGuidanceSignature', 'StuckResolutionSignature'])
