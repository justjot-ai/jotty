"""
Swarm-Level Validation (Built-In) - LLM-Based

This module provides INTERNAL validation for swarm orchestration.
Users do NOT configure this - it's part of SYNAPSE's core functionality.

A-TEAM DESIGN DECISION:
- All heuristics replaced with LLM-based validation
- DSPy signatures for structured reasoning
- Web search fallback on uncertainty
- No regex, no string matching, no length checks

Purpose:
- Check TODO completeness and clarity
- Validate actor coordination
- Ensure information flow
- Verify goal alignment
- Trigger feedback when needed

This is like the OS scheduler - it just works, users don't configure it.
"""

from typing import List, Dict, Any, Optional, AsyncGenerator
from pathlib import Path
from dataclasses import dataclass, field
import logging
import json

logger = logging.getLogger(__name__)

try:
    from .token_utils import smart_truncate
except ImportError:
    def smart_truncate(text, max_tokens=500, **kwargs):
        """Fallback if token_utils not available."""
        if not text:
            return text
        char_limit = max_tokens * 4
        if len(str(text)) <= char_limit:
            return str(text)
        return str(text)[:char_limit] + "..."

# Lazy import for DSPy to avoid startup failures
_dspy = None
_DSPY_AVAILABLE = False


def _get_dspy():
    global _dspy, _DSPY_AVAILABLE
    if _dspy is None:
        try:
            import dspy
            _dspy = dspy
            _DSPY_AVAILABLE = True
        except ImportError:
            _DSPY_AVAILABLE = False
    return _dspy, _DSPY_AVAILABLE


# =============================================================================
# DSPy SIGNATURES FOR LLM-BASED VALIDATION (RLM-Enhanced)
# =============================================================================


def _create_architect_signature():
    dspy, available = _get_dspy()
    if not available:
        return None

    class SwarmArchitectSignature(dspy.Signature):
        """
        Validate if the swarm is ready to execute a TODO.
        
        You are a swarm orchestration architect. Your job is to determine if
        the system is ready to execute a task by checking:
        1. Is the TODO description clear and actionable?
        2. Are the required actors available?
        3. Are dependencies satisfied?
        4. Is there sufficient context?
        
        Be precise. If something is missing, explain what and why.
        """
        
        todo_description: str = dspy.InputField(desc="The TODO item description to validate")
        available_actors: str = dspy.InputField(desc="JSON list of available actor names and capabilities")
        dependencies: str = dspy.InputField(desc="JSON list of dependencies this TODO requires")
        context_summary: str = dspy.InputField(desc="Summary of available context (prior outputs, shared data)")
        
        reasoning: str = dspy.OutputField(desc="Step-by-step analysis of readiness")
        ready: bool = dspy.OutputField(desc="True if swarm is ready to proceed, False otherwise")
        confidence: float = dspy.OutputField(desc="Confidence score 0.0-1.0")
        missing_items: str = dspy.OutputField(desc="JSON list of missing items (actors, context, clarity issues)")
        suggested_actions: str = dspy.OutputField(desc="JSON list of suggested actions to become ready")

    return SwarmArchitectSignature


def _create_auditor_signature():
    dspy, available = _get_dspy()
    if not available:
        return None

    class SwarmAuditorSignature(dspy.Signature):
        """
        Validate if actors are coordinating and making progress toward goal.
        
        You are a swarm orchestration auditor. Your job is to determine if
        the actors are working together effectively by checking:
        1. Did the actor produce meaningful output?
        2. Is the output consistent with previous actors' outputs?
        3. Is progress being made toward the user's goal?
        4. Should any actor receive feedback or retry?
        
        If the output seems incorrect, suggest using web search to verify.
        """
        
        actor_name: str = dspy.InputField(desc="Name of the actor that just executed")
        actor_output_summary: str = dspy.InputField(desc="Summary of the actor's output (max 2000 chars)")
        user_goal: str = dspy.InputField(desc="The original user goal/query")
        previous_outputs_summary: str = dspy.InputField(desc="Summary of all previous actors' outputs")
        trajectory_summary: str = dspy.InputField(desc="Summary of execution trajectory so far")
        
        reasoning: str = dspy.OutputField(desc="Step-by-step analysis of coordination and progress")
        coordinated: bool = dspy.OutputField(desc="True if actors are coordinating well")
        goal_aligned: bool = dspy.OutputField(desc="True if progress is being made toward goal")
        confidence: float = dspy.OutputField(desc="Confidence score 0.0-1.0")
        issues_found: str = dspy.OutputField(desc="JSON list of issues found (if any)")
        should_web_search: bool = dspy.OutputField(desc="True if web search is recommended to verify output")
        web_search_query: str = dspy.OutputField(desc="Suggested web search query (if should_web_search is True)")
        feedback_for_actors: str = dspy.OutputField(desc="JSON dict mapping actor names to feedback messages")

    return SwarmAuditorSignature


# =============================================================================
# DATA CLASSES
# =============================================================================


@dataclass
class SwarmArchitectResult:
    """Result from swarm-level pre-validation."""
    ready: bool
    confidence: float
    feedback: str
    reasoning: str = ""
    suggested_actors: List[str] = field(default_factory=list)
    missing_items: List[str] = field(default_factory=list)


@dataclass
class SwarmAuditorResult:
    """Result from swarm-level post-validation."""
    coordinated: bool
    goal_aligned: bool
    confidence: float
    feedback: str
    reasoning: str = ""
    trigger_feedback_to: List[str] = field(default_factory=list)
    should_web_search: bool = False
    web_search_query: str = ""
    issues_found: List[str] = field(default_factory=list)


# =============================================================================
# SWARM VALIDATOR (LLM-BASED)
# =============================================================================


class SwarmValidator:
    """
    Built-in validation for swarm orchestration.
    
    A-TEAM DESIGN:
    - All validation is LLM-based (no heuristics)
    - DSPy signatures for structured reasoning
    - RLM design for long context handling
    - Graceful fallback if DSPy unavailable
    
    This is INTERNAL to SYNAPSE - users have no control over it.
    Validates multi-agent coordination, not domain-specific quality.
    """
    
    def __init__(self, config):
        """
        Initialize with SYNAPSE config.
        
        Loads built-in prompts from swarm_prompts/ directory.
        These prompts are generic and domain-agnostic.
        """
        self.config = config
        
        # Built-in prompts directory (internal to SYNAPSE)
        self.prompts_dir = Path(__file__).parent / "swarm_prompts"
        self.prompts_dir.mkdir(exist_ok=True)
        
        # Initialize LLM validators
        self._architect_validator = None
        self._auditor_validator = None
        self._init_validators()
        
        logger.info("🔍 SwarmValidator initialized (LLM-based)")
        # Note: __init__ cannot yield, but initialization is logged
    
    def _init_validators(self):
        """Initialize DSPy validators if available."""
        dspy, available = _get_dspy()
        if not available:
            logger.warning("⚠️ DSPy not available - SwarmValidator will use minimal fallback")
            return
        
        architect_sig = _create_architect_signature()
        auditor_sig = _create_auditor_signature()
        
        if architect_sig:
            self._architect_validator = dspy.ChainOfThought(architect_sig)
            logger.info("✅ SwarmArchitect LLM validator initialized (RLM-enhanced)")
        
        if auditor_sig:
            self._auditor_validator = dspy.ChainOfThought(auditor_sig)
            logger.info("✅ SwarmAuditor LLM validator initialized (RLM-enhanced)")
    
    async def run_swarm_architect_stream(
        self,
        todo: Any,
        actors: List[Any],
        context: Dict[str, Any],
        recursion_depth: int = 0
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Check if the swarm is ready to execute this TODO with event streaming.
        
        A-TEAM: Uses LLM-based validation with RLM decomposition.
        
        Args:
            todo: The TODO item to validate
            actors: Available actors
            context: Current execution context
            recursion_depth: Current recursion depth for RLM
        
        Yields:
            Event dictionaries with module and conversational message
        Returns:
            SwarmArchitectResult with readiness assessment
        """
        logger.info(f"🔍 Running SWARM Architect (LLM-based, depth={recursion_depth})")
        yield {"module": "Synapse.core.swarm_validation", "message": f"I am running SWARM Architect validation at depth {recursion_depth}"}
        
        # Prepare inputs for LLM
        todo_desc = getattr(todo, 'description', str(todo)) if todo else ""
        actor_list = [
            {"name": getattr(a, 'name', str(a)), "capabilities": getattr(a, 'capabilities', [])}
            for a in (actors or [])
        ]
        dependencies = getattr(todo, 'dependencies', []) or []
        context_summary = self._summarize_context(context)
        yield {"module": "Synapse.core.swarm_validation", "message": f"I am preparing validation inputs: {len(actor_list)} actors, {len(dependencies)} dependencies"}
        
        # Use LLM validator if available
        if self._architect_validator:
            try:
                yield {"module": "Synapse.core.swarm_validation", "message": "I am using LLM to validate swarm readiness"}
                result = self._architect_validator(
                    todo_description=smart_truncate(todo_desc, max_tokens=500),
                    available_actors=smart_truncate(json.dumps(actor_list, default=str), max_tokens=500),
                    dependencies=json.dumps(dependencies, default=str),
                    context_summary=smart_truncate(context_summary, max_tokens=500)
                )
                
                # Parse LLM output
                ready = bool(result.ready) if hasattr(result, 'ready') else True
                confidence = float(result.confidence) if hasattr(result, 'confidence') else 0.8
                reasoning = str(result.reasoning) if hasattr(result, 'reasoning') else ""
                missing_items = []
                if hasattr(result, 'missing_items'):
                    try:
                        missing_items = json.loads(result.missing_items)
                    except Exception:
                        missing_items = [result.missing_items] if result.missing_items else []
                
                suggested = []
                if hasattr(result, 'suggested_actions'):
                    try:
                        suggested = json.loads(result.suggested_actions)
                    except Exception:
                        suggested = [result.suggested_actions] if result.suggested_actions else []
                
                feedback = reasoning if reasoning else ("Ready to proceed" if ready else "Not ready")
                
                logger.info(f"✅ SWARM Architect (LLM): ready={ready}, confidence={confidence:.2f}")
                yield {"module": "Synapse.core.swarm_validation", "message": f"I have completed validation: ready={ready}, confidence={confidence:.2f}"}
                if missing_items:
                    yield {"module": "Synapse.core.swarm_validation", "message": f"I found {len(missing_items)} missing items"}
                
                result_obj = SwarmArchitectResult(
                    ready=ready,
                    confidence=confidence,
                    feedback=feedback,
                    reasoning=reasoning,
                    suggested_actors=suggested,
                    missing_items=missing_items
                )
                yield {"type": "result", "result": result_obj, "module": "Synapse.core.swarm_validation", "message": "I am returning the architect validation result"}
                return
                
            except Exception as e:
                logger.warning(f"⚠️ LLM architect validation failed: {e}, using minimal fallback")
                yield {"module": "Synapse.core.swarm_validation", "message": f"I encountered an error during LLM validation: {str(e)}"}
        
        # Minimal fallback (explicit uncertainty, NOT heuristic judgment)
        logger.info("⚠️ SWARM Architect: Using minimal fallback (no LLM available)")
        yield {"module": "Synapse.core.swarm_validation", "message": "I am using minimal fallback validation (no LLM available)"}
        result_obj = SwarmArchitectResult(
            ready=True,
            confidence=0.5,
            feedback="LLM validation unavailable - proceeding with low confidence",
            reasoning="No LLM validator available for pre-validation",
            suggested_actors=[],
            missing_items=[]
        )
        yield {"type": "result", "result": result_obj, "module": "Synapse.core.swarm_validation", "message": "I am returning the fallback validation result"}
        return
    
    async def run_swarm_architect(
        self,
        todo: Any,
        actors: List[Any],
        context: Dict[str, Any],
        recursion_depth: int = 0
    ) -> SwarmArchitectResult:
        """
        Synchronous wrapper for run_swarm_architect_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use sync version directly
                return await self._run_swarm_architect_sync(todo, actors, context, recursion_depth)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            result = None
            async for event in self.run_swarm_architect_stream(todo, actors, context, recursion_depth):
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            return result
        
        return asyncio.run(_run())
    
    async def _run_swarm_architect_sync(
        self,
        todo: Any,
        actors: List[Any],
        context: Dict[str, Any],
        recursion_depth: int = 0
    ) -> SwarmArchitectResult:
        """
        Synchronous implementation (for backward compatibility).
        """
        logger.info(f"🔍 Running SWARM Architect (LLM-based, depth={recursion_depth})")
        
        # Prepare inputs for LLM
        todo_desc = getattr(todo, 'description', str(todo)) if todo else ""
        actor_list = [
            {"name": getattr(a, 'name', str(a)), "capabilities": getattr(a, 'capabilities', [])}
            for a in (actors or [])
        ]
        dependencies = getattr(todo, 'dependencies', []) or []
        context_summary = self._summarize_context(context)
        
        # Use LLM validator if available
        if self._architect_validator:
            try:
                result = self._architect_validator(
                    todo_description=smart_truncate(todo_desc, max_tokens=500),
                    available_actors=smart_truncate(json.dumps(actor_list, default=str), max_tokens=500),
                    dependencies=json.dumps(dependencies, default=str),
                    context_summary=smart_truncate(context_summary, max_tokens=500)
                )
                
                # Parse LLM output
                ready = bool(result.ready) if hasattr(result, 'ready') else True
                confidence = float(result.confidence) if hasattr(result, 'confidence') else 0.8
                reasoning = str(result.reasoning) if hasattr(result, 'reasoning') else ""
                missing_items = []
                if hasattr(result, 'missing_items'):
                    try:
                        missing_items = json.loads(result.missing_items)
                    except Exception:
                        missing_items = [result.missing_items] if result.missing_items else []
                
                suggested = []
                if hasattr(result, 'suggested_actions'):
                    try:
                        suggested = json.loads(result.suggested_actions)
                    except Exception:
                        suggested = [result.suggested_actions] if result.suggested_actions else []
                
                feedback = reasoning if reasoning else ("Ready to proceed" if ready else "Not ready")
                
                logger.info(f"✅ SWARM Architect (LLM): ready={ready}, confidence={confidence:.2f}")
                return SwarmArchitectResult(
                    ready=ready,
                    confidence=confidence,
                    feedback=feedback,
                    reasoning=reasoning,
                    suggested_actors=suggested,
                    missing_items=missing_items
                )
                
            except Exception as e:
                logger.warning(f"⚠️ LLM architect validation failed: {e}, using minimal fallback")
        
        # Minimal fallback (explicit uncertainty, NOT heuristic judgment)
        logger.info("⚠️ SWARM Architect: Using minimal fallback (no LLM available)")
        return SwarmArchitectResult(
            ready=True,
            confidence=0.5,
            feedback="LLM validation unavailable - proceeding with low confidence",
            reasoning="No LLM validator available for pre-validation",
            suggested_actors=[],
            missing_items=[]
        )
    
    async def run_swarm_auditor_stream(
        self,
        actor_name: str,
        actor_output: Any,
        trajectory: List[Dict],
        user_goal: str,
        all_outputs: Dict[str, Any],
        recursion_depth: int = 0
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Check if actors are coordinating and making progress toward goal with event streaming.
        
        A-TEAM: Uses LLM-based validation with RLM decomposition.
        
        Args:
            actor_name: Name of actor that just executed
            actor_output: Raw output from actor
            trajectory: Full execution trace
            user_goal: Original user query/goal
            all_outputs: All previous actors' outputs
            recursion_depth: Current recursion depth for RLM
        
        Yields:
            Event dictionaries with module and conversational message
        Returns:
            SwarmAuditorResult with coordination assessment
        """
        logger.info(f"🔍 Running SWARM Auditor for {actor_name} (LLM-based, depth={recursion_depth})")
        yield {"module": "Synapse.core.swarm_validation", "message": f"I am running SWARM Auditor validation for actor {actor_name} at depth {recursion_depth}"}
        
        # Prepare inputs for LLM
        output_summary = self._summarize_output(actor_output)
        previous_summary = self._summarize_outputs(all_outputs)
        trajectory_summary = self._summarize_trajectory(trajectory)
        yield {"module": "Synapse.core.swarm_validation", "message": "I am preparing validation inputs: summarizing actor output and trajectory"}
        
        # Use LLM validator if available
        if self._auditor_validator:
            try:
                yield {"module": "Synapse.core.swarm_validation", "message": "I am using LLM to validate actor coordination and goal alignment"}
                result = self._auditor_validator(
                    actor_name=actor_name,
                    actor_output_summary=smart_truncate(output_summary, max_tokens=500),
                    user_goal=smart_truncate(user_goal, max_tokens=250) if user_goal else "",
                    previous_outputs_summary=smart_truncate(previous_summary, max_tokens=500),
                    trajectory_summary=smart_truncate(trajectory_summary, max_tokens=500)
                )
                
                # Parse LLM output
                coordinated = bool(result.coordinated) if hasattr(result, 'coordinated') else True
                goal_aligned = bool(result.goal_aligned) if hasattr(result, 'goal_aligned') else True
                confidence = float(result.confidence) if hasattr(result, 'confidence') else 0.8
                reasoning = str(result.reasoning) if hasattr(result, 'reasoning') else ""
                
                should_search = bool(result.should_web_search) if hasattr(result, 'should_web_search') else False
                search_query = str(result.web_search_query) if hasattr(result, 'web_search_query') else ""
                
                issues = []
                if hasattr(result, 'issues_found'):
                    try:
                        issues = json.loads(result.issues_found)
                    except Exception:
                        issues = [result.issues_found] if result.issues_found else []
                
                feedback_to = []
                if hasattr(result, 'feedback_for_actors'):
                    try:
                        fb_dict = json.loads(result.feedback_for_actors)
                        feedback_to = list(fb_dict.keys())
                    except Exception:
                        pass
                
                feedback = reasoning if reasoning else ("Coordination OK" if coordinated else "Issues found")
                
                logger.info(f"✅ SWARM Auditor (LLM): coordinated={coordinated}, goal_aligned={goal_aligned}, confidence={confidence:.2f}")
                yield {"module": "Synapse.core.swarm_validation", "message": f"I have completed validation: coordinated={coordinated}, goal_aligned={goal_aligned}, confidence={confidence:.2f}"}
                if should_search:
                    logger.info(f"🔍 LLM suggests web search: {search_query}")
                    yield {"module": "Synapse.core.swarm_validation", "message": f"I recommend web search with query: {search_query}"}
                if issues:
                    yield {"module": "Synapse.core.swarm_validation", "message": f"I found {len(issues)} coordination issues"}
                
                result_obj = SwarmAuditorResult(
                    coordinated=coordinated,
                    goal_aligned=goal_aligned,
                    confidence=confidence,
                    feedback=feedback,
                    reasoning=reasoning,
                    trigger_feedback_to=feedback_to,
                    should_web_search=should_search,
                    web_search_query=search_query,
                    issues_found=issues
                )
                yield {"type": "result", "result": result_obj, "module": "Synapse.core.swarm_validation", "message": "I am returning the auditor validation result"}
                return
                
            except Exception as e:
                logger.warning(f"⚠️ LLM auditor validation failed: {e}, using minimal fallback")
                yield {"module": "Synapse.core.swarm_validation", "message": f"I encountered an error during LLM validation: {str(e)}"}
        
        # Minimal fallback (explicit uncertainty, NOT heuristic judgment)
        logger.info("⚠️ SWARM Auditor: Using minimal fallback (no LLM available)")
        yield {"module": "Synapse.core.swarm_validation", "message": "I am using minimal fallback validation (no LLM available)"}
        result_obj = SwarmAuditorResult(
            coordinated=True,
            goal_aligned=True,
            confidence=0.5,
            feedback="LLM validation unavailable - proceeding with low confidence",
            reasoning="No LLM validator available for post-validation",
            trigger_feedback_to=[],
            should_web_search=False,
            web_search_query="",
            issues_found=[]
        )
        yield {"type": "result", "result": result_obj, "module": "Synapse.core.swarm_validation", "message": "I am returning the fallback validation result"}
        return
    
    async def run_swarm_auditor(
        self,
        actor_name: str,
        actor_output: Any,
        trajectory: List[Dict],
        user_goal: str,
        all_outputs: Dict[str, Any],
        recursion_depth: int = 0
    ) -> SwarmAuditorResult:
        """
        Synchronous wrapper for run_swarm_auditor_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use sync version directly
                return await self._run_swarm_auditor_sync(actor_name, actor_output, trajectory, user_goal, all_outputs, recursion_depth)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            result = None
            async for event in self.run_swarm_auditor_stream(actor_name, actor_output, trajectory, user_goal, all_outputs, recursion_depth):
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            return result
        
        return asyncio.run(_run())
    
    async def _run_swarm_auditor_sync(
        self,
        actor_name: str,
        actor_output: Any,
        trajectory: List[Dict],
        user_goal: str,
        all_outputs: Dict[str, Any],
        recursion_depth: int = 0
    ) -> SwarmAuditorResult:
        """
        Synchronous implementation (for backward compatibility).
        """
        logger.info(f"🔍 Running SWARM Auditor for {actor_name} (LLM-based, depth={recursion_depth})")
        
        # Prepare inputs for LLM
        output_summary = self._summarize_output(actor_output)
        previous_summary = self._summarize_outputs(all_outputs)
        trajectory_summary = self._summarize_trajectory(trajectory)
        
        # Use LLM validator if available
        if self._auditor_validator:
            try:
                result = self._auditor_validator(
                    actor_name=actor_name,
                    actor_output_summary=smart_truncate(output_summary, max_tokens=500),
                    user_goal=smart_truncate(user_goal, max_tokens=250) if user_goal else "",
                    previous_outputs_summary=smart_truncate(previous_summary, max_tokens=500),
                    trajectory_summary=smart_truncate(trajectory_summary, max_tokens=500)
                )
                
                # Parse LLM output
                coordinated = bool(result.coordinated) if hasattr(result, 'coordinated') else True
                goal_aligned = bool(result.goal_aligned) if hasattr(result, 'goal_aligned') else True
                confidence = float(result.confidence) if hasattr(result, 'confidence') else 0.8
                reasoning = str(result.reasoning) if hasattr(result, 'reasoning') else ""
                
                should_search = bool(result.should_web_search) if hasattr(result, 'should_web_search') else False
                search_query = str(result.web_search_query) if hasattr(result, 'web_search_query') else ""
                
                issues = []
                if hasattr(result, 'issues_found'):
                    try:
                        issues = json.loads(result.issues_found)
                    except Exception:
                        issues = [result.issues_found] if result.issues_found else []
                
                feedback_to = []
                if hasattr(result, 'feedback_for_actors'):
                    try:
                        fb_dict = json.loads(result.feedback_for_actors)
                        feedback_to = list(fb_dict.keys())
                    except Exception:
                        pass
                
                feedback = reasoning if reasoning else ("Coordination OK" if coordinated else "Issues found")
                
                logger.info(f"✅ SWARM Auditor (LLM): coordinated={coordinated}, goal_aligned={goal_aligned}, confidence={confidence:.2f}")
                if should_search:
                    logger.info(f"🔍 LLM suggests web search: {search_query}")
                
                return SwarmAuditorResult(
                    coordinated=coordinated,
                    goal_aligned=goal_aligned,
                    confidence=confidence,
                    feedback=feedback,
                    reasoning=reasoning,
                    trigger_feedback_to=feedback_to,
                    should_web_search=should_search,
                    web_search_query=search_query,
                    issues_found=issues
                )
                
            except Exception as e:
                logger.warning(f"⚠️ LLM auditor validation failed: {e}, using minimal fallback")
        
        # Minimal fallback (explicit uncertainty, NOT heuristic judgment)
        logger.info("⚠️ SWARM Auditor: Using minimal fallback (no LLM available)")
        return SwarmAuditorResult(
            coordinated=True,
            goal_aligned=True,
            confidence=0.5,
            feedback="LLM validation unavailable - proceeding with low confidence",
            reasoning="No LLM validator available for post-validation",
            trigger_feedback_to=[],
            should_web_search=False,
            web_search_query="",
            issues_found=[]
        )
    
    # =========================================================================
    # HELPER METHODS (for summarization, NOT validation logic)
    # =========================================================================
    
    def _summarize_context(self, context: Dict[str, Any]) -> str:
        """Summarize context for LLM input (NOT a validation heuristic)."""
        if not context:
            return "No context available"
        
        parts = []
        for key, val in context.items():
            val_str = str(val)[:200]
            parts.append(f"- {key}: {val_str}")
        
        return "\n".join(parts[:20])
    
    def _summarize_output(self, output: Any) -> str:
        """Summarize actor output for LLM input (NOT a validation heuristic)."""
        if output is None:
            return "No output produced"
        
        if isinstance(output, str):
            return smart_truncate(output, max_tokens=500)
        
        if isinstance(output, dict):
            return smart_truncate(json.dumps(output, default=str), max_tokens=500)
        
        if hasattr(output, '_store'):
            return smart_truncate(json.dumps(output._store, default=str), max_tokens=500)
        
        return smart_truncate(str(output), max_tokens=500)
    
    def _summarize_outputs(self, outputs: Dict[str, Any]) -> str:
        """Summarize all outputs for LLM input (NOT a validation heuristic)."""
        if not outputs:
            return "No previous outputs"
        
        parts = []
        for actor, out in outputs.items():
            out_str = self._summarize_output(out)[:500]
            parts.append(f"[{actor}]: {out_str}")
        
        return "\n".join(parts[:10])
    
    def _summarize_trajectory(self, trajectory: List[Dict]) -> str:
        """Summarize trajectory for LLM input (NOT a validation heuristic)."""
        if not trajectory:
            return "No trajectory recorded yet"
        
        parts = []
        for i, step in enumerate(trajectory[-5:]):
            step_type = step.get('step', 'unknown')
            error = step.get('error', None)
            parts.append(f"Step {i+1}: {step_type}" + (f" (ERROR: {error})" if error else ""))
        
        return "\n".join(parts)
