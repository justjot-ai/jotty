"""
Synapse v6.4 - Smart Context Manager
==================================

A-Team Critical Fix: Intelligent context management that:
1. Catches API token limit errors and auto-recovers
2. Preserves task-critical info (TODO, goals, critical memories)
3. Compresses intelligently based on task needs
4. NEVER loses info needed for future tasks

This is the SMART context manager the user requested.
"""

import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import dspy

logger = logging.getLogger(__name__)


# =============================================================================
# PRIORITY LEVELS FOR CONTEXT PRESERVATION
# =============================================================================

class ContextPriority(Enum):
    """Priority levels for context chunks during compression."""
    CRITICAL = 1    # NEVER compress: current task, TODO state, goal
    HIGH = 2        # Compress last: recent memories, errors, tool results
    MEDIUM = 3      # Compress when needed: trajectory, history
    LOW = 4         # Compress first: verbose logs, old memories


@dataclass
class ContextChunk:
    """A chunk of context with metadata for smart compression."""
    content: str
    priority: ContextPriority
    category: str  # "task", "todo", "memory", "trajectory", "tool_result"
    tokens: int = 0
    is_compressed: bool = False
    original_tokens: int = 0
    
    def __post_init__(self):
        if not self.tokens:
            from .token_utils import count_tokens_accurate
            self.tokens = count_tokens_accurate(self.content)
        if not self.original_tokens:
            self.original_tokens = self.tokens


class ContextPrioritySignature(dspy.Signature):
    """
    LLM-based priority classification for context chunks.
    """
    category = dspy.InputField(desc="Chunk category")
    content = dspy.InputField(desc="Chunk content")
    goal = dspy.InputField(desc="Current goal")
    
    reasoning = dspy.OutputField(desc="Why this priority was chosen")
    priority = dspy.OutputField(desc="One of: CRITICAL, HIGH, MEDIUM, LOW")


class ContextOverflowSignature(dspy.Signature):
    """
    LLM-based overflow detection from error context.
    """
    error_message = dspy.InputField(desc="Error message or summary")
    current_tokens = dspy.InputField(desc="Current token count")
    max_tokens = dspy.InputField(desc="Maximum allowed tokens")
    
    is_overflow = dspy.OutputField(desc="True if error indicates overflow")


# 🔴 A-TEAM FIX: Use UnifiedCompressor instead of duplicate signature
# (Signature removed - see unified_compression.py)


# =============================================================================
# SMART CONTEXT MANAGER
# =============================================================================

class SmartContextManager:
    """
    Intelligent context manager that NEVER loses critical info.
    
    Features:
    1. Task-aware prioritization
    2. API error catching and recovery
    3. Hierarchical compression
    4. TODO preservation
    5. Memory consolidation instead of truncation
    """
    
    def __init__(self, 
                 max_tokens: int = 28000,
                 safety_margin: float = 0.85,  # Use 85% of max
                 enable_api_error_recovery: bool = True,
                 config=None):
        """
        Args:
            max_tokens: Maximum context tokens (from model config)
            safety_margin: Use only this fraction of max
            enable_api_error_recovery: Catch and recover from API errors
            config: Optional SynapseConfig for lightweight model routing in compression
        """
        self.max_tokens = max_tokens
        self.effective_limit = int(max_tokens * safety_margin)
        self.enable_api_error_recovery = enable_api_error_recovery
        self.config = config
        self._token_model = None
        
        # LLM-based classifiers
        self._priority_classifier = dspy.ChainOfThought(ContextPrioritySignature)
        self._overflow_detector = dspy.ChainOfThought(ContextOverflowSignature)
        
        # 🔴 A-TEAM FIX: Use UnifiedCompressor with lightweight model config
        from .unified_compression import UnifiedCompressor
        self._compressor = UnifiedCompressor(config=config)
        
        # Statistics
        self.compressions_count = 0
        self.api_errors_recovered = 0
        self.total_tokens_saved = 0
        
        # Current context state
        self.current_chunks: List[ContextChunk] = []
        
        # TODO/Task preservation
        self._current_todo: Optional[str] = None
        self._current_goal: Optional[str] = None
        self._critical_memories: List[str] = []
        
        # Compression history for learning
        self.compression_history: List[Dict] = []
        
        # LLM summarizer for smart compression
        self._init_summarizer()
    
    def _init_summarizer(self):
        """Initialize LLM-based summarizer for smart compression."""
        class SummarizeSignature(dspy.Signature):
            """Summarize text while preserving critical information."""
            content: str = dspy.InputField(desc="Content to summarize")
            max_tokens: int = dspy.InputField(desc="Target length in tokens")
            summary: str = dspy.OutputField(desc="Compressed summary preserving key info")
        
        try:
            self.summarizer = dspy.ChainOfThought(SummarizeSignature)
        except (Exception) as e:
            logger.warning(f"Failed to initialize summarizer: {e}")
            self.summarizer = None
    
    # =========================================================================
    # CONTEXT REGISTRATION
    # =========================================================================
    
    def register_todo(self, todo_content: str):
        """Register current TODO for preservation (NEVER compressed)."""
        self._current_todo = todo_content
        logger.debug(f"📋 Registered TODO ({len(todo_content)} chars)")
    
    def register_goal(self, goal: str):
        """Register current goal for preservation."""
        self._current_goal = goal
        logger.debug(f"🎯 Registered goal: {goal}...")
    
    def register_critical_memory(self, memory: str):
        """Register a critical memory that must be preserved."""
        self._critical_memories.append(memory)
        logger.debug(f"💾 Registered critical memory ({len(memory)} chars)")
    
    def add_chunk(self, content: str, category: str, priority: ContextPriority = None):
        """Add a context chunk with auto-detected priority."""
        if priority is None:
            priority = self._auto_detect_priority(category, content)
        
        chunk = ContextChunk(
            content=content,
            priority=priority,
            category=category
        )
        self.current_chunks.append(chunk)
    
    def _auto_detect_priority(self, category: str, content: str) -> ContextPriority:
        """Auto-detect priority based on category and content."""
        try:
            result = self._priority_classifier(
                category=category,
                content=content[:1500],
                goal=self._current_goal or ""
            )
            priority_str = str(getattr(result, "priority", "MEDIUM")).upper()
            return ContextPriority[priority_str] if priority_str in ContextPriority.__members__ else ContextPriority.MEDIUM
        except Exception as e:
            logger.debug(f"Priority classification failed: {e}")
            return ContextPriority.MEDIUM
    
    # =========================================================================
    # CONTEXT BUILDING
    # =========================================================================
    
    def build_context(self, 
                      system_prompt: str,
                      user_input: str,
                      additional_context: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Build context that fits within limits while preserving critical info.
        
        Returns dict with:
        - context: The built context string
        - truncated: Whether truncation occurred
        - preserved: What critical info was preserved
        - stats: Compression statistics
        """
        # Calculate fixed costs
        system_tokens = self.estimate_tokens(system_prompt)
        input_tokens = self.estimate_tokens(user_input)
        fixed_cost = system_tokens + input_tokens
        
        # Reserved space for CRITICAL items
        todo_cost = self.estimate_tokens(self._current_todo or "")
        goal_cost = self.estimate_tokens(self._current_goal or "")
        critical_mem_cost = sum(self.estimate_tokens(m) for m in self._critical_memories)
        reserved_cost = todo_cost + goal_cost + critical_mem_cost
        
        # Available budget for other context
        available = self.effective_limit - fixed_cost - reserved_cost
        
        if available < 500:
            # Not enough space - need aggressive compression
            logger.warning(f"⚠️ Very limited context budget: {available} tokens")
            available = max(500, available)
        
        # Sort chunks by priority (CRITICAL first)
        sorted_chunks = sorted(self.current_chunks, key=lambda c: c.priority.value)
        
        # Build context
        included_chunks = []
        tokens_used = 0
        
        for chunk in sorted_chunks:
            if tokens_used + chunk.tokens <= available:
                included_chunks.append(chunk)
                tokens_used += chunk.tokens
            elif chunk.priority == ContextPriority.CRITICAL:
                # MUST include critical - compress others
                compressed = self._compress_chunk(chunk, available - tokens_used)
                included_chunks.append(compressed)
                tokens_used += compressed.tokens
            elif chunk.priority == ContextPriority.HIGH and available - tokens_used > 200:
                # Try to fit HIGH priority with compression
                target_tokens = min(13000, max(256, available - tokens_used))
                compressed = self._compress_chunk(chunk, target_tokens)
                included_chunks.append(compressed)
                tokens_used += compressed.tokens
        
        # Build final context
        context_parts = []
        
        # Always include TODO
        if self._current_todo:
            context_parts.append(f"## Current TODO\n{self._current_todo}")
        
        # Always include goal
        if self._current_goal:
            context_parts.append(f"## Goal\n{self._current_goal}")
        
        # Include critical memories
        for mem in self._critical_memories:  # Max 5
            context_parts.append(f"## Critical Memory\n{mem}")
        
        # Include other chunks
        for chunk in included_chunks:
            context_parts.append(f"## {chunk.category}\n{chunk.content}")
        
        final_context = "\n\n".join(context_parts)
        
        return {
            'system_prompt': system_prompt,
            'user_input': user_input,
            'context': final_context,
            'truncated': len(included_chunks) < len(self.current_chunks),
            'preserved': {
                'todo': bool(self._current_todo),
                'goal': bool(self._current_goal),
                'critical_memories': len(self._critical_memories),
                'chunks_included': len(included_chunks),
                'chunks_total': len(self.current_chunks)
            },
            'stats': {
                'total_tokens': fixed_cost + reserved_cost + tokens_used,
                'effective_limit': self.effective_limit,
                'budget_remaining': self.effective_limit - fixed_cost - reserved_cost - tokens_used
            }
        }
    
    # =========================================================================
    # COMPRESSION
    # =========================================================================
    
    def _compress_chunk(self, chunk: ContextChunk, target_tokens: int) -> ContextChunk:
        """Compress a chunk to fit within target token budget."""
        if chunk.tokens <= target_tokens:
            return chunk
        
        self.compressions_count += 1
        original_tokens = chunk.tokens
        
        # Try LLM summarization for important content
        if self.summarizer and chunk.priority.value <= 2:
            try:
                result = self.summarizer(
                    content=chunk.content,
                    max_tokens=target_tokens
                )
                compressed_content = result.summary
            except Exception as e:
                logger.warning(f"LLM compression failed, using simple compress: {e}")
                compressed_content = self._simple_compress(chunk.content, target_tokens)
        else:
            compressed_content = self._simple_compress(chunk.content, target_tokens)
        
        new_chunk = ContextChunk(
            content=compressed_content,
            priority=chunk.priority,
            category=chunk.category,
            is_compressed=True,
            original_tokens=original_tokens
        )
        
        self.total_tokens_saved += original_tokens - new_chunk.tokens
        
        return new_chunk
    
    def _simple_compress(self, text: str, target_tokens: int) -> str:
        """
        LLM-based compression using ContentIngestionPipeline.
        
        🔧 FIX: Uses ContentIngestionPipeline for automatic chunking if content is too large.
        """
        try:
            # 🔧 FIX: Use ContentIngestionPipeline instead of UnifiedCompressor directly
            # Pipeline handles chunking automatically for large content
            if not hasattr(self, '_content_ingestion_pipeline'):
                from .content_ingestion import ContentIngestionPipeline
                self._content_ingestion_pipeline = ContentIngestionPipeline(config=self.config)
            
            result = self._content_ingestion_pipeline.process_sync(
                content=text,
                max_tokens=target_tokens,
                query="Compress content while preserving critical information",
                goal="Context chunk compression",
                context_type="context_chunk"
            )
            # process_sync returns IngestionResult with .content attribute
            return result.content
        except Exception as e:
            logger.debug(f"LLM compression failed: {e}")
            return text
    
    # =========================================================================
    # API ERROR RECOVERY
    # =========================================================================
    
    def check_and_compress(self, context: str) -> str:
        """
        PROACTIVE: Check context length and compress BEFORE API call.
        
        This prevents "input too long" errors by compressing proactively.
        
        Returns: Original context if within limits, compressed context otherwise
        """
        if not context:
            return context
        
        # Estimate tokens accurately
        estimated_tokens = self.estimate_tokens(context)
        
        # If within safe limit, return as-is
        if estimated_tokens <= self.effective_limit:
            return context
        
        # Need compression - log warning
        logger.warning(f"⚠️ Context too long ({estimated_tokens} tokens > {self.effective_limit} limit). Compressing proactively...")
        
        # Compress to target
        target_tokens = self.effective_limit
        compressed = self._simple_compress(context, target_tokens)
        
        compressed_tokens = self.estimate_tokens(compressed)
        logger.info(f"✅ Context compressed proactively: {estimated_tokens} → {compressed_tokens} tokens")
        
        return compressed
    
    def catch_and_recover(self, error: Exception, current_context: str) -> Optional[str]:
        """
        REACTIVE: Catch API token limit errors and recover with compressed context.
        
        This is a fallback if proactive compression didn't catch everything.
        
        Returns: Compressed context if recoverable, None otherwise
        """
        if not self.enable_api_error_recovery:
            return None
        
        try:
            result = self._overflow_detector(
                error_message=str(error)[:500],
                current_tokens=str(self.estimate_tokens(current_context)),
                max_tokens=str(self.effective_limit)
            )
            is_overflow = bool(getattr(result, "is_overflow", False))
            if not is_overflow:
                return None
        except Exception as e:
            logger.debug(f"Overflow detection failed: {e}")
            return None
        
        self.api_errors_recovered += 1
        logger.warning("🔄 Token limit error detected (LLM) - compressing context...")
        
        compressed = self._simple_compress(current_context, self.effective_limit)
        logger.info(f"✅ Context compressed (reactive): {len(current_context)} → {len(compressed)} chars")
        return compressed
    
    # =========================================================================
    # UTILITIES
    # =========================================================================
    
    def estimate_tokens(self, text: str) -> int:
        """Estimate token count from text."""
        if not text:
            return 0
        from .token_utils import count_tokens_accurate
        return count_tokens_accurate(text)
    
    def clear_chunks(self):
        """Clear non-persistent chunks."""
        self.current_chunks = []
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get context manager statistics."""
        return {
            'max_tokens': self.max_tokens,
            'effective_limit': self.effective_limit,
            'compressions_count': self.compressions_count,
            'api_errors_recovered': self.api_errors_recovered,
            'total_tokens_saved': self.total_tokens_saved,
            'current_chunks': len(self.current_chunks),
            'critical_memories': len(self._critical_memories),
            'has_todo': bool(self._current_todo),
            'has_goal': bool(self._current_goal)
        }


# =============================================================================
# INTEGRATION DECORATOR
# =============================================================================

def with_smart_context(max_tokens: int = 28000):
    """
    Decorator to add smart context management to any agent.
    
    Usage:
        @with_smart_context(max_tokens=28000)
        async def my_agent(query: str, context: str):
            ...
    """
    def decorator(func):
        manager = SmartContextManager(max_tokens=max_tokens)
        
        async def wrapper(*args, **kwargs):
            # Try to execute
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                # Check if recoverable
                context = kwargs.get('context', str(args))
                compressed = manager.catch_and_recover(e, context)
                
                if compressed:
                    kwargs['context'] = compressed
                    logger.info("🔄 Retrying with compressed context...")
                    return await func(*args, **kwargs)
                
                raise
        
        return wrapper
    return decorator


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'SmartContextManager',
    'ContextChunk',
    'ContextPriority',
    'with_smart_context'
]

