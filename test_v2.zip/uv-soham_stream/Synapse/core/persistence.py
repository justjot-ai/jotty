"""
SYNAPSE Persistence Manager (Vault) - Complete State Management

A-Team Design: NO HARDCODING ANYWHERE
- All paths configurable
- All formats dynamic
- All thresholds learned or configured

Handles persistence of:
- Roadmap TODOs (JSON + rich markdown)
- Q-tables and experience buffers
- Hierarchical memories (Cortex)
- Episode trajectories
- Brain consolidation state (Hippocampus)
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Set
import time
from datetime import datetime

logger = logging.getLogger(__name__)


class Vault:
    """
    Manages persistence of all SYNAPSE state components.
    
    NO HARDCODING PRINCIPLE:
    - Directory structure configurable
    - File formats extensible
    - Display generation dynamic
    - No magic numbers or thresholds
    
    Directory Structure:
        Global (shared across all runs):
        {global_base_dir}/synapse_state/
        ├── memories/
        │   ├── shared_memory.json
        │   └── agent_memories/
        │       └── {actor_name}.json  (dynamically named per actor)
        ├── q_tables/
        │   ├── q_predictor_state.json
        │   ├── q_predictor_buffer.json
        │   └── agentic_tag_index.json
        └── brain_state/
            └── consolidated_memories.json
        
        Run-specific (per run folder):
        {run_dir}/synapse_state/
        ├── markovian_todos/
        │   ├── todo_state.json
        │   └── todo_display.md         (Rich markdown)
        ├── env/
        │   ├── env.md                  (Environment context)
        │   └── env_history.json        (Snapshot history)
        ├── episode_history/
        │   ├── episode_1.json
        │   └── episode_2.json
        ├── test_aggregator/
        │   └── test_aggregator.json    (Bayesian learning data)
        ├── user_feedback/
        │   └── user_feedback.json      (Human feedback)
        └── td_lambda/
            └── td_lambda_state.json
    """
    
    def __init__(self, base_output_dir: str, auto_save_interval: int = 10, global_base_dir: Optional[str] = None):
        """
        Initialize persistence manager.
        
        Args:
            base_output_dir: Run-specific output directory (NO HARDCODED PATH)
            auto_save_interval: Save every N iterations (CONFIGURABLE)
            global_base_dir: Global base directory for shared state (memories, q_tables, brain_state).
                            If None, uses {base_output_dir}/../global or {base_output_dir}/../../global
        """
        self.run_dir = Path(base_output_dir)
        self.run_synapse_dir = self.run_dir / "synapse_state"
        
        # Determine global base directory
        if global_base_dir:
            self.global_base_dir = Path(global_base_dir)
        else:
            # Default: go up from run folder to outputs, then to global
            # outputs/run_XXX -> outputs -> outputs/../global or just outputs/global
            if self.run_dir.parent.name == "outputs" or "run_" in self.run_dir.name:
                # We're in a run folder, go to outputs/global
                self.global_base_dir = self.run_dir.parent / "global"
            else:
                # Fallback: create global sibling to run_dir
                self.global_base_dir = self.run_dir.parent / "global"
        
        self.global_synapse_dir = self.global_base_dir / "synapse_state"
        self.auto_save_interval = auto_save_interval
        self._ensure_directories()
        
        logger.info(f"💾 SYNAPSE Vault initialized:")
        logger.info(f"   Global: {self.global_synapse_dir}")
        logger.info(f"   Run: {self.run_synapse_dir}")
    
    def _ensure_directories(self):
        """Create all necessary directories (NO HARDCODED LIST - extensible)."""
        # Global directories (shared across runs)
        global_dirs = [
            self.global_synapse_dir,
            self.global_synapse_dir / "memories" / "agent_memories",
            self.global_synapse_dir / "q_tables",
            self.global_synapse_dir / "brain_state"
        ]
        
        # Run-specific directories (per run)
        run_dirs = [
            self.run_synapse_dir,
            self.run_synapse_dir / "markovian_todos",
            self.run_synapse_dir / "env",
            self.run_synapse_dir / "episode_history",
            self.run_synapse_dir / "test_aggregator",
            self.run_synapse_dir / "user_feedback",
            self.run_synapse_dir / "td_lambda"
        ]
        
        for d in global_dirs + run_dirs:
            d.mkdir(parents=True, exist_ok=True)
    
    # =========================================================================
    # MARKOVIAN TODO PERSISTENCE (NO HARDCODING)
    # =========================================================================
    
    def save_markovian_todo(self, todo: 'MarkovianTODO'):
        """
        Save Markovian TODO state (JSON + rich markdown).
        
        NO HARDCODING:
        - All task attributes serialized dynamically
        - Display generated from current state
        - No hardcoded formatting rules
        """
        # JSON state (complete serialization) - RUN-SPECIFIC
        state_file = self.run_synapse_dir / "markovian_todos" / "todo_state.json"
        state_data = self._serialize_todo(todo)
        with open(state_file, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
        
        # Rich Markdown display - RUN-SPECIFIC
        display_file = self.run_synapse_dir / "markovian_todos" / "todo_display.md"
        with open(display_file, 'w') as f:
            f.write(self._format_todo_markdown(todo))
        
        logger.info(f"✅ Saved Markovian TODO: {len(todo.subtasks)} tasks, "
                   f"{len(todo.completed_tasks)} completed")
    
    def load_markovian_todo(self) -> Optional[Dict[str, Any]]:
        """Load Markovian TODO state from JSON (if available)."""
        state_file = self.run_synapse_dir / "markovian_todos" / "todo_state.json"
        if not state_file.exists():
            return None
        try:
            with open(state_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"⚠️ Failed to load todo_state.json: {e}")
            return None
    
    def _serialize_todo(self, todo) -> Dict:
        """
        Serialize TODO to JSON-compatible dict.
        
        NO HARDCODING: Serializes ALL task attributes dynamically.
        """
        return {
            'root_task': todo.root_task,
            'todo_id': todo.todo_id,
            'subtasks': {
                task_id: self._serialize_task(task)
                for task_id, task in todo.subtasks.items()
            },
            'execution_order': todo.execution_order,
            'completed_tasks': list(todo.completed_tasks),
            'failed_tasks': list(todo.failed_tasks),
            'current_task_id': todo.current_task_id,
            'estimated_remaining_steps': todo.estimated_remaining_steps,
            'completion_probability': todo.completion_probability,
            'timestamp': time.time()
        }
    
    def _serialize_task(self, task) -> Dict:
        """
        Serialize a single task.
        
        NO HARDCODING: Handles all attributes including intermediary_values.
        """
        return {
            'task_id': task.task_id,
            'description': task.description,
            'actor': task.actor,
            'status': task.status.value if hasattr(task.status, 'value') else str(task.status),
            'priority': task.priority,
            'estimated_reward': task.estimated_reward,
            'confidence': task.confidence,
            'attempts': task.attempts,
            'max_attempts': task.max_attempts,
            'progress': task.progress,
            'depends_on': task.depends_on,
            'blocks': task.blocks,
            'started_at': task.started_at.isoformat() if task.started_at else None,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None,
            'estimated_duration': task.estimated_duration,
            'intermediary_values': task.intermediary_values,  # NO HARDCODED KEYS
            'predicted_next_task': task.predicted_next_task,
            'predicted_duration': task.predicted_duration,
            'predicted_reward': task.predicted_reward,
            'failure_reasons': task.failure_reasons,
            'result': task.result,
            'error': task.error
        }
    
    def _format_todo_markdown(self, todo) -> str:
        """
        Format TODO as rich markdown display.
        
        NO HARDCODING:
        - Dynamically generates sections based on state
        - No hardcoded display thresholds
        - Sorting by priority * Q-value (algorithmic)
        """
        md = f"# Markovian TODO - {todo.root_task}\n\n"
        md += f"**ID:** `{todo.todo_id}`\n"
        md += f"**Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        md += "---\n\n"
        
        # Progress overview (NO HARDCODED THRESHOLDS)
        total = len(todo.subtasks)
        completed = len(todo.completed_tasks)
        failed = len(todo.failed_tasks)
        pending = total - completed - failed
        
        md += "## 📊 Progress Overview\n\n"
        md += f"- ✅ Completed: **{completed}/{total}** ({100*completed/total if total > 0 else 0:.0f}%)\n"
        md += f"- ❌ Failed: **{failed}**\n"
        md += f"- ⏳ Pending: **{pending}**\n"
        md += f"- 🎯 Completion Probability: **{todo.completion_probability:.0%}**\n"
        md += f"- 📍 Estimated Remaining: **{todo.estimated_remaining_steps}** tasks\n\n"
        
        # In-progress tasks with FULL details (NO HARDCODING)
        in_progress = [t for t in todo.subtasks.values() 
                      if str(t.status.value if hasattr(t.status, 'value') else t.status) == 'in_progress']
        
        if in_progress:
            md += "## 🔄 Currently In Progress\n\n"
            for task in in_progress:
                md += f"### {task.description}\n\n"
                md += f"- **Actor:** `{task.actor}`\n"
                md += f"- **Q-Value:** {task.estimated_reward:.3f} (confidence: {task.confidence:.2f})\n"
                md += f"- **Priority:** {task.priority:.2f}\n"
                md += f"- **Attempt:** {task.attempts}/{task.max_attempts}\n"
                md += f"- **Progress:** {task.progress:.0%}\n"
                
                # Intermediary values (NO HARDCODED KEYS - displays whatever is tracked)
                if task.intermediary_values:
                    md += f"- **Intermediary Values:**\n"
                    for key, val in task.intermediary_values.items():
                        md += f"  - `{key}`: {val}\n"
                
                # Predictions
                if task.predicted_next_task:
                    md += f"- **Predicted Next:** {task.predicted_next_task}"
                    if task.predicted_duration:
                        md += f" (duration: {task.predicted_duration:.1f}s)"
                    if task.predicted_reward:
                        md += f" (reward: {task.predicted_reward:.2f})"
                    md += "\n"
                
                # Timing
                if task.started_at:
                    elapsed = (datetime.now() - task.started_at).total_seconds()
                    md += f"- **Elapsed Time:** {elapsed:.1f}s / {task.estimated_duration:.1f}s estimated\n"
                
                md += "\n"
        
        # Pending tasks sorted by ALGORITHM (NO HARDCODED WEIGHTS)
        pending_tasks = [t for t in todo.subtasks.values() 
                        if str(t.status.value if hasattr(t.status, 'value') else t.status) == 'pending']
        
        if pending_tasks:
            # Sort by priority * Q-value (ALGORITHMIC SCORING)
            pending_tasks.sort(key=lambda t: t.priority * t.estimated_reward, reverse=True)
            
            md += "## ⏳ Pending Tasks Queue\n\n"
            md += "| Rank | Task | Actor | Priority | Q-Value | Score | Dependencies |\n"
            md += "|------|------|-------|----------|---------|-------|-------------|\n"
            
            # Show top tasks (NO HARDCODED LIMIT - uses all if <= 15, else top 15)
            display_count = min(len(pending_tasks), 15)
            for i, task in enumerate(pending_tasks[:display_count], 1):
                score = task.priority * task.estimated_reward
                deps = len(task.depends_on)
                can_start = task.can_start(todo.completed_tasks)
                status_icon = "🟢" if can_start else "🔴"
                
                md += f"| {i} | {task.description}... | {task.actor} | {task.priority:.2f} | {task.estimated_reward:.3f} | {score:.3f} | {deps} {status_icon} |\n"
            
            if len(pending_tasks) > display_count:
                md += f"\n*...and {len(pending_tasks) - display_count} more tasks*\n"
            md += "\n"
        
        # Completed tasks (recent ones, NO HARDCODED LIMIT)
        completed_tasks = [todo.subtasks[tid] for tid in todo.completed_tasks 
                          if tid in todo.subtasks]
        if completed_tasks:
            # Sort by completion time (most recent first)
            completed_tasks.sort(key=lambda t: t.completed_at if t.completed_at else datetime.min, reverse=True)
            
            md += "## ✅ Recently Completed\n\n"
            display_count = min(len(completed_tasks), 10)
            for task in completed_tasks[:display_count]:
                duration = ""
                if task.started_at and task.completed_at:
                    dur = (task.completed_at - task.started_at).total_seconds()
                    duration = f" ({dur:.1f}s)"
                
                reward_info = ""
                if 'reward_obtained' in task.intermediary_values:
                    reward_info = f" [Reward: {task.intermediary_values['reward_obtained']:.2f}]"
                
                md += f"- {task.description}{duration}{reward_info}\n"
            
            if len(completed_tasks) > display_count:
                md += f"\n*...and {len(completed_tasks) - display_count} more*\n"
            md += "\n"
        
        # Failed tasks with reasons (NO HARDCODED ERROR MESSAGES)
        failed_tasks = [todo.subtasks[tid] for tid in todo.failed_tasks 
                       if tid in todo.subtasks]
        if failed_tasks:
            md += "## ❌ Failed Tasks (Need Investigation)\n\n"
            for task in failed_tasks:
                md += f"### {task.description}\n\n"
                md += f"- **Actor:** `{task.actor}`\n"
                md += f"- **Attempts:** {task.attempts}/{task.max_attempts}\n"
                md += f"- **Last Error:** {task.error if task.error else 'Unknown'}\n"
                
                if task.failure_reasons:
                    md += f"- **Failure History:**\n"
                    # Show all failures (NO HARDCODED LIMIT)
                    for i, reason in enumerate(task.failure_reasons, 1):
                        md += f"  {i}. {reason}\n"
                
                md += "\n"
        
        # State Insights (ALGORITHMIC - NO HARDCODING)
        md += "## 🧠 State Insights\n\n"
        
        if total > 0:
            avg_q = sum(t.estimated_reward for t in todo.subtasks.values()) / total
            md += f"- **Average Q-Value:** {avg_q:.3f}\n"
        
        if completed > 0:
            completed_with_time = [t for t in completed_tasks if t.started_at and t.completed_at]
            if completed_with_time:
                avg_duration = sum((t.completed_at - t.started_at).total_seconds() 
                                  for t in completed_with_time) / len(completed_with_time)
                md += f"- **Average Task Duration:** {avg_duration:.1f}s\n"
        
        if failed > 0:
            failure_rate = failed / total
            md += f"- **Failure Rate:** {failure_rate:.1%}\n"
        
        md += "\n---\n\n"
        md += "*This display is auto-generated by SYNAPSE Vault with NO HARDCODED FORMATTING.*\n"
        
        return md
    
    # =========================================================================
    # Q-TABLE PERSISTENCE (NO HARDCODING)
    # =========================================================================
    
    def save_q_predictor(self, q_predictor: 'LLMQPredictor'):
        """
        Save Q-predictor Q-table, experience buffer, and all meta-learning state.
        
        🔴 A-TEAM FIX: Delegates to q_predictor.save_state() which saves ALL state
        (Q-table, experience buffer, NeuroChunk tiers, agentic tag index, meta-learning)
        in ONE atomic file. This ensures save/load symmetry — load_q_predictor calls
        q_predictor.load_state() which expects this exact format.
        
        Previously save used a DIFFERENT format than load expected, causing:
        - Experience buffer saved to separate file but never loaded
        - Meta-learning state (prediction_history, confidence) never saved
        - Agentic tag index saved but format didn't match q_predictor.load_state()
        """
        q_tables_dir = self.global_synapse_dir / "q_tables"
        q_tables_dir.mkdir(parents=True, exist_ok=True)
        
        q_table_file = q_tables_dir / "q_predictor_state.json"
        
        try:
            # Use q_predictor's own save_state which ensures format symmetry with load_state
            q_predictor.save_state(str(q_table_file))
            
            q_size = len(q_predictor.Q) if hasattr(q_predictor, 'Q') else 0
            buf_size = len(q_predictor.experience_buffer) if hasattr(q_predictor, 'experience_buffer') else 0
            logger.info(f"✅ Saved Q-predictor (unified): {q_size} Q-entries, {buf_size} experiences")
        except Exception as e:
            logger.warning(f"⚠️ Failed to save Q-predictor: {e}")
    
    def load_q_predictor(self, q_predictor: 'LLMQPredictor') -> bool:
        """
        Load Q-predictor Q-table and experience buffer from disk.
        
        Returns: True if loaded successfully, False otherwise
        """
        q_table_file = self.global_synapse_dir / "q_tables" / "q_predictor_state.json"
        
        if not q_table_file.exists():
            logger.info(f"ℹ️ No previous Q-table state at {q_table_file}")
            return False
        
        try:
            # Use the q_predictor's own load_state method which handles all the deserialization
            result = q_predictor.load_state(str(q_table_file))
            
            # 🏷️ A-TEAM: Load Agentic Tag Index - GLOBAL
            try:
                if hasattr(q_predictor, 'agentic_index'):
                    index_file = self.global_synapse_dir / "q_tables" / "agentic_tag_index.json"
                    if index_file.exists():
                        q_predictor.agentic_index.load_state(str(index_file))
                        logger.info(f"✅ Loaded Agentic Tag Index: {len(q_predictor.agentic_index.tag_stats)} tags, "
                                   f"{len(q_predictor.agentic_index.clusters)} clusters")
            except Exception as e:
                logger.info(f"ℹ️ No agentic index to load (starting fresh): {e}")
            
            return result
        except Exception as e:
            logger.warning(f"⚠️ Failed to load Q-predictor state: {e}")
            return False
    
    def save_environment_manager(self, env_manager: 'EnvironmentManager'):
        """
        Save environment manager state.
        
        The environment manager handles its own persistence internally,
        but this method ensures the state is properly saved to the vault.
        """
        env_dir = self.run_synapse_dir / "env"
        env_dir.mkdir(parents=True, exist_ok=True)
        
        # Environment manager saves its own state to env.md and env_history.json
        # We just need to ensure it's in the right location
        stats = env_manager.get_statistics()
        logger.info(f"✅ Environment Manager state at: {stats['env_file']}")
    
    def load_environment_manager(self, config, goal_context: str = "General task execution") -> 'EnvironmentManager':
        """
        Load or create environment manager.
        
        Args:
            config: Synapse configuration
            goal_context: Current goal/task description
        
        Returns:
            EnvironmentManager instance with loaded state
        """
        from .environment_manager import EnvironmentManager
        
        # Update config to point to the right directory - RUN-SPECIFIC
        if not hasattr(config, 'env_dir'):
            config.env_dir = self.run_synapse_dir / "env"
        
        # Create environment manager (it will load existing state if available)
        env_manager = EnvironmentManager(config, goal_context)
        
        logger.info(f"✅ Environment Manager initialized/loaded: {env_manager.env_file}")
        return env_manager
    
    # =========================================================================
    # MEMORY PERSISTENCE (NO HARDCODING)
    # =========================================================================
    
    def save_memory(self, memory: 'HierarchicalMemory', name: str = "shared", 
                   max_per_level: int = 100):
        """
        Save hierarchical memory.
        
        NO HARDCODING:
        - Saves all memory levels dynamically
        - max_per_level is configurable
        - Memory structure extensible
        """
        # Memories are GLOBAL (shared across runs)
        if name == "shared":
            memory_file = self.global_synapse_dir / "memories" / "shared_memory.json"
        else:
            # 🔴 A-TEAM FIX: Use `agent_memories/` to match SessionManager directory structure
            memory_file = self.global_synapse_dir / "memories" / "agent_memories" / f"{name}.json"
        
        # Serialize memory levels (NO HARDCODED LEVELS - iterates whatever exists)
        memory_data = {}
        total_memories = 0
        
        # 🔴 A-TEAM FIX: Use HierarchicalMemory.to_dict() if available (canonical serialization)
        # Previous code checked `memory.storage` but HierarchicalMemory uses `memory.memories`
        if hasattr(memory, 'to_dict') and callable(memory.to_dict):
            # Use the canonical serialization from HierarchicalMemory
            full_data = memory.to_dict()
            # Extract just the memories section, respecting max_per_level
            for level_str, level_memories in full_data.get('memories', {}).items():
                level_data = []
                for key, mem_dict in list(level_memories.items())[:max_per_level]:
                    level_data.append(mem_dict)
                memory_data[level_str] = level_data
                total_memories += len(level_data)
        elif hasattr(memory, 'memories') and isinstance(memory.memories, dict):
            # Fallback: iterate memory.memories directly (Dict[MemoryLevel, Dict[str, MemoryEntry]])
            for level, level_dict in memory.memories.items():
                level_key = level.value if hasattr(level, 'value') else str(level)
                level_data = []
                for key, mem_entry in list(level_dict.items())[:max_per_level]:
                    # MemoryEntry is a dataclass, use getattr not .get()
                    level_data.append({
                        'key': getattr(mem_entry, 'key', ''),
                        'content': getattr(mem_entry, 'content', ''),
                        'context': getattr(mem_entry, 'context', {}),
                        'level': level_key,
                        'default_value': getattr(mem_entry, 'default_value', 0.0),
                        'token_count': getattr(mem_entry, 'token_count', 0),
                        'access_count': getattr(mem_entry, 'access_count', 0),
                        'causal_links': getattr(mem_entry, 'causal_links', []),
                    })
                memory_data[level_key] = level_data
                total_memories += len(level_data)
        
        memory_data['metadata'] = {
            'name': name,
            'total_memories': total_memories,
            'timestamp': time.time()
        }
        
        # 🔴 A-TEAM FIX: Ensure parent directory exists (handles first-run scenario)
        memory_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(memory_file, 'w') as f:
            json.dump(memory_data, f, indent=2, default=str)
        
        logger.info(f"✅ Saved memory '{name}': {total_memories} memories across "
                   f"{len(memory_data)-1} levels")
    
    def load_memory(self, name: str = "shared", config=None):
        """
        Load hierarchical memory from persistence.
        
        🔴 A-TEAM FIX: Previously save_memory existed but load_memory did not,
        meaning all memories (shared + per-actor) were LOST across sessions.
        
        Args:
            name: Memory name ("shared" or actor name)
            config: SynapseConfig for HierarchicalMemory reconstruction
            
        Returns:
            HierarchicalMemory instance or None if not found
        """
        if name == "shared":
            memory_file = self.global_synapse_dir / "memories" / "shared_memory.json"
        else:
            memory_file = self.global_synapse_dir / "memories" / "agent_memories" / f"{name}.json"
        
        if not memory_file.exists():
            logger.info(f"ℹ️ No previous memory state for '{name}' at {memory_file}")
            return None
        
        try:
            with open(memory_file, 'r') as f:
                memory_data = json.load(f)
            
            # Use HierarchicalMemory.from_dict for canonical deserialization
            from .cortex import HierarchicalMemory
            
            # Reconstruct the format from_dict expects
            # from_dict expects {'agent_name': ..., 'memories': {level: {key: entry}}, ...}
            agent_name = memory_data.get('metadata', {}).get('name', name)
            
            # Build from_dict compatible structure
            memories_dict = {}
            for level_str, entries in memory_data.items():
                if level_str == 'metadata':
                    continue
                if isinstance(entries, list):
                    level_entries = {}
                    for entry in entries:
                        if isinstance(entry, dict):
                            key = entry.get('key', f"mem_{len(level_entries)}")
                            level_entries[key] = entry
                    memories_dict[level_str] = level_entries
            
            from_dict_data = {
                'agent_name': agent_name,
                'memories': memories_dict,
                'total_accesses': 0,
                'consolidation_count': 0,
            }
            
            memory = HierarchicalMemory.from_dict(from_dict_data, config)
            total = sum(len(v) for k, v in memories_dict.items())
            logger.info(f"✅ Loaded memory '{name}': {total} memories across {len(memories_dict)} levels")
            return memory
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to load memory '{name}': {e}")
            return None
    
    # =========================================================================
    # EPISODE PERSISTENCE (NO HARDCODING)
    # =========================================================================
    
    def save_episode(self, episode_num: int, trajectory: List, metadata: Dict):
        """
        Save episode history.
        
        NO HARDCODING: Saves complete trajectory with any metadata.
        """
        # Episodes are RUN-SPECIFIC
        episode_file = self.run_synapse_dir / "episode_history" / f"episode_{episode_num}.json"
        episode_data = {
            'episode': episode_num,
            'metadata': metadata,  # Accept any metadata (NO HARDCODED KEYS)
            'trajectory': trajectory,
            'trajectory_length': len(trajectory),
            'timestamp': time.time()
        }
        with open(episode_file, 'w') as f:
            json.dump(episode_data, f, indent=2, default=str)
        
        logger.info(f"✅ Saved episode {episode_num}: {len(trajectory)} steps")
    
    # =========================================================================
    # BRAIN STATE PERSISTENCE (NO HARDCODING)
    # =========================================================================
    
    def save_brain_state(self, brain: 'SimpleBrain'):
        """
        Save brain consolidated memories.
        
        NO HARDCODING: Saves whatever brain state exists.
        """
        if not brain:
            return
        
        # Brain state is GLOBAL (shared across runs)
        brain_file = self.global_synapse_dir / "brain_state" / "consolidated_memories.json"
        
        # Serialize brain state (DEFENSIVE - works with any brain type)
        brain_data = {
            'timestamp': time.time(),
            'brain_type': type(brain).__name__,
        }
        
        # Add known attributes defensively
        if hasattr(brain, 'preset'):
            brain_data['preset'] = str(brain.preset.value if hasattr(brain.preset, 'value') else brain.preset)
        if hasattr(brain, 'chunk_size'):
            brain_data['chunk_size'] = brain.chunk_size
        if hasattr(brain, 'consolidation_count'):
            brain_data['consolidation_count'] = brain.consolidation_count
        if hasattr(brain, 'sleep_interval'):
            brain_data['sleep_interval'] = brain.sleep_interval
        
        # Add any other brain attributes dynamically (NO HARDCODED LIST)
        for attr in dir(brain):
            if not attr.startswith('_') and attr not in brain_data:
                try:
                    val = getattr(brain, attr)
                    if not callable(val):
                        brain_data[attr] = str(val)
                except (AttributeError, TypeError) as e:
                    logger.debug(f"Skipping brain attribute {attr}: {e}")
        
        with open(brain_file, 'w') as f:
            json.dump(brain_data, f, indent=2, default=str)
        
        logger.info("✅ Saved brain state")
    
    # =========================================================================
    # COMPLETE STATE SAVE (NO HARDCODING)
    # =========================================================================
    
    def save_all(self, conductor):
        """
        Save complete SYNAPSE Conductor state.
        
        NO HARDCODING: Saves all components that exist on the object.
        """
        logger.info(f"\n{'='*60}")
        logger.info("💾 SAVING COMPLETE SYNAPSE STATE")
        logger.info(f"{'='*60}")
        
        # Save TODO
        if hasattr(conductor, 'todo'):
            self.save_markovian_todo(conductor.todo)
        
        # Save Q-predictor
        if hasattr(conductor, 'q_predictor'):
            self.save_q_predictor(conductor.q_predictor)
        
        # Save shared memory
        if hasattr(conductor, 'shared_memory'):
            self.save_memory(conductor.shared_memory, "shared")
        
        # Save local memories (NO HARDCODED ACTOR LIST)
        if hasattr(conductor, 'local_memories'):
            for name, memory in conductor.local_memories.items():
                self.save_memory(memory, name)
        
        # Save episode
        if hasattr(conductor, 'episode_count') and hasattr(conductor, 'trajectory'):
            metadata = {
                'total_episodes': getattr(conductor, 'total_episodes', 1),
                'iteration': getattr(conductor, 'iteration', 0),
                # Add any other swarm metadata dynamically
            }
            self.save_episode(conductor.episode_count, conductor.trajectory, metadata)
        
        # Save brain
        if hasattr(conductor, 'brain') and conductor.brain:
            self.save_brain_state(conductor.brain)
        
        # 🔴 A-TEAM FIX: Save MARL trajectory predictor and divergence memory
        # These contain learned agent models, divergence patterns, and consolidated insights
        # that are the "DQN weights" — critical for cross-session learning
        if hasattr(conductor, 'trajectory_predictor') and conductor.trajectory_predictor:
            divergence_mem = getattr(conductor, 'divergence_memory', None)
            self.save_marl_state(conductor.trajectory_predictor, divergence_mem)
        
        # 🔴 A-TEAM FIX: Save TD(λ) state
        if hasattr(conductor, 'td_learner') and conductor.td_learner:
            self.save_td_lambda_state(conductor.td_learner)
        
        # 🔴 A-TEAM FIX: Save test aggregator (Bayesian learning data)
        if hasattr(conductor, 'test_aggregator') and conductor.test_aggregator:
            self.save_test_aggregator(conductor.test_aggregator)
        
        # 🔴 A-TEAM FIX: Save user feedback
        if hasattr(conductor, 'reward_calculator') and conductor.reward_calculator:
            self.save_user_feedback(conductor.reward_calculator)
        
        logger.info(f"{'='*60}")
        logger.info(f"✅ ALL SYNAPSE STATE SAVED")
        logger.info(f"📁 Global Location: {self.global_synapse_dir}")
        logger.info(f"📁 Run Location: {self.run_synapse_dir}")
        logger.info(f"{'='*60}\n")
    
    # =========================================================================
    # AUTO-SAVE HELPER (NO HARDCODED INTERVAL)
    # =========================================================================
    
    def should_auto_save(self, iteration: int) -> bool:
        """Check if should auto-save (based on configurable interval)."""
        return iteration % self.auto_save_interval == 0
    
    # =========================================================================
    # 🎯 A-TEAM FIX: BAYESIAN TEST AGGREGATOR PERSISTENCE
    # =========================================================================
    
    def save_test_aggregator(self, aggregator: 'HybridTestAggregator', name: str = "test_aggregator"):
        """
        Save test aggregator state for persistence across sessions.
        
        CRITICAL FIX: Without this, Bayesian learning data is lost on restart!
        """
        from collections import defaultdict
        
        # Test aggregator is RUN-SPECIFIC
        state_file = self.run_synapse_dir / "test_aggregator" / f"{name}.json"
        state_file.parent.mkdir(parents=True, exist_ok=True)
        
        state = {
            'episode_count': aggregator.bayesian_aggregator.episode_count,
            'test_pass_counts': dict(aggregator.bayesian_aggregator.test_pass_counts),
            'test_total_counts': dict(aggregator.bayesian_aggregator.test_total_counts),
            'test_quality_correlation': {
                k: list(v) for k, v in aggregator.bayesian_aggregator.test_quality_correlation.items()
            },
            'timestamp': datetime.now().isoformat()
        }
        
        with open(state_file, 'w') as f:
            json.dump(state, f, indent=2)
        
        logger.info(f"💾 Saved test aggregator state: {state_file} ({state['episode_count']} episodes)")
    
    def load_test_aggregator(self, aggregator: 'HybridTestAggregator', name: str = "test_aggregator"):
        """
        Load test aggregator state from previous session.
        
        CRITICAL FIX: Enables Bayesian learning across sessions!
        """
        from collections import defaultdict
        
        # Test aggregator is RUN-SPECIFIC
        state_file = self.run_synapse_dir / "test_aggregator" / f"{name}.json"
        
        if not state_file.exists():
            logger.info("ℹ️  No saved test aggregator state found (fresh start)")
            return
        
        try:
            with open(state_file, 'r') as f:
                state = json.load(f)
            
            aggregator.bayesian_aggregator.episode_count = state['episode_count']
            aggregator.bayesian_aggregator.test_pass_counts = defaultdict(int, state['test_pass_counts'])
            aggregator.bayesian_aggregator.test_total_counts = defaultdict(int, state['test_total_counts'])
            aggregator.bayesian_aggregator.test_quality_correlation = defaultdict(
                list,
                {k: list(v) for k, v in state['test_quality_correlation'].items()}
            )
            
            logger.info(
                f"✅ Loaded test aggregator state: {aggregator.bayesian_aggregator.episode_count} episodes, "
                f"{len(aggregator.bayesian_aggregator.test_quality_correlation)} tests learned"
            )
        
        except Exception as e:
            logger.error(f"❌ Failed to load test aggregator state: {e}")
    
    # =========================================================================
    # 🎯 A-TEAM FIX: USER FEEDBACK PERSISTENCE
    # =========================================================================
    
    def save_user_feedback(self, reward_calculator: 'UnifiedRewardCalculator', name: str = "user_feedback"):
        """
        Save user feedback for persistence across sessions.
        
        HIGH PRIORITY FIX: Enables human-in-the-loop learning!
        """
        # User feedback is RUN-SPECIFIC
        state_file = self.run_synapse_dir / "user_feedback" / f"{name}.json"
        state_file.parent.mkdir(parents=True, exist_ok=True)
        
        feedback_data = [
            {
                'task_id': f.task_id,
                'reward': f.reward,
                'reason': f.reason,
                'timestamp': f.timestamp.isoformat()
            }
            for f in reward_calculator.user_feedback
        ]
        
        with open(state_file, 'w') as f:
            json.dump(feedback_data, f, indent=2)
        
        logger.info(f"💾 Saved {len(feedback_data)} user feedback entries: {state_file}")
    
    def load_user_feedback(self, reward_calculator: 'UnifiedRewardCalculator', name: str = "user_feedback"):
        """
        Load user feedback from previous session.
        
        HIGH PRIORITY FIX: Enables continuous learning from human feedback!
        """
        # User feedback is RUN-SPECIFIC
        state_file = self.run_synapse_dir / "user_feedback" / f"{name}.json"
        
        if not state_file.exists():
            logger.info("ℹ️  No saved user feedback found (fresh start)")
            return
        
        try:
            with open(state_file, 'r') as f:
                feedback_data = json.load(f)
            
            from Synapse.core.unified_reward import UserReward
            
            for item in feedback_data:
                reward_calculator.user_feedback.append(UserReward(
                    task_id=item['task_id'],
                    reward=item['reward'],
                    reason=item['reason'],
                    timestamp=datetime.fromisoformat(item['timestamp'])
                ))
            
            logger.info(f"✅ Loaded {len(feedback_data)} user feedback entries")
        
        except Exception as e:
            logger.error(f"❌ Failed to load user feedback: {e}")
    
    # =========================================================================
    # 🎯 A-TEAM FIX: MARL TRAJECTORY PREDICTOR PERSISTENCE
    # =========================================================================
    
    def save_marl_state(self, trajectory_predictor, divergence_memory=None):
        """
        Save MARL trajectory predictor and divergence memory state.
        
        🔴 A-TEAM CRITICAL FIX: Without this, all learned agent models,
        divergence patterns, and consolidated insights are LOST on restart!
        
        The trajectory predictor is the "DQN" — its learned_patterns and
        agent_models are the equivalent of neural network weights.
        Losing them means relearning from scratch every session.
        
        Args:
            trajectory_predictor: LLMTrajectoryPredictor instance
            divergence_memory: DivergenceMemory instance (optional)
        """
        if not trajectory_predictor:
            return
        
        # MARL state is GLOBAL (learned patterns transfer across runs)
        marl_dir = self.global_synapse_dir / "marl"
        marl_dir.mkdir(parents=True, exist_ok=True)
        
        # Save trajectory predictor state
        try:
            predictor_data = trajectory_predictor.to_dict()
            predictor_file = marl_dir / "trajectory_predictor.json"
            with open(predictor_file, 'w') as f:
                json.dump(predictor_data, f, indent=2, default=str)
            
            logger.info(f"✅ Saved MARL trajectory predictor: "
                       f"{len(predictor_data.get('learned_patterns', []))} patterns, "
                       f"{len(predictor_data.get('agent_models', {}))} agent models, "
                       f"{len(predictor_data.get('consolidated_insights', []))} insights")
        except Exception as e:
            logger.warning(f"⚠️ Failed to save trajectory predictor: {e}")
        
        # Save divergence memory
        if divergence_memory and hasattr(divergence_memory, 'memories'):
            try:
                div_data = {
                    'memories': [
                        {
                            'action_divergence': d.action_divergence,
                            'state_divergence': d.state_divergence,
                            'reward_divergence': d.reward_divergence,
                            'information_content': d.information_content,
                            'learning': d.learning,
                            'predicted_reward': d.predicted.predicted_reward if d.predicted else 0.0,
                            'actual_reward': d.actual.actual_reward if d.actual else 0.0,
                        }
                        for d in divergence_memory.memories[-100:]  # Keep last 100
                    ],
                    'total_stored': len(divergence_memory.memories),
                    'timestamp': time.time()
                }
                div_file = marl_dir / "divergence_memory.json"
                with open(div_file, 'w') as f:
                    json.dump(div_data, f, indent=2, default=str)
                
                logger.info(f"✅ Saved divergence memory: {len(div_data['memories'])} entries")
            except Exception as e:
                logger.warning(f"⚠️ Failed to save divergence memory: {e}")
    
    def load_marl_state(self, config) -> dict:
        """
        Load MARL state from persistence.
        
        Returns:
            Dict with 'trajectory_predictor_data' and 'divergence_data' keys,
            or empty dict if nothing found.
        """
        result = {}
        marl_dir = self.global_synapse_dir / "marl"
        
        # Load trajectory predictor
        predictor_file = marl_dir / "trajectory_predictor.json"
        if predictor_file.exists():
            try:
                with open(predictor_file, 'r') as f:
                    result['trajectory_predictor_data'] = json.load(f)
                logger.info(f"✅ Loaded MARL trajectory predictor state")
            except Exception as e:
                logger.warning(f"⚠️ Failed to load trajectory predictor: {e}")
        
        # Load divergence memory
        div_file = marl_dir / "divergence_memory.json"
        if div_file.exists():
            try:
                with open(div_file, 'r') as f:
                    result['divergence_data'] = json.load(f)
                logger.info(f"✅ Loaded divergence memory state")
            except Exception as e:
                logger.warning(f"⚠️ Failed to load divergence memory: {e}")
        
        return result
    
    def save_td_lambda_state(self, td_learner: Any) -> bool:
        """
        Save TD(λ) learner state for cross-session learning.
        
        🔥 A-TEAM FIX: Persist eligibility traces and value estimates
        so temporal credit assignment learning continues across sessions.
        
        Args:
            td_learner: TDLambdaLearner instance
        
        Returns:
            bool: Success status
        """
        if not td_learner:
            return False
        
        try:
            # TD(λ) state is RUN-SPECIFIC
            td_lambda_dir = self.run_synapse_dir / "td_lambda"
            td_lambda_dir.mkdir(parents=True, exist_ok=True)
            td_lambda_path = td_lambda_dir / "td_lambda_state.json"
            
            # Extract state from TD(λ) learner
            state = {
                'traces': td_learner.traces if hasattr(td_learner, 'traces') else {},
                'values_at_access': td_learner.values_at_access if hasattr(td_learner, 'values_at_access') else {},
                'current_goal': td_learner.current_goal if hasattr(td_learner, 'current_goal') else "",
                'access_sequence': td_learner.access_sequence if hasattr(td_learner, 'access_sequence') else [],
                'timestamp': datetime.now().isoformat()
            }
            
            with open(td_lambda_path, 'w') as f:
                json.dump(state, f, indent=2, default=str)
            
            logger.debug(f"✅ TD(λ) state saved: {len(state.get('traces', {}))} traces")
            return True
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to save TD(λ) state: {e}")
            return False
    
    def load_td_lambda_state(self, td_learner: Any) -> bool:
        """
        Load TD(λ) learner state from previous session.
        
        Args:
            td_learner: TDLambdaLearner instance to restore state into
        
        Returns:
            bool: Success status
        """
        if not td_learner:
            return False
        
        try:
            # TD(λ) state is RUN-SPECIFIC
            td_lambda_path = self.run_synapse_dir / "td_lambda" / "td_lambda_state.json"
            
            if not td_lambda_path.exists():
                logger.debug("No previous TD(λ) state found")
                return False
            
            with open(td_lambda_path, 'r') as f:
                state = json.load(f)
            
            # Restore state to TD(λ) learner
            if hasattr(td_learner, 'traces'):
                td_learner.traces = state.get('traces', {})
            if hasattr(td_learner, 'values_at_access'):
                td_learner.values_at_access = state.get('values_at_access', {})
            if hasattr(td_learner, 'current_goal'):
                td_learner.current_goal = state.get('current_goal', "")
            if hasattr(td_learner, 'access_sequence'):
                td_learner.access_sequence = state.get('access_sequence', [])
            
            logger.info(f"✅ TD(λ) state restored: {len(state.get('traces', {}))} traces")
            return True
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to load TD(λ) state: {e}")
            return False

