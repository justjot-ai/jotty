"""
Q-Learning components for ReVal.

Provides LLM-based Q-value prediction and experience management with
NATURAL LANGUAGE Q-table for semantic generalization.
"""
import dspy
import json
import time
import random
import logging
from contextlib import nullcontext
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass, field
from .token_utils import smart_truncate  # 🔴 A-TEAM FIX: Token-aware truncation

logger = logging.getLogger(__name__)


class LLMQPredictorSignature(dspy.Signature):
    """Predict Q-value (expected reward) for a state-action pair using LLM reasoning."""
    
    state_description = dspy.InputField(desc="Current state of the swarm (TODO state, actor states, memory summary)")
    proposed_action = dspy.InputField(desc="The action being considered (which task, which actor)")
    historical_outcomes = dspy.InputField(desc="JSON of similar past state-action-reward tuples")
    goal_context = dspy.InputField(desc="The root goal we're trying to achieve")
    
    reasoning = dspy.OutputField(desc="Step-by-step reasoning about expected outcome")
    q_value = dspy.OutputField(desc="Predicted Q-value between 0.0 and 1.0")
    confidence = dspy.OutputField(desc="Confidence in this prediction (0.0-1.0)")
    alternative_suggestion = dspy.OutputField(desc="If confidence is low, suggest better action")


class StateToNaturalLanguageSignature(dspy.Signature):
    """
    Convert a state dictionary to a COMPREHENSIVE natural language description for LLM-based Q-learning.
    
    🔥 A-TEAM CRITICAL: This is for an LLM with linguistic understanding - BE ELABORATE!
    
    The description must capture the FULL CONTEXT needed for learning:
    
    1. PROBLEM CONTEXT (What are we trying to solve?)
       - Root goal/objective
       - Why this matters
       - Constraints or requirements
    
    2. HISTORY CONTEXT (What has been done so far?)
       - Previous tasks completed
       - What worked and what didn't
       - How we got to this state
    
    3. CURRENT STATE (Where are we now?)
       - Current task being executed
       - Actor/agent assigned
       - Dependencies satisfied
       - Resources available
    
    4. ERROR/PITFALL CONTEXT (What to avoid?)
       - Previous errors encountered
       - Recovery strategies tried
       - What caused failures
    
    5. ACTION CONTEXT (What was done?)
       - Tools/commands used with parameters
       - Reasoning for choices
       - Alternative approaches considered
    """
    
    state_dict = dspy.InputField(
        desc="State dictionary containing full execution context (JSON string)"
    )
    
    natural_language_description = dspy.OutputField(
        desc="""COMPREHENSIVE state description for LLM Q-learning (aim for 500-2000 characters).

=== REQUIRED SECTIONS (use narrative style, not telegrams) ===

## PROBLEM NARRATIVE
Describe the overall goal and current objective in natural language.
Example: "We are trying to send an email summary to the team. This requires first gathering information, then formatting it, then sending via the email client."

## JOURNEY SO FAR
Describe what has been accomplished and how we got here.
Example: "We have completed 2 of 3 tasks. First, the WebSearchAgent gathered relevant articles (took 2 attempts after initial timeout). Then TerminalExecutor generated the report successfully on first try."

## CURRENT SITUATION
Describe the current task, actor, and state.
Example: "Currently executing task 3/3: 'Send email with report'. Actor: BrowserExecutor. Dependencies: report.pdf is ready. The email client needs to be opened and the attachment added."

## PITFALLS ENCOUNTERED (if any)
Describe any errors, failures, or challenges.
Example: "The first attempt at gathering info failed with timeout. Root cause: network latency. Resolution: increased timeout to 30s. Future similar tasks should use longer timeouts from the start."

## TOOLS AND PARAMETERS USED
List tools/commands with their parameters and outcomes.
Example: "Used web_search(query='topic', max_results=5) -> Success. Used run_command('python generate.py', timeout=60) -> Success, output: report.pdf"

## LEARNING CONTEXT
What should be remembered for similar future states?
Example: "For research tasks, WebSearchAgent works well but needs longer timeouts for complex queries. The TerminalExecutor's report generation is reliable."

=== FORMAT ===
Use markdown-style sections (##) and natural language.
Be VERBOSE - LLMs understand narratives better than compressed codes.
Include reasoning, not just facts.
Capture the "story" of the execution.

=== EXAMPLE OUTPUT ===

## PROBLEM NARRATIVE
Goal: Analyze competitor pricing and generate summary report. This is part of a market research workflow requiring web data collection, analysis, and report generation.

## JOURNEY SO FAR
Completed tasks: (1) Web search for competitor sites - 3 found after 2 search attempts (first attempt had too narrow query). (2) Data extraction from 2 of 3 sites - one site had anti-scraping protection that required different approach.

## CURRENT SITUATION
Task 3/5: Extract pricing from site C using API instead of scraping (learned from previous failure). Actor: BrowserExecutor. Available: competitor_sites.json from previous steps.

## PITFALLS ENCOUNTERED
- Site B blocked scraping -> Used API endpoint instead
- First search was too narrow -> Broadened query terms
- Data parsing failed on malformed JSON -> Added error handling

## TOOLS AND PARAMETERS
- web_search(query="competitor pricing SaaS", max_results=10) -> 3 relevant
- navigate_to_url(site_a, wait_time=5) -> Success
- extract_data(selector=".price") -> Failed on site C
- call_api(endpoint="/pricing", method="GET") -> Trying now

## LEARNING CONTEXT
This domain (competitor analysis) requires: (1) flexible scraping strategies, (2) API fallbacks, (3) error-tolerant parsing. Similar future tasks should check for API availability first before scraping."""
    )


class LLMLessonExtractionSignature(dspy.Signature):
    """Extract a concise, ACTIONABLE lesson from a Q-learning experience.
    
    The lesson must be SPECIFIC (not generic) and help an LLM agent avoid
    repeating mistakes or replicate successes in similar future situations.
    
    BAD lessons:
    - "The task failed" (no actionable detail)
    - "Try a different approach" (too vague)
    - "The browser executor failed" (no root cause)
    
    GOOD lessons:
    - "Google Finance blocks JavaScript execution via CSP; use CDP click_element instead of execute_js for UI interaction"
    - "yfinance Python library is more reliable than browser scraping for fetching Indian stock data (PAYTM.NS)"
    - "WhatsApp Web requires exact contact name match in search; use CDP Runtime.evaluate as fallback for CSP-restricted sites"
    """
    
    state_description = dspy.InputField(desc="Natural language description of the state when this action was taken")
    action_description = dspy.InputField(desc="Natural language description of the action that was taken")
    reward = dspy.InputField(desc="Reward received (0.0=failure, 1.0=success)")
    td_error = dspy.InputField(desc="Temporal difference error (positive=better than expected, negative=worse)")
    
    lesson = dspy.OutputField(desc="One specific, actionable lesson (1-2 sentences). Include tool names, URLs, strategies, error types. Must help similar future tasks succeed.")


# =============================================================================
# AGENTIC INDEX CONFIGURATION (NO MAGIC NUMBERS!)
# =============================================================================

@dataclass
class AgenticIndexConfig:
    """
    All configurable parameters for AgenticTagIndex.
    
    🔥 A-TEAM CRITICAL: NO SLICING! USE FULL CONTEXT!
    Modern LLMs (GPT-4, Claude) have 128K+ context - use it all!
    
    NO MAGIC NUMBERS - everything documented and configurable!
    """
    # === TAG EXTRACTION ===
    max_existing_tags_sample: int = 200  # More existing tags for better consistency
    max_tags_per_entry: int = 25  # More tags for richer indexing
    min_word_length_fallback: int = 4  # Min word length for fallback extraction
    
    # === CONTEXT LIMITS (NO TRUNCATION!) ===
    # 🔥 A-TEAM: Modern LLMs have 128K+ context - USE IT ALL!
    state_desc_max_chars: int = 50000  # Full state (no truncation)
    action_desc_max_chars: int = 20000  # Full action (no truncation)
    outcome_max_chars: int = 10000  # Full outcome (no truncation)
    
    # === SEARCH PARAMETERS ===
    default_top_k: int = 10  # Default top-k for searches (configurable)
    max_clusters_for_assignment: int = 50  # More clusters for better assignment
    expansion_score_weight: float = 0.3  # Weight for expanded tag matches
    cluster_score_weight: float = 0.2  # Weight for cluster membership
    top_candidates_for_llm: int = 200  # More candidates for better scoring
    cluster_member_sample_size: int = 100  # More members per cluster
    
    # === RECALL GUARANTEE ===
    recent_entries_search_count: int = 50  # More recent entries
    high_value_entries_count: int = 30  # More high-Q entries
    recency_boost: float = 0.1  # Boost for recent entries
    high_value_boost: float = 0.15  # Boost for high-value entries
    
    # === CONTEXT RETRIEVAL LIMITS ===
    max_lessons_to_inject: int = 20  # Full lessons, no truncation
    max_pitfalls_to_inject: int = 15  # Full pitfalls
    max_strategies_to_inject: int = 10  # Full strategies
    max_warnings_to_inject: int = 10  # Full warnings
    max_suggestions: int = 10  # Full suggestions
    
    # === REORGANIZATION ===
    reorganize_interval: int = 500  # Reorganize clusters every N inserts
    min_clusters_for_reorg: int = 3  # Minimum clusters before reorganization
    
    # === ONLINE LEARNING ===
    min_uses_for_tag_boost: int = 5  # Min uses before applying tag utility boost
    
    # === Q-TABLE CONTEXT ===
    max_execution_history: int = 50  # Keep more history
    max_strategies_per_entry: int = 20  # More strategies
    max_pitfalls_per_entry: int = 15  # More pitfalls
    max_lessons_per_entry: int = 30  # More lessons
    
    # === TRAJECTORY CORRECTION ===
    trajectory_search_top_k: int = 10  # Search for corrections (configurable)
    max_avoid_actions: int = 15  # More actions to avoid
    max_specific_actions: int = 10  # More specific recommendations
    
    # === PERSISTENCE ===
    version: str = "2.0.0"  # Updated for no-truncation version


# =============================================================================
# ONLINE LEARNING TRACKER (Learn which tags are useful)
# =============================================================================

@dataclass
class TagUtility:
    """Tracks how useful a tag is for search and learning."""
    tag: str
    total_uses: int = 0  # How many times tag appeared in search
    success_uses: int = 0  # How many times search led to task success
    result_used_count: int = 0  # How many times results with this tag were used
    false_negative_count: int = 0  # Times this tag missed relevant results
    
    @property
    def utility_score(self) -> float:
        """Calculate tag utility (0-1). Higher = more useful."""
        if self.total_uses < 5:
            return 0.5  # Not enough data
        
        success_rate = self.success_uses / max(self.total_uses, 1)
        usage_rate = self.result_used_count / max(self.total_uses, 1)
        reliability = 1.0 - (self.false_negative_count / max(self.total_uses, 1))
        
        return 0.3 * success_rate + 0.3 * usage_rate + 0.4 * reliability
    
    def to_dict(self) -> Dict:
        return {
            'tag': self.tag,
            'total_uses': self.total_uses,
            'success_uses': self.success_uses,
            'result_used_count': self.result_used_count,
            'false_negative_count': self.false_negative_count
        }
    
    @classmethod
    def from_dict(cls, d: Dict) -> 'TagUtility':
        return cls(
            tag=d['tag'],
            total_uses=d.get('total_uses', 0),
            success_uses=d.get('success_uses', 0),
            result_used_count=d.get('result_used_count', 0),
            false_negative_count=d.get('false_negative_count', 0)
        )


@dataclass
class SearchResult:
    """
    Rich search result including gotcha context.
    
    🔥 A-TEAM: Search must return CONTEXT, not just keys!
    """
    key: Tuple[str, str]  # (state_desc, action_desc)
    relevance_score: float
    matching_tags: List[str]
    cluster_id: Optional[str] = None
    
    # GOTCHA CONTEXT - Critical for learning from failures!
    pitfalls: List[str] = field(default_factory=list)
    lessons: List[str] = field(default_factory=list)
    successful_strategies: List[str] = field(default_factory=list)
    failed_strategies: List[str] = field(default_factory=list)
    
    def get_gotcha_context(self) -> str:
        """Format gotcha context for prompt injection - FULL CONTEXT, NO TRUNCATION."""
        parts = []
        if self.pitfalls:
            # 🔥 A-TEAM: Use full pitfalls, no truncation
            parts.append("⚠️ PITFALLS:\n" + "\n".join(f"- {p}" for p in self.pitfalls))
        if self.lessons:
            # 🔥 A-TEAM: Use full lessons, no truncation
            parts.append("📚 LESSONS:\n" + "\n".join(f"- {l}" for l in self.lessons))
        if self.failed_strategies:
            # 🔥 A-TEAM: Use full strategies, no truncation
            parts.append("❌ AVOID:\n" + "\n".join(f"- {f}" for f in self.failed_strategies))
        return "\n\n".join(parts) if parts else ""


# =============================================================================
# AGENTIC TAG AND CLUSTER SIGNATURES (NO HARDCODING)
# =============================================================================

class DynamicTagExtractorSignature(dspy.Signature):
    """
    Extract semantic tags from Q-entry content.
    
    🔥 CRITICAL: Do NOT use predefined categories!
    Extract whatever concepts are SEMANTICALLY IMPORTANT.
    Tags should emerge from content, not from a fixed list.
    """
    
    state_description = dspy.InputField(
        desc="Full natural language state description"
    )
    action_description = dspy.InputField(
        desc="Full natural language action description"
    )
    outcome = dspy.InputField(
        desc="Success/failure and what happened"
    )
    existing_tags = dspy.InputField(
        desc="Tags that already exist in the system (for consistency, but you can create new ones)"
    )
    
    extracted_tags = dspy.OutputField(
        desc="""List of 5-15 semantic tags as JSON array.
        
        Guidelines:
        - Use existing tags if they fit (consistency)
        - Create NEW tags for novel concepts
        - Tags should capture: task type, outcome patterns, tools used, error types, domain hints
        - Be specific enough to be useful, general enough to apply to similar cases
        
        Example output (these are examples, NOT a fixed list!):
        ["web_navigation", "timeout_error", "retry_successful", "email_client", "form_submission"]
        """
    )


class ClusterAssignmentSignature(dspy.Signature):
    """
    Assign a Q-entry to a cluster, or create a new cluster.
    
    NO predefined clusters - they emerge from data!
    """
    
    entry_description = dspy.InputField(
        desc="Full description of the new Q-entry (state + action + outcome)"
    )
    entry_tags = dspy.InputField(
        desc="Tags extracted for this entry (JSON array)"
    )
    existing_clusters = dspy.InputField(
        desc="""List of existing clusters as JSON:
        [{"id": "c1", "description": "...", "common_tags": [...], "size": N}, ...]
        """
    )
    
    assignment = dspy.OutputField(
        desc="""Decision in format:
        - "ASSIGN:cluster_id" - assign to existing cluster
        - "CREATE:description" - create new cluster with this description
        
        Create new if no cluster captures this entry well.
        """
    )


class ClusterReorganizationSignature(dspy.Signature):
    """
    Periodically reorganize clusters for better structure.
    """
    
    cluster_stats = dspy.InputField(
        desc="Stats for all clusters: id, description, size, common_tags, sample_entries"
    )
    total_entries = dspy.InputField(
        desc="Total number of entries in Q-table"
    )
    
    actions = dspy.OutputField(
        desc="""JSON list of reorganization actions:
        [
            {"action": "SPLIT", "cluster_id": "c1", "into": ["desc1", "desc2"]},
            {"action": "MERGE", "cluster_ids": ["c1", "c2"], "new_description": "..."},
            {"action": "RENAME", "cluster_id": "c1", "new_description": "..."},
            {"action": "KEEP", "cluster_id": "c1"}
        ]
        """
    )


class RelevanceScoringSignature(dspy.Signature):
    """
    Score relevance of candidate Q-entries to a query.
    """
    
    query_state = dspy.InputField(desc="The state we're searching for")
    query_action = dspy.InputField(desc="The action we're considering")
    candidate_entries = dspy.InputField(
        desc="JSON list of candidate entries with their state/action descriptions"
    )
    
    scored_entries = dspy.OutputField(
        desc="""JSON list of entries with relevance scores:
        [{"id": "...", "score": 0.85, "reason": "..."}, ...]
        Score 0.0-1.0 based on semantic similarity to query.
        """
    )


# =============================================================================
# DATA STRUCTURES FOR AGENTIC INDEX
# =============================================================================

@dataclass
class TagStats:
    """Statistics for a dynamically-emerged tag."""
    tag: str
    created_at: float
    usage_count: int = 0
    last_used: float = 0.0
    co_occurring_tags: Dict[str, int] = field(default_factory=dict)
    
    @property
    def importance(self) -> float:
        """Higher = more important tag."""
        import math
        recency = 1.0 / (1.0 + (time.time() - self.last_used) / 86400)
        frequency = math.log(1 + self.usage_count)
        return recency * frequency
    
    def to_dict(self) -> Dict:
        return {
            'tag': self.tag,
            'created_at': self.created_at,
            'usage_count': self.usage_count,
            'last_used': self.last_used,
            'co_occurring_tags': self.co_occurring_tags
        }
    
    @classmethod
    def from_dict(cls, d: Dict) -> 'TagStats':
        return cls(
            tag=d['tag'],
            created_at=d['created_at'],
            usage_count=d.get('usage_count', 0),
            last_used=d.get('last_used', 0.0),
            co_occurring_tags=d.get('co_occurring_tags', {})
        )


@dataclass
class AgenticCluster:
    """Self-organizing cluster with LLM-generated identity."""
    id: str
    description: str  # LLM-generated, evolves
    members: List[Tuple[str, str]]  # (state_desc, action_desc) keys
    common_tags: set = field(default_factory=set)
    created_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)
    
    @property
    def size(self) -> int:
        return len(self.members)
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'description': self.description,
            'members': [f"{m[0]}|||{m[1]}" for m in self.members],
            'common_tags': list(self.common_tags),
            'created_at': self.created_at,
            'last_updated': self.last_updated
        }
    
    @classmethod
    def from_dict(cls, d: Dict) -> 'AgenticCluster':
        members = []
        for m in d.get('members', []):
            if '|||' in m:
                parts = m.split('|||', 1)
                members.append((parts[0], parts[1]))
        return cls(
            id=d['id'],
            description=d['description'],
            members=members,
            common_tags=set(d.get('common_tags', [])),
            created_at=d.get('created_at', time.time()),
            last_updated=d.get('last_updated', time.time())
        )


# =============================================================================
# AGENTIC TAG INDEX (NO HARDCODING)
# =============================================================================

class AgenticTagIndex:
    """
    FULLY AGENTIC tag-based Q-table index.
    
    NO HARDCODED CATEGORIES - everything emerges from data!
    
    Key features:
    1. Tags extracted by LLM, not predefined
    2. Co-occurrence tracking for semantic expansion
    3. Self-organizing clusters
    4. Full persistence support
    5. Online learning of tag utility
    6. Multi-path retrieval for recall guarantee
    7. Rich search results with gotcha context
    """
    
    # Persistence version for backward compatibility
    VERSION = "1.0.0"
    
    def __init__(self, synapse_config=None):
        # Use AgenticIndexConfig for all parameters (NO MAGIC NUMBERS!)
        self.idx_config = AgenticIndexConfig()
        self.synapse_config = synapse_config or {}
        
        # Tag index (all dynamic!)
        self.tag_to_entries: Dict[str, set] = {}  # tag → set of entry keys
        self.entry_to_tags: Dict[Tuple[str, str], set] = {}  # key → set of tags
        self.tag_stats: Dict[str, TagStats] = {}
        
        # 🔥 A-TEAM: Online learning - track tag utility
        self.tag_utility: Dict[str, TagUtility] = {}
        
        # Self-organizing clusters
        self.clusters: Dict[str, AgenticCluster] = {}
        self.entry_to_cluster: Dict[Tuple[str, str], str] = {}
        
        # Entry metadata for multi-path retrieval
        self.entry_timestamps: Dict[Tuple[str, str], float] = {}  # For recency search
        self.entry_q_values: Dict[Tuple[str, str], float] = {}  # For value-based search
        
        # LLM components
        try:
            self.tag_extractor = dspy.ChainOfThought(DynamicTagExtractorSignature)
            self.cluster_assigner = dspy.ChainOfThought(ClusterAssignmentSignature)
            self.reorganizer = dspy.ChainOfThought(ClusterReorganizationSignature)
            self.relevance_scorer = dspy.ChainOfThought(RelevanceScoringSignature)
            self._tag_extraction_llm_ready = True
        except Exception as e:
            logger.warning(f"LLM signatures not available: {e}")
            self._tag_extraction_llm_ready = False
        
        # Counters for monitoring
        self.total_indexed_entries = 0
        self.total_searches_performed = 0
        self.search_hit_count = 0  # Searches that found relevant results
        self.search_miss_count = 0  # Searches with no results
        
        logger.info("🏷️ AgenticTagIndex initialized (NO hardcoded categories, online learning enabled)")
    
    def index_entry(self, key: Tuple[str, str], state_desc: str, action_desc: str, 
                    outcome: str = "unknown", q_value: float = 0.5) -> List[str]:
        """
        Index a new Q-table entry using LLM-extracted tags.
        
        🔥 A-TEAM: Also tracks metadata for multi-path retrieval.
        
        Args:
            key: (state_desc, action_desc) tuple
            state_desc: Full state description
            action_desc: Full action description
            outcome: "success", "partial", "failure", or "unknown"
            q_value: Current Q-value for this entry (for value-based retrieval)
        
        Returns: List of extracted tags
        """
        self.total_indexed_entries += 1
        
        # === STEP 1: LLM Tag Extraction ===
        tags = self._extract_tags(state_desc, action_desc, outcome)
        
        # === STEP 2: Update Tag Index ===
        for tag in tags:
            # Initialize tag tracking
            if tag not in self.tag_to_entries:
                self.tag_to_entries[tag] = set()
            if tag not in self.tag_stats:
                self.tag_stats[tag] = TagStats(tag=tag, created_at=time.time())
                logger.debug(f"🏷️ NEW TAG EMERGED: '{tag}'")
            
            # Add entry to tag's posting list
            self.tag_to_entries[tag].add(key)
            
            # Update stats
            self.tag_stats[tag].usage_count += 1
            self.tag_stats[tag].last_used = time.time()
            
            # Track co-occurrence (for semantic expansion)
            for other_tag in tags:
                if other_tag != tag:
                    self.tag_stats[tag].co_occurring_tags[other_tag] = \
                        self.tag_stats[tag].co_occurring_tags.get(other_tag, 0) + 1
        
        # Track entry's tags
        if key not in self.entry_to_tags:
            self.entry_to_tags[key] = set()
        self.entry_to_tags[key].update(tags)
        
        # === STEP 3: Store Metadata for Multi-Path Retrieval ===
        self.entry_timestamps[key] = time.time()  # For recency search
        self.entry_q_values[key] = q_value  # For value-based search
        
        # === STEP 4: Cluster Assignment ===
        self._assign_to_cluster(key, state_desc, action_desc, tags)
        
        # === STEP 5: Maybe Reorganize ===
        if self.total_indexed_entries % self.idx_config.reorganize_interval == 0:
            self._reorganize_clusters()
        
        return tags
    
    def _extract_tags(self, state_desc: str, action_desc: str, outcome: str) -> List[str]:
        """
        Extract tags using LLM with robust parsing and retry.
        
        🔥 A-TEAM: Safe format handling:
        1. Try JSON parsing
        2. Try YAML parsing (more forgiving)
        3. Try comma-separated extraction
        4. Fallback to word extraction
        
        Plus: Retry mechanism for transient failures.
        """
        if not self._tag_extraction_llm_ready:
            return self._fallback_tag_extraction(state_desc, action_desc)
        
        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                # Sample existing tags for consistency
                existing = list(self.tag_stats.keys())[:self.idx_config.max_existing_tags_sample]
                
                result = self.tag_extractor(
                    state_description=state_desc[:self.idx_config.state_desc_max_chars],
                    action_description=action_desc[:self.idx_config.action_desc_max_chars],
                    outcome=outcome[:self.idx_config.outcome_max_chars],
                    existing_tags=json.dumps(existing)
                )
                
                # Parse tags with multi-format fallback
                tags_str = result.extracted_tags
                tags = self._safe_parse_tags(tags_str)
                
                if tags:
                    return tags[:self.idx_config.max_tags_per_entry]
                
                # If parsing failed but no exception, try next attempt
                if attempt < max_retries:
                    logger.debug(f"Tag parsing returned empty, retry {attempt + 1}/{max_retries}")
                    continue
                    
            except Exception as e:
                if attempt < max_retries:
                    logger.debug(f"Tag extraction attempt {attempt + 1} failed: {e}, retrying...")
                    continue
                logger.warning(f"Tag extraction failed after {max_retries + 1} attempts: {e}")
        
        # All retries exhausted, use fallback
        return self._fallback_tag_extraction(state_desc, action_desc)
    
    def _safe_parse_tags(self, tags_str: str, parse_attempt: int = 0, last_error: str = None) -> List[str]:
        """
        Parse tags from LLM output with LLM-based error correction.
        
        🔥 A-TEAM CRITICAL: ONE FORMAT ONLY (JSON)
        If JSON fails, ask LLM to correct with error context.
        No YAML, no multiple formats - just JSON with smart correction.
        
        Args:
            tags_str: Raw string from LLM
            parse_attempt: Current attempt number (for limiting retries)
            last_error: Error message from previous parse attempt (for LLM context)
        """
        if not tags_str or not tags_str.strip():
            return []
        
        tags_str = tags_str.strip()
        
        # === ATTEMPT 1: Direct JSON Parse ===
        try:
            tags = json.loads(tags_str)
            if isinstance(tags, list):
                return self._clean_tags(tags)
            # If it's a dict with a tags key, extract it
            if isinstance(tags, dict) and 'tags' in tags:
                return self._clean_tags(tags['tags'])
        except json.JSONDecodeError as e:
            error_msg = str(e)
        
        # === ATTEMPT 2: Extract JSON array from text ===
        # LLM might output: "Here are the tags: ["tag1", "tag2"]"
        import re
        json_match = re.search(r'\[([^\]]*)\]', tags_str)
        if json_match:
            try:
                array_str = '[' + json_match.group(1) + ']'
                tags = json.loads(array_str)
                if isinstance(tags, list):
                    return self._clean_tags(tags)
            except json.JSONDecodeError as e:
                error_msg = f"Extracted array parse error: {e}"
        
        # === ATTEMPT 3: Ask LLM to fix the JSON (with error context) ===
        if parse_attempt < 2 and self._tag_extraction_llm_ready:
            try:
                corrected = self._llm_correct_json_format(tags_str, error_msg)
                if corrected:
                    # Recursive call with incremented attempt
                    return self._safe_parse_tags(corrected, parse_attempt + 1, error_msg)
            except Exception as e:
                logger.debug(f"LLM JSON correction failed: {e}")
        
        # === FINAL FALLBACK: Simple comma extraction ===
        # Only used if all else fails - extract anything that looks like a tag
        if ',' in tags_str or '\n' in tags_str:
            delimiter = ',' if ',' in tags_str else '\n'
            tags = []
            for item in tags_str.split(delimiter):
                # Clean thoroughly
                clean = item.strip().strip('"').strip("'").strip('[').strip(']').lstrip('-').strip()
                if clean and len(clean) > 2 and len(clean) < 50:
                    tags.append(clean.lower())
            if tags:
                return tags[:self.idx_config.max_tags_per_entry]
        
        # Single word
        clean = tags_str.strip().strip('"').strip("'").strip('[').strip(']')
        if clean and len(clean) > 2 and len(clean) < 50:
            return [clean.lower()]
        
        return []
    
    def _llm_correct_json_format(self, malformed_json: str, error_msg: str) -> Optional[str]:
        """
        Ask LLM to correct malformed JSON with error context.
        
        🔥 A-TEAM: ONE FORMAT - LLM fixes errors, we don't fallback to other formats!
        """
        if not self._tag_extraction_llm_ready:
            return None
        
        try:
            # Use a simple correction signature
            correction_prompt = f"""The following was supposed to be a JSON array of tags, but it has a format error.

ERROR: {error_msg}

MALFORMED OUTPUT:
{malformed_json}

Please return ONLY a valid JSON array of tags. Example: ["tag1", "tag2", "tag3"]
Do NOT include any explanation, just the JSON array."""

            # Use a simple completion
            result = self.tag_extractor(
                state_description="(JSON correction request)",
                action_description=correction_prompt,
                outcome="Fix the JSON format",
                existing_tags="[]"
            )
            
            return result.extracted_tags
            
        except Exception as e:
            logger.debug(f"JSON correction LLM call failed: {e}")
            return None
    
    def _clean_tags(self, tags: List) -> List[str]:
        """Clean and normalize tags."""
        cleaned = []
        for t in tags:
            if t is None:
                continue
            tag = str(t).lower().strip().strip('"').strip("'")
            # Remove common prefixes/suffixes
            tag = tag.lstrip('-').lstrip('*').strip()
            # Skip too short or too long tags
            if len(tag) > 2 and len(tag) < 50:
                cleaned.append(tag)
        # Deduplicate while preserving order
        seen = set()
        result = []
        for tag in cleaned:
            if tag not in seen:
                seen.add(tag)
                result.append(tag)
        return result
    
    def _fallback_tag_extraction(self, state_desc: str, action_desc: str) -> List[str]:
        """
        Fallback tag extraction when LLM unavailable.
        
        🔥 A-TEAM: NO HARDCODED STOPWORDS!
        Instead, we use statistical filtering:
        - Words that appear in >50% of entries are likely stopwords
        - Words that appear in <2 entries are too specific
        - We learn which words are useful over time
        """
        import re
        from collections import Counter
        
        text = f"{state_desc} {action_desc}".lower()
        min_word_len = self.idx_config.min_word_length_fallback
        
        # Extract words meeting minimum length
        words = re.findall(rf'\b[a-z]{{{min_word_len},}}\b', text)
        
        # Use LEARNED stopwords from tag utility (words with low utility)
        learned_low_utility = {
            tag for tag, util in self.tag_utility.items()
            if util.utility_score < 0.3 and util.total_uses > 10
        }
        
        # Filter out learned low-utility words
        words = [w for w in words if w not in learned_low_utility]
        
        # Boost words that match high-utility tags
        word_scores = Counter()
        for word in words:
            base_count = 1
            # Boost if this word is a known high-utility tag
            if word in self.tag_utility:
                base_count += self.tag_utility[word].utility_score * 2
            word_scores[word] += base_count
        
        # Return top words by score
        return [w for w, c in word_scores.most_common(self.idx_config.max_tags_per_entry)]
    
    def _assign_to_cluster(self, key: Tuple[str, str], state_desc: str, 
                           action_desc: str, tags: List[str]):
        """
        Assign entry to cluster (or create new one).
        
        🔥 A-TEAM: NO HARDCODED CLUSTER NAMES!
        Descriptions are generated from content, not hardcoded.
        """
        if not self.clusters:
            # First entry - create first cluster with descriptive name
            desc = self._generate_cluster_description(tags, state_desc)
            self._create_cluster(desc, key, tags)
            return
        
        if not self._tag_extraction_llm_ready:
            # Fallback: assign to cluster with most tag overlap
            best_cluster = None
            best_overlap = 0
            for cid, cluster in self.clusters.items():
                overlap = len(set(tags) & cluster.common_tags)
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_cluster = cid
            
            if best_cluster and best_overlap > 0:
                self._add_to_cluster(best_cluster, key, tags)
            else:
                # Create new cluster with auto-generated description
                desc = self._generate_cluster_description(tags, state_desc)
                self._create_cluster(desc, key, tags)
            return
        
        try:
            max_clusters = self.idx_config.max_clusters_for_assignment
            # Get cluster summaries
            summaries = [
                {"id": c.id, "description": c.description, 
                 "common_tags": list(c.common_tags)[:10], "size": c.size}
                for c in list(self.clusters.values())[:max_clusters]
            ]
            
            # 🔥 A-TEAM: Full context, no truncation
            result = self.cluster_assigner(
                entry_description=f"State: {state_desc}\nAction: {action_desc}",
                entry_tags=json.dumps(tags),
                existing_clusters=json.dumps(summaries)
            )
            
            decision = result.assignment.strip()
            
            if decision.startswith("ASSIGN:"):
                cid = decision.split(":")[1].strip()
                if cid in self.clusters:
                    self._add_to_cluster(cid, key, tags)
                    return
            
            if decision.startswith("CREATE:"):
                desc = decision.split(":", 1)[1].strip()
                self._create_cluster(desc, key, tags)
                return
            
            # Fallback with auto-generated description
            desc = self._generate_cluster_description(tags, state_desc)
            self._create_cluster(desc, key, tags)
            
        except Exception as e:
            logger.warning(f"Cluster assignment failed: {e}")
            desc = self._generate_cluster_description(tags, state_desc)
            self._create_cluster(desc, key, tags)
    
    def _generate_cluster_description(self, tags: List[str], state_desc: str) -> str:
        """
        Generate meaningful cluster description WITHOUT hardcoding.
        
        Uses tags if available, otherwise extracts key phrases from state.
        """
        if tags:
            # Use top tags as description
            tag_str = ", ".join(tags[:5])
            return f"Experiences involving: {tag_str}"
        
        # Extract key words from state description
        import re
        words = re.findall(r'\b[A-Za-z]{5,}\b', state_desc[:200])
        if words:
            unique_words = list(dict.fromkeys(words))[:4]
            return f"Tasks related to: {' '.join(unique_words)}"
        
        # Last resort: use timestamp-based unique identifier
        return f"Cluster created at {time.strftime('%Y-%m-%d %H:%M')}"
    
    def _create_cluster(self, description: str, first_key: Tuple[str, str], tags: List[str]):
        """Create a new cluster."""
        cid = f"c_{len(self.clusters)}_{int(time.time())}"
        
        self.clusters[cid] = AgenticCluster(
            id=cid,
            description=description,
            members=[first_key],
            common_tags=set(tags)
        )
        self.entry_to_cluster[first_key] = cid
        
        logger.debug(f"🗂️ NEW CLUSTER: '{cid}' - {description}")
    
    def _add_to_cluster(self, cluster_id: str, key: Tuple[str, str], tags: List[str]):
        """Add entry to existing cluster."""
        if cluster_id not in self.clusters:
            return
        
        cluster = self.clusters[cluster_id]
        cluster.members.append(key)
        cluster.common_tags.update(tags)
        cluster.last_updated = time.time()
        self.entry_to_cluster[key] = cluster_id
    
    def search(self, query_state: str, query_action: str, top_k: int = None) -> List[Tuple[Tuple[str, str], float]]:
        """Search with configurable top_k (default from config: 10)."""
        if top_k is None:
            top_k = self.idx_config.default_top_k
        """
        Search for relevant Q-entries using MULTI-PATH retrieval.
        
        🔥 A-TEAM: Guarantees recall by using multiple independent retrieval paths.
        Returns: List of (key, score) tuples.
        """
        self.total_searches_performed += 1
        import math
        
        # === STEP 1: Extract Query Tags ===
        query_tags = self._extract_tags(query_state, query_action, "(searching)")
        
        # === PATH 1: Tag-Based Retrieval (Primary) ===
        candidates = {}  # key → score
        matching_tags_per_entry = {}  # key → List[tags]
        
        for tag in query_tags:
            if tag in self.tag_to_entries:
                entries = self.tag_to_entries[tag]
                # Safe IDF calculation (no division by zero)
                idf = self._safe_idf(tag)
                # Apply tag utility boost if available
                utility_boost = self._get_tag_utility_boost(tag)
                
                for entry in entries:
                    candidates[entry] = candidates.get(entry, 0) + idf * utility_boost
                    if entry not in matching_tags_per_entry:
                        matching_tags_per_entry[entry] = []
                    matching_tags_per_entry[entry].append(tag)
        
        # === PATH 2: Co-occurrence Expansion ===
        expanded_tags = self._expand_tags(query_tags)
        expansion_weight = self.idx_config.expansion_score_weight
        for tag in expanded_tags:
            if tag in self.tag_to_entries:
                for entry in self.tag_to_entries[tag]:
                    candidates[entry] = candidates.get(entry, 0) + expansion_weight
        
        # === PATH 3: Cluster-Based Retrieval ===
        cluster_weight = self.idx_config.cluster_score_weight
        relevant_clusters = self._find_relevant_clusters(query_tags)
        for cid in relevant_clusters:
            if cid in self.clusters:
                for member in self.clusters[cid].members[:50]:
                    candidates[member] = candidates.get(member, 0) + cluster_weight
        
        # === PATH 4: Recency-Based (catch new entries not well-indexed) ===
        recent_entries = self._get_recent_entries(self.idx_config.recent_entries_search_count)
        for entry in recent_entries:
            candidates[entry] = candidates.get(entry, 0) + 0.1  # Small boost
        
        # === PATH 5: High-Value Entries (universally useful) ===
        high_value_entries = self._get_high_value_entries(self.idx_config.high_value_entries_count)
        for entry in high_value_entries:
            candidates[entry] = candidates.get(entry, 0) + 0.1  # Small boost
        
        # Track search quality
        if candidates:
            self.search_hit_count += 1
        else:
            self.search_miss_count += 1
        
        # Sort by score
        sorted_candidates = sorted(candidates.items(), key=lambda x: -x[1])
        top_candidates = sorted_candidates[:self.idx_config.top_candidates_for_llm]
        
        # === STEP 6: LLM Scoring (only on top candidates) ===
        if self._tag_extraction_llm_ready and len(top_candidates) > top_k * 2:
            try:
                final = self._llm_score_candidates(query_state, query_action, top_candidates)
                return final[:top_k]
            except Exception as e:
                logger.debug(f"LLM scoring failed, using tag scores: {e}")
        
        return top_candidates[:top_k]
    
    def _safe_idf(self, tag: str) -> float:
        """
        Safe IDF calculation (no division by zero, no log of zero).
        
        Formula: log((N + 1) / (df + 1)) + 1
        Where N = total docs, df = docs with tag
        """
        import math
        total_docs = max(len(self.entry_to_tags), 1)
        docs_with_tag = len(self.tag_to_entries.get(tag, set()))
        return math.log((total_docs + 1) / (docs_with_tag + 1)) + 1
    
    def _get_tag_utility_boost(self, tag: str) -> float:
        """
        Get boost factor for tags based on learned utility.
        
        High-utility tags (that led to successful searches) get higher weight.
        """
        if tag not in self.tag_utility:
            return 1.0  # Neutral boost
        
        util = self.tag_utility[tag]
        if util.total_uses < self.idx_config.min_uses_for_tag_boost:
            return 1.0  # Not enough data
        
        # Boost range: 0.5 to 1.5 based on utility
        return 0.5 + util.utility_score
    
    def _get_recent_entries(self, n: int) -> List[Tuple[str, str]]:
        """Get most recent N entries (for recency-based retrieval path)."""
        if not self.entry_timestamps:
            return []
        sorted_by_time = sorted(self.entry_timestamps.items(), key=lambda x: -x[1])
        return [entry for entry, ts in sorted_by_time[:n]]
    
    def _get_high_value_entries(self, n: int) -> List[Tuple[str, str]]:
        """Get entries with highest Q-values (universally useful experiences)."""
        if not self.entry_q_values:
            return []
        sorted_by_value = sorted(self.entry_q_values.items(), key=lambda x: -x[1])
        return [entry for entry, val in sorted_by_value[:n]]
    
    def record_search_feedback(self, query_tags: List[str], used_results: List[Tuple[str, str]], 
                                task_success: bool):
        """
        Record feedback on search quality for online learning.
        
        🔥 A-TEAM: This is how we learn which tags are useful!
        Call this after using search results to complete a task.
        """
        for tag in query_tags:
            if tag not in self.tag_utility:
                self.tag_utility[tag] = TagUtility(tag=tag)
            
            util = self.tag_utility[tag]
            util.total_uses += 1
            
            if task_success:
                util.success_uses += 1
            
            # Check if results with this tag were used
            tag_entries = self.tag_to_entries.get(tag, set())
            if any(r in tag_entries for r in used_results):
                util.result_used_count += 1
    
    # =========================================================================
    # TASK RECOVERY & USER FEEDBACK METHODS
    # =========================================================================
    
    def find_unfinished_similar_tasks(self, current_state: str, current_action: str) -> List[Dict]:
        """
        Find past experiences with similar states that had failures or partial success.
        
        🔥 A-TEAM: This helps agents recover by learning from past failures!
        
        Returns:
            List of dicts with:
            - key: (state, action) tuple
            - outcome: "failure" or "partial"
            - pitfalls: List of known pitfalls
            - suggestions: What might work based on successful similar cases
        """
        # Search for similar entries - use config top_k (default 10)
        similar = self.search(current_state, current_action)
        
        unfinished = []
        successful_patterns = []
        
        for key, score in similar:
            if key not in self.entry_q_values:
                continue
            
            q_val = self.entry_q_values[key]
            entry_tags = self.entry_to_tags.get(key, set())
            
            if q_val < getattr(self.config, 'q_low_reward_threshold', 0.3):  # Failure (A-TEAM: configurable)
                unfinished.append({
                    'key': key,
                    'outcome': 'failure',
                    'q_value': q_val,
                    'tags': list(entry_tags),
                    'relevance': score
                })
            elif q_val < 0.7:  # Partial
                unfinished.append({
                    'key': key,
                    'outcome': 'partial',
                    'q_value': q_val,
                    'tags': list(entry_tags),
                    'relevance': score
                })
            else:  # Success - use as pattern
                successful_patterns.append({
                    'key': key,
                    'q_value': q_val,
                    'tags': list(entry_tags)
                })
        
        # Enrich unfinished tasks with suggestions from successful patterns
        for task in unfinished:
            task['suggestions'] = self._extract_suggestions(task['tags'], successful_patterns)
        
        return unfinished
    
    def _extract_suggestions(self, failed_tags: List[str], success_patterns: List[Dict]) -> List[str]:
        """Extract suggestions from successful patterns that share tags with failed task."""
        suggestions = []
        
        for pattern in success_patterns:
            common_tags = set(failed_tags) & set(pattern['tags'])
            if common_tags:
                # This success pattern shares tags - might have useful insight
                diff_tags = set(pattern['tags']) - set(failed_tags)
                if diff_tags:
                    suggestions.append(f"Try adding approach: {', '.join(list(diff_tags)[:3])}")
        
        return suggestions[:5]  # Top 5 suggestions
    
    def update_from_user_feedback(self, key: Tuple[str, str], feedback: Dict):
        """
        Update entry based on user feedback.
        
        🔥 A-TEAM: User corrections improve the system!
        
        Args:
            key: (state_desc, action_desc) tuple
            feedback: Dict with:
                - correct_tags: List[str] - tags user says are correct
                - wrong_tags: List[str] - tags user says are wrong
                - new_tags: List[str] - tags user wants to add
                - outcome_correction: str - "success"/"partial"/"failure"
                - pitfall_note: str - user-provided pitfall
                - lesson_note: str - user-provided lesson
        """
        # Update tags
        if 'wrong_tags' in feedback:
            for tag in feedback['wrong_tags']:
                if tag in self.tag_to_entries and key in self.tag_to_entries[tag]:
                    self.tag_to_entries[tag].remove(key)
                if key in self.entry_to_tags and tag in self.entry_to_tags[key]:
                    self.entry_to_tags[key].remove(tag)
                # Mark tag as potentially low-utility
                if tag in self.tag_utility:
                    self.tag_utility[tag].false_negative_count += 1
        
        if 'new_tags' in feedback:
            for tag in feedback['new_tags']:
                if tag not in self.tag_to_entries:
                    self.tag_to_entries[tag] = set()
                self.tag_to_entries[tag].add(key)
                if key not in self.entry_to_tags:
                    self.entry_to_tags[key] = set()
                self.entry_to_tags[key].add(tag)
                # Initialize tag stats
                if tag not in self.tag_stats:
                    self.tag_stats[tag] = TagStats(tag=tag, created_at=time.time())
                self.tag_stats[tag].usage_count += 1
        
        # Update Q-value if outcome corrected
        if 'outcome_correction' in feedback:
            outcome = feedback['outcome_correction']
            if outcome == 'success':
                self.entry_q_values[key] = 0.9
            elif outcome == 'partial':
                self.entry_q_values[key] = 0.5
            elif outcome == 'failure':
                self.entry_q_values[key] = 0.1
        
        logger.info(f"📝 Updated entry from user feedback: {len(feedback)} corrections applied")
        
        return True
    
    def get_defect_analysis(self, task_description: str) -> Dict:
        """
        Analyze potential defects for a task based on historical data.
        
        🔥 A-TEAM: Proactive defect detection!
        
        Returns:
            Dict with:
            - known_pitfalls: Pitfalls from similar past tasks
            - failure_rate: Historical failure rate for similar tasks
            - risky_patterns: Patterns that often lead to failure
            - recommended_approach: Based on successful patterns
        """
        # Search for similar tasks
        # Use config default top_k (10)
        similar = self.search(task_description, "")
        
        total = len(similar)
        failures = 0
        partials = 0
        successes = 0
        
        failure_tags = []
        success_tags = []
        
        for key, score in similar:
            q_val = self.entry_q_values.get(key, 0.5)
            tags = list(self.entry_to_tags.get(key, set()))
            
            # 🔴 A-TEAM FIX: Use config thresholds
            if q_val < getattr(self.config, 'q_low_reward_threshold', 0.3):
                failures += 1
                failure_tags.extend(tags)
            elif q_val < getattr(self.config, 'q_high_reward_threshold', 0.7):
                partials += 1
            else:
                successes += 1
                success_tags.extend(tags)
        
        # Find risky patterns (tags that appear more in failures than successes)
        from collections import Counter
        failure_counter = Counter(failure_tags)
        success_counter = Counter(success_tags)
        
        risky_patterns = []
        for tag, fail_count in failure_counter.most_common(10):
            success_count = success_counter.get(tag, 0)
            if fail_count > success_count:
                risky_patterns.append(tag)
        
        # Recommended approach (tags from successes not in failures)
        recommended_tags = []
        for tag, count in success_counter.most_common(10):
            if tag not in failure_counter:
                recommended_tags.append(tag)
        
        return {
            'total_similar': total,
            'failure_rate': failures / max(total, 1),
            'partial_rate': partials / max(total, 1),
            'success_rate': successes / max(total, 1),
            'risky_patterns': risky_patterns[:5],
            'recommended_approach': recommended_tags[:5],
            'historical_data_quality': 'high' if total > 10 else 'low' if total < 3 else 'medium'
        }
    
    def _expand_tags(self, tags: List[str], max_expand: int = 10) -> List[str]:
        """Expand tags using co-occurrence patterns."""
        expanded = {}
        
        for tag in tags:
            if tag in self.tag_stats:
                for co_tag, count in self.tag_stats[tag].co_occurring_tags.items():
                    if co_tag not in tags:
                        score = count * self.tag_stats.get(co_tag, TagStats(co_tag, 0)).importance
                        expanded[co_tag] = max(expanded.get(co_tag, 0), score)
        
        sorted_exp = sorted(expanded.items(), key=lambda x: -x[1])
        return [t for t, s in sorted_exp[:max_expand]]
    
    def _find_relevant_clusters(self, tags: List[str], top_n: int = 5) -> List[str]:
        """Find clusters with highest tag overlap."""
        scored = []
        for cid, cluster in self.clusters.items():
            overlap = len(set(tags) & cluster.common_tags)
            if overlap > 0:
                scored.append((cid, overlap))
        
        scored.sort(key=lambda x: -x[1])
        return [cid for cid, s in scored[:top_n]]
    
    def _llm_score_candidates(self, query_state: str, query_action: str,
                              candidates: List[Tuple[Tuple[str, str], float]]) -> List[Tuple[Tuple[str, str], float]]:
        """Use LLM to score candidate relevance."""
        # Format candidates for LLM
        candidate_list = []
        for (state, action), score in candidates[:50]:
            candidate_list.append({
                "id": f"{hash((state, action)) % 10000}",
                "state": smart_truncate(state, max_tokens=100),
                "action": smart_truncate(action, max_tokens=50),
                "initial_score": score
            })
        
        # 🔥 A-TEAM: Full context for relevance scoring
        result = self.relevance_scorer(
            query_state=query_state,
            query_action=query_action,
            candidate_entries=json.dumps(candidate_list)
        )
        
        # Parse scores
        try:
            scores = json.loads(result.scored_entries)
            id_to_score = {s['id']: s['score'] for s in scores}
            
            # Update candidate scores
            final = []
            for (state, action), old_score in candidates[:50]:
                eid = f"{hash((state, action)) % 10000}"
                new_score = id_to_score.get(eid, old_score)
                final.append(((state, action), new_score))
            
            final.sort(key=lambda x: -x[1])
            return final
            
        except (ValueError, KeyError, TypeError, AttributeError) as e:
            logger.warning(f"Q-learning ranking failed: {e}")
            return candidates
    
    def _reorganize_clusters(self):
        """Periodically reorganize clusters using LLM."""
        if not self._tag_extraction_llm_ready or len(self.clusters) < self.idx_config.min_clusters_for_reorg:
            return
        
        logger.info(f"🔄 Reorganizing clusters (insert #{self.insert_count})")
        
        try:
            stats = [
                {"id": c.id, "description": c.description, "size": c.size,
                 "common_tags": list(c.common_tags)[:10]}
                for c in self.clusters.values()
            ]
            
            result = self.reorganizer(
                cluster_stats=json.dumps(stats),
                total_entries=str(len(self.entry_to_tags))
            )
            
            # Parse and execute actions
            actions = json.loads(result.actions)
            for action in actions:
                if action.get('action') == 'MERGE' and len(action.get('cluster_ids', [])) >= 2:
                    self._merge_clusters(action['cluster_ids'], action.get('new_description', ''))
                elif action.get('action') == 'RENAME' and action.get('cluster_id'):
                    if action['cluster_id'] in self.clusters:
                        self.clusters[action['cluster_id']].description = action.get('new_description', '')
            
        except Exception as e:
            logger.warning(f"Cluster reorganization failed: {e}")
    
    def _merge_clusters(self, cluster_ids: List[str], new_description: str):
        """Merge multiple clusters into one."""
        if len(cluster_ids) < 2:
            return
        
        # Keep first cluster, merge others into it
        primary = cluster_ids[0]
        if primary not in self.clusters:
            return
        
        for cid in cluster_ids[1:]:
            if cid in self.clusters:
                # Move members
                for member in self.clusters[cid].members:
                    self.clusters[primary].members.append(member)
                    self.entry_to_cluster[member] = primary
                # Merge tags
                self.clusters[primary].common_tags.update(self.clusters[cid].common_tags)
                # Delete merged cluster
                del self.clusters[cid]
        
        # Update description
        if new_description:
            self.clusters[primary].description = new_description
        
        logger.debug(f"🔗 Merged clusters {cluster_ids} into {primary}")
    
    # === PERSISTENCE (with versioning for backward compatibility) ===
    
    def save_state(self, path: str):
        """
        Save tag index state to file with versioning.
        
        🔥 A-TEAM: Includes all fields for complete state recovery:
        - Core indices (tags, clusters)
        - Online learning data (tag_utility)
        - Metadata for multi-path retrieval (timestamps, q_values)
        - Counters and statistics
        """
        from pathlib import Path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        state = {
            # Version for backward compatibility
            'version': self.VERSION,
            'schema': 'agentic_tag_index_v1',
            
            # Core tag index
            'tag_to_entries': {
                tag: [f"{k[0]}|||{k[1]}" for k in entries]
                for tag, entries in self.tag_to_entries.items()
            },
            'entry_to_tags': {
                f"{k[0]}|||{k[1]}": list(tags)
                for k, tags in self.entry_to_tags.items()
            },
            'tag_stats': {
                tag: stats.to_dict() 
                for tag, stats in self.tag_stats.items()
            },
            
            # 🔥 Online learning data
            'tag_utility': {
                tag: util.to_dict()
                for tag, util in self.tag_utility.items()
            },
            
            # Cluster data
            'clusters': {
                cid: cluster.to_dict()
                for cid, cluster in self.clusters.items()
            },
            'entry_to_cluster': {
                f"{k[0]}|||{k[1]}": cid
                for k, cid in self.entry_to_cluster.items()
            },
            
            # 🔥 Metadata for multi-path retrieval
            'entry_timestamps': {
                f"{k[0]}|||{k[1]}": ts
                for k, ts in self.entry_timestamps.items()
            },
            'entry_q_values': {
                f"{k[0]}|||{k[1]}": val
                for k, val in self.entry_q_values.items()
            },
            
            # Counters and statistics
            'total_indexed_entries': self.total_indexed_entries,
            'total_searches_performed': self.total_searches_performed,
            'search_hit_count': self.search_hit_count,
            'search_miss_count': self.search_miss_count,
            
            # Timestamp
            'saved_at': time.time()
        }
        
        with open(path, 'w') as f:
            json.dump(state, f, indent=2, default=str)
        
        logger.info(f"✅ AgenticTagIndex saved (v{self.VERSION}): "
                   f"{len(self.tag_stats)} tags, {len(self.clusters)} clusters, "
                   f"{len(self.tag_utility)} learned utilities")
    
    def load_state(self, path: str) -> bool:
        """
        Load tag index state from file with version migration.
        
        Handles backward compatibility with older versions.
        """
        from pathlib import Path
        
        if not Path(path).exists():
            logger.info(f"ℹ️ No tag index state at {path}")
            return False
        
        try:
            with open(path, 'r') as f:
                state = json.load(f)
            
            # Check version and migrate if needed
            version = state.get('version', '0.0.0')
            if version < "1.0.0":
                state = self._migrate_v0_to_v1(state)
            
            # Restore tag_to_entries
            self.tag_to_entries = {}
            for tag, entries in state.get('tag_to_entries', {}).items():
                self.tag_to_entries[tag] = set()
                for e in entries:
                    if '|||' in e:
                        parts = e.split('|||', 1)
                        self.tag_to_entries[tag].add((parts[0], parts[1]))
            
            # Restore entry_to_tags
            self.entry_to_tags = {}
            for k_str, tags in state.get('entry_to_tags', {}).items():
                if '|||' in k_str:
                    parts = k_str.split('|||', 1)
                    self.entry_to_tags[(parts[0], parts[1])] = set(tags)
            
            # Restore tag_stats
            self.tag_stats = {}
            for tag, stats_dict in state.get('tag_stats', {}).items():
                self.tag_stats[tag] = TagStats.from_dict(stats_dict)
            
            # 🔥 Restore online learning data
            self.tag_utility = {}
            for tag, util_dict in state.get('tag_utility', {}).items():
                self.tag_utility[tag] = TagUtility.from_dict(util_dict)
            
            # Restore clusters
            self.clusters = {}
            for cid, cluster_dict in state.get('clusters', {}).items():
                self.clusters[cid] = AgenticCluster.from_dict(cluster_dict)
            
            # Restore entry_to_cluster
            self.entry_to_cluster = {}
            for k_str, cid in state.get('entry_to_cluster', {}).items():
                if '|||' in k_str:
                    parts = k_str.split('|||', 1)
                    self.entry_to_cluster[(parts[0], parts[1])] = cid
            
            # 🔥 Restore metadata for multi-path retrieval
            self.entry_timestamps = {}
            for k_str, ts in state.get('entry_timestamps', {}).items():
                if '|||' in k_str:
                    parts = k_str.split('|||', 1)
                    self.entry_timestamps[(parts[0], parts[1])] = ts
            
            self.entry_q_values = {}
            for k_str, val in state.get('entry_q_values', {}).items():
                if '|||' in k_str:
                    parts = k_str.split('|||', 1)
                    self.entry_q_values[(parts[0], parts[1])] = val
            
            # Restore counters
            self.total_indexed_entries = state.get('total_indexed_entries', state.get('insert_count', 0))
            self.total_searches_performed = state.get('total_searches_performed', state.get('search_count', 0))
            self.search_hit_count = state.get('search_hit_count', 0)
            self.search_miss_count = state.get('search_miss_count', 0)
            
            logger.info(f"✅ AgenticTagIndex loaded (v{version}): "
                       f"{len(self.tag_stats)} tags, {len(self.clusters)} clusters, "
                       f"{len(self.tag_utility)} learned utilities")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load tag index: {e}")
            return False
    
    def _migrate_v0_to_v1(self, state: Dict) -> Dict:
        """
        Migrate old state format to v1.0.0.
        
        Handles backward compatibility with pre-versioned saves.
        """
        logger.info("🔄 Migrating AgenticTagIndex state from v0 to v1.0.0")
        
        # Add version
        state['version'] = "1.0.0"
        
        # Rename counters if using old names
        if 'insert_count' in state and 'total_indexed_entries' not in state:
            state['total_indexed_entries'] = state['insert_count']
        if 'search_count' in state and 'total_searches_performed' not in state:
            state['total_searches_performed'] = state['search_count']
        
        # Initialize new fields
        if 'tag_utility' not in state:
            state['tag_utility'] = {}
        if 'entry_timestamps' not in state:
            state['entry_timestamps'] = {}
        if 'entry_q_values' not in state:
            state['entry_q_values'] = {}
        if 'search_hit_count' not in state:
            state['search_hit_count'] = 0
        if 'search_miss_count' not in state:
            state['search_miss_count'] = 0
        
        return state


class LLMQPredictor:
    """
    LLM-based Q-value predictor using natural language Q-table.
    
    KEY INNOVATION: Instead of Q[s,a] = float, we use:
    Q[(verbose_state_description, verbose_action_description)] = {
        'value': float,
        'context': [experiences],
        'learned_lessons': [natural language lessons],
        'visit_count': int
    }
    
    LLMs can generalize across similar states/actions because they
    understand semantic similarity in natural language!
    
    ✅ GENERIC: No domain-specific logic, works for any swarm.
    """
    
    def __init__(self, config):
        self.config = config
        self.predictor = dspy.ChainOfThought(LLMQPredictorSignature)
        
        # 🔥 A-TEAM FIX: LLM-based state-to-natural-language conversion
        # Replaces hardcoded keyword matching with semantic understanding
        # Uses config-driven lightweight model for cost efficiency
        self.state_converter_lm = self._create_state_converter_lm()
        self.state_converter = dspy.ChainOfThought(StateToNaturalLanguageSignature)
        # 🔴 A-TEAM FIX: LLM-based lesson extraction (replaces keyword parsing)
        self.lesson_extractor = dspy.ChainOfThought(LLMLessonExtractionSignature)
        if self.state_converter_lm:
            lm_model = getattr(self.state_converter_lm, 'model', 'configured lightweight model')
            logger.info(f"✅ State converter + lesson extractor will use {lm_model} (cost-efficient)")
        else:
            logger.info("✅ State converter + lesson extractor will use default LM")
        
        # REAL Q-TABLE: (state_desc, action_desc) -> Q-value + context
        self.Q = {}  # Natural language Q-table!
        
        # ===== NEUROCHUNK TIERED MEMORY =====
        # Tier 1: Working Memory (always in context)
        self.tier1_working = []  # Hot path, high Q-value or recent
        self.tier1_max_size = getattr(config, 'tier1_max_size', 50)
        # 🔥 A-TEAM FIX #3: Configurable thresholds (not hardcoded!)
        self.tier1_threshold = getattr(config, 'q_tier1_threshold', 0.8)
        
        # Tier 2: Semantic Clusters (compressed, retrieval-based)
        self.tier2_clusters = {}  # {cluster_id: {'centroid': str, 'members': [keys]}}
        self.tier2_max_clusters = getattr(config, 'tier2_max_clusters', 10)
        
        # Tier 3: Long-term Archive (causal impact pruning)
        self.tier3_archive = []  # Low Q-value but novel/high-variance
        self.tier3_max_size = getattr(config, 'tier3_max_size', 500)
        
        # Adaptive threshold management
        self.last_episode_reward = 0.0
        self.episodes_without_improvement = 0
        
        # Chunker for semantic clustering (lazy-init)
        self._chunker = None
        # ====================================
        
        # Experience buffer for replay
        # 🔬 A-TEAM ENHANCEMENT: Prioritized replay buffer
        self.experience_buffer = []
        self.max_buffer_size = getattr(config, 'max_experience_buffer', 1000)
        self.priority_alpha = getattr(config, 'q_priority_alpha', 0.6)
        self.priority_beta = getattr(config, 'q_priority_beta', 0.4)
        self.priority_epsilon = 0.01  # Small constant to ensure non-zero priority
    
        # Learning parameters
        self.alpha = getattr(config, 'alpha', 0.1)
        self.gamma = getattr(config, 'gamma', 0.99)
        self.epsilon = getattr(config, 'epsilon', 0.1)
        
        # 🔥 A-TEAM: Agentic Tag Index (NO HARDCODED CATEGORIES!)
        # Tags and clusters emerge from data, not predefined
        self.agentic_index = AgenticTagIndex(config)
        logger.info("🏷️ AgenticTagIndex integrated (self-organizing, no hardcoding)")
        
        # ===== N-STEP BACKWARD PROPAGATION: Episode Trajectory Tracking =====
        # 🔴 A-TEAM CRITICAL: When a task fails at step N, we need to propagate
        # that failure signal back to steps 1..N-1 that led to the failure.
        # Without this, the system gives high Q-values to steps that look
        # good locally but lead to failure downstream.
        #
        # Math: For failure at step t with reward r_t:
        #   For each preceding step t-k (k=1..n):
        #     G_k = γ^k * r_t  (discounted failure signal)
        #     ΔQ(s_{t-k}, a_{t-k}) = α_backward * (G_k - Q(s_{t-k}, a_{t-k}))
        #   where α_backward decays with k to reduce impact on distant steps.
        self._episode_trajectory: List[Dict] = []  # Per-episode ordered list
        self._n_step_horizon = getattr(config, 'n_step_backward_horizon', 5)
        self._backward_alpha_decay = getattr(config, 'backward_alpha_decay', 0.7)
        
        # ===== META-LEARNING: Track prediction accuracy =====
        # 🧠 A-TEAM: DQN needs to learn from its own prediction errors!
        # This is how the system improves its Q-predictions over time.
        self.prediction_history = []  # [{predicted_q, actual_reward, error, state_features}]
        self.max_prediction_history = 500
        self.prediction_error_ema = 0.0  # Exponential moving average of errors
        self.prediction_confidence_adjustment = 1.0  # Adjusts confidence based on track record
        self.meta_learning_rate = getattr(config, 'meta_learning_rate', 0.05)
        logger.info("🧠 Meta-learning tracking enabled for Q-prediction improvement")
    
    def _create_state_converter_lm(self):
        """
        Create LM for state converter.
        
        🔴 A-TEAM FIX: Uses config-driven lightweight model (no hardcoded model names).
        Priority order:
        1. Per-internal-agent override from agent_models.yaml (StateConverter)
        2. SynapseConfig.default_lightweight_model
        3. SYNAPSE_STATE_CONVERTER_MODEL env var (legacy support)
        4. Falls back to None (uses globally configured dspy LM)
        """
        try:
            import os
            
            # Priority 0: Per-internal-agent override from YAML
            model_name = None
            try:
                import yaml
                from pathlib import Path
                config_path = Path(__file__).parent.parent / "config" / "agent_models.yaml"
                if config_path.exists():
                    with open(config_path, "r") as f:
                        yaml_cfg = yaml.safe_load(f) or {}
                    internal_cfg = yaml_cfg.get("internal_agents", {})
                    agent_entry = internal_cfg.get("StateConverter", {})
                    if isinstance(agent_entry, dict):
                        model_val = agent_entry.get("model", "lightweight")
                        if model_val == "default":
                            model_name = yaml_cfg.get("default_model")
                        elif model_val == "lightweight":
                            model_name = yaml_cfg.get("default_lightweight_model")
                        elif model_val:
                            model_name = model_val
            except Exception:
                pass
            
            # Priority 1: Config-driven lightweight model
            if not model_name:
                model_name = getattr(self.config, 'default_lightweight_model', None)
            # Priority 2: Legacy env var support
            if not model_name:
                model_name = os.getenv("SYNAPSE_STATE_CONVERTER_MODEL")
            
            if not model_name:
                logger.debug("🏷️  State converter using globally configured dspy LM (no lightweight model in config)")
                return None
            
            api_key = (
                getattr(self.config, 'model_api_key', None)
                or os.getenv("LITELLM_API_KEY")
            )
            api_base = (
                getattr(self.config, 'model_api_base', None)
                or os.getenv("LITELLM_BASE_URL")
            )
            
            kwargs = {"model": model_name}
            if api_key:
                kwargs["api_key"] = api_key
            if api_base:
                kwargs["api_base"] = api_base
            
            state_converter_lm = dspy.LM(**kwargs)
            logger.debug(f"🏷️  State converter LM initialized with {model_name}")
            return state_converter_lm
        except Exception as e:
            logger.warning(f"⚠️  Failed to create state converter LM: {e}, using default")
            return None
    
    def add_experience(self, state: Dict, action: Dict, reward: float, next_state: Dict = None, done: bool = False, divergence_adjusted: bool = False):
        """
        Add experience to buffer AND update Q-table.
        
        This is REAL Q-learning - not just storage!
        
        Args:
            state: Current state (will be converted to natural language description)
            action: Action taken (will be converted to natural language description)
            reward: Reward received
            next_state: Next state (for bootstrapping)
            done: Whether episode terminated
            divergence_adjusted: Whether reward was adjusted by divergence penalty (uses lower failure threshold)
        """
        # Convert to natural language descriptions
        state_desc = self._state_to_natural_language(state)
        action_desc = self._action_to_natural_language(action)
        next_state_desc = self._state_to_natural_language(next_state) if next_state else None
        
        # Add to experience buffer
        experience = {
            'state': state,
            'state_desc': state_desc,
            'action': action,
            'action_desc': action_desc,
            'reward': reward,
            'next_state': next_state,
            'next_state_desc': next_state_desc,
            'done': done,
            'timestamp': time.time()
        }
        # 🔬 A-TEAM: Prioritized Experience Replay
        # Priority = |TD_error| + ε (per GRF MARL paper)
        td_error = abs(reward - self._get_q_value(state_desc, action_desc))
        priority = (td_error + self.priority_epsilon) ** self.priority_alpha
        experience['priority'] = priority
        experience['td_error'] = td_error
        
        self.experience_buffer.append(experience)
        
        # Keep buffer bounded - evict LOW priority experiences (not FIFO)
        if len(self.experience_buffer) > self.max_buffer_size:
            # Sort by priority (ascending) and remove lowest
            self.experience_buffer.sort(key=lambda e: e.get('priority', 0))
            self.experience_buffer.pop(0)
    
        # REAL Q-LEARNING UPDATE
        td_error = self._update_q_value(state_desc, action_desc, reward, next_state_desc, done, divergence_adjusted)
        
        # 🔬 A-TEAM ENHANCEMENT: Comprehensive Q-Learning Logging
        # Log Q-value updates for strategy tracking and failure analysis
        logger.info(
            f"📊 Q-LEARNING UPDATE | "
            f"state={state_desc[:80]}... | "
            f"action={action_desc[:60]}... | "
            f"reward={reward:.3f} | "
            f"td_error={td_error:.3f} | "
            f"strategy={action.get('actor', action.get('tool', 'unknown'))}"
        )
        
        # Track strategy performance
        strategy = action.get('actor', action.get('tool', 'unknown'))
        if not hasattr(self, '_strategy_stats'):
            self._strategy_stats = {}
        if strategy not in self._strategy_stats:
            self._strategy_stats[strategy] = {
                'count': 0,
                'total_reward': 0.0,
                'successes': 0,
                'failures': 0,
                'avg_q_value': 0.5
            }
        
        stats = self._strategy_stats[strategy]
        stats['count'] += 1
        stats['total_reward'] += reward
        # 🔴 A-TEAM FIX: Use config thresholds instead of hardcoded magic numbers
        high_threshold = getattr(self.config, 'q_high_reward_threshold', 0.7)
        low_threshold = getattr(self.config, 'q_low_reward_threshold', 0.3)
        if reward > high_threshold:
            stats['successes'] += 1
        elif reward < low_threshold:
            stats['failures'] += 1
        
        # Update average Q-value for this strategy
        current_q = self._get_q_value_from_table(state_desc, action_desc)
        stats['avg_q_value'] = (stats['avg_q_value'] * (stats['count'] - 1) + current_q) / stats['count']
        
        # Log strategy performance summary periodically
        if stats['count'] % 10 == 0:
            success_rate = stats['successes'] / max(stats['count'], 1)
            avg_reward = stats['total_reward'] / stats['count']
            logger.info(
                f"📈 STRATEGY STATS | "
                f"strategy={strategy} | "
                f"count={stats['count']} | "
                f"success_rate={success_rate:.2%} | "
                f"avg_reward={avg_reward:.3f} | "
                f"avg_q_value={stats['avg_q_value']:.3f}"
            )
        
        # 🏷️ A-TEAM: Update Agentic Tag Index (self-organizing, no hardcoding!)
        try:
            key = (state_desc, action_desc)
            # 🔴 A-TEAM FIX: Use config thresholds
            _high = getattr(self.config, 'q_high_reward_threshold', 0.7)
            _low = getattr(self.config, 'q_low_reward_threshold', 0.3)
            outcome = "success" if reward > _high else "partial" if reward > _low else "failure"
            q_value = current_q  # Pass current Q-value for value-based retrieval
            self.agentic_index.index_entry(key, state_desc, action_desc, outcome, q_value)
        except Exception as e:
            logger.debug(f"Agentic index update failed (non-critical): {e}")
        
        # 🔴 A-TEAM: Track step in episode trajectory for n-step backward propagation
        # When a failure occurs later, we can trace back and correct prior Q-values
        self._episode_trajectory.append({
            'state_desc': state_desc,
            'action_desc': action_desc,
            'reward': reward,
            'q_at_time': current_q,
            'timestamp': time.time()
        })
        
        # If this step is a failure, propagate backward through trajectory
        _failure_thresh = getattr(self.config, 'q_low_reward_threshold', 0.3)
        if reward < _failure_thresh and len(self._episode_trajectory) > 1:
            self._propagate_failure_backward(reward)
    
    def start_new_episode(self):
        """Reset episode trajectory for n-step backward propagation."""
        self._episode_trajectory.clear()
    
    def _propagate_failure_backward(self, failure_reward: float):
        """
        N-step backward Q-value propagation on delayed failure.
        
        🔴 A-TEAM CRITICAL: When a failure is detected at step t, this
        propagates a discounted penalty backward through the preceding
        steps that led to the failure. This corrects Q-values that
        looked optimistic locally but led to downstream failure.
        
        Math:
            For each preceding step t-k (k = 1..n_step_horizon):
                discounted_signal = γ^k * failure_reward
                current_q = Q(s_{t-k}, a_{t-k})
                td_correction = α * (backward_alpha_decay)^k * (discounted_signal - current_q)
                Q(s_{t-k}, a_{t-k}) += td_correction
        
        This ensures:
        - Steps immediately before failure get strongest correction
        - Correction decays exponentially with distance (both γ and α_decay)
        - Only corrects when the discounted failure signal is worse than current Q
        """
        n = min(self._n_step_horizon, len(self._episode_trajectory) - 1)
        if n <= 0:
            return
        
        current_step_idx = len(self._episode_trajectory) - 1
        corrections_made = 0
        
        for k in range(1, n + 1):
            prior_idx = current_step_idx - k
            if prior_idx < 0:
                break
            
            prior_step = self._episode_trajectory[prior_idx]
            state_desc = prior_step['state_desc']
            action_desc = prior_step['action_desc']
            key = (state_desc, action_desc)
            
            if key not in self.Q:
                continue
            
            current_q = self.Q[key]['value']
            
            # Discounted failure signal: how much should this step be blamed?
            discounted_signal = (self.gamma ** k) * failure_reward
            
            # Only correct if the discounted failure signal suggests Q is too high
            if discounted_signal < current_q:
                # α decays with distance (backward_alpha_decay^k)
                effective_alpha = self.alpha * (self._backward_alpha_decay ** k)
                td_correction = effective_alpha * (discounted_signal - current_q)
                
                new_q = max(0.0, min(1.0, current_q + td_correction))
                self.Q[key]['value'] = new_q
                self.Q[key]['last_updated'] = time.time()
                
                # Record the backward correction as a pitfall discovery
                self.Q[key].setdefault('pitfalls_discovered', []).append(
                    f"Downstream failure (reward={failure_reward:.2f}) at step +{k}: "
                    f"Q corrected {current_q:.3f} → {new_q:.3f}"
                )
                # Trim pitfalls to avoid unbounded growth
                if len(self.Q[key]['pitfalls_discovered']) > 20:
                    self.Q[key]['pitfalls_discovered'] = self.Q[key]['pitfalls_discovered'][-20:]
                
                corrections_made += 1
                logger.info(
                    f"⬅️ N-STEP BACKWARD | step=-{k} | "
                    f"state={state_desc[:50]}... | "
                    f"Q: {current_q:.3f} → {new_q:.3f} | "
                    f"γ^k={self.gamma**k:.3f} | "
                    f"α_eff={effective_alpha:.4f}"
                )
        
        if corrections_made > 0:
            logger.info(
                f"⬅️ N-STEP BACKWARD COMPLETE | "
                f"failure_reward={failure_reward:.3f} | "
                f"steps_corrected={corrections_made}/{n}"
            )
    
    def record_outcome(self, state: Dict, action: Any, reward: float, next_state: Dict = None, done: bool = False):
        """Record outcome - alias for add_experience() for backwards compat."""
        action_dict = action if isinstance(action, dict) else {'actor': str(action)}
        self.add_experience(state, action_dict, reward, next_state, done)
    
    # =========================================================================
    # META-LEARNING: LEARNING FROM PREDICTION ERRORS
    # =========================================================================
    
    def record_prediction_outcome(self, state: Dict, action: Dict, predicted_q: float, 
                                   predicted_confidence: float, actual_reward: float):
        """
        Record actual outcome of a Q-prediction for meta-learning.
        
        🧠 A-TEAM CRITICAL: This is how DQN learns from its own prediction errors!
        
        The system tracks:
        1. How accurate Q-predictions are
        2. What features correlate with prediction errors
        3. When to trust or distrust its predictions
        
        Args:
            state: State when prediction was made
            action: Action that was predicted
            predicted_q: What we predicted Q(s,a) would be
            predicted_confidence: How confident we were
            actual_reward: What reward we actually got
        """
        # Calculate prediction error
        error = abs(predicted_q - actual_reward)
        signed_error = actual_reward - predicted_q  # Positive = underestimated, Negative = overestimated
        
        # Extract state features for pattern detection
        state_desc = self._state_to_natural_language(state)
        action_desc = self._action_to_natural_language(action)
        
        # Get tags for this state-action (for pattern analysis)
        tags = list(self.agentic_index.entry_to_tags.get((state_desc, action_desc), set()))
        
        # Record prediction
        prediction_record = {
            'state_desc': smart_truncate(state_desc, max_tokens=125),  # Token-aware truncation
            'action_desc': smart_truncate(action_desc, max_tokens=75),
            'predicted_q': predicted_q,
            'predicted_confidence': predicted_confidence,
            'actual_reward': actual_reward,
            'error': error,
            'signed_error': signed_error,
            'tags': tags,
            'timestamp': time.time()
        }
        
        self.prediction_history.append(prediction_record)
        
        # Keep bounded
        if len(self.prediction_history) > self.max_prediction_history:
            self.prediction_history = self.prediction_history[-self.max_prediction_history:]
        
        # Update exponential moving average of errors
        self.prediction_error_ema = (1 - self.meta_learning_rate) * self.prediction_error_ema + \
                                     self.meta_learning_rate * error
        
        # Adjust confidence based on track record
        # If we're consistently wrong, reduce confidence
        if error > 0.3:  # Significant error
            self.prediction_confidence_adjustment *= 0.95  # Reduce confidence
        elif error < 0.1:  # Good prediction
            self.prediction_confidence_adjustment = min(1.2, self.prediction_confidence_adjustment * 1.02)
        
        # Log meta-learning update
        logger.debug(
            f"🧠 META-LEARNING | error={error:.3f} | signed_error={signed_error:+.3f} | "
            f"ema_error={self.prediction_error_ema:.3f} | conf_adj={self.prediction_confidence_adjustment:.3f}"
        )
        
        # Store gotcha if prediction was badly wrong
        if error > 0.4:
            self._learn_from_prediction_error(prediction_record)
    
    def _learn_from_prediction_error(self, prediction_record: Dict):
        """
        Extract lessons from significant prediction errors.
        
        🧠 A-TEAM: This converts prediction errors into gotchas for future guidance!
        """
        error = prediction_record['error']
        signed_error = prediction_record['signed_error']
        state_desc = prediction_record['state_desc']
        action_desc = prediction_record['action_desc']
        tags = prediction_record['tags']
        
        # Determine error type
        if signed_error > 0:
            # Underestimated - actual reward was higher than predicted
            lesson_type = "UNDERESTIMATE"
            lesson = f"Q-prediction underestimated by {signed_error:.2f}. This state-action performed better than expected."
        else:
            # Overestimated - actual reward was lower than predicted
            lesson_type = "OVERESTIMATE"
            lesson = f"Q-prediction overestimated by {abs(signed_error):.2f}. This state-action performed worse than expected."
        
        # Store as pitfall/lesson in Q-table entry
        key = (state_desc, action_desc)
        if key in self.Q:
            if lesson_type == "OVERESTIMATE":
                # Add as pitfall - we thought this would work but it didn't
                if len(self.Q[key].get('pitfalls_discovered', [])) < 5:
                    self.Q[key].setdefault('pitfalls_discovered', []).append(
                        f"[META-LEARNING] Prediction was overconfident: expected Q={prediction_record['predicted_q']:.2f}, "
                        f"got reward={prediction_record['actual_reward']:.2f}. Be more cautious with this approach."
                    )
            else:
                # Add as positive lesson - this is better than we thought
                if len(self.Q[key].get('learned_lessons', [])) < 10:
                    self.Q[key].setdefault('learned_lessons', []).append(
                        f"[META-LEARNING] This approach was undervalued: expected Q={prediction_record['predicted_q']:.2f}, "
                        f"got reward={prediction_record['actual_reward']:.2f}. Consider using this more."
                    )
        
        # Update tag utility based on prediction accuracy
        for tag in tags:
            if tag in self.agentic_index.tag_utility:
                # Tags associated with bad predictions get penalized
                if error > 0.3:
                    self.agentic_index.tag_utility[tag].false_negative_count += 1
    
    # =========================================================================
    # TRAJECTORY CORRECTION - Recommend TODO changes based on Q-learning
    # =========================================================================
    
    def recommend_trajectory_correction(self, todo_state_summary: str, failed_tasks: List[Dict]) -> Dict:
        """
        Analyze current trajectory and recommend corrections based on Q-learning.
        
        🔥 A-TEAM CRITICAL: This enables automatic recovery from wrong trajectories!
        
        Args:
            todo_state_summary: Current TODO state summary (from MarkovianTODO.get_state_summary())
            failed_tasks: List of failed task dicts [{description, actor, failure_reasons}, ...]
        
        Returns:
            {
                'should_correct': bool,
                'correction_type': 'insert'|'delete'|'reorder'|'retry'|'delegate',
                'specific_actions': [{'action': ..., 'reason': ...}],
                'avoid_actions': [...],
                'confidence': float,
                'reasoning': str
            }
        """
        if not failed_tasks:
            return {'should_correct': False, 'reasoning': 'No failed tasks'}
        
        # Search for similar past situations - FULL CONTEXT
        search_query = f"Failed tasks: {json.dumps(failed_tasks, default=str)}"
        try:
            # Use config default top_k
            similar = self.agentic_index.search(todo_state_summary, search_query)
        except Exception as e:
            logger.debug(f"Index search failed: {e}")
            similar = []
        
        if not similar:
            return {'should_correct': False, 'reasoning': 'No similar past experiences found'}
        
        # Categorize similar experiences
        successes = []
        failures = []
        
        for key, score in similar:
            if key not in self.Q:
                continue
            q_data = self.Q[key]
            entry = {
                'state': key[0],
                'action': key[1],
                'q_value': q_data['value'],
                'strategies': q_data.get('successful_strategies', []),
                'pitfalls': q_data.get('pitfalls_discovered', []),
                'failed_strategies': q_data.get('failed_strategies', []),
                'lessons': q_data.get('learned_lessons', []),
                'relevance': score
            }
            
            if q_data['value'] > 0.6:
                successes.append(entry)
            else:
                failures.append(entry)
        
        if not successes:
            return {
                'should_correct': True,
                'correction_type': 'retry',
                'specific_actions': [],
                'avoid_actions': [p for f in failures for p in f.get('pitfalls', [])],
                'confidence': 0.4,
                'reasoning': 'Found failures but no successes to guide correction'
            }
        
        # Extract recommendations from successes
        best_success = max(successes, key=lambda x: x['q_value'] * x['relevance'])
        
        # 🔥 A-TEAM: Full strategies, use config limits
        specific_actions = []
        for strategy in best_success.get('strategies', [])[:self.idx_config.max_specific_actions]:
            specific_actions.append({
                'action': 'try_strategy',
                'description': strategy,  # Full strategy, no truncation
                'reason': f"Worked in similar situation (Q={best_success['q_value']:.2f})"
            })
        
        # Extract actions to avoid from failures - FULL CONTEXT
        avoid_actions = []
        for failure in failures[:self.idx_config.max_avoid_actions]:
            for pitfall in failure.get('pitfalls', []):
                avoid_actions.append(pitfall)  # Full pitfall
            for failed_strat in failure.get('failed_strategies', []):
                avoid_actions.append(f"AVOID: {failed_strat}")  # Full strategy
        
        # Determine correction type based on patterns
        correction_type = 'insert'  # Default
        if len(failures) > len(successes) * 2:
            correction_type = 'delegate'  # Too many failures, might need different agent
        elif best_success.get('lessons'):
            correction_type = 'retry'  # Has lessons, can retry with knowledge
        
        return {
            'should_correct': True,
            'correction_type': correction_type,
            'specific_actions': specific_actions,
            'avoid_actions': avoid_actions[:self.idx_config.max_avoid_actions],
            'confidence': min(0.9, best_success['relevance'] * best_success['q_value']),
            'reasoning': f"Found {len(successes)} successful similar experiences. "
                        f"Best match has Q={best_success['q_value']:.2f}. "
                        f"Recommending: {correction_type}"
        }
    
    def get_proactive_warnings(self, state: Dict, proposed_action: Dict) -> List[str]:
        """
        Get proactive warnings BEFORE taking an action.
        
        🔥 A-TEAM: Prevent mistakes before they happen!
        
        Returns:
            List of warning strings about potential pitfalls
        """
        warnings = []
        
        state_desc = self._state_to_natural_language(state)
        action_desc = self._action_to_natural_language(proposed_action)
        
        # Check Q-table for this state-action
        key = (state_desc, action_desc)
        if key in self.Q:
            q_data = self.Q[key]
            
            # Warn if historically bad
            if q_data['value'] < 0.3:
                warnings.append(
                    f"⚠️ WARNING: This action has historically poor performance "
                    f"(Q={q_data['value']:.2f}, avg_reward={q_data.get('avg_reward', 0):.2f})"
                )
            
            # Warn about known pitfalls
            for pitfall in q_data.get('pitfalls_discovered', [])[:2]:
                warnings.append(f"⚠️ PITFALL: {pitfall}")
            
            # Warn if high variance (unpredictable)
            if q_data.get('reward_variance', 0) > 0.2:
                warnings.append(
                    f"⚠️ UNPREDICTABLE: This action has high variance "
                    f"(variance={q_data.get('reward_variance', 0):.3f}). Results may vary."
                )
        
        # Check meta-learning for systematic issues
        if self.prediction_error_ema > 0.3:
            warnings.append(
                f"⚠️ META-LEARNING: Recent predictions have been inaccurate "
                f"(EMA error={self.prediction_error_ema:.3f}). Be cautious with Q-estimates."
            )
        
        # Check for defect analysis
        try:
            defect = self.agentic_index.get_defect_analysis(state_desc)
            if defect.get('failure_rate', 0) > 0.4:
                warnings.append(
                    f"⚠️ HIGH RISK: Similar tasks have {defect['failure_rate']:.0%} failure rate. "
                    f"Risky patterns: {', '.join(defect.get('risky_patterns', [])[:3])}"
                )
        except Exception:
            pass  # Defect analysis not available
        
        return warnings
    
    def get_meta_learning_context(self) -> str:
        """
        Get meta-learning context to inject into Q-predictions.
        
        This tells the LLM how accurate its recent predictions have been
        and adjusts its confidence accordingly.
        """
        if not self.prediction_history:
            return ""
        
        recent = self.prediction_history[-20:]  # Last 20 predictions
        
        # Calculate stats
        errors = [p['error'] for p in recent]
        avg_error = sum(errors) / len(errors)
        max_error = max(errors)
        
        # Count under/over estimates
        underestimates = sum(1 for p in recent if p['signed_error'] > 0)
        overestimates = sum(1 for p in recent if p['signed_error'] < 0)
        
        # Build context
        context = f"""## 🧠 META-LEARNING CONTEXT (Your Recent Prediction Accuracy)

**Recent Performance ({len(recent)} predictions):**
- Average prediction error: {avg_error:.3f}
- Max error: {max_error:.3f}
- Underestimates: {underestimates} | Overestimates: {overestimates}
- Confidence adjustment: {self.prediction_confidence_adjustment:.2f}x

"""
        if avg_error > 0.3:
            context += "⚠️ WARNING: Recent predictions have been inaccurate. Be more conservative.\n"
        elif avg_error < 0.15:
            context += "✅ Recent predictions have been accurate. You can be more confident.\n"
        
        if overestimates > underestimates * 2:
            context += "📉 BIAS DETECTED: You tend to OVERESTIMATE. Lower your Q-value predictions.\n"
        elif underestimates > overestimates * 2:
            context += "📈 BIAS DETECTED: You tend to UNDERESTIMATE. Raise your Q-value predictions.\n"
        
        return context
    
    def get_adjusted_confidence(self, raw_confidence: float) -> float:
        """
        Adjust confidence based on meta-learning track record.
        
        If predictions have been inaccurate, reduce confidence.
        If predictions have been accurate, allow higher confidence.
        """
        adjusted = raw_confidence * self.prediction_confidence_adjustment
        return max(0.1, min(0.95, adjusted))  # Clamp to reasonable range
    
    def _state_to_natural_language(self, state: Dict) -> str:
        """
        Convert state dict to RICH natural language description using LLM.
        
        🔥 A-TEAM CRITICAL FIX: Replaced hardcoded keyword matching with LLM-based
        semantic understanding for better generalization across ALL task types!
        
        This enables:
        1. Similar task matching (Q-value transfer across domains)
        2. Error pattern recognition (avoid repeated mistakes)
        3. Metadata-aware learning (files, URLs, tools, actors)
        4. Tool/actor usage patterns (which strategies work for which tasks)
        
        Works for ANY task type:
        - Browser automation, terminal commands, web search
        - API calls, file operations, game playing
        - Database queries, data analysis, and more
        
        Example:
        Instead of: "TODO: 2 completed, 1 pending"
        We get: "QUERY: Perform web action | ACTOR: BrowserExecutor | 
                 DOMAIN: web_automation | TODO: 2✓/0⏳/0✗ | SUCCESS: True"
        """
        if not state:
            return "Initial state (no history)"
        
        # 🔥 A-TEAM FIX: Use LLM for semantic state description
        try:
            # Convert state dict to JSON string for LLM input
            state_json = json.dumps(state, default=str, ensure_ascii=False)
            
            # Use DSPy ChainOfThought to generate natural language description
            # Use custom lightweight LM if available, otherwise use default
            if self.state_converter_lm:
                with dspy.context(lm=self.state_converter_lm):
                    result = self.state_converter(state_dict=state_json)
            else:
                result = self.state_converter(state_dict=state_json)
            
            if result and hasattr(result, 'natural_language_description'):
                description = result.natural_language_description.strip()
                if description and len(description) > 10:  # Valid description
                    logger.debug(f"✅ LLM-generated state description: {description[:100]}...")
                    return description
            
            # Fall through to fallback if LLM output is invalid
            logger.warning("⚠️ LLM state conversion returned invalid output, using fallback")
            
        except Exception as e:
            logger.warning(f"⚠️ LLM state conversion failed: {e}, using fallback")
        
        # ====== FALLBACK: Simple extraction for critical fields ======
        # This ensures we always return something useful even if LLM fails
        parts = []
        
        # Always include query if present
        if 'query' in state:
            query = state['query']
            parts.append(f"QUERY: {query[:100]}")
        
        # Include actor if present
        if 'current_actor' in state:
            parts.append(f"ACTOR: {state['current_actor']}")
        
        # Include task progress if present
        if 'todo' in state:
            todo = state['todo']
            if isinstance(todo, dict):
                pending = todo.get('pending', 0)
                completed = todo.get('completed', 0)
                failed = todo.get('failed', 0)
                parts.append(f"TODO: {completed}✓/{pending}⏳/{failed}✗")
        
        # Include success status if present
        if 'success' in state:
            parts.append(f"SUCCESS: {state['success']}")
        
        # Include errors if present (critical for learning)
        if 'errors' in state:
            errors = state['errors']
            if isinstance(errors, list) and errors:
                error_types = []
                for err in errors[:3]:
                    if isinstance(err, dict):
                        error_types.append(f"{err.get('type','ERR')}:{err.get('column','')}")
                    else:
                        error_types.append(str(err)[:30])
                parts.append(f"ERRORS: [{','.join(error_types)}]")
        
        # Include tables if present
        if 'tables' in state or 'relevant_tables' in state:
            tables = state.get('tables') or state.get('relevant_tables', [])
            if isinstance(tables, list) and tables:
                short_names = [t.split('.')[-1] if '.' in t else t for t in tables[:3]]
                parts.append(f"TABLES: {','.join(short_names)}")
        
        # Fallback: at least return state keys if nothing else
        if not parts:
            state_keys = list(state.keys())[:5]
            return f"STATE_KEYS: {','.join(state_keys)}"
        
        return " | ".join(parts)
    
    def _action_to_natural_language(self, action: Dict) -> str:
        """
        Convert action dict to RICH natural language description.
        
        🔥 A-TEAM CRITICAL FIX: Action must capture SEMANTIC INTENT!
        
        Works generically for ANY action type by extracting available fields:
        - Actor/agent executing the action
        - Task/goal being performed
        - Tools/commands used
        - Files/URLs/tables involved (if applicable)
        - Filters/parameters (if applicable)
        - Operation type (if applicable)
        
        Example:
        Instead of: "Actor: BrowserExecutor; Task: task_1"
        We get: "ACTOR: BrowserExecutor | TASK: Perform web interaction | 
                 TOOL: navigate,click,type | TARGET: web_application"
        """
        if not action:
            return "No action"
        
        parts = []
        
        # ====== 1. ACTOR IDENTITY ======
        if 'actor' in action:
            parts.append(f"ACTOR: {action['actor']}")
        
        # ====== 2. TASK/GOAL ======
        if 'task' in action:
            parts.append(f"TASK: {action['task']}")
        
        if 'goal' in action:
            parts.append(f"GOAL: {action['goal'][:80]}")
        
        # ====== 3. QUERY CONTEXT ======
        if 'query' in action:
            parts.append(f"QUERY: {action['query'][:50]}")
        
        # A-TEAM FIX: Check for any executable content generically
        # Uses action dict keys, not content keyword matching
        executable_keys = ['sql', 'code', 'command', 'script', 'query_string', 'executable']
        if any(key in action for key in executable_keys):
            parts.append("HAS_EXECUTABLE: True")
        
        # ====== 4. TARGET TABLES ======
        if 'tables' in action:
            tables = action['tables']
            if isinstance(tables, list) and tables:
                short_names = [t.split('.')[-1] for t in tables[:2]]
                parts.append(f"TABLES: {','.join(short_names)}")
        
        if 'table' in action:
            parts.append(f"TABLE: {action['table'].split('.')[-1]}")
        
        # ====== 5. COLUMNS/FIELDS ======
        if 'columns' in action:
            cols = action['columns']
            if isinstance(cols, list) and cols:
                parts.append(f"COLS: {','.join(cols[:3])}")
        
        if 'select_columns' in action:
            cols = action['select_columns']
            if isinstance(cols, list):
                parts.append(f"SELECT: {','.join(cols[:3])}")
        
        # ====== 6. FILTERS ======
        if 'filters' in action:
            filters = action['filters']
            if isinstance(filters, dict):
                filter_desc = '+'.join(list(filters.keys())[:3])
                parts.append(f"FILTERS: {filter_desc}")
            elif isinstance(filters, str):
                parts.append(f"FILTER: {filters[:30]}")
        
        # ====== 7. DATE HANDLING (CRITICAL!) ======
        if 'date_column' in action:
            parts.append(f"DATE_COL: {action['date_column']}")
        
        if 'partition_column' in action:
            parts.append(f"PARTITION: {action['partition_column']}")
        
        if 'date_filter' in action:
            parts.append(f"DATE_FILTER: {action['date_filter']}")
        
        # ====== 8. TOOL USAGE ======
        if 'tool' in action:
            parts.append(f"TOOL: {action['tool']}")
        
        if 'tool_args' in action:
            args = action['tool_args']
            if isinstance(args, dict):
                arg_keys = list(args.keys())[:3]
                parts.append(f"ARGS: {','.join(arg_keys)}")
        
        # ====== 9. STRATEGY/APPROACH ======
        if 'strategy' in action:
            parts.append(f"STRATEGY: {action['strategy']}")
        
        if 'approach' in action:
            parts.append(f"APPROACH: {action['approach']}")
        
        # ====== 10. ERROR HANDLING ======
        if 'retry_reason' in action:
            parts.append(f"RETRY: {action['retry_reason'][:30]}")
        
        if 'fallback' in action:
            parts.append(f"FALLBACK: {action['fallback']}")
        
        # ====== 11. PARAMETERS ======
        if 'params' in action:
            params = action['params']
            if isinstance(params, dict) and params:
                # Extract key params only
                key_params = []
                for k, v in list(params.items())[:3]:
                    v_str = str(v)[:20] if len(str(v)) > 20 else str(v)
                    key_params.append(f"{k}={v_str}")
                parts.append(f"PARAMS: {','.join(key_params)}")
        
        # ====== FALLBACK ======
        if not parts:
            action_keys = list(action.keys())[:5]
            return f"ACTION_KEYS: {','.join(action_keys)}"
        
        return " | ".join(parts)
    
    def _update_q_value(self, state_desc: str, action_desc: str, reward: float, 
                        next_state_desc: str = None, done: bool = False, divergence_adjusted: bool = False):
        """
        REAL Q-learning update: Q(s,a) ← Q(s,a) + α[r + γ max_a' Q(s',a') - Q(s,a)]
        
        KEY: State and action are NATURAL LANGUAGE, so LLM can generalize!
        """
        key = (state_desc, action_desc)
        
        # Get current Q-value
        current_q = self._get_q_value_from_table(state_desc, action_desc)
        
        # Get max Q-value for next state (if not terminal)
        if done or not next_state_desc:
            max_next_q = 0.0
        else:
            # Find all actions we've tried from similar states
            # (LLM will generalize based on semantic similarity!)
            max_next_q = self._get_max_next_q(next_state_desc)
        
        # Q-learning update
        target = reward + self.gamma * max_next_q
        td_error = target - current_q
        new_q = current_q + self.alpha * td_error
        
        # Clamp to [0, 1]
        new_q = max(0.0, min(1.0, new_q))
        
        # 🔴 A-TEAM FIX: Use config thresholds for outcome labeling (not hardcoded)
        _high_thresh = getattr(self.config, 'q_high_reward_threshold', 0.7)
        _low_thresh = getattr(self.config, 'q_low_reward_threshold', 0.3)
        
        def _label_outcome(r: float) -> str:
            return 'success' if r > _high_thresh else 'partial' if r > _low_thresh else 'failure'
        
        # Store/update in Q-table with RICH CONTEXT (A-Team enhanced)
        if key not in self.Q:
            self.Q[key] = {
                'value': new_q,
                # 🔥 A-TEAM: Rich context for LLM understanding
                'full_state_narrative': state_desc,  # Complete state description
                'full_action_narrative': action_desc,  # Complete action description
                'execution_history': [],  # List of execution attempts with outcomes
                'pitfalls_discovered': [],  # Specific pitfalls for this state-action
                'successful_strategies': [],  # What worked
                'failed_strategies': [],  # What didn't work
                'learned_lessons': [],  # Natural language lessons
                'reasoning_traces': [],  # Why certain decisions were made
                'visit_count': 1,
                'avg_reward': reward,
                'reward_variance': 0.0,  # Track reward consistency
                'td_errors': [td_error],
                'created_at': time.time(),
                'last_updated': time.time()
            }
            
            # Record first execution
            self.Q[key]['execution_history'].append({
                'timestamp': time.time(),
                'reward': reward,
                'outcome': _label_outcome(reward),
                'td_error': td_error
            })
            
            # Categorize first strategy (using config thresholds)
            if reward > _high_thresh:
                self.Q[key]['successful_strategies'].append(smart_truncate(action_desc, max_tokens=125))
            elif reward < _low_thresh:
                self.Q[key]['failed_strategies'].append(smart_truncate(action_desc, max_tokens=125))
                # Extract pitfall from failure
                self.Q[key]['pitfalls_discovered'].append(
                    f"Action resulted in low reward ({reward:.2f}). Avoid this approach: {smart_truncate(action_desc, max_tokens=50)}"
                )
        else:
            self.Q[key]['value'] = new_q
            self.Q[key]['visit_count'] += 1
            self.Q[key]['last_updated'] = time.time()
            
            # Update reward statistics using Welford's online algorithm
            # Numerically stable and mathematically correct
            n = self.Q[key]['visit_count']
            old_avg = self.Q[key]['avg_reward']
            new_avg = old_avg + (reward - old_avg) / n
            self.Q[key]['avg_reward'] = new_avg
            # Welford's: var_n = var_{n-1} + ((x - old_avg)(x - new_avg) - var_{n-1}) / n
            self.Q[key]['reward_variance'] += (
                (reward - old_avg) * (reward - new_avg) - self.Q[key]['reward_variance']
            ) / n
            
            self.Q[key]['td_errors'].append(td_error)
            
            # Add to execution history (keep last 10)
            self.Q[key]['execution_history'].append({
                'timestamp': time.time(),
                'reward': reward,
                'outcome': _label_outcome(reward),
                'td_error': td_error
            })
            if len(self.Q[key]['execution_history']) > 10:
                self.Q[key]['execution_history'] = self.Q[key]['execution_history'][-10:]
            
            # Categorize strategy (using config thresholds)
            if reward > _high_thresh:
                truncated_desc = smart_truncate(action_desc, max_tokens=125)
                if truncated_desc not in self.Q[key]['successful_strategies']:
                    self.Q[key]['successful_strategies'].append(truncated_desc)
                    if len(self.Q[key]['successful_strategies']) > 5:
                        self.Q[key]['successful_strategies'] = self.Q[key]['successful_strategies'][-5:]
            elif reward < _low_thresh:
                truncated_desc = smart_truncate(action_desc, max_tokens=125)
                if truncated_desc not in self.Q[key]['failed_strategies']:
                    self.Q[key]['failed_strategies'].append(truncated_desc)
                    if len(self.Q[key]['failed_strategies']) > 5:
                        self.Q[key]['failed_strategies'] = self.Q[key]['failed_strategies'][-5:]
                    # Extract pitfall
                    pitfall = f"Attempt #{self.Q[key]['visit_count']}: Low reward ({reward:.2f}). Approach: {smart_truncate(action_desc, max_tokens=40)}"
                    self.Q[key]['pitfalls_discovered'].append(pitfall)
                    if len(self.Q[key]['pitfalls_discovered']) > 10:
                        self.Q[key]['pitfalls_discovered'] = self.Q[key]['pitfalls_discovered'][-10:]
            
            # Keep TD errors bounded
            if len(self.Q[key]['td_errors']) > 20:
                self.Q[key]['td_errors'] = self.Q[key]['td_errors'][-20:]
        
        # Add learned lesson (natural language!)
        lesson = self._extract_lesson(state_desc, action_desc, reward, td_error, divergence_adjusted)
        if lesson:
            self.Q[key]['learned_lessons'].append(lesson)
            # Keep more lessons (15 instead of 5) for richer learning
            if len(self.Q[key]['learned_lessons']) > 15:
                self.Q[key]['learned_lessons'] = self.Q[key]['learned_lessons'][-15:]
        
        # 🔬 A-TEAM ENHANCEMENT: Penalize failed strategies more aggressively
        # If reward is very low (failure), apply additional penalty
        # 🔴 A-TEAM FIX D4: Use config threshold instead of hardcoded 0.2
        _penalty_thresh = getattr(self.config, 'q_low_reward_threshold', 0.3) * 0.67  # ~0.2 by default
        if reward < _penalty_thresh:
            # Apply additional penalty for failures (asymmetric learning)
            penalty_factor = getattr(self.config, 'q_failure_penalty_factor', 1.5)
            penalized_td_error = td_error * penalty_factor
            new_q_penalized = current_q + self.alpha * penalized_td_error
            new_q_penalized = max(0.0, min(1.0, new_q_penalized))
            
            # Only apply penalty if it makes Q-value worse
            if new_q_penalized < new_q:
                self.Q[key]['value'] = new_q_penalized
                logger.warning(
                    f"⚠️ STRATEGY PENALTY | "
                    f"state={state_desc[:60]}... | "
                    f"action={action_desc[:40]}... | "
                    f"reward={reward:.3f} | "
                    f"q_before={current_q:.3f} | "
                    f"q_after={new_q_penalized:.3f} | "
                    f"penalty_applied=True"
                )
        
        return td_error
    
    def _get_q_value(self, state_desc: str, action_desc: str) -> float:
        """Alias for _get_q_value_from_table (for backward compatibility)."""
        return self._get_q_value_from_table(state_desc, action_desc)
    
    def _get_q_value_from_table(self, state_desc: str, action_desc: str) -> float:
        """Get Q-value from table, with semantic fallback."""
        key = (state_desc, action_desc)
        
        if key in self.Q:
            return self.Q[key]['value']
        
        # Check for semantically similar states (simple heuristic)
        # In a more advanced version, use embedding similarity
        for (s, a), q_data in self.Q.items():
            if self._are_similar(state_desc, s) and self._are_similar(action_desc, a):
                # Use Q-value from similar (state, action) pair
                return q_data['value'] * 0.9  # Slight discount for not exact match
        
        return 0.5  # Neutral default for truly novel (state, action)
    
    def _get_max_next_q(self, next_state_desc: str) -> float:
        """Get max Q-value for next state across all actions."""
        max_q = 0.0
        
        for (s, a), q_data in self.Q.items():
            if self._are_similar(next_state_desc, s):
                max_q = max(max_q, q_data['value'])
        
        return max_q if max_q > 0 else 0.5  # Default if no similar states
    
    def _are_similar(self, desc1: str, desc2: str) -> bool:
        """
        Check if two natural language descriptions are similar.
        
        Simple heuristic: shared keywords. 
        Advanced: use embeddings.
        """
        if desc1 == desc2:
            return True
        
        # Keyword overlap
        words1 = set(desc1.lower().split())
        words2 = set(desc2.lower().split())
        
        if not words1 or not words2:
            return False
        
        overlap = len(words1 & words2)
        union = len(words1 | words2)
        
        similarity = overlap / union if union > 0 else 0
        return similarity > 0.5  # >50% word overlap
    
    def _extract_lesson(self, state_desc: str, action_desc: str, reward: float, td_error: float, divergence_adjusted: bool = False) -> Optional[str]:
        """
        Extract ACTIONABLE natural language lesson from experience using LLM.
        
        🔥 A-TEAM FIX: Replaced ALL hardcoded keyword parsing (DOMAIN:, COLS_TRIED:, etc.)
        with LLM-based extraction via LLMLessonExtractionSignature.
        
        The LLM reads the full state/action narrative and generates a specific,
        actionable lesson — no regex, no string splitting, no domain-specific parsing.
        
        Args:
            divergence_adjusted: If True, uses lower failure threshold (0.05) for divergence-penalized rewards
        """
        if abs(td_error) < 0.1:
            return None  # Not significant enough to learn from
        
        try:
            # 🔴 A-TEAM: Use LLM to extract lesson (replaces hardcoded keyword parsing)
            lm_context = dspy.context(lm=self.state_converter_lm) if self.state_converter_lm else nullcontext()
            with lm_context:
                result = self.lesson_extractor(
                    state_description=state_desc,
                    action_description=action_desc,
                    reward=str(reward),
                    td_error=str(td_error)
                )
            
            lesson_text = getattr(result, 'lesson', None)
            if not lesson_text or not str(lesson_text).strip():
                return None
            
            lesson_text = str(lesson_text).strip()
            
            # Add outcome emoji prefix for quick scanning (not hardcoded content — just label)
            failure_threshold = 0.05 if divergence_adjusted else 0.3
            if reward > 0.7:
                return f"✅ {lesson_text}"
            elif reward < failure_threshold:
                return f"❌ {lesson_text}"
            elif td_error > 0.2:
                return f"📈 {lesson_text}"
            elif td_error < -0.2:
                return f"📉 {lesson_text}"
            else:
                return f"💡 {lesson_text}"
                
        except Exception as e:
            logger.debug(f"LLM lesson extraction failed, using condensed fallback: {e}")
            # Minimal fallback — no keyword parsing, just outcome + truncated context
            outcome = "SUCCESS" if reward > 0.7 else "FAILED" if reward < 0.3 else "MIXED"
            return f"{'✅' if reward > 0.7 else '❌' if reward < 0.3 else '💡'} {outcome}: " \
                   f"State: {state_desc[:120]}... Action: {action_desc[:80]}... " \
                   f"(reward={reward:.2f}, td_error={td_error:.2f})"
    
    def _get_similar_experiences(self, state: Dict, action: Dict) -> List[Dict]:
        """Get similar past experiences for few-shot learning."""
        state_desc = self._state_to_natural_language(state)
        action_desc = self._action_to_natural_language(action)
        
        similar = []
        for exp in self.experience_buffer:
            exp_state_desc = exp.get('state_desc', '')
            exp_action_desc = exp.get('action_desc', '')
            
            # Check semantic similarity
            if self._are_similar(state_desc, exp_state_desc) or \
               self._are_similar(action_desc, exp_action_desc):
                similar.append(exp)
        
        return sorted(similar, key=lambda x: x.get('timestamp', 0), reverse=True)[:10]  # Top 10
    
    def predict_q_value(
        self, 
        state: Dict[str, Any], 
        action: Dict[str, Any],
        goal: str = ""
    ) -> Tuple[Optional[float], Optional[float], Optional[str]]:
        """
        Predict Q-value for a state-action pair using LLM reasoning.
        
        🔥 A-TEAM FIX: Now injects meta-learning and learned context!
        
        Returns:
            (q_value, confidence, alternative_suggestion)
        """
        try:
            # Get similar experiences for few-shot learning
            similar_exps = self._get_similar_experiences(state, action)
            
            # Format historical outcomes
            historical = []
            for exp in similar_exps:  # Top 5
                historical.append({
                    'state': str(exp.get('state', {})),
                    'action': str(exp.get('action', {})),
                    'reward': exp.get('reward', 0.0)
                })
            
            # Prepare inputs
            state_desc = str(state)
            action_desc = str(action)
            historical_json = json.dumps(historical, indent=2)
            
            # 🧠 A-TEAM FIX: Inject meta-learning and learned context!
            meta_context = self.get_meta_learning_context()
            learned_context = self.get_learned_context(state, action)
            
            # Build enhanced goal context
            full_goal_context = goal
            if meta_context:
                full_goal_context += f"\n\n{meta_context}"
            if learned_context:
                full_goal_context += f"\n\n{learned_context}"
            
            # Predict using LLM (with enhanced context)
            result = self.predictor(
                state_description=state_desc,
                proposed_action=action_desc,
                historical_outcomes=historical_json,
                goal_context=full_goal_context  # 🔥 ENHANCED with meta-learning!
            )
            
            # Parse outputs
            try:
                q_val = float(result.q_value)
                q_val = max(0.0, min(1.0, q_val))  # Clamp to [0,1]
            except (ValueError, TypeError, AttributeError):
                q_val = 0.5  # Neutral default
            
            try:
                conf = float(result.confidence)
                conf = max(0.0, min(1.0, conf))
            except (ValueError, TypeError, AttributeError):
                conf = 0.5
            
            alt = result.alternative_suggestion if hasattr(result, 'alternative_suggestion') else None
            
            return q_val, conf, alt
            
        except Exception as e:
            # Fallback: use Q-table if available
            state_desc = self._state_to_natural_language(state)
            action_desc = self._action_to_natural_language(action)
            q_from_table = self._get_q_value_from_table(state_desc, action_desc)
            
            if q_from_table != 0.5:  # Found in table
                return q_from_table, 0.5, None
            
            # Last resort: historical average
            if similar_exps:
                avg_reward = sum(exp.get('reward', 0.0) for exp in similar_exps) / len(similar_exps)
                return avg_reward, 0.3, None
            return 0.5, 0.1, None
    
    def get_learned_context(self, state: Dict, action: Dict = None) -> str:
        """
        Get COMPREHENSIVE learned context to inject into prompts.
        
        🔥 A-TEAM ENHANCED: THIS IS HOW LEARNING MANIFESTS IN LLM AGENTS!
        
        Returns RICH natural language context including:
        - Learned lessons from experience
        - Pitfalls to avoid
        - Successful strategies to consider
        - Failed approaches to skip
        - Execution history insights
        - Reward consistency information
        """
        state_desc = self._state_to_natural_language(state)
        action_desc = self._action_to_natural_language(action) if action else ""
        
        # Collect from similar states (A-Team: use semantic similarity)
        lessons = []
        pitfalls = []
        successful_strategies = []
        failed_strategies = []
        execution_insights = []
        
        # 🏷️ A-TEAM: Use Agentic Tag Index for FAST retrieval (O(k) not O(n)!)
        similar_entries = []
        try:
            # Use tag-based search (much faster than brute force)
            # Use config default top_k (10)
            similar_keys = self.agentic_index.search(state_desc, action_desc)
            for key, score in similar_keys:
                if key in self.Q:
                    similar_entries.append((key[0], key[1], self.Q[key]))
        except Exception as e:
            logger.debug(f"Agentic index search failed, using fallback: {e}")
            # Fallback to old O(n) method
            for (s, a), q_data in self.Q.items():
                if self._are_similar(state_desc, s):
                    similar_entries.append((s, a, q_data))
        
        # If action provided, prioritize exact matches
        if action:
            action_desc = self._action_to_natural_language(action)
            key = (state_desc, action_desc)
            if key in self.Q:
                q_data = self.Q[key]
                lessons.extend(q_data.get('learned_lessons', []))
                pitfalls.extend(q_data.get('pitfalls_discovered', []))
                successful_strategies.extend(q_data.get('successful_strategies', []))
                failed_strategies.extend(q_data.get('failed_strategies', []))
                
                # Extract execution insights
                exec_hist = q_data.get('execution_history', [])
                if exec_hist:
                    success_count = sum(1 for e in exec_hist if e['outcome'] == 'success')
                    fail_count = sum(1 for e in exec_hist if e['outcome'] == 'failure')
                    if len(exec_hist) > 0:
                        success_rate = success_count / len(exec_hist)
                        execution_insights.append(
                            f"This state-action pair has {len(exec_hist)} recorded attempts: "
                            f"{success_rate:.0%} success rate ({success_count} successes, {fail_count} failures). "
                            f"Avg reward: {q_data.get('avg_reward', 0.5):.2f}, Reward variance: {q_data.get('reward_variance', 0):.3f}"
                        )
        
        # Also collect from similar states
        for s, a, q_data in similar_entries:
            lessons.extend(q_data.get('learned_lessons', []))
            pitfalls.extend(q_data.get('pitfalls_discovered', []))
            # Include successful strategies from similar states
            if q_data.get('successful_strategies'):
                successful_strategies.extend(q_data.get('successful_strategies', []))
            if q_data.get('failed_strategies'):
                failed_strategies.extend(q_data.get('failed_strategies', []))
        
        # Build RICH context - 🔥 A-TEAM: FULL CONTEXT, NO TRUNCATION!
        context_parts = []
        
        # Section 1: Key Lessons - Use config limit
        if lessons:
            unique_lessons = list(dict.fromkeys(lessons))[:self.agentic_index.idx_config.max_lessons_to_inject]
            context_parts.append("## 📚 LEARNED LESSONS (from similar past experiences):\n")
            for i, lesson in enumerate(unique_lessons, 1):
                context_parts.append(f"{i}. {lesson}\n")  # Full lesson, no truncation
        
        # Section 2: Pitfalls to AVOID - Use config limit
        if pitfalls:
            unique_pitfalls = list(dict.fromkeys(pitfalls))[:self.agentic_index.idx_config.max_pitfalls_to_inject]
            context_parts.append("\n## ⚠️ PITFALLS TO AVOID (failures from similar situations):\n")
            for pitfall in unique_pitfalls:
                context_parts.append(f"- {pitfall}\n")  # Full pitfall, no truncation
        
        # Section 3: What HAS worked before - Use config limit, NO TRUNCATION
        if successful_strategies:
            unique_success = list(dict.fromkeys(successful_strategies))[:self.agentic_index.idx_config.max_strategies_to_inject]
            context_parts.append("\n## ✅ SUCCESSFUL STRATEGIES (approaches that worked):\n")
            for strategy in unique_success:
                context_parts.append(f"- {strategy}\n")  # Full strategy, no truncation!
        
        # Section 4: What did NOT work - Use config limit, NO TRUNCATION
        if failed_strategies:
            unique_fails = list(dict.fromkeys(failed_strategies))[:self.agentic_index.idx_config.max_strategies_to_inject]
            context_parts.append("\n## ❌ FAILED APPROACHES (do NOT repeat):\n")
            for strategy in unique_fails:
                context_parts.append(f"- {strategy}\n")  # Full strategy, no truncation!
        
        # Section 5: Execution insights
        if execution_insights:
            context_parts.append("\n## 📊 EXECUTION STATISTICS:\n")
            for insight in execution_insights:
                context_parts.append(f"{insight}\n")
        
        # Section 6: Q-value guidance
        if action:
            action_desc = self._action_to_natural_language(action)
            q_val = self._get_q_value_from_table(state_desc, action_desc)
            confidence = "high" if q_val > 0.7 else "medium" if q_val > 0.4 else "low"
            context_parts.append(f"\n## 🎯 EXPECTED VALUE: Q(state, action) = {q_val:.3f} (confidence: {confidence})\n")
            
            # Add reasoning about Q-value
            if q_val > 0.7:
                context_parts.append("This state-action combination has historically performed well. Consider proceeding.\n")
            elif q_val < 0.3:
                context_parts.append("WARNING: This state-action combination has poor historical performance. Consider alternatives.\n")
        
        if not context_parts:
            return ""
        
        # Add header
        full_context = "# 🧠 Q-LEARNING CONTEXT (Learned from Experience)\n"
        full_context += "Use this as GUIDANCE, not rules. Final decision is yours.\n\n"
        full_context += "".join(context_parts)
        
        return full_context
    
    def get_best_action(self, state: Dict, available_actions: List[Dict]) -> Tuple[Dict, float, str]:
        """
        Choose best action for given state using learned Q-values.
        
        Returns: (best_action, q_value, reasoning)
        """
        if not available_actions:
            return None, 0.5, "No actions available"
        
        state_desc = self._state_to_natural_language(state)
        
        # Get Q-values for all actions
        action_values = []
        for action in available_actions:
            action_desc = self._action_to_natural_language(action)
            q_val = self._get_q_value_from_table(state_desc, action_desc)
            action_values.append((action, q_val, action_desc))
        
        # Epsilon-greedy
        import random
        if random.random() < self.epsilon:
            # Explore
            chosen = random.choice(action_values)
            reasoning = f"Exploring (ε={self.epsilon}): Trying {chosen[2][:100]}..."
        else:
            # Exploit: choose best
            chosen = max(action_values, key=lambda x: x[1])
            reasoning = f"Exploiting: Best Q-value = {chosen[1]:.3f} for {chosen[2][:100]}..."
        
        return chosen[0], chosen[1], reasoning
    
    def experience_replay(self, batch_size: int = 32) -> int:
        """
        Experience replay: re-learn from past experiences.
        
        This improves sample efficiency (key RL technique).
        
        Returns: number of updates performed
        """
        if len(self.experience_buffer) < batch_size:
            return 0
        
        # 🔬 A-TEAM: Prioritized sampling (per GRF MARL paper)
        # Sample proportional to priority
        import random
        priorities = [e.get('priority', 1.0) for e in self.experience_buffer]
        total_priority = sum(priorities)
        
        if total_priority > 0:
            # Weighted sampling
            probs = [p / total_priority for p in priorities]
            indices = random.choices(
                range(len(self.experience_buffer)),
                weights=probs,
                k=min(batch_size, len(self.experience_buffer))
            )
            batch = [self.experience_buffer[i] for i in indices]
        else:
            batch = random.sample(self.experience_buffer, min(batch_size, len(self.experience_buffer)))
        
        updates = 0
        for exp in batch:
            self._update_q_value(
                exp['state_desc'],
                exp['action_desc'],
                exp['reward'],
                exp.get('next_state_desc'),
                exp.get('done', False)
            )
            updates += 1
        
        return updates
    
    def get_q_table_summary(self) -> Dict[str, Any]:
        """Get summary statistics of Q-table for debugging/monitoring."""
        if not self.Q:
            return {
                'size': 0,
                'avg_value': 0.0,
                'max_value': 0.0,
                'min_value': 0.0,
                'total_visits': 0
            }
        
        values = [q_data['value'] for q_data in self.Q.values()]
        visits = [q_data['visit_count'] for q_data in self.Q.values()]
        
        return {
            'size': len(self.Q),
            'avg_value': sum(values) / len(values),
            'max_value': max(values),
            'min_value': min(values),
            'total_visits': sum(visits),
            'avg_visits_per_entry': sum(visits) / len(visits),
            'total_lessons': sum(len(q_data.get('learned_lessons', [])) for q_data in self.Q.values()),
            # NeuroChunk stats
            'tier1_size': len(self.tier1_working),
            'tier2_clusters': len(self.tier2_clusters),
            'tier3_size': len(self.tier3_archive),
            'tier1_threshold': self.tier1_threshold
        }
    
    # ===== NEUROCHUNK TIERED MEMORY MANAGEMENT =====
    
    @property
    def chunker(self):
        """Lazy-init chunker to avoid circular imports."""
        if self._chunker is None:
            try:
                from .agentic_chunker import AgenticChunker
                lm = getattr(self.config, 'lm', None) or dspy.settings.lm
                self._chunker = AgenticChunker(lm=lm)
            except Exception as e:
                # Fallback: no chunking
                self._chunker = None
        return self._chunker
    
    def _compute_retention_score(self, key: Tuple[str, str]) -> float:
        """
        Compute multi-criteria retention score for a Q-table entry.
        
        Score = α·Q-value + β·novelty + γ·causal_impact - δ·staleness
        
        Where:
        - α, β, γ, δ are learnable weights (currently fixed, but can be meta-learned)
        - Q-value: Expected reward
        - Novelty: Inverse visit count (rare states = high novelty)
        - Causal impact: Average absolute TD error (high = impactful)
        - Staleness: Time since last access
        
        Returns: float in [0, 1]
        """
        if key not in self.Q:
            return 0.0
        
        q_data = self.Q[key]
        
        # Q-value component (0-1, normalized)
        q_value = q_data['value']
        
        # Novelty component (inverse visit count, normalized)
        visit_count = q_data['visit_count']
        novelty = 1.0 / (1.0 + visit_count)  # High novelty = low visits
        
        # Causal impact component (average absolute TD error)
        td_errors = q_data.get('td_errors', [])
        causal_impact = sum(abs(e) for e in td_errors) / len(td_errors) if td_errors else 0.0
        causal_impact = min(1.0, causal_impact)  # Clamp to [0, 1]
        
        # Staleness component (time since last update)
        last_updated = q_data.get('last_updated', time.time())
        staleness = min(1.0, (time.time() - last_updated) / 3600.0)  # 1 hour = max staleness
        
        # Weighted combination (weights from neuroscience literature, but adaptable)
        alpha = 0.4  # Q-value weight (reward salience)
        beta = 0.3   # Novelty weight (rare = important)
        gamma = 0.2  # Causal impact weight (influence on future)
        delta = 0.1  # Staleness penalty
        
        score = alpha * q_value + beta * novelty + gamma * causal_impact - delta * staleness
        
        # Clamp to [0, 1]
        return max(0.0, min(1.0, score))
    
    def _promote_demote_memories(self, episode_reward: float = None):
        """
        Move memories between tiers based on retention scores.
        
        Tier 1: High-value, recently accessed (always in context)
        Tier 2: Medium-value, semantically clustered (retrieval-based)
        Tier 3: Low-value, archived (pruned periodically)
        
        This is called after each episode to reorganize memory.
        """
        if not self.Q:
            return
        
        # Adaptive threshold adjustment
        if episode_reward is not None:
            if episode_reward > self.last_episode_reward:
                # Policy improved - current threshold is good
                self.episodes_without_improvement = 0
            else:
                # Policy plateaued - might need to explore more
                self.episodes_without_improvement += 1
                
                # Promote archived memories if stuck
                if self.episodes_without_improvement >= 10:
                    self._promote_from_archive(top_k=5)
                    self.episodes_without_improvement = 0
            
            self.last_episode_reward = episode_reward
        
        # Compute retention scores for all memories
        scored_memories = []
        for key in self.Q.keys():
            score = self._compute_retention_score(key)
            scored_memories.append((key, score))
        
        # Sort by score (descending)
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        
        # Tier 1: Top N (working memory)
        self.tier1_working = [key for key, score in scored_memories[:self.tier1_max_size]]
        
        # Tier 2: Next M (semantic clusters)
        tier2_candidates = [key for key, score in scored_memories[self.tier1_max_size:self.tier1_max_size + 100]]
        if tier2_candidates and self.chunker:
            self._cluster_tier2(tier2_candidates)
        
        # Tier 3: Rest (archive)
        self.tier3_archive = [key for key, score in scored_memories[self.tier1_max_size + 100:]]
        
        # Adaptive threshold: If Tier 1 overflows, tighten
        if len(self.tier1_working) >= self.tier1_max_size:
            self.tier1_threshold = min(0.95, self.tier1_threshold * 1.05)
    
    def _cluster_tier2(self, keys: List[Tuple[str, str]]):
        """
        Cluster Tier 2 memories by semantic similarity using AgenticChunker.
        
        This enables efficient retrieval: when state matches cluster centroid,
        retrieve all members of that cluster.
        """
        if not self.chunker or not keys:
            return
        
        # Format memories as text chunks for clustering
        memory_texts = []
        for key in keys:
            state_desc, action_desc = key
            memory_texts.append(f"State: {state_desc}\nAction: {action_desc}")
        
        try:
            # Use AgenticChunker to find semantic clusters
            # (Simplified: In reality, we'd use chunker's semantic grouping)
            # For now, simple keyword-based clustering
            
            clusters = {}
            for i, key in enumerate(keys):
                state_desc, action_desc = key
                
                # Extract key concepts for clustering (simple heuristic)
                concepts = self._extract_concepts(state_desc + " " + action_desc)
                cluster_id = "_".join(concepts[:2])  # Use first 2 concepts as cluster ID
                
                if cluster_id not in clusters:
                    clusters[cluster_id] = {
                        'centroid': " ".join(concepts),
                        'members': []
                    }
                
                clusters[cluster_id]['members'].append(key)
            
            # Keep only top N clusters
            self.tier2_clusters = dict(list(clusters.items())[:self.tier2_max_clusters])
            
        except Exception as e:
            # Fallback: no clustering
            pass
    
    def _extract_concepts(self, text: str) -> List[str]:
        """Extract key concepts from text (simple keyword extraction)."""
        # Remove common words
        stopwords = {'the', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'but'}
        words = text.lower().split()
        concepts = [w for w in words if len(w) > 3 and w not in stopwords]
        return concepts[:5]  # Top 5 concepts
    
    def _retrieve_relevant_cluster(self, state_desc: str) -> List[Tuple[str, str]]:
        """
        Retrieve relevant cluster based on state similarity.
        
        Returns: List of (state_desc, action_desc) keys from the matched cluster.
        """
        if not self.tier2_clusters:
            return []
        
        # Find cluster with highest similarity to current state
        best_cluster = None
        best_similarity = 0.0
        
        for cluster_id, cluster_data in self.tier2_clusters.items():
            centroid = cluster_data['centroid']
            similarity = self._compute_similarity(state_desc, centroid)
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_cluster = cluster_data
        
        # Return members if similarity > threshold
        if best_similarity > 0.7 and best_cluster:
            return best_cluster['members']
        
        return []
    
    def _compute_similarity(self, text1: str, text2: str) -> float:
        """Compute semantic similarity (simple cosine of word sets)."""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        overlap = len(words1 & words2)
        union = len(words1 | words2)
        
        return overlap / union if union > 0 else 0.0
    
    def _promote_from_archive(self, top_k: int = 5):
        """
        Promote top-K memories from Tier 3 to Tier 2.
        
        Called when policy plateaus (exploration mechanism).
        """
        if not self.tier3_archive:
            return
        
        # Score archived memories by novelty (rare = explore)
        scored = []
        for key in self.tier3_archive:
            if key in self.Q:
                visit_count = self.Q[key]['visit_count']
                novelty = 1.0 / (1.0 + visit_count)
                scored.append((key, novelty))
        
        # Promote top-K novel memories
        scored.sort(key=lambda x: x[1], reverse=True)
        promoted = [key for key, _ in scored[:top_k]]
        
        # Remove from archive, add to Tier 2
        for key in promoted:
            self.tier3_archive.remove(key)
            # They'll be re-clustered in next _cluster_tier2 call
    
    def prune_tier3_by_causal_impact(self, sample_rate: float = 0.1):
        """
        Prune Tier 3 using causal impact scoring.
        
        Causal Impact = E[Q_with_memory] - E[Q_without_memory]
        
        We sample 10% of Tier 3, compute their causal impact, and extrapolate.
        
        Args:
            sample_rate: Fraction of Tier 3 to sample (default 0.1 = 10%)
        """
        if not self.tier3_archive:
            return
        
        # Sample memories for causal impact assessment
        sample_size = max(1, int(len(self.tier3_archive) * sample_rate))
        sampled = random.sample(self.tier3_archive, min(sample_size, len(self.tier3_archive)))
        
        # Compute causal impact for sampled memories
        low_impact_keys = []
        for key in sampled:
            if key not in self.Q:
                continue
            
            q_data = self.Q[key]
            
            # Proxy for causal impact: average absolute TD error
            # High TD error = high impact on learning
            td_errors = q_data.get('td_errors', [])
            avg_td_error = sum(abs(e) for e in td_errors) / len(td_errors) if td_errors else 0.0
            
            # Also consider visit count (very low = not useful)
            visit_count = q_data['visit_count']
            
            # Low impact = low TD error AND low visits AND low Q-value
            if avg_td_error < 0.05 and visit_count <= 1 and q_data['value'] < 0.4:
                low_impact_keys.append(key)
        
        # Prune low-impact memories from Tier 3 AND Q-table
        for key in low_impact_keys:
            if key in self.tier3_archive:
                self.tier3_archive.remove(key)
            if key in self.Q:
                del self.Q[key]
    
    def get_context_for_state(self, state: Dict, max_tokens: int = 2000) -> str:
        """
        Get tiered context for a given state.
        
        Tier 1: Always included (working memory)
        Tier 2: Retrieve relevant cluster if state matches
        
        This is the KEY method that enables O(1) context size!
        
        Args:
            state: Current state dict
            max_tokens: Maximum context size (soft limit)
        
        Returns: Natural language context string
        """
        state_desc = self._state_to_natural_language(state)
        
        context_parts = []
        
        # === TIER 1: WORKING MEMORY (always include) ===
        if self.tier1_working:
            context_parts.append("# Working Memory (High-Value Recent):")
            for i, key in enumerate(self.tier1_working[:20], 1):  # Top 20
                if key not in self.Q:
                    continue
                state_d, action_d = key
                q_data = self.Q[key]
                q_val = q_data['value']
                visits = q_data['visit_count']
                
                # Truncate for readability
                state_short = state_d[:80] + "..." if len(state_d) > 80 else state_d
                action_short = action_d[:80] + "..." if len(action_d) > 80 else action_d
                
                context_parts.append(f"{i}. [{state_short}] → [{action_short}] | Q={q_val:.2f} (n={visits})")
        
        # === TIER 2: RETRIEVE RELEVANT CLUSTER ===
        relevant_cluster = self._retrieve_relevant_cluster(state_desc)
        if relevant_cluster:
            context_parts.append("\n# Retrieved Relevant Context (Semantic Match):")
            for i, key in enumerate(relevant_cluster[:10], 1):  # Top 10 from cluster
                if key not in self.Q:
                    continue
                state_d, action_d = key
                q_data = self.Q[key]
                q_val = q_data['value']
                
                state_short = state_d[:60] + "..." if len(state_d) > 60 else state_d
                action_short = action_d[:60] + "..." if len(action_d) > 60 else action_d
                
                context_parts.append(f"{i}. [{state_short}] → [{action_short}] | Q={q_val:.2f}")
        
        # === LEARNED LESSONS (from Tier 1 + retrieved) ===
        all_keys = self.tier1_working + relevant_cluster
        all_lessons = []
        for key in all_keys[:30]:  # Limit to prevent explosion
            if key in self.Q:
                all_lessons.extend(self.Q[key].get('learned_lessons', []))
        
        if all_lessons:
            unique_lessons = list(dict.fromkeys(all_lessons))[:10]  # Top 10 unique
            context_parts.append("\n# Learned Lessons:")
            for i, lesson in enumerate(unique_lessons, 1):
                context_parts.append(f"{i}. {lesson}")
        
        # Join and truncate if needed
        full_context = "\n".join(context_parts)
        
        # Simple token estimation (4 chars ≈ 1 token)
        estimated_tokens = len(full_context) // 4
        if estimated_tokens > max_tokens:
            # Truncate to fit
            target_chars = max_tokens * 4
            full_context = full_context[:target_chars] + "\n... (truncated for context window)"
        
        return full_context
    
    # ===== PERSISTENCE METHODS =====
    
    def save_state(self, path: str):
        """
        Save ALL Q-learning state to ONE file for persistence.
        
        🧠 A-TEAM CRITICAL: 
        - ONE FILE ONLY - no separate files for tag index
        - All state in one JSON for atomic save/load
        - Meta-learning state included
        
        Saves:
        - Q-table (natural language state-action values)
        - Experience buffer (for replay)
        - Tiered memories (NeuroChunk)
        - Agentic Tag Index (EMBEDDED, not separate file)
        - Meta-learning state (prediction history, confidence)
        """
        import json
        from pathlib import Path
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        # Convert Q-table: tuple keys → string keys
        q_table_serializable = {}
        for key, value in self.Q.items():
            key_str = f"{key[0]}|||{key[1]}" if isinstance(key, tuple) else str(key)
            q_table_serializable[key_str] = value
        
        # Build complete state (ONE FILE)
        state = {
            'version': '2.0.0',  # Consolidated format version
            'schema': 'llm_q_predictor_unified_v2',
            
            # Core Q-table
            'q_table': q_table_serializable,
            'experience_buffer': self.experience_buffer[-self.max_buffer_size:],
            
            # NeuroChunk tiers
            'tier1_working': [
                f"{k[0]}|||{k[1]}" if isinstance(k, tuple) else str(k)
                for k in self.tier1_working
            ],
            'tier2_clusters': {
                cid: {
                    'centroid': c['centroid'],
                    'members': [
                        f"{k[0]}|||{k[1]}" if isinstance(k, tuple) else str(k)
                        for k in c['members']
                    ]
                }
                for cid, c in self.tier2_clusters.items()
            },
            'tier3_archive': [
                f"{k[0]}|||{k[1]}" if isinstance(k, tuple) else str(k)
                for k in self.tier3_archive
            ],
            
            # Learning parameters
            'tier1_threshold': self.tier1_threshold,
            'last_episode_reward': self.last_episode_reward,
            'alpha': self.alpha,
            'gamma': self.gamma,
            'epsilon': self.epsilon,
            
            # 🧠 META-LEARNING STATE (NEW)
            'meta_learning': {
                'prediction_history': self.prediction_history[-100:],  # Keep last 100
                'prediction_error_ema': self.prediction_error_ema,
                'prediction_confidence_adjustment': self.prediction_confidence_adjustment
            },
            
            # 🏷️ AGENTIC TAG INDEX (EMBEDDED - NOT SEPARATE FILE)
            'agentic_tag_index': self._serialize_agentic_index(),
            
            # Strategy stats
            'strategy_stats': getattr(self, '_strategy_stats', {}),
            
            # Save timestamp
            'saved_at': time.time()
        }
        
        with open(path, 'w') as f:
            json.dump(state, f, indent=2, default=str)
        
        logger.info(f"✅ Q-learning state saved (UNIFIED): {len(self.Q)} Q-entries, "
                    f"{len(self.experience_buffer)} experiences, "
                    f"{len(self.agentic_index.tag_stats)} tags, "
                    f"{len(self.agentic_index.clusters)} clusters, "
                    f"meta-learning={len(self.prediction_history)} predictions")
    
    def _serialize_agentic_index(self) -> Dict:
        """Serialize agentic tag index for embedding in main state file."""
        return {
            'version': self.agentic_index.VERSION,
            'tag_to_entries': {
                tag: [f"{k[0]}|||{k[1]}" for k in entries]
                for tag, entries in self.agentic_index.tag_to_entries.items()
            },
            'entry_to_tags': {
                f"{k[0]}|||{k[1]}": list(tags)
                for k, tags in self.agentic_index.entry_to_tags.items()
            },
            'tag_stats': {
                tag: stats.to_dict() 
                for tag, stats in self.agentic_index.tag_stats.items()
            },
            'tag_utility': {
                tag: util.to_dict()
                for tag, util in self.agentic_index.tag_utility.items()
            },
            'clusters': {
                cid: cluster.to_dict()
                for cid, cluster in self.agentic_index.clusters.items()
            },
            'entry_to_cluster': {
                f"{k[0]}|||{k[1]}": cid
                for k, cid in self.agentic_index.entry_to_cluster.items()
            },
            'entry_timestamps': {
                f"{k[0]}|||{k[1]}": ts
                for k, ts in self.agentic_index.entry_timestamps.items()
            },
            'entry_q_values': {
                f"{k[0]}|||{k[1]}": val
                for k, val in self.agentic_index.entry_q_values.items()
            },
            'total_indexed_entries': self.agentic_index.total_indexed_entries,
            'total_searches_performed': self.agentic_index.total_searches_performed,
            'search_hit_count': self.agentic_index.search_hit_count,
            'search_miss_count': self.agentic_index.search_miss_count
        }
    
    def load_state(self, path: str) -> bool:
        """
        Load ALL Q-learning state from ONE file.
        
        🧠 A-TEAM CRITICAL:
        - ONE FILE ONLY - everything in one place
        - Backward compatible with old format (separate files)
        - Meta-learning state restored
        
        Returns: True if loaded successfully, False otherwise
        """
        import json
        from pathlib import Path
        
        if not Path(path).exists():
            logger.info(f"ℹ️ No previous Q-learning state at {path}")
            return False
        
        try:
            with open(path, 'r') as f:
                state = json.load(f)
            
            # Check version for migration
            version = state.get('version', '1.0.0')
            
            # Restore Q-table: string keys → tuple keys
            self.Q = {}
            for key_str, value in state.get('q_table', {}).items():
                if '|||' in key_str:
                    parts = key_str.split('|||', 1)
                    key = (parts[0], parts[1])
                else:
                    key = (key_str, '')
                self.Q[key] = value
            
            # Restore experience buffer
            self.experience_buffer = state.get('experience_buffer', [])
            
            # Restore NeuroChunk tiers
            self.tier1_working = [
                tuple(k.split('|||', 1)) if '|||' in k else (k, '')
                for k in state.get('tier1_working', [])
            ]
            
            self.tier2_clusters = {}
            for cid, c in state.get('tier2_clusters', {}).items():
                self.tier2_clusters[cid] = {
                    'centroid': c['centroid'],
                    'members': [
                        tuple(k.split('|||', 1)) if '|||' in k else (k, '')
                        for k in c['members']
                    ]
                }
            
            self.tier3_archive = [
                tuple(k.split('|||', 1)) if '|||' in k else (k, '')
                for k in state.get('tier3_archive', [])
            ]
            
            # Restore learning parameters
            self.tier1_threshold = state.get('tier1_threshold', 0.8)
            self.last_episode_reward = state.get('last_episode_reward', 0.0)
            self.alpha = state.get('alpha', self.alpha)
            self.gamma = state.get('gamma', self.gamma)
            self.epsilon = state.get('epsilon', self.epsilon)
            
            # 🧠 RESTORE META-LEARNING STATE (NEW in v2.0.0)
            meta_state = state.get('meta_learning', {})
            self.prediction_history = meta_state.get('prediction_history', [])
            self.prediction_error_ema = meta_state.get('prediction_error_ema', 0.0)
            self.prediction_confidence_adjustment = meta_state.get('prediction_confidence_adjustment', 1.0)
            
            # Restore strategy stats
            self._strategy_stats = state.get('strategy_stats', {})
            
            # 🏷️ RESTORE AGENTIC TAG INDEX
            if 'agentic_tag_index' in state:
                # New unified format - embedded in main file
                self._deserialize_agentic_index(state['agentic_tag_index'])
            else:
                # Old format - try loading from separate file (backward compat)
                try:
                    index_path = str(Path(path).parent / "agentic_tag_index.json")
                    self.agentic_index.load_state(index_path)
                    logger.info("ℹ️ Loaded agentic index from legacy separate file")
                except Exception:
                    logger.info("ℹ️ No agentic index to load (starting fresh)")
            
            logger.info(f"✅ Q-learning state loaded (UNIFIED v{version}): "
                        f"{len(self.Q)} Q-entries, {len(self.experience_buffer)} experiences, "
                        f"{len(self.agentic_index.tag_stats)} tags, "
                        f"{len(self.agentic_index.clusters)} clusters, "
                        f"meta-learning={len(self.prediction_history)} predictions")
            return True
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to load Q-learning state: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            return False
    
    def _deserialize_agentic_index(self, index_state: Dict):
        """Deserialize agentic tag index from embedded state."""
        try:
            # Restore tag_to_entries
            self.agentic_index.tag_to_entries = {}
            for tag, entries in index_state.get('tag_to_entries', {}).items():
                self.agentic_index.tag_to_entries[tag] = set()
                for entry_str in entries:
                    if '|||' in entry_str:
                        parts = entry_str.split('|||', 1)
                        self.agentic_index.tag_to_entries[tag].add((parts[0], parts[1]))
            
            # Restore entry_to_tags
            self.agentic_index.entry_to_tags = {}
            for entry_str, tags in index_state.get('entry_to_tags', {}).items():
                if '|||' in entry_str:
                    parts = entry_str.split('|||', 1)
                    key = (parts[0], parts[1])
                    self.agentic_index.entry_to_tags[key] = set(tags)
            
            # Restore tag_stats
            self.agentic_index.tag_stats = {}
            for tag, stats_dict in index_state.get('tag_stats', {}).items():
                self.agentic_index.tag_stats[tag] = TagStats.from_dict(stats_dict)
            
            # Restore tag_utility
            self.agentic_index.tag_utility = {}
            for tag, util_dict in index_state.get('tag_utility', {}).items():
                self.agentic_index.tag_utility[tag] = TagUtility.from_dict(util_dict)
            
            # Restore clusters
            self.agentic_index.clusters = {}
            for cid, cluster_dict in index_state.get('clusters', {}).items():
                self.agentic_index.clusters[cid] = AgenticCluster.from_dict(cluster_dict)
            
            # Restore entry_to_cluster
            self.agentic_index.entry_to_cluster = {}
            for entry_str, cid in index_state.get('entry_to_cluster', {}).items():
                if '|||' in entry_str:
                    parts = entry_str.split('|||', 1)
                    self.agentic_index.entry_to_cluster[(parts[0], parts[1])] = cid
            
            # Restore timestamps
            self.agentic_index.entry_timestamps = {}
            for entry_str, ts in index_state.get('entry_timestamps', {}).items():
                if '|||' in entry_str:
                    parts = entry_str.split('|||', 1)
                    self.agentic_index.entry_timestamps[(parts[0], parts[1])] = ts
            
            # Restore q_values
            self.agentic_index.entry_q_values = {}
            for entry_str, val in index_state.get('entry_q_values', {}).items():
                if '|||' in entry_str:
                    parts = entry_str.split('|||', 1)
                    self.agentic_index.entry_q_values[(parts[0], parts[1])] = val
            
            # Restore counters
            self.agentic_index.total_indexed_entries = index_state.get('total_indexed_entries', 0)
            self.agentic_index.total_searches_performed = index_state.get('total_searches_performed', 0)
            self.agentic_index.search_hit_count = index_state.get('search_hit_count', 0)
            self.agentic_index.search_miss_count = index_state.get('search_miss_count', 0)
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to deserialize agentic index (will start fresh): {e}")
    
    # ===== END NEUROCHUNK METHODS ====


# =============================================================================
# ASYNC Q-LEARNING UPDATER - Parallel Execution Without Blocking
# =============================================================================

class AsyncQLearningUpdater:
    """
    Background Q-learning updates without blocking main execution loop.
    
    🔥 A-TEAM CRITICAL: Enables parallel LLM calls and non-blocking updates!
    
    DESIGN:
    - Main loop queues updates (fire-and-forget)
    - Background task processes queue asynchronously
    - LLM calls batched where possible
    - Never blocks the main execution path
    
    USAGE:
        async_updater = AsyncQLearningUpdater(q_predictor)
        await async_updater.start()
        
        # In main loop (doesn't block!):
        await async_updater.queue_experience(state, action, reward)
        
        # When done:
        await async_updater.stop()
    """
    
    def __init__(self, q_predictor: LLMQPredictor, max_queue_size: int = 1000):
        self.q_predictor = q_predictor
        self.update_queue = None  # Will be asyncio.Queue
        self.max_queue_size = max_queue_size
        self._running = False
        self._task = None
        self._batch_size = 10  # Process in batches for efficiency
        self._batch_interval = 0.5  # Seconds between batch processing
        
        # Statistics
        self.updates_queued = 0
        self.updates_processed = 0
        self.batch_count = 0
        
        logger.info(f"🔄 AsyncQLearningUpdater initialized (batch_size={self._batch_size})")
    
    async def start(self):
        """Start background processing."""
        import asyncio
        self.update_queue = asyncio.Queue(maxsize=self.max_queue_size)
        self._running = True
        self._task = asyncio.create_task(self._process_loop())
        logger.info("🚀 AsyncQLearningUpdater started - background processing enabled")
    
    async def stop(self, drain: bool = True):
        """
        Stop background processing.
        
        Args:
            drain: If True, process remaining queue before stopping
        """
        self._running = False
        
        if drain and self.update_queue and not self.update_queue.empty():
            logger.info(f"⏳ Draining {self.update_queue.qsize()} queued updates...")
            await self._process_batch(drain_all=True)
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        
        logger.info(f"🛑 AsyncQLearningUpdater stopped | "
                   f"queued={self.updates_queued} | processed={self.updates_processed}")
    
    async def _process_loop(self):
        """Main processing loop - runs in background."""
        import asyncio
        
        while self._running:
            try:
                # Wait for batch interval or until queue has enough items
                await asyncio.sleep(self._batch_interval)
                
                if not self.update_queue.empty():
                    await self._process_batch()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"⚠️ Async updater error: {e}")
                continue
    
    async def _process_batch(self, drain_all: bool = False):
        """Process a batch of updates."""
        import asyncio
        
        batch = []
        max_items = self.update_queue.qsize() if drain_all else self._batch_size
        
        while len(batch) < max_items:
            try:
                item = self.update_queue.get_nowait()
                batch.append(item)
            except asyncio.QueueEmpty:
                break
        
        if not batch:
            return
        
        self.batch_count += 1
        
        # Group by update type for efficient processing
        experiences = [u for u in batch if u['type'] == 'experience']
        predictions = [u for u in batch if u['type'] == 'prediction_outcome']
        saves = [u for u in batch if u['type'] == 'save']
        
        # Process experiences (can be parallelized)
        if experiences:
            await self._process_experiences_parallel(experiences)
        
        # Process prediction outcomes
        for pred in predictions:
            try:
                self.q_predictor.record_prediction_outcome(**pred['data'])
                self.updates_processed += 1
            except Exception as e:
                logger.debug(f"Prediction outcome processing failed: {e}")
        
        # Process saves (only do one save per batch)
        if saves:
            try:
                # Use the most recent save request
                self.q_predictor.save_state(saves[-1]['path'])
                self.updates_processed += 1
            except Exception as e:
                logger.debug(f"Save failed: {e}")
        
        if self.batch_count % 10 == 0:
            logger.debug(f"📊 Async updater: batch={self.batch_count}, processed={self.updates_processed}")
    
    async def _process_experiences_parallel(self, experiences: List[Dict]):
        """Process multiple experiences in parallel."""
        import asyncio
        
        async def process_one(exp: Dict):
            try:
                # Run synchronous add_experience in executor to not block
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    lambda: self.q_predictor.add_experience(**exp['data'])
                )
                return True
            except Exception as e:
                logger.debug(f"Experience processing failed: {e}")
                return False
        
        # Process all experiences in parallel
        results = await asyncio.gather(*[process_one(exp) for exp in experiences])
        self.updates_processed += sum(results)
    
    # =========================================================================
    # PUBLIC API - Fire-and-Forget Methods
    # =========================================================================
    
    async def queue_experience(
        self,
        state: Dict,
        action: Dict,
        reward: float,
        next_state: Dict = None,
        done: bool = False,
        **kwargs
    ):
        """
        Queue experience for background processing (fire-and-forget).
        
        Does NOT block! Returns immediately.
        """
        if not self._running:
            logger.warning("Async updater not running, processing synchronously")
            self.q_predictor.add_experience(state, action, reward, next_state, done, **kwargs)
            return
        
        try:
            self.update_queue.put_nowait({
                'type': 'experience',
                'data': {
                    'state': state,
                    'action': action,
                    'reward': reward,
                    'next_state': next_state,
                    'done': done,
                    **kwargs
                }
            })
            self.updates_queued += 1
        except asyncio.QueueFull:
            # Queue full - process synchronously
            logger.warning("Queue full, processing experience synchronously")
            self.q_predictor.add_experience(state, action, reward, next_state, done, **kwargs)
    
    async def queue_prediction_outcome(
        self,
        state: Dict,
        action: Dict,
        predicted_q: float,
        predicted_confidence: float,
        actual_reward: float
    ):
        """Queue prediction outcome for background processing."""
        if not self._running:
            self.q_predictor.record_prediction_outcome(
                state, action, predicted_q, predicted_confidence, actual_reward
            )
            return
        
        try:
            self.update_queue.put_nowait({
                'type': 'prediction_outcome',
                'data': {
                    'state': state,
                    'action': action,
                    'predicted_q': predicted_q,
                    'predicted_confidence': predicted_confidence,
                    'actual_reward': actual_reward
                }
            })
            self.updates_queued += 1
        except asyncio.QueueFull:
            self.q_predictor.record_prediction_outcome(
                state, action, predicted_q, predicted_confidence, actual_reward
            )
    
    async def queue_save(self, path: str):
        """Queue save for background processing."""
        if not self._running:
            self.q_predictor.save_state(path)
            return
        
        try:
            self.update_queue.put_nowait({
                'type': 'save',
                'path': path
            })
            self.updates_queued += 1
        except asyncio.QueueFull:
            self.q_predictor.save_state(path)
    
    def get_stats(self) -> Dict:
        """Get updater statistics."""
        return {
            'running': self._running,
            'queue_size': self.update_queue.qsize() if self.update_queue else 0,
            'updates_queued': self.updates_queued,
            'updates_processed': self.updates_processed,
            'batch_count': self.batch_count,
            'pending': self.updates_queued - self.updates_processed
        }


# =============================================================================
# PARALLEL LLM CALL BATCHER - For efficient multi-call scenarios
# =============================================================================

class ParallelLLMBatcher:
    """
    Batch multiple LLM calls for parallel execution.
    
    🔥 A-TEAM: Reduces latency by running LLM calls in parallel!
    
    USAGE:
        batcher = ParallelLLMBatcher(max_parallel=5)
        
        # Add calls
        batcher.add_call('tag_extract', tag_extractor, {...})
        batcher.add_call('relevance', relevance_scorer, {...})
        
        # Execute all in parallel
        results = await batcher.execute_all()
    """
    
    def __init__(self, max_parallel: int = 10):
        self.max_parallel = max_parallel
        self.pending_calls = []
        self.results = {}
    
    def add_call(self, call_id: str, callable_obj, kwargs: Dict):
        """Add a call to the batch."""
        self.pending_calls.append({
            'id': call_id,
            'callable': callable_obj,
            'kwargs': kwargs
        })
    
    async def execute_all(self) -> Dict[str, Any]:
        """Execute all pending calls in parallel."""
        import asyncio
        
        if not self.pending_calls:
            return {}
        
        async def execute_one(call: Dict) -> Tuple[str, Any]:
            try:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: call['callable'](**call['kwargs'])
                )
                return call['id'], result
            except Exception as e:
                logger.debug(f"Parallel call {call['id']} failed: {e}")
                return call['id'], None
        
        # Execute in parallel with semaphore to limit concurrency
        sem = asyncio.Semaphore(self.max_parallel)
        
        async def execute_with_sem(call):
            async with sem:
                return await execute_one(call)
        
        results = await asyncio.gather(*[execute_with_sem(c) for c in self.pending_calls])
        
        self.results = {call_id: result for call_id, result in results}
        self.pending_calls = []  # Clear for next batch
        
        return self.results
    
    def clear(self):
        """Clear pending calls."""
        self.pending_calls = []
        self.results = {}

