import asyncio
import tempfile
from pathlib import Path

try:
    from Synapse.core.skill_registry import SkillRegistry
    from Synapse.core.skill_validation import SkillValidator
    from Synapse.core.skill_runtime import SkillRuntime
except Exception:
    import importlib.util

    _base = Path(__file__).resolve().parent

    def _load(name: str):
        import sys
        spec = importlib.util.spec_from_file_location(name, str(_base / f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        sys.modules[name] = mod
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        return mod

    SkillRegistry = _load("skill_registry").SkillRegistry
    SkillValidator = _load("skill_validation").SkillValidator
    SkillRuntime = _load("skill_runtime").SkillRuntime


def _run(coro):
    return asyncio.run(coro)


def test_skill_registry_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        reg = SkillRegistry(root_dir=td)
        art = _run(
            reg.register_skill(
                name="demo",
                description="demo skill",
                module_path=str(Path(td) / "skills" / "demo.py"),
                owner_actor="tester",
                status="approved",
            )
        )
        assert art.skill_id
        all_skills = _run(reg.list_skills(status="approved"))
        assert len(all_skills) == 1
        assert all_skills[0].name == "demo"


def test_skill_validator_and_runtime():
    with tempfile.TemporaryDirectory() as td:
        module_path = Path(td) / "s.py"
        module_path.write_text(
            "def run(value: int = 1):\n"
            "    return {'ok': True, 'value': value + 1}\n",
            encoding="utf-8",
        )
        validator = SkillValidator()
        result = _run(validator.validate(str(module_path)))
        assert result.valid
        runtime = SkillRuntime()
        out = _run(runtime.execute(module_path=str(module_path), payload={"value": 2}))
        assert out["success"] is True
        assert out["result"]["value"] == 3

