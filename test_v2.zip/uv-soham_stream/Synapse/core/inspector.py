"""
Synapse v6.0 - Enhanced Agent Module
===================================

All A-Team agent enhancements:
- Dr. Chen: Inter-agent communication, multi-round validation
- Aristotle: Causal knowledge injection
- Dr. Agarwal: Dynamic context allocation

Agent types:
- InspectorAgent: Architect and Auditor validation agents
- Shared scratchpad for tool result caching
- Multi-round refinement loop
"""

import dspy
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import json
import logging
import asyncio
import time  # 🔥 CRITICAL FIX: Missing import causing "name 'time' is not defined"

from .logging_config import get_logger
from .data_structures import (
    SynapseConfig, ValidationResult, OutputTag, ValidationRound,
    MemoryLevel, AgentMessage, SharedScratchpad, CommunicationType
)
from .cortex import HierarchicalMemory
from .learning import DynamicBudgetManager

logger = get_logger(__name__)


# =============================================================================
# SIGNATURES
# =============================================================================

class ArchitectSignature(dspy.Signature):
    """🔍 Pre-Exploration Agent: Explore data and brief the actor.
    
    🔥 A-TEAM PHASE 2 FIX: Architect is an ADVISOR, not a gatekeeper!
    
    YOUR ROLE:
    - EXPLORE available data using your tools (including web search if needed)
    - UNDERSTAND what data exists and its quality
    - BRIEF the actor on your findings
    - ADVISE on best approaches
    - RECOMMEND an incremental, test-first plan (small checks before full execution)
    - DO NOT BLOCK execution!
    
    YOU ARE A REACT AGENT WITH TOOLS:
    - CALL tools to discover tables, search terms, explore metadata, or verify via web search
    - Suggest minimal checks/tests the actor should run early to validate assumptions
    - DO NOT just generate text
    - Base your briefing on TOOL EVIDENCE
    
    CRITICAL: You are an exploration advisor, NOT a validator!
    """
    
    # Simple inputs - agent uses TOOLS for details
    task: str = dspy.InputField(desc="What to explore. USE TOOLS to discover available data.")
    context: str = dspy.InputField(desc="Current state summary. Call tools for specifics.")
    
    # 🔥 A-TEAM: Exploration outputs (NO should_proceed!)
    reasoning: str = dspy.OutputField(desc="Step-by-step exploration WITH tool calls and results. What did you discover?")
    exploration_summary: str = dspy.OutputField(desc="Summary of what you found: available tables, relevant terms, data quality notes")
    recommendations: str = dspy.OutputField(desc="Recommendations for the actor: suggested approach, things to be careful about, tips")
    data_quality_notes: str = dspy.OutputField(desc="Notes on data quality: missing data, stale tables, partition issues, etc.")
    confidence: float = dspy.OutputField(desc="Confidence in your exploration 0.0-1.0. Low confidence = need more exploration.")
    suggested_approach: str = dspy.OutputField(desc="Suggested approach for the actor based on what you discovered")
    insight_to_share: str = dspy.OutputField(desc="Key insight to share with other agents for learning")


class AuditorSignature(dspy.Signature):
    """Post-validation agent. USE YOUR TOOLS to validate extracted data.
    
    You are a ReAct agent with tools. DO NOT just generate text.
    CALL your tools to check the extraction (including web search for verification).
    """
    
    # Simple inputs - agent uses TOOLS for details
    task: str = dspy.InputField(desc="What extraction to validate. USE TOOLS to inspect actual data.")
    context: str = dspy.InputField(desc="Extraction summary. Call tools for detailed validation.")
    
    # FULL outputs for memory, RL, and reflection
    reasoning: str = dspy.OutputField(desc="Step-by-step analysis WITH tool calls and validation results")
    is_valid: bool = dspy.OutputField(desc="True if extraction is valid, False if issues found")
    confidence: float = dspy.OutputField(desc="Confidence 0.0-1.0 based on tool observations")
    output_tag: str = dspy.OutputField(desc="One of: useful (valid), fail (invalid), enquiry (uncertain)")
    output_name: str = dspy.OutputField(desc="Name for this validated output")
    why_useful: str = dspy.OutputField(desc="Why this output is useful - for memory/learning")
    fix_instructions: str = dspy.OutputField(desc="If invalid, specific fix instructions from tools")
    insight_to_share: str = dspy.OutputField(desc="Key insight to share with other agents for learning")


class RefinementSignature(dspy.Signature):
    """Refinement: Improve decision based on feedback."""
    
    original_decision: str = dspy.InputField(desc="Original validation decision and reasoning")
    feedback: str = dspy.InputField(desc="Feedback from other agents or round results")
    additional_context: str = dspy.InputField(desc="New context gathered")
    
    refined_reasoning: str = dspy.OutputField(desc="Updated reasoning incorporating feedback")
    refined_decision: bool = dspy.OutputField(desc="Refined should_proceed/is_valid")
    refined_confidence: float = dspy.OutputField(desc="Updated confidence")
    changes_made: str = dspy.OutputField(desc="What changed and why")


class TrajectoryFilterSignature(dspy.Signature):
    """Select relevant trajectory items for Architect/Auditor (LLM-based)."""
    trajectory_items: str = dspy.InputField(desc="JSON list of trajectory items")
    goal_context: str = dspy.InputField(desc="Root goal context")
    role: str = dspy.InputField(desc="Role: architect or auditor")
    max_items: int = dspy.InputField(desc="Maximum items to keep")
    
    reasoning: str = dspy.OutputField(desc="Why these items were selected")
    selected_indices: str = dspy.OutputField(desc="JSON list of indices to keep")


class AuditorActorNegotiationSignature(dspy.Signature):
    """Negotiate consensus between actor and auditor on whether a rejection is truly blocking.

    When an auditor rejects an actor's output after multiple retries, this mechanism
    weighs both parties' reasoning to determine if the issue is genuinely blocking
    or can be accepted as non-blocking (e.g., data unavailable, cosmetic mismatch,
    infrastructure/environment errors like SSL/proxy issues that are outside the
    actor's control).

    This replaces brittle vote-flipping with principled negotiation:
    - Actor explains why their output is correct/sufficient
    - Auditor explains their rejection rationale (including suggested_fixes)
    - The negotiation evaluates whether the gap is a true blocker vs. an acceptable deviation
    - If the auditor identifies the error as infrastructure/environment, the negotiation
      should lean toward accept_with_caveat or recommend switching to a different actor
    """
    task_description: str = dspy.InputField(desc="The task the actor was asked to perform")
    actor_output_summary: str = dspy.InputField(desc="Summary of what the actor produced")
    actor_reasoning: str = dspy.InputField(desc="Actor's reasoning for why output is correct/sufficient")
    auditor_rejection_reasoning: str = dspy.InputField(desc="Auditor's detailed reasoning for rejection")
    auditor_confidence: float = dspy.InputField(desc="Auditor's confidence in rejection (0.0-1.0)")
    retry_count: int = dspy.InputField(desc="Number of times actor has retried addressing feedback")
    trajectory_summary: str = dspy.InputField(desc="Brief summary of retry trajectory and what changed")

    is_truly_blocking: bool = dspy.OutputField(desc="True if the rejection identifies a genuine, unresolvable blocker")
    consensus_reasoning: str = dspy.OutputField(desc="Detailed reasoning for the consensus decision, weighing both perspectives")
    recommended_action: str = dspy.OutputField(desc="One of: 'accept_with_caveat' (non-blocking, proceed), 'retry_with_guidance' (actor should try specific approach), 'abandon_task' (task is impossible)")


# 🔴 A-TEAM CLEANUP: Removed InspectorCompressionSignature (duplicate)
# Now uses UnifiedCompressor instead


# =============================================================================
# INTERNAL REASONING TOOL
# =============================================================================

class InternalReasoningTool:
    """
    Agent's internal reasoning capability.
    
    Allows agents to:
    - Think through complex decisions
    - Access memory without external tools
    - Reason about causal relationships
    """
    
    def __init__(self, memory: HierarchicalMemory, config: SynapseConfig):
        self.memory = memory
        self.config = config
        self.name = "reason_about"
        self.description = """
        Internal reasoning tool for complex analysis.
        Use when you need to:
        - Think through a decision step by step
        - Access relevant past experiences
        - Understand why something works or doesn't
        
        Arguments:
        - question: What to reason about
        - context_scope: 'all', 'relevant', 'memory', 'causal'
        """
    
    def __call__(self, question: str, context_scope: str = "relevant") -> Dict[str, Any]:
        """Execute internal reasoning."""
        result = {
            "question": question,
            "relevant_memories": [],
            "causal_insights": [],
            "analysis": ""
        }
        
        # Get relevant memories
        if context_scope in ("all", "relevant", "memory"):
            memories = self.memory.retrieve(
                query=question,
                goal=question,
                budget_tokens=5000,
                levels=[MemoryLevel.SEMANTIC, MemoryLevel.PROCEDURAL, MemoryLevel.META]
            )
            # ✅ Return FULL memory content, not truncated 
            result["relevant_memories"] = [
                {"content": m.content, "value": m.default_value}
                for m in memories  # 🔥 NO LIMIT - FULL content
            ]
        
        # Get causal knowledge
        if context_scope in ("all", "relevant", "causal"):
            causal = self.memory.retrieve_causal(question, {})
            result["causal_insights"] = [
                {"cause": c.cause, "effect": c.effect, "confidence": c.confidence}
                for c in causal
            ]
        
        return result


# =============================================================================
# TOOL WRAPPER WITH CACHING
# =============================================================================

class CachingToolWrapper:
    """
    Wraps user tools with caching via shared scratchpad.
    
    Prevents redundant tool calls across agents.
    """
    
    def __init__(self, tool: Any, scratchpad: SharedScratchpad, agent_name: str):
        self.tool = tool
        self.scratchpad = scratchpad
        self.agent_name = agent_name
        self.name = getattr(tool, 'name', str(tool))
        self.description = getattr(tool, 'description', '')
    
    def __call__(self, **kwargs) -> Any:
        """Call tool with caching."""
        # Check cache first (handle errors gracefully)
        try:
            cached = self.scratchpad.get_cached_result(self.name, kwargs)
            if cached is not None:
                return cached
        except Exception as e:
            # If cache lookup fails, log but continue to execute tool
            logger = logging.getLogger(__name__)
            logger.warning(f"⚠️ Cache lookup failed for {self.name}: {e}, proceeding with tool execution")
        
        # Execute tool
        try:
            if callable(self.tool):
                result = self.tool(**kwargs)
            else:
                result = self.tool
        except Exception as e:
            result = {"error": str(e)}
        
        # Cache result WITHOUT truncation (handle errors gracefully)
        try:
            message = AgentMessage(
                sender=self.agent_name,
                receiver="*",  # Broadcast
                message_type=CommunicationType.TOOL_RESULT,
                content={
                    "tool": self.name, 
                    "args": str(kwargs), 
                    "result_summary": str(result)  # ✅ FULL result, no  truncation!
                },
                tool_name=self.name,
                tool_args=kwargs,
                tool_result=result
            )
            self.scratchpad.add_message(message)
        except Exception as e:
            # If caching fails, log but still return the result
            logger = logging.getLogger(__name__)
            logger.warning(f"⚠️ Failed to cache result for {self.name}: {e}, result still returned")
        
        return result


# =============================================================================
# EVAL AGENT
# =============================================================================

class InspectorAgent:
    """
    Enhanced evaluation agent with all A-Team features.
    
    Supports:
    - Inter-agent communication via scratchpad
    - Multi-round validation refinement
    - Causal knowledge injection
    - Dynamic context allocation
    """
    
    def __init__(self,
                 md_path: Path,
                 is_architect: bool,
                 tools: List[Any],
                 config: SynapseConfig,
                 scratchpad: SharedScratchpad = None):
        """
        Initialize InspectorAgent.
        
        Parameters:
            md_path: Path to markdown system prompt
            is_architect: True for Architect, False for Auditor
            tools: List of user-provided tools
            config: SYNAPSE configuration
            scratchpad: Shared scratchpad for communication
        """
        self.config = config
        self.is_architect = is_architect
        self.scratchpad = scratchpad or SharedScratchpad()
        
        # Load system prompt
        self.md_path = Path(md_path)
        self.system_prompt = self._load_system_prompt()
        
        # Agent name from filename
        self.agent_name = self.md_path.stem
        
        # Initialize memory
        self.memory = HierarchicalMemory(self.agent_name, config)
        
        # Budget manager
        self.budget_manager = DynamicBudgetManager(config)
        
        # LLM-based helpers (no heuristics)
        self._trajectory_filter = dspy.ChainOfThought(TrajectoryFilterSignature)
        # 🔴 A-TEAM CLEANUP: _vote_consistency removed — vote flipping replaced by
        # AuditorActorNegotiationSignature-based consensus in negotiate_consensus().
        # 🔴 A-TEAM CLEANUP: Use UnifiedCompressor (not duplicate signature)
        # 🔴 A-TEAM FIX: Pass config= kwarg (was incorrectly passed as lm= positional arg)
        from .unified_compression import UnifiedCompressor
        from .data_structures import SynapseConfig
        self._compressor = UnifiedCompressor(config=config or SynapseConfig())
        
        # 🔥 A-TEAM CRITICAL FIX: Don't double-wrap tools!
        # Tools from _get_auto_discovered_dspy_tools() are ALREADY smart wrappers
        # with caching, param resolution, etc. Don't wrap them again!
        self.user_tools = tools
        
        # Check if tools are already dspy.Tool objects (from new architecture)
        if tools and len(tools) > 0 and hasattr(tools[0], 'func'):
            # New architecture: Individual DSPy tools with smart wrappers
            # NO additional wrapping needed!
            logger.debug(f"✅ Using {len(tools)} individual DSPy tools (already wrapped)")
            self.cached_tools = tools  # Use as-is!
        else:
            # Legacy: Wrap with CachingToolWrapper
            logger.debug(f"⚠️  Wrapping {len(tools)} legacy tools with CachingToolWrapper")
            self.cached_tools = [
                CachingToolWrapper(t, self.scratchpad, self.agent_name)
                for t in tools
            ]
        
        # Add internal reasoning tool
        self.reasoning_tool = InternalReasoningTool(self.memory, config)
        self.all_tools = self.cached_tools + [self.reasoning_tool]
        
        # Log available tools for debugging
        tool_names = []
        tool_details = []
        for t in self.all_tools:
            tool_name = getattr(t, 'name', None) or getattr(t, '__name__', None) or str(t)
            tool_names.append(tool_name)
            # Log tool details for debugging
            if hasattr(t, 'func'):
                func = t.func
                if hasattr(func, '__name__'):
                    tool_details.append(f"{tool_name}(func={func.__name__})")
                else:
                    tool_details.append(f"{tool_name}(func={type(func).__name__})")
            else:
                tool_details.append(tool_name)
        
        logger.info(f"🔧 [{self.agent_name}] Available tools ({len(self.all_tools)}): {', '.join(tool_names)}")
        if tool_details != tool_names:
            logger.debug(f"   Tool details: {', '.join(tool_details)}")
        
        # Create DSPy agent
        self.signature = ArchitectSignature if is_architect else AuditorSignature
        
        # 🔥 A-TEAM: Architect IS a ReAct agent with tools when tools are registered
        # This ensures the Architect can properly use tools for exploration
        if len(self.all_tools) > 0:
            logger.info(f"✅ [{self.agent_name}] Creating ReAct agent with {len(self.all_tools)} tools (max_iters={config.max_eval_iters})")
            
            # 🔍 DETAILED LOGGING: Create ReAct with iteration logging
            react_agent = dspy.ReAct(
                self.signature,
                tools=self.all_tools,
                max_iters=config.max_eval_iters
            )
            
            # Wrap the forward method to log iterations
            original_forward = react_agent.forward
            def logged_forward(*args, **kwargs):
                iter_count = 0
                logger.info(f"    🔄 [REACT START] agent={self.agent_name} | max_iters={config.max_eval_iters}")
                
                # Wrap tools to log each call
                if hasattr(react_agent, 'tools') and react_agent.tools:
                    for tool in react_agent.tools:
                        if hasattr(tool, 'func'):
                            original_tool = tool.func
                            def make_logged_tool(orig_func, tool_name):
                                def logged_tool(*tool_args, **tool_kwargs):
                                    tool_start = time.time()
                                    logger.info(f"      🔧 [TOOL CALL] {tool_name}")
                                    result = orig_func(*tool_args, **tool_kwargs)
                                    tool_duration = time.time() - tool_start
                                    logger.info(f"      ✅ [TOOL COMPLETE] {tool_name} | duration={tool_duration:.3f}s")
                                    return result
                                return logged_tool
                            tool.func = make_logged_tool(original_tool, tool.__name__ if hasattr(tool, '__name__') else str(tool))
                
                result = original_forward(*args, **kwargs)
                logger.info(f"    ✅ [REACT COMPLETE] agent={self.agent_name}")
                return result
            
            react_agent.forward = logged_forward
            self.agent = react_agent
        else:
            # Fallback to ChainOfThought if no tools (shouldn't happen for Architect with registered tools)
            logger.warning(f"⚠️  [{self.agent_name}] No tools available, using ChainOfThought instead of ReAct")
            self.agent = dspy.ChainOfThought(self.signature)
        
        # Refinement agent
        if config.enable_multi_round:
            self.refiner = dspy.ChainOfThought(RefinementSignature)
        
        # Statistics
        self.total_calls = 0
        self.total_approvals = 0
        self.tool_calls: List[Dict] = []
    
    def _smart_truncate(self, text: str, max_chars: int) -> str:
        """
        LLM-based compression to fit within budget.
        
        🔴 A-TEAM FIX (E7b): Uses ContentIngestionPipeline for proper chunking
        when content is large. Direct compression at extreme ratios (e.g. 67K→1K 
        tokens) causes catastrophic 0.6% retention. Pipeline chunks first, then
        compresses each chunk, producing much better results.
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        if len(text) <= max_chars:
            return text
        
        max_tokens = max(1, max_chars // 4)
        current_tokens = len(text) // 4
        # Prevent extreme one-shot compression that erases validation signal.
        # Keep at least 50% of source tokens per compression request.
        min_tokens = max(1, int(current_tokens * 0.5))
        if max_tokens < min_tokens:
            logger.warning(
                f"⚖️ Inspector compression policy: requested {max_tokens} for {current_tokens} tokens. "
                f"Raising to {min_tokens} (50% retention)."
            )
            max_tokens = min_tokens
        
        # 🔴 A-TEAM FIX (E7b): Use ContentIngestionPipeline which handles 
        # both chunking and compression — prevents catastrophic information loss
        # when compression ratio is extreme (e.g. 67K→1K tokens = 0.6% retention)
        try:
            if not hasattr(self, '_ingestion_pipeline'):
                from .content_ingestion import ContentIngestionPipeline
                self._ingestion_pipeline = ContentIngestionPipeline(config=self.config)
            
            result = self._ingestion_pipeline.process_sync(
                content=text,
                max_tokens=max_tokens,
                query="Compress content while preserving critical details for validation",
                goal="Inspector context compression",
                context_type="inspector"
            )
            
            logger.debug(
                f"   📄 _smart_truncate: {current_tokens} → {result.final_tokens} tokens "
                f"via {result.processing_path} (retention: {result.compression_ratio:.1%})"
            )
            return result.content
        except Exception as e:
            logger.warning(f"   ⚠️ ContentIngestionPipeline failed: {e}, trying UnifiedCompressor")
        
        # Fallback to UnifiedCompressor (which now auto-delegates for extreme ratios)
        if not self._compressor:
            raise RuntimeError(
                "❌ InspectorAgent compression requires LLM intelligence!\n"
                "Inspector context compression is critical for validation accuracy. "
                "Cannot fall back to returning uncompressed text as it causes context overflow. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        try:
            result = self._compressor.compress_sync(
                content=text,
                max_tokens=max_tokens,
                task_context={'purpose': 'inspector_context_compression'}
            )
            return result
        except Exception as e:
            raise RuntimeError(
                f"❌ Inspector compression failed: {e}\n"
                "Cannot return uncompressed text as it causes context overflow. "
                "Please check LLM configuration."
            )

    def _select_trajectory_items(
        self,
        trajectory: List[Any],
        goal: str,
        role: str,
        max_items: int
    ) -> List[str]:
        """
        LLM-based trajectory selection (no keyword heuristics).
        
        🔥 A-TEAM CRITICAL FIX: NO silent fallback!
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        if not trajectory:
            return []
        # Use LLM-based truncation instead of hardcoded slicing
        items = [self._smart_truncate(str(item), 4000) for item in trajectory]
        if not self._trajectory_filter:
            raise RuntimeError(
                "❌ InspectorAgent trajectory filtering requires LLM intelligence!\n"
                "Trajectory selection is critical for validation quality. "
                "Cannot fall back to returning all raw items as it causes context overflow and inefficiency. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        try:
            result = self._trajectory_filter(
                trajectory_items=json.dumps(items),
                goal_context=self._smart_truncate(goal, 2000) if goal else "",
                role=role,
                max_items=max_items
            )
            indices = json.loads(result.selected_indices) if hasattr(result, "selected_indices") else []
            selected = []
            for idx in indices:
                if isinstance(idx, int) and 0 <= idx < len(items):
                    selected.append(items[idx])
            return selected if selected else items[:max_items]
        except Exception as e:
            logger.debug(f"Trajectory selection failed: {e}")
            return items
    
    def _load_system_prompt(self) -> str:
        """Load system prompt from markdown file."""
        if self.md_path.exists():
            return self.md_path.read_text()
        else:
            # Default minimal prompt
            role = "pre-validation" if self.is_architect else "post-validation"
            return f"You are a {role} agent. Analyze inputs carefully."
    
    async def run(self,
                  goal: str,
                  inputs: Dict[str, Any],
                  trajectory: List[Dict],
                  round: ValidationRound = ValidationRound.INITIAL) -> ValidationResult:
        """
        Run validation.
        
        Parameters:
            goal: The goal being validated
            inputs: Input fields for signature
            trajectory: Current trajectory
            round: Validation round (for multi-round)
        
        Returns:
            ValidationResult with decision and metadata
        """
        import time
        start_time = time.time()
        self.total_calls += 1
        self.tool_calls = []
        
        # 🎨 AGENT STATUS: Show what agent is doing with nice icons
        agent_type = "🔍 Architect" if self.is_architect else "✅ Auditor"
        logger.info(f"")
        logger.info(f"{'='*80}")
        logger.info(f"{agent_type} Agent: {self.agent_name}")
        logger.info(f"🎯 Task: Validate inputs/output for goal")
        logger.info(f"⏰ Started: {datetime.now().strftime('%H:%M:%S')}")
        logger.info(f"🔄 Status: WORKING... (Agent is analyzing with LLM)")
        logger.info(f"{'='*80}")
        
        # 🎯 A-TEAM FIX: SMART MEMORY for Learning, NOT Blocking!
        # Memory should HELP actors improve, not block them based on past failures
        if self.is_architect:
            # Architect: Retrieve SUCCESS PATTERNS ONLY (not blocking decisions)
            memory_context = self._build_smart_memory_for_architect(goal, inputs)
            logger.info(f"✅ [ARCHITECT SMART MEMORY] Retrieved success patterns for learning")
        else:
            # Auditor: Retrieve all patterns for validation
            memory_context = self._build_memory_context(goal, inputs)
        
        causal_context = self._build_causal_context(goal, inputs)
        shared_insights = self._get_shared_insights()
        
        # 🔧 FIX: Convert trajectory items to serializable format
        # ✅ A-TEAM FIX: FILTER trajectory for Architect - keep success patterns, remove failures!
        # Auditor needs recent trajectory to understand what actor did
        if self.is_architect:
            serializable_trajectory = self._select_trajectory_items(
                trajectory=trajectory,
                goal=goal,
                role="architect",
                max_items=3
            )
            logger.info(f"✅ [ARCHITECT TRAJECTORY] LLM-selected items: {len(trajectory)} → {len(serializable_trajectory)}")
        else:
            serializable_trajectory = self._select_trajectory_items(
                trajectory=trajectory,
                goal=goal,
                role="auditor",
                max_items=5
            )
        
        # 🎯 USE SYNAPSE'S BUDGET MANAGER - NO HARDCODING!
        # Compute budget allocation intelligently
        system_tokens = len(self.system_prompt) // 4
        input_tokens = sum(len(str(v)) // 4 for v in inputs.values())
        trajectory_tokens = sum(len(s) // 4 for s in serializable_trajectory)
        
        allocation = self.budget_manager.compute_allocation(
            system_prompt_tokens=system_tokens,
            input_tokens=input_tokens,
            trajectory_tokens=trajectory_tokens,
            tool_output_tokens=0  # Will be computed dynamically
        )
        
        # 🎯 BUILD CONTEXT PARTS WITH BUDGET ALLOCATION
        # SmartContextGuard will handle intelligent truncation if needed
        logger.debug(f"🔨 [CONTEXT BUILD] Starting context parts assembly | agent={self.agent_name}")
        context_parts = []
        
        # Add memory context (use allocated budget)
        logger.debug(f"  Step 1: Processing memory context")
        if memory_context:
            memory_budget = allocation.get('memory', 5000)
            memory_tokens = len(memory_context) // 4
            original_memory_len = len(memory_context)
            logger.debug(f"    Memory context: {original_memory_len} chars ({memory_tokens} tokens) | budget={memory_budget} tokens")
            
            if memory_tokens > memory_budget:
                # Intelligent truncation: keep complete sentences
                logger.debug(f"    ⚠️  Memory exceeds budget, truncating...")
                memory_context = self._smart_truncate(memory_context, memory_budget * 4)
                logger.debug(f"    ✅ Memory truncated: {original_memory_len} -> {len(memory_context)} chars")
            else:
                logger.debug(f"    ✅ Memory fits within budget")
            
            context_parts.append(f"{memory_context}")
            logger.debug(f"    ✅ Memory context added to context_parts")
        elif self.is_architect:
            # ✅ EXPLICIT: Architect validates CURRENT inputs, learns from SUCCESS
            architect_note = (
                "IMPORTANT: You are validating CURRENT inputs for THIS execution attempt. "
                "Focus on whether the current inputs are sufficient NOW. "
                "If you see learned patterns above, use them to HELP validate (what inputs work well), "
                "NOT to block based on past failures. Your job is to enable success, not prevent attempts."
            )
            context_parts.append(architect_note)
            logger.debug(f"    ✅ Architect validation note added (no memory context available)")
        else:
            logger.debug(f"    ⚠️  No memory context available")
        
        # Add trajectory (use allocated budget)
        logger.debug(f"  Step 2: Processing trajectory")
        if serializable_trajectory:
            traj_budget = allocation.get('trajectory', 5000)
            traj_items = len(serializable_trajectory)
            logger.debug(f"    Trajectory: {traj_items} items | budget={traj_budget} tokens")
            
            # Keep most recent items that fit in budget
            traj_str = json.dumps(serializable_trajectory, indent=2)
            traj_tokens = len(traj_str) // 4
            logger.debug(f"    Trajectory JSON: {len(traj_str)} chars ({traj_tokens} tokens)")
            
            if traj_tokens > traj_budget:
                logger.debug(f"    ⚠️  Trajectory exceeds budget, keeping recent items...")
                # Keep recent items
                for i in range(len(serializable_trajectory) - 1, -1, -1):
                    partial = json.dumps(serializable_trajectory[i:], indent=2)
                    if len(partial) // 4 <= traj_budget:
                        traj_str = partial
                        logger.debug(f"    ✅ Kept {len(serializable_trajectory) - i} recent items: {len(traj_str)} chars")
                        break
            else:
                logger.debug(f"    ✅ Trajectory fits within budget")
            
            context_parts.append(f"History: {traj_str}")
            logger.debug(f"    ✅ Trajectory added to context_parts")
        else:
            logger.debug(f"    ⚠️  No trajectory available")
        
        # Add insights (typically small, no truncation needed)
        logger.debug(f"  Step 3: Processing shared insights")
        if shared_insights:
            insights_len = len(str(shared_insights))
            logger.debug(f"    Insights: {insights_len} chars")
            context_parts.append(f"Insights: {shared_insights}")
            logger.debug(f"    ✅ Insights added to context_parts")
        else:
            logger.debug(f"    ⚠️  No shared insights available")
        
        # Add causal context (use remaining budget)
        logger.debug(f"  Step 4: Processing causal context")
        if causal_context:
            causal_len = len(str(causal_context))
            logger.debug(f"    Causal context: {causal_len} chars")
            context_parts.append(f"Causal: {causal_context}")
            logger.debug(f"    ✅ Causal context added to context_parts")
        else:
            logger.debug(f"    ⚠️  No causal context available")
        
        logger.debug(f"  Context parts assembled: {len(context_parts)} parts so far")
        
        # 🔥 A-TEAM GENERIC SOLUTION: Inject ALL extra inputs into context
        # ANY field in inputs that's NOT part of the agent's signature gets added to context.
        # This allows integration layers to pass domain-specific data WITHOUT hardcoding in SYNAPSE!
        # Examples: schemas, business terms, metadata, constraints, etc.
        logger.debug(f"🔍 [GENERIC CONTEXT] Starting extra fields collection | agent={self.agent_name}")
        
        signature_fields = set(self.signature.input_fields.keys()) if hasattr(self.signature, 'input_fields') else set()
        logger.debug(f"  Signature fields: {list(signature_fields)} | count={len(signature_fields)}")
        
        extra_fields = {}
        skipped_fields = []
        empty_fields = []
        
        logger.debug(f"  Scanning {len(inputs)} input fields for extra context")
        for key, value in inputs.items():
            # Skip fields that are part of signature or special SYNAPSE fields
            if key not in signature_fields and key not in ['goal', 'trajectory', 'round']:
                if value is not None and str(value).strip():  # Only non-empty values
                    value_str = str(value)
                    value_len = len(value_str)
                    logger.debug(f"    ✅ Adding extra field: {key} | type={type(value).__name__} | length={value_len} chars")
                    extra_fields[key] = value
                else:
                    empty_fields.append(key)
                    logger.debug(f"    ⚠️  Skipping empty field: {key} | value={value}")
            else:
                skipped_fields.append(key)
                logger.debug(f"    ⏭️  Skipping signature field: {key}")
        
        logger.info(f"  📊 Extra fields scan complete | "
                   f"found={len(extra_fields)} | "
                   f"skipped_signature={len(skipped_fields)} | "
                   f"skipped_empty={len(empty_fields)}")
        if skipped_fields:
            logger.debug(f"    Skipped signature fields: {skipped_fields}")
        if empty_fields:
            logger.debug(f"    Skipped empty fields: {empty_fields}")
        
        # Add ALL extra fields to context generically (NO HARDCODING!)
        if extra_fields:
            logger.info(f"  🔨 Injecting {len(extra_fields)} extra fields into context")
            context_parts.append("\n=== ADDITIONAL CONTEXT ===")
            
            total_injected_chars = 0
            truncated_count = 0
            
            for field_name, field_value in extra_fields.items():
                # Smart truncation for large values to respect token budget
                value_str = str(field_value)
                original_len = len(value_str)
                
                if original_len > 5000:
                    value_str = value_str[:5000] + f"...[truncated from {original_len} chars]"
                    truncated_count += 1
                    logger.debug(f"    ⚠️  Truncated {field_name}: {original_len} -> {len(value_str)} chars")
                else:
                    logger.debug(f"    ✅ Added {field_name}: {len(value_str)} chars")
                
                # Format nicely for LLM
                formatted_name = field_name.replace('_', ' ').title()
                formatted_value = f"\n{formatted_name}:\n{value_str}"
                context_parts.append(formatted_value)
                total_injected_chars += len(formatted_value)
            
            logger.info(f"✅ [GENERIC CONTEXT] Injected {len(extra_fields)} extra fields into {self.agent_name} | "
                       f"fields={list(extra_fields.keys())} | "
                       f"total_chars={total_injected_chars} | "
                       f"truncated={truncated_count}")
        else:
            logger.debug(f"  ⚠️  No extra fields to inject")
        
        logger.info(f"  Step 5: Building final context string from {len(context_parts)} parts")
        context_build_start = time.time()
        context_str = "\n".join(context_parts)
        context_build_duration = time.time() - context_build_start
        logger.info(f"  ✅ Context string built | length={len(context_str)} chars | "
                   f"duration={context_build_duration:.3f}s")
        
        # Simplified inputs - agent should call tools for details
        logger.info(f"  Step 6: Extracting base task from inputs")
        base_task = inputs.get("goal", goal) or goal
        logger.info(f"  ✅ Base task extracted | length={len(base_task)} chars | "
                   f"preview='{base_task[:100]}{'...' if len(base_task) > 100 else ''}'")
        
        # 🆕 A-TEAM FIX #1: Extract ALL execution metadata from inputs
        # SYNAPSE is generic - we extract ALL fields so agent can see execution results!
        # This fixes the Auditor false negative bug where execution metadata was invisible.
        logger.info(f"  Step 7: Extracting execution metadata from inputs")
        execution_metadata_parts = []
        metadata_fields = [
            'execution_status', 'execution_success', 'row_count',
            'has_data', 'error_message', 'action_result', 'action_taken'
        ]
        
        found_metadata = []
        for field in metadata_fields:
            if field in inputs and inputs[field] is not None:
                # Format for LLM readability
                value = inputs[field]
                original_value = value
                # Intelligently truncate very long values (but keep reasonable detail)
                if isinstance(value, str) and len(value) > 1000:
                    value = value[:1000] + f"...[{len(value)-1000} chars truncated for context]"
                    logger.debug(f"    ⚠️  Truncated {field}: {len(original_value)} -> {len(value)} chars")
                else:
                    logger.debug(f"    ✅ Added {field}: {value}")
                execution_metadata_parts.append(f"{field}: {value}")
                found_metadata.append(field)
        
        logger.info(f"  ✅ Execution metadata extraction complete | found={len(found_metadata)} fields: {found_metadata}")
        
        # Build context with ALL available information
        logger.info(f"  Step 8: Building execution metadata string")
        metadata_str = ""
        if execution_metadata_parts:
            metadata_str = "EXECUTION METADATA:\n" + "\n".join(execution_metadata_parts) + "\n\n"
            logger.info(f"  ✅ Execution metadata string built | length={len(metadata_str)} chars")
        else:
            logger.info(f"  ⚠️  No execution metadata found")
        
        logger.info(f"  Step 9: Combining all context parts")
        action_args = inputs.get('action_args', '')
        action_args_len = len(action_args) if action_args else 0
        logger.debug(f"    action_args length: {action_args_len} chars")
        logger.debug(f"    metadata_str length: {len(metadata_str)} chars")
        logger.debug(f"    context_str length: {len(context_str)} chars")
        
        base_context = f"{metadata_str}{action_args}\n\n{context_str}"
        logger.info(f"  ✅ Base context combined | total_length={len(base_context)} chars")
        
        # 🌍 Step 9.5: Add environment context if available
        env_manager = getattr(self.config, 'env_manager', None)
        if env_manager:
            try:
                logger.info(f"  Step 9.5: Adding environment context from env_manager")
                current_env = env_manager.get_current_env()
                if current_env:
                    env_context_section = f"\n\n=== CURRENT ENVIRONMENT STATE ===\n{current_env}\n"
                    base_context += env_context_section
                    logger.info(f"  ✅ Environment context added | env_length={len(current_env)} chars")
            except Exception as e:
                logger.warning(f"  ⚠️  Failed to add environment context: {e}")
        
        # If context is too large, use smart truncation
        logger.info(f"  Step 10: Checking context size and truncating if needed")
        max_context_tokens = self.config.max_context_tokens - system_tokens - 1000  # Reserve for output
        base_context_tokens = len(base_context) // 4
        logger.debug(f"    Base context tokens: {base_context_tokens}")
        logger.debug(f"    Max context tokens: {max_context_tokens}")
        
        if base_context_tokens > max_context_tokens:
            logger.warning(f"  ⚠️  Context exceeds limit ({base_context_tokens} > {max_context_tokens} tokens), truncating...")
            truncate_start = time.time()
            base_context = self._smart_truncate(base_context, max_context_tokens * 4)
            truncate_duration = time.time() - truncate_start
            logger.info(f"  ✅ Context truncated | new_length={len(base_context)} chars | "
                       f"duration={truncate_duration:.3f}s")
        else:
            logger.info(f"  ✅ Context size OK | tokens={base_context_tokens} <= {max_context_tokens}")
        
        # =====================================================================
        # RETRY LOOP with signature validation and regeneration feedback
        # =====================================================================
        logger.info(f"  Step 11: Starting validation loop | max_retries={self.config.max_eval_retries}")
        max_retries = self.config.max_eval_retries  # ✅ FROM CONFIG! (was hardcoded=3)
        last_error = None
        validation_result = None
        
        for attempt in range(max_retries):
            attempt_start_time = time.time()
            logger.info(f"  🔄 VALIDATION ATTEMPT {attempt + 1}/{max_retries} | agent={self.agent_name}")
            try:
                # Build inputs with retry feedback if needed
                if attempt == 0:
                    logger.info(f"    Building initial inputs | task_length={len(base_task)} | context_length={len(base_context)}")
                    full_inputs = {"task": base_task, "context": base_context}
                    logger.debug(f"    Inputs prepared: task='{base_task[:100]}...', context_length={len(base_context)}")
                else:
                    logger.warning(f"    ⚠️  RETRY: Adding feedback about previous error")
                    logger.debug(f"    Previous error: {last_error}")
                    # Add feedback about what was missing
                    retry_feedback = f"""
RETRY ATTEMPT {attempt + 1}/{max_retries}
PREVIOUS ERROR: {last_error}

YOU MUST provide ALL required output fields:
"""
                    if self.is_architect:
                        retry_feedback += """
Architect Required Outputs:
- reasoning: Your step-by-step exploration WITH tool calls and results (string)
- exploration_summary: Summary of what you found (string)
- recommendations: Recommendations for the actor (string)
- data_quality_notes: Notes on data quality (string)
- confidence: 0.0 to 1.0 (float)
- suggested_approach: Suggested approach for the actor (string)
- insight_to_share: Key insight for other agents (string, can be empty)

NOTE: Architect is an ADVISOR, not a gatekeeper. You provide recommendations but don't block execution.
"""
                    else:
                        retry_feedback += """
Auditor Required Outputs:
- reasoning: Your validation analysis (string)
- is_valid: True or False (boolean)
- confidence: 0.0 to 1.0 (float)
- output_tag: 'useful', 'fail', or 'enquiry' (string)
- output_name: Name for this output (string)
- why_useful: Why this is useful (string)
- fix_instructions: What to fix if invalid (string)
- insight_to_share: Key insight for other agents (string)
"""
                    full_inputs = {
                        "task": f"{base_task}\n\n{retry_feedback}",
                        "context": base_context
                    }
                    logger.info(f"    ✅ Retry inputs built | task_length={len(full_inputs['task'])} | "
                               f"feedback_length={len(retry_feedback)}")
                
                # Run agent WITH TIMEOUT (to prevent hanging on API failures)
                # ⚡ A-TEAM FIX: Add timeout for LLM calls to prevent indefinite hangs
                timeout_seconds = getattr(self.config, 'llm_timeout_seconds', 300)  # 5 minutes default
                logger.info(f"    🔵 Calling LLM agent | timeout={timeout_seconds}s")
                
                # 🔍 DETAILED LOGGING: Log input sizes for debugging
                input_sizes = {}
                total_input_chars = 0
                for key, value in full_inputs.items():
                    if isinstance(value, str):
                        size = len(value)
                        input_sizes[key] = size
                        total_input_chars += size
                    elif isinstance(value, list):
                        size = sum(len(str(item)) for item in value)
                        input_sizes[key] = f"{len(value)} items, {size} chars"
                        total_input_chars += size
                logger.info(f"    📊 [INPUT SIZES] total_chars={total_input_chars:,} | breakdown={input_sizes}")
                
                try:
                    llm_call_start = time.time()
                    logger.info(f"⏱️ [INSPECTOR LLM START] InspectorAgent.run | agent={self.agent_name} | attempt={attempt+1}/{max_retries} | timeout={timeout_seconds}s")
                    logger.info(f"    🔄 [STEP 1/4] Preparing to call DSPy agent...")
                    
                    # Create instrumented wrapper for detailed logging
                    def instrumented_agent_call():
                        logger.info(f"    🔄 [STEP 2/4] Inside thread, calling self.agent with {len(full_inputs)} inputs...")
                        thread_start = time.time()
                        result = self.agent(**full_inputs)
                        thread_duration = time.time() - thread_start
                        logger.info(f"    ✅ [STEP 3/4] Agent call completed in thread | duration={thread_duration:.3f}s")
                        return result
                    
                    logger.info(f"    🔄 [STEP 4/4] Executing in thread with timeout={timeout_seconds}s...")
                    # Wrap LLM call in timeout
                    result = await asyncio.wait_for(
                        asyncio.to_thread(instrumented_agent_call),
                        timeout=timeout_seconds
                    )
                    llm_call_duration = time.time() - llm_call_start
                    logger.info(f"⏱️ [INSPECTOR LLM COMPLETE] InspectorAgent.run | llm_call_duration={llm_call_duration:.3f}s | agent={self.agent_name}")
                    
                    # Extract token usage if available
                    if hasattr(result, '_completions') and result._completions:
                        for i, completion in enumerate(result._completions):
                            if hasattr(completion, 'usage'):
                                usage = completion.usage
                                logger.info(f"⏱️ [INSPECTOR LLM TOKENS] completion[{i}] | input_tokens={getattr(usage, 'prompt_tokens', 'N/A')} | output_tokens={getattr(usage, 'completion_tokens', 'N/A')} | total_tokens={getattr(usage, 'total_tokens', 'N/A')}")
                    
                    logger.info(f"    ✅ LLM call completed | duration={llm_call_duration:.3f}s")
                except asyncio.TimeoutError:
                    logger.warning(f"⏰ [{self.agent_name}] LLM call timed out after {timeout_seconds}s on attempt {attempt + 1}/{max_retries}")
                    last_error = f"LLM API timeout after {timeout_seconds}s"
                    if attempt < max_retries - 1:
                        # Exponential backoff before retry
                        backoff_time = min(5 * (2 ** attempt), 30)  # 5s, 10s, 30s max
                        logger.info(f"⏰ Retrying after {backoff_time}s backoff...")
                        await asyncio.sleep(backoff_time)
                        continue
                    else:
                        # Final timeout - return default result
                        logger.error(f"❌ [{self.agent_name}] All {max_retries} attempts timed out. Using default.")
                        raise Exception(last_error)
                
                # Validate the result has required fields
                logger.info(f"    🔍 Validating result has required fields")
                validation_start = time.time()
                missing_fields = self._check_required_fields(result)
                validation_duration = time.time() - validation_start
                
                if missing_fields:
                    last_error = f"Missing fields: {missing_fields}"
                    logger.warning(f"    ❌ Validation failed | missing_fields={missing_fields} | duration={validation_duration:.3f}s")
                    if attempt < max_retries - 1:
                        logger.info(f"    🔄 Will retry (attempt {attempt + 1}/{max_retries})")
                        continue  # Retry
                    else:
                        logger.warning(f"    ⚠️  Last attempt, will use defaults for missing fields")
                    # On last attempt, use defaults for missing fields
                else:
                    logger.info(f"    ✅ Validation passed | duration={validation_duration:.3f}s")
                
                # Parse result
                logger.info(f"    📝 Parsing result")
                parse_start = time.time()
                validation_result = self._parse_result(result, round, start_time)
                parse_duration = time.time() - parse_start
                logger.info(f"    ✅ Result parsed | duration={parse_duration:.3f}s")
                logger.debug(f"      Result: is_valid={getattr(validation_result, 'is_valid', 'N/A')}, "
                           f"confidence={getattr(validation_result, 'confidence', 'N/A')}, "
                           f"reasoning_length={len(getattr(validation_result, 'reasoning', ''))}")
                
                # Share insight if any
                if hasattr(result, 'insight_to_share') and result.insight_to_share:
                    logger.info(f"    💡 Sharing insight with other agents")
                    self._share_insight(result.insight_to_share)
                    logger.debug(f"      Insight: {result.insight_to_share[:200]}{'...' if len(result.insight_to_share) > 200 else ''}")
                else:
                    logger.debug(f"    ⚠️  No insight to share")
                
                # Store in memory
                logger.info(f"    💾 Storing experience in memory")
                store_start = time.time()
                self._store_experience(goal, inputs, validation_result)
                store_duration = time.time() - store_start
                logger.info(f"    ✅ Experience stored | duration={store_duration:.3f}s")
                
                # Success - break retry loop
                attempt_duration = time.time() - attempt_start_time
                logger.info(f"  ✅ VALIDATION ATTEMPT {attempt + 1} SUCCESS | total_duration={attempt_duration:.3f}s")
                break
                
            except Exception as e:
                attempt_duration = time.time() - attempt_start_time
                last_error = str(e)
                error_type = type(e).__name__
                logger.error(f"  ❌ VALIDATION ATTEMPT {attempt + 1} FAILED | error={error_type}: {last_error} | "
                           f"duration={attempt_duration:.3f}s", exc_info=True)
                
                if attempt == max_retries - 1:
                    # Final failure
                    logger.error(f"  ❌ All {max_retries} attempts failed, using default result")
                    validation_result = ValidationResult(
                        agent_name=self.agent_name,
                        is_valid=True if self.is_architect else False,  # Default to proceed for architect
                        confidence=self.config.default_confidence_on_error,  # ✅ FROM CONFIG! (was 0.3)
                        reasoning=f"Error after {max_retries} attempts: {last_error}",
                        should_proceed=True if self.is_architect else None,  # Default proceed
                        output_tag=OutputTag.ENQUIRY if not self.is_architect else None,
                        validation_round=round
                    )
                    logger.warning(f"  ⚠️  Using default validation result due to errors")
        
        # Ensure we have a result
        if validation_result is None:
            logger.warning(f"  ⚠️  No validation result created, using default")
            validation_result = ValidationResult(
                agent_name=self.agent_name,
                is_valid=True,
                confidence=self.config.default_confidence_no_validation,  # ✅ FROM CONFIG! (was 0.5)
                reasoning="Default result - no validation performed",
                should_proceed=True if self.is_architect else None,
                validation_round=round
            )
        
        validation_result.execution_time = time.time() - start_time
        validation_result.tool_calls = self.tool_calls
        
        logger.info(f"  📊 Finalizing validation result | execution_time={validation_result.execution_time:.3f}s | "
                   f"tool_calls={len(self.tool_calls)}")
        
        # Update stats
        if self.is_architect:
            # Architect is advisor - always counts as approval (doesn't block)
            self.total_approvals += 1
            logger.debug(f"    ✅ Architect provided advice, incrementing approval count")
        elif not self.is_architect and validation_result.is_valid:
            self.total_approvals += 1
            logger.debug(f"    ✅ Auditor validated, incrementing approval count")
        
        total_duration = time.time() - start_time
        logger.info(f"✅ VALIDATION COMPLETE | agent={self.agent_name} | "
                   f"is_valid={getattr(validation_result, 'is_valid', 'N/A')} | "
                   f"confidence={getattr(validation_result, 'confidence', 'N/A'):.3f} | "
                   f"total_duration={total_duration:.3f}s")
        
        return validation_result
    
    async def refine(self,
                     original_result: ValidationResult,
                     feedback: str,
                     additional_context: str = "") -> ValidationResult:
        """
        Refine decision based on feedback (multi-round validation).
        """
        if not self.config.enable_multi_round:
            return original_result
        
        try:
            # For Architect: decision is always "proceed" (advisor role)
            architect_decision = "proceed" if self.is_architect else ('proceed' if original_result.should_proceed else 'block')
            result = self.refiner(
                original_decision=f"Decision: {architect_decision}, Reasoning: {original_result.reasoning}",
                feedback=feedback,
                additional_context=additional_context
            )
            
            # Create refined result
            refined = ValidationResult(
                agent_name=self.agent_name,
                is_valid=result.refined_decision if not self.is_architect else True,  # Architect always True
                confidence=float(result.refined_confidence),
                reasoning=result.refined_reasoning,
                should_proceed=True if self.is_architect else None,  # Architect always True (advisor)
                validation_round=ValidationRound.REFINEMENT,
                previous_rounds=[original_result]
            )
            
            # Assess reasoning quality
            refined.reasoning_steps = result.refined_reasoning.split('\n')
            refined.reasoning_quality = min(1.0, len(refined.reasoning_steps) * 0.1 + 0.3)
            
            return refined
            
        except Exception:
            return original_result
    
    def _build_smart_memory_for_architect(self, goal: str, inputs: Dict) -> str:
        """
        Build SMART memory context for Architect.
        
        🎯 USER CRITICAL FIX: Memory should HELP, not BLOCK!
        
        Architect should learn from:
        - ✅ Successful validation patterns ("what inputs led to success?")
        - ✅ Overcoming blocks ("how did we fix previous blocks?")
        - ❌ NOT past blocking decisions
        
        This is like a mentor saying "here's what worked before" 
        instead of "you failed before, so fail again".
        """
        # Get query from inputs
        query = inputs.get('proposed_action', '') or inputs.get('action_result', '') or goal
        
        # Compute budget using budget manager
        system_tokens = len(self.system_prompt) // 4
        input_tokens = sum(len(str(v)) // 4 for v in inputs.values())
        
        allocation = self.budget_manager.compute_allocation(
            system_prompt_tokens=system_tokens,
            input_tokens=input_tokens,
            trajectory_tokens=2000,  # Estimate
            tool_output_tokens=2000
        )
        
        memory_budget = allocation['memory']
        
        # 🎯 CRITICAL: Retrieve SUCCESS patterns, NOT blocking decisions!
        memories = self.memory.retrieve(
            query=query,
            goal=goal,
            budget_tokens=memory_budget,
            context_hints=f"Looking for successful patterns that helped similar tasks: {goal}"
        )
        
        # 🔥 FILTER OUT blocked/failed memories after retrieval
        if memories:
            filtered_memories = []
            for mem in memories:
                # Skip memories with failure tags
                if hasattr(mem, 'metadata') and isinstance(mem.metadata, dict):
                    tags = mem.metadata.get('tags', [])
                    if any(tag in tags for tag in ['blocked', 'architect_blocked', 'failed_validation', 'failed']):
                        continue  # Skip this memory
                filtered_memories.append(mem)
            memories = filtered_memories if filtered_memories else memories
        
        if not memories:
            return ""
        
        # Format as learning context (positive framing)
        memory_lines = ["LEARNED PATTERNS (what worked before):"]
        for mem in memories:
            # Extract only actionable insights, not blocking decisions
            if hasattr(mem, 'insight') and mem.insight:
                memory_lines.append(f"- {mem.insight}")
            elif hasattr(mem, 'what_worked') and mem.what_worked:
                memory_lines.append(f"- {mem.what_worked}")
        
        return "\n".join(memory_lines) if len(memory_lines) > 1 else ""
    
    def _build_memory_context(self, goal: str, inputs: Dict) -> str:
        """
        Build memory context string.
        
        🎯 NO HARDCODED SLICING - Uses budget manager allocation!
        """
        # Get query from inputs
        query = inputs.get('proposed_action', '') or inputs.get('action_result', '') or goal
        
        # Compute budget using budget manager
        system_tokens = len(self.system_prompt) // 4
        input_tokens = sum(len(str(v)) // 4 for v in inputs.values())
        
        allocation = self.budget_manager.compute_allocation(
            system_prompt_tokens=system_tokens,
            input_tokens=input_tokens,
            trajectory_tokens=2000,  # Estimate
            tool_output_tokens=2000
        )
        
        memory_budget = allocation['memory']
        
        # Retrieve memories with computed budget
        memories = self.memory.retrieve(
            query=query,
            goal=goal,
            budget_tokens=memory_budget,
            context_hints=f"Looking for memories relevant to: {goal}"  # ✅ NO  limit!
        )
        
        if not memories:
            return "No relevant memories found."
        
        # Format memories WITHOUT hardcoded truncation
        # Budget manager already handles sizing during retrieval
        context_parts = []
        for mem in memories:
            value = mem.get_value(goal)
            # Let budget manager control size, not hardcoded 
            content = mem.content
            if len(content) > 500:  # Only truncate VERY long individual memories
                content = self._smart_truncate(content, 500)
            context_parts.append(f"[Value: {value:.2f}] {content}")
        
        return "\n---\n".join(context_parts)
    
    def _build_causal_context(self, goal: str, inputs: Dict) -> str:
        """Build causal knowledge context."""
        if not self.config.enable_causal_learning:
            return "No causal knowledge available."
        
        # Get relevant causal links
        query = goal + " " + str(inputs.get('proposed_action', ''))
        causal_links = self.memory.retrieve_causal(query, inputs)
        
        if not causal_links:
            return "No relevant causal knowledge."
        
        parts = []
        for link in causal_links:
            parts.append(f"BECAUSE: {link.cause}\nTHEREFORE: {link.effect}\n(Confidence: {link.confidence:.2f})")
        
        return "\n---\n".join(parts)
    
    def _get_shared_insights(self) -> str:
        """
        Get insights shared by other agents.
        
        🎯 NO HARDCODED  - Returns ALL relevant insights!
        Let context manager handle sizing if needed.
        """
        if not self.config.enable_agent_communication:
            return ""
        
        messages = self.scratchpad.get_messages_for(self.agent_name)
        
        insights = []
        for msg in messages:
            if msg.message_type == CommunicationType.INSIGHT:
                insights.append(f"[{msg.sender}]: {msg.insight}")
            elif msg.message_type == CommunicationType.WARNING:
                insights.append(f"[WARNING from {msg.sender}]: {msg.content}")
        
        if not insights:
            return "No shared insights."
        
        # Return ALL insights, not just last 5!
        # If this gets too large, _smart_truncate will handle it
        return "\n".join(insights)
    
    def _share_insight(self, insight: str):
        """Share insight with other agents."""
        if not self.config.enable_agent_communication:
            return
        
        message = AgentMessage(
            sender=self.agent_name,
            receiver="*",
            message_type=CommunicationType.INSIGHT,
            content={"insight": insight},
            insight=insight,
            confidence=self.config.default_confidence_insight_share  # ✅ FROM CONFIG! (was 0.7)
        )
        self.scratchpad.add_message(message)
    
    def _check_required_fields(self, result: Any) -> List[str]:
        """Check if result has all required fields, return list of missing ones."""
        missing = []
        
        # Common required fields
        if not hasattr(result, 'reasoning') or not result.reasoning:
            missing.append('reasoning')
        if not hasattr(result, 'confidence'):
            missing.append('confidence')
        
        if self.is_architect:
            # Architect required fields (NO should_proceed - Architect is advisor, not gatekeeper!)
            # Note: should_proceed was intentionally removed from ArchitectSignature
            pass
        else:
            # Auditor required fields
            if not hasattr(result, 'is_valid'):
                missing.append('is_valid')
            if not hasattr(result, 'output_tag'):
                missing.append('output_tag')
        
        return missing
    
    def _parse_result(self, result: Any, round: ValidationRound, start_time: float) -> ValidationResult:
        """Parse DSPy result into ValidationResult with all fields for memory/RL/reflection."""
        # Extract common fields with defaults
        reasoning = getattr(result, 'reasoning', '') or ''
        try:
            raw_conf = getattr(result, 'confidence', 0.5)
        except Exception:
            # Some DSPy wrappers attempt eager type coercion on attribute access.
            raw_conf = None
            try:
                store = getattr(result, '_store', {}) or {}
                raw_conf = store.get('confidence', None)
            except Exception:
                raw_conf = None
            if raw_conf is None:
                raw_conf = 0.5
        try:
            confidence = float(raw_conf or 0.5)
        except (TypeError, ValueError):
            # Some LLMs return rationale text in confidence; extract first numeric token safely.
            import re
            text = str(raw_conf or "")
            match = re.search(r"[-+]?\d*\.?\d+", text)
            if match:
                try:
                    confidence = float(match.group(0))
                except Exception:
                    confidence = 0.5
            else:
                confidence = 0.5
        confidence = max(0.0, min(1.0, confidence))
        
        # Extract insight for inter-agent sharing
        insight = getattr(result, 'insight_to_share', '') or ''
        if insight:
            self._share_insight(insight)
        
        if self.is_architect:
            # Extract Architect fields
            # 🔥 A-TEAM: Architect is an ADVISOR, not a gatekeeper - always proceed!
            should_proceed = True  # Architect advises, doesn't block
            
            # Get all instruction fields
            injected_context = getattr(result, 'injected_context', '') or ''
            injected_instructions = getattr(result, 'injected_instructions', '') or ''
            
            # 🎨 AGENT COMPLETION STATUS
            elapsed = time.time() - start_time
            logger.info(f"")
            logger.info(f"{'='*80}")
            logger.info(f"🔍 Architect Agent: {self.agent_name} - COMPLETE")
            logger.info(f"💡 Advisor: Provided recommendations (Architect doesn't block)")
            logger.info(f"💪 Confidence: {confidence:.2f}")
            logger.info(f"⏱️  Duration: {elapsed:.2f}s")
            logger.info(f"{'='*80}")
            logger.info(f"")
            
            return ValidationResult(
                agent_name=self.agent_name,
                is_valid=True,  # Architect always allows execution (advisor role)
                confidence=confidence,
                reasoning=reasoning,
                should_proceed=True,  # Always True for Architect (advisor, not gatekeeper)
                injected_context=injected_context,
                injected_instructions=injected_instructions,
                validation_round=round,
                reasoning_steps=reasoning.split('\n') if reasoning else [],
                reasoning_quality=min(1.0, len(reasoning) / 500)
            )
        else:
            # Extract Auditor fields
            is_valid = getattr(result, 'is_valid', True)
            if isinstance(is_valid, str):
                is_valid = is_valid.lower() in ('true', 'yes', '1', 'valid')
            
            # Parse output tag
            tag_str = getattr(result, 'output_tag', 'useful') or 'useful'
            tag_str = tag_str.lower().strip()
            try:
                output_tag = OutputTag(tag_str)
            except ValueError:
                output_tag = OutputTag.USEFUL if is_valid else OutputTag.FAIL
            
            # Get all Auditor fields
            why_useful = getattr(result, 'why_useful', '') or ''
            fix_instructions = getattr(result, 'fix_instructions', '') or ''
            output_name = getattr(result, 'output_name', '') or ''
            
            # 🎨 AGENT COMPLETION STATUS
            elapsed = time.time() - start_time
            decision_icon = "✅" if is_valid else "❌"
            logger.info(f"")
            logger.info(f"{'='*80}")
            logger.info(f"✅ Auditor Agent: {self.agent_name} - COMPLETE")
            logger.info(f"{decision_icon} Decision: {'VALID' if is_valid else 'INVALID'}")
            logger.info(f"💪 Confidence: {confidence:.2f}")
            logger.info(f"🏷️  Tag: {output_tag.value}")
            logger.info(f"⏱️  Duration: {elapsed:.2f}s")
            logger.info(f"{'='*80}")
            logger.info(f"")
            
            return ValidationResult(
                agent_name=self.agent_name,
                is_valid=is_valid,
                confidence=confidence,
                reasoning=reasoning,
                output_tag=output_tag,
                why_useful=why_useful if is_valid else fix_instructions,
                validation_round=round,
                reasoning_steps=reasoning.split('\n') if reasoning else [],
                reasoning_quality=min(1.0, len(reasoning) / 500)
            )
    
    def _store_experience(self, goal: str, inputs: Dict, result: ValidationResult):
        """
        Store experience in memory.
        
        🎯 NO HARDCODED TRUNCATION - Store FULL reasoning!
        Memory system handles deduplication and prioritization.
        """
        # Format experience WITHOUT arbitrary truncation
        if self.is_architect:
            content = f"""
Architect Advisor: Provided recommendations (Architect doesn't block)
Confidence: {result.confidence:.2f}
Proposed Action: {inputs.get('proposed_action', 'N/A')}
Reasoning: {result.reasoning}
""".strip()
        else:
            # Get full result string (no  truncation!)
            action_result = str(inputs.get('action_result', 'N/A'))
            content = f"""
Auditor Decision: {'VALID' if result.is_valid else 'INVALID'}
Tag: {result.output_tag.value if result.output_tag else 'N/A'}
Confidence: {result.confidence:.2f}
Result: {action_result}
Reasoning: {result.reasoning}
""".strip()
        
        # Initial value based on confidence
        initial_value = 0.5 + 0.3 * (result.confidence - 0.5)
        
        # Store with FULL context (no  truncation!)
        self.memory.store(
            content=content,
            level=MemoryLevel.EPISODIC,
            context={
                'goal': goal,
                'inputs': {k: str(v) for k, v in inputs.items()},  # ✅ Full values!
                'round': result.validation_round.value
            },
            goal=goal,
            initial_value=initial_value
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics."""
        return {
            "agent_name": self.agent_name,
            "is_architect": self.is_architect,
            "total_calls": self.total_calls,
            "total_approvals": self.total_approvals,
            "approval_rate": self.total_approvals / max(1, self.total_calls),
            "memory_stats": self.memory.get_statistics()
        }


# =============================================================================
# MULTI-ROUND VALIDATION ORCHESTRATOR
# =============================================================================

class MultiRoundValidator:
    """
    Orchestrates multi-round validation with refinement.
    
    Process:
    1. Initial round: All agents vote independently
    2. Check for disagreement or low confidence
    3. If needed: Share insights, run refinement round
    4. Final decision based on all rounds
    """
    
    def __init__(self, agents: List[InspectorAgent], config: SynapseConfig):
        self.agents = agents
        self.config = config
        # Negotiation module: used when auditor blocks after retries exhausted
        # Actor and auditor reasoning are weighed to determine if rejection is truly blocking
        self._negotiation = dspy.ChainOfThought(AuditorActorNegotiationSignature)
    
    async def validate(self,
                       goal: str,
                       inputs: Dict[str, Any],
                       trajectory: List[Dict],
                       is_architect: bool) -> Tuple[List[ValidationResult], bool]:
        """
        Run multi-round validation.
        
        Returns:
            (all_results, combined_decision)
        """
        all_results = []
        
        # Round 1: Initial validation
        initial_results = []
        for agent in self.agents:
            result = await agent.run(goal, inputs, trajectory, ValidationRound.INITIAL)
            initial_results.append(result)
            all_results.append(result)
        
        # Check if refinement needed
        needs_refinement = self._needs_refinement(initial_results, is_architect)
        
        if needs_refinement and self.config.enable_multi_round:
            # Build feedback from initial results
            feedback = self._build_feedback(initial_results)
            
            # Run refinement round
            for i, agent in enumerate(self.agents):
                if initial_results[i].confidence < self.config.refinement_on_low_confidence:
                    refined = await agent.refine(
                        initial_results[i],
                        feedback,
                        additional_context="Other agents' reasoning and insights are available."
                    )
                    all_results.append(refined)
                    # Use refined result
                    initial_results[i] = refined
        
        # ═══════════════════════════════════════════════════════════════════
        # DIRECT VOTING — No vote flipping, no secondary LLM override.
        # ═══════════════════════════════════════════════════════════════════
        # Auditor's decision is RESPECTED as-is. If there's a disagreement
        # between actor and auditor, it's handled via negotiation in
        # synapse_core.py (AuditorActorNegotiationSignature) — not here.
        # This prevents the infinite retry loop caused by a secondary LLM
        # overriding the auditor's carefully contextualized verdict.
        # ═══════════════════════════════════════════════════════════════════
        
        if is_architect:
            # Architect is advisor, not gatekeeper — always proceed
            combined = True
        else:
            # Auditor voting: weighted by confidence
            # If ANY validator has a confident rejection (confidence > 0.5), BLOCK
            confident_rejections = [
                r for r in all_results
                if not r.is_valid and r.confidence > 0.5
            ]
            
            if confident_rejections:
                combined = False
                logger.info(f"🛑 [VOTING] Blocked: {len(confident_rejections)} confident rejection(s). "
                           f"Top: {confident_rejections[0].agent_name} "
                           f"(conf={confident_rejections[0].confidence:.2f})")
            elif all(r.is_valid for r in all_results):
                combined = True
                logger.info(f"✅ [VOTING] All validators agree: PASS")
            else:
                # Mixed results, no confident rejection → weighted average
                total_weight = sum(r.confidence for r in all_results)
                if total_weight == 0:
                    combined = any(r.is_valid for r in all_results)
                else:
                    weighted_valid = sum(
                        r.confidence if r.is_valid else 0
                        for r in all_results
                    ) / total_weight
                    combined = weighted_valid > 0.5
                logger.info(f"📊 [VOTING] Mixed results → weighted average: combined={combined}")
        
        return all_results, combined
    
    def _needs_refinement(self, results: List[ValidationResult], is_architect: bool) -> bool:
        """Check if refinement round is needed."""
        # Low confidence
        if any(r.confidence < self.config.refinement_on_low_confidence for r in results):
            return True
        
        # Disagreement
        if self.config.refinement_on_disagreement:
            if is_architect:
                # Architect is advisor - check confidence disagreement instead
                confidences = [r.confidence for r in results]
                if confidences and max(confidences) - min(confidences) > 0.3:  # Significant confidence spread
                    return True
            else:
                decisions = [r.is_valid for r in results]
                if len(set(decisions)) > 1:
                    return True
        
        return False
    
    def _build_feedback(self, results: List[ValidationResult]) -> str:
        """
        Build feedback summary for refinement.
        
        🎯 NO HARDCODED  - Include FULL reasoning for refinement!
        """
        parts = []
        for r in results:
            if hasattr(r, 'should_proceed') and r.should_proceed is not None:
                # Architect case - they're advisors, not blockers
                decision = "advisor recommendation" if r.should_proceed else "block"
            else:
                # Auditor case
                decision = "valid" if r.is_valid else "invalid"
            # Include FULL reasoning, not truncated 
            parts.append(f"{r.agent_name}: {decision} (confidence: {r.confidence:.2f})\nReasoning: {r.reasoning}")
        
        return "\n---\n".join(parts)

    async def negotiate_consensus(
        self,
        task_description: str,
        actor_output_summary: str,
        actor_reasoning: str,
        auditor_results: List[ValidationResult],
        retry_count: int,
        trajectory_summary: str = "",
    ) -> Dict[str, Any]:
        """
        Negotiate consensus between actor and auditor when retries are exhausted.

        Instead of brittle vote-flipping or hardcoded confidence thresholds,
        this method uses an LLM to weigh both sides' reasoning and determine
        whether the rejection is a genuine blocker or an acceptable deviation.

        Returns:
            {
                "is_truly_blocking": bool,
                "consensus_reasoning": str,
                "recommended_action": str,  # 'accept_with_caveat' | 'retry_with_guidance' | 'abandon_task'
            }
        """
        # Aggregate auditor reasoning and confidence
        auditor_reasonings = []
        avg_confidence = 0.5
        for r in auditor_results:
            auditor_reasonings.append(
                f"[{r.agent_name}] valid={r.is_valid}, confidence={r.confidence:.2f}: {r.reasoning or 'No reasoning'}"
            )
            avg_confidence = r.confidence  # Last result is most relevant

        combined_auditor_reasoning = "\n".join(auditor_reasonings)

        try:
            result = self._negotiation(
                task_description=task_description,
                actor_output_summary=actor_output_summary[:2000],
                actor_reasoning=actor_reasoning[:2000],
                auditor_rejection_reasoning=combined_auditor_reasoning[:3000],
                auditor_confidence=avg_confidence,
                retry_count=retry_count,
                trajectory_summary=trajectory_summary[:1500],
            )

            # Parse is_truly_blocking safely
            raw_blocking = getattr(result, "is_truly_blocking", True)
            if isinstance(raw_blocking, str):
                is_blocking = raw_blocking.strip().lower() in ("true", "1", "yes")
            else:
                is_blocking = bool(raw_blocking)

            consensus_reasoning = getattr(result, "consensus_reasoning", "") or ""
            recommended_action = getattr(result, "recommended_action", "retry_with_guidance") or "retry_with_guidance"

            # Normalize recommended_action
            action_lower = recommended_action.strip().lower()
            if "accept" in action_lower:
                recommended_action = "accept_with_caveat"
            elif "abandon" in action_lower:
                recommended_action = "abandon_task"
            else:
                recommended_action = "retry_with_guidance"

            logger.info(
                f"🤝 [NEGOTIATION] is_blocking={is_blocking}, action={recommended_action}, "
                f"reasoning={consensus_reasoning[:200]}"
            )

            return {
                "is_truly_blocking": is_blocking,
                "consensus_reasoning": consensus_reasoning,
                "recommended_action": recommended_action,
            }

        except Exception as e:
            logger.warning(f"⚠️ [NEGOTIATION] Failed: {e}. Defaulting to blocking.")
            return {
                "is_truly_blocking": True,
                "consensus_reasoning": f"Negotiation failed ({e}), defaulting to respect auditor rejection.",
                "recommended_action": "retry_with_guidance",
            }
