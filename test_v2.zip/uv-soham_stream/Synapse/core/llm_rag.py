"""
Synapse v6.0 - LLM-Based RAG System
=================================

NO EMBEDDING MODELS - Uses PURE LLM semantic matching.
NO KEYWORD MATCHING - Works with any language, code, or unique text.

Why no embeddings:
1. Embedding models fail on tricky/nuanced text
2. They miss context-dependent meaning
3. Can't reason about relevance
4. No interpretability

Why no keywords:
1. Multilingual text breaks keyword extraction
2. Code and technical terms don't match
3. Unique phrasing gets zero matches
4. Synonyms and paraphrases missed

Our approach:
1. Recency + Value pre-ranking (no content analysis)
2. Sliding window chunking (handles large content) - NOW UNIFIED!
3. PURE LLM semantic scoring (works for ANY text)
4. Budget-aware selection (no truncation)

🔴 A-TEAM UPDATE: Chunking logic extracted to unified_chunker.py
This module now imports from there for backward compatibility.
"""

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)
import hashlib

from .data_structures import (
    MemoryEntry, MemoryLevel, SynapseConfig,
    GoalHierarchy, GoalNode
)

# 🔴 A-TEAM FIX: Import from unified_chunker instead of defining here
from .unified_chunker import ContentChunk, SlidingWindowChunker as _UnifiedSlidingWindowChunker


# =============================================================================
# BACKWARD COMPATIBILITY WRAPPER
# =============================================================================

class SlidingWindowChunker(_UnifiedSlidingWindowChunker):
    """
    Backward compatibility wrapper for UnifiedChunker.
    
    🔴 A-TEAM: This just inherits from unified_chunker.SlidingWindowChunker.
    All logic is now in the unified module.
    """
    pass


# =============================================================================
# RECENCY + VALUE PRE-RANKER (NO KEYWORDS!)
# =============================================================================

class RecencyValueRanker:
    """
    LLM-based pre-selection using memory metadata (no heuristics).
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.selector = dspy.ChainOfThought(MemoryCandidateSelectorSignature) if DSPY_AVAILABLE else None
    
    def prerank(self, 
                memories: List[MemoryEntry],
                goal: str,
                max_candidates: int = 100) -> List[Tuple[MemoryEntry, float]]:
        """
        Select candidate memories using LLM over metadata.
        
        🔥 A-TEAM CRITICAL FIX: NO silent fallback!
        
        Raises:
            RuntimeError: If LLM is not configured
        """
        if not self.selector:
            raise RuntimeError(
                "❌ LLMRAGRetriever requires LLM intelligence!\n"
                "Memory selection is a critical agentic operation. "
                "Cannot fall back to returning empty list as it breaks retrieval. "
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))"
            )
        
        try:
            candidates = [
                {
                    "key": m.key,
                    "level": m.level.value,
                    "access_count": m.access_count,
                    "last_accessed": m.last_accessed.isoformat() if m.last_accessed else None,
                    "value": m.get_value(goal)
                }
                for m in memories
            ]
            result = self.selector(
                goal=goal,
                candidates=json.dumps(candidates, default=str),
                max_candidates=str(max_candidates)
            )
            selected = json.loads(getattr(result, "selected_keys", "[]"))
            selected_set = {k for k in selected if isinstance(k, str)}
            return [(m, 1.0) for m in memories if m.key in selected_set]
        except Exception as e:
            # 🔴 A-TEAM FIX: Log at WARNING, not DEBUG - silent failures caused
            # 0 retrieved memories for the entire session!
            # When LLM preranking fails, pass all memories through to the LLM scorer
            # (the scorer IS the intelligence layer - preranking is just an optimization)
            logger.warning(f"⚠️ LLM candidate preranking failed: {e} — passing all {len(memories)} memories to scorer")
            return [(m, 1.0) for m in memories[:max_candidates]]


class MemoryCandidateSelectorSignature(dspy.Signature):
    """
    Select candidate memories based on metadata for LLM scoring.
    """
    goal = dspy.InputField(desc="Current goal")
    candidates = dspy.InputField(desc="JSON list of memory metadata")
    max_candidates = dspy.InputField(desc="Maximum number of candidates to select")
    
    reasoning = dspy.OutputField(desc="Why these candidates were selected")
    selected_keys = dspy.OutputField(desc="JSON list of memory keys to include")


# =============================================================================
# LLM RELEVANCE SCORER (Pure Semantic - No Keywords!)
# =============================================================================

class RelevanceSignature(dspy.Signature):
    """Score relevance of memories to a query using pure semantic understanding."""
    
    query: str = dspy.InputField(desc="The current query/goal - can be ANY language or format")
    memory_batch: str = dspy.InputField(desc="Batch of memories to score (JSON)")
    context_hints: str = dspy.InputField(desc="Additional context about the task domain")
    
    reasoning: str = dspy.OutputField(desc="Step-by-step semantic analysis of each memory's relevance")
    scores: str = dspy.OutputField(desc="JSON dict mapping memory_key to relevance score 0.0-1.0")


class LLMRelevanceScorer:
    """
    PURE LLM semantic scoring - NO keywords, NO embeddings.
    
    Works with:
    - Any language (English, Japanese, Chinese, mixed)
    - Code snippets (Python, SQL, any syntax)
    - Technical jargon and domain-specific terms
    - Unique phrasing and synonyms
    - Metaphors and indirect references
    
    Examples of what keywords CANNOT handle but LLM CAN:
    
    1. Multilingual:
       Query: "日付の処理方法" (How to handle dates in Japanese)
       Memory: "Use DATE literal for Trino"
       Keywords: ZERO match
       LLM: 0.95 (understands both are about date handling)
    
    2. Code:
       Query: "def process_timestamp():"
       Memory: "DateTime columns need explicit casting"
       Keywords: ZERO match
       LLM: 0.85 (understands timestamp relates to DateTime)
    
    3. Synonyms:
       Query: "revenue by territory"
       Memory: "sales aggregation by region"
       Keywords: ZERO match
       LLM: 0.90 (revenue≈sales, territory≈region)
    
    4. Indirect:
       Query: "why is my query slow?"
       Memory: "Large tables need partition filters"
       Keywords: ZERO match
       LLM: 0.80 (understands missing filters cause slowness)
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.window_size = config.rag_window_size
        self.use_cot = config.rag_use_cot
        
        # Create the scorer agent
        if self.use_cot:
            self.scorer = dspy.ChainOfThought(RelevanceSignature)
        else:
            self.scorer = dspy.Predict(RelevanceSignature)
    
    def score_batch(self, query: str, memories: List[MemoryEntry],
                    context_hints: str = "") -> Dict[str, float]:
        """
        Score memories using PURE LLM semantic understanding.
        
        No keyword matching - the LLM understands meaning across:
        - Languages
        - Coding styles
        - Domain jargon
        - Synonyms and paraphrases
        """
        all_scores = {}
        
        # Process in windows
        for i in range(0, len(memories), self.window_size):
            batch = memories[i:i + self.window_size]
            
            # Format batch as JSON for LLM
            batch_data = []
            for mem in batch:
                batch_data.append({
                    "key": mem.key,
                    "content": mem.content,
                    "level": mem.level.value,
                    "value": round(mem.default_value, 2)
                })
            
            # Build context hints for semantic matching
            semantic_hints = context_hints or ""
            semantic_hints += """

IMPORTANT: Score based on SEMANTIC meaning, not keyword overlap.
- Consider synonyms (revenue = sales = income)
- Consider translations (日付 = date = fecha)
- Consider indirect relevance (slow query → missing index)
- Consider code meaning (def parse_date → date handling)

Score 0.9-1.0: Directly answers or highly relevant
Score 0.7-0.8: Related and useful context
Score 0.4-0.6: Tangentially related
Score 0.1-0.3: Weak connection
Score 0.0: Completely unrelated
"""
            
            try:
                result = self.scorer(
                    query=query,
                    memory_batch=json.dumps(batch_data, indent=2, ensure_ascii=False),
                    context_hints=semantic_hints
                )
                
                # Parse scores from response
                scores_text = result.scores
                
                from .robust_parsing import parse_json_robust
                batch_scores = parse_json_robust(scores_text)
                if isinstance(batch_scores, dict):
                    for key, score in batch_scores.items():
                        if isinstance(score, (int, float)):
                            all_scores[key] = max(0.0, min(1.0, float(score)))
                        else:
                            all_scores[key] = 0.5
                else:
                    for mem in batch:
                        all_scores[mem.key] = 0.5
                
            except Exception as e:
                # On error, use neutral score
                for mem in batch:
                    all_scores[mem.key] = 0.5
        
        return all_scores


# =============================================================================
# DEDUPLICATION ENGINE (Shannon Enhancement)
# =============================================================================

class DeduplicationSignature(dspy.Signature):
    """Check if two memories are semantically similar enough to merge."""
    
    memory_a: str = dspy.InputField(desc="First memory content")
    memory_b: str = dspy.InputField(desc="Second memory content")
    context: str = dspy.InputField(desc="Context about memory purpose")
    
    reasoning: str = dspy.OutputField(desc="Analysis of similarity")
    is_duplicate: bool = dspy.OutputField(desc="True if memories convey same information")
    similarity_score: float = dspy.OutputField(desc="Similarity 0.0-1.0")
    merged_content: str = dspy.OutputField(desc="If duplicate, the merged content preserving all info")


class DeduplicationEngine:
    """
    LLM-based deduplication to reduce memory redundancy.
    
    Why LLM over string similarity:
    1. Understands semantic equivalence
    2. Can merge information intelligently
    3. Preserves unique details from both
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.threshold = config.similarity_threshold
        self.checker = dspy.ChainOfThought(DeduplicationSignature)
    
    def check_duplicate(self, mem_a: MemoryEntry, mem_b: MemoryEntry) -> Tuple[bool, float, str]:
        """
        Check if two memories are duplicates.
        
        Returns:
            (is_duplicate, similarity, merged_content)
        """
        # Quick hash check first
        if mem_a.content_hash == mem_b.content_hash:
            return True, 1.0, mem_a.content
        
        # Quick length check (very different lengths unlikely duplicates)
        len_ratio = min(len(mem_a.content), len(mem_b.content)) / max(len(mem_a.content), len(mem_b.content))
        if len_ratio < 0.3:
            return False, len_ratio, ""
        
        try:
            result = self.checker(
                memory_a=mem_a.content,
                memory_b=mem_b.content,
                context=f"Memory level: {mem_a.level.value}, Agent: {mem_a.source_agent}"
            )
            
            is_dup = result.is_duplicate
            sim = float(result.similarity_score) if result.similarity_score else 0.0
            merged = result.merged_content if is_dup else ""
            
            return is_dup and sim >= self.threshold, sim, merged
            
        except Exception:
            return False, 0.0, ""
    
    def deduplicate_batch(self, memories: List[MemoryEntry]) -> List[MemoryEntry]:
        """
        Remove duplicates from a batch of memories.
        
        Returns deduplicated list with merged content.
        
        🔥 A-TEAM FIX: Skip deduplication for very large memories (>10KB)
        to prevent LLM context overflow and 400 Bad Request errors!
        """
        if len(memories) <= 1:
            return memories
        
        # 🔥 A-TEAM: Filter out huge memories that would cause LLM timeout
        MAX_MEMORY_SIZE = 10000  # 10KB limit
        normal_memories = []
        large_memories = []
        
        for mem in memories:
            if len(mem.content) > MAX_MEMORY_SIZE:
                large_memories.append(mem)
                logger.info(f"📦 Memory too large ({len(mem.content)} chars), skipping dedup for: {mem.key[:50]}...")
            else:
                normal_memories.append(mem)
        
        # Only deduplicate normal-sized memories
        if len(normal_memories) <= 1:
            return normal_memories + large_memories
        
        # Group by content hash first (exact duplicates)
        hash_groups: Dict[str, List[MemoryEntry]] = {}
        for mem in normal_memories:
            if mem.content_hash not in hash_groups:
                hash_groups[mem.content_hash] = []
            hash_groups[mem.content_hash].append(mem)
        
        # Keep one from each hash group (highest value)
        unique = []
        for group in hash_groups.values():
            best = max(group, key=lambda m: m.default_value)
            unique.append(best)
        
        # Now check semantic duplicates (more expensive)
        if len(unique) <= 1:
            return unique
        
        # Compare pairs (O(n²) but n is small after hash dedup)
        to_remove = set()
        for i, mem_a in enumerate(unique):
            if mem_a.key in to_remove:
                continue
            for j, mem_b in enumerate(unique[i+1:], i+1):
                if mem_b.key in to_remove:
                    continue
                
                is_dup, sim, merged = self.check_duplicate(mem_a, mem_b)
                
                if is_dup:
                    # Merge into the one with higher value
                    if mem_a.default_value >= mem_b.default_value:
                        mem_a.content = merged
                        mem_a.similar_entries.append(mem_b.key)
                        to_remove.add(mem_b.key)
                    else:
                        mem_b.content = merged
                        mem_b.similar_entries.append(mem_a.key)
                        to_remove.add(mem_a.key)
        
        # Return deduplicated normal memories + all large memories
        return [m for m in unique if m.key not in to_remove] + large_memories


# =============================================================================
# CAUSAL EXTRACTOR (Aristotle Enhancement)
# =============================================================================

class CausalExtractionSignature(dspy.Signature):
    """Extract causal relationships from episode experiences."""
    
    success_episodes: str = dspy.InputField(desc="Summary of successful episodes")
    failure_episodes: str = dspy.InputField(desc="Summary of failed episodes")
    domain_context: str = dspy.InputField(desc="Domain information")
    
    reasoning: str = dspy.OutputField(desc="Analysis of what caused success vs failure")
    causal_links: str = dspy.OutputField(desc="JSON list of {cause, effect, conditions, confidence}")


class CausalExtractor:
    """
    Extracts causal knowledge (WHY things work) from experiences.
    
    Moves beyond correlation to causation:
    - "DATE literal needed" (correlation)
    - "Trino parser requires type annotation for date columns" (causation)
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.extractor = dspy.ChainOfThought(CausalExtractionSignature)
        self.min_evidence = config.causal_min_support
    
    def extract_from_episodes(self, 
                               success_episodes: List[Dict],
                               failure_episodes: List[Dict],
                               domain: str = "sql") -> List[Dict]:
        """
        Extract causal links from contrasting episodes.
        """
        # Format episodes
        success_summary = self._summarize_episodes(success_episodes)
        failure_summary = self._summarize_episodes(failure_episodes)
        
        try:
            result = self.extractor(
                success_episodes=success_summary,
                failure_episodes=failure_summary,
                domain_context=f"Domain: {domain}. Extract root causes, not just correlations."
            )
            
            # Parse causal links
            links_text = result.causal_links
            
            from .robust_parsing import parse_json_robust
            links = parse_json_robust(links_text)
            if not isinstance(links, list):
                return []
            
            # Filter by confidence
            return [
                link for link in links 
                if link.get('confidence', 0) >= self.config.causal_confidence_threshold
            ]
            
        except Exception as e:
            return []
    
    def _summarize_episodes(self, episodes: List[Dict]) -> str:
        """Create summary of episodes for causal analysis."""
        if not episodes:
            return "No episodes"
        
        summaries = []
        for ep in episodes:  # Limit for context
            summary = f"Episode {ep.get('id', '?')}: "
            summary += f"Query: {ep.get('query', '?')}. "
            summary += f"Result: {ep.get('result', '?')}"
            summaries.append(summary)
        
        return "\n".join(summaries)


# =============================================================================
# MAIN LLM RAG RETRIEVER (PURE SEMANTIC)
# =============================================================================

class LLMRAGRetriever:
    """
    PURE LLM-based RAG - NO keywords, NO embeddings.
    
    Pipeline:
    1. Recency + Value pre-ranking (metadata only, no content analysis)
    2. Sliding window chunking (if needed)
    3. PURE LLM semantic scoring (works for ANY text/language)
    4. Deduplication (Shannon optimization)
    5. Budget-aware selection (no truncation)
    6. Goal-conditioned value blending (RL integration)
    
    Works with:
    - English, Japanese, Chinese, Spanish, any language
    - Mixed language text
    - Code (Python, SQL, JavaScript, etc.)
    - Technical documentation
    - Unique phrasing
    - Domain-specific jargon
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        
        self.chunker = SlidingWindowChunker(
            chunk_size=config.chunk_size,
            overlap=config.chunk_overlap
        )
        
        # NO keyword filter - use recency/value ranking instead
        self.preranker = RecencyValueRanker(config)
        
        # Pure LLM semantic scoring
        self.scorer = LLMRelevanceScorer(config)
        
        # Deduplication
        self.deduplicator = DeduplicationEngine(config)
    
    def retrieve(self,
                 query: str,
                 goal: str,
                 memories: List[MemoryEntry],
                 budget_tokens: int,
                 goal_hierarchy: Optional[GoalHierarchy] = None,
                 context_hints: str = "") -> List[MemoryEntry]:
        """
        Retrieve relevant memories using PURE LLM semantic matching.
        
        NO keyword matching - works for any language or content type.
        
        Parameters:
            query: The current query text (ANY language)
            goal: The goal for value lookup
            memories: All available memories
            budget_tokens: Token budget for memories
            goal_hierarchy: Optional hierarchy for knowledge transfer
            context_hints: Additional context for LLM scorer
        
        Returns:
            List of relevant memories that fit within budget
        """
        if not memories:
            logger.info(f"🧠 [RAG] No memories to retrieve from (empty pool)")
            return []
        
        logger.info(f"🧠 [RAG] Retrieving from {len(memories)} memories | query={query[:80]}... | goal={goal[:60]}...")
        
        # Step 1: Pre-rank by recency + value (NO content analysis)
        candidates = self.preranker.prerank(
            memories=memories,
            goal=goal,
            max_candidates=self.config.rag_max_candidates
        )
        
        if not candidates:
            logger.warning(f"⚠️ [RAG] Preranker returned 0 candidates from {len(memories)} memories — retrieval will be empty")
            return []
        
        # Step 2: PURE LLM semantic scoring
        candidate_memories = [m for m, _ in candidates]
        relevance_scores = self.scorer.score_batch(
            query=query,
            memories=candidate_memories,
            context_hints=context_hints
        )
        
        # Step 3: Use pure LLM relevance (no weighted heuristics)
        scored_memories = []
        for memory in candidate_memories:
            relevance = relevance_scores.get(memory.key, 0.0)
            scored_memories.append((memory, relevance))
        
        # Sort by LLM relevance score
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        
        # Step 4: Deduplication
        if self.config.enable_deduplication:
            unique_memories = self.deduplicator.deduplicate_batch(
                [m for m, _ in scored_memories]
            )
        else:
            unique_memories = [m for m, _ in scored_memories]
        
        # Step 5: Budget-aware selection (NO TRUNCATION)
        selected = []
        tokens_used = 0
        
        for memory in unique_memories:
            if tokens_used + memory.token_count <= budget_tokens:
                selected.append(memory)
                tokens_used += memory.token_count
        
        logger.info(
            f"🧠 [RAG] Retrieved {len(selected)}/{len(memories)} memories "
            f"| {tokens_used}/{budget_tokens} tokens used "
            f"| candidates={len(candidates)}, scored={len(scored_memories)}, deduped={len(unique_memories)}"
        )
        
        return selected
    
    def retrieve_with_chunks(self,
                             query: str,
                             goal: str,
                             large_content: str,
                             source_key: str,
                             budget_tokens: int) -> List[ContentChunk]:
        """
        Retrieve relevant chunks from large content using LLM scoring.
        """
        chunks = self.chunker.chunk_content(large_content, source_key)
        
        if not chunks:
            return []
        
        # Create temporary MemoryEntry objects for scoring
        temp_memories = []
        for chunk in chunks:
            temp_mem = MemoryEntry(
                key=f"{source_key}_chunk_{chunk.chunk_index}",
                content=chunk.content,
                level=MemoryLevel.EPISODIC,
                context={},
                token_count=chunk.token_count
            )
            temp_memories.append(temp_mem)
        
        # Score with LLM
        scores = self.scorer.score_batch(query, temp_memories)
        
        # Sort chunks by score
        chunk_scores = [(chunk, scores.get(f"{source_key}_chunk_{chunk.chunk_index}", 0.5)) 
                        for chunk in chunks]
        chunk_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Select within budget
        selected = []
        tokens_used = 0
        
        for chunk, score in chunk_scores:
            if tokens_used + chunk.token_count <= budget_tokens:
                selected.append(chunk)
                tokens_used += chunk.token_count
        
        # Sort selected by original order for coherence
        selected.sort(key=lambda c: c.chunk_index)
        
        return selected
