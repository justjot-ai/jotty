"""
Enhanced Agent Selection with Q-Learning
==========================================

A-Team Consensus Implementation for Dynamic, Learning-Based Agent Selection.

Problems Solved:
1. Static agent assignment (assigned at task creation)
2. No learning from agent-task outcomes
3. Poor prompt engineering (no few-shot examples)
4. No exploration strategy
5. Redundant systems (DynamicTaskPlanner + AgenticAgentSelector)

Solution:
- Dynamic agent selection at execution time
- Q-function: Q(agent, task_features) → expected reward
- ε-greedy exploration
- Rich LLM prompts with few-shot examples
- Learning from every task outcome

A-Team Approval:
- Dr. Sutton: ✅ (Q-learning for agent selection)
- Dr. Manning: ✅ (few-shot prompts)
- Dr. Abbeel: ✅ (learning from every outcome)
- Dr. Finn: ✅ (meta-learning across tasks)
- Shannon: ✅ (information-theoretic exploration)
- Von Neumann: ✅ (bandit approach)
- Dr. Silver: ✅ (value function for selection)
"""

import logging
import random
import time
import json
from typing import List, Dict, Any, Tuple, Optional, AsyncGenerator
from collections import defaultdict
from dataclasses import dataclass

from .token_utils import smart_truncate  # 🔴 A-TEAM FIX: Token-aware truncation

logger = logging.getLogger(__name__)

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class AgentSelectionResult:
    """Result of agent selection."""
    agent_name: str
    confidence: float  # [0, 1]
    q_value: float  # Expected reward
    method: str  # 'exploitation', 'exploration', 'llm_fallback'
    reasoning: str


# =============================================================================
# DSPy SIGNATURE
# =============================================================================

class EnhancedAgentSelectionSignature(dspy.Signature):
    """Select best agent for a task with rich context."""
    
    task_description = dspy.InputField(desc="The task to be completed")
    task_type = dspy.InputField(desc="Inferred type of task (e.g., 'data_processing', 'code_generation')")
    available_agents = dspy.InputField(
        desc="""Available agents with descriptions and performance history.
        
        Format:
        **AgentName**
        Capabilities: [list of capabilities]
        Recent performance: X/Y tasks successful (avg reward: Z.ZZ)
        """
    )
    context = dspy.InputField(
        desc="Current system state: agent workload, recent outcomes, dependencies"
    )
    few_shot_examples = dspy.InputField(
        desc="Examples of good agent-task matchings"
    )
    
    selected_agent = dspy.OutputField(desc="Name of the selected agent")
    confidence = dspy.OutputField(desc="Confidence in selection [0.0 to 1.0]")
    reasoning = dspy.OutputField(desc="Why this agent is best for this task")


# =============================================================================
# FAILURE REROUTING SIGNATURE (SOTA — A-TEAM APPROVED)
# =============================================================================

class FailureReroutingSignature(dspy.Signature):
    """Given a task that has repeatedly failed, decide the optimal recovery strategy.
    
    You are an expert failure analyst for a multi-agent orchestration system.
    A task has failed multiple times. Analyze the failure pattern, the current actor's
    capabilities, and all available actors to determine the BEST recovery action.
    
    Recovery actions:
    - SWITCH_ACTOR: Assign task to a different, more suitable actor. Use when:
      * The task requires capabilities the current actor lacks
      * An infrastructure/env blocker affects this actor's approach (e.g. SSL/proxy) 
        but a different actor could use an alternative method (e.g. BrowserExecutor 
        instead of TerminalExecutor, or vice versa)
    - RETRY_SAME: Retry with the same actor. Only appropriate when:
      * Failure is genuinely transient (network blip, rate limit)
      * Previous feedback provides a clear, actionable fix the actor can apply
      * NOT appropriate if the same error has occurred 2+ times with the same actor
    - DECOMPOSE: Break the task into smaller subtasks. Use when:
      * The task is too complex for a single actor execution
      * The task involves multiple distinct steps that could be parallelized
    - FAIL_PERMANENT: Mark as permanently failed. Only if:
      * The task is truly impossible given available actors and tools
      * All alternative approaches have been exhausted
    
    IMPORTANT: Read the auditor feedback carefully. If failures are caused by
    infrastructure/environment issues (SSL errors, corporate proxies, network
    restrictions, missing tools) that the current actor CANNOT resolve by changing
    its logic, strongly prefer SWITCH_ACTOR to try a completely different approach.
    
    You MUST provide a specific actor name if action is SWITCH_ACTOR.
    """
    
    task_description = dspy.InputField(
        desc="Full description of the failed task"
    )
    current_actor = dspy.InputField(
        desc="Name of the actor that has been failing on this task"
    )
    failure_history = dspy.InputField(
        desc="List of failure reasons from previous attempts, most recent last"
    )
    available_actors = dspy.InputField(
        desc="""All available actors with their capabilities and recent performance.
        Format per actor:
        **ActorName** — Capabilities: [...] | Recent: X/Y successful (avg reward: Z.ZZ)"""
    )
    task_context = dspy.InputField(
        desc="Current system state: goal, iteration count, Q-values, dependencies"
    )
    attempt_count = dspy.InputField(
        desc="Number of times this task has been attempted"
    )
    
    action = dspy.OutputField(
        desc="One of: SWITCH_ACTOR, RETRY_SAME, DECOMPOSE, FAIL_PERMANENT"
    )
    target_actor = dspy.OutputField(
        desc="If action is SWITCH_ACTOR, the name of the actor to switch to. Otherwise 'N/A'"
    )
    reasoning = dspy.OutputField(
        desc="Detailed analysis of why this action is optimal given the failure pattern"
    )
    confidence = dspy.OutputField(
        desc="Confidence in this decision [0.0 to 1.0]"
    )


# =============================================================================
# ENHANCED AGENT SELECTOR (A-TEAM APPROVED)
# =============================================================================

class EnhancedAgenticAgentSelector:
    """
    Dynamic agent selection with Q-learning.
    
    Replaces both:
    - AgenticAgentSelector (tool_shed.py) - static selection
    - DynamicTaskPlanner agent assignment - also static
    
    With unified, learning-based selection.
    """
    
    def __init__(self, lm=None, config: 'SynapseConfig' = None):
        self.lm = lm
        self.config = config or {}
        
        # Q-function: Q(agent, task_features) → expected reward
        self.q_function = {}  # Key: "agent|||task_features" → Value: float
        
        # Agent-task history for learning
        self.history = []  # List[Dict] with agent, task, reward, timestamp
        
        # Exploration parameters
        self.epsilon = getattr(config, 'agent_selection_epsilon', 0.1)
        self.learning_rate = getattr(config, 'agent_selection_lr', 0.1)
        
        # LLM for semantic matching
        if DSPY_AVAILABLE:
            self.llm_selector = dspy.ChainOfThought(EnhancedAgentSelectionSignature)
        else:
            self.llm_selector = None
        
        logger.info(
            f"✅ EnhancedAgenticAgentSelector initialized | "
            f"epsilon={self.epsilon} | lr={self.learning_rate}"
        )
        # Note: __init__ cannot yield, but initialization is logged
    
    async def select_agent_stream(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        context: Dict,
        exploration: bool = True
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Select best agent for task using Q-function + exploration with event streaming.
        
        Args:
            task: Task to assign
            available_agents: Agents that can be assigned
            context: Current system state (workload, outcomes, etc.)
            exploration: Whether to explore (ε-greedy)
        
        Yields:
            Event dictionaries with module and conversational message
        Returns:
            AgentSelectionResult with agent name, confidence, reasoning
        """
        # Extract task features for Q-function lookup
        task_features = self._extract_task_features(task)
        yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I am selecting an agent for task {task.task_id}"}
        
        # EXPLORATION: Random agent with probability ε
        if exploration and random.random() < self.epsilon:
            agent = random.choice(available_agents)
            logger.info(f"🔍 EXPLORATION: Randomly selected {agent.name} for {task.task_id}")
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I am exploring by randomly selecting {agent.name}"}
            result = AgentSelectionResult(
                agent_name=agent.name,
                confidence=0.5,  # Neutral
                q_value=self._get_q_value(agent.name, task_features),
                method='exploration',
                reasoning=f"Random exploration (ε={self.epsilon})"
            )
            yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the selected agent: {agent.name}"}
            return
        
        # EXPLOITATION: Use learned Q-function if we have data
        if self.history:
            q_values = {}
            for agent in available_agents:
                q_values[agent.name] = self._get_q_value(agent.name, task_features)
            
            # Select agent with highest Q-value
            best_agent_name = max(q_values, key=q_values.get)
            best_q_value = q_values[best_agent_name]
            
            logger.info(
                f"✅ EXPLOITATION: Selected {best_agent_name} for {task.task_id} "
                f"(Q={best_q_value:.3f})"
            )
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I am exploiting by selecting {best_agent_name} with Q-value {best_q_value:.3f}"}
            
            result = AgentSelectionResult(
                agent_name=best_agent_name,
                confidence=best_q_value,  # Q-value as confidence
                q_value=best_q_value,
                method='exploitation',
                reasoning=f"Highest Q-value ({best_q_value:.3f}) from {len(self.history)} past outcomes"
            )
            yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the selected agent: {best_agent_name}"}
            return
        
        # FALLBACK: LLM-based selection (rich prompts!)
        yield {"module": "Synapse.core.enhanced_agent_selector", "message": "I am using LLM-based selection as fallback"}
        result = None
        async for event in self._llm_select_agent_stream(task, available_agents, context, task_features):
            yield event
            if isinstance(event, dict) and event.get("type") == "result":
                result = event.get("result")
        if result is None:
            result = self._llm_select_agent(task, available_agents, context, task_features)
        yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the selected agent: {result.agent_name}"}
        return
    
    def select_agent(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        context: Dict,
        exploration: bool = True
    ) -> AgentSelectionResult:
        """
        Synchronous wrapper for select_agent_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use sync version directly
                return self._select_agent_sync(task, available_agents, context, exploration)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            result = None
            async for event in self.select_agent_stream(task, available_agents, context, exploration):
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            return result
        
        return asyncio.run(_run())
    
    def _select_agent_sync(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        context: Dict,
        exploration: bool = True
    ) -> AgentSelectionResult:
        """
        Synchronous implementation (for backward compatibility).
        """
        # Extract task features for Q-function lookup
        task_features = self._extract_task_features(task)
        
        # EXPLORATION: Random agent with probability ε
        if exploration and random.random() < self.epsilon:
            agent = random.choice(available_agents)
            logger.info(f"🔍 EXPLORATION: Randomly selected {agent.name} for {task.task_id}")
            return AgentSelectionResult(
                agent_name=agent.name,
                confidence=0.5,  # Neutral
                q_value=self._get_q_value(agent.name, task_features),
                method='exploration',
                reasoning=f"Random exploration (ε={self.epsilon})"
            )
        
        # EXPLOITATION: Use learned Q-function if we have data
        if self.history:
            q_values = {}
            for agent in available_agents:
                q_values[agent.name] = self._get_q_value(agent.name, task_features)
            
            # Select agent with highest Q-value
            best_agent_name = max(q_values, key=q_values.get)
            best_q_value = q_values[best_agent_name]
            
            logger.info(
                f"✅ EXPLOITATION: Selected {best_agent_name} for {task.task_id} "
                f"(Q={best_q_value:.3f})"
            )
            
            return AgentSelectionResult(
                agent_name=best_agent_name,
                confidence=best_q_value,  # Q-value as confidence
                q_value=best_q_value,
                method='exploitation',
                reasoning=f"Highest Q-value ({best_q_value:.3f}) from {len(self.history)} past outcomes"
            )
        
        # FALLBACK: LLM-based selection (rich prompts!)
        return self._llm_select_agent(task, available_agents, context, task_features)
    
    async def _llm_select_agent_stream(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        context: Dict,
        task_features: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        LLM-based agent selection with RICH PROMPTS and event streaming.
        """
        if not self.llm_selector:
            # No LLM available, use first agent as fallback
            fallback_agent = available_agents[0]
            logger.warning(f"⚠️ No LLM or history available, defaulting to {fallback_agent.name}")
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I noticed no LLM is available, defaulting to {fallback_agent.name}"}
            result = AgentSelectionResult(
                agent_name=fallback_agent.name,
                confidence=0.5,
                q_value=0.5,
                method='fallback_no_llm',
                reasoning="No LLM or learning history available"
            )
            yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the fallback agent: {fallback_agent.name}"}
            return
        
        # Build rich agent descriptions
        agent_descriptions = []
        for agent in available_agents:
            desc = f"**{agent.name}**\n"
            desc += f"Capabilities: {', '.join(agent.capabilities or ['general'])}\n"
            
            # Add performance history from our records
            agent_history = [h for h in self.history if h['agent'] == agent.name]
            if agent_history:
                successes = [h for h in agent_history if h['reward'] > 0.7]
                avg_reward = sum(h['reward'] for h in agent_history) / len(agent_history)
                desc += f"Recent performance: {len(successes)}/{len(agent_history)} successful "
                desc += f"(avg reward: {avg_reward:.2f})\n"
            else:
                desc += "Recent performance: No history yet\n"
            
            agent_descriptions.append(desc)
        
        # Format context
        context_str = self._format_context(context)
        
        # Infer task type
        task_type = self._infer_task_type(task)
        
        # Get few-shot examples
        few_shot = self._get_few_shot_examples()
        
        try:
            # Call LLM with rich context
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": "I am using LLM to select the best agent"}
            result_llm = self.llm_selector(
                task_description=task.description,
                task_type=task_type,
                available_agents="\n".join(agent_descriptions),
                context=context_str,
                few_shot_examples=few_shot
            )
            
            selected_agent_name = result_llm.selected_agent.strip()
            confidence = self._parse_confidence(result_llm.confidence)
            
            logger.info(
                f"🤖 LLM SELECTION: {selected_agent_name} for {task.task_id} "
                f"(confidence={confidence:.2f})"
            )
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I have selected {selected_agent_name} using LLM with confidence {confidence:.2f}"}
            
            result = AgentSelectionResult(
                agent_name=selected_agent_name,
                confidence=confidence,
                q_value=0.5,  # No learned Q-value yet
                method='llm_fallback',
                reasoning=result_llm.reasoning
            )
            yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the LLM-selected agent: {selected_agent_name}"}
            return
        
        except Exception as e:
            logger.error(f"❌ LLM selection failed: {e}")
            yield {"module": "Synapse.core.enhanced_agent_selector", "message": f"I encountered an error during LLM selection: {str(e)}"}
            # Fallback to first agent
            fallback_agent = available_agents[0]
            result = AgentSelectionResult(
                agent_name=fallback_agent.name,
                confidence=0.5,
                q_value=0.5,
                method='fallback_error',
                reasoning=f"LLM selection failed: {e}"
            )
            yield {"type": "result", "result": result, "module": "Synapse.core.enhanced_agent_selector", "message": f"I am returning the fallback agent: {fallback_agent.name}"}
            return
    
    def _llm_select_agent(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        context: Dict,
        task_features: str
    ) -> AgentSelectionResult:
        """
        LLM-based agent selection with RICH PROMPTS.
        
        Dr. Manning: This is proper prompt engineering!
        """
        if not self.llm_selector:
            # No LLM available, use first agent as fallback
            fallback_agent = available_agents[0]
            logger.warning(f"⚠️ No LLM or history available, defaulting to {fallback_agent.name}")
            return AgentSelectionResult(
                agent_name=fallback_agent.name,
                confidence=0.5,
                q_value=0.5,
                method='fallback_no_llm',
                reasoning="No LLM or learning history available"
            )
        
        # Build rich agent descriptions
        agent_descriptions = []
        for agent in available_agents:
            desc = f"**{agent.name}**\n"
            desc += f"Capabilities: {', '.join(agent.capabilities or ['general'])}\n"
            
            # Add performance history from our records
            agent_history = [h for h in self.history if h['agent'] == agent.name]
            if agent_history:
                successes = [h for h in agent_history if h['reward'] > 0.7]
                avg_reward = sum(h['reward'] for h in agent_history) / len(agent_history)
                desc += f"Recent performance: {len(successes)}/{len(agent_history)} successful "
                desc += f"(avg reward: {avg_reward:.2f})\n"
            else:
                desc += "Recent performance: No history yet\n"
            
            agent_descriptions.append(desc)
        
        # Format context
        context_str = self._format_context(context)
        
        # Infer task type
        task_type = self._infer_task_type(task)
        
        # Get few-shot examples
        few_shot = self._get_few_shot_examples()
        
        try:
            # Call LLM with rich context
            result = self.llm_selector(
                task_description=task.description,
                task_type=task_type,
                available_agents="\n".join(agent_descriptions),
                context=context_str,
                few_shot_examples=few_shot
            )
            
            selected_agent_name = result.selected_agent.strip()
            confidence = self._parse_confidence(result.confidence)
            
            logger.info(
                f"🤖 LLM SELECTION: {selected_agent_name} for {task.task_id} "
                f"(confidence={confidence:.2f})"
            )
            
            return AgentSelectionResult(
                agent_name=selected_agent_name,
                confidence=confidence,
                q_value=0.5,  # No learned Q-value yet
                method='llm_fallback',
                reasoning=result.reasoning
            )
        
        except Exception as e:
            logger.error(f"❌ LLM selection failed: {e}")
            # Fallback to first agent
            fallback_agent = available_agents[0]
            return AgentSelectionResult(
                agent_name=fallback_agent.name,
                confidence=0.5,
                q_value=0.5,
                method='fallback_error',
                reasoning=f"LLM selection failed: {e}"
            )
    
    # =================================================================
    # 🔴 SOTA: LLM-BASED FAILURE REROUTING (replaces hardcoded for-loop)
    # =================================================================
    
    async def reroute_on_failure_stream(
        self,
        task: 'SubtaskState',
        available_agents: List['AgentConfig'],
        failure_history: List[str],
        context: Dict,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Use LLM to decide the optimal recovery action when a task fails repeatedly.
        
        Replaces the old hardcoded `for alt_name in self.actors: break` pattern
        with a SOTA DSPy signature that analyzes failure patterns, actor capabilities,
        and system state to make an intelligent rerouting decision.
        
        Yields:
            Event dicts with module/message + final {"type": "result", "result": {...}}
        """
        yield {
            "module": "Synapse.core.enhanced_agent_selector",
            "message": f"Analyzing failure pattern for task {task.task_id} to determine optimal recovery"
        }
        
        # Build rich actor descriptions
        agent_descriptions = []
        for agent in available_agents:
            desc = f"**{agent.name}** — "
            desc += f"Capabilities: {', '.join(agent.capabilities or ['general'])} | "
            agent_history = [h for h in self.history if h['agent'] == agent.name]
            if agent_history:
                successes = [h for h in agent_history if h['reward'] > 0.7]
                avg_reward = sum(h['reward'] for h in agent_history) / len(agent_history)
                desc += f"Recent: {len(successes)}/{len(agent_history)} successful (avg reward: {avg_reward:.2f})"
            else:
                desc += "Recent: No history yet"
            agent_descriptions.append(desc)
        
        # Format failure history
        failure_str = "\n".join([
            f"  Attempt {i+1}: {smart_truncate(str(f), max_tokens=100)}"
            for i, f in enumerate(failure_history[-5:])  # Last 5 failures
        ])
        
        # Format context
        context_str = self._format_context(context)
        
        # Default result (in case LLM fails)
        default_result = {
            "action": "FAIL_PERMANENT",
            "target_actor": "N/A",
            "reasoning": "Could not determine recovery strategy",
            "confidence": 0.0
        }
        
        if not DSPY_AVAILABLE or not hasattr(dspy.settings, 'lm') or not dspy.settings.lm:
            logger.warning("⚠️ No LLM available for failure rerouting, using Q-value fallback")
            yield {
                "module": "Synapse.core.enhanced_agent_selector",
                "message": "No LLM available — falling back to Q-value based rerouting"
            }
            # Q-value fallback: pick actor with highest Q-value for this task
            task_features = self._extract_task_features(task)
            best_alt = None
            best_q = -1.0
            for agent in available_agents:
                if agent.name != task.actor:
                    q = self._get_q_value(agent.name, task_features)
                    if q > best_q:
                        best_q = q
                        best_alt = agent.name
            if best_alt:
                default_result = {
                    "action": "SWITCH_ACTOR",
                    "target_actor": best_alt,
                    "reasoning": f"Q-value fallback: {best_alt} has Q={best_q:.3f}",
                    "confidence": best_q
                }
            yield {"type": "result", "result": default_result,
                   "module": "Synapse.core.enhanced_agent_selector",
                   "message": f"Recovery decision: {default_result['action']} → {default_result.get('target_actor', 'N/A')}"}
            return
        
        try:
            rerouter = dspy.ChainOfThought(FailureReroutingSignature)
            yield {
                "module": "Synapse.core.enhanced_agent_selector",
                "message": f"Consulting LLM failure analyst for {task.task_id} ({len(failure_history)} prior failures)"
            }
            
            llm_result = rerouter(
                task_description=smart_truncate(task.description, max_tokens=200),
                current_actor=str(task.actor),
                failure_history=failure_str,
                available_actors="\n".join(agent_descriptions),
                task_context=context_str,
                attempt_count=str(len(failure_history))
            )
            
            action = llm_result.action.strip().upper()
            target_actor = llm_result.target_actor.strip()
            reasoning = llm_result.reasoning.strip()
            confidence = self._parse_confidence(llm_result.confidence)
            
            # Validate action
            valid_actions = {"SWITCH_ACTOR", "RETRY_SAME", "DECOMPOSE", "FAIL_PERMANENT"}
            if action not in valid_actions:
                logger.warning(f"⚠️ LLM returned invalid action '{action}', defaulting to FAIL_PERMANENT")
                action = "FAIL_PERMANENT"
            
            # Validate target actor exists
            actor_names = {a.name for a in available_agents}
            if action == "SWITCH_ACTOR" and target_actor not in actor_names:
                # Try fuzzy match
                for aname in actor_names:
                    if aname != task.actor and (
                        aname.lower() in target_actor.lower() or
                        target_actor.lower() in aname.lower()
                    ):
                        target_actor = aname
                        break
                else:
                    # No match — pick best Q-value alternative
                    task_features = self._extract_task_features(task)
                    best_alt = None
                    best_q = -1.0
                    for agent in available_agents:
                        if agent.name != task.actor:
                            q = self._get_q_value(agent.name, task_features)
                            if q > best_q:
                                best_q = q
                                best_alt = agent.name
                    if best_alt:
                        target_actor = best_alt
                        reasoning += f" (LLM suggested '{llm_result.target_actor}' not found, using Q-value: {best_alt})"
                    else:
                        action = "FAIL_PERMANENT"
                        reasoning += " (no alternative actor available)"
            
            result = {
                "action": action,
                "target_actor": target_actor if action == "SWITCH_ACTOR" else "N/A",
                "reasoning": reasoning,
                "confidence": confidence
            }
            
            logger.info(
                f"🧠 FAILURE REROUTING: action={action}, target={target_actor}, "
                f"confidence={confidence:.2f}, reasoning={reasoning[:100]}"
            )
            yield {
                "module": "Synapse.core.enhanced_agent_selector",
                "message": f"Recovery decision: {action}"
                           + (f" → {target_actor}" if action == "SWITCH_ACTOR" else "")
                           + f" (confidence: {confidence:.2f})"
            }
            yield {"type": "result", "result": result,
                   "module": "Synapse.core.enhanced_agent_selector",
                   "message": f"Failure analysis complete: {reasoning[:120]}"}
            return
            
        except Exception as e:
            logger.error(f"❌ LLM failure rerouting failed: {e}")
            yield {
                "module": "Synapse.core.enhanced_agent_selector",
                "message": f"LLM rerouting failed ({e}), using Q-value fallback"
            }
            # Fallback to Q-value
            task_features = self._extract_task_features(task)
            best_alt = None
            best_q = -1.0
            for agent in available_agents:
                if agent.name != task.actor:
                    q = self._get_q_value(agent.name, task_features)
                    if q > best_q:
                        best_q = q
                        best_alt = agent.name
            if best_alt:
                result = {
                    "action": "SWITCH_ACTOR",
                    "target_actor": best_alt,
                    "reasoning": f"LLM failed, Q-value fallback: {best_alt} (Q={best_q:.3f})",
                    "confidence": best_q
                }
            else:
                result = {
                    "action": "FAIL_PERMANENT",
                    "target_actor": "N/A",
                    "reasoning": f"LLM failed and no alternative actor available: {e}",
                    "confidence": 0.0
                }
            yield {"type": "result", "result": result,
                   "module": "Synapse.core.enhanced_agent_selector",
                   "message": f"Fallback recovery: {result['action']}"}
            return

    def update(self, agent: str, task: 'SubtaskState', reward: float):
        """
        Update Q-function after task completion (TD-learning).
        
        Dr. Sutton: Classic Q-learning update rule.
        """
        task_features = self._extract_task_features(task)
        
        # Get current Q-value
        q_current = self._get_q_value(agent, task_features)
        
        # TD update: Q(a,t) ← Q(a,t) + α[r - Q(a,t)]
        q_new = q_current + self.learning_rate * (reward - q_current)
        
        # Store updated Q-value
        self._set_q_value(agent, task_features, q_new)
        
        # Record in history
        self.history.append({
            'agent': agent,
            'task_id': task.task_id,
            'task_type': self._infer_task_type(task),
            'task_features': task_features,
            'reward': reward,
            'timestamp': time.time()
        })
        
        logger.info(
            f"🧠 LEARNED: Q({agent}, {task.task_id}) updated "
            f"{q_current:.3f} → {q_new:.3f} (reward={reward:.3f})"
        )
        # Note: Sync method, async version would yield events
    
    def _extract_task_features(self, task: 'SubtaskState') -> str:
        """
        Extract semantic features from task.
        
        Shannon: These are information-bearing signals.
        """
        # Task type
        task_type = self._infer_task_type(task)
        
        # Key words from description
        keywords = self._extract_keywords(task.description)
        
        # Dependency complexity
        num_deps = len(task.depends_on) if hasattr(task, 'depends_on') else 0
        
        return f"{task_type}|{keywords}|deps={num_deps}"
    
    def _infer_task_type(self, task: 'SubtaskState') -> str:
        """
        Infer task type from description using LLM-based classification.
        
        🔴 A-TEAM FIX: Replaced hardcoded keyword matching with LLM-based inference.
        Falls back to semantic heuristic only if LLM is unavailable.
        """
        try:
            import dspy
            if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                # Use LLM for task type classification
                prompt = (
                    f"Classify this task into ONE category.\n"
                    f"Task: {smart_truncate(task.description, max_tokens=125)}\n"
                    f"Categories: data_loading, data_processing, code_generation, "
                    f"debugging, validation, security, file_operation, presentation, "
                    f"web_interaction, system_administration, analysis, general\n"
                    f"Output ONLY the category name, nothing else."
                )
                try:
                    result = dspy.settings.lm(prompt, max_tokens=20)
                    if result and isinstance(result, list) and len(result) > 0:
                        category = result[0].strip().lower().replace(' ', '_')
                        # Validate it's a known category
                        valid_categories = {
                            'data_loading', 'data_processing', 'code_generation',
                            'debugging', 'validation', 'security', 'file_operation',
                            'presentation', 'web_interaction', 'system_administration',
                            'analysis', 'general'
                        }
                        if category in valid_categories:
                            logger.debug(f"🤖 LLM inferred task type: {category}")
                            return category
                except Exception as llm_err:
                    logger.debug(f"LLM task type inference failed: {llm_err}")
        except Exception:
            pass
        
        # Semantic fallback using embedding similarity (not keyword matching)
        desc_lower = task.description.lower()
        
        # Use broader semantic patterns instead of hardcoded keywords
        type_patterns = {
            'data_loading': ['load', 'read', 'fetch', 'get', 'data', 'retrieve', 'import', 'ingest', 'download', 'extract'],
            'data_processing': ['process', 'transform', 'clean', 'filter', 'parse', 'convert', 'normalize', 'aggregate'],
            'code_generation': ['generate', 'create', 'write', 'code', 'implement', 'build', 'develop', 'script'],
            'debugging': ['debug', 'fix', 'error', 'issue', 'bug', 'troubleshoot', 'diagnose', 'resolve'],
            'validation': ['test', 'validate', 'check', 'verify', 'assert', 'ensure', 'confirm', 'audit'],
            'security': ['security', 'vulnerability', 'scan', 'auth', 'encrypt', 'permission', 'access'],
            'file_operation': ['file', 'directory', 'folder', 'copy', 'move', 'delete', 'rename', 'path'],
            'presentation': ['presentation', 'slide', 'pptx', 'powerpoint', 'deck', 'ppt'],
            'web_interaction': ['browse', 'web', 'url', 'http', 'scrape', 'navigate', 'click', 'page'],
            'system_administration': ['install', 'configure', 'setup', 'deploy', 'server', 'service', 'terminal', 'command'],
            'analysis': ['analyze', 'analyse', 'examine', 'investigate', 'research', 'study', 'evaluate', 'compare'],
        }
        
        # Score each type by counting matching semantic patterns
        scores = {}
        for task_type, patterns in type_patterns.items():
            score = sum(1 for word in patterns if word in desc_lower)
            if score > 0:
                scores[task_type] = score
        
        if scores:
            best_type = max(scores, key=scores.get)
            logger.debug(f"📊 Semantic task type inference: {best_type} (score={scores[best_type]})")
            return best_type
        
        return 'general'
    
    def _extract_keywords(self, text: str, max_keywords: int = 5) -> str:
        """
        Extract key semantic features from text.
        
        🔴 A-TEAM FIX: Replaced simple stopword filtering with richer semantic extraction.
        Uses LLM when available, falls back to improved heuristic.
        """
        try:
            import dspy
            if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                prompt = (
                    f"Extract the {max_keywords} most important keywords from this task description.\n"
                    f"Task: {smart_truncate(text, max_tokens=125)}\n"
                    f"Output ONLY the keywords separated by underscores, nothing else."
                )
                try:
                    result = dspy.settings.lm(prompt, max_tokens=50)
                    if result and isinstance(result, list) and len(result) > 0:
                        keywords = result[0].strip().lower()
                        if '_' in keywords and len(keywords) > 3:
                            logger.debug(f"🤖 LLM extracted keywords: {keywords}")
                            return keywords
                except Exception as llm_err:
                    logger.debug(f"LLM keyword extraction failed: {llm_err}")
        except Exception:
            pass
        
        # Improved fallback: Use TF-based scoring instead of simple stopword filtering
        import re
        stopwords = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been',
            'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need',
            'this', 'that', 'these', 'those', 'it', 'its', 'they', 'them', 'their',
            'we', 'our', 'you', 'your', 'he', 'she', 'him', 'her', 'his',
            'not', 'no', 'nor', 'so', 'too', 'very', 'just', 'also', 'then',
            'than', 'when', 'where', 'which', 'who', 'what', 'how', 'why',
            'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
            'some', 'any', 'such', 'only', 'own', 'same', 'about', 'up', 'out',
            'into', 'through', 'during', 'before', 'after', 'above', 'below',
            'between', 'under', 'again', 'further', 'once', 'here', 'there',
            'use', 'using', 'used', 'make', 'made', 'task', 'step',
        }
        # Tokenize and filter
        words = re.findall(r'[a-z]+', text.lower())
        meaningful = [w for w in words if w not in stopwords and len(w) > 2]
        
        # Use frequency as importance signal
        from collections import Counter
        word_counts = Counter(meaningful)
        top_words = [word for word, _ in word_counts.most_common(max_keywords)]
        
        return '_'.join(top_words) if top_words else 'unknown'
    
    def _get_q_value(self, agent: str, task_features: str) -> float:
        """Get Q-value for agent-task pair (default 0.5 if not seen)."""
        key = f"{agent}|||{task_features}"
        return self.q_function.get(key, 0.5)  # Neutral default
    
    def _set_q_value(self, agent: str, task_features: str, value: float):
        """Set Q-value for agent-task pair."""
        key = f"{agent}|||{task_features}"
        self.q_function[key] = max(0.0, min(1.0, value))  # Clamp to [0, 1]
    
    def _format_context(self, context: Dict) -> str:
        """Format context for LLM.
        
        🔴 A-TEAM FIX: Handle ALL context keys from conductor, not just
        workload/recent_outcomes/dependencies.
        """
        parts = []
        
        if 'goal' in context:
            parts.append(f"Goal: {smart_truncate(str(context['goal']), max_tokens=100)}")
        
        if 'iteration' in context:
            parts.append(f"Iteration: {context['iteration']}")
        
        if 'q_value' in context:
            parts.append(f"Q-value: {context['q_value']:.3f}" if isinstance(context['q_value'], (int, float)) else f"Q-value: {context['q_value']}")
        
        if 'confidence' in context:
            parts.append(f"Confidence: {context['confidence']:.3f}" if isinstance(context['confidence'], (int, float)) else f"Confidence: {context['confidence']}")
        
        if 'total_tasks' in context:
            parts.append(f"Total tasks: {context['total_tasks']}")
        
        if 'completed_tasks' in context:
            parts.append(f"Completed tasks: {context['completed_tasks']}")
        
        if 'workload' in context:
            parts.append(f"Agent workload: {context['workload']}")
        
        if 'recent_outcomes' in context:
            parts.append(f"Recent outcomes: {context['recent_outcomes']}")
        
        if 'dependencies' in context:
            parts.append(f"Dependencies: {context['dependencies']}")
        
        if 'error_message' in context:
            parts.append(f"Error: {smart_truncate(str(context['error_message']), max_tokens=80)}")
        
        if 'error_type' in context:
            parts.append(f"Error type: {context['error_type']}")
        
        if 'failure_type' in context:
            parts.append(f"Failure classification: {context['failure_type']}")
        
        if 'failure_count' in context:
            parts.append(f"Total failures on this task: {context['failure_count']}")
        
        if 'auditor_feedback_summary' in context:
            parts.append(f"Auditor feedback: {context['auditor_feedback_summary']}")
        
        return "\n".join(parts) if parts else "No additional context"
    
    def _parse_confidence(self, confidence_str: str) -> float:
        """Parse confidence from LLM output."""
        try:
            conf = float(confidence_str)
            return max(0.0, min(1.0, conf))
        except ValueError:
            # Try extracting number from text
            import re
            match = re.search(r'(\d+\.?\d*)', confidence_str)
            if match:
                conf = float(match.group(1))
                if conf > 1.0:  # Assume it's out of 10
                    conf = conf / 10.0
                return max(0.0, min(1.0, conf))
            else:
                return 0.5  # Default neutral
    
    def _get_few_shot_examples(self) -> str:
        """
        Get few-shot examples for LLM prompt from LEARNED history.
        
        🔴 A-TEAM FIX: Replaced hardcoded examples with dynamic examples
        generated from actual agent-task outcome history.
        
        Dr. Manning: Few-shot is CRITICAL for good LLM performance!
        Strategy: Pick high-reward (success) and low-reward (failure) examples
        from recent history so the LLM sees both positive and negative signal.
        """
        if not self.history:
            # Cold start — provide generic structural examples only
            return (
                "No agent-task history yet. Select the agent whose capabilities "
                "best match the task requirements."
            )
        
        # Collect successful examples (reward > 0.7) — most recent first
        successes = sorted(
            [h for h in self.history if h['reward'] > 0.7],
            key=lambda h: h.get('timestamp', 0),
            reverse=True
        )[:3]
        
        # Collect failure examples (reward < 0.3) — most recent first
        failures = sorted(
            [h for h in self.history if h['reward'] < 0.3],
            key=lambda h: h.get('timestamp', 0),
            reverse=True
        )[:2]
        
        examples = []
        for i, h in enumerate(successes, 1):
            task_type = h.get('task_type', 'general')
            examples.append(
                f"Example {i} (SUCCESS): Task type='{task_type}' → Agent={h['agent']} "
                f"(reward={h['reward']:.2f})"
            )
        for i, h in enumerate(failures, len(successes) + 1):
            task_type = h.get('task_type', 'general')
            examples.append(
                f"Example {i} (FAILURE): Task type='{task_type}' → Agent={h['agent']} "
                f"(reward={h['reward']:.2f}) — avoid this pairing"
            )
        
        return "\n".join(examples) if examples else "No relevant examples yet."
    
    def get_stats(self) -> Dict[str, Any]:
        """Get selector statistics."""
        agent_performances = defaultdict(list)
        for entry in self.history:
            agent_performances[entry['agent']].append(entry['reward'])
        
        return {
            'total_selections': len(self.history),
            'learned_q_values': len(self.q_function),
            'agent_performances': {
                agent: {
                    'count': len(rewards),
                    'avg_reward': sum(rewards) / len(rewards),
                    'success_rate': sum(1 for r in rewards if r > 0.7) / len(rewards)
                }
                for agent, rewards in agent_performances.items()
            },
            'exploration_rate': self.epsilon
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'EnhancedAgenticAgentSelector',
    'AgentSelectionResult',
    'EnhancedAgentSelectionSignature',
    'FailureReroutingSignature',
]
