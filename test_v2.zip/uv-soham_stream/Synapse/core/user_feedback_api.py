"""
User Feedback API
=================

Simple API for users to provide reward feedback after task completion.

This is the CRITICAL MISSING FEATURE identified by the A-Team.

Usage:
------

### Scenario 1: Real-time feedback during execution

```python
from Synapse.core.conductor import Conductor
from Synapse.core.user_feedback_api import UserFeedback

conductor = Conductor(goal="Generate SQL query", ...)

# User provides feedback during execution
UserFeedback.rate_task(
    task_id="generate_sql",
    rating=9,  # Out of 10
    comment="SQL was correct but could be optimized"
)

result = conductor.run()
```

### Scenario 2: Post-execution feedback

```python
result = conductor.run()

# User reviews final result
if result.success:
    UserFeedback.rate_episode(
        episode_id=conductor.episode_id,
        rating=8.5,
        comment="Good solution, but could be faster"
    )
```

### Scenario 3: Batch feedback from file

```python
# Load feedback from CSV/JSON
UserFeedback.load_from_file("user_ratings.json")
```

A-Team Consensus:
-----------------
- Dr. Manning: ✅ (simple, clear API)
- Dr. Sutton: ✅ (enables learning from human preferences)
- Dr. Chen: ✅ (RLHF for multi-agent systems!)
- Shannon: ✅ (feedback as information channel)
- Von Neumann: ✅ (human-in-the-loop game theory)
- Dr. Silver: ✅ (THIS IS THE FEATURE!)
"""

import logging
from datetime import datetime
from typing import Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Singleton pattern for global access
_GLOBAL_CALCULATOR = None


class UserFeedback:
    """
    User-facing API for providing reward feedback.
    
    THIS IS THE CRITICAL MISSING FEATURE!
    """
    
    @classmethod
    def rate_task(
        cls,
        task_id: str,
        rating: float,
        comment: str = ""
    ):
        """
        Rate a single task after it completes.
        
        Args:
            task_id: Task identifier (e.g., "generate_sql", "format_output")
            rating: User rating 0-10 (will be normalized to 0-1)
            comment: Optional explanation
        
        Example:
            >>> UserFeedback.rate_task("generate_sql", 9.0, "Perfect query!")
        """
        if not 0.0 <= rating <= 10.0:
            raise ValueError(f"Rating must be between 0 and 10, got {rating}")
        
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(
                f"⚠️  UserFeedback.rate_task called but UnifiedRewardCalculator not initialized. "
                f"Feedback will be lost. Make sure Conductor is created first."
            )
            return
        
        calculator.accept_user_feedback(
            task_id=task_id,
            reward=rating / 10.0,  # Normalize to [0, 1]
            reason=comment,
            timestamp=datetime.now()
        )
        
        logger.info(
            f"✅ USER FEEDBACK: Task '{task_id}' rated {rating}/10"
            + (f" - {comment}" if comment else "")
        )
    
    @classmethod
    def rate_episode(
        cls,
        episode_id: str,
        rating: float,
        comment: str = ""
    ):
        """
        Rate an entire episode after completion.
        
        This applies feedback to all tasks in the episode.
        
        Args:
            episode_id: Episode identifier
            rating: User rating 0-10 (will be normalized to 0-1)
            comment: Optional explanation
        
        Example:
            >>> UserFeedback.rate_episode("ep_001", 8.5, "Good but slow")
        """
        if not 0.0 <= rating <= 10.0:
            raise ValueError(f"Rating must be between 0 and 10, got {rating}")
        
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(
                f"⚠️  UserFeedback.rate_episode called but UnifiedRewardCalculator not initialized. "
                f"Feedback will be lost. Make sure Conductor is created first."
            )
            return
        
        # Apply feedback to the episode (task_id = episode_id)
        calculator.accept_user_feedback(
            task_id=f"episode_{episode_id}",
            reward=rating / 10.0,
            reason=comment,
            timestamp=datetime.now()
        )
        
        logger.info(
            f"✅ USER FEEDBACK: Episode '{episode_id}' rated {rating}/10"
            + (f" - {comment}" if comment else "")
        )
    
    @classmethod
    def rate_agent(
        cls,
        agent_name: str,
        rating: float,
        comment: str = ""
    ):
        """
        Rate a specific agent's performance.
        
        Args:
            agent_name: Agent name (e.g., "CodeMaster", "DataMind")
            rating: User rating 0-10 (will be normalized to 0-1)
            comment: Optional explanation
        
        Example:
            >>> UserFeedback.rate_agent("CodeMaster", 9.5, "Great code quality!")
        """
        if not 0.0 <= rating <= 10.0:
            raise ValueError(f"Rating must be between 0 and 10, got {rating}")
        
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(
                f"⚠️  UserFeedback.rate_agent called but UnifiedRewardCalculator not initialized. "
                f"Feedback will be lost. Make sure Conductor is created first."
            )
            return
        
        # Apply feedback to the agent (task_id = agent_name)
        calculator.accept_user_feedback(
            task_id=f"agent_{agent_name}",
            reward=rating / 10.0,
            reason=comment,
            timestamp=datetime.now()
        )
        
        logger.info(
            f"✅ USER FEEDBACK: Agent '{agent_name}' rated {rating}/10"
            + (f" - {comment}" if comment else "")
        )
    
    @classmethod
    def save_feedback(cls, path: str = None):
        """
        Save all user feedback to file.
        
        Args:
            path: File path (defaults to session_data/user_feedback.json)
        
        Example:
            >>> UserFeedback.save_feedback("my_feedback.json")
        """
        if path is None:
            path = "session_data/user_feedback.json"
        
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(f"⚠️  No feedback to save (calculator not initialized)")
            return
        
        calculator.save_user_feedback(path)
    
    @classmethod
    def load_feedback(cls, path: str):
        """
        Load user feedback from file.
        
        Args:
            path: File path to JSON feedback file
        
        Example:
            >>> UserFeedback.load_feedback("my_feedback.json")
        """
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(
                f"⚠️  UserFeedback.load_feedback called but UnifiedRewardCalculator not initialized. "
                f"Make sure Conductor is created first."
            )
            return
        
        calculator.load_user_feedback(path)
    
    @classmethod
    def load_from_csv(cls, path: str):
        """
        Load user feedback from CSV file.
        
        CSV format:
            task_id,rating,comment
            generate_sql,9.0,"Perfect query"
            format_output,7.5,"Good but verbose"
        
        Args:
            path: Path to CSV file
        
        Example:
            >>> UserFeedback.load_from_csv("ratings.csv")
        """
        import csv
        
        calculator = cls._get_calculator()
        if calculator is None:
            logger.warning(
                f"⚠️  UserFeedback.load_from_csv called but UnifiedRewardCalculator not initialized. "
                f"Make sure Conductor is created first."
            )
            return
        
        try:
            with open(path, 'r') as f:
                reader = csv.DictReader(f)
                count = 0
                
                for row in reader:
                    task_id = row.get('task_id', '').strip()
                    rating = float(row.get('rating', '0'))
                    comment = row.get('comment', '').strip()
                    
                    if task_id:
                        calculator.accept_user_feedback(
                            task_id=task_id,
                            reward=rating / 10.0,
                            reason=comment,
                            timestamp=datetime.now()
                        )
                        count += 1
                
                logger.info(f"✅ Loaded {count} feedback entries from {path}")
        
        except Exception as e:
            logger.error(f"❌ Failed to load CSV feedback: {e}")
    
    @classmethod
    def get_summary(cls) -> str:
        """
        Get summary of all user feedback.
        
        Returns:
            Human-readable summary
        
        Example:
            >>> print(UserFeedback.get_summary())
        """
        calculator = cls._get_calculator()
        if calculator is None:
            return "No feedback available (calculator not initialized)"
        
        return calculator.get_user_feedback_summary()
    
    @classmethod
    def _get_calculator(cls):
        """Get global calculator instance."""
        global _GLOBAL_CALCULATOR
        return _GLOBAL_CALCULATOR
    
    @classmethod
    def _set_calculator(cls, calculator):
        """Set global calculator instance (called by Conductor)."""
        global _GLOBAL_CALCULATOR
        _GLOBAL_CALCULATOR = calculator


# =============================================================================
# INTERACTIVE CLI (for manual feedback)
# =============================================================================

def interactive_feedback_cli():
    """
    Interactive CLI for providing feedback.
    
    Usage:
        python -m Synapse.core.user_feedback_api
    """
    print("=" * 80)
    print("SYNAPSE USER FEEDBACK CLI")
    print("=" * 80)
    print()
    print("Provide feedback on completed tasks to improve future performance.")
    print()
    
    calculator = UserFeedback._get_calculator()
    if calculator is None:
        print("⚠️  WARNING: No active Synapse session detected.")
        print("   Feedback will be saved to file and loaded in next session.")
        print()
    
    while True:
        print("\nOptions:")
        print("  1. Rate a task")
        print("  2. Rate an episode")
        print("  3. Rate an agent")
        print("  4. View feedback summary")
        print("  5. Save and exit")
        print()
        
        choice = input("Enter choice (1-5): ").strip()
        
        if choice == '1':
            task_id = input("Task ID: ").strip()
            rating = float(input("Rating (0-10): ").strip())
            comment = input("Comment (optional): ").strip()
            
            try:
                UserFeedback.rate_task(task_id, rating, comment)
            except Exception as e:
                print(f"❌ Error: {e}")
        
        elif choice == '2':
            episode_id = input("Episode ID: ").strip()
            rating = float(input("Rating (0-10): ").strip())
            comment = input("Comment (optional): ").strip()
            
            try:
                UserFeedback.rate_episode(episode_id, rating, comment)
            except Exception as e:
                print(f"❌ Error: {e}")
        
        elif choice == '3':
            agent_name = input("Agent name: ").strip()
            rating = float(input("Rating (0-10): ").strip())
            comment = input("Comment (optional): ").strip()
            
            try:
                UserFeedback.rate_agent(agent_name, rating, comment)
            except Exception as e:
                print(f"❌ Error: {e}")
        
        elif choice == '4':
            print()
            print(UserFeedback.get_summary())
        
        elif choice == '5':
            UserFeedback.save_feedback()
            print("✅ Feedback saved. Goodbye!")
            break
        
        else:
            print("Invalid choice. Please enter 1-5.")


if __name__ == '__main__':
    interactive_feedback_cli()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = ['UserFeedback', 'interactive_feedback_cli']
