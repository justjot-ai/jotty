"""
Swarm Learner for Synapse.

SOTA: Treats prompt updates as weight updates.

Instead of static prompts:
- Learns from each episode
- Updates prompts with new patterns
- Accumulates wisdom over time
- Like fine-tuning but at prompt level

🔴 A-TEAM FIX: Consolidated from duplicate definitions. This is the canonical
implementation — conductor.py imports from here.
"""
import json
import time
import logging
from typing import Dict, List, Any, Tuple

logger = logging.getLogger(__name__)

from .data_structures import SynapseConfig
from .token_utils import smart_truncate

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False


class SwarmLearnerSignature(dspy.Signature):
    """Update system prompts based on episode outcomes (online learning)."""
    
    current_prompt = dspy.InputField(desc="Current Architect/Auditor prompt")
    episode_trajectory = dspy.InputField(desc="What happened this episode")
    outcome = dspy.InputField(desc="Success/failure and why")
    patterns_observed = dspy.InputField(desc="Patterns that led to success/failure")
    
    updated_prompt = dspy.OutputField(desc="Updated prompt incorporating learnings")
    changes_made = dspy.OutputField(desc="List of specific changes made")
    learning_summary = dspy.OutputField(desc="What the system learned")


class SwarmLearner:
    """
    SOTA: Treats prompt updates as weight updates.
    
    Instead of static prompts:
    - Learns from each episode
    - Updates prompts with new patterns
    - Accumulates wisdom over time
    - Like fine-tuning but at prompt level
    """
    
    def __init__(self, config: SynapseConfig):
        self.config = config
        self.learner = dspy.ChainOfThought(SwarmLearnerSignature) if DSPY_AVAILABLE else None
        
        # Learning state
        self.learned_patterns: List[Dict] = []
        self.prompt_versions: Dict[str, List[str]] = {}  # prompt_name -> versions
        self.update_threshold = self.config.policy_update_threshold if hasattr(self.config, 'policy_update_threshold') else 10
        self.episode_buffer: List[Dict] = []
    
    def record_episode(
        self, 
        trajectory: List[Dict], 
        outcome: bool, 
        insights: List[str]
    ):
        """Record episode for learning."""
        self.episode_buffer.append({
            'trajectory': trajectory,
            'outcome': outcome,
            'insights': insights,
            'timestamp': time.time()
        })
        
        # Extract patterns
        if outcome:
            self.learned_patterns.append({
                'type': 'success',
                'pattern': self._extract_pattern(trajectory),
                'timestamp': time.time()
            })
        else:
            self.learned_patterns.append({
                'type': 'failure',
                'pattern': self._extract_pattern(trajectory),
                'timestamp': time.time()
            })
        
        # Keep only recent patterns (🔴 A-TEAM FIX: was no-op)
        if len(self.learned_patterns) > 100:
            self.learned_patterns = self.learned_patterns[-100:]
    
    def should_update_prompts(self) -> bool:
        """Check if we should update prompts."""
        return len(self.episode_buffer) >= self.update_threshold
    
    def update_prompt(
        self, 
        prompt_name: str, 
        current_prompt: str
    ) -> Tuple[str, List[str]]:
        """
        Update a prompt based on learned patterns.
        
        Returns:
            (updated_prompt, changes_made)
        """
        if not self.learner or not self.episode_buffer:
            return current_prompt, []
        
        # Summarize episodes
        successes = [e for e in self.episode_buffer if e['outcome']]
        failures = [e for e in self.episode_buffer if not e['outcome']]
        
        patterns = []
        for p in self.learned_patterns[-20:]:
            patterns.append(f"{p['type']}: {p['pattern']}")
        
        try:
            result = self.learner(
                current_prompt=smart_truncate(current_prompt, max_tokens=750),
                episode_trajectory=smart_truncate(json.dumps({
                    'success_count': len(successes),
                    'failure_count': len(failures),
                    'recent_trajectories': [e['trajectory'][:3] for e in self.episode_buffer[-3:]]
                }, default=str), max_tokens=375),
                outcome=f"Successes: {len(successes)}, Failures: {len(failures)}",
                patterns_observed=smart_truncate("\n".join(patterns[-10:]), max_tokens=250)
            )
            
            updated = result.updated_prompt or current_prompt
            changes = result.changes_made.split('\n') if result.changes_made else []
            
            # Track versions
            if prompt_name not in self.prompt_versions:
                self.prompt_versions[prompt_name] = []
            self.prompt_versions[prompt_name].append(updated)
            
            # Clear buffer after update
            self.episode_buffer = []
            
            logger.info(f"📝 Prompt '{prompt_name}' updated with {len(changes)} changes")
            return updated, changes
            
        except Exception as e:
            logger.warning(f"Prompt update failed: {e}")
            return current_prompt, []
    
    def _extract_pattern(self, trajectory: List[Dict]) -> str:
        """Extract pattern from trajectory."""
        steps = [step.get('step', 'unknown') for step in trajectory[:5]]
        return " → ".join(steps)
