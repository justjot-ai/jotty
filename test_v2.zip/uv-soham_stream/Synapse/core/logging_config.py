"""
Centralized logging configuration for Synapse with timestamps.

This module sets up comprehensive logging with timestamps throughout the Synapse system.
All loggers should use this configuration for consistent timestamp formatting.
"""

import logging
import sys
from datetime import datetime
from typing import Optional


def setup_synapse_logging(
    level: int = logging.INFO,
    include_timestamp: bool = True,
    format_string: Optional[str] = None
) -> None:
    """
    Configure logging for Synapse with timestamps.
    
    Args:
        level: Logging level (default: INFO)
        include_timestamp: Whether to include timestamps in log messages
        format_string: Custom format string (if None, uses default with timestamp)
    """
    if format_string is None:
        if include_timestamp:
            format_string = (
                '%(asctime)s.%(msecs)03d | %(levelname)-8s | '
                '%(name)s:%(lineno)d | %(message)s'
            )
        else:
            format_string = '%(levelname)-8s | %(name)s:%(lineno)d | %(message)s'
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Remove existing handlers to avoid duplicates
    root_logger.handlers.clear()
    
    # Create formatter with timestamps
    formatter = logging.Formatter(
        format_string,
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # Set specific loggers to appropriate levels
    logging.getLogger('Synapse').setLevel(level)
    logging.getLogger('Synapse.core').setLevel(level)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with Synapse configuration.
    
    Args:
        name: Logger name (typically __name__)
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    
    # Ensure logging is configured if not already done
    if not logger.handlers and logging.getLogger().handlers:
        # Root logger is configured, but this logger might not inherit
        logger.setLevel(logging.NOTSET)  # Inherit from parent
    
    return logger


def log_function_call(logger: logging.Logger, func_name: str, **kwargs):
    """
    Log a function call with parameters.
    
    Args:
        logger: Logger instance
        func_name: Name of the function being called
        **kwargs: Function parameters to log
    """
    params_str = ', '.join(f"{k}={v!r}" for k, v in kwargs.items())
    logger.debug(f"🔵 CALL: {func_name}({params_str})")


def log_function_return(logger: logging.Logger, func_name: str, result: any = None, duration: Optional[float] = None):
    """
    Log a function return with result and duration.
    
    Args:
        logger: Logger instance
        func_name: Name of the function returning
        result: Return value (optional)
        duration: Execution duration in seconds (optional)
    """
    duration_str = f" [{duration:.3f}s]" if duration else ""
    if result is not None:
        logger.debug(f"🟢 RETURN: {func_name}() -> {result!r}{duration_str}")
    else:
        logger.debug(f"🟢 RETURN: {func_name}(){duration_str}")


def log_state_change(logger: logging.Logger, component: str, old_state: any, new_state: any):
    """
    Log a state change.
    
    Args:
        logger: Logger instance
        component: Component name
        old_state: Previous state
        new_state: New state
    """
    logger.info(f"🔄 STATE CHANGE: {component} | {old_state} -> {new_state}")


def log_decision(logger: logging.Logger, decision_point: str, decision: any, reasoning: Optional[str] = None):
    """
    Log a decision point.
    
    Args:
        logger: Logger instance
        decision_point: Description of the decision point
        decision: The decision made
        reasoning: Optional reasoning for the decision
    """
    reasoning_str = f" | Reasoning: {reasoning}" if reasoning else ""
    logger.info(f"🎯 DECISION: {decision_point} | Decision: {decision}{reasoning_str}")


# Auto-configure on import
setup_synapse_logging()
