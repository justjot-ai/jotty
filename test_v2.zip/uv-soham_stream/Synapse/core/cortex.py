"""
Synapse v6.0 - Enhanced Memory System
====================================

Hierarchical memory with all A-Team enhancements:
- Aristotle: Causal knowledge layer, goal-conditioned wisdom
- Shannon: Deduplication, compression, information-theoretic selection
- Dr. Agarwal: LLM-based consolidation, size-aware storage

Five levels:
1. EPISODIC - Raw experiences (fast decay)
2. SEMANTIC - Abstracted patterns (slow decay)  
3. PROCEDURAL - Action sequences (medium decay)
4. META - Learning wisdom (no decay)
5. CAUSAL - Why things work (no decay) [NEW]
"""

import json
import hashlib
import logging
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict
import dspy

logger = logging.getLogger(__name__)

from .token_utils import count_tokens_accurate, smart_truncate
from .data_structures import (
    MemoryEntry, MemoryLevel, GoalValue, SynapseConfig,
    GoalHierarchy, GoalNode, CausalLink, StoredEpisode
)
from .llm_rag import LLMRAGRetriever, DeduplicationEngine, CausalExtractor


# =============================================================================
# CONSOLIDATION SIGNATURES
# =============================================================================

class PatternExtractionSignature(dspy.Signature):
    """Extract patterns from episodic memories using chain-of-thought."""
    
    memories: str = dspy.InputField(desc="JSON list of related episodic memories")
    goal_context: str = dspy.InputField(desc="The goal context these memories relate to")
    # 🔴 A-TEAM FIX: Was "Domain (e.g., sql, python, api, etc.)" — hardcoded domain examples
    domain: str = dspy.InputField(desc="Domain context for pattern extraction (dynamically determined)")
    
    reasoning: str = dspy.OutputField(desc="Analysis of what patterns emerge")
    pattern: str = dspy.OutputField(desc="The extracted pattern as a clear statement")
    confidence: float = dspy.OutputField(desc="Confidence in pattern 0.0-1.0")
    conditions: str = dspy.OutputField(desc="When this pattern applies")
    exceptions: str = dspy.OutputField(desc="When this pattern does NOT apply")


class ProceduralExtractionSignature(dspy.Signature):
    """Extract procedural knowledge (how to do things)."""
    
    success_traces: str = dspy.InputField(desc="Traces of successful episodes")
    failure_traces: str = dspy.InputField(desc="Traces of failed episodes")
    task_type: str = dspy.InputField(desc="Type of task")
    
    reasoning: str = dspy.OutputField(desc="Analysis of what steps lead to success")
    procedure: str = dspy.OutputField(desc="Step-by-step procedure")
    key_decisions: str = dspy.OutputField(desc="Critical decision points")


class MetaWisdomSignature(dspy.Signature):
    """Extract meta-level wisdom about learning itself."""
    
    learning_history: str = dspy.InputField(desc="Summary of learning progress")
    failure_analysis: str = dspy.InputField(desc="Common failure patterns")
    success_analysis: str = dspy.InputField(desc="Common success patterns")
    
    wisdom: str = dspy.OutputField(desc="Meta-level insight about when to apply what knowledge")
    applicability: str = dspy.OutputField(desc="When this wisdom applies")


# =============================================================================
# CONTRADICTION DETECTION (A-Team Enhancement)
# =============================================================================

class ContradictionDetectionSignature(dspy.Signature):
    """
    A-Team Enhancement: LLM-based contradiction detection.
    
    Instead of creating duplicate entries, detect if new memory contradicts
    an existing one and should UPDATE rather than CREATE.
    
    This ensures memory remains consistent and learns from corrections.
    """
    
    new_memory: str = dspy.InputField(desc="The new memory content to store")
    existing_memory: str = dspy.InputField(desc="An existing memory that might be related")
    context: str = dspy.InputField(desc="Context: goal, domain, task type")
    
    reasoning: str = dspy.OutputField(desc="Analysis of relationship between memories")
    relationship: str = dspy.OutputField(desc="One of: DUPLICATE, CONTRADICTION, EXTENSION, UNRELATED")
    should_update: bool = dspy.OutputField(desc="True if existing memory should be updated")
    merged_content: str = dspy.OutputField(desc="If should_update, the merged/corrected content")
    confidence: float = dspy.OutputField(desc="Confidence 0.0-1.0")


# =============================================================================
# MEMORY LEVEL CLASSIFIER (A-Team Enhancement)
# =============================================================================

class MemoryLevelClassificationSignature(dspy.Signature):
    """
    A-Team Enhancement: LLM-based memory level classification.
    
    Instead of hardcoding which level to store to, use LLM to decide:
    - EPISODIC: Raw experiences, specific events, tool outputs
    - SEMANTIC: Patterns, abstractions, generalizations
    - PROCEDURAL: How-to knowledge, step sequences
    - META: Wisdom about learning, when to use what
    - CAUSAL: Why things work, cause-effect relationships
    """
    
    experience: str = dspy.InputField(desc="The experience/knowledge to classify")
    context: str = dspy.InputField(desc="Context: task type, agent, goal, outcome")
    
    reasoning: str = dspy.OutputField(desc="Why this memory level is appropriate")
    level: str = dspy.OutputField(desc="One of: EPISODIC, SEMANTIC, PROCEDURAL, META, CAUSAL")
    confidence: float = dspy.OutputField(desc="Confidence 0.0-1.0")
    should_store: bool = dspy.OutputField(desc="True if worth storing, False if redundant")


class MemoryLevelClassifier:
    """
    A-Team Enhancement: LLM-based automatic memory level classification.
    
    Replaces hardcoded level decisions with intelligent classification.
    
    Usage:
        classifier = MemoryLevelClassifier()
        level, confidence, should_store = classifier.classify(
            experience="Successfully mapped bank_code column using regex extraction",
            context={"task": "column_mapping", "agent": "diffuser", "outcome": "success"}
        )
        
        if should_store:
            memory.store(content=experience, level=level, ...)
    """
    
    def __init__(self, use_cot: bool = True):
        self.use_cot = use_cot
        if use_cot:
            self.classifier = dspy.ChainOfThought(MemoryLevelClassificationSignature)
        else:
            self.classifier = dspy.Predict(MemoryLevelClassificationSignature)
        
        # Level mapping
        self.level_map = {
            'EPISODIC': MemoryLevel.EPISODIC,
            'SEMANTIC': MemoryLevel.SEMANTIC,
            'PROCEDURAL': MemoryLevel.PROCEDURAL,
            'META': MemoryLevel.META,
            'CAUSAL': MemoryLevel.CAUSAL
        }
        
        # A-Team v8.0: NO keyword lists! Structure-based classification only
        # Removed level_hints entirely - uses _heuristic_classify with structural analysis
    
    def classify(self, experience: str, context: Dict[str, Any]) -> Tuple[MemoryLevel, float, bool]:
        """
        Classify experience into appropriate memory level.
        
        Returns:
            (MemoryLevel, confidence, should_store)
        """
        import json
        
        try:
            result = self.classifier(
                experience=experience,  # 🔥 NO LIMIT - FULL content
                context=json.dumps(context)
            )
            
            level_str = result.level.upper().strip()
            level = self.level_map.get(level_str, MemoryLevel.EPISODIC)
            confidence = float(result.confidence) if result.confidence else 0.5
            should_store = result.should_store if hasattr(result, 'should_store') else True
            
            return level, confidence, should_store
            
        except Exception as e:
            # Explicit uncertainty: do not store when classification fails
            logger.warning(f"Memory level classification failed: {e}")
            return MemoryLevel.EPISODIC, 0.0, False
    
    async def _classify_with_retry(self, experience: str, context: Dict[str, Any]) -> MemoryLevel:
        """
        A-Team v9.0: NO HEURISTIC FALLBACKS.
        
        If primary classification fails:
        1. Retry with context of failure
        2. If still fails, use FallbackClassificationAgent
        3. NEVER use hardcoded rules
        """
        from .modern_agents import UniversalRetryHandler, PatternDetector
        
        retry_handler = UniversalRetryHandler(max_retries=3)
        
        async def classify_attempt(**kwargs):
            exp = kwargs.get('experience', '')
            ctx = kwargs.get('context', {})
            
            result = self.classifier(
                experience=exp,
                context=json.dumps(ctx)
            )
            
            level_str = result.level.upper().strip()
            return self.level_map.get(level_str, MemoryLevel.EPISODIC)
        
        # Fallback agent (specialized for difficult cases)
        async def fallback_classifier(**kwargs):
            """
            Specialized agent for difficult classification cases.
            
            Gets full error context and tries harder.
            """
            task_info = kwargs.get('task', '')
            errors = kwargs.get('error_history', [])
            
            # Create a more detailed prompt with all context
            detailed_prompt = f"""
            DIFFICULT CLASSIFICATION TASK
            
            The primary classifier failed with these errors:
            {errors}
            
            Original task: {task_info}
            
            Please classify this experience into one of:
            - EPISODIC: Raw events, specific instances, tool outputs
            - SEMANTIC: Patterns, generalizations, abstractions
            - PROCEDURAL: How-to knowledge, step sequences
            - META: Wisdom about approach, when to use what
            - CAUSAL: Why things work, cause-effect relationships
            
            Think carefully and provide classification.
            """
            
            # Use a fresh classifier with detailed prompt
            class DetailedClassification(dspy.Signature):
                detailed_context = dspy.InputField()
                experience = dspy.InputField()
                level = dspy.OutputField()
                confidence = dspy.OutputField()
            
            specialist = dspy.ChainOfThought(DetailedClassification)
            result = specialist(
                detailed_context=detailed_prompt,
                experience=kwargs.get('original_input', {}).get('experience', '')
            )
            
            level_str = result.level.upper().strip()
            return self.level_map.get(level_str, MemoryLevel.EPISODIC)
        
        result = await retry_handler.execute_with_retry(
            agent_func=classify_attempt,
            task_description=f"Classify memory level for: {experience}...",
            initial_input={'experience': experience, 'context': context},
            specialist_agent=fallback_classifier
        )
        
        if result.is_certain:
            return result.value
        else:
            # Even specialist failed - return with uncertainty flag
            # (This is NOT a heuristic fallback, it's explicit uncertainty)
            logger.warning(f"Classification uncertain after all retries: {result.reasoning}")
            return MemoryLevel.EPISODIC  # Default with logged uncertainty


# =============================================================================
# MEMORY CLUSTER
# =============================================================================

@dataclass
class MemoryCluster:
    """A cluster of related memories for consolidation."""
    cluster_id: str
    goal_signature: str
    memories: List[MemoryEntry]
    
    # Cluster statistics
    avg_value: float = 0.0
    success_rate: float = 0.0
    common_keywords: List[str] = field(default_factory=list)
    
    # Extracted pattern (if consolidated)
    extracted_pattern: Optional[str] = None
    pattern_confidence: float = 0.0
    
    def compute_statistics(self):
        """
        Compute cluster statistics.
        
        A-Team Fix: Removed keyword extraction (loses semantic meaning).
        Uses content length and value distribution instead.
        """
        if not self.memories:
            return
        
        values = [m.default_value for m in self.memories]
        self.avg_value = sum(values) / len(values)
        
        # Success rate from memory values (value > 0.5 = successful use)
        successful = sum(1 for v in values if v > 0.5)
        self.success_rate = successful / len(values)
        
        # A-Team: Instead of keywords, store content signatures for hash-based similarity
        # This avoids keyword matching which loses semantic meaning
        # Keywords list now stores content length buckets for fast filtering
        length_buckets = []
        for m in self.memories:
            content_len = len(m.content)
            if content_len < 100:
                length_buckets.append("short")
            elif content_len < 500:
                length_buckets.append("medium")
            else:
                length_buckets.append("long")
        
        # Store most common length bucket (useful for clustering similar experiences)
        from collections import Counter
        bucket_counts = Counter(length_buckets)
        self.common_keywords = [f"content_{b}" for b, _ in bucket_counts.most_common(3)]


# =============================================================================
# NULL MEMORY (No-op stub when memory is disabled)
# =============================================================================

class NullMemory:
    """
    No-op memory stub for when memory is disabled.
    Implements the same interface as HierarchicalMemory but does nothing.
    """
    def __init__(self, agent_name: str = "Null", config: Any = None):
        self.agent_name = agent_name
        self.config = config
        self.memories = {}
        self.causal_links = {}
        self.goal_hierarchy = None
        self.total_accesses = 0
        self.consolidation_count = 0
    
    def store(self, *args, **kwargs):
        """No-op: memory disabled"""
        return None
    
    def store_with_outcome(self, *args, **kwargs):
        """No-op: memory disabled"""
        return None
    
    def retrieve(self, *args, **kwargs):
        """No-op: return empty list"""
        return []
    
    def retrieve_for_context(self, *args, **kwargs):
        """No-op: return empty list"""
        return []
    
    def retrieve_causal(self, *args, **kwargs):
        """No-op: return empty list"""
        return []
    
    def retrieve_temporal_chain(self, *args, **kwargs):
        """No-op: return empty list"""
        return []
    
    def consolidate(self, *args, **kwargs):
        """No-op: memory disabled"""
        pass
    
    def to_dict(self):
        """Return empty dict"""
        return {}
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], config: Any):
        """Create NullMemory instance"""
        return cls(config=config)


# =============================================================================
# MAIN HIERARCHICAL MEMORY
# =============================================================================

class HierarchicalMemory:
    """
    Enhanced hierarchical memory with all A-Team features.
    
    Levels:
    - EPISODIC: Raw experiences, high detail, fast decay
    - SEMANTIC: Abstracted patterns, extracted via LLM
    - PROCEDURAL: Action sequences, how to do things
    - META: Learning wisdom, never decays
    - CAUSAL: Why things work, enables reasoning about new situations
    
    Key features:
    - LLM-based retrieval (no embeddings)
    - Goal-conditioned values with transfer
    - Causal knowledge extraction
    - Automatic consolidation
    - Deduplication
    - Protection against forgetting
    """
    
    def __init__(self, agent_name: str, config: SynapseConfig):
        self.agent_name = agent_name
        self.config = config
        
        # Memory storage by level
        self.memories: Dict[MemoryLevel, Dict[str, MemoryEntry]] = {
            MemoryLevel.EPISODIC: {},
            MemoryLevel.SEMANTIC: {},
            MemoryLevel.PROCEDURAL: {},
            MemoryLevel.META: {},
            MemoryLevel.CAUSAL: {}
        }
        
        # Causal knowledge
        self.causal_links: Dict[str, CausalLink] = {}
        
        # Goal hierarchy
        self.goal_hierarchy = GoalHierarchy()
        
        # Capacities
        self.capacities = {
            MemoryLevel.EPISODIC: config.episodic_capacity,
            MemoryLevel.SEMANTIC: config.semantic_capacity,
            MemoryLevel.PROCEDURAL: config.procedural_capacity,
            MemoryLevel.META: config.meta_capacity,
            MemoryLevel.CAUSAL: config.causal_capacity
        }
        
        # LLM components
        self.retriever = LLMRAGRetriever(config)
        self.deduplicator = DeduplicationEngine(config)
        self.causal_extractor = CausalExtractor(config)
        
        # LLM consolidators
        self.pattern_extractor = dspy.ChainOfThought(PatternExtractionSignature)
        self.procedural_extractor = dspy.ChainOfThought(ProceduralExtractionSignature)
        self.meta_extractor = dspy.ChainOfThought(MetaWisdomSignature)
        
        # A-Team: LLM-based contradiction detector
        self.contradiction_detector = dspy.ChainOfThought(ContradictionDetectionSignature)
        
        # 🔴 A-TEAM FIX: Temporal linking — track last stored memory per goal
        # This enables "what happened before/after" reasoning
        self._last_memory_key_by_goal: Dict[str, str] = {}  # goal -> last_stored_key
        self._temporal_links: Dict[str, str] = {}  # memory_key -> previous_memory_key
        
        # Statistics
        self.total_accesses = 0
        self.consolidation_count = 0
        self.contradiction_updates = 0  # Track contradiction-based updates
    
    # =========================================================================
    # GOAL NORMALIZATION
    # =========================================================================
    
    @staticmethod
    def _normalize_goal(goal: str) -> str:
        """
        Normalize goal strings for consistent storage and retrieval.
        
        🔴 A-TEAM FIX: Goal strings were inconsistent between storage and retrieval:
        - Storage might use: "Send Anshul printscreen of paytm stocks..."
        - Retrieval might use: "## CURRENT_TASK\nAccess historical stock data..."
        - Or Q-learning advisory: "[Q-Advisory] ...\n\nActual goal: Send Anshul..."
        
        This normalizer strips markdown headers, task prefixes, and advisory context
        to produce a stable, canonical goal signature for memory scoping.
        """
        import re
        if not goal:
            return ""
        
        # Strip markdown headers (## CURRENT_TASK, ## ROOT_GOAL, etc.)
        goal = re.sub(r'^##\s+\w[\w_\s]*\n', '', goal, flags=re.MULTILINE)
        
        # Strip Q-learning advisory prefix
        if '[Q-Advisory]' in goal or '[Q-Learning]' in goal:
            # Try to find the actual goal after the advisory
            for marker in ['Actual goal:', 'Task:', 'Goal:', 'Original task:']:
                idx = goal.find(marker)
                if idx != -1:
                    goal = goal[idx + len(marker):]
                    break
        
        # Take only the first meaningful line (the core goal)
        lines = [l.strip() for l in goal.strip().split('\n') if l.strip() and not l.strip().startswith('#')]
        if lines:
            goal = lines[0]
        
        # Trim to first 120 chars for consistent hashing
        goal = goal.strip()[:120]
        
        return goal
    
    # =========================================================================
    # STORAGE
    # =========================================================================
    
    def store(self,
              content: str,
              level: MemoryLevel,
              context: Dict[str, Any],
              goal: str,
              initial_value: float = 0.5,
              causal_links: List[str] = None) -> MemoryEntry:
        """
        Store a new memory with size checking and deduplication.
        
        A-Team Note: For information-weighted storage, use store_with_outcome()
        which automatically adjusts storage detail based on event rarity.
        """
        # 🔴 A-TEAM FIX: Was `len(content) // 4 + 1` heuristic — now uses token_utils
        token_count = count_tokens_accurate(content)
        if token_count > self.config.max_entry_tokens:
            # Truncate using token-aware smart_truncate (preserves word boundaries)
            content = smart_truncate(content, max_tokens=self.config.max_entry_tokens)
            content += "\n[TRUNCATED - Original was longer]"
            token_count = self.config.max_entry_tokens
        
        # Create entry
        key = hashlib.md5(f"{content}{datetime.now().isoformat()}".encode()).hexdigest()
        
        entry = MemoryEntry(
            key=key,
            content=content,
            level=level,
            context=context,
            token_count=token_count,
            source_episode=context.get('episode', 0),
            source_agent=self.agent_name,
            causal_links=causal_links or []
        )
        
        # Set goal-conditioned value (using normalized goal for consistent matching)
        normalized_goal = self._normalize_goal(goal)
        entry.goal_values[normalized_goal] = GoalValue(value=initial_value)
        entry.default_value = initial_value
        
        # A-Team: Check for duplicates AND contradictions using LLM
        if self.config.enable_deduplication:
            existing = list(self.memories[level].values())
            for existing_mem in existing[-20:]:  # Check recent only for efficiency
                # First: quick deduplication check
                is_dup, sim, merged = self.deduplicator.check_duplicate(entry, existing_mem)
                if is_dup:
                    # Merge into existing
                    existing_mem.content = merged
                    existing_mem.similar_entries.append(key)
                    return existing_mem
                
                # Second: LLM-based contradiction detection (no similarity gating)
                try:
                    # 🔴 A-TEAM FIX: Was hardcoded `[:1500]` — now uses smart_truncate
                    result = self.contradiction_detector(
                        new_memory=smart_truncate(content, max_tokens=375),
                        existing_memory=smart_truncate(existing_mem.content, max_tokens=375),
                        context=f"Goal: {goal}, Domain: {context.get('domain', 'general')}"
                    )
                    
                    relationship = str(result.relationship).upper() if hasattr(result, 'relationship') else "UNRELATED"
                    should_update = bool(result.should_update) if hasattr(result, 'should_update') else False
                    
                    if relationship == "CONTRADICTION" and should_update:
                        # UPDATE existing memory with corrected content
                        merged_content = str(result.merged_content) if hasattr(result, 'merged_content') else content
                        existing_mem.content = merged_content
                        existing_mem.similar_entries.append(key)
                        self.contradiction_updates += 1
                        logger.info(f"🔄 Memory updated via contradiction detection (total: {self.contradiction_updates})")
                        return existing_mem
                    elif relationship == "EXTENSION":
                        # Append to existing
                        existing_mem.content = f"{existing_mem.content}\n\n[EXTENSION]\n{content}"
                        return existing_mem
                except Exception as e:
                    logger.debug(f"Contradiction detection failed: {e}")
        
        # Enforce capacity
        self._enforce_capacity(level)
        
        # Store
        self.memories[level][key] = entry
        
        # 🔴 A-TEAM FIX: Temporal linking — chain memories in sequence per goal
        # This enables retrieval of "what happened before/after" for a given goal
        prev_key = self._last_memory_key_by_goal.get(goal)
        if prev_key:
            self._temporal_links[key] = prev_key
        self._last_memory_key_by_goal[goal] = key
        
        # Update goal hierarchy
        if self.config.enable_goal_hierarchy:
            domain = context.get('domain', 'general')
            op_type = context.get('operation_type', 'query')
            entities = context.get('entities', [])
            self.goal_hierarchy.add_goal(goal, domain, op_type, entities)
        
        return entry
    
    def store_with_outcome(self,
                           content: str,
                           context: Dict[str, Any],
                           goal: str,
                           outcome: str = "neutral") -> MemoryEntry:
        """
        A-Team Enhancement: Information-Weighted Storage.
        
        Shannon Insight: I(event) = -log P(event)
        
        - FAILURES are rare (hopefully) → HIGH information → store MORE details
        - SUCCESSES are common → LOW information → store LESS details
        - NEUTRAL events → NORMAL storage
        
        🔴 A-TEAM FIX: Memory Storage Philosophy
        ═══════════════════════════════════════════
        STORE: Procedural knowledge (HOW to do things), patterns, strategies
        STORE: Error types and recovery approaches (generalizable)
        STORE: Tool effectiveness metrics (which tools work for what)
        
        DO NOT STORE: Specific names, contacts, file paths, URLs (PII/ephemeral)
        DO NOT STORE: Exact message contents (privacy risk)
        DO NOT STORE: One-time data (match scores, dates, specific facts)
        
        PRINCIPLE: Memories should generalize. "Send WhatsApp message to contact"
        is useful. "Send to Anshul" is NOT — it biases future unrelated tasks.
        ═══════════════════════════════════════════
        
        Args:
            content: The content to store
            context: Context dictionary
            goal: The goal being pursued
            outcome: One of "success", "failure", "neutral"
        
        Returns:
            The stored memory entry
        """
        # ═══════════════════════════════════════════
        # 🔴 A-TEAM FIX: Generalize content before storage
        # Strip PII and ephemeral details to prevent bias
        # ═══════════════════════════════════════════
        content = self._generalize_for_storage(content, context)
        
        if outcome == "failure":
            # Failures are rare = HIGH information content
            # Store MAXIMUM detail in CAUSAL memory (learn WHY it failed)
            # 🔴 A-TEAM FIX: Store generalizable failure pattern, NOT raw trace
            # Strip PII from context too
            safe_context = {k: v for k, v in context.items() 
                          if k in ('actor', 'task', 'failure', 'reward', 'error_type', 'tool_used')}
            enhanced_content = f"""❌ FAILURE PATTERN (High Information Event)
═══════════════════════════════════════════════════
{content}

PATTERN CONTEXT:
{json.dumps(safe_context, default=str, indent=2)}

MEMORY NOTE: Generalizable failure pattern. Focus on WHY and HOW to recover.
═══════════════════════════════════════════════════"""
            
            return self.store(
                content=enhanced_content,
                level=MemoryLevel.CAUSAL,  # Causal for "why" learning
                context=safe_context,
                goal=goal,
                initial_value=0.9  # High value (rare = valuable)
            )
        
        elif outcome == "success":
            # Successes should be common = LOW information content
            # Store SUMMARY in SEMANTIC memory (just the key insight)
            # Summarize to key insight
            lines = content.split('\n')
            summary = lines[0] if lines else content
            
            return self.store(
                content=f"✅ Success: {summary}",
                level=MemoryLevel.SEMANTIC,  # Semantic for patterns
                context=context,
                goal=goal,
                initial_value=0.4  # Lower value (common = less valuable)
            )
        
        else:
            # Neutral - normal storage
            return self.store(
                content=content,
                level=MemoryLevel.EPISODIC,  # Episodic for events
                context=context,
                goal=goal,
                initial_value=0.5
            )
    
    def _generalize_for_storage(self, content: str, context: Dict[str, Any]) -> str:
        """
        🔴 A-TEAM FIX: Generalize content for memory storage.
        
        Memory Storage Philosophy:
        ═══════════════════════════════
        Memories should contain PROCEDURAL knowledge (how to do things),
        not EPHEMERAL data (specific names, numbers, dates, URLs).
        
        This prevents:
        1. PII bias: "Send to Anshul" → future tasks default to Anshul
        2. Stale data: "Score is 245/3" → irrelevant next time
        3. Path dependency: "/Users/john/file.txt" → breaks on other machines
        
        We use LLM-based generalization when available, with a safe fallback.
        """
        if not content:
            return content
        
        # Try LLM-based generalization for better quality
        try:
            import dspy
            
            class GeneralizeMemorySignature(dspy.Signature):
                """Generalize a memory entry to remove PII and ephemeral details while preserving procedural knowledge."""
                raw_memory: str = dspy.InputField(desc="Raw memory content to generalize")
                task_type: str = dspy.InputField(desc="Type of task: e.g. browser, terminal, messaging, file, api")
                generalized: str = dspy.OutputField(
                    desc="Generalized version: replace specific names with [CONTACT], "
                         "specific URLs with [URL], file paths with [FILE_PATH], "
                         "specific data values with [DATA]. Keep procedural steps, "
                         "tool names, error types, and recovery strategies intact."
                )
            
            generalizer = dspy.Predict(GeneralizeMemorySignature)
            task_type = context.get('actor', 'general')
            result = generalizer(raw_memory=content[:1000], task_type=task_type)
            generalized = str(result.generalized)
            if generalized and len(generalized) > 10:
                return generalized
        except Exception as e:
            logger.debug(f"LLM generalization failed, using rule-based: {e}")
        
        # Fallback: rule-based generalization (safe but less intelligent)
        import re
        result = content
        # Remove specific file paths
        result = re.sub(r'(/[\w./-]+){3,}', '[FILE_PATH]', result)
        # Remove URLs
        result = re.sub(r'https?://[^\s]+', '[URL]', result)
        # Remove email addresses
        result = re.sub(r'\b[\w.+-]+@[\w-]+\.[\w.]+\b', '[EMAIL]', result)
        # Remove phone numbers
        result = re.sub(r'\b\d{10,}\b', '[PHONE]', result)
        
        return result

    def _enforce_capacity(self, level: MemoryLevel):
        """Ensure level doesn't exceed capacity."""
        capacity = self.capacities[level]
        memories = self.memories[level]
        
        while len(memories) >= capacity:
            # Find lowest-value unprotected memory
            candidates = [
                (k, m) for k, m in memories.items()
                if not m.is_protected
            ]
            
            if not candidates:
                # All protected - force remove oldest
                oldest = min(memories.values(), key=lambda m: m.created_at)
                del memories[oldest.key]
            else:
                # Remove lowest value
                to_remove = min(candidates, key=lambda x: x[1].default_value)
                del memories[to_remove[0]]
    
    # =========================================================================
    # RETRIEVAL
    # =========================================================================
    
    def retrieve(self,
                 query: str,
                 goal: str,
                 budget_tokens: int,
                 levels: List[MemoryLevel] = None,
                 context_hints: str = "") -> List[MemoryEntry]:
        """
        Retrieve relevant memories using LLM-based RAG.
        
        🔴 A-TEAM FIX: Goal-scoped retrieval.
        Memories are now filtered to prefer those associated with the current goal.
        Cross-goal memories (META and PROCEDURAL) are still included as they contain
        generalizable knowledge, but EPISODIC and CAUSAL memories from unrelated
        goals are deprioritized to prevent cross-task contamination (e.g., sending
        messages to wrong contacts because their name was in a memory from a
        different task).
        
        No embeddings - uses keyword pre-filter + LLM scoring.
        """
        if levels is None:
            levels = list(MemoryLevel)
        
        # 🔴 A-TEAM FIX: Normalize goal for consistent matching
        normalized_goal = self._normalize_goal(goal)
        
        # Collect all candidates with goal-scoping
        all_memories = []
        for level in levels:
            for mem in self.memories[level].values():
                # 🔴 A-TEAM FIX: Goal-scope filtering for EPISODIC and CAUSAL memories
                # META and PROCEDURAL are goal-agnostic (generalizable knowledge)
                # SEMANTIC patterns may transfer across goals, so include them
                if level in (MemoryLevel.EPISODIC, MemoryLevel.CAUSAL):
                    # Only include if memory is associated with current goal
                    # or if it has no specific goal association
                    if mem.goal_values:
                        # Check both normalized and raw goal strings for matching
                        normalized_mem_goals = {self._normalize_goal(g) for g in mem.goal_values.keys()}
                        if normalized_goal not in normalized_mem_goals and goal not in mem.goal_values:
                            # Skip memories from unrelated goals to prevent PII/context leak
                            continue
                all_memories.append(mem)
        
        if not all_memories:
            logger.info(f"🧠 [Memory] No memories matched goal-scope filter | levels={[l.value for l in levels]} | goal={goal[:60]}...")
            return []
        
        logger.info(f"🧠 [Memory] {len(all_memories)} memories passed goal-scope filter | query={query[:60]}...")
        
        # Use LLM RAG retriever
        selected = self.retriever.retrieve(
            query=query,
            goal=goal,
            memories=all_memories,
            budget_tokens=budget_tokens,
            goal_hierarchy=self.goal_hierarchy if self.config.enable_goal_hierarchy else None,
            context_hints=context_hints
        )
        
        # Update access tracking
        self.total_accesses += 1
        for mem in selected:
            mem.access_count += 1
            mem.ucb_visits += 1
            mem.last_accessed = datetime.now()
        
        return selected
    
    def retrieve_for_context(
        self,
        query: str,
        goal: str,
        context_type: str,
        budget_tokens: int,
        context_hints: str = ""
    ) -> List[MemoryEntry]:
        """
        A-Team Enhancement: Context-aware memory retrieval.
        
        Different context types prioritize different memory levels:
        - validation: PROCEDURAL > META > SEMANTIC (how-to first)
        - debugging: CAUSAL > EPISODIC > SEMANTIC (why first)
        - planning: META > SEMANTIC > PROCEDURAL (wisdom first)
        - exploration: EPISODIC > CAUSAL > SEMANTIC (examples first)
        - transformation: PROCEDURAL > SEMANTIC > EPISODIC (steps first)
        
        Usage:
            memories = memory.retrieve_for_context(
                query="How to map bank_code column?",
                goal="column_mapping",
                context_type="transformation",
                budget_tokens=5000
            )
        """
        from .data_structures import ContextType
        
        # Context-specific level priorities
        context_level_priorities = {
            ContextType.VALIDATION.value: [
                MemoryLevel.PROCEDURAL, MemoryLevel.META, MemoryLevel.SEMANTIC,
                MemoryLevel.CAUSAL, MemoryLevel.EPISODIC
            ],
            ContextType.DEBUGGING.value: [
                MemoryLevel.CAUSAL, MemoryLevel.EPISODIC, MemoryLevel.SEMANTIC,
                MemoryLevel.PROCEDURAL, MemoryLevel.META
            ],
            ContextType.PLANNING.value: [
                MemoryLevel.META, MemoryLevel.SEMANTIC, MemoryLevel.PROCEDURAL,
                MemoryLevel.CAUSAL, MemoryLevel.EPISODIC
            ],
            ContextType.EXPLORATION.value: [
                MemoryLevel.EPISODIC, MemoryLevel.CAUSAL, MemoryLevel.SEMANTIC,
                MemoryLevel.PROCEDURAL, MemoryLevel.META
            ],
            ContextType.TRANSFORMATION.value: [
                MemoryLevel.PROCEDURAL, MemoryLevel.SEMANTIC, MemoryLevel.EPISODIC,
                MemoryLevel.CAUSAL, MemoryLevel.META
            ],
            ContextType.DEFAULT.value: list(MemoryLevel)
        }
        
        # Get prioritized levels
        levels = context_level_priorities.get(context_type, list(MemoryLevel))
        
        # Add context type hint
        enhanced_hints = f"CONTEXT TYPE: {context_type}\n{context_hints}"
        
        return self.retrieve(
            query=query,
            goal=goal,
            budget_tokens=budget_tokens,
            levels=levels,
            context_hints=enhanced_hints
        )
    
    def retrieve_causal(self, query: str, context: Dict[str, Any]) -> List[CausalLink]:
        """
        Retrieve relevant causal knowledge using LLM-based semantic relevance.
        
        🔴 A-TEAM FIX: Was pure keyword matching — now uses LLM for relevance scoring.
        Strategy: Pre-filter by context applicability, then LLM-rank for semantic relevance.
        """
        if not self.config.enable_causal_learning:
            return []
        
        if not self.causal_links:
            return []
        
        # Step 1: Pre-filter by context applicability (cheap)
        candidates = []
        for link in self.causal_links.values():
            if link.applies_in_context(context):
                candidates.append(link)
        
        if not candidates:
            return []
        
        # Step 2: LLM-based semantic relevance scoring
        # Format candidates for LLM evaluation
        candidates_desc = "\n".join([
            f"[{i}] CAUSE: {link.cause} → EFFECT: {link.effect} (confidence: {link.confidence:.2f})"
            for i, link in enumerate(candidates[:30])  # Cap at 30 to keep prompt manageable
        ])
        
        try:
            relevance_checker = dspy.Predict("query: str, causal_links: str -> relevant_indices: str")
            result = relevance_checker(
                query=query,
                causal_links=candidates_desc
            )
            # Parse returned indices
            indices_str = str(result.relevant_indices)
            relevant = []
            for token in indices_str.replace(',', ' ').replace('[', ' ').replace(']', ' ').split():
                try:
                    idx = int(token.strip())
                    if 0 <= idx < len(candidates):
                        relevant.append(candidates[idx])
                except (ValueError, IndexError):
                    continue
            
            if relevant:
                # Sort by confidence (already LLM-filtered for relevance)
                relevant.sort(key=lambda x: x.confidence, reverse=True)
                return relevant
        except Exception as e:
            logger.debug(f"LLM causal retrieval failed, falling back: {e}")
        
        # Fallback: return candidates sorted by confidence
        candidates.sort(key=lambda x: x.confidence, reverse=True)
        return candidates[:10]
    
    def retrieve_temporal_chain(self, memory_key: str, depth: int = 5, 
                                direction: str = "backward") -> List[MemoryEntry]:
        """
        🔴 A-TEAM FIX: Retrieve temporally linked memories.
        
        Follows the temporal chain (linked list) of memories to understand
        what happened before/after a given memory event.
        
        Args:
            memory_key: Starting memory key
            depth: How far back/forward to trace (max chain length)
            direction: "backward" (what happened before), "forward" (what happened after)
        
        Returns:
            List of temporally linked memories in chronological order
        """
        chain = []
        current_key = memory_key
        
        if direction == "backward":
            # Trace backward through temporal links
            for _ in range(depth):
                prev_key = self._temporal_links.get(current_key)
                if not prev_key:
                    break
                # Find the memory entry across all levels
                for level_memories in self.memories.values():
                    if prev_key in level_memories:
                        chain.append(level_memories[prev_key])
                        break
                current_key = prev_key
            chain.reverse()  # Chronological order
        
        elif direction == "forward":
            # Build reverse index (child → parent becomes parent → child)
            forward_links = {}
            for child_key, parent_key in self._temporal_links.items():
                forward_links[parent_key] = child_key
            
            for _ in range(depth):
                next_key = forward_links.get(current_key)
                if not next_key:
                    break
                for level_memories in self.memories.values():
                    if next_key in level_memories:
                        chain.append(level_memories[next_key])
                        break
                current_key = next_key
        
        return chain
    
    # =========================================================================
    # CONSOLIDATION
    # =========================================================================
    
    async def consolidate(self, episodes: List[StoredEpisode] = None):
        """
        Run consolidation to extract higher-level knowledge.
        
        Episodic → Semantic (patterns)
        Episodic → Procedural (how-to)
        All → Meta (wisdom)
        Episodes → Causal (why)
        """
        self.consolidation_count += 1
        
        # 1. Cluster episodic memories by goal
        clusters = self._cluster_episodic_memories()
        
        # 2. Extract semantic patterns
        for cluster in clusters:
            if len(cluster.memories) >= self.config.min_cluster_size:
                await self._extract_semantic_pattern(cluster)
        
        # 3. Extract procedural knowledge
        if episodes:
            await self._extract_procedural(episodes)
        
        # 4. Extract meta wisdom
        await self._extract_meta_wisdom()
        
        # 5. Extract causal knowledge
        if episodes and self.config.enable_causal_learning:
            await self._extract_causal(episodes)
        
        # 6. Prune old episodic memories
        self._prune_episodic()
    
    def _cluster_episodic_memories(self) -> List[MemoryCluster]:
        """Cluster episodic memories by goal signature."""
        episodic = self.memories[MemoryLevel.EPISODIC]
        
        # Group by first goal in goal_values
        goal_groups: Dict[str, List[MemoryEntry]] = defaultdict(list)
        
        for mem in episodic.values():
            if mem.goal_values:
                goal = next(iter(mem.goal_values.keys()))
                # Create goal signature (first 50 chars + domain)
                domain = mem.context.get('domain', 'general')
                signature = f"{domain}:{goal}"
                goal_groups[signature].append(mem)
        
        # Create clusters
        clusters = []
        for sig, mems in goal_groups.items():
            cluster = MemoryCluster(
                cluster_id=hashlib.md5(sig.encode()).hexdigest(),
                goal_signature=sig,
                memories=mems
            )
            cluster.compute_statistics()
            clusters.append(cluster)
        
        return clusters
    
    async def _extract_semantic_pattern(self, cluster: MemoryCluster):
        """Extract semantic pattern from episodic cluster."""
        # Format memories for LLM
        memory_data = []
        for mem in cluster.memories:  # 🔥 NO LIMIT - FULL content
            memory_data.append({
                "content": mem.content,
                "value": mem.default_value,
                "success": mem.default_value > 0.5
            })
        
        try:
            result = self.pattern_extractor(
                memories=json.dumps(memory_data, indent=2),
                goal_context=cluster.goal_signature,
                domain=cluster.goal_signature.split(":")[0]
            )
            
            confidence = float(result.confidence) if result.confidence else 0.5
            
            if confidence >= self.config.pattern_confidence_threshold:
                # Store as semantic memory
                pattern_content = f"""
PATTERN: {result.pattern}

CONDITIONS: {result.conditions}

EXCEPTIONS: {result.exceptions}

DERIVED FROM: {len(cluster.memories)} episodic memories
CONFIDENCE: {confidence:.2f}
""".strip()
                
                # Get a representative goal
                sample_mem = cluster.memories[0]
                goal = next(iter(sample_mem.goal_values.keys()), "general")
                
                self.store(
                    content=pattern_content,
                    level=MemoryLevel.SEMANTIC,
                    context={
                        'cluster_id': cluster.cluster_id,
                        'source_count': len(cluster.memories),
                        'domain': cluster.goal_signature.split(":")[0]
                    },
                    goal=goal,
                    initial_value=cluster.avg_value
                )
                
                cluster.extracted_pattern = result.pattern
                cluster.pattern_confidence = confidence
                
                # 🔬 A-TEAM ENHANCEMENT: Log pattern extraction for monitoring
                logger.info(
                    f"🧠 SEMANTIC PATTERN EXTRACTED | "
                    f"pattern={result.pattern[:80]}... | "
                    f"confidence={confidence:.3f} | "
                    f"source_memories={len(cluster.memories)} | "
                    f"domain={cluster.goal_signature.split(':')[0]} | "
                    f"goal={goal}"
                )
                
        except Exception as e:
            logger.warning(f"⚠️ Pattern extraction failed for cluster {cluster.cluster_id}: {e}")
            # Consolidation failure is non-fatal, but log it
    
    async def _extract_procedural(self, episodes: List[StoredEpisode]):
        """Extract procedural knowledge from episode trajectories."""
        # Separate success and failure
        successes = [ep for ep in episodes if ep.success]
        failures = [ep for ep in episodes if not ep.success]
        
        if len(successes) < 3 or len(failures) < 2:
            return  # Not enough data
        
        # Group by task type
        task_groups: Dict[str, Tuple[List, List]] = defaultdict(lambda: ([], []))
        
        for ep in successes:
            domain = ep.kwargs.get('domain', 'general')
            task_groups[domain][0].append(ep)
        
        for ep in failures:
            domain = ep.kwargs.get('domain', 'general')
            task_groups[domain][1].append(ep)
        
        for task_type, (succ, fail) in task_groups.items():
            if len(succ) < 2:
                continue
            
            # Format traces
            success_traces = self._format_traces(succ)
            failure_traces = self._format_traces(fail)
            
            try:
                result = self.procedural_extractor(
                    success_traces=success_traces,
                    failure_traces=failure_traces,
                    task_type=task_type
                )
                
                procedure_content = f"""
PROCEDURE FOR: {task_type}

STEPS:
{result.procedure}

KEY DECISIONS:
{result.key_decisions}

ANALYSIS:
{result.reasoning}
""".strip()
                
                self.store(
                    content=procedure_content,
                    level=MemoryLevel.PROCEDURAL,
                    context={'task_type': task_type, 'source_episodes': len(succ) + len(fail)},
                    goal=f"{task_type}_procedure",
                    initial_value=0.7  # Procedures start with moderate value
                )
                
            except Exception:
                pass
    
    async def _extract_meta_wisdom(self):
        """Extract meta-level wisdom about learning."""
        # Analyze patterns across all levels
        all_high_value = []
        all_low_value = []
        
        for level in [MemoryLevel.SEMANTIC, MemoryLevel.PROCEDURAL]:
            for mem in self.memories[level].values():
                if mem.default_value > 0.8:
                    all_high_value.append(mem.content)
                elif mem.default_value < 0.3:
                    all_low_value.append(mem.content)
        
        if len(all_high_value) < 3:
            return
        
        try:
            result = self.meta_extractor(
                learning_history=f"Consolidation cycles: {self.consolidation_count}, High-value patterns: {len(all_high_value)}, Low-value: {len(all_low_value)}",
                failure_analysis=smart_truncate("\n".join(all_low_value), max_tokens=2000),
                success_analysis=smart_truncate("\n".join(all_high_value), max_tokens=2000)
            )
            
            wisdom_content = f"""
META WISDOM:
{result.wisdom}

WHEN TO APPLY:
{result.applicability}
""".strip()
            
            self.store(
                content=wisdom_content,
                level=MemoryLevel.META,
                context={'consolidation': self.consolidation_count},
                goal="meta_wisdom",
                initial_value=0.9  # Meta starts high
            )
            
            # Protect meta memories
            for mem in self.memories[MemoryLevel.META].values():
                mem.is_protected = True
                mem.protection_reason = "META level"
                
        except Exception:
            pass
    
    async def _extract_causal(self, episodes: List[StoredEpisode]):
        """Extract causal knowledge from contrasting episodes."""
        successes = [{'id': ep.episode_id, 'query': ep.goal, 'result': str(ep.actor_output)}
                     for ep in episodes if ep.success]
        failures = [{'id': ep.episode_id, 'query': ep.goal, 'result': str(ep.actor_error)}
                    for ep in episodes if not ep.success]
        
        if len(successes) < 3 or len(failures) < 2:
            return
        
        links = self.causal_extractor.extract_from_episodes(
            success_episodes=successes,
            failure_episodes=failures,
            domain=episodes[0].kwargs.get('domain', 'general')  # Generic default (not 'sql'!)
        )
        
        for link_data in links:
            link_key = hashlib.md5(f"{link_data['cause']}{link_data['effect']}".encode()).hexdigest()
            
            if link_key in self.causal_links:
                # Update existing
                existing = self.causal_links[link_key]
                existing.update_confidence(True)
                existing.supporting_episodes.append(episodes[0].episode_id)
            else:
                # Create new
                causal_link = CausalLink(
                    cause=link_data['cause'],
                    effect=link_data['effect'],
                    confidence=link_data.get('confidence', 0.7),
                    conditions=link_data.get('conditions', []),
                    domain=episodes[0].kwargs.get('domain', 'general')
                )
                self.causal_links[link_key] = causal_link
                
                # Also store as CAUSAL memory
                causal_content = f"""
CAUSAL LINK:
CAUSE: {causal_link.cause}
EFFECT: {causal_link.effect}
CONFIDENCE: {causal_link.confidence:.2f}
CONDITIONS: {', '.join(causal_link.conditions) if causal_link.conditions else 'None'}
""".strip()
                
                self.store(
                    content=causal_content,
                    level=MemoryLevel.CAUSAL,
                    context={'causal_key': link_key},
                    goal="causal_knowledge",
                    initial_value=causal_link.confidence,
                    causal_links=[link_key]
                )
    
    def _format_traces(self, episodes: List[StoredEpisode]) -> str:
        """Format episode traces for LLM."""
        traces = []
        for ep in episodes:
            trace = f"Episode {ep.episode_id}:\n"
            trace += f"  Goal: {ep.goal}\n"
            trace += f"  Steps: {len(ep.trajectory)}\n"
            trace += f"  Result: {'SUCCESS' if ep.success else 'FAILURE'}\n"
            if ep.actor_error:
                trace += f"  Error: {ep.actor_error}\n"
            traces.append(trace)
        return "\n".join(traces)
    
    def _prune_episodic(self):
        """Prune old low-value episodic memories."""
        episodic = self.memories[MemoryLevel.EPISODIC]
        
        # Keep top 80% by value, all less than 1 day old
        now = datetime.now()
        one_day_ago = now - timedelta(days=1)
        
        to_remove = []
        for key, mem in episodic.items():
            if mem.created_at < one_day_ago and mem.default_value < 0.3:
                to_remove.append(key)
        
        # Remove up to 20%
        max_remove = len(episodic) // 5
        for key in to_remove[:max_remove]:
            del episodic[key]
    
    # =========================================================================
    # PROTECTION
    # =========================================================================
    
    def protect_high_value(self, threshold: float = None):
        """Mark high-value memories as protected."""
        threshold = threshold or self.config.protected_memory_threshold
        
        for level, memories in self.memories.items():
            for mem in memories.values():
                if mem.default_value >= threshold:
                    mem.is_protected = True
                    mem.protection_reason = f"Value >= {threshold}"
                elif level == MemoryLevel.META:
                    mem.is_protected = True
                    mem.protection_reason = "META level"
                elif level == MemoryLevel.CAUSAL:
                    mem.is_protected = True
                    mem.protection_reason = "CAUSAL knowledge"
    
    # =========================================================================
    # SERIALIZATION
    # =========================================================================
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON storage."""
        data = {
            'agent_name': self.agent_name,
            'total_accesses': self.total_accesses,
            'consolidation_count': self.consolidation_count,
            'memories': {},
            'causal_links': {},
            'goal_hierarchy': {
                'nodes': {k: vars(v) for k, v in self.goal_hierarchy.nodes.items()},
                'root_id': self.goal_hierarchy.root_id
            }
        }
        
        for level in MemoryLevel:
            data['memories'][level.value] = {}
            for key, mem in self.memories[level].items():
                mem_dict = {
                    'key': mem.key,
                    'content': mem.content,
                    'level': mem.level.value,
                    'context': mem.context,
                    'created_at': mem.created_at.isoformat(),
                    'last_accessed': mem.last_accessed.isoformat(),
                    'goal_values': {
                        g: {'value': gv.value, 'access_count': gv.access_count}
                        for g, gv in mem.goal_values.items()
                    },
                    'default_value': mem.default_value,
                    'access_count': mem.access_count,
                    'ucb_visits': mem.ucb_visits,
                    'token_count': mem.token_count,
                    'is_protected': mem.is_protected,
                    'protection_reason': mem.protection_reason,
                    'causal_links': mem.causal_links
                }
                data['memories'][level.value][key] = mem_dict
        
        for key, link in self.causal_links.items():
            data['causal_links'][key] = {
                'cause': link.cause,
                'effect': link.effect,
                'confidence': link.confidence,
                'conditions': link.conditions,
                'exceptions': link.exceptions,
                'domain': link.domain
            }
        
        # 🔴 A-TEAM FIX: Serialize temporal links
        data['temporal_links'] = self._temporal_links
        data['last_memory_key_by_goal'] = self._last_memory_key_by_goal
        
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], config: SynapseConfig) -> 'HierarchicalMemory':
        """Deserialize from dictionary."""
        memory = cls(data['agent_name'], config)
        memory.total_accesses = data.get('total_accesses', 0)
        memory.consolidation_count = data.get('consolidation_count', 0)
        
        # Load memories
        for level_str, memories in data.get('memories', {}).items():
            level = MemoryLevel(level_str)
            for key, mem_data in memories.items():
                entry = MemoryEntry(
                    key=mem_data['key'],
                    content=mem_data['content'],
                    level=level,
                    context=mem_data['context'],
                    created_at=datetime.fromisoformat(mem_data['created_at']),
                    last_accessed=datetime.fromisoformat(mem_data['last_accessed']),
                    default_value=mem_data['default_value'],
                    access_count=mem_data['access_count'],
                    ucb_visits=mem_data['ucb_visits'],
                    token_count=mem_data['token_count'],
                    is_protected=mem_data.get('is_protected', False),
                    protection_reason=mem_data.get('protection_reason', ''),
                    causal_links=mem_data.get('causal_links', [])
                )
                
                # Restore goal values
                for goal, gv_data in mem_data.get('goal_values', {}).items():
                    entry.goal_values[goal] = GoalValue(
                        value=gv_data['value'],
                        access_count=gv_data['access_count']
                    )
                
                memory.memories[level][key] = entry
        
        # Load causal links
        for key, link_data in data.get('causal_links', {}).items():
            memory.causal_links[key] = CausalLink(
                cause=link_data['cause'],
                effect=link_data['effect'],
                confidence=link_data['confidence'],
                conditions=link_data.get('conditions', []),
                exceptions=link_data.get('exceptions', []),
                domain=link_data.get('domain', 'general')
            )
        
        # Load goal hierarchy
        gh_data = data.get('goal_hierarchy', {})
        memory.goal_hierarchy.root_id = gh_data.get('root_id', 'root')
        for node_id, node_data in gh_data.get('nodes', {}).items():
            memory.goal_hierarchy.nodes[node_id] = GoalNode(
                goal_id=node_data['goal_id'],
                goal_text=node_data['goal_text'],
                parent_id=node_data.get('parent_id'),
                children_ids=node_data.get('children_ids', []),
                domain=node_data.get('domain', 'general'),
                operation_type=node_data.get('operation_type', 'query'),
                entities=node_data.get('entities', []),
                episode_count=node_data.get('episode_count', 0),
                success_rate=node_data.get('success_rate', 0.5)
            )
        
        # 🔴 A-TEAM FIX: Restore temporal links
        memory._temporal_links = data.get('temporal_links', {})
        memory._last_memory_key_by_goal = data.get('last_memory_key_by_goal', {})
        
        return memory
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get memory statistics."""
        stats = {
            'total_memories': sum(len(m) for m in self.memories.values()),
            'by_level': {level.value: len(mems) for level, mems in self.memories.items()},
            'total_accesses': self.total_accesses,
            'consolidation_count': self.consolidation_count,
            'causal_links': len(self.causal_links),
            'unique_goals': len(self.goal_hierarchy.nodes),
            'protected_memories': sum(
                1 for mems in self.memories.values() 
                for m in mems.values() if m.is_protected
            )
        }
        return stats
    
    def get_consolidated_knowledge(self, goal: str = None, max_items: int = 10) -> str:
        """
        Get consolidated knowledge to inject into prompts.
        
        THIS IS HOW MEMORY CONSOLIDATION MANIFESTS IN LLM AGENTS!
        
        Returns natural language lessons from semantic/procedural/meta/causal levels.
        """
        consolidated = []
        
        # Semantic patterns (abstracted learnings)
        semantic_mems = self.memories.get(MemoryLevel.SEMANTIC, {})
        if semantic_mems:
            # Sort by value if goal provided
            if goal:
                sorted_semantic = sorted(
                    semantic_mems.values(),
                    key=lambda m: m.get_value(goal),
                    reverse=True
                )
            else:
                # Sort by access count
                sorted_semantic = sorted(
                    semantic_mems.values(),
                    key=lambda m: m.access_count,
                    reverse=True
                )
            
            for mem in sorted_semantic[:max_items//2]:
                consolidated.append(('PATTERN', mem.content, mem.get_value(goal) if goal else 0.5))
        
        # Procedural knowledge (how-to)
        procedural_mems = self.memories.get(MemoryLevel.PROCEDURAL, {})
        if procedural_mems:
            sorted_procedural = sorted(
                procedural_mems.values(),
                key=lambda m: m.access_count,
                reverse=True
            )
            for mem in sorted_procedural[:max_items//4]:
                consolidated.append(('PROCEDURE', mem.content, 0.5))
        
        # Meta wisdom
        meta_mems = self.memories.get(MemoryLevel.META, {})
        if meta_mems:
            for mem in list(meta_mems.values())[:max_items//4]:
                consolidated.append(('WISDOM', mem.content, 0.5))
        
        # Causal knowledge (WHY things work)
        if self.causal_links:
            sorted_causal = sorted(
                self.causal_links.values(),
                key=lambda link: link.confidence,
                reverse=True
            )
            for link in sorted_causal[:3]:
                causal_str = f"CAUSE: {link.cause} → EFFECT: {link.effect}"
                if link.conditions:
                    causal_str += f" (when: {', '.join(link.conditions)})"
                consolidated.append(('CAUSAL', causal_str, link.confidence))
        
        if not consolidated:
            return ""
        
        # Format as natural language
        context = "# Consolidated Knowledge (Long-Term Memory):\n"
        
        # Group by type
        patterns = [c for c in consolidated if c[0] == 'PATTERN']
        procedures = [c for c in consolidated if c[0] == 'PROCEDURE']
        wisdom = [c for c in consolidated if c[0] == 'WISDOM']
        causal = [c for c in consolidated if c[0] == 'CAUSAL']
        
        if patterns:
            context += "\n## Learned Patterns:\n"
            for _, content, value in patterns:
                if goal and value > 0:
                    context += f"- {smart_truncate(content, max_tokens=100)}... (value: {value:.2f})\n"
                else:
                    context += f"- {smart_truncate(content, max_tokens=100)}...\n"
        
        if procedures:
            context += "\n## Procedural Knowledge:\n"
            for _, content, _ in procedures:
                context += f"- {smart_truncate(content, max_tokens=100)}...\n"
        
        if wisdom:
            context += "\n## Meta Wisdom:\n"
            for _, content, _ in wisdom:
                context += f"- {smart_truncate(content, max_tokens=100)}...\n"
        
        if causal:
            context += "\n## Causal Understanding (WHY things work):\n"
            for _, content, conf in causal:
                context += f"- {content} (confidence: {conf:.2f})\n"
        
        return context