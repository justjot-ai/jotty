"""
🗜️ UNIFIED COMPRESSION MODULE
==============================

A-TEAM CONSOLIDATION: ONE compression implementation for ALL Synapse needs.

This module consolidates 7 different compression implementations into a single,
feature-rich, context-aware compressor.

Previous implementations (DELETED):
- compression_agent.py (CompressionSignature)
- agentic_compressor.py (AgenticCompressor, CompressionSignature)
- conductor.py (ContextCompressionSignature)
- smart_context_manager.py (ContextCompressionSignature)
- global_context_guard.py (GlobalCompressionSignature)
- inspector.py (InspectorCompressionSignature)
- validation_manager.py (ValidationCompressionSignature)

A-Team Consensus: 100% (20/20) - CONSOLIDATE ALL INTO ONE

Design Principles:
1. ONE signature, optional context fields
2. Works for ALL use cases (validation, memory, retrieval, etc.)
3. Shapley-aware (preserves high-impact items)
4. Chunking support (for large documents)
5. Caching (LRU for performance)
6. NO hardcoding, fully generic
"""

import asyncio
import logging
import os
import time
from functools import lru_cache
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

try:
    import dspy
    DSPY_AVAILABLE = True
except ImportError:
    DSPY_AVAILABLE = False
    dspy = None

logger = logging.getLogger(__name__)


# =============================================================================
# UNIFIED COMPRESSION SIGNATURE
# =============================================================================

if DSPY_AVAILABLE:
    class UnifiedCompressionSignature(dspy.Signature):
        """
        CANONICAL compression signature for ALL Synapse compression needs.
        
        A-Team Design: Supports ALL use cases via optional fields.
        
        Required Fields:
        - content: What to compress
        - max_tokens: Target size
        
        Optional Context Fields (provide as needed):
        - task_description: What the agent needs to do
        - priority_keywords: Keywords that MUST be preserved
        - high_impact_items: Shapley high-credit items (preserve first)
        - low_impact_items: Shapley low-credit items (can remove)
        - purpose: Why compressing (validation, memory, retrieval)
        - goal: Overall system goal for context
        
        Outputs:
        - compressed: Compressed content within max_tokens
        - compression_ratio: Percentage of original retained (optional)
        - what_was_removed: Summary of removed information (optional)
        """
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # REQUIRED FIELDS (always provide)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        content = dspy.InputField(
            desc="Full content to compress (NO pre-slicing!)"
        )
        max_tokens = dspy.InputField(
            desc="Maximum tokens allowed in compressed output"
        )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # OPTIONAL CONTEXT FIELDS (provide for better compression)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        task_description = dspy.InputField(
            desc="Optional: What the agent needs to do with this content"
        )
        priority_keywords = dspy.InputField(
            desc="Optional: Keywords/concepts that MUST be preserved (comma-separated)"
        )
        high_impact_items = dspy.InputField(
            desc="Optional: Items with HIGH Shapley credit (preserve these first!)"
        )
        low_impact_items = dspy.InputField(
            desc="Optional: Items with LOW Shapley credit (can be compressed/removed)"
        )
        purpose = dspy.InputField(
            desc="Optional: Why compressing? (for_validation, for_memory, for_retrieval, etc.)"
        )
        goal = dspy.InputField(
            desc="Optional: Overall system goal for relevance context"
        )
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # OUTPUTS
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        compressed = dspy.OutputField(
            desc="Compressed content within max_tokens. CRITICAL: Preserve ALL critical information including file paths, data values, tool outputs, error messages, and task-specific details. Aim for at least 20% retention of original content. Do NOT return empty or near-empty output."
        )
        compression_ratio = dspy.OutputField(
            desc="Percentage of original content retained (e.g., '0.3' = 30%). Must be at least 0.05 (5%). If compression would lose more than 95%, flag it."
        )
        what_was_removed = dspy.OutputField(
            desc="Optional: Brief summary of what information was removed"
        )


# =============================================================================
# STATISTICS TRACKING
# =============================================================================

@dataclass
class CompressionStats:
    """Track compression statistics."""
    total_compressions: int = 0
    total_time: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    chunked_compressions: int = 0
    
    @property
    def avg_time(self) -> float:
        return self.total_time / max(self.total_compressions, 1)
    
    @property
    def avg_compression_ratio(self) -> float:
        if self.total_input_tokens == 0:
            return 0.0
        return self.total_output_tokens / self.total_input_tokens
    
    @property
    def cache_hit_rate(self) -> float:
        total = self.cache_hits + self.cache_misses
        if total == 0:
            return 0.0
        return self.cache_hits / total


# =============================================================================
# UNIFIED COMPRESSOR
# =============================================================================

class UnifiedCompressor:
    """
    ONE compressor to rule them all.
    
    A-Team Consolidation: Replaces 7 different compression implementations.
    
    Features:
    1. **Context-aware compression** - Preserves task-relevant information
    2. **Shapley credit support** - Prioritizes high-impact items
    3. **Chunking for large documents** - Handles 100k+ token documents
    4. **LRU caching** - Performance optimization
    5. **Statistics tracking** - Monitor performance
    6. **Async + sync APIs** - Works everywhere
    
    Usage:
        ```python
        compressor = UnifiedCompressor()
        
        # Basic compression
        result = await compressor.compress(
            content="Very long text...",
            max_tokens=500
        )
        
        # Context-aware compression
        result = await compressor.compress(
            content="Very long text...",
            max_tokens=500,
            task_description="Agent needs to validate SQL query",
            priority_keywords=["schema", "constraints"],
            purpose="for_validation"
        )
        
        # With Shapley credits
        result = await compressor.compress(
            content="Very long text...",
            max_tokens=500,
            shapley_credits={
                "schema_info": 0.95,
                "examples": 0.1
            }
        )
        ```
    """
    
    def __init__(
        self,
        lm: Optional[Any] = None,
        enable_caching: bool = True,
        cache_size: int = 128,
        min_retention_ratio: float = 0.5,
        config: Optional[Any] = None,
    ):
        """
        Initialize unified compressor.
        
        Args:
            lm: Optional DSPy language model. If None, uses lightweight model from config or dspy.settings.lm.
            enable_caching: Whether to cache compression results (default: True)
            cache_size: LRU cache size (default: 128)
            config: Optional SynapseConfig. If provided and has default_lightweight_model,
                    creates a dedicated lightweight LM for compression instead of using
                    the main (expensive) model. This dramatically reduces cost and latency
                    for compression operations.
        """
        self.lm = lm
        self._config = config  # Store for passing to ContentIngestionPipeline
        
        # 🔴 A-TEAM FIX: Use lightweight model for compression (NOT the main expensive model!)
        # Compression is a low-value operation that doesn't need Claude Sonnet 4.5.
        # Use gpt-4o-mini or equivalent lightweight model to reduce cost and latency.
        if lm is None and DSPY_AVAILABLE:
            lightweight_model = None
            if config is not None:
                lightweight_model = getattr(config, 'default_lightweight_model', None)
            
            if lightweight_model:
                try:
                    api_key = getattr(config, 'model_api_key', None) or os.environ.get('LITELLM_API_KEY', '')
                    api_base = getattr(config, 'model_api_base', None) or os.environ.get('LITELLM_BASE_URL', '')
                    self.lm = dspy.LM(
                        model=lightweight_model,
                        api_key=api_key,
                        api_base=api_base,
                        temperature=0.3,
                        max_tokens=4096,
                    )
                    logger.info(f"✅ UnifiedCompressor using lightweight model: {lightweight_model}")
                except Exception as e:
                    logger.warning(f"⚠️ Failed to create lightweight LM for compression: {e}, falling back to default")
                    if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                        self.lm = dspy.settings.lm
            else:
                if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                    self.lm = dspy.settings.lm
        
        self.enable_caching = enable_caching
        self.cache_size = cache_size
        self.min_retention_ratio = max(0.05, min(1.0, float(min_retention_ratio)))
        self.stats = CompressionStats()
        
        # Initialize compressor
        if DSPY_AVAILABLE:
            self.compressor = dspy.ChainOfThought(UnifiedCompressionSignature)
            logger.info("✅ UnifiedCompressor initialized with DSPy")
        else:
            self.compressor = None
            logger.warning("⚠️  UnifiedCompressor initialized WITHOUT DSPy (will use fallback)")
        
        # Cache: (content_hash, max_tokens, context_hash) -> compressed_result
        self._cache: Dict[Tuple[int, int, int], str] = {}
        self._cache_order: List[Tuple[int, int, int]] = []
    
    async def compress(
        self,
        content: str,
        max_tokens: int,
        task_description: Optional[str] = None,
        priority_keywords: Optional[List[str]] = None,
        shapley_credits: Optional[Dict[str, float]] = None,
        purpose: Optional[str] = None,
        goal: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Intelligently compress content based on task needs.
        
        🔴 A-TEAM CRITICAL FIX: Added token limit check BEFORE calling LLM!
        
        The compressor can ONLY handle inputs that fit in the model's context window.
        If content is too large, this method will FAIL FAST with a helpful error.
        
        Use ContentIngestionPipeline instead for automatic chunking/compression.
        
        A-Team Enhancement: Context-aware, Shapley-impact-based prioritization.
        
        Args:
            content: FULL content (NO pre-slicing!)
            max_tokens: Target token count
            task_description: Optional: What the agent needs to do
            priority_keywords: Optional: Keywords that MUST be preserved
            shapley_credits: Optional: Dict of {item: credit} for prioritization
            purpose: Optional: Why compressing (for_validation, for_memory, etc.)
            goal: Optional: Overall system goal
            **kwargs: Additional context
        
        Returns:
            Compressed content preserving critical information
        
        Raises:
            ValueError: If content is too large for compressor (exceeds model context window)
        """
        start_time = time.time()
        
        # Estimate current tokens (rough: 4 chars = 1 token)
        current_tokens = len(content) // 4
        requested_max_tokens = max_tokens

        # Policy guard: avoid catastrophic information loss from over-compression.
        min_allowed_tokens = max(1, int(current_tokens * self.min_retention_ratio))
        if max_tokens < min_allowed_tokens:
            logger.warning(
                f"⚖️ Compression policy guard: requested {max_tokens} tokens for {current_tokens} input "
                f"({(max_tokens / max(current_tokens, 1)):.1%} retention). "
                f"Raising target to {min_allowed_tokens} tokens (min retention "
                f"{self.min_retention_ratio:.0%})."
            )
            max_tokens = min_allowed_tokens
        
        logger.info(f"🗜️  UnifiedCompressor: {current_tokens} → {max_tokens} tokens (requested={requested_max_tokens})")
        
        # If already within budget, return as-is
        if current_tokens <= max_tokens:
            logger.info(f"   ✅ Already within budget, no compression needed")
            return content
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔴 A-TEAM FIX (E7b): Auto-delegate to ContentIngestionPipeline
        # when compression ratio is too extreme for direct LLM compression.
        # A single LLM call cannot meaningfully compress 67K→1K tokens.
        # The pipeline chunks first, compresses each chunk, then merges.
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        compression_ratio = current_tokens / max(max_tokens, 1)
        if compression_ratio > 10.0:
            logger.info(
                f"   📄 Compression ratio too extreme ({compression_ratio:.1f}:1). "
                f"Delegating to ContentIngestionPipeline for chunk-then-compress."
            )
            try:
                from .content_ingestion import ContentIngestionPipeline
                if not hasattr(self, '_ingestion_pipeline'):
                    self._ingestion_pipeline = ContentIngestionPipeline(config=self._config)
                result = await self._ingestion_pipeline.process(
                    content=content,
                    max_tokens=max_tokens,
                    query=task_description or goal or "Compress content preserving critical information",
                    goal=goal or task_description or "Context compression",
                    context_type=purpose or "context"
                )
                duration = time.time() - start_time
                self.stats.total_compressions += 1
                self.stats.total_time += duration
                self.stats.total_input_tokens += current_tokens
                self.stats.total_output_tokens += result.final_tokens
                logger.info(
                    f"   ✅ Pipeline compressed {current_tokens} → {result.final_tokens} tokens "
                    f"via {result.processing_path} in {duration:.2f}s "
                    f"(retention: {result.compression_ratio:.1%})"
                )
                return result.content
            except Exception as e:
                logger.warning(f"   ⚠️ Pipeline delegation failed: {e}. Attempting direct compression.")
                # Fall through to direct compression as last resort
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # 🔴 A-TEAM CRITICAL FIX: Check token limits BEFORE calling LLM
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # Get model's context window
        model_context = self._get_model_context_window()
        safety_margin = 2000  # Reserve for prompt, output, etc.
        
        # Validate that max_tokens is reasonable for the model context
        max_output_reasonable = model_context - safety_margin - 64000  # Leave room for input
        
        if max_tokens > max_output_reasonable:
            logger.warning(
                f"⚠️  Requested max_tokens ({max_tokens}) exceeds reasonable limit "
                f"for model context ({model_context}). Capping to {max_output_reasonable}."
            )
            # Auto-adjust to prevent negative max_compressor_input
            max_tokens = max_output_reasonable
        
        max_compressor_input = model_context - max_tokens - safety_margin
        
        # Sanity check: max_compressor_input should be positive
        if max_compressor_input <= 0:
            error_msg = (
                f"Invalid compression parameters: "
                f"model_context={model_context}, max_tokens={max_tokens}, safety={safety_margin} "
                f"results in max_compressor_input={max_compressor_input} (must be positive). "
                f"\n\n"
                f"🔧 FIX: Either increase model context window or reduce max_tokens target."
            )
            logger.error(f"❌ {error_msg}")
            raise ValueError(error_msg)
        
        if current_tokens > max_compressor_input:
            # 🔴 A-TEAM FIX (E7b): Instead of raising, delegate to pipeline
            logger.warning(
                f"   ⚠️ Content ({current_tokens} tokens) exceeds direct compression limit "
                f"({max_compressor_input} tokens). Auto-delegating to ContentIngestionPipeline."
            )
            try:
                from .content_ingestion import ContentIngestionPipeline
                if not hasattr(self, '_ingestion_pipeline'):
                    self._ingestion_pipeline = ContentIngestionPipeline(config=self._config)
                result = await self._ingestion_pipeline.process(
                    content=content,
                    max_tokens=max_tokens,
                    query=task_description or goal or "Compress content preserving critical information",
                    goal=goal or task_description or "Context compression",
                    context_type=purpose or "context"
                )
                duration = time.time() - start_time
                self.stats.total_compressions += 1
                self.stats.total_time += duration
                self.stats.total_input_tokens += current_tokens
                self.stats.total_output_tokens += result.final_tokens
                logger.info(
                    f"   ✅ Pipeline compressed {current_tokens} → {result.final_tokens} tokens "
                    f"via {result.processing_path} in {duration:.2f}s"
                )
                return result.content
            except Exception as e:
                error_msg = (
                    f"Content too large for compression and pipeline failed: {e}. "
                    f"Content: {current_tokens} tokens, limit: {max_compressor_input} tokens."
                )
                logger.error(f"❌ {error_msg}")
                raise ValueError(error_msg)
        
        logger.debug(f"   ✅ Content fits in model window ({current_tokens}/{max_compressor_input} tokens)")
        
        # Check cache
        if self.enable_caching:
            cache_key = self._compute_cache_key(
                content, max_tokens, task_description, priority_keywords, shapley_credits
            )
            if cache_key in self._cache:
                self.stats.cache_hits += 1
                logger.info(f"   💾 Cache hit! Returning cached result")
                return self._cache[cache_key]
            self.stats.cache_misses += 1
        
        # Standard compression (no chunking - that's ContentIngestionPipeline's job!)
        result = await self._compress_direct(
            content=content,
            max_tokens=max_tokens,
            task_description=task_description or "",
            priority_keywords=", ".join(priority_keywords or []),
            shapley_credits=shapley_credits,
            purpose=purpose or "",
            goal=goal or ""
        )
        
        # Update stats
        duration = time.time() - start_time
        self.stats.total_compressions += 1
        self.stats.total_time += duration
        self.stats.total_input_tokens += current_tokens
        self.stats.total_output_tokens += len(result) // 4
        
        # Cache result
        if self.enable_caching:
            self._add_to_cache(cache_key, result)
        
        logger.info(f"   ✅ Compressed in {duration:.2f}s")
        return result
    
    def compress_sync(self, content: str, max_tokens: int, **kwargs) -> str:
        """
        Synchronous version of compress().
        
        For compatibility with sync codebases. Handles both cases:
        - When called from outside an event loop: uses asyncio.run()
        - When called from within an event loop: uses ThreadPoolExecutor
        
        Returns:
            str: Compressed content (same as async compress())
        """
        try:
            # Check if there's already a running event loop
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop - we can use asyncio.run()
            return asyncio.run(self.compress(content, max_tokens, **kwargs))
        
        # There's a running loop - use thread pool to avoid blocking
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(
                asyncio.run,
                self.compress(content, max_tokens, **kwargs)
            )
            return future.result()
    
    def _get_model_context_window(self) -> int:
        """
        Get model's context window size dynamically.
        
        A-Team Requirement: NO hardcoded thresholds!
        Uses token_counter.py catalog for accurate limits.
        
        Priority:
        1. DSPy LM's context_window attribute
        2. Model limits catalog (token_counter.py)
        3. Fallback: 128000 (modern model minimum)
        """
        try:
            import dspy
            if hasattr(dspy.settings, 'lm') and dspy.settings.lm:
                lm = dspy.settings.lm
                # Try context_window attribute
                context_window = getattr(lm, 'context_window', None)
                if context_window and context_window > 0:
                    return context_window
                
                # Try model name + catalog lookup
                model_name = getattr(lm, 'model', None) or getattr(lm, 'model_name', None)
                if model_name:
                    try:
                        from .token_counter import get_model_limits
                        limits = get_model_limits(model_name)
                        return limits.get('max_prompt', 128000)
                    except (ImportError, ValueError):
                        pass
        except Exception as e:
            logger.debug(f"Could not get model context window: {e}")
        
        # A-TEAM FIX: Modern default (NOT 8000!)
        return 128000
    
    async def _compress_direct(
        self,
        content: str,
        max_tokens: int,
        task_description: str = "",
        priority_keywords: str = "",
        shapley_credits: Optional[Dict[str, float]] = None,
        purpose: str = "",
        goal: str = ""
    ) -> str:
        """
        Direct compression using LLM.
        
        Args:
            All fields from UnifiedCompressionSignature
        
        Returns:
            Compressed content
        
        Raises:
            RuntimeError: If DSPy/LLM is not configured
        """
        # 🔥 A-TEAM CRITICAL FIX: NO heuristic fallback!
        if not self.compressor:
            raise RuntimeError(
                "❌ UnifiedCompressor requires DSPy/LLM intelligence!\n"
                "Please configure dspy.settings.lm before using:\n"
                "  import dspy\n"
                "  dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))\n"
                "\n"
                "Content compression is a critical agentic operation. "
                "Cannot fall back to heuristic truncation as it loses context and semantic meaning. "
                "This would cause silent failures in downstream components."
            )
        
        # Format Shapley credits if provided
        high_impact = ""
        low_impact = ""
        if shapley_credits:
            high_impact, low_impact = self._format_shapley(shapley_credits)
        
        try:
            # Call LLM compressor
            result = self.compressor(
                content=content,
                max_tokens=str(max_tokens),
                task_description=task_description,
                priority_keywords=priority_keywords,
                high_impact_items=high_impact,
                low_impact_items=low_impact,
                purpose=purpose,
                goal=goal
            )
            
            compressed = str(getattr(result, 'compressed', content))
            
            # 🔴 A-TEAM FIX: Validate compression didn't lose too much
            input_len = len(content)
            output_len = len(compressed)
            retention_ratio = output_len / max(input_len, 1)
            
            if output_len < 50 and input_len > 500:
                # Near-empty output from substantial input = catastrophic compression
                logger.error(
                    f"  ❌ COMPRESSION QUALITY ALERT: Output is near-empty ({output_len} chars) "
                    f"from {input_len} char input (retention: {retention_ratio:.1%}). "
                    f"Falling back to truncation to preserve content."
                )
                # Truncate instead - better to have raw content than empty content
                return content[:max_tokens * 4]  # Rough: 4 chars per token
            
            if retention_ratio < 0.05 and input_len > 1000:  # Less than 5% retained from substantial input
                logger.warning(
                    f"  ⚠️ COMPRESSION QUALITY WARNING: Only {retention_ratio:.1%} of content retained. "
                    f"Catastrophic information loss detected. "
                    f"Input: {input_len} chars, Output: {output_len} chars. "
                    f"Falling back to smart truncation to preserve content."
                )
                # 🔴 A-TEAM FIX: When LLM compresses too aggressively (< 5% retained),
                # fall back to smart truncation. Better to have raw content than a tiny summary.
                # Keep first 70% and last 30% of the target to preserve both context and conclusion.
                target_chars = max_tokens * 4  # Rough: 4 chars per token
                if target_chars < input_len:
                    head_chars = int(target_chars * 0.7)
                    tail_chars = target_chars - head_chars - 30  # 30 for separator
                    compressed = (
                        content[:head_chars] 
                        + "\n\n[...content compressed...]\n\n" 
                        + content[-tail_chars:]
                    )
                else:
                    compressed = content  # Target is larger than input, no truncation needed
            
            # Log optional outputs if available
            if hasattr(result, 'compression_ratio'):
                logger.debug(f"   Compression ratio: {result.compression_ratio}")
            if hasattr(result, 'what_was_removed'):
                logger.debug(f"   Removed: {result.what_was_removed}")
            
            return compressed
            
        except Exception as e:
            # 🔥 A-TEAM CRITICAL FIX: NO heuristic fallback on LLM failure!
            raise RuntimeError(
                f"❌ LLM compression failed: {e}\n"
                "UnifiedCompressor is an agentic component that requires LLM intelligence. "
                "Cannot fall back to heuristic truncation as it loses context and semantic meaning. "
                "Please check LLM configuration and content quality."
            )
    
    def _format_shapley(self, shapley_credits: Dict[str, float]) -> Tuple[str, str]:
        """
        Format Shapley credits for LLM prompt.
        
        Args:
            shapley_credits: Dict of {item: credit_score}
        
        Returns:
            (high_impact_items, low_impact_items) as formatted strings
        """
        if not shapley_credits:
            return "", ""
        
        # Sort by credit
        sorted_items = sorted(shapley_credits.items(), key=lambda x: x[1], reverse=True)
        
        # Split into high (top 30%) and low (bottom 30%)
        n = len(sorted_items)
        high_threshold = int(n * 0.3)
        low_threshold = int(n * 0.7)
        
        high_items = [f"{item} (credit: {score:.2f})" for item, score in sorted_items[:high_threshold]]
        low_items = [f"{item} (credit: {score:.2f})" for item, score in sorted_items[low_threshold:]]
        
        high_impact = ", ".join(high_items) if high_items else ""
        low_impact = ", ".join(low_items) if low_items else ""
        
        return high_impact, low_impact
    
    def _compute_cache_key(
        self,
        content: str,
        max_tokens: int,
        task_description: Optional[str],
        priority_keywords: Optional[List[str]],
        shapley_credits: Optional[Dict[str, float]]
    ) -> Tuple[int, int, int]:
        """
        Compute cache key for compression request.
        
        Returns:
            (content_hash, max_tokens, context_hash)
        """
        content_hash = hash(content)
        context_parts = [
            task_description or "",
            ",".join(priority_keywords or []),
            str(sorted(shapley_credits.items()) if shapley_credits else "")
        ]
        context_hash = hash("::".join(context_parts))
        return (content_hash, max_tokens, context_hash)
    
    def _add_to_cache(self, key: Tuple[int, int, int], value: str):
        """Add result to LRU cache."""
        # Remove oldest if cache full
        if len(self._cache) >= self.cache_size:
            oldest_key = self._cache_order.pop(0)
            del self._cache[oldest_key]
        
        # Add new entry
        self._cache[key] = value
        self._cache_order.append(key)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get compression statistics.
        
        Returns:
            Dictionary with compression stats
        """
        return {
            'total_compressions': self.stats.total_compressions,
            'total_time': self.stats.total_time,
            'avg_time': self.stats.avg_time,
            'total_input_tokens': self.stats.total_input_tokens,
            'total_output_tokens': self.stats.total_output_tokens,
            'avg_compression_ratio': self.stats.avg_compression_ratio,
            'cache_hits': self.stats.cache_hits,
            'cache_misses': self.stats.cache_misses,
            'cache_hit_rate': self.stats.cache_hit_rate,
            'chunked_compressions': self.stats.chunked_compressions,
            'cache_size': len(self._cache)
        }
    
    def reset_stats(self):
        """Reset statistics (useful for testing)."""
        self.stats = CompressionStats()
    
    def clear_cache(self):
        """Clear compression cache."""
        self._cache.clear()
        self._cache_order.clear()
        logger.info("♻️  Compression cache cleared")


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

# Global compressor instance (lazy initialization)
_global_compressor: Optional[UnifiedCompressor] = None


def get_global_compressor(config=None) -> UnifiedCompressor:
    """
    Get or create global compressor instance.
    
    Args:
        config: Optional SynapseConfig for lightweight model routing.
    
    Returns:
        Global UnifiedCompressor instance
    """
    global _global_compressor
    if _global_compressor is None:
        _global_compressor = UnifiedCompressor(config=config)
    return _global_compressor


async def compress(content: str, max_tokens: int, **kwargs) -> str:
    """
    Convenience function for quick compression.
    
    Uses global compressor instance.
    
    Args:
        content: Content to compress
        max_tokens: Target token count
        **kwargs: Additional arguments for compress()
    
    Returns:
        Compressed content
    """
    compressor = get_global_compressor()
    return await compressor.compress(content, max_tokens, **kwargs)


def compress_sync(content: str, max_tokens: int, **kwargs) -> str:
    """
    Convenience function for quick synchronous compression.
    
    Uses global compressor instance.
    
    Args:
        content: Content to compress
        max_tokens: Target token count
        **kwargs: Additional arguments for compress()
    
    Returns:
        Compressed content
    """
    compressor = get_global_compressor()
    return compressor.compress_sync(content, max_tokens, **kwargs)


__all__ = [
    'UnifiedCompressor',
    'UnifiedCompressionSignature',
    'CompressionStats',
    'get_global_compressor',
    'compress',
    'compress_sync'
]
