"""
MetaDataFetcher - Production-Grade Proactive Metadata Fetching

🎯 SOTA DESIGN PRINCIPLES:
- Automatic @synapse_method discovery via introspection
- DSPy ReAct agent with intelligent tool selection
- Caching with TTL for performance
- Comprehensive error handling and retry logic
- Detailed logging for debugging
- Thread-safe operations
- Performance monitoring and metrics
- Fallback strategies for robustness

Architecture:
1. Tool Discovery: Auto-discovers @synapse_method decorated methods
2. Tool Conversion: Wraps methods as dspy.Tool objects
3. ReAct Agent: Uses DSPy ReAct for intelligent metadata fetching
4. Result Caching: Caches results with configurable TTL
5. Error Recovery: Automatic retries with exponential backoff
"""

import dspy
import logging
import time
import json
import hashlib
import threading
from typing import Dict, Any, List, Optional, Callable, Set, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import inspect
import traceback
import time

from .logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class ToolMetadata:
    """Metadata about a discovered tool."""
    name: str
    func: Callable
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    returns: Optional[str] = None
    cache_ttl: int = 240  # 5 minutes default
    when_to_use: str = "Use when relevant"
    call_count: int = 0
    total_time: float = 0.0
    last_called: Optional[datetime] = None
    success_count: int = 0
    failure_count: int = 0


@dataclass
class CacheEntry:
    """Cached metadata result."""
    data: Any
    timestamp: datetime
    ttl: int
    query_hash: str
    
    def is_expired(self) -> bool:
        """Check if cache entry is expired."""
        return datetime.now() > self.timestamp + timedelta(seconds=self.ttl)


class MetaDataFetcherSignature(dspy.Signature):
    """
    Intelligent metadata fetching signature for ReAct agent.
    
    The agent analyzes the query and decides which metadata tools to call
    to gather all necessary information for downstream actors.
    """
    query: str = dspy.InputField(
        desc="User's natural language query that needs metadata"
    )
    available_tools: str = dspy.InputField(
        desc="Comprehensive catalog of available metadata tools with descriptions and usage guidelines"
    )
    previous_context: str = dspy.InputField(
        desc="Any previously fetched metadata or context from prior steps"
    )
    
    reasoning: str = dspy.OutputField(
        desc="Step-by-step reasoning about which metadata is needed and which tools to call"
    )
    tool_sequence: str = dspy.OutputField(
        desc="Ordered list of tools to call with rationale for each"
    )
    fetched_metadata: str = dspy.OutputField(
        desc="JSON dictionary of all fetched metadata with semantic keys (e.g., {'business_terms': {...}, 'available_tables': [...]})"
    )


class MetaDataFetcher:
    """
    Production-Grade Metadata Fetcher using DSPy ReAct.
    
    Features:
    - Automatic tool discovery via @synapse_method decorator
    - Intelligent metadata fetching using DSPy ReAct agent
    - Result caching with configurable TTL
    - Comprehensive error handling and retries
    - Performance monitoring and metrics
    - Thread-safe operations
    - Detailed logging for debugging
    
    Usage:
        # In SwarmReVal
        fetcher = MetaDataFetcher(metadata_provider=user_metadata)
        metadata = fetcher.fetch(query="User's natural language query")
        
        # Access metadata (keys depend on what tools returned)
        for key, value in metadata.items():
            logger.info(f"Fetched {key}: {value}")
    """
    
    def __init__(
        self,
        metadata_provider: Any,
        enable_cache: bool = True,
        default_cache_ttl: int = 300,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        react_max_iters: int = 5
    ):
        """
        Initialize MetaDataFetcher with advanced configuration.
        
        Args:
            metadata_provider: Instance with @synapse_method decorated methods
            enable_cache: Enable result caching (default: True)
            default_cache_ttl: Default cache TTL in seconds (default: 300)
            max_retries: Maximum retry attempts on failure (default: 3)
            retry_delay: Initial retry delay in seconds (default: 1.0)
            react_max_iters: Max iterations for ReAct agent (default: 5)
        """
        self.metadata_provider = metadata_provider
        self.enable_cache = enable_cache
        self.default_cache_ttl = default_cache_ttl
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.react_max_iters = react_max_iters
        
        # Tool registry
        self.tools: List[dspy.Tool] = []
        self.tool_metadata: Dict[str, ToolMetadata] = {}
        
        # Caching
        self._cache: Dict[str, CacheEntry] = {}
        self._cache_lock = threading.Lock()
        
        # Metrics
        self.total_fetches = 0
        self.cache_hits = 0
        self.cache_misses = 0
        self.total_fetch_time = 0.0
        
        # ReAct agent (lazy init)
        self._react_agent = None
        
        # Initialize
        start_time = time.time()
        metadata_type = type(metadata_provider).__name__
        logger.info(f"🔧 INIT: MetaDataFetcher | metadata_type={metadata_type} | "
                   f"enable_cache={enable_cache} | cache_ttl={default_cache_ttl}s | "
                   f"max_retries={max_retries} | react_max_iters={react_max_iters}")
        
        discovery_start = time.time()
        self._discover_and_convert_tools()
        discovery_duration = time.time() - discovery_start
        
        total_duration = time.time() - start_time
        logger.info(f"✅ INIT COMPLETE: MetaDataFetcher | tools_discovered={len(self.tools)} | "
                   f"discovery_duration={discovery_duration:.3f}s | total_duration={total_duration:.3f}s")
    
    def _discover_and_convert_tools(self):
        """
        Auto-discover @synapse_method decorated methods and convert to dspy.Tool.
        
        Process:
        1. Introspect metadata_provider for all methods
        2. Find methods with _synapse_meta attribute (added by @synapse_method decorator)
        3. Extract rich metadata (desc, params, returns, cache settings, etc.)
        4. Create dspy.Tool wrapper for each method
        5. Store tool metadata for monitoring and optimization
        """
        start_time = time.time()
        metadata_type = type(self.metadata_provider).__name__
        logger.info(f"🔍 DISCOVER_TOOLS: MetaDataFetcher | metadata_type={metadata_type}")
        
        discovered_count = 0
        skipped_count = 0
        error_count = 0
        discovered_tools = []
        
        all_attrs = dir(self.metadata_provider)
        logger.debug(f"  Scanning {len(all_attrs)} total attributes")
        
        for attr_name in all_attrs:
            # Skip private/magic methods
            if attr_name.startswith('_'):
                skipped_count += 1
                continue
            
            try:
                attr_start = time.time()
                attr = getattr(self.metadata_provider, attr_name)
                attr_duration = time.time() - attr_start
                
                # Check if it's a callable with @synapse_method decorator
                if not callable(attr):
                    logger.debug(f"  '{attr_name}': Not callable, skipping")
                    continue
                
                if not hasattr(attr, '_synapse_meta'):
                    logger.debug(f"  '{attr_name}': No _synapse_meta attribute, skipping")
                    continue
                
                # Extract metadata from decorator
                meta = attr._synapse_meta
                
                # Create tool metadata
                tool_meta = ToolMetadata(
                    name=attr_name,
                    func=attr,
                    description=meta.get('desc', f"Call {attr_name}"),
                    parameters=meta.get('params', {}),
                    returns=meta.get('returns'),
                    cache_ttl=meta.get('cache_ttl', self.default_cache_ttl),
                    when_to_use=meta.get('when', "Use when relevant")
                )
                
                # Create dspy.Tool
                tool = dspy.Tool(
                    func=attr,
                    name=attr_name,
                    desc=f"{tool_meta.description}\nWhen to use: {tool_meta.when_to_use}"
                )
                
                self.tools.append(tool)
                self.tool_metadata[attr_name] = tool_meta
                discovered_count += 1
                discovered_tools.append(attr_name)
                
                logger.info(f"  ✅ DISCOVERED: {attr_name} | desc='{tool_meta.description[:50]}...' | "
                           f"cache_ttl={tool_meta.cache_ttl}s | duration={attr_duration:.3f}s")
                
            except Exception as e:
                error_count += 1
                logger.warning(f"  ⚠️  Error discovering '{attr_name}': {e}", exc_info=True)
                continue
        
        duration = time.time() - start_time
        
        if discovered_count == 0:
            logger.warning(f"⚠️  DISCOVERY COMPLETE: No @synapse_method tools found | "
                          f"scanned={len(all_attrs)} | skipped={skipped_count} | errors={error_count} | "
                          f"duration={duration:.3f}s")
        else:
            logger.info(f"✅ DISCOVERY COMPLETE: {discovered_count} tools discovered | "
                       f"scanned={len(all_attrs)} | skipped={skipped_count} | errors={error_count} | "
                       f"duration={duration:.3f}s")
            logger.debug(f"  Discovered tools: {', '.join(discovered_tools)}")
    
    async def fetch_stream(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False
    ) -> AsyncGenerator[Dict[str, Any], Dict[str, Any]]:
        """
        Proactively fetch metadata relevant to the query with event streaming.
        
        Uses intelligent caching and ReAct agent to minimize LLM calls
        and maximize metadata relevance.
        
        Args:
            query: User's natural language query
            previous_context: Any previously fetched metadata (for context)
            force_refresh: Bypass cache and fetch fresh data
        
        Yields:
            Dict events with module and message
        Returns:
            Dict of fetched metadata with semantic keys
        """
        start_time = time.time()
        self.total_fetches += 1
        
        logger.info(f"📥 FETCH: MetaDataFetcher | query_length={len(query)} | "
                   f"force_refresh={force_refresh} | cache_enabled={self.enable_cache}")
        yield {"module": "Synapse.core.metadata_fetcher", "message": f"I am starting to fetch metadata for query of length {len(query)}"}
        logger.debug(f"  Query: {query[:200]}{'...' if len(query) > 200 else ''}")
        logger.debug(f"  Previous context keys: {list(previous_context.keys()) if previous_context else 'None'}")
        
        # Check cache first (unless force_refresh)
        if not force_refresh and self.enable_cache:
            cache_check_start = time.time()
            cached_result = self._get_from_cache(query)
            cache_check_duration = time.time() - cache_check_start
            
            if cached_result is not None:
                self.cache_hits += 1
                duration = time.time() - start_time
                logger.info(f"💾 FETCH CACHE_HIT: MetaDataFetcher | "
                           f"cached_keys={len(cached_result)} | "
                           f"cache_check_duration={cache_check_duration:.3f}s | "
                           f"total_duration={duration:.3f}s")
                yield {"module": "Synapse.core.metadata_fetcher", "message": f"I found a cached result with {len(cached_result)} keys"}
                logger.debug(f"  Cached keys: {list(cached_result.keys())}")
                yield {"type": "result", "result": cached_result, "module": "Synapse.core.metadata_fetcher", "message": "I am returning the cached result"}
                return
            
            self.cache_misses += 1
            logger.debug(f"  Cache miss | cache_check_duration={cache_check_duration:.3f}s")
            yield {"module": "Synapse.core.metadata_fetcher", "message": "I did not find a cached result, will fetch fresh metadata"}
        
        # No cache hit - fetch fresh metadata
        if not self.tools:
            duration = time.time() - start_time
            logger.warning(f"⚠️  FETCH FAILED: No tools available | duration={duration:.3f}s")
            yield {"module": "Synapse.core.metadata_fetcher", "message": "I encountered an error: no tools available"}
            yield {"type": "result", "result": {}, "module": "Synapse.core.metadata_fetcher", "message": "I am returning an empty result"}
            return
        
        logger.info(f"  🔵 Fetching fresh metadata with {len(self.tools)} available tools")
        yield {"module": "Synapse.core.metadata_fetcher", "message": f"I am fetching fresh metadata with {len(self.tools)} available tools"}
        
        # Fetch with retry logic
        fetch_start = time.time()
        result = None
        async for event in self._fetch_with_retry_stream(query, previous_context):
            yield event
            if isinstance(event, dict) and event.get("type") == "result":
                result = event.get("result")
        fetch_duration = time.time() - fetch_start
        
        if result is None:
            logger.warning("No result from _fetch_with_retry_stream")
            result = {}
        
        logger.debug(f"  Fetch completed: {len(result)} items | fetch_duration={fetch_duration:.3f}s")
        
        # Cache result
        if self.enable_cache and result:
            cache_store_start = time.time()
            self._add_to_cache(query, result)
            cache_store_duration = time.time() - cache_store_start
            logger.debug(f"  Cached result | cache_store_duration={cache_store_duration:.3f}s")
            yield {"module": "Synapse.core.metadata_fetcher", "message": "I have cached the fetched result"}
        
        # Update metrics
        elapsed = time.time() - start_time
        self.total_fetch_time += elapsed
        
        logger.info(f"✅ FETCH COMPLETE: MetaDataFetcher | "
                   f"items={len(result)} | fetch_duration={fetch_duration:.3f}s | "
                   f"total_duration={elapsed:.3f}s")
        yield {"module": "Synapse.core.metadata_fetcher", "message": f"I have completed fetching metadata, got {len(result)} items"}
        logger.debug(f"  Fetched keys: {list(result.keys())}")
        
        yield {"type": "result", "result": result, "module": "Synapse.core.metadata_fetcher", "message": "I am returning the fetched metadata"}
        return
    
    def fetch(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Synchronous wrapper for fetch_stream.
        """
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, we need to use a different approach
                # For now, just call the sync version directly
                return self._fetch_sync(query, previous_context, force_refresh)
        except RuntimeError:
            pass
        
        # Run async version
        async def _run():
            result = None
            async for event in self.fetch_stream(query, previous_context, force_refresh):
                if isinstance(event, dict) and event.get("type") == "result":
                    result = event.get("result")
            return result
        
        return asyncio.run(_run())
    
    def _fetch_sync(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Synchronous implementation of fetch (for backward compatibility).
        """
        start_time = time.time()
        self.total_fetches += 1
        
        logger.info(f"📥 FETCH: MetaDataFetcher | query_length={len(query)} | "
                   f"force_refresh={force_refresh} | cache_enabled={self.enable_cache}")
        logger.debug(f"  Query: {query[:200]}{'...' if len(query) > 200 else ''}")
        logger.debug(f"  Previous context keys: {list(previous_context.keys()) if previous_context else 'None'}")
        
        # Check cache first (unless force_refresh)
        if not force_refresh and self.enable_cache:
            cache_check_start = time.time()
            cached_result = self._get_from_cache(query)
            cache_check_duration = time.time() - cache_check_start
            
            if cached_result is not None:
                self.cache_hits += 1
                duration = time.time() - start_time
                logger.info(f"💾 FETCH CACHE_HIT: MetaDataFetcher | "
                           f"cached_keys={len(cached_result)} | "
                           f"cache_check_duration={cache_check_duration:.3f}s | "
                           f"total_duration={duration:.3f}s")
                logger.debug(f"  Cached keys: {list(cached_result.keys())}")
                return cached_result
            
            self.cache_misses += 1
            logger.debug(f"  Cache miss | cache_check_duration={cache_check_duration:.3f}s")
        
        # No cache hit - fetch fresh metadata
        if not self.tools:
            duration = time.time() - start_time
            logger.warning(f"⚠️  FETCH FAILED: No tools available | duration={duration:.3f}s")
            return {}
        
        logger.info(f"  🔵 Fetching fresh metadata with {len(self.tools)} available tools")
        
        # Fetch with retry logic
        fetch_start = time.time()
        result = self._fetch_with_retry(query, previous_context)
        fetch_duration = time.time() - fetch_start
        
        logger.debug(f"  Fetch completed: {len(result)} items | fetch_duration={fetch_duration:.3f}s")
        
        # Cache result
        if self.enable_cache and result:
            cache_store_start = time.time()
            self._add_to_cache(query, result)
            cache_store_duration = time.time() - cache_store_start
            logger.debug(f"  Cached result | cache_store_duration={cache_store_duration:.3f}s")
        
        # Update metrics
        elapsed = time.time() - start_time
        self.total_fetch_time += elapsed
        
        logger.info(f"✅ FETCH COMPLETE: MetaDataFetcher | "
                   f"items={len(result)} | fetch_duration={fetch_duration:.3f}s | "
                   f"total_duration={elapsed:.3f}s")
        logger.debug(f"  Fetched keys: {list(result.keys())}")
        
        return result
    
    async def _fetch_with_retry_stream(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[Dict[str, Any], Dict[str, Any]]:
        """
        Fetch metadata with automatic retry on failure and event streaming.
        
        Implements exponential backoff for retries.
        """
        import asyncio
        last_error = None
        retry_delay = self.retry_delay
        
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.debug(f"🔄 Fetch attempt {attempt}/{self.max_retries}")
                yield {"module": "Synapse.core.metadata_fetcher", "message": f"I am starting fetch attempt {attempt} of {self.max_retries}"}
                result = None
                async for event in self._execute_fetch_stream(query, previous_context):
                    yield event
                    if isinstance(event, dict) and event.get("type") == "result":
                        result = event.get("result")
                if result is not None:
                    yield {"type": "result", "result": result, "module": "Synapse.core.metadata_fetcher", "message": f"I successfully fetched metadata on attempt {attempt}"}
                    return
                
            except Exception as e:
                last_error = e
                logger.warning(f"⚠️  Fetch attempt {attempt} failed: {e}")
                yield {"module": "Synapse.core.metadata_fetcher", "message": f"I encountered an error on attempt {attempt}: {str(e)}"}
                
                if attempt < self.max_retries:
                    logger.info(f"   Retrying in {retry_delay:.1f}s...")
                    yield {"module": "Synapse.core.metadata_fetcher", "message": f"I will retry in {retry_delay:.1f} seconds"}
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.error(f"❌ All {self.max_retries} fetch attempts failed")
                    logger.error(f"   Last error: {last_error}")
                    logger.error(traceback.format_exc())
                    yield {"module": "Synapse.core.metadata_fetcher", "message": f"I have exhausted all {self.max_retries} retry attempts"}
        
        # All retries failed - return empty dict
        yield {"type": "result", "result": {}, "module": "Synapse.core.metadata_fetcher", "message": "I am returning an empty result after all retries failed"}
        return
    
    def _fetch_with_retry(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Synchronous implementation of _fetch_with_retry (for backward compatibility).
        """
        last_error = None
        retry_delay = self.retry_delay
        
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.debug(f"🔄 Fetch attempt {attempt}/{self.max_retries}")
                result = self._execute_fetch(query, previous_context)
                return result
                
            except Exception as e:
                last_error = e
                logger.warning(f"⚠️  Fetch attempt {attempt} failed: {e}")
                
                if attempt < self.max_retries:
                    logger.info(f"   Retrying in {retry_delay:.1f}s...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.error(f"❌ All {self.max_retries} fetch attempts failed")
                    logger.error(f"   Last error: {last_error}")
                    logger.error(traceback.format_exc())
        
        # All retries failed - return empty dict
        return {}
    
    async def _execute_fetch_stream(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[Dict[str, Any], Dict[str, Any]]:
        """
        Execute actual metadata fetch using ReAct agent with event streaming.
        
        This is the core fetching logic that uses DSPy ReAct
        to intelligently select and call metadata tools.
        """
        # Initialize ReAct agent (lazy)
        if self._react_agent is None:
            self._react_agent = dspy.ReAct(
                signature=MetaDataFetcherSignature,
                tools=self.tools,
                max_iters=self.react_max_iters
            )
            logger.debug("🤖 ReAct agent initialized")
            yield {"module": "Synapse.core.metadata_fetcher", "message": "I have initialized the ReAct agent"}
        
        # Generate tool catalog for LLM
        tool_catalog = self._generate_tool_catalog()
        yield {"module": "Synapse.core.metadata_fetcher", "message": f"I have generated a tool catalog with {len(self.tools)} tools"}
        
        # Prepare previous context
        context_str = json.dumps(previous_context or {}, indent=2)
        
        # Execute ReAct
        logger.debug("🤖 Executing ReAct agent...")
        yield {"module": "Synapse.core.metadata_fetcher", "message": "I am executing the ReAct agent to fetch metadata"}
        result = self._react_agent(
            query=query,
            available_tools=tool_catalog,
            previous_context=context_str
        )
        
        # Extract and parse fetched metadata
        fetched_data = self._parse_react_output(result)
        yield {"module": "Synapse.core.metadata_fetcher", "message": f"I have parsed the ReAct output and extracted {len(fetched_data)} metadata items"}
        
        # Log reasoning if available
        if hasattr(result, 'reasoning') and result.reasoning:
            logger.debug(f"💭 Agent reasoning: {result.reasoning[:200]}...")
            yield {"module": "Synapse.core.metadata_fetcher", "message": f"I have agent reasoning: {result.reasoning[:100]}..."}
        
        # A-TEAM FIX: Trust the ReAct agent's tool selection (no SQL-specific overrides)
        yield {"type": "result", "result": fetched_data, "module": "Synapse.core.metadata_fetcher", "message": "I am returning the fetched metadata"}
        return
    
    def _execute_fetch(
        self,
        query: str,
        previous_context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Synchronous implementation of _execute_fetch (for backward compatibility).
        """
        # Initialize ReAct agent (lazy)
        if self._react_agent is None:
            self._react_agent = dspy.ReAct(
                signature=MetaDataFetcherSignature,
                tools=self.tools,
                max_iters=self.react_max_iters
            )
            logger.debug("🤖 ReAct agent initialized")
        
        # Generate tool catalog for LLM
        tool_catalog = self._generate_tool_catalog()
        
        # Prepare previous context
        context_str = json.dumps(previous_context or {}, indent=2)
        
        # Execute ReAct
        logger.debug("🤖 Executing ReAct agent...")
        result = self._react_agent(
            query=query,
            available_tools=tool_catalog,
            previous_context=context_str
        )
        
        # Extract and parse fetched metadata
        fetched_data = self._parse_react_output(result)
        
        # Log reasoning if available
        if hasattr(result, 'reasoning') and result.reasoning:
            logger.debug(f"💭 Agent reasoning: {result.reasoning[:200]}...")
        
        # A-TEAM FIX: Trust the ReAct agent's tool selection (no SQL-specific overrides)
        return fetched_data
    
    def _generate_tool_catalog(self) -> str:
        """
        Generate comprehensive tool catalog for LLM.
        
        Includes tool names, descriptions, parameters, and usage guidelines.
        """
        catalog_lines = ["Available Metadata Tools:", ""]
        
        for tool_name, tool_meta in self.tool_metadata.items():
            catalog_lines.append(f"### {tool_name}")
            catalog_lines.append(f"Description: {tool_meta.description}")
            catalog_lines.append(f"When to use: {tool_meta.when_to_use}")
            
            if tool_meta.parameters:
                params_str = ", ".join([
                    f"{k}: {v}" for k, v in tool_meta.parameters.items()
                ])
                catalog_lines.append(f"Parameters: {params_str}")
            
            if tool_meta.returns:
                catalog_lines.append(f"Returns: {tool_meta.returns}")
            
            # Add usage stats if available
            if tool_meta.call_count > 0:
                success_rate = (tool_meta.success_count / tool_meta.call_count) * 100
                avg_time = tool_meta.total_time / tool_meta.call_count
                catalog_lines.append(
                    f"Stats: {tool_meta.call_count} calls, "
                    f"{success_rate:.0f}% success, "
                    f"avg {avg_time:.2f}s"
                )
            
            catalog_lines.append("")  # Blank line between tools
        
        return "\n".join(catalog_lines)
    
    def _parse_react_output(self, result: Any) -> Dict[str, Any]:
        """
        Parse ReAct agent output to extract fetched metadata.
        
        🔥 A-TEAM FIX: Extract tool outputs from DSPy ReAct trajectory!
        DSPy ReAct stores trajectory as: {thought_0, tool_name_0, tool_args_0, observation_0, ...}
        """
        fetched_data = {}
        
        # 🔥 STRATEGY 1: Extract from DSPy ReAct trajectory (CORRECT FORMAT!)
        if hasattr(result, 'trajectory') and result.trajectory:
            trajectory = result.trajectory
            logger.info(f"🔍 Parsing DSPy ReAct trajectory with {len(trajectory)} keys")
            
            # Find all observation keys (observation_0, observation_1, ...)
            tool_calls = {}
            for key in trajectory.keys():
                if key.startswith('tool_name_'):
                    idx = key.split('_')[2]  # Extract index
                    tool_name = trajectory.get(f'tool_name_{idx}')
                    observation = trajectory.get(f'observation_{idx}')
                    
                    if tool_name and observation and tool_name != 'finish':
                        tool_calls[idx] = {'tool': tool_name, 'output': observation}
                        logger.info(f"✅ Found tool call {idx}: {tool_name}")
            
            # Map tool outputs to semantic keys
            for idx, call in tool_calls.items():
                tool_name = call['tool']
                observation = call['output']
                
                # A-TEAM FIX: Generic - always use tool_name as key (no SQL-specific hardcoding)
                try:
                    fetched_data[tool_name] = json.loads(observation) if isinstance(observation, str) else observation
                    logger.info(f"✅ Extracted {tool_name} from trajectory[{idx}]")
                except (json.JSONDecodeError, TypeError, ValueError):
                    fetched_data[tool_name] = observation
                    logger.info(f"✅ Extracted {tool_name} (raw) from trajectory[{idx}]")
        
        # STRATEGY 2: Try to parse fetched_metadata field (if LLM followed instructions)
        if hasattr(result, 'fetched_metadata') and result.fetched_metadata:
            try:
                parsed = json.loads(result.fetched_metadata)
                # Merge with trajectory data (trajectory takes precedence)
                for key, value in parsed.items():
                    if key not in fetched_data:
                        fetched_data[key] = value
                logger.info(f"✅ Merged fetched_metadata: {len(parsed)} items")
            except json.JSONDecodeError:
                logger.debug("⚠️  fetched_metadata is not valid JSON, relying on trajectory extraction")
        
        # 🔥 A-TEAM FIX: POST-PROCESS to parse filter conditions if present
        fetched_data = self._post_process_metadata(fetched_data)
        
        logger.info(f"✅ Extracted {len(fetched_data)} metadata items: {list(fetched_data.keys())}")
        
        return fetched_data
    
    def _post_process_metadata(self, fetched_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Post-process fetched metadata to enrich it.
        
        CRITICAL: Parse filter_conditions text into structured format!
        This is GENERIC - works for ANY domain, not just SQL!
        """
        # Check if we have filter conditions (text format)
        filter_text = None
        for key in ['filter_conditions', 'get_all_filter_definitions', 'filters']:
            if key in fetched_data and isinstance(fetched_data[key], str):
                filter_text = fetched_data[key]
                logger.info(f"🔍 Found filter conditions in key '{key}' ({len(filter_text)} chars)")
                break
        
        if not filter_text:
            logger.debug("No filter conditions found to parse")
            return fetched_data
        
        # Parse filter conditions using LLM (generic!)
        try:
            parsed_filters = self._parse_filter_conditions_with_llm(filter_text)
            
            if parsed_filters:
                # Store both raw and parsed
                fetched_data['filter_conditions_parsed'] = parsed_filters
                logger.info(f"✅ Parsed {len(parsed_filters)} filter condition sections")
            else:
                logger.warning("⚠️  Filter parsing returned empty result")
        
        except Exception as e:
            logger.warning(f"⚠️  Failed to parse filter conditions: {e}")
            # Don't crash - continue with unparsed data
        
        return fetched_data
    
    def _parse_filter_conditions_with_llm(self, filter_text: str) -> Dict[str, Any]:
        """
        Parse filter conditions text into structured format using LLM.
        
        This is GENERIC - works for ANY filter/condition text, not just SQL!
        No hardcoding of SQL keywords, business terms, or domain-specific knowledge.
        
        Args:
            filter_text: Raw text containing filter conditions (any format)
        
        Returns:
            Dict mapping category names to their filter specifications
        """
        # Use configured LM (no hardcoding of model name!)
        lm = dspy.settings.lm if dspy.settings.lm else None
        if not lm:
            logger.warning("⚠️  No LM configured, skipping filter parsing")
            return {}
        
        prompt = f"""You are a metadata parser. Extract filter/condition specifications from text.

INPUT TEXT:
{filter_text[:5000]}  

TASK:
1. Identify ALL sections that define filters, conditions, or constraints
2. For each section, extract:
   - Category/term name (the thing being filtered)
   - Required fields/columns (if mentioned)
   - Filter expression or condition (exact text)
   - Description/purpose (if provided)

OUTPUT FORMAT (JSON):
{{
    "category_name_1": {{
        "fields": ["field1", "field2"],
        "filter_expression": "exact filter text from document",
        "description": "brief description"
    }},
    ...
}}

RULES:
- Extract ONLY what's explicitly in the text
- Do NOT invent or guess data
- Use exact field/column names from text
- Preserve exact filter expressions
- If a section has no clear filters, omit it

Return ONLY the JSON, no other text."""

        try:
            # Call LLM (generic!)
            response = lm(prompt)
            
            # Handle different response formats
            if isinstance(response, list) and len(response) > 0:
                response_text = response[0]
            elif hasattr(response, 'choices') and len(response.choices) > 0:
                response_text = response.choices[0].message.content
            elif isinstance(response, str):
                response_text = response
            else:
                response_text = str(response)
            
            # Extract JSON from response (handle markdown code blocks)
            response_text = response_text.strip()
            if '```json' in response_text:
                response_text = response_text.split('```json')[1].split('```')[0].strip()
            elif '```' in response_text:
                response_text = response_text.split('```')[1].split('```')[0].strip()
            
            # Parse JSON
            parsed = json.loads(response_text)
            logger.debug(f"✅ LLM parsed {len(parsed)} filter categories")
            return parsed
        
        except Exception as e:
            logger.warning(f"⚠️  LLM parsing failed: {e}")
            return {}
    
    def _get_from_cache(self, query: str) -> Optional[Dict[str, Any]]:
        """Get cached result if available and not expired."""
        query_hash = self._hash_query(query)
        
        with self._cache_lock:
            if query_hash in self._cache:
                entry = self._cache[query_hash]
                
                if not entry.is_expired():
                    logger.debug(f"📦 Cache hit for query (age: {(datetime.now() - entry.timestamp).seconds}s)")
                    return entry.data
                else:
                    logger.debug("📦 Cache entry expired, removing")
                    del self._cache[query_hash]
        
        return None
    
    def _add_to_cache(self, query: str, data: Dict[str, Any]):
        """Add result to cache."""
        query_hash = self._hash_query(query)
        
        entry = CacheEntry(
            data=data,
            timestamp=datetime.now(),
            ttl=self.default_cache_ttl,
            query_hash=query_hash
        )
        
        with self._cache_lock:
            self._cache[query_hash] = entry
            logger.debug(f"📦 Cached result (TTL: {self.default_cache_ttl}s)")
    
    def _hash_query(self, query: str) -> str:
        """Generate hash for query (for cache keys)."""
        return hashlib.md5(query.encode()).hexdigest()
    
    def clear_cache(self):
        """Clear all cached results."""
        with self._cache_lock:
            cleared_count = len(self._cache)
            self._cache.clear()
            logger.info(f"🗑️  Cleared {cleared_count} cache entries")
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Get performance metrics.
        
        Returns:
            Dict with fetch counts, cache stats, timing info, etc.
        """
        with self._cache_lock:
            active_cache_entries = len(self._cache)
        
        cache_hit_rate = (
            (self.cache_hits / (self.cache_hits + self.cache_misses) * 100)
            if (self.cache_hits + self.cache_misses) > 0
            else 0.0
        )
        
        avg_fetch_time = (
            self.total_fetch_time / self.total_fetches
            if self.total_fetches > 0
            else 0.0
        )
        
        return {
            'total_fetches': self.total_fetches,
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'cache_hit_rate': f"{cache_hit_rate:.1f}%",
            'active_cache_entries': active_cache_entries,
            'total_fetch_time': f"{self.total_fetch_time:.2f}s",
            'avg_fetch_time': f"{avg_fetch_time:.2f}s",
            'tools_discovered': len(self.tools),
            'tool_stats': {
                name: {
                    'calls': meta.call_count,
                    'success_rate': f"{(meta.success_count/meta.call_count*100):.0f}%"
                    if meta.call_count > 0 else "N/A",
                    'avg_time': f"{(meta.total_time/meta.call_count):.2f}s"
                    if meta.call_count > 0 else "N/A"
                }
                for name, meta in self.tool_metadata.items()
                if meta.call_count > 0
            }
        }
    
    def __repr__(self) -> str:
        """String representation with key stats."""
        return (
            f"MetaDataFetcher("
            f"tools={len(self.tools)}, "
            f"fetches={self.total_fetches}, "
            f"cache_hit_rate={self.cache_hits/(self.cache_hits+self.cache_misses+1)*100:.0f}%"
            f")"
        )








