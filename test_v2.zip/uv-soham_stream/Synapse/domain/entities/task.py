"""
Task entity representing a single granular task in the workflow.
"""

from typing import List, Optional
from dataclasses import dataclass, field

from .task_types import TaskType, TaskStatus


@dataclass
class Task:
    """Represents a single granular task in the workflow."""
    
    id: str  # Unique task identifier (e.g., "task_1", "task_2")
    name: str  # Short descriptive name
    description: str  # Detailed description of what to do
    task_type: TaskType  # Type of task
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)  # List of task IDs this task depends on
    
    # Execution details
    code_snippet: Optional[str] = None  # Code to execute (if applicable)
    commands: List[str] = field(default_factory=list)  # Shell commands to run
    files_to_create: List[str] = field(default_factory=list)  # Files this task creates
    files_required: List[str] = field(default_factory=list)  # Files this task needs
    
    # Metadata
    estimated_duration: Optional[str] = None  # e.g., "5 minutes"
    priority: int = 1  # Higher = more important
    status: TaskStatus = TaskStatus.PENDING
    
    # Validation
    success_criteria: List[str] = field(default_factory=list)  # How to verify success
    failure_handling: Optional[str] = None  # What to do on failure
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        if isinstance(other, Task):
            return self.id == other.id
        return False
