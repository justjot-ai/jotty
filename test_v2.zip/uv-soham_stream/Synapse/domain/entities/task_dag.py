"""
TaskDAG - Directed Acyclic Graph of tasks with dependencies and advanced management features.
"""

import logging
from typing import Dict, List, Set, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

from .task import Task
from .task_types import TaskType, TaskStatus

logger = logging.getLogger(__name__)


@dataclass
class TaskDAG:
    """Directed Acyclic Graph of tasks with dependencies."""
    
    tasks: Dict[str, Task] = field(default_factory=dict)  # task_id -> Task
    adjacency_list: Dict[str, List[str]] = field(default_factory=dict)  # task_id -> [dependent_task_ids]
    
    # Metadata
    name: str = "Implementation Workflow"
    description: str = ""
    total_tasks: int = 0
    
    def add_task(self, task: Task) -> None:
        """Add a task to the DAG."""
        self.tasks[task.id] = task
        
        # Initialize adjacency list entry
        if task.id not in self.adjacency_list:
            self.adjacency_list[task.id] = []
        
        # Add edges for dependencies
        for dep_id in task.depends_on:
            if dep_id not in self.adjacency_list:
                self.adjacency_list[dep_id] = []
            self.adjacency_list[dep_id].append(task.id)
        
        self.total_tasks = len(self.tasks)
    
    def get_root_tasks(self) -> List[Task]:
        """Get tasks with no dependencies (can start immediately)."""
        return [task for task in self.tasks.values() if not task.depends_on]
    
    def get_next_ready_tasks(self, completed_task_ids: Set[str]) -> List[Task]:
        """Get tasks that are ready to execute (all dependencies completed)."""
        ready_tasks = []
        
        for task in self.tasks.values():
            if task.status in [TaskStatus.COMPLETED, TaskStatus.RUNNING, TaskStatus.SKIPPED]:
                continue
            
            # Check if all dependencies are completed
            if all(dep_id in completed_task_ids for dep_id in task.depends_on):
                ready_tasks.append(task)
        
        return ready_tasks
    
    def get_task_level(self, task_id: str) -> int:
        """
        Get the level of a task in the DAG (0 = root, 1 = depends on root, etc.).
        
        Note: This is a simple recursive approach. For large DAGs, use get_topological_order() instead.
        """
        task = self.tasks.get(task_id)
        if not task or not task.depends_on:
            return 0
        
        return 1 + max(self.get_task_level(dep_id) for dep_id in task.depends_on)
    
    def get_execution_stages(self) -> List[List[Task]]:
        """Get tasks grouped by execution stage (tasks in same stage can run in parallel)."""
        stages: Dict[int, List[Task]] = {}
        
        for task_id, task in self.tasks.items():
            level = self.get_task_level(task_id)
            if level not in stages:
                stages[level] = []
            stages[level].append(task)
        
        # Return stages in order
        return [stages[i] for i in sorted(stages.keys())]
    
    def get_topological_order(self, exclude_completed: bool = True) -> List[str]:
        """
        Get topologically sorted execution order using Kahn's algorithm.
        
        This is more efficient than recursive get_task_level() for large DAGs.
        Time complexity: O(V + E) where V = vertices (tasks), E = edges (dependencies)
        
        Args:
            exclude_completed: If True, exclude already completed tasks
        
        Returns:
            List of task IDs in execution order
        
        Raises:
            ValueError: If graph contains a cycle
        """
        # Get completed tasks
        completed = {task_id for task_id, task in self.tasks.items() 
                    if task.status == TaskStatus.COMPLETED} if exclude_completed else set()
        
        # Calculate in-degree (number of dependencies) for each task
        in_degree = {
            task: len([d for d in self.tasks[task].depends_on if d not in completed])
            for task in self.tasks.keys()
            if task not in completed
        }
        
        # Start with tasks that have no dependencies
        queue = [task for task, degree in in_degree.items() if degree == 0]
        order = []
        
        while queue:
            # Pick a task with no remaining dependencies
            task = queue.pop(0)
            order.append(task)
            
            # Remove this task's edges (it's "done")
            for dependent in self.adjacency_list.get(task, []):
                if dependent not in completed:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)
        
        # Check if all tasks were processed
        remaining = [t for t in self.tasks.keys() 
                    if t not in completed and t not in order]
        
        if remaining:
            # Try to detect the cycle
            cycle = self.detect_cycle_with_path()
            cycle_info = f" Cycle: {' -> '.join(cycle)}" if cycle else ""
            raise ValueError(
                f"Circular dependency detected! Cannot order tasks. "
                f"Remaining tasks: {remaining}.{cycle_info}"
            )
        
        logger.debug(f"📊 Topological order: {order}")
        return order
    
    def detect_cycle_with_path(self) -> Optional[List[str]]:
        """
        Detect cycles in the dependency graph and return the cycle path.
        
        Uses DFS to detect cycles. If a cycle exists, returns the path showing the cycle.
        
        Returns:
            List of task IDs forming the cycle, or None if no cycle exists
            Example: ['task_1', 'task_3', 'task_5', 'task_1'] shows the cycle
        """
        visited = set()
        rec_stack = set()
        
        def dfs(task: str, path: List[str]) -> Optional[List[str]]:
            visited.add(task)
            rec_stack.add(task)
            path.append(task)
            
            for dep in self.tasks[task].depends_on:
                if dep not in visited:
                    cycle = dfs(dep, path[:])
                    if cycle:
                        return cycle
                elif dep in rec_stack:
                    # Found cycle!
                    cycle_start = path.index(dep)
                    return path[cycle_start:] + [dep]
            
            rec_stack.remove(task)
            return None
        
        for task in self.tasks:
            if task not in visited:
                cycle = dfs(task, [])
                if cycle:
                    logger.warning(f"⚠️  Cycle detected: {' -> '.join(cycle)}")
                    return cycle
        
        return None
    
    def get_unmet_dependencies(self, task_id: str, completed_task_ids: Set[str]) -> List[str]:
        """
        Get list of dependencies that haven't been completed yet.
        
        Useful for debugging why a task can't execute yet.
        
        Args:
            task_id: Task to check
            completed_task_ids: Set of already completed task IDs
        
        Returns:
            List of task IDs that are blocking this task
        """
        task = self.tasks.get(task_id)
        if not task:
            return []
        
        return [dep_id for dep_id in task.depends_on 
                if dep_id not in completed_task_ids]
    
    def validate(self) -> tuple[bool, List[str]]:
        """
        Validate the DAG structure. Returns (is_valid, error_messages).
        
        Checks:
        1. All dependencies reference existing tasks
        2. No circular dependencies exist
        """
        errors = []
        
        # Check for missing dependencies
        for task_id, task in self.tasks.items():
            for dep_id in task.depends_on:
                if dep_id not in self.tasks:
                    errors.append(f"Task '{task_id}' depends on non-existent task '{dep_id}'")
        
        # Check for cycles using enhanced cycle detection
        cycle = self.detect_cycle_with_path()
        if cycle:
            errors.append(f"Cycle detected in DAG: {' -> '.join(cycle)}")
        
        return len(errors) == 0, errors
    
    def checkpoint(self) -> Dict[str, Any]:
        """
        Create a checkpoint of the current DAG state for persistence.
        
        Returns:
            Dictionary containing complete DAG state that can be saved to disk
        """
        return {
            'name': self.name,
            'description': self.description,
            'total_tasks': self.total_tasks,
            'timestamp': datetime.now().isoformat(),
            'tasks': {
                task_id: {
                    'id': task.id,
                    'name': task.name,
                    'description': task.description,
                    'task_type': task.task_type.value,
                    'depends_on': task.depends_on,
                    'code_snippet': task.code_snippet,
                    'commands': task.commands,
                    'files_to_create': task.files_to_create,
                    'files_required': task.files_required,
                    'estimated_duration': task.estimated_duration,
                    'priority': task.priority,
                    'status': task.status.value,
                    'success_criteria': task.success_criteria,
                    'failure_handling': task.failure_handling
                }
                for task_id, task in self.tasks.items()
            },
            'adjacency_list': self.adjacency_list
        }
    
    @staticmethod
    def restore_from_checkpoint(checkpoint: Dict[str, Any]) -> 'TaskDAG':
        """
        Restore a DAG from a checkpoint.
        
        Args:
            checkpoint: Dictionary created by checkpoint()
        
        Returns:
            Restored TaskDAG instance
        """
        dag = TaskDAG(
            name=checkpoint['name'],
            description=checkpoint['description']
        )
        
        # Restore tasks
        for task_id, task_data in checkpoint['tasks'].items():
            task = Task(
                id=task_data['id'],
                name=task_data['name'],
                description=task_data['description'],
                task_type=TaskType(task_data['task_type']),
                depends_on=task_data['depends_on'],
                code_snippet=task_data.get('code_snippet'),
                commands=task_data.get('commands', []),
                files_to_create=task_data.get('files_to_create', []),
                files_required=task_data.get('files_required', []),
                estimated_duration=task_data.get('estimated_duration'),
                priority=task_data.get('priority', 1),
                status=TaskStatus(task_data['status']),
                success_criteria=task_data.get('success_criteria', []),
                failure_handling=task_data.get('failure_handling')
            )
            dag.tasks[task_id] = task
        
        # Restore adjacency list
        dag.adjacency_list = checkpoint['adjacency_list']
        dag.total_tasks = checkpoint['total_tasks']
        
        logger.info(f"📊 Restored DAG '{dag.name}' from checkpoint with {dag.total_tasks} tasks")
        return dag
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics about the DAG.
        
        Returns:
            Dictionary with task counts, status breakdown, and health indicators
        """
        status_counts = {
            'pending': 0,
            'ready': 0,
            'running': 0,
            'completed': 0,
            'failed': 0,
            'skipped': 0
        }
        
        completed_ids = {tid for tid, t in self.tasks.items() if t.status == TaskStatus.COMPLETED}
        
        for task in self.tasks.values():
            status_counts[task.status.value] += 1
            
            # Count ready tasks (dependencies met but not started)
            if task.status == TaskStatus.PENDING:
                if all(dep in completed_ids for dep in task.depends_on):
                    status_counts['ready'] += 1
                    status_counts['pending'] -= 1
        
        return {
            'total_tasks': self.total_tasks,
            'by_status': status_counts,
            'by_type': {
                task_type.value: len([t for t in self.tasks.values() if t.task_type == task_type])
                for task_type in TaskType
            },
            'execution_stages': len(self.get_execution_stages()),
            'has_cycle': self.detect_cycle_with_path() is not None,
            'root_tasks': len(self.get_root_tasks()),
            'completion_percentage': round(status_counts['completed'] / self.total_tasks * 100, 1) if self.total_tasks > 0 else 0
        }
    
    def __repr__(self) -> str:
        """String representation of the DAG."""
        stats = self.get_stats()
        return (
            f"TaskDAG('{self.name}', "
            f"tasks={stats['total_tasks']}, "
            f"completed={stats['by_status']['completed']}, "
            f"pending={stats['by_status']['pending']}, "
            f"stages={stats['execution_stages']})"
        )
    
    def visualize_tree(self, max_width: int = 100) -> str:
        """
        Visualize DAG as an ASCII tree showing dependencies and hierarchy.
        
        Args:
            max_width: Maximum width for task names before truncation
        
        Returns:
            ASCII tree representation of the DAG
        """
        output = []
        output.append(f"\n{'='*80}")
        output.append(f"DAG: {self.name}")
        output.append(f"{'='*80}\n")
        
        # Get execution stages for hierarchical display
        stages = self.get_execution_stages()
        
        for stage_num, stage_tasks in enumerate(stages, 1):
            output.append(f"Stage {stage_num} ({len(stage_tasks)} tasks):")
            output.append("─" * 80)
            
            for task in stage_tasks:
                # Task header
                status_icon = {
                    TaskStatus.PENDING: "⏳",
                    TaskStatus.READY: "🟢",
                    TaskStatus.RUNNING: "🔄",
                    TaskStatus.COMPLETED: "✅",
                    TaskStatus.FAILED: "❌",
                    TaskStatus.SKIPPED: "⏭️"
                }.get(task.status, "❔")
                
                type_icon = {
                    TaskType.SETUP: "🔧",
                    TaskType.IMPLEMENTATION: "💻",
                    TaskType.TESTING: "🧪",
                    TaskType.EXECUTION: "▶️",
                    TaskType.DOCUMENTATION: "📝",
                    TaskType.VALIDATION: "✔️",
                    TaskType.DEPLOYMENT: "🚀"
                }.get(task.task_type, "📦")
                
                task_name = task.name[:max_width-10] + "..." if len(task.name) > max_width-10 else task.name
                output.append(f"\n  {status_icon} {type_icon} {task.id}: {task_name}")
                
                # Dependencies
                if task.depends_on:
                    output.append(f"     ↳ Depends on: {', '.join(task.depends_on)}")
                else:
                    output.append(f"     ↳ No dependencies (can start immediately)")
                
                # Files
                if task.files_to_create:
                    files_str = ", ".join(task.files_to_create[:3])
                    if len(task.files_to_create) > 3:
                        files_str += f" +{len(task.files_to_create)-3} more"
                    output.append(f"     📄 Creates: {files_str}")
                
                # Commands preview
                if task.commands:
                    cmd_preview = task.commands[0][:60] + "..." if len(task.commands[0]) > 60 else task.commands[0]
                    output.append(f"     $ {cmd_preview}")
                    if len(task.commands) > 1:
                        output.append(f"       +{len(task.commands)-1} more commands")
                
                # Code snippet preview
                if task.code_snippet:
                    code_lines = task.code_snippet.split('\n')
                    preview = code_lines[0][:60] + "..." if len(code_lines[0]) > 60 else code_lines[0]
                    output.append(f"     💾 Code: {preview}")
                    if len(code_lines) > 1:
                        output.append(f"       +{len(code_lines)-1} more lines")
            
            output.append("")
        
        output.append("="*80)
        return "\n".join(output)
    
    def visualize_mermaid(self) -> str:
        """
        Generate Mermaid diagram syntax for the DAG.
        
        Can be rendered using mermaid.js or in markdown viewers.
        
        Returns:
            Mermaid diagram code
        """
        output = []
        output.append("```mermaid")
        output.append("graph TD")
        output.append("")
        
        # Add nodes
        for task_id, task in self.tasks.items():
            # Node styling based on status
            style_class = {
                TaskStatus.PENDING: "pending",
                TaskStatus.READY: "ready",
                TaskStatus.RUNNING: "running",
                TaskStatus.COMPLETED: "completed",
                TaskStatus.FAILED: "failed",
                TaskStatus.SKIPPED: "skipped"
            }.get(task.status, "default")
            
            # Truncate long names
            display_name = task.name[:40] + "..." if len(task.name) > 40 else task.name
            type_prefix = task.task_type.value[:3].upper()
            
            # Create node with type and name
            output.append(f"    {task_id}[\"{type_prefix}: {display_name}\"]:::{style_class}")
        
        output.append("")
        
        # Add edges (dependencies)
        for task_id, task in self.tasks.items():
            for dep_id in task.depends_on:
                output.append(f"    {dep_id} --> {task_id}")
        
        output.append("")
        
        # Add styling
        output.append("    classDef pending fill:#FFF3CD,stroke:#856404")
        output.append("    classDef ready fill:#D4EDDA,stroke:#155724")
        output.append("    classDef running fill:#CCE5FF,stroke:#004085")
        output.append("    classDef completed fill:#D1E7DD,stroke:#0F5132")
        output.append("    classDef failed fill:#F8D7DA,stroke:#842029")
        output.append("    classDef skipped fill:#E2E3E5,stroke:#383D41")
        
        output.append("```")
        return "\n".join(output)
    
    def visualize_dependencies_matrix(self) -> str:
        """
        Visualize dependencies as a matrix showing which tasks depend on which.
        
        Returns:
            ASCII matrix showing dependencies
        """
        task_ids = list(self.tasks.keys())
        
        output = []
        output.append("\n" + "="*80)
        output.append("DEPENDENCY MATRIX")
        output.append("="*80)
        output.append("Rows depend on Columns (X = has dependency)\n")
        
        # Header
        header = "Task ID".ljust(12) + " | " + " ".join(tid[-6:].ljust(8) for tid in task_ids[:10])
        if len(task_ids) > 10:
            header += " ..."
        output.append(header)
        output.append("-" * len(header))
        
        # Rows
        for i, task_id in enumerate(task_ids[:20]):  # Limit to first 20 tasks
            row = task_id.ljust(12) + " | "
            for j, dep_id in enumerate(task_ids[:10]):
                if dep_id in self.tasks[task_id].depends_on:
                    row += "   X    "
                else:
                    row += "   ·    "
            if len(task_ids) > 10:
                row += " ..."
            output.append(row)
        
        if len(task_ids) > 20:
            output.append(f"... and {len(task_ids)-20} more tasks")
        
        output.append("="*80 + "\n")
        return "\n".join(output)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert DAG to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "total_tasks": self.total_tasks,
            "tasks": {
                task_id: {
                    "id": task.id,
                    "name": task.name,
                    "description": task.description,
                    "task_type": task.task_type.value,
                    "depends_on": task.depends_on,
                    "code_snippet": task.code_snippet,
                    "commands": task.commands,
                    "files_to_create": task.files_to_create,
                    "files_required": task.files_required,
                    "estimated_duration": task.estimated_duration,
                    "priority": task.priority,
                    "status": task.status.value,
                    "success_criteria": task.success_criteria,
                    "failure_handling": task.failure_handling
                }
                for task_id, task in self.tasks.items()
            },
            "adjacency_list": self.adjacency_list,
            "execution_stages": [
                [task.id for task in stage]
                for stage in self.get_execution_stages()
            ]
        }
