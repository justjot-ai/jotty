"""
Task type and status enumerations for the workflow system.
"""

from enum import Enum


class TaskType(Enum):
    """Types of tasks in the workflow."""
    SETUP = "setup"  # Environment setup, installations
    IMPLEMENTATION = "implementation"  # Code implementation
    TESTING = "testing"  # Test creation and execution
    EXECUTION = "execution"  # Script execution
    DOCUMENTATION = "documentation"  # Documentation tasks
    VALIDATION = "validation"  # Validation and verification
    DEPLOYMENT = "deployment"  # Deployment tasks


class TaskStatus(Enum):
    """Status of task execution."""
    PENDING = "pending"
    READY = "ready"  # All dependencies satisfied
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
