## Recovery Flow

1. **Pre-execution checkpoint**
   - `Conductor._checkpoint_state("pre_execute")` saves TODO, memories, Q-predictor.
2. **Timeout checkpoint**
   - Timeouts trigger `Conductor._checkpoint_state("timeout")` and mark task failed.
3. **Restore**
   - On start, if `auto_load_on_start` is enabled and TODO matches goal,
     the TODO state is restored via `MarkovianTODO.from_dict()`.
4. **Recovery policy**
   - `enable_auto_recovery` controls parameter recovery attempts.
   - `allow_partial_execution` controls whether missing params can proceed.
