## Validation Contracts

### Output Schema Validation
- If `AgentConfig.outputs` is provided, missing fields are reported to the Auditor.

### Invariants
- `AgentConfig.invariants` is a list of callables returning error strings or `None`.
- Failures are injected into Auditor context as `invariant_failures`.

### Auditor Guidance
- Auditor prompt requires invariant checks and external verification.
- Execution success never implies correctness.
