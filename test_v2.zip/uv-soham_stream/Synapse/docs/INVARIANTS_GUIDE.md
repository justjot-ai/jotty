## Invariants Guide

Use invariants to enforce mathematical/algorithmic correctness.

### Built-in helpers
- `invariant_sorted(key=None, allow_equal=True)`
- `invariant_non_negative(key=None)`
- `invariant_finite(key=None)`

### Example
```python
from Synapse import AgentConfig, invariant_sorted

agent_cfg = AgentConfig(
    name="Sampler",
    agent=my_agent,
    architect_prompts=[],
    auditor_prompts=[],
    outputs=["samples"],
    invariants=[invariant_sorted(key="samples")]
)
```
