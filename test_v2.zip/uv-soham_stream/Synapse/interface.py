"""
SYNAPSE Interface - Clean API for Multi-Agent Orchestration
============================================================

🎯 DESIGN PRINCIPLES (per GRF MARL paper):
1. NO HARDCODING - All mappings are agentic
2. SWARM INTELLIGENCE - Internal micro-agents handle transforms
3. GAME THEORY - Nash equilibrium for cooperation decisions
4. POPULATION-BASED - Support for diverse agent populations
5. CREDIT ASSIGNMENT - Shapley + Difference rewards

📚 RESEARCH FOUNDATIONS:
- Song et al. (2023): "GRF Multi-agent Scenarios" - Population-based training, IPPO
- Reward shaping, credit assignment, coordination
- Self-play and population diversity for robustness

🔬 A-TEAM CONSENSUS: This is the ONLY entry point for Synapse.
All other imports are internal implementation details.

Example Usage:
```python
from prism.Synapse import Synapse, AgentConfig, SynapseConfig

# Define your agents (DSPy modules)
class SQLGenerator(dspy.Module):
    ...

class DataAnalyzer(dspy.Module):
    ...

# Configure Synapse
config = SynapseConfig(
    # Learning parameters
    enable_learning=True,
    learning_rate=0.1,
    discount_factor=0.99,
    
    # Memory settings
    consolidation_interval=3,
    max_memory_size=1000,
    
    # Cooperation (Game Theory)
    enable_cooperation_tracking=True,
    nash_communication_threshold=0.1,
    
    # Timeouts & reliability
    default_timeout=60.0,
    max_retries=3,
    
    # Persistence
    state_path="synapse_state/",
    output_path="outputs/"
)

# Define agents with their capabilities
agents = [
    AgentConfig(
        name="SQLGenerator",
        actor=SQLGenerator(),
        # Validation flags (Architect = pre-planning, Auditor = post-validation)
        enable_architect=True,  # Plan before execution
        enable_auditor=True,    # Validate after execution
        # Tool access (optional - can be auto-discovered)
        tools=[execute_query, get_metadata],
        # Dependencies (optional - auto-inferred from signatures)
        depends_on=["BusinessTermResolver"],
    ),
    AgentConfig(
        name="DataAnalyzer",
        actor=DataAnalyzer(),
        enable_architect=False,  # Direct execution
        enable_auditor=True,     # Validate output
    )
]

# Initialize Synapse
synapse = Synapse(config=config, agents=agents)

# Provide metadata (optional - auto-discovered from tools)
synapse.set_metadata_provider(my_metadata_manager)

# Run the swarm
result = await synapse.run(
    goal="What was the P2P transaction count yesterday?",
    context={"current_date": "2026-01-06"}
)

# Access results
print(result.final_output)
print(result.agent_outputs)
print(result.trajectory)
print(result.credits)  # Per-agent Shapley credits
```
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable, Union, Type
from enum import Enum, auto
import time

logger = logging.getLogger(__name__)


# =============================================================================
# ENUMS
# =============================================================================

class ValidationMode(Enum):
    """When to run validation."""
    NONE = auto()           # No validation
    ARCHITECT = auto()      # Pre-execution planning only
    AUDITOR = auto()        # Post-execution validation only
    BOTH = auto()           # Full validation (default)


class LearningMode(Enum):
    """How the swarm learns."""
    DISABLED = auto()       # No learning
    CONTEXTUAL = auto()     # Update prompts/context (default)
    PERSISTENT = auto()     # Save Q-tables and memories


class CooperationMode(Enum):
    """How agents cooperate."""
    INDEPENDENT = auto()    # No cooperation (IPPO-style)
    SHARED_REWARD = auto()  # System reward (default)
    NASH = auto()           # Nash equilibrium communication


# =============================================================================
# AGENT CONFIGURATION
# =============================================================================

@dataclass
class AgentConfig:
    """
    Configuration for a single agent in the swarm.
    
    🎯 CLEAN INTERFACE - All parameters have sensible defaults.
    🔬 NO HARDCODING - Tool/parameter mappings are agentic.
    
    Parameters:
    -----------
    name : str
        Unique identifier for this agent.
        
    actor : Any
        The DSPy module or callable that implements the agent logic.
        Must have a __call__ or forward method.
        
    enable_architect : bool, default=True
        Run Architect (pre-planning) before execution.
        Architect advises on strategy but doesn't block.
        
    enable_auditor : bool, default=True
        Run Auditor (post-validation) after execution.
        Auditor can request retry if validation fails.
        
    tools : List[Callable], default=[]
        Tools this agent can use. If empty, tools are auto-discovered
        from the metadata provider based on agent's signature.
        
    depends_on : List[str], default=[]
        Names of agents that must complete before this one.
        If empty, dependencies are inferred from signature parameters.
        
    max_retries : int, default=3
        Maximum retry attempts if Auditor rejects output.
        
    timeout : float, default=60.0
        Timeout in seconds for this agent's execution.
        
    confidence_threshold : float, default=0.7
        Minimum confidence required to proceed without retry.
        
    prompts : Dict[str, str], default={}
        Custom prompts for Architect/Auditor.
        Keys: 'architect', 'auditor', 'system'
        
    metadata : Dict[str, Any], default={}
        Additional agent-specific configuration.
    """
    name: str
    actor: Any
    enable_architect: bool = True
    enable_auditor: bool = True
    tools: List[Callable] = field(default_factory=list)
    depends_on: List[str] = field(default_factory=list)
    max_retries: int = 3
    timeout: float = 60.0
    confidence_threshold: float = 0.7
    prompts: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    gateway: Optional[str] = None
    api_key_env: Optional[str] = None
    api_base_env: Optional[str] = None
    
    # Optional invariants (functions return error string or None)
    invariants: Optional[List[Callable[[Any], Optional[str]]]] = None
    invariant_descriptions: Optional[List[str]] = None
    
    # 🔬 A-TEAM: Automatic discovery flags
    auto_discover_tools: bool = True    # Find tools from metadata
    auto_infer_deps: bool = True        # Infer from signatures
    auto_resolve_params: bool = True    # Resolve params agentically
    
    def __post_init__(self):
        """Validate configuration."""
        if not self.name:
            raise ValueError("Agent name cannot be empty")
        if self.actor is None:
            raise ValueError(f"Agent '{self.name}' must have an actor")


# =============================================================================
# SYNAPSE CONFIGURATION
# =============================================================================

@dataclass
class SynapseConfig:
    """
    Configuration for the Synapse orchestrator.
    
    🎯 ALL PARAMETERS DOCUMENTED with types and defaults.
    🔬 INSPIRED BY: GRF MARL paper (population-based, reward shaping)
    
    Categories:
    1. Learning & RL
    2. Memory & Consolidation
    3. Cooperation & Game Theory
    4. Reliability & Timeouts
    5. Persistence & Outputs
    6. Internal Agents (Architect/Auditor)
    
    Parameters:
    -----------
    
    # === LEARNING & RL ===
    enable_learning : bool, default=True
        Enable Q-learning and context gradient updates.
        
    learning_rate : float, default=0.1
        α in Q(s,a) ← Q(s,a) + α[r + γV(s') - Q(s,a)]
        
    discount_factor : float, default=0.99
        γ - Future reward discount.
        
    epsilon : float, default=0.1
        ε-greedy exploration rate.
        
    td_lambda : float, default=0.8
        λ for TD(λ) eligibility traces.
        
    learning_mode : LearningMode, default=CONTEXTUAL
        How learning manifests (context updates, persistence).
    
    # === MEMORY & CONSOLIDATION ===
    consolidation_interval : int, default=3
        Episodes between brain consolidation (Sharp-Wave Ripples).
        
    max_memory_size : int, default=1000
        Maximum hippocampal memories before pruning.
        
    max_q_entries : int, default=10000
        Maximum Q-table entries.
        
    neuro_chunk_enabled : bool, default=True
        Use NeuroChunk tiered memory management.
    
    # === COOPERATION & GAME THEORY ===
    cooperation_mode : CooperationMode, default=SHARED_REWARD
        How agents cooperate (independent, shared, Nash).
        
    enable_cooperation_tracking : bool, default=True
        Track help matrix and cooperation events.
        
    nash_communication_threshold : float, default=0.1
        Minimum net value for Nash-based communication.
        
    shapley_samples : int, default=20
        Monte Carlo samples for Shapley value estimation.
        
    enable_credit_assignment : bool, default=True
        Compute per-agent Shapley + Difference rewards.
    
    # === RELIABILITY & TIMEOUTS ===
    default_timeout : float, default=60.0
        Default per-agent timeout in seconds.
        
    global_timeout : float, default=300.0
        Maximum total swarm execution time.
        
    max_retries : int, default=3
        Default retry attempts for failed agents.
        
    circuit_breaker_threshold : int, default=5
        Failures before circuit breaker opens.
        
    enable_dead_letter_queue : bool, default=True
        Queue failed tasks for later retry.
    
    # === PERSISTENCE & OUTPUTS ===
    state_path : str, default="synapse_state/"
        Where to save Q-tables, memories, roadmap.
        
    output_path : str, default="outputs/"
        Where to save run logs and results.
        
    enable_persistence : bool, default=True
        Auto-save state after each run.
        
    auto_load_state : bool, default=True
        Auto-load previous state if exists.
        
    beautified_logs : bool, default=True
        Write human-readable beautified logs.
    
    # === INTERNAL AGENTS ===
    architect_temperature : float, default=0.0
        LLM temperature for Architect (deterministic).
        
    auditor_temperature : float, default=0.0
        LLM temperature for Auditor (deterministic).
        
    architect_max_tokens : int, default=2000
        Max tokens for Architect responses.
        
    auditor_max_tokens : int, default=2000
        Max tokens for Auditor responses.
    """
    
    # Learning & RL
    enable_learning: bool = True
    learning_rate: float = 0.1
    discount_factor: float = 0.99
    epsilon: float = 0.1
    td_lambda: float = 0.8
    learning_mode: LearningMode = LearningMode.CONTEXTUAL
    
    # Memory & Consolidation
    consolidation_interval: int = 3
    max_memory_size: int = 1000
    max_q_entries: int = 10000
    neuro_chunk_enabled: bool = True
    
    # Cooperation & Game Theory
    cooperation_mode: CooperationMode = CooperationMode.SHARED_REWARD
    enable_cooperation_tracking: bool = True
    nash_communication_threshold: float = 0.1
    shapley_samples: int = 20
    enable_credit_assignment: bool = True
    
    # Reliability & Timeouts
    default_timeout: float = 60.0
    global_timeout: float = 300.0
    max_retries: int = 3
    circuit_breaker_threshold: int = 5
    enable_dead_letter_queue: bool = True
    
    # Persistence & Outputs
    state_path: str = "synapse_state/"
    output_path: str = "outputs/"
    enable_persistence: bool = True
    auto_load_state: bool = True
    beautified_logs: bool = True
    
    # Internal Agents
    architect_temperature: float = 0.0
    auditor_temperature: float = 0.0
    architect_max_tokens: int = 2000
    auditor_max_tokens: int = 2000
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            k: v.value if isinstance(v, Enum) else v
            for k, v in self.__dict__.items()
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'SynapseConfig':
        """Create from dictionary."""
        # Convert enum strings back
        if 'learning_mode' in d and isinstance(d['learning_mode'], str):
            d['learning_mode'] = LearningMode[d['learning_mode']]
        if 'cooperation_mode' in d and isinstance(d['cooperation_mode'], str):
            d['cooperation_mode'] = CooperationMode[d['cooperation_mode']]
        return cls(**d)
    
    @classmethod
    def from_yaml(cls, path: str) -> 'SynapseConfig':
        """Load from YAML file."""
        import yaml
        with open(path, 'r') as f:
            d = yaml.safe_load(f)
        return cls.from_dict(d)


# =============================================================================
# METADATA PROTOCOL
# =============================================================================

class MetadataProtocol:
    """
    Protocol for metadata providers.
    
    Implement this to provide domain-specific metadata to agents.
    Synapse will auto-discover tools and context from this.
    
    🔬 NO HARDCODING: Agents use these methods to discover what's available.
    """
    
    def get_all_tools(self) -> Dict[str, Callable]:
        """Return all available tools as {name: callable}."""
        raise NotImplementedError
    
    def get_tool_for_param(self, param_name: str, param_type: type) -> Optional[Callable]:
        """Find tool that can provide a specific parameter."""
        raise NotImplementedError
    
    def get_context(self) -> Dict[str, Any]:
        """Return all context data for agents."""
        raise NotImplementedError
    
    def get_tool_schema(self, tool_name: str) -> Dict[str, Any]:
        """Return I/O schema for a tool."""
        raise NotImplementedError


# =============================================================================
# SYNAPSE MAIN CLASS
# =============================================================================

class Synapse:
    """
    SYNAPSE - Multi-Agent Orchestration with Game Theory
    
    🎯 THE ONLY ENTRY POINT for swarm orchestration.
    
    Features:
    ---------
    - 🤖 Multi-agent coordination with DSPy modules
    - 🎮 Game theory (Nash equilibrium, Shapley credits)
    - 🧠 Brain-inspired memory (Sharp-Wave Ripples)
    - 📊 Q-learning with TD(λ) and context gradients
    - 🔄 Prioritized experience replay
    - 🔌 Circuit breakers and dead letter queue
    - 💾 Full persistence and resume support
    
    Research Foundations:
    --------------------
    - GRF MARL (Song et al., 2023): Population-based training, IPPO
    - Shapley value for credit assignment
    - Nash equilibrium for communication decisions
    - Brain-inspired consolidation (Buzsáki, 2015)
    
    Example:
    --------
    ```python
    synapse = Synapse(
        config=SynapseConfig(enable_learning=True),
        agents=[
            AgentConfig(name="Agent1", actor=my_agent),
            AgentConfig(name="Agent2", actor=another_agent),
        ]
    )
    
    result = await synapse.run(goal="Do something complex")
    ```
    """
    
    def __init__(
        self,
        config: Optional[SynapseConfig] = None,
        agents: Optional[List[AgentConfig]] = None,
        metadata_provider: Optional[MetadataProtocol] = None,
    ):
        """
        Initialize Synapse orchestrator.
        
        Parameters:
        -----------
        config : SynapseConfig, optional
            Orchestrator configuration. Uses defaults if not provided.
            
        agents : List[AgentConfig], optional
            List of agent configurations. Can be added later via add_agent().
            
        metadata_provider : MetadataProtocol, optional
            Provider for domain metadata and tools. Enables auto-discovery.
        """
        self.config = config or SynapseConfig()
        self.agents: Dict[str, AgentConfig] = {}
        self.metadata_provider = metadata_provider
        
        # Internal state
        self._conductor = None
        self._initialized = False
        
        # Add agents
        if agents:
            for agent in agents:
                self.add_agent(agent)
        
        logger.info(f"🚀 Synapse initialized with {len(self.agents)} agents")
    
    def add_agent(self, agent: AgentConfig) -> 'Synapse':
        """
        Add an agent to the swarm.
        
        Returns self for chaining:
        ```python
        synapse.add_agent(a1).add_agent(a2).add_agent(a3)
        ```
        """
        if agent.name in self.agents:
            logger.warning(f"⚠️ Agent '{agent.name}' already exists, replacing")
        self.agents[agent.name] = agent
        self._initialized = False  # Re-init needed
        return self
    
    def set_metadata_provider(self, provider: MetadataProtocol) -> 'Synapse':
        """Set metadata provider for tool/context discovery."""
        self.metadata_provider = provider
        self._initialized = False
        return self
    
    async def run(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> 'SwarmResult':
        """
        Run the swarm to achieve a goal.
        
        Parameters:
        -----------
        goal : str
            Natural language description of what to achieve.
            
        context : Dict[str, Any], optional
            Additional context (current_date, user_id, etc.)
            
        **kwargs : Any
            Additional parameters passed to all agents.
        
        Returns:
        --------
        SwarmResult with:
        - final_output: The primary result
        - agent_outputs: Per-agent outputs
        - trajectory: Execution trace
        - credits: Shapley credit per agent
        - success: Whether goal was achieved
        """
        # Initialize conductor if needed
        if not self._initialized:
            await self._initialize()
        
        # Merge context
        full_context = context or {}
        full_context['goal'] = goal
        full_context['query'] = goal  # Alias
        full_context.update(kwargs)
        
        # Run via conductor - conductor.run() is now an async generator
        result = None
        async for event in self._conductor.run(goal=goal, **full_context):
            # Extract result from final event
            if isinstance(event, dict) and event.get("type") == "result":
                result = event.get("result")
        
        if result is None:
            raise RuntimeError("Conductor execution did not return a result")
        
        return result
    
    async def _initialize(self):
        """Initialize internal components."""
        from prism.Synapse.core.conductor import Conductor
        
        # Build actor configs from AgentConfigs
        actor_configs = []
        for name, agent in self.agents.items():
            actor_configs.append(self._convert_agent_config(agent))
        
        # Create conductor
        self._conductor = Conductor(
            actors=actor_configs,
            config=self._build_conductor_config(),
            metadata_manager=self.metadata_provider,
        )
        
        self._initialized = True
        logger.info(f"✅ Synapse conductor initialized with {len(actor_configs)} actors")
    
    def _convert_agent_config(self, agent: AgentConfig) -> Dict[str, Any]:
        """Convert AgentConfig to internal format."""
        return {
            'name': agent.name,
            'actor': agent.actor,
            'enable_architect': agent.enable_architect,
            'enable_auditor': agent.enable_auditor,
            'tools': agent.tools,
            'depends_on': agent.depends_on,
            'max_retries': agent.max_retries,
            'timeout': agent.timeout,
            'confidence_threshold': agent.confidence_threshold,
            'prompts': agent.prompts,
            'metadata': agent.metadata,
            'auto_discover_tools': agent.auto_discover_tools,
            'auto_infer_deps': agent.auto_infer_deps,
            'auto_resolve_params': agent.auto_resolve_params,
        }
    
    def _build_conductor_config(self) -> Dict[str, Any]:
        """Build conductor config from SynapseConfig."""
        return {
            'enable_learning': self.config.enable_learning,
            'alpha': self.config.learning_rate,
            'gamma': self.config.discount_factor,
            'epsilon': self.config.epsilon,
            'td_lambda': self.config.td_lambda,
            'consolidation_interval': self.config.consolidation_interval,
            'max_memory_size': self.config.max_memory_size,
            'max_q_entries': self.config.max_q_entries,
            'neuro_chunk_enabled': self.config.neuro_chunk_enabled,
            'enable_cooperation_tracking': self.config.enable_cooperation_tracking,
            'nash_threshold': self.config.nash_communication_threshold,
            'shapley_samples': self.config.shapley_samples,
            'enable_credit_assignment': self.config.enable_credit_assignment,
            'default_timeout': self.config.default_timeout,
            'global_timeout': self.config.global_timeout,
            'max_retries': self.config.max_retries,
            'circuit_breaker_threshold': self.config.circuit_breaker_threshold,
            'enable_dead_letter_queue': self.config.enable_dead_letter_queue,
            'state_path': self.config.state_path,
            'output_path': self.config.output_path,
            'enable_persistence': self.config.enable_persistence,
            'auto_load_state': self.config.auto_load_state,
            'beautified_logs': self.config.beautified_logs,
            'architect_temperature': self.config.architect_temperature,
            'auditor_temperature': self.config.auditor_temperature,
        }
    
    def get_state(self) -> Dict[str, Any]:
        """Get current learning state (Q-table, memories, etc.)."""
        if self._conductor:
            return self._conductor.get_state()
        return {}
    
    def save_state(self, path: Optional[str] = None):
        """Save state to disk."""
        if self._conductor:
            self._conductor.save_state(path or self.config.state_path)
    
    def load_state(self, path: Optional[str] = None) -> bool:
        """Load state from disk."""
        if self._conductor:
            return self._conductor.load_state(path or self.config.state_path)
        return False


# =============================================================================
# RESULT TYPES
# =============================================================================

@dataclass
class SwarmResult:
    """
    Result from a Synapse swarm run.
    
    Contains all outputs, trajectory, and learning artifacts.
    """
    # Primary result
    final_output: Any
    success: bool
    
    # Per-agent outputs
    agent_outputs: Dict[str, Any] = field(default_factory=dict)
    
    # Execution trace
    trajectory: List[Dict] = field(default_factory=list)
    
    # Credit assignment (Shapley + Difference)
    credits: Dict[str, float] = field(default_factory=dict)
    
    # Timing
    start_time: float = 0.0
    end_time: float = 0.0
    
    # Errors
    errors: List[str] = field(default_factory=list)
    
    @property
    def duration(self) -> float:
        return self.end_time - self.start_time
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'final_output': self.final_output,
            'success': self.success,
            'agent_outputs': self.agent_outputs,
            'trajectory_length': len(self.trajectory),
            'credits': self.credits,
            'duration': self.duration,
            'errors': self.errors,
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Main classes
    'Synapse',
    'AgentConfig',
    'SynapseConfig',
    'SwarmResult',
    
    # Enums
    'ValidationMode',
    'LearningMode',
    'CooperationMode',
    
    # Protocols
    'MetadataProtocol',
]

