"""
Task Breakdown Agent - Converts implementation plans into executable DAG workflows.

This agent uses DSPy Chain of Thought to:
1. Parse implementation plans
2. Break them into granular tasks
3. Identify dependencies between tasks
4. Create a DAG (Directed Acyclic Graph) workflow
"""

from __future__ import annotations

import logging
import re
from typing import List, Dict, Any

import dspy

from Synapse.domain.entities import Task, TaskDAG, TaskType, TaskStatus
from Synapse.signatures.task_breakdown_signatures import (
    ExtractTasksSignature,
    IdentifyDependenciesSignature,
    OptimizeWorkflowSignature
)

logger = logging.getLogger(__name__)


# ============================================================================
# Task Breakdown Agent
# ============================================================================

class TaskBreakdownAgent(dspy.Module):
    """
    DSPy Chain of Thought agent that breaks down implementation plans into DAG workflows.
    
    This agent:
    1. Extracts granular tasks from implementation plan
    2. Identifies dependencies between tasks
    3. Optimizes workflow for parallel execution
    4. Creates a validated DAG structure
    """
    
    def __init__(self):
        super().__init__()
        
        # Chain of Thought modules
        self.extract_tasks = dspy.ChainOfThought(ExtractTasksSignature)
        self.identify_dependencies = dspy.ChainOfThought(IdentifyDependenciesSignature)
        self.optimize_workflow = dspy.ChainOfThought(OptimizeWorkflowSignature)
        
        logger.info("Initialized TaskBreakdownAgent with Chain of Thought reasoning")
    
    def forward(self, implementation_plan: str) -> TaskDAG:
        """
        Break down implementation plan into executable DAG workflow.
        
        Args:
            implementation_plan: Complete implementation plan as string
        
        Returns:
            TaskDAG: Directed Acyclic Graph of tasks with dependencies
        """
        logger.info("[TASK BREAKDOWN] Starting plan analysis...")
        
        # Step 1: Extract tasks
        logger.info("[TASK BREAKDOWN] Step 1: Extracting granular tasks...")
        tasks_response = self.extract_tasks(implementation_plan=implementation_plan)
        tasks_list = tasks_response.tasks_list
        
        logger.info(f"[TASK BREAKDOWN] Extracted tasks:\n{tasks_list[:500]}...")
        
        # Step 2: Identify dependencies
        logger.info("[TASK BREAKDOWN] Step 2: Identifying dependencies...")
        deps_response = self.identify_dependencies(tasks_list=tasks_list)
        dependencies_graph = deps_response.dependencies_graph
        
        logger.info(f"[TASK BREAKDOWN] Dependencies:\n{dependencies_graph[:500]}...")
        
        # Step 3: Optimize workflow
        logger.info("[TASK BREAKDOWN] Step 3: Optimizing workflow...")
        tasks_with_deps = f"TASKS:\n{tasks_list}\n\nDEPENDENCIES:\n{dependencies_graph}"
        workflow_response = self.optimize_workflow(tasks_with_dependencies=tasks_with_deps)
        optimized_workflow = workflow_response.optimized_workflow
        
        logger.info(f"[TASK BREAKDOWN] Optimized workflow:\n{optimized_workflow[:500]}...")
        
        # Step 4: Parse and create DAG
        logger.info("[TASK BREAKDOWN] Step 4: Building DAG structure...")
        dag = self._build_dag(tasks_list, dependencies_graph, optimized_workflow, implementation_plan)
        
        # Step 5: Validate DAG
        is_valid, errors = dag.validate()
        if not is_valid:
            logger.warning(f"[TASK BREAKDOWN] DAG validation warnings: {errors}")
            # Try to fix by removing problematic dependencies
            dag = self._fix_dag_issues(dag, errors)
        
        logger.info(f"[TASK BREAKDOWN] Created DAG with {dag.total_tasks} tasks")
        logger.info(f"[TASK BREAKDOWN] Execution stages: {len(dag.get_execution_stages())}")
        
        return dag
    
    def _build_dag(
        self, 
        tasks_list: str, 
        dependencies_graph: str, 
        optimized_workflow: str,
        original_plan: str
    ) -> TaskDAG:
        """Build TaskDAG from parsed task information."""
        dag = TaskDAG(
            name="Implementation Plan Execution",
            description=f"Auto-generated workflow from implementation plan"
        )
        
        # Parse tasks
        tasks_dict = self._parse_tasks(tasks_list)
        
        # Parse dependencies
        dependencies_dict = self._parse_dependencies(dependencies_graph)
        
        # Create Task objects and add to DAG
        for task_id, task_info in tasks_dict.items():
            task = Task(
                id=task_id,
                name=task_info.get("name", f"Task {task_id}"),
                description=task_info.get("description", ""),
                task_type=self._parse_task_type(task_info.get("type", "implementation")),
                depends_on=dependencies_dict.get(task_id, []),
                code_snippet=task_info.get("code"),
                commands=task_info.get("commands", []),
                files_to_create=task_info.get("files_to_create", []),
                files_required=task_info.get("files_required", []),
                success_criteria=task_info.get("success_criteria", []),
                priority=task_info.get("priority", 1)
            )
            
            dag.add_task(task)
        
        return dag
    
    def _parse_tasks(self, tasks_list: str) -> Dict[str, Dict[str, Any]]:
        """Parse tasks from LLM output."""
        tasks = {}
        task_counter = 1
        
        # Split by TASK: markers
        task_entries = re.split(r'\n(?=TASK:)', tasks_list)
        
        for entry in task_entries:
            if not entry.strip() or not entry.startswith("TASK:"):
                continue
            
            task_id = f"task_{task_counter}"
            task_info = {}
            
            # Extract name
            name_match = re.search(r'TASK:\s*([^|]+)', entry)
            if name_match:
                task_info["name"] = name_match.group(1).strip()
            
            # Extract type
            type_match = re.search(r'TYPE:\s*([^|]+)', entry)
            if type_match:
                task_info["type"] = type_match.group(1).strip().lower()
            
            # Extract description
            desc_match = re.search(r'DESC:\s*([^|]+?)(?:\s*\||$)', entry, re.DOTALL)
            if desc_match:
                task_info["description"] = desc_match.group(1).strip()
            
            # Extract code
            code_match = re.search(r'CODE:\s*```[\w]*\n(.*?)```', entry, re.DOTALL)
            if code_match:
                task_info["code"] = code_match.group(1).strip()
            elif 'CODE:' in entry:
                code_simple = re.search(r'CODE:\s*([^|]+?)(?:\s*\||$)', entry, re.DOTALL)
                if code_simple:
                    task_info["code"] = code_simple.group(1).strip()
            
            # Extract files
            files_match = re.search(r'FILES:\s*([^|]+)', entry)
            if files_match:
                files_str = files_match.group(1).strip()
                files = [f.strip() for f in files_str.split(',') if f.strip()]
                task_info["files_to_create"] = files
            
            tasks[task_id] = task_info
            task_counter += 1
        
        return tasks
    
    def _parse_dependencies(self, dependencies_graph: str) -> Dict[str, List[str]]:
        """Parse dependencies from LLM output."""
        dependencies = {}
        
        # Split by TASK_ID: markers
        dep_entries = re.split(r'\n(?=TASK_ID:)', dependencies_graph)
        
        for entry in dep_entries:
            if not entry.strip() or not entry.startswith("TASK_ID:"):
                continue
            
            # Extract task ID
            task_id_match = re.search(r'TASK_ID:\s*([^|]+)', entry)
            if not task_id_match:
                continue
            
            task_id = task_id_match.group(1).strip()
            
            # Extract dependencies
            deps_match = re.search(r'DEPENDS_ON:\s*([^|]+)', entry)
            if deps_match:
                deps_str = deps_match.group(1).strip()
                if deps_str.lower() in ['none', 'null', '']:
                    dependencies[task_id] = []
                else:
                    deps = [d.strip() for d in deps_str.split(',') if d.strip()]
                    dependencies[task_id] = deps
            else:
                dependencies[task_id] = []
        
        return dependencies
    
    def _parse_task_type(self, type_str: str) -> TaskType:
        """Parse task type from string."""
        type_map = {
            "setup": TaskType.SETUP,
            "implementation": TaskType.IMPLEMENTATION,
            "testing": TaskType.TESTING,
            "execution": TaskType.EXECUTION,
            "documentation": TaskType.DOCUMENTATION,
            "validation": TaskType.VALIDATION,
        }
        
        return type_map.get(type_str.lower(), TaskType.IMPLEMENTATION)
    
    def _fix_dag_issues(self, dag: TaskDAG, errors: List[str]) -> TaskDAG:
        """Attempt to fix DAG validation issues."""
        logger.info("[TASK BREAKDOWN] Attempting to fix DAG issues...")
        
        # Remove dependencies on non-existent tasks
        for task in dag.tasks.values():
            task.depends_on = [dep for dep in task.depends_on if dep in dag.tasks]
        
        # Rebuild adjacency list
        dag.adjacency_list = {}
        for task in dag.tasks.values():
            if task.id not in dag.adjacency_list:
                dag.adjacency_list[task.id] = []
            
            for dep_id in task.depends_on:
                if dep_id not in dag.adjacency_list:
                    dag.adjacency_list[dep_id] = []
                dag.adjacency_list[dep_id].append(task.id)
        
        return dag


def create_task_breakdown_agent() -> TaskBreakdownAgent:
    """
    Factory function to create TaskBreakdownAgent.
    
    The agent uses DSPy Chain of Thought to break down implementation plans into
    executable tasks, automatically excluding Docker/CI/CD/deployment setup tasks
    based on the signature prompts.
    
    Returns:
        TaskBreakdownAgent instance
    """
    return TaskBreakdownAgent()
