"""
TodoCreatorAgent - DSPy ReAct agent for DAG validation, actor assignment, and fixing.

This agent:
1. Takes a TaskDAG and available actors
2. Assigns actors to tasks based on capabilities
3. Validates DAG structure (cycles, dependencies, feasibility)
4. Fixes issues automatically
5. Returns executable DAG with actor assignments

The agent uses DSPy ReAct orchestration with registered tools.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

import dspy

from Synapse.domain.entities import Task, TaskDAG, TaskType, TaskStatus
from Synapse.signatures.todo_creator_signatures import (
    ActorAssignmentSignature,
    DAGValidationSignature
    # DAGFixSignature removed - automatic fixing was redundant
)
from Synapse.signatures.dag_optimization_signatures import OptimizeDAGSignature

logger = logging.getLogger(__name__)


@dataclass
class Actor:
    """Represents an actor/agent that can execute tasks."""
    
    name: str
    capabilities: List[str]  # e.g., ["git", "coding", "web_search", "testing"]
    description: Optional[str] = None
    max_concurrent_tasks: int = 1
    priority_boost: float = 0.0  # Boost priority when actor is suggested for re-evaluation


@dataclass
class AssignedTask:
    """Task with assigned actor."""
    
    task: Task
    actor: Actor
    assigned_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ExecutableDAG:
    """DAG with actor assignments and validation results."""
    
    dag: TaskDAG
    assignments: Dict[str, Actor]  # task_id -> Actor
    validation_passed: bool
    validation_issues: List[str] = field(default_factory=list)
    fixes_applied: List[str] = field(default_factory=list)
    
    def get_assigned_tasks(self) -> List[AssignedTask]:
        """Get all tasks with their assignments."""
        return [
            AssignedTask(task=task, actor=self.assignments.get(task.id))
            for task in self.dag.tasks.values()
        ]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "dag": self.dag.checkpoint(),
            "assignments": {
                task_id: {
                    "actor_name": actor.name,
                    "capabilities": actor.capabilities
                }
                for task_id, actor in self.assignments.items()
            },
            "validation_passed": self.validation_passed,
            "validation_issues": self.validation_issues,
            "fixes_applied": self.fixes_applied
        }


# =============================================================================
# TODO CREATOR AGENT
# =============================================================================

class TodoCreatorAgent:
    """
    DSPy ReAct agent for DAG validation, actor assignment, and fixing.
    
    This is the orchestrator that decides:
    - Which tasks need actor assignment
    - When to validate the DAG
    - What fixes to apply
    - When the DAG is ready for execution
    """
    
    def __init__(self, lm: Optional[dspy.LM] = None):
        """Initialize the agent."""
        # Use provided LM, or fall back to dspy.settings.lm (configured globally)
        self.lm = lm or getattr(dspy.settings, 'lm', None)
        
        if self.lm is None:
            raise RuntimeError(
                "No language model configured. Either pass 'lm' parameter or "
                "configure globally via dspy.configure(lm=...)"
            )
        
        # Initialize sub-modules (not ReAct, just CoT for specific tasks)
        # These will use dspy.settings.lm automatically
        self.dag_optimizer = dspy.ChainOfThought(OptimizeDAGSignature)
        self.actor_assigner = dspy.ChainOfThought(ActorAssignmentSignature)
        self.dag_validator = dspy.ChainOfThought(DAGValidationSignature)
        # Note: dag_fixer removed - automatic fixing was redundant and ineffective
        
        logger.info("TodoCreatorAgent initialized")
    
    def _optimize_dag(self, dag: TaskDAG, actors: List[Actor]) -> TaskDAG:
        """
        Optimize DAG by removing unnecessary tasks.
        
        Args:
            dag: TaskDAG to optimize
            actors: Available actors with capabilities
        
        Returns:
            Optimized TaskDAG with unnecessary tasks removed
        """
        # Extract all capabilities from actors
        all_capabilities = set()
        for actor in actors:
            all_capabilities.update(actor.capabilities)
        
        # Create summary of all tasks
        tasks_summary = []
        for task in dag.tasks.values():
            tasks_summary.append(
                f"ID: {task.id} | NAME: {task.name} | TYPE: {task.task_type.value} | "
                f"DESC: {task.description[:100]}"
            )
        
        tasks_summary_str = "\n".join(tasks_summary)
        capabilities_str = ", ".join(sorted(all_capabilities))
        
        # Call optimizer
        result = self.dag_optimizer(
            tasks_summary=tasks_summary_str,
            available_capabilities=capabilities_str
        )
        
        optimization_plan = result.optimization_plan
        logger.info(f"Optimization plan generated:\n{optimization_plan[:500]}...")
        
        # Parse optimization plan and apply changes
        tasks_to_remove = set()
        
        for line in optimization_plan.split("\n"):
            line = line.strip()
            if line.startswith("REMOVE:"):
                # Extract task IDs to remove
                parts = line.split("|")[0].replace("REMOVE:", "").strip()
                task_ids = [tid.strip() for tid in parts.split(",")]
                tasks_to_remove.update(task_ids)
        
        # Remove tasks from DAG
        for task_id in tasks_to_remove:
            if task_id in dag.tasks:
                task = dag.tasks[task_id]
                logger.info(f"Removing task: {task_id} - {task.name}")
                # Remove from tasks dict
                del dag.tasks[task_id]
                # Remove from dependencies (Task entity uses 'depends_on', not 'dependencies')
                for other_task in dag.tasks.values():
                    if task_id in other_task.depends_on:
                        other_task.depends_on.remove(task_id)
        
        return dag
    
    def create_executable_dag(
        self,
        dag: TaskDAG,
        available_actors: List[Dict[str, Any]]
    ) -> ExecutableDAG:
        """
        Main entry point: Create an executable DAG with actor assignments and validation.
        
        Args:
            dag: TaskDAG to process
            available_actors: List of actor dicts with 'name' and 'capabilities'
        
        Returns:
            ExecutableDAG with assignments and validation results
        """
        logger.info(f"Creating executable DAG for: {dag.name}")
        logger.info(f"Tasks: {dag.total_tasks}, Actors: {len(available_actors)}")
        
        # Convert actor dicts to Actor objects
        actors = [
            Actor(
                name=a["name"],
                capabilities=a["capabilities"],
                description=a.get("description"),
                max_concurrent_tasks=a.get("max_concurrent_tasks", 1)
            )
            for a in available_actors
        ]
        
        # Step 0: Optimize DAG (remove unnecessary tasks)
        # DISABLED: Commenting out DAG optimizer
        # logger.info("Step 0: Optimizing DAG (removing unnecessary tasks)...")
        # original_task_count = dag.total_tasks
        # dag = self._optimize_dag(dag, actors)
        # removed_count = original_task_count - dag.total_tasks
        # logger.info(f"Optimization complete: {removed_count} tasks removed, {dag.total_tasks} tasks remaining")
        
        # Step 1: Assign actors to tasks
        logger.info("Step 1: Assigning actors to tasks...")
        assignments = self._assign_actors_to_tasks(dag, actors)
        logger.info(f"Assigned actors to {len(assignments)}/{dag.total_tasks} tasks")
        
        # Step 1.5: Keep tasks uncollapsed to preserve true fan-out/fan-in semantics.
        # Collapsing can hide independent units, degrade observability, and reduce parallelism.
        logger.info("Step 1.5: Skipping task collapse to preserve explicit parallel task graph")
        
        # Step 2: Validate DAG
        logger.info("Step 2: Validating DAG structure...")
        is_valid, issues = self._validate_dag(dag, assignments, actors)
        
        if is_valid:
            logger.info("✓ DAG validation passed")
            return ExecutableDAG(
                dag=dag,
                assignments=assignments,
                validation_passed=True,
                validation_issues=[],
                fixes_applied=[]
            )
        
        # Step 3: Use validation feedback to LLM-reassign flagged tasks
        logger.warning(f"⚠️  DAG validation found {len(issues)} issues:")
        for i, issue in enumerate(issues, 1):
            logger.warning(f"   {i}. {issue}")
        
        # Step 3b: LLM-based reassignment using validation issues as feedback
        logger.info("Step 3: Re-assigning flagged tasks using validation feedback...")
        fixes_applied = []
        with dspy.context(lm=self.lm):
            for task_id, task in dag.tasks.items():
                current_actor = assignments.get(task_id)
                if not current_actor:
                    continue
                
                # Check if any validation issue mentions this task
                task_issues = [
                    iss for iss in issues
                    if task_id in iss or (task.name and task.name.lower() in iss.lower())
                ]
                if not task_issues:
                    continue
                
                # Re-run assignment with validation feedback appended
                actors_json = json.dumps([
                    {"name": a.name, "capabilities": a.capabilities}
                    for a in actors
                ], indent=2)
                
                feedback_str = "\n".join(task_issues)
                augmented_desc = (
                    f"{task.description}\n\n"
                    f"VALIDATION FEEDBACK (must address):\n{feedback_str}\n"
                    f"Previous assignment '{current_actor.name}' was flagged. "
                    f"Choose the BEST actor considering this feedback."
                )
                
                result = self.actor_assigner(
                    task_id=task_id,
                    task_name=task.name,
                    task_type=task.task_type.value,
                    task_description=augmented_desc,
                    available_actors=actors_json
                )
                
                new_actor = next((a for a in actors if a.name == result.assigned_actor_name), None)
                if new_actor and new_actor.name != current_actor.name:
                    logger.info(f"  🔀 Reassigned {task_id}: {current_actor.name} → {new_actor.name}")
                    assignments[task_id] = new_actor
                    fixes_applied.append(
                        f"Reassigned {task_id} from {current_actor.name} to {new_actor.name} "
                        f"based on validation feedback: {feedback_str[:100]}"
                    )
        
        if fixes_applied:
            logger.info(f"✅ Applied {len(fixes_applied)} reassignment(s) based on validation feedback")
        else:
            logger.info("ℹ️  No reassignments needed; proceeding with original assignments")
        
        return ExecutableDAG(
            dag=dag,
            assignments=assignments,
            validation_passed=len(fixes_applied) > 0,  # Considered passing if we fixed issues
            validation_issues=issues,
            fixes_applied=fixes_applied
        )
    
    def _has_internal_dependencies(self, dag: TaskDAG, task_ids: List[str]) -> bool:
        """
        Check if any task in the group depends on another task in the same group.
        
        A-TEAM FIX: Tasks with internal dependencies cannot be merged because
        they have execution order requirements within the group.
        
        Args:
            dag: TaskDAG with tasks
            task_ids: List of task IDs in the group
            
        Returns:
            True if there are internal dependencies, False otherwise
        """
        task_id_set = set(task_ids)
        for task_id in task_ids:
            task = dag.tasks.get(task_id)
            if task:
                for dep_id in task.depends_on:
                    if dep_id in task_id_set:
                        return True
        return False
    
    def _split_group_by_dependencies(
        self,
        dag: TaskDAG,
        task_ids: List[str]
    ) -> List[List[str]]:
        """
        Split a group of tasks into sub-groups where each sub-group has no internal dependencies.
        
        A-TEAM FIX: When tasks have internal dependencies (e.g., task 3 depends on task 2),
        we cannot merge them. This function splits at dependency boundaries.
        
        Example:
            Tasks [1,2,3,4] where 3→2 becomes [[1,2], [3,4]] or [[1], [2], [3], [4]]
            depending on the dependency structure.
        
        Args:
            dag: TaskDAG with tasks
            task_ids: List of task IDs in topological order
            
        Returns:
            List of sub-groups, each with no internal dependencies
        """
        if not task_ids:
            return []
        
        task_id_set = set(task_ids)
        sub_groups = []
        current_sub_group = []
        
        for task_id in task_ids:
            task = dag.tasks.get(task_id)
            if not task:
                continue
            
            # Check if this task depends on any task in the current sub-group
            has_internal_dep = False
            for dep_id in task.depends_on:
                if dep_id in set(current_sub_group):
                    has_internal_dep = True
                    break
            
            if has_internal_dep:
                # This task depends on something in current sub-group
                # Finalize current sub-group and start new one
                if current_sub_group:
                    sub_groups.append(current_sub_group)
                current_sub_group = [task_id]
            else:
                # No internal dependency, add to current sub-group
                current_sub_group.append(task_id)
        
        # Don't forget the last sub-group
        if current_sub_group:
            sub_groups.append(current_sub_group)
        
        return sub_groups
    
    def _collapse_consecutive_tasks(
        self,
        dag: TaskDAG,
        assignments: Dict[str, Actor]
    ) -> Tuple[TaskDAG, Dict[str, Actor]]:
        """
        Collapse consecutive tasks assigned to the same actor into single combined tasks.
        
        A-TEAM FIX (2026-02-02): Now respects internal dependencies.
        - Tasks with dependencies BETWEEN themselves (internal) are NOT merged
        - Tasks with dependencies on EXTERNAL tasks ARE merged, carrying the external deps
        
        Example 1 (external deps only - CAN merge):
            Tasks [1,2,3,4] where 2,3 depend on 1 (actor A), and 2,3,4 are actor B:
            → Task 1 (actor A), Task 2_3_4 (actor B, depends on 1)
            
        Example 2 (internal deps - CANNOT merge):
            Tasks [1,2,3,4] where 3 depends on 2, 4 depends on 3 (all same actor):
            → Tasks 1, 2, 3, 4 kept separate (dependency chain preserved)
            
        Args:
            dag: TaskDAG with tasks
            assignments: Dict mapping task_id -> Actor
            
        Returns:
            Tuple of (modified_dag, updated_assignments)
        """
        try:
            # Get topological order to identify consecutive tasks
            task_order = dag.get_topological_order(exclude_completed=False)
        except ValueError as e:
            logger.warning(f"Cannot collapse tasks - topological sort failed: {e}")
            return dag, assignments
        
        # Group consecutive tasks by actor
        groups = []
        current_group = []
        current_actor = None
        
        for task_id in task_order:
            if task_id not in assignments:
                # Task not assigned, start new group
                if current_group:
                    groups.append((current_actor, current_group))
                current_group = []
                current_actor = None
                continue
            
            task_actor = assignments[task_id]
            
            if current_actor is None or current_actor.name != task_actor.name:
                # Actor changed, start new group
                if current_group:
                    groups.append((current_actor, current_group))
                current_group = [task_id]
                current_actor = task_actor
            else:
                # Same actor, add to current group
                current_group.append(task_id)
        
        # Don't forget the last group
        if current_group:
            groups.append((current_actor, current_group))
        
        # Compute lightweight dependency depth map for structure-aware merge decisions.
        # Tasks at the same depth with no internal dependencies are likely parallelizable and
        # should be preserved as separate tasks to let Conductor run them concurrently.
        depth_cache: Dict[str, int] = {}

        def _task_depth(task_id: str, visiting: Optional[set] = None) -> int:
            if task_id in depth_cache:
                return depth_cache[task_id]
            if visiting is None:
                visiting = set()
            if task_id in visiting:
                # Cycle safety (validation should prevent this)
                return 0
            visiting.add(task_id)
            task = dag.tasks.get(task_id)
            if not task or not task.depends_on:
                depth_cache[task_id] = 0
                visiting.remove(task_id)
                return 0
            max_parent = 0
            for dep in task.depends_on:
                if dep in dag.tasks:
                    max_parent = max(max_parent, _task_depth(dep, visiting) + 1)
            depth_cache[task_id] = max_parent
            visiting.remove(task_id)
            return max_parent

        for tid in dag.tasks.keys():
            _task_depth(tid)

        # Now collapse groups with structure-aware (non-hardcoded) decisions.
        new_assignments = {}
        tasks_to_remove = set()
        
        for actor, task_ids in groups:
            if len(task_ids) == 1:
                # Single task, keep as is
                new_assignments[task_ids[0]] = actor
                continue
            
            has_internal = self._has_internal_dependencies(dag, task_ids)
            group_depths = {depth_cache.get(tid, 0) for tid in task_ids}
            same_depth = len(group_depths) == 1

            # Preserve tasks when they are independent + same-depth (parallelizable),
            # or when internal dependencies require explicit ordering.
            preserve_group = has_internal or same_depth

            if preserve_group:
                reason = "internal dependencies" if has_internal else "same-depth independent tasks (parallelizable)"
                logger.info(
                    f"Preserving {len(task_ids)} tasks for actor {actor.name} due to {reason}: {task_ids}"
                )
                for tid in task_ids:
                    new_assignments[tid] = actor
            else:
                logger.info(
                    f"Collapsing {len(task_ids)} tasks for actor {actor.name} "
                    f"(depths={sorted(group_depths)}): {task_ids}"
                )
                self._merge_task_group(dag, task_ids, actor, new_assignments, tasks_to_remove)
            
        # Remove original tasks from DAG
        for task_id in tasks_to_remove:
            if task_id in dag.tasks:
                del dag.tasks[task_id]
            if task_id in dag.adjacency_list:
                del dag.adjacency_list[task_id]
        
        # Update total tasks count
        dag.total_tasks = len(dag.tasks)
        
        logger.info(f"Task collapse complete: {len(groups)} groups, {len(new_assignments)} final tasks")
        return dag, new_assignments
    
    def _merge_task_group(
        self,
        dag: TaskDAG,
        task_ids: List[str],
        actor: Actor,
        new_assignments: Dict[str, Actor],
        tasks_to_remove: set
    ) -> None:
        """
        Merge a group of tasks into a single combined task.
        
        A-TEAM UPDATE (2026-02-02): 
        - Same-actor tasks are ALWAYS merged, even with internal dependencies
        - The actor handles execution order internally
        - Only EXTERNAL dependencies (on tasks outside the group) are preserved
        
        This method collects ALL external dependencies from ALL tasks in the group,
        ensuring the merged task correctly depends on all prerequisites from other actors.
        
        Args:
            dag: TaskDAG with tasks
            task_ids: List of task IDs to merge
            actor: Actor assigned to this group
            new_assignments: Dict to update with new assignment
            tasks_to_remove: Set to update with tasks to remove
        """
        logger.info(f"Merging {len(task_ids)} tasks for actor {actor.name}: {task_ids}")
        
        # Create combined task ID
        combined_id = "_".join(task_ids)
        
        # Get all tasks
        tasks = [dag.tasks[tid] for tid in task_ids]
        
        # Combine task properties
        combined_name = " + ".join([t.name for t in tasks])
        combined_description = "\n\n".join([
            f"**{t.id}: {t.name}**\n{t.description}"
            for t in tasks
        ])
        
        # Combine commands, files, etc.
        combined_commands = []
        combined_files_to_create = []
        combined_files_required = []
        combined_success_criteria = []
        
        for task in tasks:
            combined_commands.extend(task.commands)
            combined_files_to_create.extend(task.files_to_create)
            combined_files_required.extend(task.files_required)
            combined_success_criteria.extend(task.success_criteria)
        
        # A-TEAM FIX: Collect ALL external dependencies from ALL tasks in the group
        # Not just the first task - this ensures we don't lose any prerequisites
        task_id_set = set(task_ids)
        all_external_deps = set()
        for task in tasks:
            for dep_id in task.depends_on:
                if dep_id not in task_id_set:  # Only external deps
                    all_external_deps.add(dep_id)
        
        # Create combined task
        combined_task = Task(
            id=combined_id,
            name=combined_name[:200],  # Limit name length
            description=combined_description,
            task_type=tasks[0].task_type,  # Use first task's type
            depends_on=list(all_external_deps),  # All external dependencies
            commands=combined_commands,
            files_to_create=combined_files_to_create,
            files_required=combined_files_required,
            estimated_duration=None,  # Could sum durations if needed
            priority=max(t.priority for t in tasks),  # Use highest priority
            status=tasks[0].status,
            success_criteria=combined_success_criteria,
            failure_handling=tasks[0].failure_handling
        )
        
        # Add combined task to DAG
        dag.tasks[combined_id] = combined_task
        new_assignments[combined_id] = actor
        
        # Update adjacency list
        if combined_id not in dag.adjacency_list:
            dag.adjacency_list[combined_id] = []
        
        # Find all tasks that depend on ANY task in this group
        dependents = set()
        for task_id in task_ids:
            if task_id in dag.adjacency_list:
                for dependent in dag.adjacency_list[task_id]:
                    if dependent not in task_id_set:  # Don't include internal dependencies
                        dependents.add(dependent)
        
        # Update dependents to depend on combined task instead
        for dependent_id in dependents:
            if dependent_id in dag.tasks:
                dependent_task = dag.tasks[dependent_id]
                # Remove old dependencies
                for old_task_id in task_ids:
                    if old_task_id in dependent_task.depends_on:
                        dependent_task.depends_on.remove(old_task_id)
                # Add new dependency
                if combined_id not in dependent_task.depends_on:
                    dependent_task.depends_on.append(combined_id)
        
        # Add dependents to combined task's adjacency list
        dag.adjacency_list[combined_id] = list(dependents)
        
        # Mark original tasks for removal
        tasks_to_remove.update(task_ids)
    
    def _assign_actors_to_tasks(
        self,
        dag: TaskDAG,
        actors: List[Actor]
    ) -> Dict[str, Actor]:
        """Assign actors to all tasks in the DAG based on capabilities only."""
        assignments = {}
        
        with dspy.context(lm=self.lm):
            for task_id, task in dag.tasks.items():
                # Use LLM to make smart assignment from all available actors
                # Focus on capability matching only, no continuity preference
                # Use JSON format for better LLM parsing (instead of str() which creates Python repr)
                actors_json = json.dumps([
                    {"name": a.name, "capabilities": a.capabilities}
                    for a in actors
                ], indent=2)
                
                result = self.actor_assigner(
                    task_id=task_id,
                    task_name=task.name,
                    task_type=task.task_type.value,
                    task_description=task.description,
                    available_actors=actors_json
                )
                
                # Primary: take LLM-selected actor by name.
                assigned_actor = next((a for a in actors if a.name == result.assigned_actor_name), None)
                if assigned_actor is None:
                    # Fallback: map near-miss actor names (case/spacing/typo) generically.
                    import difflib
                    wanted = (result.assigned_actor_name or "").strip().lower()
                    actor_names = [a.name for a in actors]
                    normalized = {
                        a.name: a.name.replace("_", "").replace(" ", "").lower()
                        for a in actors
                    }
                    close = difflib.get_close_matches(
                        wanted.replace("_", "").replace(" ", ""),
                        list(normalized.values()),
                        n=1,
                        cutoff=0.55,
                    )
                    if close:
                        matched = next(name for name, norm in normalized.items() if norm == close[0])
                        assigned_actor = next(a for a in actors if a.name == matched)
                    else:
                        # Last-resort fallback keeps planner alive if LLM emits an unknown actor.
                        assigned_actor = actors[0]
                
                assignments[task_id] = assigned_actor
                logger.debug(f"Assigned {task_id} to {assigned_actor.name}: {result.reasoning}")
        
        return assignments
    
    def _validate_dag(
        self,
        dag: TaskDAG,
        assignments: Dict[str, Actor],
        actors: List[Actor]
    ) -> Tuple[bool, List[str]]:
        """Validate DAG structure and assignments."""
        issues = []
        
        # 1. Check for cycles
        cycle = dag.detect_cycle_with_path()
        cycle_info = f"Cycle found: {' → '.join(cycle)}" if cycle else "No cycle detected"
        
        # 2. Check missing dependencies
        for task_id, task in dag.tasks.items():
            for dep_id in task.depends_on:
                if dep_id not in dag.tasks:
                    issues.append(f"Task {task_id} depends on non-existent task {dep_id}")
        
        # 3. Check unassigned tasks
        unassigned = [tid for tid in dag.tasks if tid not in assignments]
        if unassigned:
            issues.append(f"Unassigned tasks: {', '.join(unassigned)}")
        
        # 4. Use LLM for deeper validation
        stats = dag.get_stats()
        
        with dspy.context(lm=self.lm):
            result = self.dag_validator(
                dag_summary=str(stats),
                tasks_info=str([
                    {
                        "id": t.id,
                        "name": t.name,
                        "type": t.task_type.value,
                        "depends_on": t.depends_on
                    }
                    for t in dag.tasks.values()
                ]),
                assignments_info=str({
                    tid: actor.name
                    for tid, actor in assignments.items()
                }),
                available_actors=str([
                    {"name": a.name, "capabilities": a.capabilities}
                    for a in actors
                ]),
                cycle_check=cycle_info
            )
        
        # Parse LLM results
        is_valid = result.is_valid.upper() == "YES"
        
        if result.issues_found.strip().lower() not in ["none", "no issues", ""]:
            llm_issues = [
                issue.strip()
                for issue in result.issues_found.split("\n")
                if issue.strip() and not issue.strip().lower().startswith("none")
            ]
            issues.extend(llm_issues)
        
        # Add cycle to issues if found
        if cycle:
            issues.insert(0, f"Circular dependency: {' → '.join(cycle)}")
        
        return (len(issues) == 0 and is_valid), issues
    
    def visualize_assignments(self, executable_dag: ExecutableDAG) -> str:
        """Generate a visualization of task-actor assignments."""
        output = []
        output.append("\n" + "="*80)
        output.append("TASK-ACTOR ASSIGNMENTS")
        output.append("="*80 + "\n")
        
        # Group by actor
        actor_tasks: Dict[str, List[Task]] = {}
        for task_id, actor in executable_dag.assignments.items():
            if actor.name not in actor_tasks:
                actor_tasks[actor.name] = []
            actor_tasks[actor.name].append(executable_dag.dag.tasks[task_id])
        
        for actor_name, tasks in actor_tasks.items():
            actor = next(a for a in executable_dag.assignments.values() if a.name == actor_name)
            output.append(f"\n👤 {actor_name}")
            output.append(f"   Capabilities: {', '.join(actor.capabilities)}")
            output.append(f"   Assigned Tasks: {len(tasks)}")
            output.append("   " + "-"*70)
            
            for task in tasks:
                output.append(f"   • {task.id}: {task.name} ({task.task_type.value})")
                if task.depends_on:
                    output.append(f"     ↳ Depends on: {', '.join(task.depends_on)}")
        
        output.append("\n" + "="*80 + "\n")
        return "\n".join(output)


def create_todo_creator_agent(lm: Optional[dspy.LM] = None) -> TodoCreatorAgent:
    """Factory function to create a TodoCreatorAgent."""
    return TodoCreatorAgent(lm=lm)
