"""
User Communication Agent - Generates user-facing messages for tasks.

This agent uses DSPy Chain of Thought to:
1. Analyze task status and context
2. Determine appropriate communication type
3. Generate clear, concise messages for users
4. Suggest actionable next steps when needed
"""

from __future__ import annotations

import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field

import dspy

from Synapse.signatures.user_communication_signatures import (
    UserCommunicationSignature,
    CommunicationPrioritySignature
)

logger = logging.getLogger(__name__)


# ============================================================================
# Data Structures
# ============================================================================

@dataclass
class UserCommunication:
    """Represents a communication to be sent to the user."""
    
    communication_type: str  # PROGRESS, COMPLETION, ERROR, CLARIFICATION, WAITING, INFO
    message: str
    suggested_actions: list[str] = field(default_factory=list)
    priority: str = "MEDIUM"  # CRITICAL, HIGH, MEDIUM, LOW
    should_notify: bool = False
    reasoning: str = ""  # Internal reasoning for debugging
    # 🆕 A-TEAM: Detailed answer in markdown for "View More" modal
    # This contains the full detailed response when the short message isn't enough
    detailed_answer: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "communication_type": self.communication_type,
            "message": self.message,
            "suggested_actions": self.suggested_actions,
            "priority": self.priority,
            "should_notify": self.should_notify,
            "reasoning": self.reasoning,
            "detailed_answer": self.detailed_answer
        }
    
    def __str__(self) -> str:
        """User-friendly string representation."""
        result = f"[{self.communication_type}] {self.message}"
        if self.suggested_actions:
            actions = "\n".join(f"  • {action}" for action in self.suggested_actions)
            result += f"\n\nSuggested actions:\n{actions}"
        return result


# ============================================================================
# User Communication Agent
# ============================================================================

class UserCommunicationAgent:
    """
    DSPy Chain of Thought agent that generates user communications.
    
    This agent analyzes task context and status to determine what should be
    communicated to the user, generating clear, concise, and actionable messages.
    
    Usage:
        agent = UserCommunicationAgent()
        
        # Basic usage
        communication = agent.generate(
            task_description="Analyze sales data and create a summary report",
            context="Status: completed. Output: Generated report with 150 rows analyzed."
        )
        
        # With priority determination
        communication = agent.generate_with_priority(
            task_description="Deploy application to production",
            context="Status: failed. Error: Connection timeout to server.",
            task_importance="Critical path - release deadline tomorrow"
        )
    """
    
    def __init__(self, lm: Optional[dspy.LM] = None):
        """
        Initialize the UserCommunicationAgent.
        
        Args:
            lm: Optional DSPy language model. If not provided, uses the
                globally configured model from dspy.settings.lm
        """
        self.lm = lm or getattr(dspy.settings, 'lm', None)
        
        # Chain of Thought modules for reasoning
        self.communicator = dspy.ChainOfThought(UserCommunicationSignature)
        self.prioritizer = dspy.ChainOfThought(CommunicationPrioritySignature)
        
        logger.info("Initialized UserCommunicationAgent with Chain of Thought reasoning")
    
    def generate(
        self,
        task_description: str,
        context: str
    ) -> UserCommunication:
        """
        Generate a user communication for the given task and context.
        
        Args:
            task_description: The task that was requested or is being worked on
            context: Current context including status, outputs, errors, etc.
        
        Returns:
            UserCommunication object with the message and metadata
        """
        logger.info("[USER_COMM] Generating communication for task...")
        logger.debug(f"[USER_COMM] Task: {task_description[:100]}...")
        logger.debug(f"[USER_COMM] Context: {context[:200]}...")
        
        try:
            # Use LM context if available
            if self.lm:
                with dspy.context(lm=self.lm):
                    result = self.communicator(
                        task_description=task_description,
                        context=context
                    )
            else:
                result = self.communicator(
                    task_description=task_description,
                    context=context
                )
            
            # Parse suggested actions
            actions = self._parse_actions(result.suggested_actions)
            
            # Parse detailed answer (None if empty or 'None')
            detailed_answer = self._parse_detailed_answer(result.detailed_answer)
            
            # Create communication object
            communication = UserCommunication(
                communication_type=self._normalize_type(result.communication_type),
                message=result.message.strip(),
                suggested_actions=actions,
                reasoning=result.reasoning,
                detailed_answer=detailed_answer
            )
            
            logger.info(f"[USER_COMM] Generated {communication.communication_type} communication")
            if detailed_answer:
                logger.info(f"[USER_COMM] Detailed answer included ({len(detailed_answer)} chars)")
            return communication
            
        except Exception as e:
            logger.error(f"[USER_COMM] Error generating communication: {e}")
            # Return a safe fallback
            return UserCommunication(
                communication_type="ERROR",
                message=f"Unable to generate communication: {str(e)}",
                reasoning=f"Exception occurred: {str(e)}"
            )
    
    def generate_with_priority(
        self,
        task_description: str,
        context: str,
        task_importance: str = "Standard priority task"
    ) -> UserCommunication:
        """
        Generate a user communication with priority determination.
        
        Args:
            task_description: The task that was requested or is being worked on
            context: Current context including status, outputs, errors, etc.
            task_importance: Description of how important this task is to the workflow
        
        Returns:
            UserCommunication object with priority and notification flag
        """
        # First, generate the base communication
        communication = self.generate(task_description, context)
        
        # Then determine priority
        logger.info("[USER_COMM] Determining communication priority...")
        
        try:
            if self.lm:
                with dspy.context(lm=self.lm):
                    priority_result = self.prioritizer(
                        communication_type=communication.communication_type,
                        message=communication.message,
                        task_importance=task_importance
                    )
            else:
                priority_result = self.prioritizer(
                    communication_type=communication.communication_type,
                    message=communication.message,
                    task_importance=task_importance
                )
            
            # Update communication with priority info
            communication.priority = self._normalize_priority(priority_result.priority)
            communication.should_notify = priority_result.should_notify.lower().strip() == "yes"
            communication.reasoning += f"\n\nPriority reasoning: {priority_result.reasoning}"
            
            logger.info(f"[USER_COMM] Priority: {communication.priority}, Notify: {communication.should_notify}")
            
        except Exception as e:
            logger.warning(f"[USER_COMM] Priority determination failed: {e}, using defaults")
            # Use sensible defaults based on communication type
            communication.priority = self._default_priority(communication.communication_type)
            communication.should_notify = communication.priority in ["CRITICAL", "HIGH"]
        
        return communication
    
    def _parse_actions(self, actions_str: str) -> list[str]:
        """Parse suggested actions from string to list."""
        if not actions_str or actions_str.lower().strip() in ["none", "n/a", "-", ""]:
            return []
        
        # Handle comma-separated or newline-separated
        if "," in actions_str:
            actions = [a.strip() for a in actions_str.split(",")]
        elif "\n" in actions_str:
            actions = [a.strip() for a in actions_str.split("\n")]
        else:
            actions = [actions_str.strip()]
        
        # Filter out empty strings and "None" entries
        return [a for a in actions if a and a.lower() not in ["none", "n/a"]]
    
    def _parse_detailed_answer(self, detailed_str: str) -> Optional[str]:
        """Parse detailed answer - return None if empty/None, otherwise return cleaned markdown."""
        if not detailed_str:
            return None
        
        cleaned = detailed_str.strip()
        
        # Check for "None" or empty responses
        if cleaned.lower() in ["none", "n/a", "-", "null", ""]:
            return None
        
        # Return the detailed markdown content
        return cleaned
    
    def _normalize_type(self, comm_type: str) -> str:
        """Normalize communication type to expected values."""
        comm_type = comm_type.upper().strip()
        valid_types = {"PROGRESS", "COMPLETION", "ERROR", "CLARIFICATION", "WAITING", "INFO"}
        
        if comm_type in valid_types:
            return comm_type
        
        # Handle common variations
        type_map = {
            "COMPLETE": "COMPLETION",
            "COMPLETED": "COMPLETION",
            "SUCCESS": "COMPLETION",
            "FAILED": "ERROR",
            "FAILURE": "ERROR",
            "QUESTION": "CLARIFICATION",
            "PENDING": "WAITING",
            "UPDATE": "PROGRESS",
            "STATUS": "PROGRESS",
            "INFORMATION": "INFO",
            "INFORMATIONAL": "INFO"
        }
        
        return type_map.get(comm_type, "INFO")
    
    def _normalize_priority(self, priority: str) -> str:
        """Normalize priority to expected values."""
        priority = priority.upper().strip()
        valid_priorities = {"CRITICAL", "HIGH", "MEDIUM", "LOW"}
        
        if priority in valid_priorities:
            return priority
        
        # Handle variations
        priority_map = {
            "URGENT": "CRITICAL",
            "IMPORTANT": "HIGH",
            "NORMAL": "MEDIUM",
            "ROUTINE": "MEDIUM",
            "MINOR": "LOW",
            "MINIMAL": "LOW"
        }
        
        return priority_map.get(priority, "MEDIUM")
    
    def _default_priority(self, comm_type: str) -> str:
        """Get default priority based on communication type."""
        priority_map = {
            "ERROR": "HIGH",
            "CLARIFICATION": "HIGH",
            "COMPLETION": "MEDIUM",
            "PROGRESS": "LOW",
            "WAITING": "LOW",
            "INFO": "LOW"
        }
        return priority_map.get(comm_type, "MEDIUM")


# ============================================================================
# Factory Function
# ============================================================================

def create_user_communication_agent(lm: Optional[dspy.LM] = None) -> UserCommunicationAgent:
    """
    Factory function to create UserCommunicationAgent.
    
    Args:
        lm: Optional DSPy language model. If not provided, uses the
            globally configured model from dspy.settings.lm
    
    Returns:
        UserCommunicationAgent instance
    
    Example:
        # Using global LM
        agent = create_user_communication_agent()
        
        # Using specific LM
        my_lm = dspy.LM(model="gpt-4", api_key="...")
        agent = create_user_communication_agent(lm=my_lm)
    """
    return UserCommunicationAgent(lm=lm)
