"""
Agent Resolver Agent - Intelligently resolves agent names when direct matches fail.

This agent uses DSPy Chain of Thought to:
1. Analyze the requested agent name and context
2. Match against available agents based on capabilities
3. Resolve to the correct agent name or suggest "all" for broadcast
"""

from __future__ import annotations

import json
import logging
from typing import Dict, Any, Optional

import dspy

from Synapse.signatures.agent_resolver_signatures import ResolveAgentSignature

logger = logging.getLogger(__name__)


class AgentResolverAgent(dspy.Module):
    """
    DSPy Chain of Thought agent that resolves agent names when direct matches fail.
    
    This agent:
    1. Analyzes the requested agent name and what help is needed
    2. Matches against available agents based on capabilities
    3. Returns the best matching agent name or "all" for broadcast
    """
    
    def __init__(self):
        super().__init__()
        
        # Chain of Thought module for agent resolution
        self.resolve_agent = dspy.ChainOfThought(ResolveAgentSignature)
        
        logger.info("Initialized AgentResolverAgent with Chain of Thought reasoning")
    
    def forward(
        self,
        requested_agent_name: str,
        knowledge_type: str,
        request_context: Dict[str, Any],
        available_agents: Dict[str, Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Resolve a requested agent name to the correct agent.
        
        Args:
            requested_agent_name: The agent name that was requested (may be incorrect)
            knowledge_type: Type of knowledge/help being requested
            request_context: Context about what help is needed
            available_agents: Dictionary of available agents with their capabilities
            
        Returns:
            Dictionary with:
                - resolved_agent_name: The correct agent name or "all"
                - reasoning: Explanation of the resolution
                - confidence: Confidence score 0.0-1.0
        """
        logger.info(f"[AGENT RESOLVER] Resolving '{requested_agent_name}' for '{knowledge_type}'")
        
        # Format available agents for LLM
        agents_json = json.dumps(available_agents, indent=2, default=str)
        context_json = json.dumps(request_context, indent=2, default=str)
        
        # Call Chain of Thought resolver
        result = self.resolve_agent(
            requested_agent_name=requested_agent_name,
            knowledge_type=knowledge_type,
            request_context=context_json,
            available_agents=agents_json
        )
        
        resolved_name = result.resolved_agent_name.strip()
        reasoning = result.reasoning
        confidence = float(result.confidence) if result.confidence else 0.5
        
        # Validate resolved name
        if resolved_name not in available_agents and resolved_name != "all":
            logger.warning(
                f"[AGENT RESOLVER] Resolved agent '{resolved_name}' not in available agents. "
                f"Available: {list(available_agents.keys())}. Falling back to 'all'."
            )
            resolved_name = "all"
            confidence = 0.0
        
        logger.info(
            f"[AGENT RESOLVER] Resolved '{requested_agent_name}' → '{resolved_name}' "
            f"(confidence: {confidence:.2f})"
        )
        logger.debug(f"[AGENT RESOLVER] Reasoning: {reasoning}")
        
        return {
            "resolved_agent_name": resolved_name,
            "reasoning": reasoning,
            "confidence": confidence,
            "original_request": requested_agent_name
        }
