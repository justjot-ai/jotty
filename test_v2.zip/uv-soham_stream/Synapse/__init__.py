"""
SYNAPSE v10.0 - SYnergistic Neural Agent Processing & Self-organizing Execution
================================================================================

Production-Ready Multi-Agent RL Wrapper for DSPy

Quick Start:
    from Synapse import Conductor, AgentConfig
    
    swarm = Conductor(
        actors=[AgentConfig(name="my_agent", agent=my_dspy_module, 
                           architect_prompts=["plan.md"], auditor_prompts=["validate.md"])],
    )
    result = await swarm.run("Process this")

Key Features:
- Works with ANY DSPy module (ChainOfThought, ReAct, Predict, custom)
- Never runs out of context (auto-chunking + compression)
- Cooperative reward (helps swarm cooperation)
- 5-level hierarchical memory
- Zero hardcoding (all decisions by LLM agents)

SYNAPSE Naming Convention:
- Conductor = Main orchestrator (was SwarmReVal)
- SynapseCore = Core execution engine (was ReVal)
- Architect = Pre-execution planner (was PreVal)
- Auditor = Post-execution validator (was PostVal)
- AgentConfig = Agent configuration (was ActorConfig)
- Cortex = Hierarchical memory system
- Axon = Agent communication layer (was AgentSlack)
- Roadmap = Markovian TODO system

See README.md for complete documentation.
"""

__version__ = "10.0.0"
__author__ = "A-Team"

# =============================================================================
# PRIMARY EXPORTS (Production API)
# =============================================================================

# 🎯 CLEAN INTERFACE (Recommended entry point)
from .interface import (
    Synapse,
    AgentConfig as AgentConfigNew,
    SynapseConfig as SynapseConfigNew,
    SwarmResult,
    ValidationMode,
    LearningMode,
    CooperationMode,
    MetadataProtocol,
)

# Main Entry Points (Legacy compatibility)
from .core.conductor import (
    Conductor,
    TodoItem,
    create_conductor
)
from .core.agent_config import AgentConfig

# Configuration
from .core.data_structures import (
    SynapseConfig,
    MemoryLevel,
    ValidationResult
)

# Tool Management
from .core.tool_shed import (
    ToolShed,
    ToolSchema,
    ToolResult,
    CapabilityIndex,
)

# Web Search Tools (open source)
from .core.web_search_tools import (
    OpenSourceWebSearchProvider,
)

from .core.composite_metadata_provider import (
    CompositeMetadataProvider,
)

# Commented out - invariants.py doesn't exist
# from .core.invariants import (
#     invariant_sorted,
#     invariant_non_negative,
#     invariant_finite,
# )

# Simple Brain (Recommended for quick setup)
from .core.simple_brain import (
    SimpleBrain,
    BrainPreset,
    calculate_chunk_size,
    get_model_context
)

# =============================================================================
# SECONDARY EXPORTS (Advanced Usage)
# =============================================================================

# Memory System
from .core.cortex import (
    HierarchicalMemory,
    MemoryCluster
)

# Learning Components
from .core.learning import (
    TDLambdaLearner,
    AdaptiveLearningRate,
    ReasoningCreditAssigner
)

# Environment Management
from .core.environment_manager import (
    EnvironmentManager,
    EnvironmentSnapshot,
    create_environment_manager
)

# Context Protection
from .core.global_context_guard import (
    GlobalContextGuard,
    patch_dspy_with_guard,
    unpatch_dspy
)

# Universal Wrapper (for wrapping single modules)
from .core.universal_wrapper import (
    SynapseUniversal,
    SmartConfig,
    synapse_universal
)

# =============================================================================
# ADVANCED EXPORTS (For Custom Implementations)
# =============================================================================

# Data Structures
from .core.data_structures import (
    MemoryEntry,
    GoalValue,
    EpisodeResult,
    TaggedOutput,
    OutputTag,
    StoredEpisode,
    LearningMetrics,
    GoalHierarchy,
    GoalNode,
    CausalLink
)

# Enhanced State
from .core.roadmap import (
    AgenticState,
    TrajectoryStep,
    DecomposedQFunction,
    MarkovianTODO,
    SubtaskState,
    TaskStatus
)

# Predictive MARL
from .core.predictive_marl import (
    LLMTrajectoryPredictor,
    DivergenceMemory,
    CooperativeCreditAssigner,
    AgentModel
)

# Brain Modes - REMOVED (SimpleBrain + HierarchicalMemory are superior)
# See A_TEAM_TECHNICAL_COMPARISON_ACTIVE_VS_ORPHANED.md for details

# Modern Agents (v9.0 - No Heuristics)
from .core.modern_agents import (
    UniversalRetryHandler,
    PatternDetector,
    LLMCounterfactualCritic,
    SelfRAGMemoryRetriever,
    LLMSurpriseEstimator
)

# Robust Parsing
from .core.robust_parsing import (
    parse_float_robust,
    parse_bool_robust,
    parse_json_robust,
    AdaptiveThreshold,
    safe_hash
)

# =============================================================================
# ALL EXPORTS
# =============================================================================

__all__ = [
    # 🎯 CLEAN INTERFACE (Recommended)
    "Synapse",
    "SwarmResult",
    "ValidationMode",
    "LearningMode",
    "CooperationMode",
    "MetadataProtocol",
    
    # Tool Management
    "ToolShed",
    "ToolSchema",
    "CapabilityIndex",
    "OpenSourceWebSearchProvider",
    "CompositeMetadataProvider",
    "invariant_sorted",
    "invariant_non_negative",
    "invariant_finite",
    
    # Shaped Rewards
    "ShapedRewardManager",
    "RewardCondition",
    
    # Primary (Legacy)
    "Conductor",
    "AgentConfig", 
    "SynapseConfig",
    "TodoItem",
    "create_conductor",
    "SimpleBrain",
    "BrainPreset",
    
    # Memory
    "HierarchicalMemory",
    "MemoryLevel",
    "MemoryCluster",
    
    # Learning
    "TDLambdaLearner",
    "AdaptiveLearningRate",
    "ReasoningCreditAssigner",
    
    # Environment Management
    "EnvironmentManager",
    "EnvironmentSnapshot",
    "create_environment_manager",
    
    # Context
    "GlobalContextGuard",
    "patch_dspy_with_guard",
    
    # Universal Wrapper
    "SynapseUniversal",
    "SmartConfig",
    "synapse_universal",
    
    # Data Structures
    "MemoryEntry",
    "ValidationResult",
    "EpisodeResult",
    "GoalHierarchy",
    
    # State
    "AgenticState",
    "MarkovianTODO",
    
    # MARL
    "LLMTrajectoryPredictor",
    "CooperativeCreditAssigner",
    
    # Brain
    "BrainMode",
    "HippocampalExtractor",
    
    # Modern Agents
    "UniversalRetryHandler",
    "PatternDetector",
    "LLMCounterfactualCritic",
    "SelfRAGMemoryRetriever",
    "LLMSurpriseEstimator",
    
    # Utilities
    "parse_float_robust",
    "parse_json_robust",
    "AdaptiveThreshold",
    "calculate_chunk_size",
    "get_model_context",
]
