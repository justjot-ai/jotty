#!/usr/bin/env python3
"""
Persona Refinement Script for Terminal-Bench Tasks

This script refines persona assignments to create optimal teams for each task based on:
1. Category-based primary persona selection
2. Knowledge domain-based supporting persona selection
3. Instruction content analysis for technical stack
4. Tag-based enhancement

Based on A-Team Review Decision (2026-01-10)
"""

import yaml
import json
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict

# Category to Primary Persona mapping (max 2 primaries per category)
CATEGORY_PRIMARY_MAP = {
    "machine-learning": ["ML Engineer", "Data Scientist"],
    "model-training": ["ML Engineer", "Data Scientist"],
    "scientific-computing": ["Research Scientist", "Data Scientist"],
    "system-administration": ["System Administrator", "DevOps Engineer"],
    "security": ["Security Engineer", "Cryptographer"],
    "games": ["Game Developer", "Software Engineer"],
    "data-science": ["Data Scientist", "Data Engineer"],
    "software-engineering": ["Software Engineer", "Backend Engineer"],
    "debugging": ["Software Engineer", "QA Engineer"],
    "file-operations": ["Software Engineer", "System Administrator"],
    "algorithms": ["Software Engineer", "Research Scientist"],
    "mathematics": ["Research Scientist", "Data Scientist"],
    "web": ["Web Developer", "Backend Engineer"],
    "networking": ["Network Engineer", "System Administrator"],
    "reproducible-builds": ["DevOps Engineer", "Compiler Engineer"],
    "research": ["Research Scientist", "Data Scientist"],
    "data-processing": ["Data Engineer", "Data Scientist"],
    "personal-assistant": ["Software Engineer", "Backend Engineer"],
    "cryptography": ["Cryptographer", "Security Engineer"],
}

# Knowledge domain to supporting persona mapping
KNOWLEDGE_DOMAIN_SUPPORT = {
    "Docker": "DevOps Engineer",
    "Kubernetes": "DevOps Engineer",
    "PyTorch": "ML Engineer",
    "TensorFlow": "ML Engineer",
    "SQL": "Database Administrator",
    "Cryptography": "Cryptographer",
    "Linux": "System Administrator",
    "QEMU": "System Administrator",
    "HTML/CSS": "Frontend Engineer",
    "JavaScript": "Web Developer",
    "C/C++": "Compiler Engineer",
    "Bioinformatics": "Bioinformatics Scientist",
    "Financial": "Financial Engineer",
    "Computer Vision": "ML Engineer",
    "NLP": "ML Engineer",
    "Reinforcement Learning": "ML Engineer",
    "Game Development": "Game Developer",
    "Networking": "Network Engineer",
    "Security": "Security Engineer",
    "Git": "DevOps Engineer",
    "ETL": "Data Engineer",
    "Data Analysis": "Data Scientist",
    "HTTP/REST": "Backend Engineer",
    "Web Scraping": "Web Developer",
    "Compiler Design": "Compiler Engineer",
    "HuggingFace": "ML Engineer",
    "Scikit-learn": "Data Scientist",
    "Shell/Bash": "System Administrator",
    "R": "Data Scientist",
    "Go": "Backend Engineer",
    "Rust": "Software Engineer",
    "Graph Algorithms": "Software Engineer",
    "Dynamic Programming": "Software Engineer",
    "Search Algorithms": "Software Engineer",
    "Sorting": "Software Engineer",
    "Regular Expressions": "Software Engineer",
    "Jupyter": "Data Scientist",
}

# Tag-based persona enhancement
TAG_PERSONA_MAP = {
    "pytorch": "ML Engineer",
    "tensorflow": "ML Engineer",
    "keras": "ML Engineer",
    "ml": "ML Engineer",
    "machine-learning": "ML Engineer",
    "deep-learning": "ML Engineer",
    "neural-network": "ML Engineer",
    "security": "Security Engineer",
    "cryptography": "Cryptographer",
    "encryption": "Cryptographer",
    "docker": "DevOps Engineer",
    "kubernetes": "DevOps Engineer",
    "devops": "DevOps Engineer",
    "ci/cd": "DevOps Engineer",
    "database": "Database Administrator",
    "sql": "Database Administrator",
    "frontend": "Frontend Engineer",
    "backend": "Backend Engineer",
    "web": "Web Developer",
    "api": "Backend Engineer",
    "rest": "Backend Engineer",
    "system": "System Administrator",
    "sys-admin": "System Administrator",
    "linux": "System Administrator",
    "kernel": "System Administrator",
    "network": "Network Engineer",
    "networking": "Network Engineer",
    "game": "Game Developer",
    "games": "Game Developer",
    "maze": "Game Developer",
    "puzzle": "Game Developer",
    "chess": "Game Developer",
    "compiler": "Compiler Engineer",
    "compilation": "Compiler Engineer",
    "build-tools": "DevOps Engineer",
    "data": "Data Scientist",
    "data-science": "Data Scientist",
    "data-processing": "Data Engineer",
    "etl": "Data Engineer",
    "statistics": "Data Scientist",
    "research": "Research Scientist",
    "algorithm": "Software Engineer",
    "algorithms": "Software Engineer",
    "debugging": "QA Engineer",
    "testing": "QA Engineer",
    "test": "QA Engineer",
    "biology": "Bioinformatics Scientist",
    "bioinformatics": "Bioinformatics Scientist",
    "dna": "Bioinformatics Scientist",
    "financial": "Financial Engineer",
    "trading": "Financial Engineer",
    "rl": "ML Engineer",
    "reinforcement-learning": "ML Engineer",
}

# Instruction keyword patterns for specialized personas
INSTRUCTION_PATTERNS = {
    "Cryptographer": [
        r"cryptanalysis", r"cipher", r"decrypt", r"encrypt", r"\bfeal\b", r"\baes\b",
        r"\brsa\b", r"cryptographic", r"chosen\s+plaintext", r"linear\s+cryptanalysis",
        r"differential\s+cryptanalysis"
    ],
    "Bioinformatics Scientist": [
        r"\bdna\b", r"\bprotein\b", r"plasmid", r"genome", r"sequence\s+assembly",
        r"bioinformatics", r"molecular", r"primers", r"fasta"
    ],
    "Financial Engineer": [
        r"bank\s+transaction", r"portfolio", r"trading", r"financial\s+document",
        r"invoice", r"derivative", r"stock\s+market"
    ],
    "Game Developer": [
        r"\bchess\b", r"\bmaze\b", r"\bpuzzle\b", r"\bzork\b", r"game\s+board",
        r"winning\s+hand", r"mahjong", r"sudoku", r"cartpole", r"gym\s+environment"
    ],
    "Compiler Engineer": [
        r"\bllvm\b", r"\bcompiler\b", r"compcert", r"gcc", r"clang", r"\btcc\b",
        r"assembly", r"bytecode", r"object\s+file", r"linker"
    ],
    "Embedded Systems Engineer": [
        r"embedded", r"firmware", r"microcontroller", r"arduino", r"raspberry",
        r"gpio", r"hardware\s+interface"
    ],
    "Research Scientist": [
        r"research\s+paper", r"theorem", r"proof", r"eigenvalue", r"eigenvector",
        r"mathematical\s+model", r"optimization\s+algorithm", r"bayesian",
        r"adaptive\s+rejection\s+sampl", r"causal\s+inference"
    ],
    "ML Engineer": [
        r"neural\s+network", r"training\s+loop", r"model\s+training", r"fine-tun",
        r"transformer", r"attention\s+mechanism", r"\bbert\b", r"\bgpt\b", r"lora", r"adapter",
        r"hyperparameter", r"batch\s+size", r"learning\s+rate", r"pytorch", r"tensorflow",
        r"deep\s+learning", r"convolutional", r"recurrent"
    ],
    "Data Scientist": [
        r"pandas", r"dataframe", r"data\s+analysis", r"exploratory", r"visualization",
        r"correlation", r"regression", r"classification", r"clustering", r"jupyter"
    ],
    "DevOps Engineer": [
        r"docker", r"kubernetes", r"container", r"deploy", r"ci/cd", r"pipeline",
        r"infrastructure", r"orchestrat", r"nginx", r"apache"
    ],
    "System Administrator": [
        r"initramfs", r"qemu", r"kernel\s+build", r"systemd", r"cron", r"permissions",
        r"acl", r"user\s+group", r"firewall", r"iptables", r"networking\s+broken"
    ],
    "Security Engineer": [
        r"vulnerability", r"exploit", r"penetration", r"injection", r"\bxss\b",
        r"sql\s+injection", r"rce", r"remote\s+code", r"cve-", r"vulhub"
    ],
    "Database Administrator": [
        r"database\s+schema", r"sql\s+query", r"index", r"migration", r"sqlite",
        r"postgres", r"mysql", r"wal\s+recovery", r"transaction"
    ],
    "Network Engineer": [
        r"tcp/ip", r"packet", r"pcap", r"socket", r"port\s+\d+", r"protocol",
        r"routing", r"dns", r"dhcp"
    ],
    "Web Developer": [
        r"scraper", r"crawler", r"http\s+request", r"web\s+page", r"beautifulsoup",
        r"selenium", r"html\s+file", r"javascript\s+file"
    ],
    "Frontend Engineer": [
        r"react", r"vue", r"angular", r"dom", r"user\s+interface", r"ui\s+component",
        r"responsive", r"css\s+style"
    ],
    "Backend Engineer": [
        r"rest\s+api", r"endpoint", r"microservice", r"server\s+on\s+port",
        r"handler", r"controller", r"middleware"
    ],
}


def score_persona_match(instruction: str, persona: str) -> float:
    """Score how well a persona matches an instruction based on keyword patterns."""
    if persona not in INSTRUCTION_PATTERNS:
        return 0.0
    
    instruction_lower = instruction.lower()
    score = 0.0
    patterns = INSTRUCTION_PATTERNS[persona]
    
    for pattern in patterns:
        if re.search(pattern, instruction_lower, re.IGNORECASE):
            score += 1.0
    
    return score


def get_primary_personas(category: str, instruction: str, tags: List[str]) -> List[str]:
    """Determine primary personas based on category and instruction analysis."""
    primaries = []
    
    # Start with category-based primaries (these are the anchor)
    if category in CATEGORY_PRIMARY_MAP:
        primaries.extend(CATEGORY_PRIMARY_MAP[category])
    else:
        primaries.append("Software Engineer")
    
    # Score specialized personas based on instruction content
    persona_scores = {}
    for persona in INSTRUCTION_PATTERNS.keys():
        score = score_persona_match(instruction, persona)
        if score > 0:
            persona_scores[persona] = score
    
    # Only replace/insert specialized personas if they score VERY high (2+)
    # and are NOT already covered by category primaries
    if persona_scores:
        sorted_personas = sorted(persona_scores.items(), key=lambda x: x[1], reverse=True)
        for persona, score in sorted_personas[:2]:
            # High threshold: only insert if score >= 2 (multiple pattern matches)
            # AND the persona provides specialized expertise not in category
            if score >= 2.0 and persona not in primaries:
                # Don't let ML Engineer override Game Developer for game tasks
                if category == "games" and persona == "ML Engineer":
                    continue
                # Don't let generic personas override specialized ones
                if persona in ["Software Engineer", "Backend Engineer"]:
                    continue
                primaries.insert(0, persona)
    
    # Limit to 2 primaries
    return primaries[:2]


def get_supporting_personas(
    knowledge_domains: List[str],
    tags: List[str],
    primaries: List[str]
) -> List[str]:
    """Determine supporting personas based on knowledge domains and tags."""
    supports = []
    
    # Add from knowledge domains
    for domain in knowledge_domains:
        if domain in KNOWLEDGE_DOMAIN_SUPPORT:
            persona = KNOWLEDGE_DOMAIN_SUPPORT[domain]
            if persona not in primaries and persona not in supports:
                supports.append(persona)
    
    # Add from tags
    for tag in tags:
        tag_lower = tag.lower()
        if tag_lower in TAG_PERSONA_MAP:
            persona = TAG_PERSONA_MAP[tag_lower]
            if persona not in primaries and persona not in supports:
                supports.append(persona)
    
    # Limit supports to 3
    return supports[:3]


def dedupe_and_prioritize(personas: List[str]) -> List[str]:
    """Remove duplicates while preserving order (first occurrence wins)."""
    seen = set()
    result = []
    for p in personas:
        if p not in seen:
            seen.add(p)
            result.append(p)
    return result


def remove_overlaps(personas: List[str], task_info: dict) -> List[str]:
    """Remove personas that significantly overlap for this task type."""
    category = task_info.get('category', '')
    instruction = task_info.get('instruction', '')
    
    # Define overlap rules
    overlaps = {
        # If we have both, keep the more specialized one
        ("Software Engineer", "Backend Engineer"): lambda: "Backend Engineer" if "api" in instruction.lower() or "server" in instruction.lower() else "Software Engineer",
        ("Web Developer", "Frontend Engineer"): lambda: "Frontend Engineer" if "react" in instruction.lower() or "vue" in instruction.lower() else "Web Developer",
        ("Data Scientist", "ML Engineer"): lambda: "ML Engineer" if "training" in instruction.lower() or "neural" in instruction.lower() else "Data Scientist",
    }
    
    result = list(personas)
    
    for (p1, p2), picker in overlaps.items():
        if p1 in result and p2 in result:
            keep = picker()
            remove = p2 if keep == p1 else p1
            result.remove(remove)
    
    return result


def refine_task_personas(task_info: dict) -> dict:
    """Refine personas for a single task."""
    instruction = task_info.get('instruction', '')
    category = task_info.get('category', '')
    tags = task_info.get('tags', [])
    knowledge_domains = task_info.get('knowledge_domains', [])
    
    # Step 1: Get primary personas
    primaries = get_primary_personas(category, instruction, tags)
    
    # Step 2: Get supporting personas
    supports = get_supporting_personas(knowledge_domains, tags, primaries)
    
    # Step 3: Combine and dedupe
    all_personas = primaries + supports
    all_personas = dedupe_and_prioritize(all_personas)
    
    # Step 4: Remove overlaps
    all_personas = remove_overlaps(all_personas, task_info)
    
    # Step 5: Cap at 5
    final_team = all_personas[:5]
    
    # Ensure at least Software Engineer if empty
    if not final_team:
        final_team = ["Software Engineer"]
    
    return {
        'lead_persona': final_team[0],
        'team': final_team,
        'team_size': len(final_team)
    }


def load_yaml_data(filepath: Path) -> dict:
    """Load the YAML data file."""
    with open(filepath, 'r') as f:
        return yaml.safe_load(f)


def refine_all_tasks(data: dict) -> dict:
    """Refine personas for all tasks."""
    task_results = data.get('task_results', {})
    refined_results = {}
    
    stats = {
        'total_tasks': 0,
        'avg_original_personas': 0,
        'avg_refined_personas': 0,
        'persona_distribution': defaultdict(int),
        'lead_persona_distribution': defaultdict(int),
    }
    
    total_original = 0
    total_refined = 0
    
    for task_id, task_info in task_results.items():
        original_personas = task_info.get('personas', [])
        
        # Refine the personas
        refined = refine_task_personas(task_info)
        
        refined_results[task_id] = {
            'instruction': task_info.get('instruction', ''),
            'category': task_info.get('category', ''),
            'tags': task_info.get('tags', []),
            'knowledge_domains': task_info.get('knowledge_domains', []),
            'lead_persona': refined['lead_persona'],
            'personas': refined['team'],
            'original_personas': original_personas,
        }
        
        # Update stats
        stats['total_tasks'] += 1
        total_original += len(original_personas)
        total_refined += len(refined['team'])
        
        for p in refined['team']:
            stats['persona_distribution'][p] += 1
        stats['lead_persona_distribution'][refined['lead_persona']] += 1
    
    stats['avg_original_personas'] = round(total_original / stats['total_tasks'], 2) if stats['total_tasks'] > 0 else 0
    stats['avg_refined_personas'] = round(total_refined / stats['total_tasks'], 2) if stats['total_tasks'] > 0 else 0
    stats['persona_distribution'] = dict(sorted(stats['persona_distribution'].items(), key=lambda x: x[1], reverse=True))
    stats['lead_persona_distribution'] = dict(sorted(stats['lead_persona_distribution'].items(), key=lambda x: x[1], reverse=True))
    
    return {
        'summary': {
            'total_tasks': stats['total_tasks'],
            'avg_original_personas': stats['avg_original_personas'],
            'avg_refined_personas': stats['avg_refined_personas'],
            'persona_distribution': stats['persona_distribution'],
            'lead_persona_distribution': stats['lead_persona_distribution'],
        },
        'task_results': refined_results,
    }


def main():
    # Input file
    input_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.yaml")
    
    if not input_file.exists():
        print(f"Error: Input file not found: {input_file}")
        return
    
    print(f"Loading data from {input_file}...")
    data = load_yaml_data(input_file)
    
    print("Refining personas for all tasks...")
    refined_data = refine_all_tasks(data)
    
    # Save refined YAML
    output_yaml = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-refined.yaml")
    with open(output_yaml, 'w') as f:
        yaml.dump(refined_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    
    # Save refined JSON for easier programmatic access
    output_json = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-refined.json")
    with open(output_json, 'w') as f:
        json.dump(refined_data, f, indent=2)
    
    print(f"\nRefinement complete!")
    print(f"Output YAML: {output_yaml}")
    print(f"Output JSON: {output_json}")
    print(f"\n--- Summary ---")
    print(f"Total tasks: {refined_data['summary']['total_tasks']}")
    print(f"Avg original personas per task: {refined_data['summary']['avg_original_personas']}")
    print(f"Avg refined personas per task: {refined_data['summary']['avg_refined_personas']}")
    print(f"\nLead persona distribution:")
    for persona, count in list(refined_data['summary']['lead_persona_distribution'].items())[:10]:
        print(f"  {persona}: {count}")
    print(f"\nOverall persona distribution:")
    for persona, count in list(refined_data['summary']['persona_distribution'].items())[:10]:
        print(f"  {persona}: {count}")


if __name__ == "__main__":
    main()
