# Terminal-Bench Persona Analysis: Sub-Categories & Knowledge Domains

Total Tasks Analyzed: 241
Total Personas Identified: 20

## Persona Breakdown by Sub-Category

### Backend Engineer

**Total Tasks:** 105

#### API Development

**Task Count:** 48

**Knowledge Domains Required:**
- HTTP/REST
- JavaScript
- Python
- SQL

**Skills Required:**
- Authentication
- Error handling
- RESTful APIs

**Tasks in this sub-category:**
- `analyze-access-logs`
- `ancient-puzzle`
- `attention-mil`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-pmars`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `configure-git-webserver`
- `debug-long-program`
- `enemy-grid-escape`
- `fibonacci-server`
- `fix-code-vulnerability`
- `fix-pandas-version`
- ... and 33 more

#### General

**Task Count:** 13

**Knowledge Domains Required:**
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- ETL
- Financial
- Game Development
- Git
- HTML/CSS
- Linux
- NLP
- Networking
- QEMU
- R
- Scikit-learn
- Security
- Shell/Bash
- Sorting

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `adaptive-rejection-sampler`
- `count-call-stack`
- `decommissioning-service-with-sensitive-data`
- `find-restaurant`
- `flood-monitoring-basic`
- `install-windows-3.11`
- `log-summary`
- `mlflow-register`
- `movie-helper`
- `predict-customer-churn`
- `qemu-alpine-ssh`
- `security-vulhub-minio`
- `tree-directory-parser`

#### Microservices

**Task Count:** 44

**Knowledge Domains Required:**
- Docker
- HTTP/REST

**Skills Required:**
- Inter-service communication
- Scalability
- Service architecture

**Tasks in this sub-category:**
- `analyze-access-logs`
- `ancient-puzzle`
- `attention-mil`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-pmars`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `configure-git-webserver`
- `debug-long-program`
- `enemy-grid-escape`
- `fibonacci-server`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- ... and 29 more

---

### Bioinformatics Scientist

**Total Tasks:** 13

#### Sequence Analysis

**Task Count:** 13

**Knowledge Domains Required:**
- Bioinformatics
- Data Analysis
- Python

**Skills Required:**
- Biological data processing
- Genomic analysis
- Sequence alignment

**Tasks in this sub-category:**
- `chem-property-targeting`
- `chem-rf`
- `cross-entropy-method`
- `dna-assembly`
- `dna-insert`
- `get-bitcoin-nodes`
- `gomoku-planner`
- `llm-spec-decoding`
- `parallelize-graph`
- `port-compressor`
- `processing-pipeline`
- `protein-assembly`
- `wasm-pipeline`

---

### Compiler Engineer

**Total Tasks:** 86

#### Build Systems

**Task Count:** 24

**Knowledge Domains Required:**
- Build Systems
- C/C++

**Skills Required:**
- Build configuration
- Cross-compilation
- Dependency management

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `add-benchmark-lm-eval-harness`
- `circuit-fibsqrt`
- `compile-compcert`
- `count-call-stack`
- `custom-memory-heap-crash`
- `deterministic-tarball`
- `extract-elf`
- `fix-ocaml-gc`
- `gcc-compiler-optimization`
- `gpt2-codegolf`
- `install-klee-minimal`
- `magsac-install`
- `make-doom-for-mips`
- `modernize-fortran-build`
- ... and 9 more

#### Compiler Design

**Task Count:** 22

**Knowledge Domains Required:**
- Compiler Design

**Skills Required:**
- Code generation
- Lexical analysis
- Parsing

**Tasks in this sub-category:**
- `compile-compcert`
- `count-call-stack`
- `custom-memory-heap-crash`
- `dna-assembly`
- `enemy-grid-escape`
- `fix-ocaml-gc`
- `gcc-compiler-optimization`
- `gpt2-codegolf`
- `incompatible-python-fasttext`
- `install-klee-minimal`
- `make-mips-interpreter`
- `modernize-fortran-build`
- `overfull-hbox`
- `parallelize-graph`
- `path-tracing`
- ... and 7 more

#### General

**Task Count:** 40

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Computer Vision
- Cryptography
- Data Analysis
- ETL
- Financial
- Game Development
- Git
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- JavaScript
- Linux
- NLP
- Networking
- PyTorch
- Python
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Scikit-learn
- Search Algorithms
- Security
- Shell/Bash
- Sorting
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `assign-seats`
- `audio-synth-stft-peaks`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-cython-ext`
- `build-linux-kernel-qemu`
- `build-pmars`
- `build-pov-ray`
- `build-stp`
- `build-tcc-qemu`
- `caffe-cifar-10`
- `chem-property-targeting`
- `chem-rf`
- `cobol-modernization`
- `cprofiling-python`
- ... and 25 more

---

### Cryptographer

**Total Tasks:** 71

#### Cryptanalysis

**Task Count:** 33

**Knowledge Domains Required:**
- Cryptography
- Security

**Skills Required:**
- Attack techniques
- Security research
- Vulnerability analysis

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `adaptive-rejection-sampler`
- `cprofiling-python`
- `cross-entropy-method`
- `custom-memory-heap-crash`
- `decommissioning-service-with-sensitive-data`
- `deterministic-tarball`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `grid-pattern-transform`
- `lean4-proof`
- `llm-inference-batching-scheduler`
- `mnist-learning-fix`
- ... and 18 more

#### Cryptographic Algorithms

**Task Count:** 30

**Knowledge Domains Required:**
- Cryptography

**Skills Required:**
- Algorithm implementation
- Cryptographic protocols
- Security analysis

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `adaptive-rejection-sampler`
- `cprofiling-python`
- `cross-entropy-method`
- `custom-memory-heap-crash`
- `decommissioning-service-with-sensitive-data`
- `deterministic-tarball`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `fix-code-vulnerability`
- `grid-pattern-transform`
- `lean4-proof`
- `llm-inference-batching-scheduler`
- `mnist-learning-fix`
- `model-extraction-relu-logits`
- ... and 15 more

#### General

**Task Count:** 8

**Knowledge Domains Required:**
- Bioinformatics
- Compiler Design
- Computer Vision
- Data Analysis
- ETL
- HTML/CSS
- HTTP/REST
- HuggingFace
- NLP
- Networking
- PyTorch
- Python
- R
- SQL
- Scikit-learn
- Shell/Bash

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `attention-mil`
- `audio-synth-stft-peaks`
- `dna-assembly`
- `flood-monitoring-basic`
- `mlflow-register`
- `rare-mineral-allocation`
- `swe-bench-astropy-1`
- `vertex-solver`

---

### Data Engineer

**Total Tasks:** 58

#### Big Data

**Task Count:** 2

**Knowledge Domains Required:**
- Big Data

**Skills Required:**
- Cluster management
- Data processing
- Distributed computing

**Tasks in this sub-category:**
- `hdfs-deployment`
- `predicate-pushdown-bench`

#### ETL Pipelines

**Task Count:** 37

**Knowledge Domains Required:**
- ETL
- Python

**Skills Required:**
- Data transformation
- Pipeline design
- Workflow automation

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `audio-synth-stft-peaks`
- `blind-maze-explorer-algorithm`
- `chem-property-targeting`
- `classifier-debug`
- `conda-env-conflict-resolution`
- `deterministic-tarball`
- `fix-pandas-version`
- `fmri-encoding-r`
- `get-bitcoin-nodes`
- `git-workflow-hack`
- `grid-pattern-transform`
- `hf-model-inference`
- `hydra-debug-slurm-mode`
- `jq-data-processing`
- ... and 22 more

#### General

**Task Count:** 19

**Knowledge Domains Required:**
- C/C++
- Computer Vision
- Data Analysis
- Docker
- Financial
- Game Development
- Git
- HTML/CSS
- HTTP/REST
- HuggingFace
- JavaScript
- NLP
- Networking
- R
- Regular Expressions
- SQL
- Security
- Shell/Bash
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `analyze-access-logs`
- `ancient-puzzle`
- `blind-maze-explorer-5x5`
- `count-dataset-tokens`
- `csv-to-parquet`
- `flood-monitoring-basic`
- `heterogeneous-dates`
- `html-finance-verify`
- `jsonl-aggregator`
- `log-summary-date-ranges`
- `mahjong-winninghand`
- `movie-helper`
- `mteb-eval`
- `mteb-retrieve`
- `multi-source-data-merger`
- ... and 4 more

---

### Data Scientist

**Total Tasks:** 409

#### Data Analysis

**Task Count:** 84

**Knowledge Domains Required:**
- Data Analysis
- Python

**Skills Required:**
- Data cleaning
- Exploratory data analysis
- Statistical analysis

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `attention-mil`
- `audio-synth-stft-peaks`
- `bank-trans-filter`
- `bn-fit-modify`
- `build-cython-ext`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `cobol-modernization`
- `conda-env-conflict-resolution`
- ... and 69 more

#### Data Visualization

**Task Count:** 68

**Knowledge Domains Required:**
- Python

**Skills Required:**
- Chart creation
- Dashboard design
- Data visualization

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `attention-mil`
- `audio-synth-stft-peaks`
- `build-cython-ext`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `cobol-modernization`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `deterministic-tarball`
- ... and 53 more

#### General

**Task Count:** 44

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Docker
- ETL
- Financial
- Game Development
- Git
- Go
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- HuggingFace
- NLP
- Networking
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Search Algorithms
- Security
- Shell/Bash
- Sorting
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `analyze-access-logs`
- `ancient-puzzle`
- `build-pov-ray`
- `caffe-cifar-10`
- `configure-git-webserver`
- `count-dataset-tokens`
- `db-wal-recovery`
- `decommissioning-service-with-sensitive-data`
- `fix-permissions`
- `gpt2-codegolf`
- `hdfs-deployment`
- `hf-lora-adapter`
- `html-finance-verify`
- `intrusion-detection`
- ... and 29 more

#### Machine Learning

**Task Count:** 71

**Knowledge Domains Required:**
- PyTorch
- Python
- Scikit-learn
- TensorFlow

**Skills Required:**
- Feature engineering
- Model evaluation
- Model training

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `attention-mil`
- `audio-synth-stft-peaks`
- `build-cython-ext`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `cobol-modernization`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `deterministic-tarball`
- ... and 56 more

#### Research & Experimentation

**Task Count:** 68

**Knowledge Domains Required:**
- Jupyter
- Python

**Skills Required:**
- A/B testing
- Experimental design
- Research methodology

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `attention-mil`
- `audio-synth-stft-peaks`
- `build-cython-ext`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `cobol-modernization`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `deterministic-tarball`
- ... and 53 more

#### Statistical Analysis

**Task Count:** 74

**Knowledge Domains Required:**
- Python
- R

**Skills Required:**
- Data interpretation
- Hypothesis testing
- Statistical modeling

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `attention-mil`
- `audio-synth-stft-peaks`
- `build-cython-ext`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `cobol-modernization`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- ... and 59 more

---

### Database Administrator

**Total Tasks:** 94

#### Database Optimization

**Task Count:** 29

**Knowledge Domains Required:**
- SQL

**Skills Required:**
- Index optimization
- Performance tuning
- Query analysis

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `audio-synth-stft-peaks`
- `chem-property-targeting`
- `db-wal-recovery`
- `fibonacci-server`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `hf-model-inference`
- `hf-train-lora-adapter`
- `intrusion-detection`
- `jq-data-processing`
- `model-extraction-relu-logits`
- `mteb-retrieve`
- `multi-source-data-merger`
- `optimal-transport`
- ... and 14 more

#### General

**Task Count:** 36

**Knowledge Domains Required:**
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- Docker
- Dynamic Programming
- ETL
- Financial
- Game Development
- Git
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- JavaScript
- Jupyter
- Linux
- Networking
- PyTorch
- Python
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Scikit-learn
- Search Algorithms
- Security
- Shell/Bash
- Sorting
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `adaptive-rejection-sampler`
- `ancient-puzzle`
- `assign-seats`
- `bank-trans-filter`
- `cancel-async-tasks`
- `causal-inference-r`
- `cobol-modernization`
- `cprofiling-python`
- `deterministic-tarball`
- `filter-js-from-html`
- `fix-pandas-version`
- `gcc-compiler-optimization`
- `git-multibranch`
- `home-server-https`
- ... and 21 more

#### SQL Databases

**Task Count:** 29

**Knowledge Domains Required:**
- SQL

**Skills Required:**
- Database design
- Query optimization
- Schema management

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `audio-synth-stft-peaks`
- `chem-property-targeting`
- `db-wal-recovery`
- `fibonacci-server`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `hf-model-inference`
- `hf-train-lora-adapter`
- `intrusion-detection`
- `jq-data-processing`
- `model-extraction-relu-logits`
- `mteb-retrieve`
- `multi-source-data-merger`
- `optimal-transport`
- ... and 14 more

---

### DevOps Engineer

**Total Tasks:** 107

#### Build & Deployment

**Task Count:** 10

**Knowledge Domains Required:**
- Build Systems
- Docker

**Skills Required:**
- Build automation
- Release management
- Version control

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `ancient-puzzle`
- `magsac-install`
- `modernize-fortran-build`
- `parallel-particle-simulator`
- `parallelize-graph`
- `postgres-csv-clean`
- `security-celery-redis-rce`
- `stable-parallel-kmeans`
- `unprivileged-headless-pyrender`

#### Containerization

**Task Count:** 6

**Knowledge Domains Required:**
- Docker

**Skills Required:**
- Container management
- Orchestration
- Service deployment

**Tasks in this sub-category:**
- `ancient-puzzle`
- `magsac-install`
- `postgres-csv-clean`
- `security-celery-redis-rce`
- `stable-parallel-kmeans`
- `unprivileged-headless-pyrender`

#### General

**Task Count:** 27

**Knowledge Domains Required:**
- Big Data
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- ETL
- Financial
- Game Development
- Git
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- JavaScript
- NLP
- Python
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- SQL
- Scikit-learn
- Shell/Bash
- Sorting

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `build-pov-ray`
- `build-stp`
- `compile-compcert`
- `configure-git-webserver`
- `count-call-stack`
- `cron-broken-network`
- `custom-memory-heap-crash`
- `db-wal-recovery`
- `extract-elf`
- `fibonacci-server`
- `fix-ocaml-gc`
- `gpt2-codegolf`
- `hdfs-deployment`
- `install-klee-minimal`
- ... and 12 more

#### Infrastructure Management

**Task Count:** 64

**Knowledge Domains Required:**
- Linux
- Networking
- Security

**Skills Required:**
- Configuration management
- Infrastructure provisioning
- Monitoring

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `analyze-access-logs`
- `audio-synth-stft-peaks`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `broken-networking`
- `build-cython-ext`
- `build-initramfs-qemu`
- `build-linux-kernel-qemu`
- `build-pmars`
- `build-tcc-qemu`
- `caffe-cifar-10`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `chem-rf`
- ... and 49 more

---

### Embedded Systems Engineer

**Total Tasks:** 6

#### General

**Task Count:** 6

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Cryptography
- Data Analysis
- Dynamic Programming
- ETL
- Graph Algorithms
- HTTP/REST
- HuggingFace
- NLP
- Networking
- PyTorch
- Python
- R
- Regular Expressions
- SQL
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `llm-inference-batching-scheduler`
- `llm-spec-decoding`
- `predicate-pushdown-bench`
- `predict-customer-churn`
- `torch-pipeline-parallelism`

---

### Financial Engineer

**Total Tasks:** 23

#### Financial Modeling

**Task Count:** 21

**Knowledge Domains Required:**
- Financial
- Python

**Skills Required:**
- Financial analysis
- Portfolio optimization
- Risk modeling

**Tasks in this sub-category:**
- `cobol-modernization`
- `constraints-scheduling`
- `count-call-stack`
- `fix-pandas-version`
- `get-bitcoin-nodes`
- `hf-train-lora-adapter`
- `html-finance-verify`
- `ilp-solver`
- `jq-data-processing`
- `large-scale-text-editing`
- `lean4-proof`
- `multi-source-data-merger`
- `openssl-selfsigned-cert`
- `optimal-transport`
- `parallel-particle-simulator`
- ... and 6 more

#### General

**Task Count:** 2

**Knowledge Domains Required:**
- Data Analysis
- HTTP/REST
- Networking
- Regular Expressions
- Security
- Sorting

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `bank-trans-filter`
- `solana-data`

---

### Frontend Engineer

**Total Tasks:** 108

#### General

**Task Count:** 77

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- Go
- Graph Algorithms
- HTTP/REST
- HuggingFace
- Jupyter
- Linux
- NLP
- Networking
- PyTorch
- Python
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Scikit-learn
- Search Algorithms
- Security
- Shell/Bash
- Sorting
- TensorFlow
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `acl-permissions-inheritance`
- `add-benchmark-lm-eval-harness`
- `amuse-install`
- `attention-mil`
- `audio-synth-stft-peaks`
- `build-initramfs-qemu`
- `build-linux-kernel-qemu`
- `build-pmars`
- `build-pov-ray`
- `build-stp`
- `caffe-cifar-10`
- `causal-inference-r`
- `chem-property-targeting`
- `chem-rf`
- ... and 62 more

#### UI Development

**Task Count:** 31

**Knowledge Domains Required:**
- HTML/CSS
- JavaScript

**Skills Required:**
- Component development
- State management
- User interaction

**Tasks in this sub-category:**
- `adaptive-rejection-sampler`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `build-cython-ext`
- `configure-git-webserver`
- `count-dataset-tokens`
- `deterministic-tarball`
- `filter-js-from-html`
- `fix-code-vulnerability`
- `fmri-encoding-r`
- `git-multibranch`
- `hf-lora-adapter`
- `home-server-https`
- `html-finance-verify`
- ... and 16 more

---

### Game Developer

**Total Tasks:** 46

#### AI for Games

**Task Count:** 16

**Knowledge Domains Required:**
- Game Development
- Reinforcement Learning

**Skills Required:**
- AI agents
- Decision making
- Game AI

**Tasks in this sub-category:**
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `cartpole-rl-training`
- `chess-best-move`
- `cross-entropy-method`
- `enemy-grid-escape`
- `huarong-dao-solver`
- `interactive-maze-game`
- `leelachess0-pytorch-conversion`
- `play-lord`
- `play-zork`
- `play-zork-easy`
- `puzzle-solver`
- `regex-chess`
- `solve-maze-challenge`
- ... and 1 more

#### Game Logic

**Task Count:** 14

**Knowledge Domains Required:**
- Game Development

**Skills Required:**
- Game mechanics
- Rule implementation
- State management

**Tasks in this sub-category:**
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `chess-best-move`
- `enemy-grid-escape`
- `huarong-dao-solver`
- `interactive-maze-game`
- `leelachess0-pytorch-conversion`
- `play-lord`
- `play-zork`
- `play-zork-easy`
- `puzzle-solver`
- `regex-chess`
- `solve-maze-challenge`
- `solve-sudoku`

#### General

**Task Count:** 2

**Knowledge Domains Required:**
- Cryptography
- HTTP/REST
- Networking
- Security

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `mahjong-winninghand`
- `sha-puzzle`

#### Puzzle Solving

**Task Count:** 14

**Knowledge Domains Required:**
- Game Development

**Skills Required:**
- Algorithm design
- Optimization
- Problem solving

**Tasks in this sub-category:**
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `chess-best-move`
- `enemy-grid-escape`
- `huarong-dao-solver`
- `interactive-maze-game`
- `leelachess0-pytorch-conversion`
- `play-lord`
- `play-zork`
- `play-zork-easy`
- `puzzle-solver`
- `regex-chess`
- `solve-maze-challenge`
- `solve-sudoku`

---

### ML Engineer

**Total Tasks:** 120

#### General

**Task Count:** 18

**Knowledge Domains Required:**
- Big Data
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- ETL
- Game Development
- Git
- Go
- HTML/CSS
- HTTP/REST
- JavaScript
- NLP
- Networking
- R
- SQL
- Scikit-learn
- Shell/Bash

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `caffe-cifar-10`
- `custom-memory-heap-crash`
- `fmri-encoding-r`
- `gcc-compiler-optimization`
- `gpt2-codegolf`
- `hf-lora-adapter`
- `mcmc-sampling-stan`
- `mlflow-register`
- `mteb-leaderboard`
- `mteb-retrieve`
- `predicate-pushdown-bench`
- `predict-customer-churn`
- ... and 3 more

#### ML Infrastructure

**Task Count:** 2

**Knowledge Domains Required:**
- Docker

**Skills Required:**
- Infrastructure management
- MLOps
- Pipeline automation

**Tasks in this sub-category:**
- `stable-parallel-kmeans`
- `unprivileged-headless-pyrender`

#### Model Deployment

**Task Count:** 35

**Knowledge Domains Required:**
- Docker
- Python

**Skills Required:**
- API development
- Containerization
- Model serving

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `attention-mil`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-rf`
- `classifier-debug`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `distribution-search`
- `hf-model-inference`
- `hf-train-lora-adapter`
- `hydra-debug-slurm-mode`
- `leelachess0-pytorch-conversion`
- `llm-inference-batching-scheduler`
- ... and 20 more

#### Model Optimization

**Task Count:** 13

**Knowledge Domains Required:**
- PyTorch
- TensorFlow

**Skills Required:**
- Model compression
- Performance optimization
- Quantization

**Tasks in this sub-category:**
- `attention-mil`
- `cartpole-rl-training`
- `conda-env-conflict-resolution`
- `leelachess0-pytorch-conversion`
- `llm-spec-decoding`
- `ode-solver-rk4`
- `oom`
- `pytorch-model-recovery`
- `sam-cell-seg`
- `torch-pipeline-parallelism`
- `torch-tensor-parallelism`
- `triton-interpret`
- `word2vec-from-scratch`

#### Model Training

**Task Count:** 37

**Knowledge Domains Required:**
- PyTorch
- Python
- TensorFlow

**Skills Required:**
- Deep learning
- Hyperparameter tuning
- Model optimization

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `attention-mil`
- `cartpole-rl-training`
- `causal-inference-r`
- `chem-rf`
- `classifier-debug`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `distribution-search`
- `hf-model-inference`
- `hf-train-lora-adapter`
- `hydra-debug-slurm-mode`
- `leelachess0-pytorch-conversion`
- `llm-inference-batching-scheduler`
- ... and 22 more

#### Transfer Learning

**Task Count:** 15

**Knowledge Domains Required:**
- HuggingFace
- PyTorch
- TensorFlow

**Skills Required:**
- Adapter techniques
- Fine-tuning
- Pre-trained models

**Tasks in this sub-category:**
- `attention-mil`
- `cartpole-rl-training`
- `conda-env-conflict-resolution`
- `count-dataset-tokens`
- `leelachess0-pytorch-conversion`
- `llm-spec-decoding`
- `mteb-eval`
- `ode-solver-rk4`
- `oom`
- `pytorch-model-recovery`
- `sam-cell-seg`
- `torch-pipeline-parallelism`
- `torch-tensor-parallelism`
- `triton-interpret`
- `word2vec-from-scratch`

---

### Network Engineer

**Total Tasks:** 67

#### General

**Task Count:** 25

**Knowledge Domains Required:**
- Bioinformatics
- Build Systems
- C/C++
- Computer Vision
- Cryptography
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- HTML/CSS
- HTTP/REST
- HuggingFace
- Linux
- NLP
- Python
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Search Algorithms
- Security
- Shell/Bash
- Sorting
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `ancient-puzzle`
- `build-pmars`
- `configure-git-webserver`
- `cprofiling-python`
- `extract-moves-from-video`
- `find-official-code`
- `find-restaurant`
- `flood-monitoring-basic`
- `git-multibranch`
- `hf-model-inference`
- `home-server-https`
- `huarong-dao-solver`
- `install-windows-xp`
- ... and 10 more

#### Network Protocols

**Task Count:** 42

**Knowledge Domains Required:**
- Networking

**Skills Required:**
- Network troubleshooting
- Protocol implementation
- Traffic analysis

**Tasks in this sub-category:**
- `attention-mil`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `bn-fit-modify`
- `broken-networking`
- `build-cython-ext`
- `caffe-cifar-10`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `classifier-debug`
- `debug-long-program`
- `enemy-grid-escape`
- `fix-code-vulnerability`
- `form-filling`
- ... and 27 more

---

### QA Engineer

**Total Tasks:** 79

#### General

**Task Count:** 35

**Knowledge Domains Required:**
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- Go
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- HuggingFace
- JavaScript
- Linux
- NLP
- Networking
- NoSQL
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Search Algorithms
- Security
- Shell/Bash
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `acl-permissions-inheritance`
- `adaptive-rejection-sampler`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-pmars`
- `build-pov-ray`
- `caffe-cifar-10`
- `custom-memory-heap-crash`
- `debug-long-program`
- `extract-elf`
- `fmri-encoding-r`
- `gcc-compiler-optimization`
- `hf-lora-adapter`
- `home-server-https`
- ... and 20 more

#### Test Automation

**Task Count:** 44

**Knowledge Domains Required:**
- Python

**Skills Required:**
- Automation scripting
- Test design
- Test frameworks

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `attention-mil`
- `cartpole-rl-training`
- `chem-property-targeting`
- `chem-rf`
- `classifier-debug`
- `conda-env-conflict-resolution`
- `cprofiling-python`
- `cross-entropy-method`
- `fix-code-vulnerability`
- `fix-pandas-version`
- `get-bitcoin-nodes`
- `grid-pattern-transform`
- `hf-train-lora-adapter`
- ... and 29 more

---

### Research Scientist

**Total Tasks:** 38

#### General

**Task Count:** 19

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- ETL
- Financial
- Game Development
- Git
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- JavaScript
- Linux
- NLP
- Networking
- R
- Regular Expressions
- Reinforcement Learning
- SQL
- Search Algorithms
- Security
- Shell/Bash

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-pmars`
- `build-stp`
- `custom-memory-heap-crash`
- `find-official-code`
- `gcc-compiler-optimization`
- `git-workflow-hack`
- `lean4-proof`
- `mahjong-winninghand`
- `movie-helper`
- `parallelize-graph`
- `path-tracing`
- `predicate-pushdown-bench`
- ... and 4 more

#### Mathematical Modeling

**Task Count:** 19

**Knowledge Domains Required:**
- Python

**Skills Required:**
- Mathematical modeling
- Simulation
- Statistical analysis

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `attention-mil`
- `cartpole-rl-training`
- `cross-entropy-method`
- `hydra-debug-slurm-mode`
- `implement-eigenvectors-from-eigenvalues-research-paper`
- `largest-eigenval`
- `llm-spec-decoding`
- `magsac-install`
- `model-extraction-relu-logits`
- `optimal-transport`
- `portfolio-optimization`
- `recover-accuracy-log`
- `spinning-up-rl`
- `stable-parallel-kmeans`
- ... and 4 more

---

### Security Engineer

**Total Tasks:** 146

#### Application Security

**Task Count:** 25

**Knowledge Domains Required:**
- Security

**Skills Required:**
- Secure coding
- Security auditing
- Vulnerability assessment

**Tasks in this sub-category:**
- `cprofiling-python`
- `cross-entropy-method`
- `decommissioning-service-with-sensitive-data`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `git-multibranch`
- `home-server-https`
- `jupyter-notebook-server`
- `large-scale-text-editing`
- `new-encrypt-command`
- `openssl-selfsigned-cert`
- `parallelize-compute-squares`
- `parallelize-graph`
- ... and 10 more

#### Cryptography

**Task Count:** 21

**Knowledge Domains Required:**
- Cryptography

**Skills Required:**
- Cryptographic protocols
- Hash algorithms
- Key management

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `cprofiling-python`
- `cross-entropy-method`
- `custom-memory-heap-crash`
- `decommissioning-service-with-sensitive-data`
- `deterministic-tarball`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `fix-code-vulnerability`
- `model-extraction-relu-logits`
- `new-encrypt-command`
- `openssl-selfsigned-cert`
- `optimal-transport`
- `parallel-particle-simulator`
- `parallelize-compute-squares`
- ... and 6 more

#### General

**Task Count:** 22

**Knowledge Domains Required:**
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Computer Vision
- Data Analysis
- ETL
- Game Development
- Git
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- HuggingFace
- Linux
- Python
- QEMU
- R
- Reinforcement Learning
- Rust
- SQL
- Search Algorithms
- Shell/Bash

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `build-initramfs-qemu`
- `build-linux-kernel-qemu`
- `build-pmars`
- `build-pov-ray`
- `compile-compcert`
- `crack-7z-hash`
- `extract-safely`
- `git-leak-recovery`
- `git-workflow-hack`
- `play-lord`
- `port-compressor`
- `protocol-analysis-rs`
- `qemu-alpine-ssh`
- `rare-mineral-allocation`
- ... and 7 more

#### Network Security

**Task Count:** 53

**Knowledge Domains Required:**
- Networking
- Security

**Skills Required:**
- Intrusion detection
- Network security
- Traffic analysis

**Tasks in this sub-category:**
- `break-filter-js-from-html`
- `build-cython-ext`
- `cartpole-rl-training`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `cprofiling-python`
- `cross-entropy-method`
- `decommissioning-service-with-sensitive-data`
- `deterministic-tarball`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `filter-js-from-html`
- `fix-code-vulnerability`
- `fmri-encoding-r`
- `form-filling`
- ... and 38 more

#### Penetration Testing

**Task Count:** 25

**Knowledge Domains Required:**
- Security

**Skills Required:**
- Exploit development
- Security testing
- Vulnerability scanning

**Tasks in this sub-category:**
- `cprofiling-python`
- `cross-entropy-method`
- `decommissioning-service-with-sensitive-data`
- `feal-differential-cryptanalysis`
- `feal-linear-cryptanalysis`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `git-multibranch`
- `home-server-https`
- `jupyter-notebook-server`
- `large-scale-text-editing`
- `new-encrypt-command`
- `openssl-selfsigned-cert`
- `parallelize-compute-squares`
- `parallelize-graph`
- ... and 10 more

---

### Software Engineer

**Total Tasks:** 613

#### API Development

**Task Count:** 126

**Knowledge Domains Required:**
- HTTP/REST
- JavaScript
- Python
- SQL

**Skills Required:**
- Authentication
- Error handling
- RESTful design

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `amuse-install`
- `ancient-puzzle`
- `attention-mil`
- `audio-synth-stft-peaks`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `broken-python`
- `build-cython-ext`
- `build-pmars`
- `cancel-async-tasks`
- ... and 111 more

#### Algorithm Implementation

**Task Count:** 119

**Knowledge Domains Required:**
- C/C++
- Graph Algorithms
- Python
- Search Algorithms

**Skills Required:**
- Algorithm design
- Complexity analysis
- Data structures

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `accelerate-maximal-square`
- `acl-permissions-inheritance`
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `amuse-install`
- `attention-mil`
- `audio-synth-stft-peaks`
- `bn-fit-modify`
- `break-filter-js-from-html`
- `broken-python`
- `build-cython-ext`
- `build-linux-kernel-qemu`
- `cancel-async-tasks`
- ... and 104 more

#### Backend Development

**Task Count:** 123

**Knowledge Domains Required:**
- Go
- HTTP/REST
- Python
- SQL

**Skills Required:**
- API design
- Database integration
- Server-side logic

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `amuse-install`
- `ancient-puzzle`
- `attention-mil`
- `audio-synth-stft-peaks`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `broken-python`
- `build-cython-ext`
- `build-pmars`
- ... and 108 more

#### General

**Task Count:** 37

**Knowledge Domains Required:**
- Compiler Design
- Computer Vision
- Cryptography
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- NLP
- Networking
- NoSQL
- PyTorch
- QEMU
- R
- Regular Expressions
- Reinforcement Learning
- Security

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `assign-seats`
- `build-pov-ray`
- `caffe-cifar-10`
- `chess-best-move`
- `code-from-image`
- `constraints-scheduling`
- `countdown-game`
- `create-bucket`
- `decommissioning-service-with-sensitive-data`
- `download-youtube`
- `financial-document-processor`
- `fix-git`
- `gcode-to-text`
- `git-leak-recovery`
- `hello-world`
- ... and 22 more

#### Scripting & Automation

**Task Count:** 98

**Knowledge Domains Required:**
- Python
- Shell/Bash

**Skills Required:**
- Process management
- System scripting
- Task automation

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `add-benchmark-lm-eval-harness`
- `aimo-airline-departures`
- `amuse-install`
- `attention-mil`
- `audio-synth-stft-peaks`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `broken-python`
- `build-cython-ext`
- `cancel-async-tasks`
- `cartpole-rl-training`
- `catch-me-if-you-can`
- `causal-inference-r`
- ... and 83 more

#### System Programming

**Task Count:** 41

**Knowledge Domains Required:**
- Build Systems
- C/C++
- Linux
- Rust

**Skills Required:**
- Low-level programming
- Memory management
- System calls

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `acl-permissions-inheritance`
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `bn-fit-modify`
- `build-linux-kernel-qemu`
- `build-pmars`
- `causal-inference-r`
- `classifier-debug`
- `compile-compcert`
- `cpp-compatibility`
- `custom-memory-heap-crash`
- `deterministic-tarball`
- `extract-elf`
- `feal-linear-cryptanalysis`
- ... and 26 more

#### Web Development

**Task Count:** 69

**Knowledge Domains Required:**
- HTML/CSS
- HTTP/REST
- JavaScript
- Web Scraping

**Skills Required:**
- API integration
- DOM manipulation
- Frontend frameworks

**Tasks in this sub-category:**
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `ancient-puzzle`
- `attention-mil`
- `bank-trans-filter`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `build-cython-ext`
- `build-pmars`
- `catch-me-if-you-can`
- `chem-property-targeting`
- `cprofiling-python`
- `debug-long-program`
- `deterministic-tarball`
- ... and 54 more

---

### System Administrator

**Total Tasks:** 141

#### General

**Task Count:** 31

**Knowledge Domains Required:**
- Big Data
- Bioinformatics
- Build Systems
- C/C++
- Compiler Design
- Cryptography
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- Go
- Graph Algorithms
- HTML/CSS
- HTTP/REST
- HuggingFace
- NLP
- PyTorch
- Python
- R
- Regular Expressions
- Reinforcement Learning
- Rust
- SQL
- Search Algorithms
- Sorting
- Web Scraping

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `3d-model-format-legacy`
- `adaptive-rejection-sampler`
- `add-benchmark-lm-eval-harness`
- `ancient-puzzle`
- `cancel-async-tasks`
- `compile-compcert`
- `configure-git-webserver`
- `count-call-stack`
- `create-bucket`
- `cron-broken-network`
- `custom-memory-heap-crash`
- `dna-insert`
- `extract-safely`
- `fix-pandas-version`
- `hdfs-deployment`
- ... and 16 more

#### Linux Administration

**Task Count:** 22

**Knowledge Domains Required:**
- Linux
- Shell/Bash

**Skills Required:**
- Service management
- System configuration
- User management

**Tasks in this sub-category:**
- `acl-permissions-inheritance`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `build-initramfs-qemu`
- `build-linux-kernel-qemu`
- `build-tcc-qemu`
- `causal-inference-r`
- `debug-long-program`
- `deterministic-tarball`
- `fix-permissions`
- `home-server-https`
- `intrusion-detection`
- `jq-data-processing`
- `processing-pipeline`
- `protocol-analysis-rs`
- ... and 7 more

#### Network Configuration

**Task Count:** 64

**Knowledge Domains Required:**
- Networking

**Skills Required:**
- Firewall configuration
- Network setup
- Routing

**Tasks in this sub-category:**
- `accelerate-maximal-square`
- `attention-mil`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `bn-fit-modify`
- `broken-networking`
- `broken-python`
- `build-cython-ext`
- `caffe-cifar-10`
- `catch-me-if-you-can`
- `causal-inference-r`
- `classifier-debug`
- `conda-env-conflict-resolution`
- `cross-entropy-method`
- `debug-long-program`
- ... and 49 more

#### Security Hardening

**Task Count:** 17

**Knowledge Domains Required:**
- Security

**Skills Required:**
- Access control
- Certificate management
- Security configuration

**Tasks in this sub-category:**
- `cross-entropy-method`
- `decommissioning-service-with-sensitive-data`
- `fix-code-vulnerability`
- `get-bitcoin-nodes`
- `git-multibranch`
- `home-server-https`
- `jupyter-notebook-server`
- `large-scale-text-editing`
- `openssl-selfsigned-cert`
- `parallelize-graph`
- `privilege-escalation`
- `puzzle-solver`
- `security-celery-redis-rce`
- `solana-data`
- `sql-injection-attack`
- ... and 2 more

#### Virtualization

**Task Count:** 7

**Knowledge Domains Required:**
- QEMU

**Skills Required:**
- Hypervisor configuration
- Resource allocation
- VM management

**Tasks in this sub-category:**
- `build-initramfs-qemu`
- `build-linux-kernel-qemu`
- `build-tcc-qemu`
- `install-windows-3.11`
- `install-windows-xp`
- `qemu-alpine-ssh`
- `qemu-startup`

---

### Web Developer

**Total Tasks:** 137

#### Backend Development

**Task Count:** 56

**Knowledge Domains Required:**
- HTTP/REST
- JavaScript
- Python

**Skills Required:**
- API development
- Database integration
- Server-side logic

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `analyze-access-logs`
- `ancient-puzzle`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `build-cython-ext`
- `build-pmars`
- `catch-me-if-you-can`
- `configure-git-webserver`
- `cprofiling-python`
- `debug-long-program`
- `deterministic-tarball`
- `enemy-grid-escape`
- `extract-moves-from-video`
- ... and 41 more

#### Frontend Development

**Task Count:** 21

**Knowledge Domains Required:**
- HTML/CSS
- JavaScript

**Skills Required:**
- Browser APIs
- Responsive design
- UI development

**Tasks in this sub-category:**
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `build-cython-ext`
- `configure-git-webserver`
- `deterministic-tarball`
- `filter-js-from-html`
- `fix-code-vulnerability`
- `fmri-encoding-r`
- `git-multibranch`
- `home-server-https`
- `html-finance-verify`
- `leelachess0-pytorch-conversion`
- `mlflow-register`
- `nginx-request-logging`
- ... and 6 more

#### General

**Task Count:** 6

**Knowledge Domains Required:**
- C/C++
- Compiler Design
- Computer Vision
- Data Analysis
- Docker
- ETL
- Financial
- Game Development
- Git
- Linux
- QEMU
- SQL
- Search Algorithms
- Sorting

**Skills Required:**
- General software development

**Tasks in this sub-category:**
- `count-call-stack`
- `download-youtube`
- `git-workflow-hack`
- `install-windows-3.11`
- `postgres-csv-clean`
- `qemu-alpine-ssh`

#### Web Scraping

**Task Count:** 54

**Knowledge Domains Required:**
- HTTP/REST
- Python
- Web Scraping

**Skills Required:**
- Data extraction
- HTML parsing
- Request handling

**Tasks in this sub-category:**
- `add-benchmark-lm-eval-harness`
- `analyze-access-logs`
- `ancient-puzzle`
- `blind-maze-explorer-5x5`
- `blind-maze-explorer-algorithm`
- `break-filter-js-from-html`
- `build-cython-ext`
- `build-pmars`
- `catch-me-if-you-can`
- `configure-git-webserver`
- `cprofiling-python`
- `debug-long-program`
- `deterministic-tarball`
- `enemy-grid-escape`
- `extract-moves-from-video`
- ... and 39 more

---

