#!/usr/bin/env python3
"""Test script to verify custom_terminus2 agent can be imported and instantiated."""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

try:
    # Test import
    print("Testing import...")
    from custom_terminus2 import Terminus2
    print("✓ Successfully imported Terminus2")
    
    # Test agent name
    agent_name = Terminus2.name()
    print(f"✓ Agent name: {agent_name}")
    
    # Test that it's a valid agent class (check for required methods)
    required_methods = ['name', 'perform_task']
    for method in required_methods:
        if hasattr(Terminus2, method):
            print(f"✓ Has required method: {method}")
        else:
            print(f"✗ Missing required method: {method}")
            sys.exit(1)
    
    print("\n✅ Custom agent setup is correct!")
    print(f"   You can use it with: --agent-import-path custom_terminus2:Terminus2")
    
except ImportError as e:
    print(f"✗ Import failed: {e}")
    sys.exit(1)
except Exception as e:
    print(f"✗ Error: {e}")
    sys.exit(1)


