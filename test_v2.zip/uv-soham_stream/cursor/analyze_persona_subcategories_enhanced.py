#!/usr/bin/env python3
"""
Enhanced script to analyze terminal-bench tasks and identify:
1. Required personas/designations (using existing analysis)
2. Sub-categories for each persona
3. Knowledge domains and skills required
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple
import yaml
from collections import defaultdict

# Import persona extraction logic from previous script
from analyze_task_personas import (
    PERSONA_KEYWORDS, 
    CATEGORY_PERSONA_MAP,
    extract_personas_from_instruction
)

# Knowledge domain and skill patterns
KNOWLEDGE_PATTERNS = {
    # Programming Languages
    "Python": [r"\bpython\b", r"pandas", r"numpy", r"scipy", r"jupyter", r"pytest", r"\.py\b"],
    "JavaScript": [r"\bjavascript\b", r"\bjs\b", r"node\.js", r"react", r"vue", r"angular", r"\.js\b"],
    "C/C++": [r"\bc\+\+\b", r"\bc\b", r"gcc", r"g\+\+", r"clang", r"cmake", r"makefile", r"\.cpp\b", r"\.c\b"],
    "Rust": [r"\brust\b", r"cargo", r"rustc", r"\.rs\b"],
    "Go": [r"\bgo\b", r"golang", r"\.go\b"],
    "Java": [r"\bjava\b", r"maven", r"gradle", r"\.java\b"],
    "Shell/Bash": [r"\bbash\b", r"\bsh\b", r"shell\s+script", r"\.sh\b"],
    "R": [r"\br\b", r"r\s+script", r"\.r\b"],
    
    # Web Technologies
    "HTML/CSS": [r"\bhtml\b", r"\bcss\b", r"dom", r"webpage", r"\.html\b", r"\.css\b"],
    "HTTP/REST": [r"\bhttp\b", r"\bhttps\b", r"\brest\b", r"api", r"endpoint", r"request", r"response"],
    "Web Scraping": [r"scraper", r"crawler", r"beautifulsoup", r"selenium", r"requests", r"scrapy"],
    
    # Databases
    "SQL": [r"\bsql\b", r"sqlite", r"postgres", r"mysql", r"query", r"schema", r"\.sql\b"],
    "NoSQL": [r"mongodb", r"redis", r"cassandra"],
    
    # ML/AI Frameworks
    "PyTorch": [r"pytorch", r"torch", r"\.pt\b"],
    "TensorFlow": [r"tensorflow", r"keras", r"tf\."],
    "Scikit-learn": [r"scikit-learn", r"sklearn"],
    "HuggingFace": [r"huggingface", r"transformers", r"hf", r"model\s+hub"],
    
    # DevOps Tools
    "Docker": [r"docker", r"container", r"dockerfile", r"docker-compose", r"\.dockerfile"],
    "Kubernetes": [r"kubernetes", r"k8s"],
    "CI/CD": [r"ci/cd", r"jenkins", r"github\s+actions", r"gitlab", r"travis"],
    "Build Systems": [r"makefile", r"cmake", r"maven", r"gradle", r"cargo", r"make\s+file"],
    
    # System Administration
    "Linux": [r"linux", r"kernel", r"systemd", r"initramfs", r"ubuntu", r"debian"],
    "QEMU": [r"qemu"],
    "Networking": [r"tcp", r"udp", r"ip", r"network", r"socket", r"pcap", r"netflow"],
    "Security": [r"ssl", r"tls", r"certificate", r"encryption", r"hash", r"vulnerability", r"exploit"],
    
    # Data Processing
    "Data Analysis": [r"pandas", r"numpy", r"dataframe", r"csv", r"parquet", r"data\s+analysis"],
    "ETL": [r"etl", r"extract", r"transform", r"load", r"pipeline"],
    "Big Data": [r"spark", r"hadoop", r"hdfs", r"kafka"],
    
    # Algorithms & Data Structures
    "Graph Algorithms": [r"graph", r"bfs", r"dfs", r"dijkstra", r"shortest\s+path", r"topological"],
    "Search Algorithms": [r"search", r"binary\s+search", r"linear\s+search"],
    "Sorting": [r"sort", r"quicksort", r"mergesort", r"heapsort"],
    "Dynamic Programming": [r"dynamic\s+programming", r"\bdp\b"],
    
    # Specialized Domains
    "Cryptography": [r"cryptography", r"encryption", r"decryption", r"cipher", r"sha", r"md5", r"aes", r"rsa"],
    "Computer Vision": [r"image", r"opencv", r"cv2", r"pixel", r"vision", r"opencv"],
    "NLP": [r"nlp", r"natural\s+language", r"tokenizer", r"embedding", r"bert", r"gpt"],
    "Reinforcement Learning": [r"reinforcement\s+learning", r"\brl\b", r"gym", r"agent", r"environment"],
    "Game Development": [r"game", r"chess", r"maze", r"puzzle", r"solver", r"board"],
    "Compiler Design": [r"compiler", r"llvm", r"assembly", r"bytecode", r"interpreter", r"gcc", r"clang"],
    "Bioinformatics": [r"dna", r"genome", r"sequence", r"assembly", r"protein", r"biological", r"genetic"],
    "Financial": [r"financial", r"trading", r"portfolio", r"risk", r"derivative", r"option", r"stock"],
    
    # Additional Tools
    "Git": [r"git", r"repository", r"commit", r"branch"],
    "Jupyter": [r"jupyter", r"notebook", r"\.ipynb"],
    "Regular Expressions": [r"regex", r"regular\s+expression", r"re\.", r"pattern\s+matching"],
}

# Sub-category definitions for each persona with required knowledge
PERSONA_SUBCATEGORIES = {
    "Software Engineer": {
        "Web Development": {
            "knowledge": ["HTML/CSS", "JavaScript", "HTTP/REST", "Web Scraping"],
            "skills": ["Frontend frameworks", "API integration", "DOM manipulation"]
        },
        "Backend Development": {
            "knowledge": ["Python", "Java", "Go", "HTTP/REST", "SQL"],
            "skills": ["API design", "Database integration", "Server-side logic"]
        },
        "System Programming": {
            "knowledge": ["C/C++", "Rust", "Linux", "Build Systems"],
            "skills": ["Low-level programming", "Memory management", "System calls"]
        },
        "Scripting & Automation": {
            "knowledge": ["Python", "Shell/Bash"],
            "skills": ["Task automation", "System scripting", "Process management"]
        },
        "Algorithm Implementation": {
            "knowledge": ["Python", "C/C++", "Graph Algorithms", "Search Algorithms"],
            "skills": ["Algorithm design", "Data structures", "Complexity analysis"]
        },
        "API Development": {
            "knowledge": ["HTTP/REST", "Python", "JavaScript", "SQL"],
            "skills": ["RESTful design", "Authentication", "Error handling"]
        },
    },
    "Data Scientist": {
        "Data Analysis": {
            "knowledge": ["Python", "Data Analysis", "Pandas", "Numpy"],
            "skills": ["Statistical analysis", "Data cleaning", "Exploratory data analysis"]
        },
        "Machine Learning": {
            "knowledge": ["Python", "Scikit-learn", "PyTorch", "TensorFlow"],
            "skills": ["Model training", "Feature engineering", "Model evaluation"]
        },
        "Statistical Analysis": {
            "knowledge": ["Python", "R", "Statistics"],
            "skills": ["Hypothesis testing", "Statistical modeling", "Data interpretation"]
        },
        "Data Visualization": {
            "knowledge": ["Python", "Matplotlib", "Seaborn"],
            "skills": ["Data visualization", "Chart creation", "Dashboard design"]
        },
        "Research & Experimentation": {
            "knowledge": ["Jupyter", "Python", "Research Methods"],
            "skills": ["Experimental design", "A/B testing", "Research methodology"]
        },
    },
    "ML Engineer": {
        "Model Training": {
            "knowledge": ["PyTorch", "TensorFlow", "Python", "GPU/CUDA"],
            "skills": ["Deep learning", "Model optimization", "Hyperparameter tuning"]
        },
        "Model Deployment": {
            "knowledge": ["Docker", "API Development", "Python"],
            "skills": ["Model serving", "API development", "Containerization"]
        },
        "Model Optimization": {
            "knowledge": ["PyTorch", "TensorFlow", "Optimization"],
            "skills": ["Performance optimization", "Model compression", "Quantization"]
        },
        "ML Infrastructure": {
            "knowledge": ["Docker", "Kubernetes", "CI/CD"],
            "skills": ["MLOps", "Pipeline automation", "Infrastructure management"]
        },
        "Transfer Learning": {
            "knowledge": ["HuggingFace", "PyTorch", "TensorFlow"],
            "skills": ["Fine-tuning", "Pre-trained models", "Adapter techniques"]
        },
    },
    "DevOps Engineer": {
        "Containerization": {
            "knowledge": ["Docker", "Kubernetes", "Container Orchestration"],
            "skills": ["Container management", "Orchestration", "Service deployment"]
        },
        "CI/CD": {
            "knowledge": ["CI/CD", "GitHub Actions", "Jenkins"],
            "skills": ["Pipeline design", "Automated testing", "Deployment automation"]
        },
        "Infrastructure Management": {
            "knowledge": ["Linux", "Networking", "Security"],
            "skills": ["Infrastructure provisioning", "Configuration management", "Monitoring"]
        },
        "Build & Deployment": {
            "knowledge": ["Build Systems", "Docker", "CI/CD"],
            "skills": ["Build automation", "Release management", "Version control"]
        },
    },
    "System Administrator": {
        "Linux Administration": {
            "knowledge": ["Linux", "System Administration", "Shell/Bash"],
            "skills": ["System configuration", "User management", "Service management"]
        },
        "Network Configuration": {
            "knowledge": ["Networking", "TCP/IP", "Firewall"],
            "skills": ["Network setup", "Routing", "Firewall configuration"]
        },
        "Security Hardening": {
            "knowledge": ["Security", "SSL/TLS", "Certificate Management"],
            "skills": ["Security configuration", "Certificate management", "Access control"]
        },
        "Virtualization": {
            "knowledge": ["QEMU", "Virtualization", "KVM"],
            "skills": ["VM management", "Hypervisor configuration", "Resource allocation"]
        },
        "Service Management": {
            "knowledge": ["Systemd", "Service Configuration", "Cron"],
            "skills": ["Service deployment", "Process management", "Scheduling"]
        },
    },
    "Security Engineer": {
        "Penetration Testing": {
            "knowledge": ["Security", "Vulnerability Assessment", "Exploitation"],
            "skills": ["Security testing", "Vulnerability scanning", "Exploit development"]
        },
        "Cryptography": {
            "knowledge": ["Cryptography", "Encryption", "Hash Functions"],
            "skills": ["Cryptographic protocols", "Key management", "Hash algorithms"]
        },
        "Network Security": {
            "knowledge": ["Networking", "Security", "Firewall"],
            "skills": ["Network security", "Intrusion detection", "Traffic analysis"]
        },
        "Application Security": {
            "knowledge": ["Security", "Code Review", "Vulnerability Scanning"],
            "skills": ["Secure coding", "Vulnerability assessment", "Security auditing"]
        },
    },
    "Database Administrator": {
        "SQL Databases": {
            "knowledge": ["SQL", "PostgreSQL", "MySQL", "Database Design"],
            "skills": ["Database design", "Query optimization", "Schema management"]
        },
        "Database Optimization": {
            "knowledge": ["SQL", "Query Optimization", "Indexing"],
            "skills": ["Performance tuning", "Index optimization", "Query analysis"]
        },
        "Backup & Recovery": {
            "knowledge": ["Backup", "Recovery", "Database Administration"],
            "skills": ["Backup strategies", "Disaster recovery", "Data restoration"]
        },
    },
    "Network Engineer": {
        "Network Protocols": {
            "knowledge": ["Networking", "TCP/IP", "HTTP/HTTPS"],
            "skills": ["Protocol implementation", "Network troubleshooting", "Traffic analysis"]
        },
        "Network Analysis": {
            "knowledge": ["Pcap", "Network Analysis", "Packet Inspection"],
            "skills": ["Packet analysis", "Network monitoring", "Traffic inspection"]
        },
    },
    "Web Developer": {
        "Frontend Development": {
            "knowledge": ["HTML/CSS", "JavaScript", "React", "Vue"],
            "skills": ["UI development", "Responsive design", "Browser APIs"]
        },
        "Backend Development": {
            "knowledge": ["Python", "JavaScript", "HTTP/REST"],
            "skills": ["Server-side logic", "API development", "Database integration"]
        },
        "Web Scraping": {
            "knowledge": ["Web Scraping", "Python", "HTTP/REST"],
            "skills": ["Data extraction", "HTML parsing", "Request handling"]
        },
    },
    "Game Developer": {
        "Game Logic": {
            "knowledge": ["Game Development", "Algorithms & Data Structures"],
            "skills": ["Game mechanics", "State management", "Rule implementation"]
        },
        "AI for Games": {
            "knowledge": ["Reinforcement Learning", "Game Development"],
            "skills": ["AI agents", "Game AI", "Decision making"]
        },
        "Puzzle Solving": {
            "knowledge": ["Algorithms & Data Structures", "Game Development"],
            "skills": ["Algorithm design", "Problem solving", "Optimization"]
        },
    },
    "Compiler Engineer": {
        "Compiler Design": {
            "knowledge": ["Compiler Design", "LLVM", "Assembly"],
            "skills": ["Lexical analysis", "Parsing", "Code generation"]
        },
        "Build Systems": {
            "knowledge": ["Build Systems", "C/C++", "CMake"],
            "skills": ["Build configuration", "Dependency management", "Cross-compilation"]
        },
    },
    "Cryptographer": {
        "Cryptographic Algorithms": {
            "knowledge": ["Cryptography", "Encryption", "Hash Functions"],
            "skills": ["Algorithm implementation", "Cryptographic protocols", "Security analysis"]
        },
        "Cryptanalysis": {
            "knowledge": ["Cryptography", "Security", "Algorithm Analysis"],
            "skills": ["Attack techniques", "Vulnerability analysis", "Security research"]
        },
    },
    "Research Scientist": {
        "Algorithm Research": {
            "knowledge": ["Algorithms & Data Structures", "Research Methods"],
            "skills": ["Algorithm design", "Complexity analysis", "Research methodology"]
        },
        "Mathematical Modeling": {
            "knowledge": ["Mathematics", "Statistics", "Python"],
            "skills": ["Mathematical modeling", "Statistical analysis", "Simulation"]
        },
    },
    "Data Engineer": {
        "ETL Pipelines": {
            "knowledge": ["ETL", "Python", "Data Processing"],
            "skills": ["Pipeline design", "Data transformation", "Workflow automation"]
        },
        "Big Data": {
            "knowledge": ["Big Data", "Spark", "Hadoop"],
            "skills": ["Distributed computing", "Data processing", "Cluster management"]
        },
    },
    "QA Engineer": {
        "Test Automation": {
            "knowledge": ["Python", "Testing Frameworks", "Automation"],
            "skills": ["Test design", "Automation scripting", "Test frameworks"]
        },
        "Debugging": {
            "knowledge": ["Debugging", "Error Handling", "Log Analysis"],
            "skills": ["Bug identification", "Root cause analysis", "Troubleshooting"]
        },
    },
    "Backend Engineer": {
        "API Development": {
            "knowledge": ["HTTP/REST", "Python", "JavaScript", "SQL"],
            "skills": ["RESTful APIs", "Authentication", "Error handling"]
        },
        "Microservices": {
            "knowledge": ["HTTP/REST", "Docker", "API Development"],
            "skills": ["Service architecture", "Inter-service communication", "Scalability"]
        },
    },
    "Frontend Engineer": {
        "UI Development": {
            "knowledge": ["HTML/CSS", "JavaScript", "React", "Vue"],
            "skills": ["Component development", "State management", "User interaction"]
        },
    },
    "Embedded Systems Engineer": {
        "Firmware Development": {
            "knowledge": ["C/C++", "Embedded Systems", "Hardware"],
            "skills": ["Low-level programming", "Hardware interfaces", "Real-time systems"]
        },
    },
    "Bioinformatics Scientist": {
        "Sequence Analysis": {
            "knowledge": ["Bioinformatics", "Python", "Data Analysis"],
            "skills": ["Sequence alignment", "Genomic analysis", "Biological data processing"]
        },
    },
    "Financial Engineer": {
        "Financial Modeling": {
            "knowledge": ["Financial", "Python", "Statistics"],
            "skills": ["Risk modeling", "Portfolio optimization", "Financial analysis"]
        },
    },
}

def extract_knowledge_domains(instruction: str, category: str, tags: List[str]) -> Set[str]:
    """Extract knowledge domains and skills from task."""
    knowledge = set()
    text_lower = instruction.lower()
    
    # Check for knowledge patterns
    for domain, patterns in KNOWLEDGE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                knowledge.add(domain)
                break
    
    return knowledge

def categorize_persona_tasks(persona: str, knowledge_domains: Set[str]) -> List[Dict]:
    """Determine sub-categories for a persona based on knowledge domains."""
    subcategories = []
    
    if persona in PERSONA_SUBCATEGORIES:
        for subcat, details in PERSONA_SUBCATEGORIES[persona].items():
            required_knowledge = details.get("knowledge", [])
            # Check if task has relevant knowledge domains
            if any(knowledge in knowledge_domains for knowledge in required_knowledge):
                subcategories.append({
                    "name": subcat,
                    "knowledge_required": [k for k in required_knowledge if k in knowledge_domains],
                    "skills_required": details.get("skills", [])
                })
    
    # If no subcategory matched, add "General"
    if not subcategories:
        subcategories.append({
            "name": "General",
            "knowledge_required": list(knowledge_domains),
            "skills_required": ["General software development"]
        })
    
    return subcategories

def analyze_all_tasks_enhanced(tasks_dir: Path) -> Tuple[Dict, Dict]:
    """Enhanced analysis with sub-categories and knowledge domains."""
    results = {}
    persona_breakdown = defaultdict(lambda: defaultdict(lambda: {
        "tasks": [],
        "knowledge_domains": set(),
        "skills": set()
    }))
    
    task_dirs = [d for d in tasks_dir.iterdir() if d.is_dir()]
    print(f"Analyzing {len(task_dirs)} tasks with enhanced categorization...")
    
    for task_dir in sorted(task_dirs):
        task_id = task_dir.name
        task_yaml_path = task_dir / "task.yaml"
        
        if not task_yaml_path.exists():
            continue
        
        try:
            with open(task_yaml_path, 'r') as f:
                task_data = yaml.safe_load(f)
            
            instruction = task_data.get('instruction', '')
            category = task_data.get('category', '')
            tags = task_data.get('tags', [])
            
            # Extract personas using existing logic
            personas = extract_personas_from_instruction(instruction, category, tags)
            
            # Extract knowledge domains
            knowledge_domains = extract_knowledge_domains(instruction, category, tags)
            
            # For each persona, determine sub-categories
            task_info = {
                'task_id': task_id,
                'instruction': instruction[:300] + "..." if len(instruction) > 300 else instruction,
                'category': category,
                'tags': tags,
                'knowledge_domains': sorted(list(knowledge_domains)),
            }
            
            for persona in personas:
                subcategories = categorize_persona_tasks(persona, knowledge_domains)
                
                for subcat_info in subcategories:
                    subcat_name = subcat_info["name"]
                    persona_breakdown[persona][subcat_name]["tasks"].append(task_id)
                    persona_breakdown[persona][subcat_name]["knowledge_domains"].update(
                        subcat_info["knowledge_required"]
                    )
                    persona_breakdown[persona][subcat_name]["skills"].update(
                        subcat_info["skills_required"]
                    )
            
            results[task_id] = {
                'instruction': instruction[:200] + "..." if len(instruction) > 200 else instruction,
                'category': category,
                'tags': tags,
                'personas': sorted(list(personas)),
                'knowledge_domains': sorted(list(knowledge_domains)),
            }
            
        except Exception as e:
            print(f"Error processing {task_id}: {e}")
            continue
    
    # Convert sets to lists for JSON serialization
    persona_breakdown_serializable = {}
    for persona, subcats in persona_breakdown.items():
        persona_breakdown_serializable[persona] = {}
        for subcat, data in subcats.items():
            persona_breakdown_serializable[persona][subcat] = {
                "task_count": len(data["tasks"]),
                "tasks": sorted(data["tasks"]),
                "knowledge_domains": sorted(list(data["knowledge_domains"])),
                "skills_required": sorted(list(data["skills"]))
            }
    
    return results, persona_breakdown_serializable

def main():
    tasks_dir = Path("/Users/anshulchauhan/Tech/term/terminal-bench/tasks")
    
    if not tasks_dir.exists():
        print(f"Error: Tasks directory not found: {tasks_dir}")
        return
    
    print("Starting enhanced task persona analysis with sub-categories...")
    results, persona_breakdown = analyze_all_tasks_enhanced(tasks_dir)
    
    # Generate comprehensive report
    output_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.json")
    with open(output_file, 'w') as f:
        json.dump({
            'summary': {
                'total_tasks': len(results),
                'total_personas': len(persona_breakdown),
            },
            'task_results': results,
            'persona_breakdown': persona_breakdown
        }, f, indent=2)
    
    # Generate markdown report
    markdown_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.md")
    with open(markdown_file, 'w') as f:
        f.write("# Terminal-Bench Persona Analysis: Sub-Categories & Knowledge Domains\n\n")
        f.write(f"Total Tasks Analyzed: {len(results)}\n")
        f.write(f"Total Personas Identified: {len(persona_breakdown)}\n\n")
        
        f.write("## Persona Breakdown by Sub-Category\n\n")
        
        for persona in sorted(persona_breakdown.keys()):
            f.write(f"### {persona}\n\n")
            
            total_tasks = sum(subcat["task_count"] for subcat in persona_breakdown[persona].values())
            f.write(f"**Total Tasks:** {total_tasks}\n\n")
            
            for subcat in sorted(persona_breakdown[persona].keys()):
                data = persona_breakdown[persona][subcat]
                
                f.write(f"#### {subcat}\n\n")
                f.write(f"**Task Count:** {data['task_count']}\n\n")
                
                f.write(f"**Knowledge Domains Required:**\n")
                for domain in data['knowledge_domains']:
                    f.write(f"- {domain}\n")
                f.write("\n")
                
                f.write(f"**Skills Required:**\n")
                for skill in data['skills_required']:
                    f.write(f"- {skill}\n")
                f.write("\n")
                
                f.write(f"**Tasks in this sub-category:**\n")
                for task_id in data['tasks'][:15]:  # Show first 15
                    f.write(f"- `{task_id}`\n")
                if len(data['tasks']) > 15:
                    f.write(f"- ... and {len(data['tasks']) - 15} more\n")
                f.write("\n")
            
            f.write("---\n\n")
    
    print(f"\nEnhanced analysis complete!")
    print(f"Results saved to: {output_file}")
    print(f"Markdown report saved to: {markdown_file}")
    print(f"\nPersonas analyzed: {len(persona_breakdown)}")
    for persona in sorted(persona_breakdown.keys()):
        total = sum(s["task_count"] for s in persona_breakdown[persona].values())
        print(f"  {persona}: {total} tasks across {len(persona_breakdown[persona])} sub-categories")

if __name__ == "__main__":
    main()
