#!/usr/bin/env python3
"""
Convert the enhanced persona analysis JSON to YAML format.
"""

import json
import yaml
from pathlib import Path

def main():
    # Read the JSON file
    json_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.json")
    yaml_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.yaml")
    
    with open(json_file, 'r') as f:
        data = json.load(f)
    
    # Convert to YAML
    with open(yaml_file, 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True, width=120)
    
    print(f"YAML file created: {yaml_file}")
    print(f"Total personas: {data['summary']['total_personas']}")
    print(f"Total tasks: {data['summary']['total_tasks']}")

if __name__ == "__main__":
    main()
