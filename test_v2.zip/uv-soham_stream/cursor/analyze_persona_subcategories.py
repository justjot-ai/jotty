#!/usr/bin/env python3
"""
Enhanced script to analyze terminal-bench tasks and identify:
1. Required personas/designations
2. Sub-categories for each persona
3. Knowledge domains and skills required
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple
import yaml
from collections import defaultdict

# Knowledge domain and skill patterns
KNOWLEDGE_PATTERNS = {
    # Programming Languages
    "Python": [r"\bpython\b", r"pandas", r"numpy", r"scipy", r"jupyter", r"pytest"],
    "JavaScript": [r"\bjavascript\b", r"\bjs\b", r"node\.js", r"react", r"vue", r"angular"],
    "C/C++": [r"\bc\+\+\b", r"\bc\b", r"gcc", r"g\+\+", r"clang", r"cmake", r"makefile"],
    "Rust": [r"\brust\b", r"cargo", r"rustc"],
    "Go": [r"\bgo\b", r"golang"],
    "Java": [r"\bjava\b", r"maven", r"gradle"],
    "Shell/Bash": [r"\bbash\b", r"\bsh\b", r"shell\s+script", r"\.sh\b"],
    
    # Web Technologies
    "HTML/CSS": [r"\bhtml\b", r"\bcss\b", r"dom", r"webpage"],
    "HTTP/REST": [r"\bhttp\b", r"\bhttps\b", r"\brest\b", r"api", r"endpoint"],
    "Web Scraping": [r"scraper", r"crawler", r"beautifulsoup", r"selenium", r"requests"],
    
    # Databases
    "SQL": [r"\bsql\b", r"sqlite", r"postgres", r"mysql", r"query", r"schema"],
    "NoSQL": [r"mongodb", r"redis", r"cassandra"],
    
    # ML/AI Frameworks
    "PyTorch": [r"pytorch", r"torch"],
    "TensorFlow": [r"tensorflow", r"keras"],
    "Scikit-learn": [r"scikit-learn", r"sklearn"],
    "HuggingFace": [r"huggingface", r"transformers", r"hf"],
    
    # DevOps Tools
    "Docker": [r"docker", r"container", r"dockerfile", r"docker-compose"],
    "Kubernetes": [r"kubernetes", r"k8s"],
    "CI/CD": [r"ci/cd", r"jenkins", r"github\s+actions", r"gitlab"],
    "Build Systems": [r"makefile", r"cmake", r"maven", r"gradle", r"cargo"],
    
    # System Administration
    "Linux": [r"linux", r"kernel", r"systemd", r"initramfs"],
    "QEMU": [r"qemu"],
    "Networking": [r"tcp", r"udp", r"ip", r"network", r"socket", r"pcap"],
    "Security": [r"ssl", r"tls", r"certificate", r"encryption", r"hash", r"vulnerability"],
    
    # Data Processing
    "Data Analysis": [r"pandas", r"numpy", r"dataframe", r"csv", r"parquet"],
    "ETL": [r"etl", r"extract", r"transform", r"load", r"pipeline"],
    "Big Data": [r"spark", r"hadoop", r"hdfs", r"kafka"],
    
    # Algorithms & Data Structures
    "Graph Algorithms": [r"graph", r"bfs", r"dfs", r"dijkstra", r"shortest\s+path"],
    "Search Algorithms": [r"search", r"binary\s+search", r"linear\s+search"],
    "Sorting": [r"sort", r"quicksort", r"mergesort"],
    "Dynamic Programming": [r"dynamic\s+programming", r"dp"],
    
    # Specialized Domains
    "Cryptography": [r"cryptography", r"encryption", r"decryption", r"cipher", r"sha", r"md5"],
    "Computer Vision": [r"image", r"opencv", r"cv2", r"pixel", r"vision"],
    "NLP": [r"nlp", r"natural\s+language", r"tokenizer", r"embedding"],
    "Reinforcement Learning": [r"reinforcement\s+learning", r"\brl\b", r"gym", r"agent"],
    "Game Development": [r"game", r"chess", r"maze", r"puzzle", r"solver"],
    "Compiler Design": [r"compiler", r"llvm", r"assembly", r"bytecode", r"interpreter"],
    "Bioinformatics": [r"dna", r"genome", r"sequence", r"protein", r"biological"],
    "Financial": [r"financial", r"trading", r"portfolio", r"risk", r"derivative"],
}

# Sub-category definitions for each persona
PERSONA_SUBCATEGORIES = {
    "Software Engineer": {
        "Web Development": ["HTML/CSS", "JavaScript", "HTTP/REST", "Web Scraping"],
        "Backend Development": ["Python", "Java", "Go", "HTTP/REST", "SQL"],
        "System Programming": ["C/C++", "Rust", "Linux", "Build Systems"],
        "Scripting & Automation": ["Python", "Shell/Bash", "Automation"],
        "Algorithm Implementation": ["Algorithms & Data Structures", "Python", "C/C++"],
        "API Development": ["HTTP/REST", "Python", "JavaScript", "SQL"],
    },
    "Data Scientist": {
        "Data Analysis": ["Python", "Data Analysis", "Pandas", "Numpy"],
        "Machine Learning": ["Python", "Scikit-learn", "PyTorch", "TensorFlow"],
        "Statistical Analysis": ["Python", "R", "Statistics"],
        "Data Visualization": ["Python", "Matplotlib", "Seaborn"],
        "Research & Experimentation": ["Jupyter", "Python", "Research Methods"],
    },
    "ML Engineer": {
        "Model Training": ["PyTorch", "TensorFlow", "Python", "GPU/CUDA"],
        "Model Deployment": ["Docker", "API Development", "Python"],
        "Model Optimization": ["PyTorch", "TensorFlow", "Optimization"],
        "ML Infrastructure": ["Docker", "Kubernetes", "CI/CD"],
        "Transfer Learning": ["HuggingFace", "PyTorch", "TensorFlow"],
    },
    "DevOps Engineer": {
        "Containerization": ["Docker", "Kubernetes", "Container Orchestration"],
        "CI/CD": ["CI/CD", "GitHub Actions", "Jenkins", "Automation"],
        "Infrastructure as Code": ["Terraform", "Ansible", "Cloud Platforms"],
        "Monitoring & Logging": ["Monitoring Tools", "Logging", "Alerting"],
        "Build & Deployment": ["Build Systems", "Docker", "CI/CD"],
    },
    "System Administrator": {
        "Linux Administration": ["Linux", "System Administration", "Shell/Bash"],
        "Network Configuration": ["Networking", "TCP/IP", "Firewall"],
        "Security Hardening": ["Security", "SSL/TLS", "Certificate Management"],
        "Virtualization": ["QEMU", "Virtualization", "KVM"],
        "Service Management": ["Systemd", "Service Configuration", "Cron"],
    },
    "Security Engineer": {
        "Penetration Testing": ["Security", "Vulnerability Assessment", "Exploitation"],
        "Cryptography": ["Cryptography", "Encryption", "Hash Functions"],
        "Network Security": ["Networking", "Security", "Firewall"],
        "Application Security": ["Security", "Code Review", "Vulnerability Scanning"],
        "Incident Response": ["Security", "Forensics", "Log Analysis"],
    },
    "Database Administrator": {
        "SQL Databases": ["SQL", "PostgreSQL", "MySQL", "Database Design"],
        "Database Optimization": ["SQL", "Query Optimization", "Indexing"],
        "Backup & Recovery": ["Backup", "Recovery", "Database Administration"],
        "Data Migration": ["SQL", "ETL", "Data Migration"],
    },
    "Network Engineer": {
        "Network Protocols": ["Networking", "TCP/IP", "HTTP/HTTPS"],
        "Network Analysis": ["Pcap", "Network Analysis", "Packet Inspection"],
        "Network Configuration": ["Networking", "Routing", "Firewall"],
    },
    "Web Developer": {
        "Frontend Development": ["HTML/CSS", "JavaScript", "React", "Vue"],
        "Backend Development": ["Python", "JavaScript", "HTTP/REST"],
        "Web Scraping": ["Web Scraping", "Python", "HTTP/REST"],
        "API Integration": ["HTTP/REST", "API Development", "JavaScript"],
    },
    "Game Developer": {
        "Game Logic": ["Game Development", "Algorithms & Data Structures"],
        "AI for Games": ["Reinforcement Learning", "Game Development"],
        "Puzzle Solving": ["Algorithms & Data Structures", "Game Development"],
    },
    "Compiler Engineer": {
        "Compiler Design": ["Compiler Design", "LLVM", "Assembly"],
        "Build Systems": ["Build Systems", "C/C++", "CMake"],
        "Code Generation": ["Compiler Design", "Assembly", "Bytecode"],
    },
    "Cryptographer": {
        "Cryptographic Algorithms": ["Cryptography", "Encryption", "Hash Functions"],
        "Cryptanalysis": ["Cryptography", "Security", "Algorithm Analysis"],
    },
    "Research Scientist": {
        "Algorithm Research": ["Algorithms & Data Structures", "Research Methods"],
        "Mathematical Modeling": ["Mathematics", "Statistics", "Python"],
        "Experimental Design": ["Research Methods", "Statistics", "Python"],
    },
    "Data Engineer": {
        "ETL Pipelines": ["ETL", "Python", "Data Processing"],
        "Big Data": ["Big Data", "Spark", "Hadoop"],
        "Data Warehousing": ["SQL", "ETL", "Data Architecture"],
    },
    "QA Engineer": {
        "Test Automation": ["Python", "Testing Frameworks", "Automation"],
        "Debugging": ["Debugging", "Error Handling", "Log Analysis"],
        "Quality Assurance": ["Testing", "Validation", "Verification"],
    },
    "Backend Engineer": {
        "API Development": ["HTTP/REST", "Python", "JavaScript", "SQL"],
        "Microservices": ["HTTP/REST", "Docker", "API Development"],
        "Database Integration": ["SQL", "Database Design", "API Development"],
    },
    "Frontend Engineer": {
        "UI Development": ["HTML/CSS", "JavaScript", "React", "Vue"],
        "Browser APIs": ["JavaScript", "DOM", "Browser APIs"],
        "Responsive Design": ["HTML/CSS", "UI/UX"],
    },
    "Embedded Systems Engineer": {
        "Firmware Development": ["C/C++", "Embedded Systems", "Hardware"],
        "Device Drivers": ["C/C++", "Linux", "Hardware"],
    },
    "Bioinformatics Scientist": {
        "Sequence Analysis": ["Bioinformatics", "Python", "Data Analysis"],
        "Genomic Data": ["Bioinformatics", "Data Processing", "Python"],
    },
    "Financial Engineer": {
        "Financial Modeling": ["Financial", "Python", "Statistics"],
        "Risk Analysis": ["Financial", "Statistics", "Data Analysis"],
    },
}

def extract_knowledge_domains(instruction: str, category: str, tags: List[str]) -> Set[str]:
    """Extract knowledge domains and skills from task."""
    knowledge = set()
    text_lower = instruction.lower()
    
    # Check for knowledge patterns
    for domain, patterns in KNOWLEDGE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                knowledge.add(domain)
                break
    
    # Add based on category
    category_knowledge = {
        "machine-learning": ["PyTorch", "TensorFlow", "Python"],
        "data-science": ["Python", "Data Analysis", "Pandas"],
        "security": ["Security", "Cryptography"],
        "system-administration": ["Linux", "System Administration"],
        "networking": ["Networking", "TCP/IP"],
        "web-development": ["HTML/CSS", "JavaScript", "HTTP/REST"],
        "games": ["Game Development", "Algorithms & Data Structures"],
        "compiler": ["Compiler Design", "C/C++"],
        "cryptography": ["Cryptography", "Security"],
    }
    
    if category in category_knowledge:
        knowledge.update(category_knowledge[category])
    
    # Add based on tags
    tags_lower = [tag.lower() for tag in tags]
    for tag in tags_lower:
        if "python" in tag:
            knowledge.add("Python")
        elif "javascript" in tag or "js" in tag:
            knowledge.add("JavaScript")
        elif "docker" in tag:
            knowledge.add("Docker")
        elif "ml" in tag or "machine-learning" in tag:
            knowledge.add("PyTorch")
            knowledge.add("TensorFlow")
        elif "web" in tag:
            knowledge.add("HTML/CSS")
            knowledge.add("HTTP/REST")
        elif "sql" in tag or "database" in tag:
            knowledge.add("SQL")
    
    return knowledge

def categorize_persona_tasks(persona: str, knowledge_domains: Set[str]) -> List[str]:
    """Determine sub-categories for a persona based on knowledge domains."""
    subcategories = []
    
    if persona in PERSONA_SUBCATEGORIES:
        for subcat, required_knowledge in PERSONA_SUBCATEGORIES[persona].items():
            # Check if task has relevant knowledge domains
            if any(knowledge in knowledge_domains for knowledge in required_knowledge):
                subcategories.append(subcat)
    
    return subcategories if subcategories else ["General"]

def analyze_all_tasks_enhanced(tasks_dir: Path) -> Dict:
    """Enhanced analysis with sub-categories and knowledge domains."""
    results = {}
    persona_tasks = defaultdict(lambda: defaultdict(list))
    
    task_dirs = [d for d in tasks_dir.iterdir() if d.is_dir()]
    print(f"Analyzing {len(task_dirs)} tasks with enhanced categorization...")
    
    for task_dir in sorted(task_dirs):
        task_id = task_dir.name
        task_yaml_path = task_dir / "task.yaml"
        
        if not task_yaml_path.exists():
            continue
        
        try:
            with open(task_yaml_path, 'r') as f:
                task_data = yaml.safe_load(f)
            
            instruction = task_data.get('instruction', '')
            category = task_data.get('category', '')
            tags = task_data.get('tags', [])
            
            # Extract knowledge domains
            knowledge_domains = extract_knowledge_domains(instruction, category, tags)
            
            # Get personas (simplified - using previous logic)
            # For now, we'll use a simplified approach
            personas = set()
            if category in ["games", "game"]:
                personas.add("Game Developer")
            if "security" in category or "security" in " ".join(tags).lower():
                personas.add("Security Engineer")
            if "data" in category or "ml" in category or "machine-learning" in category:
                personas.add("Data Scientist")
                personas.add("ML Engineer")
            if "system" in category:
                personas.add("System Administrator")
                personas.add("DevOps Engineer")
            if "web" in category or any("web" in tag.lower() for tag in tags):
                personas.add("Web Developer")
            if "docker" in instruction.lower() or "container" in instruction.lower():
                personas.add("DevOps Engineer")
            if "sql" in instruction.lower() or "database" in instruction.lower():
                personas.add("Database Administrator")
            if "compiler" in instruction.lower() or "build" in instruction.lower():
                personas.add("Compiler Engineer")
            if not personas:
                personas.add("Software Engineer")
            
            # For each persona, determine sub-categories
            task_info = {
                'task_id': task_id,
                'instruction': instruction[:300] + "..." if len(instruction) > 300 else instruction,
                'category': category,
                'tags': tags,
                'knowledge_domains': sorted(list(knowledge_domains)),
            }
            
            for persona in personas:
                subcategories = categorize_persona_tasks(persona, knowledge_domains)
                task_info['persona'] = persona
                task_info['subcategories'] = subcategories
                
                # Group by persona and subcategory
                for subcat in subcategories:
                    persona_tasks[persona][subcat].append(task_info)
            
            results[task_id] = {
                'instruction': instruction[:200] + "..." if len(instruction) > 200 else instruction,
                'category': category,
                'tags': tags,
                'personas': sorted(list(personas)),
                'knowledge_domains': sorted(list(knowledge_domains)),
            }
            
        except Exception as e:
            print(f"Error processing {task_id}: {e}")
            continue
    
    return results, persona_tasks

def main():
    tasks_dir = Path("/Users/anshulchauhan/Tech/term/terminal-bench/tasks")
    
    if not tasks_dir.exists():
        print(f"Error: Tasks directory not found: {tasks_dir}")
        return
    
    print("Starting enhanced task persona analysis...")
    results, persona_tasks = analyze_all_tasks_enhanced(tasks_dir)
    
    # Generate comprehensive report
    output_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.json")
    with open(output_file, 'w') as f:
        json.dump({
            'task_results': results,
            'persona_breakdown': {
                persona: {
                    subcat: {
                        'task_count': len(tasks),
                        'knowledge_domains': sorted(list(set(
                            domain for task in tasks 
                            for domain in task.get('knowledge_domains', [])
                        ))),
                        'tasks': [task['task_id'] for task in tasks]
                    }
                    for subcat, tasks in subcats.items()
                }
                for persona, subcats in persona_tasks.items()
            }
        }, f, indent=2)
    
    # Generate markdown report
    markdown_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas-enhanced.md")
    with open(markdown_file, 'w') as f:
        f.write("# Terminal-Bench Persona Analysis: Sub-Categories & Knowledge Domains\n\n")
        f.write(f"Total Tasks Analyzed: {len(results)}\n\n")
        
        f.write("## Persona Breakdown by Sub-Category\n\n")
        
        for persona in sorted(persona_tasks.keys()):
            f.write(f"### {persona}\n\n")
            
            for subcat in sorted(persona_tasks[persona].keys()):
                tasks = persona_tasks[persona][subcat]
                knowledge_domains = sorted(list(set(
                    domain for task in tasks 
                    for domain in task.get('knowledge_domains', [])
                )))
                
                f.write(f"#### {subcat}\n\n")
                f.write(f"**Task Count:** {len(tasks)}\n\n")
                f.write(f"**Knowledge Domains & Skills Required:**\n")
                for domain in knowledge_domains:
                    f.write(f"- {domain}\n")
                f.write(f"\n**Tasks:**\n")
                for task in tasks[:10]:  # Show first 10
                    f.write(f"- `{task['task_id']}`\n")
                if len(tasks) > 10:
                    f.write(f"- ... and {len(tasks) - 10} more\n")
                f.write("\n")
            
            f.write("---\n\n")
    
    print(f"\nEnhanced analysis complete!")
    print(f"Results saved to: {output_file}")
    print(f"Markdown report saved to: {markdown_file}")
    print(f"\nPersonas analyzed: {len(persona_tasks)}")

if __name__ == "__main__":
    main()
