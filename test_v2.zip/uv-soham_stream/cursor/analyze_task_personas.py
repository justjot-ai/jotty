#!/usr/bin/env python3
"""
Script to analyze terminal-bench tasks and identify required personas/designations
for solving each task.
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Set
import yaml
from collections import defaultdict

# Mapping of keywords/patterns to personas
PERSONA_KEYWORDS = {
    "Software Engineer": [
        "code", "programming", "script", "function", "class", "module", "api",
        "debug", "fix bug", "implement", "refactor", "test", "unit test",
        "software", "application", "library", "package", "repository"
    ],
    "DevOps Engineer": [
        "docker", "container", "kubernetes", "deploy", "ci/cd", "pipeline",
        "infrastructure", "server", "nginx", "apache", "monitoring", "logging",
        "build", "compile", "makefile", "cmake", "automation", "orchestration"
    ],
    "System Administrator": [
        "linux", "kernel", "initramfs", "qemu", "permissions", "user", "group",
        "system", "service", "daemon", "cron", "network", "firewall", "ssl",
        "certificate", "ssh", "server setup", "system configuration"
    ],
    "Data Scientist": [
        "data", "dataset", "csv", "parquet", "pandas", "numpy", "analysis",
        "machine learning", "model", "training", "inference", "prediction",
        "statistics", "regression", "classification", "clustering", "neural network",
        "tensorflow", "pytorch", "scikit-learn", "jupyter", "notebook"
    ],
    "ML Engineer": [
        "model", "training", "inference", "pytorch", "tensorflow", "keras",
        "neural network", "deep learning", "gpu", "cuda", "optimization",
        "hyperparameter", "fine-tuning", "transfer learning", "lora", "adapter"
    ],
    "Security Engineer": [
        "security", "vulnerability", "exploit", "penetration", "encryption",
        "hash", "crack", "password", "authentication", "authorization", "ssl",
        "tls", "certificate", "vulhub", "rce", "injection", "sql injection"
    ],
    "Database Administrator": [
        "database", "sql", "sqlite", "postgres", "mysql", "query", "schema",
        "table", "index", "migration", "backup", "recovery", "transaction"
    ],
    "Network Engineer": [
        "network", "tcp", "udp", "http", "https", "rest", "api", "grpc",
        "socket", "protocol", "packet", "pcap", "netflow", "routing"
    ],
    "Web Developer": [
        "web", "html", "css", "javascript", "react", "frontend", "backend",
        "scraper", "crawler", "http", "request", "response", "server", "client"
    ],
    "Game Developer": [
        r"\bchess\b", r"\bmaze\b", r"\bpuzzle\b", r"\bgame\s+(board|state|engine|logic)",
        r"reinforcement learning", r"\brl\b", r"gym\s+environment", r"game\s+development",
        r"play\s+(zork|lord|game)", r"winning\s+hand", r"game\s+solver"
    ],
    "Compiler Engineer": [
        "compiler", "gcc", "clang", "llvm", "assembly", "bytecode", "interpreter",
        "build", "compile", "link", "object file", "binary", "executable"
    ],
    "Cryptographer": [
        "cryptography", "encryption", "decryption", "cipher", "hash", "sha",
        "md5", "rsa", "aes", "cryptanalysis", "differential", "linear"
    ],
    "Research Scientist": [
        "research", "paper", "algorithm", "optimization", "mathematical",
        "proof", "theorem", "eigenvalue", "eigenvector", "matrix", "linear algebra"
    ],
    "Data Engineer": [
        "etl", "pipeline", "data processing", "transform", "aggregate",
        "batch", "stream", "kafka", "spark", "hadoop", "hdfs", "reshard"
    ],
    "QA Engineer": [
        r"\btest\b", r"testing", r"quality", r"validation", r"verification",
        r"debug", r"troubleshoot", r"fix\s+(bug|error|issue)", r"error\s+handling"
    ],
    "Backend Engineer": [
        "backend", "server", "api", "rest", "grpc", "microservice", "service",
        "endpoint", "handler", "controller", "middleware"
    ],
    "Frontend Engineer": [
        "frontend", "ui", "user interface", "react", "vue", "angular", "html",
        "css", "javascript", "browser", "dom"
    ],
    "Embedded Systems Engineer": [
        "embedded", "firmware", "microcontroller", "arduino", "raspberry pi",
        "hardware", "driver", "kernel module", "device", "gpio"
    ],
    "Bioinformatics Scientist": [
        "dna", "genome", "sequence", "assembly", "protein", "bioinformatics",
        "biological", "genetic", "molecular"
    ],
    "Financial Engineer": [
        "financial", "trading", "portfolio", "risk", "derivative", "option",
        "stock", "market", "bank", "transaction"
    ]
}

# Category to persona mapping
CATEGORY_PERSONA_MAP = {
    "file-operations": ["Software Engineer"],
    "games": ["Game Developer", "Software Engineer"],
    "system-administration": ["System Administrator", "DevOps Engineer"],
    "machine-learning": ["ML Engineer", "Data Scientist"],
    "security": ["Security Engineer"],
    "networking": ["Network Engineer"],
    "web-development": ["Web Developer", "Backend Engineer", "Frontend Engineer"],
    "compiler": ["Compiler Engineer"],
    "cryptography": ["Cryptographer"],
    "research": ["Research Scientist"],
    "data-engineering": ["Data Engineer"],
    "database": ["Database Administrator"],
    "embedded": ["Embedded Systems Engineer"],
    "bioinformatics": ["Bioinformatics Scientist"],
    "financial": ["Financial Engineer"]
}


def extract_personas_from_instruction(instruction: str, category: str, tags: List[str]) -> Set[str]:
    """Extract personas from instruction text, category, and tags."""
    personas = set()
    instruction_lower = instruction.lower()
    
    # Add personas based on category (primary personas)
    if category in CATEGORY_PERSONA_MAP:
        personas.update(CATEGORY_PERSONA_MAP[category])
    
    # Check instruction text for keywords (using regex for more precise matching)
    for persona, keywords in PERSONA_KEYWORDS.items():
        for keyword in keywords:
            # Check if keyword is a regex pattern or plain string
            if keyword.startswith('\\b') or '\\' in keyword:
                # It's a regex pattern
                if re.search(keyword, instruction_lower, re.IGNORECASE):
                    personas.add(persona)
                    break
            else:
                # Plain string matching
                if keyword.lower() in instruction_lower:
                    personas.add(persona)
                    break
    
    # Check tags for additional context
    tags_lower = [tag.lower() for tag in tags]
    for tag in tags_lower:
        if "ml" in tag or "machine-learning" in tag:
            personas.add("ML Engineer")
            personas.add("Data Scientist")
        elif "security" in tag:
            personas.add("Security Engineer")
        elif "web" in tag or "frontend" in tag or "backend" in tag:
            personas.add("Web Developer")
        elif "database" in tag or "sql" in tag:
            personas.add("Database Administrator")
        elif "devops" in tag or "docker" in tag:
            personas.add("DevOps Engineer")
        elif "system" in tag or "sysadmin" in tag:
            personas.add("System Administrator")
        elif "data" in tag:
            personas.add("Data Scientist")
            personas.add("Data Engineer")
    
    # If no personas found, default to Software Engineer
    if not personas:
        personas.add("Software Engineer")
    
    return personas


def analyze_all_tasks(tasks_dir: Path) -> Dict[str, Dict]:
    """Analyze all tasks and extract personas."""
    results = {}
    task_dirs = [d for d in tasks_dir.iterdir() if d.is_dir()]
    
    print(f"Analyzing {len(task_dirs)} tasks...")
    
    for task_dir in sorted(task_dirs):
        task_id = task_dir.name
        task_yaml_path = task_dir / "task.yaml"
        
        if not task_yaml_path.exists():
            print(f"Warning: {task_id} has no task.yaml")
            continue
        
        try:
            with open(task_yaml_path, 'r') as f:
                task_data = yaml.safe_load(f)
            
            instruction = task_data.get('instruction', '')
            category = task_data.get('category', '')
            tags = task_data.get('tags', [])
            
            personas = extract_personas_from_instruction(instruction, category, tags)
            
            results[task_id] = {
                'instruction': instruction[:200] + "..." if len(instruction) > 200 else instruction,
                'category': category,
                'tags': tags,
                'personas': sorted(list(personas))
            }
            
        except Exception as e:
            print(f"Error processing {task_id}: {e}")
            continue
    
    return results


def generate_summary(results: Dict[str, Dict]) -> Dict:
    """Generate summary statistics."""
    persona_counts = defaultdict(int)
    category_counts = defaultdict(int)
    
    for task_id, data in results.items():
        for persona in data['personas']:
            persona_counts[persona] += 1
        category_counts[data['category']] += 1
    
    return {
        'total_tasks': len(results),
        'persona_counts': dict(sorted(persona_counts.items(), key=lambda x: x[1], reverse=True)),
        'category_counts': dict(sorted(category_counts.items(), key=lambda x: x[1], reverse=True))
    }


def main():
    tasks_dir = Path("/Users/anshulchauhan/Tech/term/terminal-bench/tasks")
    
    if not tasks_dir.exists():
        print(f"Error: Tasks directory not found: {tasks_dir}")
        return
    
    print("Starting task persona analysis...")
    results = analyze_all_tasks(tasks_dir)
    
    summary = generate_summary(results)
    
    # Save detailed results
    output_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas.json")
    with open(output_file, 'w') as f:
        json.dump({
            'summary': summary,
            'tasks': results
        }, f, indent=2)
    
    # Generate markdown report
    markdown_file = Path("/Users/anshulchauhan/Tech/term/terminal-bench-personas.md")
    with open(markdown_file, 'w') as f:
        f.write("# Terminal-Bench Task Persona Analysis\n\n")
        f.write(f"Total Tasks Analyzed: {summary['total_tasks']}\n\n")
        
        f.write("## Persona Distribution\n\n")
        f.write("| Persona | Count | Percentage |\n")
        f.write("|---------|-------|------------|\n")
        for persona, count in summary['persona_counts'].items():
            percentage = (count / summary['total_tasks']) * 100
            f.write(f"| {persona} | {count} | {percentage:.1f}% |\n")
        
        f.write("\n## Category Distribution\n\n")
        f.write("| Category | Count |\n")
        f.write("|----------|-------|\n")
        for category, count in summary['category_counts'].items():
            f.write(f"| {category} | {count} |\n")
        
        f.write("\n## Task-to-Persona Mapping\n\n")
        f.write("| Task ID | Category | Primary Personas | All Personas |\n")
        f.write("|---------|----------|------------------|-------------|\n")
        for task_id, data in sorted(results.items()):
            # Identify primary personas (from category or most specific)
            primary_personas = []
            category = data['category']
            if category in CATEGORY_PERSONA_MAP:
                primary_personas = [p for p in data['personas'] if p in CATEGORY_PERSONA_MAP[category]]
            if not primary_personas:
                # If no category match, use first 2-3 most specific personas
                primary_personas = data['personas'][:3]
            
            primary_str = ", ".join(primary_personas) if primary_personas else "Software Engineer"
            all_personas_str = ", ".join(data['personas'])
            f.write(f"| {task_id} | {data['category']} | {primary_str} | {all_personas_str} |\n")
        
        f.write("\n## Detailed Task Instructions\n\n")
        for task_id, data in sorted(results.items()):
            f.write(f"### {task_id}\n\n")
            f.write(f"**Category:** {data['category']}\n\n")
            f.write(f"**Tags:** {', '.join(data['tags']) if data['tags'] else 'None'}\n\n")
            f.write(f"**Required Personas:** {', '.join(data['personas'])}\n\n")
            f.write(f"**Instruction:**\n{data['instruction']}\n\n")
            f.write("---\n\n")
    
    print(f"\nAnalysis complete!")
    print(f"Results saved to: {output_file}")
    print(f"Markdown report saved to: {markdown_file}")
    print(f"\nSummary:")
    print(f"  Total tasks: {summary['total_tasks']}")
    print(f"  Unique personas: {len(summary['persona_counts'])}")
    print(f"\nTop 10 personas:")
    for persona, count in list(summary['persona_counts'].items())[:10]:
        print(f"  {persona}: {count} tasks")


if __name__ == "__main__":
    main()
