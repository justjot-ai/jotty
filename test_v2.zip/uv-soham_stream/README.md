# Term - Multi-Agent AI System

A sophisticated multi-agent AI system integrating Surface (DSPy-based agents) and Synapse (swarm intelligence) for complex task automation.

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- Poetry (dependency management)
- Selenium WebDriver (for browser automation)

### Installation

```bash
# Install dependencies
poetry install

# For browser automation, also install Selenium
poetry add selenium

# Install browser drivers (Chrome)
# macOS
brew install chromedriver

# Or download from: https://chromedriver.chromium.org/
```

### Running Examples

```bash
# Surface agents
poetry run python surface/example_browser_simple.py

# With LiteLLM router
./run_with_litellm_router.sh
```

## 📚 Documentation

- **[Project Structure](PROJECT_STRUCTURE.md)** - Complete folder organization guide
- **[Surface Documentation](surface/)** - DSPy agent system
- **[Synapse Documentation](Synapse/README.md)** - Swarm intelligence system
- **[ADRs](docs/adr/)** - Architectural decisions
- **[Design Docs](docs/design/)** - System design documents

## 🎯 Core Components

### Surface Agents

DSPy-based multi-agent system with specialized agents:

- **BrowserExecutor** - Browser automation with Selenium
- **CodeMaster** - Code generation and modification
- **DataMind** - Data analysis and processing
- **SysOps** - System operations and DevOps
- **SecureSentry** - Security analysis
- **ScienceCore** - Scientific computing
- **DomainExpert** - Domain-specific expertise

**[Learn more →](surface/)**

### Synapse

Advanced swarm intelligence system featuring:

- Multi-agent collaboration
- Reinforcement learning
- Dynamic task planning
- Memory management
- Context-aware execution

**[Learn more →](Synapse/README.md)**

## 🔧 Key Features

### Browser Automation

Full browser automation capabilities with authentication persistence:

```python
from surface.agents.browser_executor import BrowserExecutorAgent

agent = BrowserExecutorAgent(max_iters=50)
result = agent(instruction="Navigate to example.com and extract data")
```

**Features:**
- ✅ Persistent authentication across runs
- ✅ Session management (cookies, profiles)
- ✅ Headless and headed modes
- ✅ Screenshot capture
- ✅ JavaScript execution
- ✅ Multiple browser support

**[Browser Automation Guide →](surface/BROWSER_PERSISTENCE_GUIDE.md)**

### Terminal Integration

Execute shell commands through specialized agents:

- Safe command execution
- Output capture and parsing
- Session state management
- Cross-platform support

### Web Search

Integrated web search capabilities for research and data gathering.

## 📁 Project Structure

```
term/
├── surface/              # DSPy agent system
├── Synapse/             # Swarm intelligence
├── terminal-bench/      # Terminal benchmarking
├── docs/                # All documentation
│   ├── adr/            # Architecture decisions
│   ├── design/         # Design documents
│   ├── planning/       # Project planning
│   ├── analysis/       # Analysis reports
│   └── review/         # A-Team reviews
├── scripts/            # Utility scripts
├── tests/              # Test suite
└── working/            # Temporary files
```

**[Full Structure Guide →](PROJECT_STRUCTURE.md)**

## 🧪 Testing

```bash
# Run tests
poetry run pytest tests/

# Run specific test
poetry run pytest tests/test_browser_no_terminal.py

# With coverage
poetry run pytest --cov=surface tests/
```

## 🛠️ Development

### Running with DSPy Configuration

The project uses DSPy with custom LLM configurations:

```bash
# Standard run
./run_with_litellm_router.sh

# Browser automation
./run_browser_example.sh
```

### Creating New Agents

1. Create agent class in `surface/src/surface/agents/`
2. Define signature in `surface/src/surface/signatures/`
3. Add tools in `surface/src/surface/tools/`
4. Create ADR in `docs/adr/`

**Example:**

```python
from surface.agents.base_agent import BaseSwarmAgent
from surface.signatures.your_signature import YourSignature

class YourAgent(BaseSwarmAgent):
    AGENT_NAME = "YourAgent"
    SIGNATURE_CLASS = YourSignature
    TOOLS = [tool1, tool2, tool3]
```

### Adding Documentation

Per user rules:

- ✅ **ADRs** → `docs/adr/` (for design decisions)
- ✅ **Reviews** → `docs/review/` (A-Team reviews)
- ✅ **Tests** → `tests/` (always)
- ❌ Never create loose `.md` files in root

## 🤝 A-Team Review Process

Before finalizing changes, conduct toxic team debate:

```bash
# Reviews are stored in docs/review/
ls docs/review/
```

Team members should challenge each other's approaches before implementation.

## 🔐 Security

- Browser profiles stored in `~/.browser_executor/profiles/`
- Cookies saved locally with user-only permissions
- No credentials in version control
- Use `.env` for sensitive configuration

## 📊 Performance

- Profiling data: `profiling/`
- Logs: `logs/`
- Analysis: `docs/analysis/`

## 🐛 Troubleshooting

### Common Issues

**Browser automation fails:**
```bash
# Install Selenium
poetry add selenium

# Install ChromeDriver
brew install chromedriver  # macOS
```

**Import errors:**
```bash
# Use poetry run
poetry run python surface/example_browser_simple.py

# Or activate venv
poetry shell
python surface/example_browser_simple.py
```

**Terminal session errors:**
Some agents don't need terminal sessions (e.g., BrowserExecutor).
See: [WHY_TERMINAL_SESSION_NOT_NEEDED.md](surface/WHY_TERMINAL_SESSION_NOT_NEEDED.md)

## 📖 Additional Resources

### Browser Automation
- [WhatsApp Persistence How-To](surface/WHATSAPP_PERSISTENCE_HOWTO.md)
- [Browser Executor Setup](surface/BROWSER_EXECUTOR_SETUP.md)
- [Persistence Guide](surface/BROWSER_PERSISTENCE_GUIDE.md)

### System Design
- [Agent Tool Assignment](docs/adr/agent-tool-assignment-refactoring.md)
- [Browser Authentication](docs/adr/browser-authentication-persistence.md)
- [Optional Terminal Session](docs/adr/optional-terminal-session-for-agents.md)

### Planning
- [DAG Structure](docs/planning/dag_diagram.md)
- [Task Breakdown](docs/planning/tasks_detailed.txt)
- [Actor Assignments](docs/planning/actor_assignments.txt)

## 📝 Contributing

1. Follow modular code practices (user rule)
2. Create ADRs for significant changes
3. Add tests for new features
4. Conduct A-Team review before finalizing
5. Keep documentation updated

## 📄 License

[Your License Here]

## 🙋 Support

For issues and questions:
- Check `docs/` for relevant documentation
- Review ADRs in `docs/adr/`
- See examples in `surface/example_*.py`
- Check troubleshooting sections in component-specific docs

---

**Last Updated:** January 30, 2026
